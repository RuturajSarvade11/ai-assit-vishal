# Client Extension Testing Manual

## Purpose
This manual explains how to test the VS Code extension for:
- current error recommendation
- MCP tool based recommendation
- final fix learning flow
- repeat error latest solution flow

## Scope
This manual is only for extension testing.
It is not for backend development testing.

## Installation from VSIX
1. Open VS Code
2. Open Extensions view
3. Click the `...` menu in Extensions
4. Click `Install from VSIX...`
5. Select the shared `.vsix` file
6. Wait until installation is completed

## After Installation
1. Press `Ctrl+Shift+P`
2. Run command: `Developer: Reload Window`
3. Wait for VS Code window to reload
4. If needed, close VS Code and open it again

## Important Model Check
Before MCP or recommendation testing, always confirm the selected Copilot model is `Claude Sonnet 4.5`.

### Expected Result
- active model is `Claude Sonnet 4.5`
- do not test MCP recommendation flow with another model unless agreed separately

## Test Setup
Client should have:
1. VS Code installed
2. Extension installed from VSIX
3. Workspace opened for the target Gradle project
4. Backend URL reachable
5. Build project with `report.html` generation available
6. GitHub Copilot model selected as `Claude Sonnet 4.5`

## How to Open Logs
### Extension Logs
1. Press `Ctrl+Shift+U` to open Output
2. Check the output channel related to the extension if available
3. Also check `Help -> Toggle Developer Tools` if needed

### Gradle Build Failure Logs
1. Run the Gradle build
2. Check the terminal output for build failure
3. Check generated `report.html`
4. Use the same error during testing

## Important Files
Client should know these files during test:
- workspace project folder
- `build/.../report.html`
- files changed in the solution
- VS Code Output logs
- Gradle build failure logs

## Test Case 1: Extension Startup
### Steps
1. Open VS Code
2. Open the project workspace
3. Wait for extension startup
4. Open extension output/logs if needed

### Expected Result
- extension activates
- FileWatcher starts
- report discovery starts
- no startup error is shown

## Test Case 2: report.html Detection
### Steps
1. Run a Gradle build that creates `report.html`
2. Wait for extension log update
3. Confirm report file is detected

### Expected Result
- extension detects `report.html`
- BuildReportWatcher starts
- report file changes are watched

## Test Case 3: Current Error Recommendation from Command
### Steps
1. Make Gradle build fail with an ERROR in `report.html`
2. In VS Code run command:
   `AI Assisted: Recommend Fix For Current Error`
3. Wait for recommendation result

### Expected Result
- extension sends current `report.html` to backend
- backend returns recommendation JSON
- extension shows:
  - request id
  - diff link
  - file names
  - exact changes

## Test Case 4: Recommendation Format Check
### Steps
1. Run recommendation for an error with at least one saved solution
2. Read the result shown in extension

### Expected Result
- result format is clear and readable
- request id is shown
- diff link is shown
- file names are shown
- exact changes are shown

## Test Case 5: Duplicate Same Request ID
### Steps
1. Trigger recommendation where backend top 2 contains same `request_id` more than once
2. Check extension output

### Expected Result
- same `request_id` is shown only once in extension output
- if two different `request_id` values come, both should be shown

## Test Case 6: Diff Link Check
### Steps
1. Trigger recommendation
2. Click the diff link for one recommendation

### Expected Result
- diff page opens
- correct request diff is shown
- no broken or empty page

## Test Case 7: Final Fix Learning Flow
### Steps
1. Start with a known build error
2. Apply a fix
3. Complete final build flow
4. Ensure final solution is stored by backend

### Expected Result
- final build payload is stored
- archive flow completes
- solution becomes available for future recommendation

## Test Case 8: Same Exact Error Solved Again
### Steps
1. Use one exact error message and save solution A
2. Use the same exact error message again and save updated solution B
3. Trigger recommendation for the same exact error

### Expected Result
- latest solution B should come first
- older solution A can still appear as second result
- updated solution should be present in top 2

## Test Case 9: MCP Tool Flow
### Steps
1. Make sure MCP is enabled in VS Code
2. Confirm Copilot model is `Claude Sonnet 4.5`
3. Ask Copilot to use the current error recommendation tool
4. Wait for tool result

### Expected Result
- MCP tool reads current workspace report
- MCP tool calls backend recommendation API
- response format matches extension recommendation format

## Test Case 10: No Active Error Case
### Steps
1. Run a successful build or remove current ERROR state
2. Trigger current recommendation command

### Expected Result
- no false error recommendation should be shown
- client should get a clean no-error or no-solution response

## Logs to Share with Test Result
Please share:
1. VS Code extension logs
2. Gradle build failure logs
3. MCP logs if MCP path was tested
4. Backend logs for the same test time
5. Screenshot of recommendation result
6. Screenshot of diff page if diff test was done
7. Exact error message used in test
8. Exact time of test

## Defect Reporting Format
Please report issues using this format:

### Title
Short issue name

### Environment
- VS Code version:
- Extension version:
- Project name:
- Test date/time:

### Steps
1. Step one
2. Step two
3. Step three

### Actual Result
What happened

### Expected Result
What should happen

### Attachments
- logs
- screenshots
- report.html sample if allowed

## Pass Criteria
Testing is successful if:
1. Extension installs from VSIX successfully
2. Window reload works after installation
3. Extension starts without error
4. `report.html` is detected
5. recommendation command works
6. MCP flow works
7. diff link works
8. duplicate same request id is shown once
9. latest saved solution for same exact error comes in top 2

## Notes
- Client does not need to test internal backend code
- Client only needs to test user-visible flow and result correctness
- If backend is unreachable, client should report connection issue with logs
