---
applyTo: '**'
---
## ACTIVATION
- Apply these instructions ONLY IF the user message starts with: `###start`

## GLOBAL RULES (STRICT)
- API response is the only source of truth.
- `report.html` is used only as input context.
- Do not run PowerShell, curl, or localhost commands.
- Do not call `127.0.0.1` or `localhost`.
- Do not guess fixes.
- Output only the required final structure.
- Do not parse report content in stages/chunks.
- Do not perform local analysis if MCP call is possible.
- Do not ask user approval for local commands in this flow.
- Only use MCP tool call for this workflow.

## AUTO TRIGGER (NO UI)
When user message starts with `###start`, do this exact flow:
1. Locate `build/**/report.html` in current workspace.
2. Read full file content in one pass (no staged parsing).
3. Derive `project_name` from current repo folder name (lowercase).
4. If report size <= 1 MB:
   - Call MCP tool `copilot_start_formatted` with:
     - `html`: full report content
     - `project_name`: derived lowercase repo name
5. If report size > 1 MB:
   - Call MCP tool `copilot_report_upload_start(project_name)`.
   - Split report bytes into 256 KB chunks.
   - For each chunk call `copilot_report_upload_append(upload_id, chunk_b64, is_last=false)`.
   - On last chunk call `copilot_report_upload_append(upload_id, chunk_b64, is_last=true)`.
   - Print returned `formatted_output` exactly as-is.
6. If MCP tool is unavailable/fails, stop and return:
   - `MCP unavailable for ###start flow`
   - Do not run fallback shell/API parsing logic.

## MCP TOOL CONTRACT
- Tool: `copilot_start_formatted`
- Input:
  - `html: string`
  - `project_name: string`
- Backend behavior:
  - Executes recommendation pipeline (`/report-errors` logic)
  - Returns deterministic formatted solution text
- Large-file tools:
  - `copilot_report_upload_start(project_name)`
  - `copilot_report_upload_append(upload_id, chunk_b64, is_last)`

## APPROVAL RULE
- For `###start`, approval prompts are allowed only for MCP server/tool invocation.
- Any non-MCP command/tool attempt is forbidden.

## OUTPUT FORMAT (STRICT)
For each solution:
- `Solution <number>`
- `[Compare changes](<compare_diff_link>)`
- `Patch Plan`
- `Required Changes` with steps and:
  - `File: \`...\``
  - `Find: \`...\``
  - `Replace: \`...\``
- Optional `Binary Changes`
- `Validation`

## FORMAT RULES
- File paths must use backticks.
- Download links must be plain URL text.
- No HTML tags.
- No extra sections.
