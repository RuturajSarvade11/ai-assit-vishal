# AI Assisted SW Build

An enterprise Visual Studio Code extension that helps developers **predict and fix software build failures**.
It watches your Gradle/GBE build, warns you which changes are risky **before** you build, and recommends
proven fixes when a build fails.

Pre‑configured for internal use — connects only to the internal AI Assisted SW Build backend (no public
or third‑party services).

---

# 🌟 Overview

AI Assisted SW Build continuously monitors your build output, captures errors from the build report, and
tracks file changes and diffs to help engineers find the root cause of failures — and suggests fixes drawn
from previously resolved builds.

It integrates deeply with VS Code while staying lightweight and safe for secure, internal environments.

---

# ✨ Features

## 🔮 Build Failure Prediction
- Analyzes your changed files **before** you build
- Flags each file **Low / Medium / High** risk
- Highlights the changes most likely to break the build

## 💡 Fix Recommendation
- On a failed build, reads the build report automatically
- Recommends fixes from previously resolved failures, **best match first**
- Helpful / Not‑helpful feedback improves future recommendations

## 🔍 Build Error Detection
- Scans the Gradle/GBE build report (`report.html`)
- Extracts all `Severity: ERROR` diagnostics
- Supports both older and newer GBE/Gradle report formats

## 🧠 Intelligent Monitoring
- Tracks file edits, additions, and deletions after a failed build
- Captures function‑level changes using AST/diff parsing
- Handles Java, Kotlin, XML, C/C++, Ant, and binary files (SHA‑256)

## 🛡️ Enterprise‑Safe
- Pre‑configured backend connection — no manual setup
- Connects only to the internal backend — no public/third‑party calls
- Built for large monorepos and complex build systems

---

# 🚀 How It Works

### 1️⃣ Build Phase
- You run a Gradle/GBE build
- The build generates a `report.html`
- The extension parses errors using a hybrid parser (regex + JS execution)

### 2️⃣ Detection & Prediction
- On a failed build, monitoring mode activates and the FileWatcher tracks changes
- Before building, the risk report predicts which changed files are most likely to fail

### 3️⃣ Recommendation
- The extension correlates diagnostics, file changes, and history
- It presents the most relevant fixes from previously resolved failures

---

# 🛠️ Installation

This is a **private/internal** extension. No backend configuration is required — it is pre‑configured.

1. Install the VSIX (Extensions view → **Install from VSIX…**, or):
   ```bash
   code --install-extension gradle-error-assistant-0.1.0.vsix
   ```
2. Reload the window: **Ctrl+Shift+P → Developer: Reload Window**.
   New windows opened after install load the extension automatically.

---

# 💼 Usage

- **Automatic** — just build your project; the extension captures errors and offers fix recommendations.
- **Build Failure Risk Report** — Command Palette → **AI Assisted: Generate Build Failure Risk Report**.
- **Logs** — Command Palette → **AI Assisted: Open Logs** (or select the **AIASB** channel in the Output panel).

---

# 📁 File Monitoring Behavior

The assistant monitors:
- `build.gradle`, `settings.gradle`, module `.gradle` files
- Kotlin Gradle scripts (`*.kts`)
- All workspace source files changed **after the last failed build**
- XML/UI layout files, C/C++/Header files, Ant files
- Binary files (via SHA‑256 hashing)

All processing happens **locally**, with only the internal backend contacted for recommendations.

---

# 🖥️ Marketplace‑Style Details

| Property | Value |
|---------|--------|
| **Identifier** | rnt.gradle-error-assistant |
| **Version** | 0.1.0 |
| **Last Updated** | Jul 2026 |
| **Publisher** | RNT |
| **VS Code Compatibility** | ^1.106.0 |
| **Activation** | `onStartupFinished` |

---

# 👨‍💻 Commands

| Command | Purpose |
|---------|----------|
| AI Assisted: Generate Build Failure Risk Report | Predict which changed files are risky, before you build |
| Fix Recommendation (`copilot_recommendation_active`) | Recommend fixes for a failed build (also available to GitHub Copilot) |
| AI Assisted: Configure File Handling | Control how binary/large files are handled |
| AI Assisted: Open Logs | Open the extension log (AIASB output channel) |
| AI Assisted: Cache Status / Clear Cache | Inspect / clear the local cache |
| Start AI Assisted SW Build | Manually (re)start the monitoring engine |

---

# 👥 Intended Audience

- Enterprise teams and internal‑only distributed build systems
- Secure engineering environments
- CI/CD pipeline debugging
- Large Gradle/GBE‑based monorepos

---

# 🔒 License

**Internal Use Only** — strictly prohibited from public publishing or redistribution.

## Local MCP Runtime

The extension uses a bundled local MCP runtime.

Client delivery model:
- the client installs the VSIX
- the VSIX must contain `bin/local-mcp-server.exe`
- no separate Node.js installation is required on the client machine

Packaging rule:
- do not build the VSIX unless `bin/local-mcp-server.exe` is present
