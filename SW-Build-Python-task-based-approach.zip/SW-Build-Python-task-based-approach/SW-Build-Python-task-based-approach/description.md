# 🛠️ Build Report Assistant 
**Project:** Schaeffler Error Resolution And Build Failure

## 📖 Executive Summary
The **Build Report Assistant** is an enterprise-grade VS Code extension engineered to track local Gradle build failures, monitor source code changes, and log resolution telemetry. 

It acts as a silent, intelligent background observer. When a developer's build fails, the extension captures the specific compilation errors from the Gradle report and maps them to the workspace files. As the developer fixes the bugs, the extension tracks function-level code modifications. Upon a successful build, it packages the "Before & After" diffs and securely uploads the data to a centralized API.

---

## ✨ Key Features & Resilience Mechanisms
This extension is specifically designed to handle the unpredictable nature of local file systems, heavy build tools, and network instability.

* **Smart File Fallback (Ghost Tracking):** If Gradle fails to provide an exact file path (returning `<unknown>`), the extension automatically falls back to the last modified file to ensure no telemetry is lost.
* **Zero-Crash File Parsing:** Utilizes a custom `waitUntilStable` OS-lock bypass. It waits for Gradle to completely finish writing massive `report.html` files before safely streaming them into memory without crashing the V8 engine.
* **Network Resilience (Auto-Retry):** Background API uploads feature an automatic 3-retry mechanism with a 2-second cooldown to effortlessly survive VPN drops, DNS failures, and server timeouts.
* **Clean User Experience (UX):** Hides ugly, raw JSON stack traces from the user. Instead, it displays clean, temporary VS Code status bar messages (e.g., `☁️ Sync Failed: Server Unreachable`).
* **Zero Memory Leaks:** Employs aggressive background garbage collection. Resolves Promise queues instantly and utilizes a `resetTrackingState()` hard-wipe to clear ghost sessions after every successful build.
* **Multi-Language Function Diffing:** Deep syntax parsing for C, C++, Kotlin, TS/JS, XML, LaTeX, and Ant to track line modifications mapped strictly to the affected code block.

---

## 🏗️ Core Architecture & Modules

### 👁️ Watchers (The Observers)
* **`extension.ts`**: The entry point. Lazy-loads file watchers and uses deep `fs` scanning to bypass `.gitignore` blindspots to find existing build reports on startup.
* **`BuildReportWatcher.ts`**: Safely streams and monitors massive Gradle `report.html` files, extracting the embedded JSON problem payloads without blocking the VS Code UI.
* **`FileWatcher.ts`**: The core brain. Uses `chokidar` to maintain a hash-based memory of workspace files. Orchestrates tracking queues, binary file caches, and manages the start/end of an "Error Cycle".

### 🌐 Services & Data (The Couriers)
* **`ApiService.ts`**: The robust networking layer. Handles JSON/FormData uploads, wraps all requests in protective retry logic, and translates Node.js network errors into readable UI alerts.
* **`EventLogger.ts`**: Formats the final payload. Applies Levenshtein distance calculations to smartly pair removed and added lines, and manages a local fallback backup folder if the remote server goes completely offline.

### ⚙️ Processors & Utilities (The Tools)
* **`JobQueue.ts`**: A strict concurrency queue preventing race conditions when a user hits "Save" rapidly. 
* **`DiffGenerator.ts` & `DiffParser.ts`**: Generates line-by-line diffs and maps them to specific AST/Regex function blocks.
* **`FileUtils.ts`**: Bypasses Windows file locking (`EBUSY`) with `readFileSafe` and handles cross-platform path normalization.
* **`Logger.ts`**: A custom VS Code Output Channel logger featuring precise millisecond timestamps for race-condition debugging.

---

## 🔄 The Extension Lifecycle (End-to-End Flow)

1. **Initialization:** Extension activates and scans the workspace for an existing `build/report.html`.
2. **The Build Fails:** Gradle writes the error report. `BuildReportWatcher` detects it, waits for the OS file lock to release, extracts the JSON, and feeds the errors to the system.
3. **Error Cycle Begins:** `FileWatcher` isolates the broken files, takes a "Before" snapshot (`SnapshotManager`), and begins tracking user keystrokes/saves.
4. **Resolution Phase:** The developer fixes the code. `JobQueue` processes the saves, and `DiffParser` maps the changes to the exact functions being edited.
5. **The Build Succeeds:** A 0-error report triggers the upload phase. `EventLogger` packages the diffs, `ApiService` successfully sends them to the remote server, and the extension performs a hard-reset to clear its memory for the next task.

---

## 📝 Recent Updates & Optimizations
* **Resolved Race Conditions:** Removed temporary file workarounds in favor of direct, lock-safe file stream reading.
* **Memory Optimization:** Fixed an infinite mapping leak in the `JobQueue`.
* **API Reliability:** Implemented silent retry logic for failed API calls that were previously dropping telemetry data without warning.