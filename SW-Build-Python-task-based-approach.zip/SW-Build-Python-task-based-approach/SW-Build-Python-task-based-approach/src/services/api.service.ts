import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import * as crypto from 'crypto';
import { Telemetry } from "../utils/Telemetry";
import { CircuitBreaker, ExponentialBackoff } from "../utils/CircuitBreaker";
import { getConfiguredBackendUrls } from '../utils/BackendConfig';
import { Logger } from '../utils/Logger';
import { collectUsageSignals } from '../data/UsageSignals';

type HttpMethod = 'GET' | 'POST';

type BaseUrlRequestMeta = {
  url: string;
  method: string;
  timeoutMs: number;
  requestId: string;
  startedAt: number;
};

export class ApiService {
  private token?: string;

  private static readonly MAX_RETRIES = 3;
  private static readonly REQUEST_TIMEOUT = 10000;
  private static readonly BASE_CONNECT_COOLDOWN_MS = 60000;
  private static readonly PREDICT_SCOPE_TIMEOUT = 90000;
  private static readonly PREDICT_FILES_BULK_TIMEOUT = 90000;
  private static readonly PREDICT_REPORT_TIMEOUT = 120000;
  private static readonly PREDICT_EMBED_TIMEOUT = 120000;
  /** The server compares at most 5 live artifacts and embeds the last 28,000 chars of each. */
  private static readonly MAX_ARTIFACT_EXCERPTS = 5;
  private static readonly MAX_ARTIFACT_EXCERPT_CHARS = 40000;

  private baseUrls = getConfiguredBackendUrls();

  private baseSkipUntil = new Map<string, number>();
  private circuitBreaker: CircuitBreaker;
  private telemetry?: Telemetry;

  constructor(telemetry?: Telemetry) {
    this.telemetry = telemetry;
    this.circuitBreaker = new CircuitBreaker(5, 60000, 2, telemetry);
  }

  setToken(token: string) {
    this.token = token;
  }

  private getUserFriendlyErrorMessage(error: any): string {
    const cause: any = error?.cause ?? error;
    const code = cause?.code;
    const causeMsg = cause?.message || error?.message || String(error);

    if (error?.name === "AbortError" || String(causeMsg).includes("AbortError")) {
      return "Request Timed Out";
    }

    if (code === "ENOTFOUND" || /ENOTFOUND/i.test(causeMsg)) {
      return "DNS Lookup Failed";
    }

    if (code === "ECONNREFUSED") {
      return "Server Unreachable";
    }

    if (code === "ETIMEDOUT" || /timed out/i.test(causeMsg)) {
      return "Network Timed Out";
    }

    if (/certificate|SSL|TLS|self signed|unable to verify/i.test(causeMsg)) {
      return "SSL/Certificate Issue";
    }

    try {
      const parsed = JSON.parse(causeMsg);

      if (parsed && parsed?.status) {
        if (parsed.status === 401 || parsed?.status === 403) {
          return "Authentication Failed";
        }

        if (parsed?.status >= 500) {
          return `Server Error (${parsed?.status})`;
        }

        return `HTTP Error ${parsed?.status}`;
      }
    } catch {
      // Not JSON, ignore.
    }

    if (String(causeMsg).includes("fetch failed")) {
      return "Network Error";
    }

    return "Unknown Connection Error";
  }

  private async executeWithRetry<T>(
    _operationName: string,
    operation: () => Promise<T>
  ): Promise<T> {
    let lastError: any;

    for (let attempt = 1; attempt <= ApiService.MAX_RETRIES; attempt++) {
      try {
        return await this.circuitBreaker.execute(operation);
      } catch (err: any) {
        lastError = err;

        if (err.message && err.message.includes('Circuit breaker is OPEN')) {
          break;
        }

        if (attempt < ApiService.MAX_RETRIES) {
          await ExponentialBackoff.delay(attempt, 2000, 10000);
        }
      }
    }

    const cleanReason = this.getUserFriendlyErrorMessage(lastError);
    vscode.window.setStatusBarMessage(`$(cloud-error) Sync Failed: ${cleanReason}`, 8000);

    throw lastError;
  }

  private handleFetchError(
    _error: any,
    _context: string,
    _meta: BaseUrlRequestMeta
  ): void {
  }
  private async fetchWithTimeout(
    url: string,
    options: RequestInit,
    timeoutMs: number = ApiService.REQUEST_TIMEOUT,
    externalSignal?: AbortSignal
  ): Promise<Response> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    const abortFromExternal = () => controller.abort();

    if (externalSignal) {
      if (externalSignal.aborted) {
        controller.abort();
      } else {
        externalSignal.addEventListener('abort', abortFromExternal, { once: true });
      }
    }

    try {
      return await fetch(url, {
        ...options,
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeout);
      if (externalSignal) {
        externalSignal.removeEventListener('abort', abortFromExternal);
      }
    }
  }

  private isConnectTimeoutError(error: any): boolean {
    const cause: any = error?.cause ?? error;
    const code = String(cause?.code || '').toUpperCase();
    const msg = String(cause?.message || error?.message || '').toLowerCase();

    return code === 'UND_ERR_CONNECT_TIMEOUT' || msg.includes('connect timeout');
  }

  private markBaseFailure(baseUrl: string, error: any): void {
    if (!this.isConnectTimeoutError(error)) {
      return;
    }

    const until = Date.now() + ApiService.BASE_CONNECT_COOLDOWN_MS;
    this.baseSkipUntil.set(baseUrl, until);
  }

  private markBaseSuccess(baseUrl: string): void {
    this.baseSkipUntil.delete(baseUrl);
  }

  private refreshConfiguredBaseUrls(): void {
    const configuredBaseUrls = getConfiguredBackendUrls();
    if (configuredBaseUrls.length === 0) {
      return;
    }

    const unchanged = configuredBaseUrls.length === this.baseUrls.length
      && configuredBaseUrls.every((baseUrl, index) => baseUrl === this.baseUrls[index]);
    if (unchanged) {
      return;
    }

    this.baseUrls = configuredBaseUrls;
    this.baseSkipUntil.clear();
    Logger.log('[ApiService] backend URLs refreshed', {
      primary: configuredBaseUrls[0] || '',
      fallback: configuredBaseUrls[1] || '',
    });
  }

  private getHealthyBaseUrls(): string[] {
    this.refreshConfiguredBaseUrls();

    const now = Date.now();

    const healthy = this.baseUrls.filter((baseUrl) => {
      return now >= (this.baseSkipUntil.get(baseUrl) || 0);
    });

    return healthy.length > 0 ? healthy : [...this.baseUrls];
  }

  private promoteBaseUrl(baseUrl: string): void {
    if (this.baseUrls[0] === baseUrl) {
      return;
    }

    this.baseUrls = [
      baseUrl,
      ...this.baseUrls.filter((url) => url !== baseUrl)
    ];
  }

  private buildAuthHeaders(contentType?: string): Record<string, string> {
    const headers: Record<string, string> = {};

    if (contentType) {
      headers['Content-Type'] = contentType;
    }

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    return headers;
  }

  private async parseJsonResponse(
    response: Response,
    fallbackMessage: string
  ): Promise<any> {
    if (!response.ok) {
      const errorBody = await response.text();

      throw new Error(JSON.stringify({
        status: response.status,
        message: errorBody || fallbackMessage
      }));
    }

    return response.json();
  }

  private async executeOnHealthyBaseUrls<T>(
    fallbackErrorMessage: string,
    operation: (baseUrl: string) => Promise<T>,
    onError?: (error: any, baseUrl: string) => void
  ): Promise<T> {
    let lastError: any;
    const healthyBaseUrls = this.getHealthyBaseUrls();

    for (const baseUrl of healthyBaseUrls) {
      try {
        const result = await operation(baseUrl);

        this.markBaseSuccess(baseUrl);
        this.promoteBaseUrl(baseUrl);

        return result;
      } catch (error: any) {
        lastError = error;

        this.markBaseFailure(baseUrl, error);
        onError?.(error, baseUrl);
      }
    }

    throw lastError ?? new Error(fallbackErrorMessage);
  }

  private async request(
    method: HttpMethod,
    apiPath: string,
    data?: any,
    timeoutMs: number = ApiService.REQUEST_TIMEOUT
  ): Promise<any> {
    return this.executeWithRetry(`API Request (${method} ${apiPath})`, async () => {
      const headers = this.buildAuthHeaders('application/json');

      return this.executeOnHealthyBaseUrls(
        'All base URLs failed',
        async (baseUrl) => {
          const url = baseUrl + apiPath;
          const requestId = crypto.randomUUID?.() ?? `${Date.now()}`;
          const startedAt = Date.now();

          try {
            const response = await this.fetchWithTimeout(url, {
              method,
              headers,
              body: data ? JSON.stringify(data) : undefined
            }, timeoutMs);

            return this.parseJsonResponse(response, 'API Error');
          } catch (error: any) {
            this.handleFetchError(error, 'API request', {
              url,
              method,
              timeoutMs,
              requestId,
              startedAt
            });

            throw error;
          }
        }
      );
    });
  }

  get(path: string, timeoutMs: number = ApiService.REQUEST_TIMEOUT): Promise<any> {
    return this.request('GET', path, undefined, timeoutMs);
  }

  /** Storage doc §8 / rollout step 5: ask the server BEFORE the popup whether everything is
   *  already stored. Short timeout - any doubt answers "not identical" (fail-open). */
  precheckUpload(payload: any): Promise<any> {
    return this.post('upload-precheck', payload, 5000);
  }

  post(path: string, data: any, timeoutMs: number = ApiService.REQUEST_TIMEOUT): Promise<any> {
    return this.request('POST', path, data, timeoutMs);
  }

  async updateFinalBuildResolutionDescription(
    requestId: string,
    description: string | null
  ): Promise<any> {
    return this.post(`final-build/${encodeURIComponent(requestId)}/resolution-description`, {
      description,
    }, 30000);
  }

  // One-click Helpful / Not-helpful on a recommended fix. Feeds the feedback loop
  // (the human-validation signal the learned step trains on).
  async postRecommendationFeedback(data: {
    request_id: string;
    project_name?: string;
    is_helpful: boolean;
    feedback_token?: string;
    query_signature_hashes?: string[];
  }): Promise<any> {
    return this.post('error-report/feedback', data, 15000);
  }

  async getWorkspaceReportRecommendation(data: {
    project_name: string;
    report_path: string;
    query_text?: string;
    recommendation_scope?: string;
    /** 'td5-log' when report_path is a TD5 build log instead of a Gradle report.html. */
    report_format?: string;
    /** Logs of THIS failure, one entry per file - the evidence that separates fixes whose
     *  error texts are identical. */
    artifact_excerpts?: { name: string; text: string }[];
    /** Basenames of the files changed this cycle - drives the file-identity points. */
    changed_files?: string[];
    /** The task (Gradle) or Target_BuildType (TD5) the developer actually ran. */
    user_task?: string;
    usage?: { installId?: string; extVersion?: string; envKind?: string; usageKey?: string };
    abortSignal?: AbortSignal;
  }): Promise<any> {
    if (!fs.existsSync(data.report_path)) {
      throw new Error(`report file not found: ${data.report_path}`);
    }

    const fileBuf = fs.readFileSync(data.report_path);
    const formData = new FormData();

    formData.append('project_name', (data.project_name || '').trim().toLowerCase());
    formData.append('file', new Blob([new Uint8Array(fileBuf)]), 'report.html');

    // Optional documentation query — drives the document/knowledge search inside the
    // same recommendation flow, so one call returns fix + matching documentation.
    const queryText = String(data.query_text || '').trim();
    if (queryText) {
      formData.append('query_text', queryText);
      formData.append('copilot_query', queryText);
    }

    // Optional recommendation retrieval scope selected in the UI.
    const recommendationScope = String(data.recommendation_scope || '').trim().toLowerCase();
    if (recommendationScope) {
      formData.append('recommendation_scope', recommendationScope);
      formData.append('scope', recommendationScope);
      formData.append('search_scope', recommendationScope);
    }

    const reportFormat = String(data.report_format || '').trim();
    if (reportFormat) {
      formData.append('report_format', reportFormat);
    }

    // Evidence of THIS failure. Logs put the failure LAST, so an oversized file keeps its
    // TAIL; the count is bounded so one cycle's logs cannot balloon the request. The server
    // compares each file on its own (best single pair wins), so files stay separate entries.
    const excerpts = (data.artifact_excerpts || [])
      .filter((e) => e && String(e.text || '').trim())
      .slice(0, ApiService.MAX_ARTIFACT_EXCERPTS)
      .map((e) => {
        const text = String(e.text);
        return {
          name: String(e.name || 'artifact'),
          text: text.length > ApiService.MAX_ARTIFACT_EXCERPT_CHARS
            ? text.slice(text.length - ApiService.MAX_ARTIFACT_EXCERPT_CHARS)
            : text,
        };
      });
    if (excerpts.length > 0) {
      formData.append('artifact_excerpts', JSON.stringify(excerpts));
    }

    const changedFiles = Array.from(new Set((data.changed_files || [])
      .map((f) => path.basename(String(f || '').trim()))
      .filter(Boolean))).slice(0, 20);
    if (changedFiles.length > 0) {
      formData.append('changed_files', JSON.stringify(changedFiles));
    }

    const userTask = String(data.user_task || '').trim();
    if (userTask) {
      formData.append('user_task', userTask);
    }

    // Usage counting only (never affects the ranking): lets the dashboard count asks/answers.
    const usage = data.usage || {};
    if (usage.installId) { formData.append('install_id', String(usage.installId)); }
    if (usage.extVersion) { formData.append('ext_version', String(usage.extVersion)); }
    if (usage.envKind) { formData.append('env_kind', String(usage.envKind)); }
    if (usage.usageKey) { formData.append('usage_key', String(usage.usageKey)); }

    const headers = this.buildAuthHeaders();

    return this.executeOnHealthyBaseUrls(
      'Live recommendation failed on all base URLs',
      async (baseUrl) => {
        // Recommendation runs synchronous LLM analysis + selection on the server, which can
        // take well over a minute under load / rate-limiting. Allow up to 3 minutes before
        // aborting so the extension doesn't time out on a response the backend still returns
        // (Postman, with no timeout, completes the same request).
        const response = await this.fetchWithTimeout(baseUrl + 'error-report', {
          method: 'POST',
          headers,
          body: formData
        }, 180000, data.abortSignal);

        return this.parseJsonResponse(response, 'Live recommendation failed');
      }
    );
  }

  async uploadFiles(
    pathName: string,
    batchId: string,
    files: Array<{
      filePath: string;
      absolutePath: string;
      action: 'added' | 'modified' | 'deleted';
      fileContent?: Buffer;
      projectName?: string;
      artifactGroup?: string;
      taskPath?: string;
      sourceFolder?: string;
      uploadName?: string;
      originalFileName?: string;
    }>,
    timeoutMs: number = ApiService.REQUEST_TIMEOUT,
    developerId: string = 'unknown',
    requestId: string
  ): Promise<any> {
    const formData = new FormData();

    formData.append('uuid', batchId);

    if (requestId) {
      formData.append('request_id', requestId);
    }

    if (developerId) {
      formData.append('developer_id', developerId);
    }

    let filesAdded = 0;

    for (const file of files) {
      let buffer: Buffer | undefined;

      if (file.fileContent) {
        buffer = file.fileContent;
      } else if (file.action === 'deleted') {
        continue;
      } else {
        if (!fs.existsSync(file.absolutePath)) {
          continue;
        }

        try {
          buffer = fs.readFileSync(file.absolutePath);
        } catch {
          continue;
        }
      }

      try {
        const uint8 = new Uint8Array(buffer);
        const blob = new Blob([uint8]);

        const originalFileName = file.originalFileName || path.basename(file.absolutePath);
        const uploadBaseName = file.uploadName || originalFileName;
        const fileName = file.action === 'deleted'
          ? `DELETED_${uploadBaseName}`
          : uploadBaseName;

        formData.append('files', blob, fileName);
        filesAdded++;
      } catch {

      }
    }

    if (filesAdded === 0) {
      return {
        status: true,
        message: 'No files to upload'
      };
    }

    const metadata = files.map((file) => ({
      filePath: file.filePath,
      action: file.action,
      fileName: file.uploadName || path.basename(file.absolutePath),
      originalFileName: file.originalFileName || path.basename(file.absolutePath),
      artifactGroup: file.artifactGroup || '',
      taskPath: file.taskPath || '',
      sourceFolder: file.sourceFolder || ''
    }));

    formData.append('metadata', JSON.stringify(metadata));

    const projectName = String(
      files.find((file) => !!file.projectName)?.projectName || ''
    ).trim().toLowerCase();

    if (projectName) {
      formData.append('project_name', projectName);
    }

    const headers = this.buildAuthHeaders();

    try {
      const result = await this.executeOnHealthyBaseUrls(
        'File upload failed on all base URLs',
        async (baseUrl) => {
          const response = await this.fetchWithTimeout(baseUrl + pathName, {
            method: 'POST',
            headers,
            body: formData
          }, timeoutMs);

          return this.parseJsonResponse(response, 'File upload failed');
        }
      );

      this.telemetry?.recordUpload(true);
      return result;
    } catch (error) {
      this.telemetry?.recordUpload(false);
      throw error;
    }
  }

  async getPredictPendingScope(data: {
    project_name: string;
    client_id: string;
    actor_id?: string;
  }): Promise<any> {
    const params = new URLSearchParams();

    params.set('project_name', (data.project_name || '').trim().toLowerCase());
    params.set('client_id', data.client_id || 'global');
    params.set('actor_id', data.actor_id || 'global');

    return this.get(`predict/pending-scope?${params.toString()}`, 45000);
  }

  async postPredictResult(data: any): Promise<any> {
    return this.post('predict/result', data, 45000);
  }

  async getPredictionFilesBulkData(data: {
    project_name: string;
    actor_id?: string;
    selected_files?: string[];
  }): Promise<any> {
    return this.post('build-prediction/extension-files', {
      project_name: (data.project_name || '').trim().toLowerCase(),
      actor_id: data.actor_id || 'global',
      ...(Array.isArray(data.selected_files) ? { selected_files: data.selected_files } : {})
    }, ApiService.PREDICT_FILES_BULK_TIMEOUT);
  }

  async getPredictionFileData(data: {
    project_name: string;
    actor_id?: string;
    file_paths: string[];
  }): Promise<any> {
    return this.post('build-prediction/file-data', {
      project_name: (data.project_name || '').trim().toLowerCase(),
      actor_id: data.actor_id || 'global',
      ...(Array.isArray(data.file_paths) ? { file_paths: data.file_paths } : {})
    }, ApiService.PREDICT_SCOPE_TIMEOUT);
  }

  // Admin-set prediction tunables (context window, cosine/dice weights, risk thresholds).
  // Returns the dashboard envelope { success, data: { contextWindow, cosineWeight, ... } }.
  async getBuildPredictionConfig(): Promise<any> {
    return this.get('build-prediction/config');
  }

  // Admin-set artifact collection rules (dashboard "Artifact Configuration" page): scan folders +
  // include/exclude patterns. Returns the envelope { success, data: { folders: [...] } }.
  async getArtifactConfigurations(): Promise<any> {
    return this.get('api/artifact-configurations');
  }

  async getArtifactRules(): Promise<any> {
    return this.get('api/artifact-rules');
  }

  // Admin System Tracking Configuration (dashboard): the file-change-tracking inclusion list.
  // Returns the envelope { success, data: { tracking_patterns: [...] } }.
  async getSystemTrackingPatterns(): Promise<any> {
    return this.get('api/system-tracking/patterns');
  }


  async getPredictReportScope(data: {
    project_name: string;
    actor_id?: string;
    selected_files?: string[];
  }): Promise<any> {
    Logger.log('[ApiService] getPredictReportScope start', {
      projectName: data.project_name,
      actorId: data.actor_id,
      selectedFilesCount: data.selected_files?.length,
    });
    return this.post('predict/report-scope', {
      project_name: (data.project_name || '').trim().toLowerCase(),
      actor_id: data.actor_id || 'global',
      ...(Array.isArray(data.selected_files) ? { selected_files: data.selected_files } : {})
    }, ApiService.PREDICT_SCOPE_TIMEOUT);
  }

  async postPredictReport(data: any): Promise<any> {
    return this.post('predict/report', data, ApiService.PREDICT_REPORT_TIMEOUT);
  }

  async getSolutionByRequest(requestId: string): Promise<any> {
    return this.get(`get-solution-by-request/${encodeURIComponent(requestId)}`, 45000);
  }

  async getErrorsByRequest(requestId: string): Promise<any> {
    return this.get(`get-errors-by-request/${encodeURIComponent(requestId)}`, 45000);
  }

  buildDiffViewRequestUrl(requestId: string): string {
    const baseUrl = this.getHealthyBaseUrls()[0] || this.baseUrls[0] || '';
    return `${baseUrl}diff_view/request/${encodeURIComponent(requestId)}`;
  }

  async postPredictEmbedTexts(data: {
    texts: string[];
    request_id?: string;
  }): Promise<any> {
    return this.post('predict/embed-texts', data, ApiService.PREDICT_EMBED_TIMEOUT);
  }


}
