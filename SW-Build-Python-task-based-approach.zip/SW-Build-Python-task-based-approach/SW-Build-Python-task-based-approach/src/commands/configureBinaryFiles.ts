import * as vscode from 'vscode';
import { Logger } from '../utils/Logger';
import { FileUtils } from '../utils/FileUtils';
import { FileHandlingConfig } from '../utils/FileHandlingConfig';
import { BinaryConfigWebviewMessage } from '../webviews/binary-config/BinaryFileConfigTypes';
import {
  getBinaryConfigLoadingHtml,
  getBinaryConfigWebviewHtml
} from '../webviews/binary-config/BinaryFileConfigTemplate';

export async function configureBinaryFiles(context: vscode.ExtensionContext): Promise<void> {
  const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;

  if (!workspaceRoot) {
    vscode.window.showErrorMessage('No workspace folder open');
    return;
  }

  const panel = createFileHandlingConfigPanel();

  panel.webview.html = getBinaryConfigLoadingHtml();

  startProgressiveWorkspaceScan(workspaceRoot, panel);
  registerFileHandlingMessageHandlers(context, workspaceRoot, panel);
}

function createFileHandlingConfigPanel(): vscode.WebviewPanel {
  return vscode.window.createWebviewPanel(
    'fileHandlingConfig',
    'Configure File Handling',
    vscode.ViewColumn.One,
    {
      enableScripts: true,
      retainContextWhenHidden: true
    }
  );
}

function startProgressiveWorkspaceScan(
  workspaceRoot: string,
  panel: vscode.WebviewPanel
): void {
  let isFirstBatch = true;

  FileUtils.scanWorkspaceExtensionsProgressive(workspaceRoot, (result, isComplete) => {
    const extensionData = FileHandlingConfig.convertExtensionsToData(result.extensionCounts, result.binaryExtensions);

    if (isFirstBatch) {
      panel.webview.html = getBinaryConfigWebviewHtml(extensionData, isComplete);
      isFirstBatch = false;
      return;
    }

    panel.webview.postMessage({
      command: 'updateData',
      data: extensionData,
      isComplete
    });
  });
}

function registerFileHandlingMessageHandlers(
  context: vscode.ExtensionContext,
  workspaceRoot: string,
  panel: vscode.WebviewPanel
): void {
  panel.webview.onDidReceiveMessage(
    async (message: BinaryConfigWebviewMessage) => {
      try {
        switch (message.command) {
          case 'save':
            await handleSaveFileHandlingConfig(
              message.binaryExtensions,
              message.artifactExtensions,
              panel
            );
            break;

          case 'reset':
            await handleResetFileHandlingConfig(
              message.tab,
              workspaceRoot,
              panel
            );
            break;
        }
      } catch (error: any) {
        Logger.log(`[FileHandlingConfig] Failed to handle webview message: ${error?.message || String(error)}`);
        vscode.window.showErrorMessage(`File handling configuration failed: ${error?.message || String(error)}`);
      }
    },
    undefined,
    context.subscriptions
  );
}

async function handleSaveFileHandlingConfig(
  binaryExtensions: string[],
  artifactExtensions: string[],
  panel: vscode.WebviewPanel
): Promise<void> {
  const normalizedBinaryExtensions = FileHandlingConfig.normalizeExtensions(binaryExtensions);
  const normalizedArtifactExtensions = FileHandlingConfig.normalizeExtensions(artifactExtensions);

  const previousBinaryExtensions = FileHandlingConfig.getEffectiveBinaryExtensions();
  const previousArtifactExtensions = FileHandlingConfig.getEffectiveArtifactExtensions();

  const binaryAdded = normalizedBinaryExtensions.filter((ext) => !previousBinaryExtensions.has(ext));
  const binaryRemoved = Array.from(previousBinaryExtensions).filter((ext) => !normalizedBinaryExtensions.includes(ext));

  const artifactAdded = normalizedArtifactExtensions.filter((ext) => !previousArtifactExtensions.has(ext));
  const artifactRemoved = Array.from(previousArtifactExtensions).filter((ext) => !normalizedArtifactExtensions.includes(ext));

  FileHandlingConfig.saveUserBinaryExtensions(normalizedBinaryExtensions);
  FileHandlingConfig.saveUserArtifactExtensions(normalizedArtifactExtensions);

  logExtensionChanges('Binary', binaryAdded, binaryRemoved, normalizedBinaryExtensions.length);
  logExtensionChanges('Artifact', artifactAdded, artifactRemoved, normalizedArtifactExtensions.length);

  vscode.window.showInformationMessage('File handling configuration saved successfully');

  panel.webview.postMessage({
    command: 'resetInitialState'
  });
}

async function handleResetFileHandlingConfig(
  tab: 'binary' | 'artifact',
  workspaceRoot: string,
  panel: vscode.WebviewPanel
): Promise<void> {
  if (tab === 'binary') {
    const currentExtensions = FileHandlingConfig.getEffectiveBinaryExtensions();

    FileHandlingConfig.resetBinaryExtensionsToDefaults();

    Logger.log(`[FileHandlingConfig] Reset binary extensions to defaults (${currentExtensions.size} active extension(s) replaced by defaults)`);
    vscode.window.showInformationMessage('Binary file extensions reset to defaults');
  } else {
    const currentExtensions = FileHandlingConfig.getEffectiveArtifactExtensions();

    FileHandlingConfig.resetArtifactExtensionsToDefaults();

    Logger.log(`[FileHandlingConfig] Reset artifact extensions to defaults (${currentExtensions.size} active extension(s) replaced by defaults)`);
    vscode.window.showInformationMessage('Artifact file extensions reset to defaults');
  }

  const result = await FileUtils.scanWorkspaceExtensions(workspaceRoot);
  const updatedData = FileHandlingConfig.convertExtensionsToData(result.extensionCounts, result.binaryExtensions);

  panel.webview.postMessage({
    command: 'updateData',
    data: updatedData,
    isComplete: true,
    replaceSelections: true
  });

  panel.webview.postMessage({
    command: 'resetInitialState'
  });
}

function logExtensionChanges(
  label: string,
  added: string[],
  removed: string[],
  totalCount: number
): void {
  if (added.length === 0 && removed.length === 0) {
    return;
  }

  Logger.log(`[FileHandlingConfig] ${label} file extensions updated:`);

  if (added.length > 0) {
    Logger.log(`[FileHandlingConfig]   ✓ Added: ${added.join(', ')}`);
  }

  if (removed.length > 0) {
    Logger.log(`[FileHandlingConfig]   ✗ Removed: ${removed.join(', ')}`);
  }

  Logger.log(`[FileHandlingConfig]   Total selected ${label.toLowerCase()} extensions: ${totalCount}`);
}