import * as vscode from 'vscode';
import { Logger } from '../utils/Logger';
import { FileWatcher } from '../watchers/FileWatcher';
import { registerRecommendationCommand } from '../webviews/RecommendationCommand';
import { registerPredictionReportCommand } from '../webviews/PredictionReportCommand';
import { getCacheStatus, clearCacheDirs, formatBytes } from '../utils/CacheManager';
import { registerIdentitySignalsCommand } from './IdentitySignalsCommand';

export function registerCommands(
    context: vscode.ExtensionContext,
    getFileWatcher: () => FileWatcher | undefined
): void {
    registerPredictionReportCommand(context, getFileWatcher);
    registerRecommendationCommand(context, getFileWatcher);
    registerConfigureBinaryFilesCommand(context);
    registerOpenLogsCommand(context);
    registerCacheCommands(context);
    registerIdentitySignalsCommand(context);
}

function registerCacheCommands(context: vscode.ExtensionContext): void {
    const storagePath = context.globalStorageUri.fsPath;

    const statusCmd = vscode.commands.registerCommand(
        'gradleErrorAssistant.cacheStatus',
        async () => {
            try {
                const entries = getCacheStatus(storagePath);
                const total = entries.reduce((sum, e) => sum + e.bytes, 0);
                Logger.log('[Cache] Status', {
                    storagePath,
                    totalBytes: total,
                    entries: entries.map((e) => ({ name: e.name, bytes: e.bytes })),
                });
                const top = entries.slice(0, 3).map((e) => `${e.name} ${formatBytes(e.bytes)}`).join(', ');
                const pick = await vscode.window.showInformationMessage(
                    `AI Assisted local cache: ${formatBytes(total)}${top ? ` (top: ${top})` : ''}. Full breakdown in logs.`,
                    'Clear Cache', 'Open Logs'
                );
                if (pick === 'Clear Cache') {
                    await vscode.commands.executeCommand('gradleErrorAssistant.clearCache');
                } else if (pick === 'Open Logs') {
                    await vscode.commands.executeCommand('gradleErrorAssistant.openLogs');
                }
            } catch (err: any) {
                Logger.log('[Cache] status failed', err);
                vscode.window.showErrorMessage(`Failed to read cache status: ${err?.message || String(err)}`);
            }
        }
    );

    const clearCmd = vscode.commands.registerCommand(
        'gradleErrorAssistant.clearCache',
        async () => {
            const confirm = await vscode.window.showWarningMessage(
                'Clear AI Assisted local cache? This removes tracking snapshots and disk cache on this machine. '
                + 'Any in-flight (not-yet-uploaded) build tracking will be reset. Diagnostic logs are kept.',
                { modal: true },
                'Clear Cache'
            );
            if (confirm !== 'Clear Cache') { return; }
            try {
                const results = clearCacheDirs(storagePath);
                const reclaimed = results.reduce((sum, r) => sum + (r.cleared ? r.bytes : 0), 0);
                Logger.log('[Cache] Cleared', { results });
                vscode.window.showInformationMessage(`AI Assisted cache cleared — reclaimed ${formatBytes(reclaimed)}.`);
            } catch (err: any) {
                Logger.log('[Cache] clear failed', err);
                vscode.window.showErrorMessage(`Failed to clear cache: ${err?.message || String(err)}`);
            }
        }
    );

    context.subscriptions.push(statusCmd, clearCmd);
}

function registerOpenLogsCommand(context: vscode.ExtensionContext): void {
    const openLogsCmd = vscode.commands.registerCommand(
        'gradleErrorAssistant.openLogs',
        async () => {
            try {
                const file = Logger.getMostRecentLogFile();
                if (!file) {
                    const dir = Logger.getLogDir();
                    vscode.window.showInformationMessage(
                        dir
                            ? `AI Assisted Build: no log file yet — logs will appear in ${dir} once the extension records activity.`
                            : 'AI Assisted Build: disk logging is not initialized yet. Showing the live output instead.'
                    );
                    Logger.show(); // fall back to the live output channel
                    return;
                }
                const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(file));
                const editor = await vscode.window.showTextDocument(doc, { preview: false });

                // Jump to the MOST RECENT failure/upload event so the client lands directly on
                // the current failure's data. Prefer the PRE-UPLOAD snapshot (shows emptyError +
                // counts) and reveal it at the top so the request + upload result below stay visible.
                const lines = doc.getText().split('\n');
                const findLast = (needle: string): number => {
                    for (let i = lines.length - 1; i >= 0; i--) {
                        if (lines[i].includes(needle)) { return i; }
                    }
                    return -1;
                };
                let targetLine = findLast('PRE-UPLOAD snapshot');
                if (targetLine < 0) {
                    for (const m of ['EMPTY-ERROR', 'Archive upload failed', 'Upload complete']) {
                        targetLine = findLast(m);
                        if (targetLine >= 0) { break; }
                    }
                }
                if (targetLine < 0) { targetLine = Math.max(0, lines.length - 1); }
                const pos = new vscode.Position(targetLine, 0);
                editor.selection = new vscode.Selection(pos, pos);
                editor.revealRange(new vscode.Range(pos, pos), vscode.TextEditorRevealType.AtTop);
            } catch (err: any) {
                Logger.log('[OpenLogs] Failed to open log file', err);
                vscode.window.showErrorMessage(`Failed to open AI Assisted logs: ${err?.message || String(err)}`);
                Logger.show();
            }
        }
    );

    context.subscriptions.push(openLogsCmd);
}

function registerConfigureBinaryFilesCommand(context: vscode.ExtensionContext): void {
    const configureBinaryFilesCmd = vscode.commands.registerCommand(
        'gradleErrorAssistant.configureBinaryFiles',
        async () => {
            try {
                const { configureBinaryFiles } = await import('./configureBinaryFiles');
                await configureBinaryFiles(context);
            } catch (err: any) {
                Logger.log('[BinaryConfigUI] Failed to open binary file configuration', err);
                vscode.window.showErrorMessage(`Failed to configure binary files: ${err?.message || String(err)}`);
            }
        }
    );

    context.subscriptions.push(configureBinaryFilesCmd);
}
