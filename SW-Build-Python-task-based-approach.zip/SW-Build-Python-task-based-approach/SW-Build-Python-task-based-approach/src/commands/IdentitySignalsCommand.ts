import * as os from 'os';
import * as vscode from 'vscode';
import { Logger } from '../utils/Logger';

/**
 * DISCOVERY ONLY - what identity could this machine offer, if one were ever requested?
 *
 * Background. A User Management tab is planned to show who uses the extension and how
 * much, with the real id stored only as our own surrogate. Before designing that, one fact had to
 * be checked and it changed the premise: the extension currently sends NO identity at all -
 * FileWatcher declares `private readonly developerId = 'unknown'` and never assigns it, so every
 * upload from every developer is 'unknown'. There is no data being withheld; none is collected.
 *
 * So this command answers the prior question - what IS available on a real Schaeffler machine -
 * without collecting anything. It reads local signals, MASKS them, prints them to the output
 * channel, and stops. Nothing is sent to the backend, nothing is written to disk beyond the
 * normal log, and no value is stored. A developer runs it, reads it, and can paste the result.
 *
 * Masking is deliberate: this output will be pasted into chats and tickets, so it must be safe to
 * share. It shows the SHAPE of each signal (present/absent, length, a short prefix) rather than
 * the value, which is what a design decision needs. Full values would make the diagnostic itself
 * a leak.
 */

interface Signal {
    name: string;
    value: string;
    note: string;
}

/** sg586096 -> "sg58***" (8 chars). Never the whole value. */
function mask(value: string): string {
    const v = String(value || '').trim();
    if (!v) { return '(empty)'; }
    const head = v.length > 4 ? v.slice(0, 4) : v.slice(0, 1);
    return `${head}*** (${v.length} chars)`;
}

function safe(fn: () => string | undefined | null): string {
    try {
        return String(fn() || '').trim();
    } catch {
        return '';
    }
}

function collect(): Signal[] {
    const signals: Signal[] = [];

    signals.push({
        name: 'os.userInfo().username',
        value: safe(() => os.userInfo().username),
        note: 'usually the Schaeffler short id on a corporate machine - the most likely candidate',
    });
    signals.push({
        name: 'process.env.USERNAME',
        value: safe(() => process.env.USERNAME),
        note: 'Windows login name; normally identical to the above',
    });
    signals.push({
        name: 'process.env.USERDOMAIN',
        value: safe(() => process.env.USERDOMAIN),
        note: 'domain - tells us whether the machine is domain-joined at all',
    });
    signals.push({
        name: 'process.env.USERDNSDOMAIN',
        value: safe(() => process.env.USERDNSDOMAIN),
        note: 'fully-qualified domain, if present',
    });
    signals.push({
        name: 'os.hostname()',
        value: safe(() => os.hostname()),
        note: 'machine name - often encodes an asset tag, so treat as identifying',
    });
    signals.push({
        name: 'vscode.env.machineId',
        value: safe(() => vscode.env.machineId),
        note: 'VS Code\'s OWN anonymous install id - stable per machine, not derived from a person',
    });
    signals.push({
        name: 'vscode.env.sessionId',
        value: safe(() => vscode.env.sessionId),
        note: 'changes every window - useless for counting people, listed to rule it out',
    });
    signals.push({
        name: 'vscode.env.remoteName',
        value: safe(() => vscode.env.remoteName || '(local)'),
        note: 'set when the workspace is remote/WSL - the username above may then be the REMOTE user',
    });

    return signals;
}

export function registerIdentitySignalsCommand(context: vscode.ExtensionContext): void {
    const cmd = vscode.commands.registerCommand(
        'gradleErrorAssistant.identitySignals',
        async () => {
            const signals = collect();
            const lines: string[] = [];
            lines.push('='.repeat(72));
            lines.push('IDENTITY SIGNALS AVAILABLE ON THIS MACHINE (diagnostic - nothing is sent)');
            lines.push('='.repeat(72));
            lines.push('This reads local values, masks them, prints them here, and stops. No value');
            lines.push('is transmitted to the backend or stored. Safe to copy into a ticket.');
            lines.push('');
            lines.push('The extension currently sends developer_id = "unknown" on every upload, so');
            lines.push('nothing below is being collected today. This is to decide what COULD be.');
            lines.push('');

            for (const s of signals) {
                const present = s.value ? 'PRESENT' : 'absent ';
                lines.push(`  [${present}] ${s.name}`);
                lines.push(`             ${s.value ? mask(s.value) : '-'}`);
                lines.push(`             ${s.note}`);
                lines.push('');
            }

            const username = signals.find(s => s.name === 'os.userInfo().username')?.value || '';
            const machineId = signals.find(s => s.name === 'vscode.env.machineId')?.value || '';
            lines.push('-'.repeat(72));
            lines.push('READ:');
            if (username) {
                lines.push('  A per-person id IS available. It can be hashed before it leaves the');
                lines.push('  machine, so the raw value never travels - but it still identifies an');
                lines.push('  employee, so per-user usage reporting needs the works-council answer.');
            } else {
                lines.push('  No per-person id is readable here. Only an anonymous per-machine id is');
                lines.push('  available, which counts installs rather than people.');
            }
            if (machineId) {
                lines.push('  vscode.env.machineId is present: an anonymous per-install count needs');
                lines.push('  no new identifier at all and carries no personal data.');
            }
            lines.push('='.repeat(72));

            const text = lines.join('\n');
            Logger.log(text);
            Logger.show();

            const doc = await vscode.workspace.openTextDocument({
                content: text,
                language: 'plaintext',
            });
            await vscode.window.showTextDocument(doc, { preview: false });
        }
    );
    context.subscriptions.push(cmd);
}
