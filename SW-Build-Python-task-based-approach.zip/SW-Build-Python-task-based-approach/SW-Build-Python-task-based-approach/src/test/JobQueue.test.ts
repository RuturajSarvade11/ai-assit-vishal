import * as assert from 'assert';
import { JobQueue } from '../watchers/FileQueue';

suite('JobQueue Test Suite', () => {
  test('Should execute single task', async () => {
    const queue = new JobQueue();
    let executed = false;

    await queue.enqueue('file1.txt', async () => {
      executed = true;
    });

    assert.strictEqual(executed, true);
  });

  test('Should execute tasks sequentially for same file', async () => {
    const queue = new JobQueue();
    const results: number[] = [];

    const task1 = queue.enqueue('file1.txt', async () => {
      await new Promise(resolve => setTimeout(resolve, 50));
      results.push(1);
    });

    const task2 = queue.enqueue('file1.txt', async () => {
      results.push(2);
    });

    await Promise.all([task1, task2]);

    assert.deepStrictEqual(results, [1, 2]);
  });

  test('Should execute tasks in parallel for different files', async () => {
    const queue = new JobQueue();
    const results: string[] = [];

    const task1 = queue.enqueue('file1.txt', async () => {
      await new Promise(resolve => setTimeout(resolve, 50));
      results.push('file1');
    });

    const task2 = queue.enqueue('file2.txt', async () => {
      results.push('file2');
    });

    await Promise.all([task1, task2]);

    // file2 should complete before file1 (no delay)
    assert.strictEqual(results[0], 'file2');
    assert.strictEqual(results[1], 'file1');
  });

  test('Should handle task errors gracefully', async () => {
    const queue = new JobQueue();
    let nextTaskExecuted = false;

    await queue.enqueue('file1.txt', async () => {
      throw new Error('Task failed');
    });

    await queue.enqueue('file1.txt', async () => {
      nextTaskExecuted = true;
    });

    assert.strictEqual(nextTaskExecuted, true);
  });

  test('Should clean up queue after task completion', async () => {
    const queue = new JobQueue();

    await queue.enqueue('file1.txt', async () => {
      // Task completes
    });

    // Queue should be cleaned up (implementation detail)
    // We can only verify it doesn't throw
    await queue.enqueue('file1.txt', async () => {
      // Should start fresh
    });

    assert.ok(true);
  });

  test('Should handle multiple sequential tasks', async () => {
    const queue = new JobQueue();
    const results: number[] = [];

    await queue.enqueue('file1.txt', async () => { results.push(1); });
    await queue.enqueue('file1.txt', async () => { results.push(2); });
    await queue.enqueue('file1.txt', async () => { results.push(3); });

    assert.deepStrictEqual(results, [1, 2, 3]);
  });

  test('Should handle concurrent enqueues for same file', async () => {
    const queue = new JobQueue();
    const results: number[] = [];

    // Enqueue multiple tasks without awaiting
    const task1 = queue.enqueue('file1.txt', async () => {
      await new Promise(resolve => setTimeout(resolve, 30));
      results.push(1);
    });

    const task2 = queue.enqueue('file1.txt', async () => {
      await new Promise(resolve => setTimeout(resolve, 20));
      results.push(2);
    });

    const task3 = queue.enqueue('file1.txt', async () => {
      await new Promise(resolve => setTimeout(resolve, 10));
      results.push(3);
    });

    await Promise.all([task1, task2, task3]);

    // Should execute in order despite different delays
    assert.deepStrictEqual(results, [1, 2, 3]);
  });

  test('Should handle empty task', async () => {
    const queue = new JobQueue();

    await queue.enqueue('file1.txt', async () => {
      // Empty task
    });

    assert.ok(true);
  });

  test('Should handle task that returns value', async () => {
    const queue = new JobQueue();

    await queue.enqueue('file1.txt', async () => {
      const value = 'some value';
      // Tasks must return void
    });

    assert.ok(true);
  });

  test('Should isolate errors between different files', async () => {
    const queue = new JobQueue();
    let file2Executed = false;

    const task1 = queue.enqueue('file1.txt', async () => {
      throw new Error('File 1 error');
    });

    const task2 = queue.enqueue('file2.txt', async () => {
      file2Executed = true;
    });

    await Promise.all([
      task1.catch(() => {}), // Ignore error
      task2
    ]);

    assert.strictEqual(file2Executed, true);
  });

  test('Should handle rapid sequential enqueues', async () => {
    const queue = new JobQueue();
    const results: number[] = [];

    for (let i = 0; i < 10; i++) {
      await queue.enqueue('file1.txt', async () => {
        results.push(i);
      });
    }

    assert.strictEqual(results.length, 10);
    assert.deepStrictEqual(results, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
  });
});
