import * as assert from 'assert';
import { CircuitBreaker, CircuitState, ExponentialBackoff } from '../utils/CircuitBreaker';

suite('CircuitBreaker Test Suite', () => {
  test('Should start in CLOSED state', () => {
    const cb = new CircuitBreaker(3, 1000);
    assert.strictEqual(cb.getState(), CircuitState.CLOSED);
  });

  test('Should open circuit after threshold failures', async () => {
    const cb = new CircuitBreaker(3, 1000);
    
    // Simulate 3 failures
    for (let i = 0; i < 3; i++) {
      try {
        await cb.execute(async () => {
          throw new Error('Test failure');
        });
      } catch (err) {
        // Expected
      }
    }

    assert.strictEqual(cb.getState(), CircuitState.OPEN);
  });

  test('Should fail fast when circuit is OPEN', async () => {
    const cb = new CircuitBreaker(2, 1000);
    
    // Cause circuit to open
    for (let i = 0; i < 2; i++) {
      try {
        await cb.execute(async () => {
          throw new Error('Test failure');
        });
      } catch (err) {
        // Expected
      }
    }

    // Should fail fast
    try {
      await cb.execute(async () => {
        return 'success';
      });
      assert.fail('Should have thrown error');
    } catch (err: any) {
      assert.ok(err.message.includes('Circuit breaker is OPEN'));
    }
  });

  test('Should transition to HALF_OPEN after timeout', async () => {
    const cb = new CircuitBreaker(2, 100); // Short timeout for testing
    
    // Cause circuit to open
    for (let i = 0; i < 2; i++) {
      try {
        await cb.execute(async () => {
          throw new Error('Test failure');
        });
      } catch (err) {
        // Expected
      }
    }

    assert.strictEqual(cb.getState(), CircuitState.OPEN);

    // Wait for timeout
    await new Promise(resolve => setTimeout(resolve, 150));

    // Next call should transition to HALF_OPEN
    try {
      await cb.execute(async () => {
        throw new Error('Still failing');
      });
    } catch (err) {
      // Expected
    }

    assert.strictEqual(cb.getState(), CircuitState.OPEN); // Back to OPEN due to failure
  });

  test('Should close circuit after successful calls in HALF_OPEN', async () => {
    const cb = new CircuitBreaker(2, 100, 2); // 2 successes needed
    
    // Open circuit
    for (let i = 0; i < 2; i++) {
      try {
        await cb.execute(async () => {
          throw new Error('Test failure');
        });
      } catch (err) {
        // Expected
      }
    }

    // Wait for timeout
    await new Promise(resolve => setTimeout(resolve, 150));

    // Two successful calls should close circuit
    await cb.execute(async () => 'success1');
    await cb.execute(async () => 'success2');

    assert.strictEqual(cb.getState(), CircuitState.CLOSED);
  });

  test('Should not open circuit for repeated HTTP 500 application errors', async () => {
    const cb = new CircuitBreaker(2, 1000);

    for (let i = 0; i < 3; i++) {
      try {
        await cb.execute(async () => {
          throw new Error(JSON.stringify({ status: 500, message: 'Internal error' }));
        });
      } catch {
        // Expected
      }
    }

    assert.strictEqual(cb.getState(), CircuitState.CLOSED);
  });

  test('Should close circuit from HALF_OPEN when server responds with non-circuit HTTP error', async () => {
    const cb = new CircuitBreaker(2, 100);

    for (let i = 0; i < 2; i++) {
      try {
        await cb.execute(async () => {
          throw new Error('Network down');
        });
      } catch {
        // Expected
      }
    }

    assert.strictEqual(cb.getState(), CircuitState.OPEN);

    await new Promise(resolve => setTimeout(resolve, 150));

    try {
      await cb.execute(async () => {
        throw new Error(JSON.stringify({ status: 500, message: 'Endpoint failed but server is reachable' }));
      });
    } catch {
      // Expected
    }

    assert.strictEqual(cb.getState(), CircuitState.CLOSED);
  });

  test('Should reset circuit breaker', () => {
    const cb = new CircuitBreaker(2, 1000);
    
    // Cause some failures
    try {
      cb.execute(async () => {
        throw new Error('Test failure');
      });
    } catch (err) {
      // Expected
    }

    cb.reset();
    assert.strictEqual(cb.getState(), CircuitState.CLOSED);
  });
});

suite('ExponentialBackoff Test Suite', () => {
  test('Should increase delay exponentially', async () => {
    const start1 = Date.now();
    await ExponentialBackoff.delay(1, 100, 10000);
    const delay1 = Date.now() - start1;

    const start2 = Date.now();
    await ExponentialBackoff.delay(2, 100, 10000);
    const delay2 = Date.now() - start2;

    // Second delay should be roughly double (accounting for jitter)
    assert.ok(delay2 > delay1);
    assert.ok(delay2 >= 150); // At least 2^(2-1) * 100 = 200ms (minus jitter tolerance)
  });

  test('Should respect maximum delay', async () => {
    const start = Date.now();
    await ExponentialBackoff.delay(10, 100, 500); // Large attempt, but max 500ms
    const delay = Date.now() - start;

    // Should be capped at ~500ms + jitter
    assert.ok(delay < 800); // Allow some margin for jitter
  });
});
