import * as assert from 'assert';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { FileUtils } from '../utils/FileUtils';
import { FileHandlingConfig } from '../utils/FileHandlingConfig';

suite('FileUtils Path Test Suite', () => {
  test('Should normalize backslashes to forward slashes', () => {
    const input = 'C:\\Users\\test\\file.txt';
    const result = FileUtils.normalizePath(input);
    assert.strictEqual(result, 'C:/Users/test/file.txt');
  });

  test('Should handle already normalized paths', () => {
    const input = '/home/user/file.txt';
    const result = FileUtils.normalizePath(input);
    assert.strictEqual(result, '/home/user/file.txt');
  });

  test('Should remove leading slash from Windows paths', () => {
    const input = '/C:/Users/test/file.txt';
    const result = FileUtils.normalizePath(input);
    assert.strictEqual(result, 'C:/Users/test/file.txt');
  });

  test('Should check if file is inside workspace', () => {
    const workspace = 'C:/projects/myapp';
    const file1 = 'C:/projects/myapp/src/index.ts';
    const file2 = 'C:/other/file.ts';

    assert.strictEqual(FileUtils.isFileInsideWorkspace(file1, workspace), true);
    assert.strictEqual(FileUtils.isFileInsideWorkspace(file2, workspace), false);
  });
});

suite('FileUtils Content Test Suite', () => {
  test('Should slice text by line range', () => {
    const text = 'Line 0\nLine 1\nLine 2\nLine 3\nLine 4';
    const result = FileUtils.slice(text, 1, 3);
    assert.strictEqual(result, 'Line 1\nLine 2\nLine 3');
  });

  test('Should detect practically same text', () => {
    const text1 = 'const x = 1;';
    const text2 = 'const  x  =  1 ;';
    assert.strictEqual(FileUtils.isPracticallySame(text1, text2), true);
  });

  test('Should detect different text', () => {
    const text1 = 'const x = 1;';
    const text2 = 'const y = 2;';
    assert.strictEqual(FileUtils.isPracticallySame(text1, text2), false);
  });

  test('Should strip timestamps from messages', () => {
    const message = 'Error at Jan 15, 2026 10:30:45 AM in file.txt';
    const result = FileUtils.stripTimestamp(message);
    assert.ok(!result.includes('Jan'));
    assert.ok(!result.includes('10:30:45'));
  });

  test('Should preserve non-timestamp content', () => {
    const message = 'Error: undefined variable';
    const result = FileUtils.stripTimestamp(message);
    assert.strictEqual(result, message);
  });
});

suite('FileUtils File Type Test Suite', () => {
  const tempDir = path.join(os.tmpdir(), 'gradle-error-assistant-filetype-test');
  const binaryFile = path.join(tempDir, 'test-file.bin');
  const textFile = path.join(tempDir, 'test-file.txt');

  setup(() => {
    fs.mkdirSync(tempDir, { recursive: true });
    fs.writeFileSync(binaryFile, Buffer.from([0x00, 0x01, 0x02, 0x03]));
    fs.writeFileSync(textFile, 'console.log("hello world");\n', 'utf8');
  });

  teardown(() => {
    fs.rmSync(tempDir, { recursive: true, force: true });
  });

  test('Should identify binary files', () => {
    assert.strictEqual(FileHandlingConfig.isBinaryFile(binaryFile), true);
  });

  test('Should identify non-binary files', () => {
    assert.strictEqual(FileHandlingConfig.isBinaryFile(textFile), false);
  });

  test('Should ignore common directories', () => {
    assert.strictEqual(FileUtils.shouldIgnore('/project/node_modules/package'), true);
    assert.strictEqual(FileUtils.shouldIgnore('/project/.git/config'), true);
    assert.strictEqual(FileUtils.shouldIgnore('/project/.gradle/cache'), true);
    assert.strictEqual(FileUtils.shouldIgnore('/project/build/output'), true);
  });

  test('Should ignore generated tmp process dirs (GBE/TD5) but not tmp-like names', () => {
    assert.strictEqual(FileUtils.shouldIgnore('d:/casdev/gbe/4p231/001/4P231_000u0_001/tmp/system/TD4_build_ArPrePro_output.xml'), true);
    assert.strictEqual(FileUtils.shouldIgnore('d:/casdev/gbe/4p231/001/4P231_000u0_001/tmp/PDA/BSWIF_3L/in/Conti_ASW/IOABQM.upda'), true);
    assert.strictEqual(FileUtils.shouldIgnore('D:\\casdev\\gbe\\proj\\tmp\\PDA\\pl2com_cbk.c'), true);
    assert.strictEqual(FileUtils.shouldIgnore('/project/work/config/gbe/aramis.process.gradle.kts'), false);
    assert.strictEqual(FileUtils.shouldIgnore('/project/src/tmpparser.c'), false);
  });

  test('Should ignore lock and log files', () => {
    assert.strictEqual(FileUtils.shouldIgnore('package-lock.json'), true);
    assert.strictEqual(FileUtils.shouldIgnore('error.log'), true);
    assert.strictEqual(FileUtils.shouldIgnore('temp.tmp'), true);
  });

  test('Should not ignore source files', () => {
    assert.strictEqual(FileUtils.shouldIgnore('/project/src/index.ts'), false);
    assert.strictEqual(FileUtils.shouldIgnore('/project/test.js'), false);
  });
});

suite('FileUtils Advanced Path Resolution Test Suite', () => {
  test('Should handle relative paths', () => {
    const input = '../test/file.txt';
    const result = FileUtils.normalizePath(input);
    assert.ok(result.includes('test/file.txt'));
  });

  test('Should handle mixed separators', () => {
    const input = 'C:\\Users/test\\file.txt';
    const result = FileUtils.normalizePath(input);
    assert.ok(!result.includes('\\'));
    assert.ok(result.includes('/'));
  });

  test('Should handle empty path', () => {
    const result = FileUtils.normalizePath('');
    assert.strictEqual(result, '');
  });

  test('Should handle UNC paths', () => {
    const input = '\\\\server\\share\\file.txt';
    const result = FileUtils.normalizePath(input);
    assert.ok(result.includes('//server/share/file.txt'));
  });
});

suite('FileUtils Edge Cases Test Suite', () => {
  test('Should handle undefined in isPracticallySame', () => {
    const text1 = '';
    const text2 = '';
    assert.strictEqual(FileUtils.isPracticallySame(text1, text2), true);
  });

  test('Should slice with out of bounds indices', () => {
    const text = 'Line 1\nLine 2';
    const result = FileUtils.slice(text, 0, 100);
    assert.ok(result.includes('Line 1'));
    assert.ok(result.includes('Line 2'));
  });

  test('Should format various file sizes', () => {
    assert.strictEqual(FileUtils.formatFileSize(0), '0 B');
    assert.strictEqual(FileUtils.formatFileSize(1023), '1023 B');
    assert.ok(FileUtils.formatFileSize(1024).includes('KB'));
    assert.ok(FileUtils.formatFileSize(1024 * 1024).includes('MB'));
  });

  test('Should strip multiple timestamps', () => {
    const message = 'Start Jan 15, 2026 10:30:45 AM, End Feb 20, 2026 3:15:22 PM';
    const result = FileUtils.stripTimestamp(message);
    assert.ok(!result.includes('Jan'));
    assert.ok(!result.includes('Feb'));
    assert.ok(result.includes('Start'));
    assert.ok(result.includes('End'));
  });
});
