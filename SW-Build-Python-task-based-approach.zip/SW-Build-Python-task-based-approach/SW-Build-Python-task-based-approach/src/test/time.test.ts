import * as assert from 'assert';
import { formatDuration } from '../utils/time';

suite('Time Utilities Test Suite', () => {
  test('Should format seconds only', () => {
    assert.strictEqual(formatDuration(0), '00:00');
    assert.strictEqual(formatDuration(5), '00:05');
    assert.strictEqual(formatDuration(30), '00:30');
    assert.strictEqual(formatDuration(59), '00:59');
  });

  test('Should format minutes and seconds', () => {
    assert.strictEqual(formatDuration(60), '01:00');
    assert.strictEqual(formatDuration(90), '01:30');
    assert.strictEqual(formatDuration(125), '02:05');
    assert.strictEqual(formatDuration(3599), '59:59');
  });

  test('Should format hours, minutes, and seconds', () => {
    assert.strictEqual(formatDuration(3600), '01:00:00');
    assert.strictEqual(formatDuration(3661), '01:01:01');
    assert.strictEqual(formatDuration(7200), '02:00:00');
    assert.strictEqual(formatDuration(7325), '02:02:05');
  });

  test('Should pad single digits with zero', () => {
    assert.strictEqual(formatDuration(5), '00:05');
    assert.strictEqual(formatDuration(65), '01:05');
    assert.strictEqual(formatDuration(3605), '01:00:05');
  });

  test('Should handle large durations', () => {
    assert.strictEqual(formatDuration(36000), '10:00:00');
    assert.strictEqual(formatDuration(86400), '24:00:00'); // 24 hours
    assert.strictEqual(formatDuration(359999), '99:59:59');
  });

  test('Should handle edge case of 1 hour exactly', () => {
    assert.strictEqual(formatDuration(3600), '01:00:00');
  });

  test('Should handle 1 minute exactly', () => {
    assert.strictEqual(formatDuration(60), '01:00');
  });

  test('Should format typical durations', () => {
    // 5 minutes 30 seconds
    assert.strictEqual(formatDuration(330), '05:30');
    
    // 1 hour 15 minutes 45 seconds
    assert.strictEqual(formatDuration(4545), '01:15:45');
    
    // 2 hours 30 minutes
    assert.strictEqual(formatDuration(9000), '02:30:00');
  });

  test('Should handle maximum reasonable duration', () => {
    // 99 hours 59 minutes 59 seconds
    const result = formatDuration(359999);
    assert.ok(result.startsWith('99:59:59'));
  });

  test('Should use correct format based on duration', () => {
    // Less than 1 hour: MM:SS
    const short = formatDuration(500);
    assert.strictEqual(short.split(':').length, 2);
    
    // 1 hour or more: HH:MM:SS
    const long = formatDuration(3600);
    assert.strictEqual(long.split(':').length, 3);
  });
});
