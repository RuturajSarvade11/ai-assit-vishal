import * as assert from 'assert';
import { DiffGenerator } from '../processors/DiffGenerator';

suite('DiffGenerator Test Suite', () => {
  test('Should detect added lines', () => {
    const oldText = 'Line 1\nLine 2\nLine 3';
    const newText = 'Line 1\nLine 2\nLine 3\nLine 4';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.strictEqual(diff.added.length, 1);
    assert.strictEqual(diff.added[0].content, 'Line 4');
    assert.strictEqual(diff.removed.length, 0);
  });

  test('Should detect removed lines', () => {
    const oldText = 'Line 1\nLine 2\nLine 3';
    const newText = 'Line 1\nLine 3';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.strictEqual(diff.removed.length, 1);
    assert.strictEqual(diff.removed[0].content, 'Line 2');
    assert.strictEqual(diff.added.length, 0);
  });

  test('Should detect modified lines as removed + added', () => {
    const oldText = 'Line 1\nLine 2\nLine 3';
    const newText = 'Line 1\nLine 2 Modified\nLine 3';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.strictEqual(diff.removed.length, 1);
    assert.strictEqual(diff.removed[0].content, 'Line 2');
    assert.strictEqual(diff.added.length, 1);
    assert.strictEqual(diff.added[0].content, 'Line 2 Modified');
  });

  test('Should handle empty old text', () => {
    const oldText = '';
    const newText = 'New Line 1\nNew Line 2';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.strictEqual(diff.added.length, 2);
    assert.strictEqual(diff.removed.length, 0);
  });

  test('Should handle empty new text', () => {
    const oldText = 'Line 1\nLine 2';
    const newText = '';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.strictEqual(diff.removed.length, 2);
    assert.strictEqual(diff.added.length, 0);
  });

  test('Should handle no changes', () => {
    const text = 'Line 1\nLine 2\nLine 3';

    const diff = DiffGenerator.getDiffStats(text, text);

    assert.strictEqual(diff.added.length, 0);
    assert.strictEqual(diff.removed.length, 0);
  });

  test('Should track correct line numbers', () => {
    const oldText = 'Line 1\nLine 2\nLine 3';
    const newText = 'Line 1\nNew Line\nLine 2\nLine 3';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.strictEqual(diff.added.length, 1);
    assert.strictEqual(diff.added[0].line, 2); // New line inserted at line 2
    assert.strictEqual(diff.added[0].content, 'New Line');
  });

  test('Should handle Windows line endings', () => {
    const oldText = 'Line 1\r\nLine 2\r\nLine 3';
    const newText = 'Line 1\r\nLine 2 Modified\r\nLine 3';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.ok(diff.removed.length > 0 || diff.added.length > 0);
  });

  test('Should get changed line numbers', () => {
    const oldText = 'Line 1\nLine 2\nLine 3';
    const newText = 'Line 1\nLine 2\nLine 3\nLine 4\nLine 5';

    const changedLines = DiffGenerator.getChangedLineNumbers(oldText, newText);

    assert.strictEqual(changedLines.length, 2);
    assert.ok(changedLines.includes(4));
    assert.ok(changedLines.includes(5));
  });

  test('Should handle multiple insertions and deletions', () => {
    const oldText = 'Line 1\nLine 2\nLine 3\nLine 4';
    const newText = 'Line 1\nNew Line A\nLine 3\nNew Line B';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    // Line 2 removed, Line 4 removed, New Line A added, New Line B added
    assert.ok(diff.removed.length >= 1);
    assert.ok(diff.added.length >= 1);
  });

  test('Should handle complex multiline changes', () => {
    const oldText = 'function foo() {\n  console.log("old");\n}';
    const newText = 'function foo() {\n  console.log("new");\n  return true;\n}';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.ok(diff.removed.length > 0 || diff.added.length > 0);
  });

  test('Should handle special characters', () => {
    const oldText = 'const x = "hello";';
    const newText = 'const x = "hello\\nworld";';

    const diff = DiffGenerator.getDiffStats(oldText, newText);

    assert.ok(diff.removed.length > 0 || diff.added.length > 0);
  });
});
