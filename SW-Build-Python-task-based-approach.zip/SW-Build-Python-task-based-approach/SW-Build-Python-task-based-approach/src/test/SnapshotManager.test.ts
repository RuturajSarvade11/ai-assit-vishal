import * as assert from 'assert';
import * as fs from 'fs';
import * as path from 'path';
import { SnapshotManager } from '../processors/SnapshotManager';

suite('SnapshotManager Test Suite', () => {
  let tempWorkspace: string;
  let tempStorage: string;
  let snapshotManager: SnapshotManager;

  setup(() => {
    // Create temp directories
    tempWorkspace = path.join(__dirname, '..', '..', '..', 'test-workspace');
    tempStorage = path.join(__dirname, '..', '..', '..', 'test-storage');
    
    if (!fs.existsSync(tempWorkspace)) {
      fs.mkdirSync(tempWorkspace, { recursive: true });
    }
    if (!fs.existsSync(tempStorage)) {
      fs.mkdirSync(tempStorage, { recursive: true });
    }

    snapshotManager = new SnapshotManager(tempWorkspace, tempStorage);
  });

  teardown(() => {
    // Clean up
    try {
      if (fs.existsSync(tempWorkspace)) {
        fs.rmSync(tempWorkspace, { recursive: true, force: true });
      }
      if (fs.existsSync(tempStorage)) {
        fs.rmSync(tempStorage, { recursive: true, force: true });
      }
    } catch (err) {
      // Ignore cleanup errors
    }
  });

  test('Should create snapshot of existing file', () => {
    const testFile = path.join(tempWorkspace, 'test.txt');
    const content = 'Test content';
    fs.writeFileSync(testFile, content, 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(testFile);

    assert.ok(fs.existsSync(snapshotPath));
    const snapshotContent = fs.readFileSync(snapshotPath, 'utf8');
    assert.strictEqual(snapshotContent, content);
  });

  test('Should create empty snapshot for non-existent file', () => {
    const testFile = path.join(tempWorkspace, 'nonexistent.txt');

    const snapshotPath = snapshotManager.createSnapshot(testFile);

    assert.ok(fs.existsSync(snapshotPath));
    const snapshotContent = fs.readFileSync(snapshotPath, 'utf8');
    assert.strictEqual(snapshotContent, '');
  });

  test('Should create snapshot in correct directory', () => {
    const testFile = path.join(tempWorkspace, 'test.txt');
    fs.writeFileSync(testFile, 'content', 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(testFile);

    const snapshotDir = path.join(tempStorage, 'snapshots');
    assert.ok(snapshotPath.startsWith(snapshotDir));
  });

  test('Should handle nested file paths', () => {
    const nestedDir = path.join(tempWorkspace, 'src', 'utils');
    fs.mkdirSync(nestedDir, { recursive: true });
    
    const testFile = path.join(nestedDir, 'helper.ts');
    fs.writeFileSync(testFile, 'helper code', 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(testFile);

    assert.ok(fs.existsSync(snapshotPath));
    const content = fs.readFileSync(snapshotPath, 'utf8');
    assert.strictEqual(content, 'helper code');
  });

  test('Should replace path separators in snapshot filename', () => {
    const nestedFile = path.join(tempWorkspace, 'folder', 'file.txt');
    fs.mkdirSync(path.dirname(nestedFile), { recursive: true });
    fs.writeFileSync(nestedFile, 'test', 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(nestedFile);
    const snapshotName = path.basename(snapshotPath);

    // Should use underscores instead of slashes/backslashes
    assert.ok(snapshotName.includes('_'));
    assert.ok(!snapshotName.includes('/'));
    assert.ok(!snapshotName.includes('\\'));
  });

  test('Should overwrite existing snapshot', () => {
    const testFile = path.join(tempWorkspace, 'test.txt');
    fs.writeFileSync(testFile, 'version 1', 'utf8');

    const snapshot1 = snapshotManager.createSnapshot(testFile);
    
    fs.writeFileSync(testFile, 'version 2', 'utf8');
    const snapshot2 = snapshotManager.createSnapshot(testFile);

    assert.strictEqual(snapshot1, snapshot2);
    const content = fs.readFileSync(snapshot2, 'utf8');
    assert.strictEqual(content, 'version 2');
  });

  test('Should handle files with special characters', () => {
    const testFile = path.join(tempWorkspace, 'test file with spaces.txt');
    fs.writeFileSync(testFile, 'special content', 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(testFile);

    assert.ok(fs.existsSync(snapshotPath));
    const content = fs.readFileSync(snapshotPath, 'utf8');
    assert.strictEqual(content, 'special content');
  });

  test('Should handle large files', () => {
    const testFile = path.join(tempWorkspace, 'large.txt');
    const largeContent = 'x'.repeat(10000);
    fs.writeFileSync(testFile, largeContent, 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(testFile);

    assert.ok(fs.existsSync(snapshotPath));
    const content = fs.readFileSync(snapshotPath, 'utf8');
    assert.strictEqual(content.length, largeContent.length);
  });

  test('Should handle multiline content', () => {
    const testFile = path.join(tempWorkspace, 'multiline.txt');
    const content = 'Line 1\nLine 2\nLine 3\n';
    fs.writeFileSync(testFile, content, 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(testFile);

    const snapshotContent = fs.readFileSync(snapshotPath, 'utf8');
    assert.strictEqual(snapshotContent, content);
  });

  test('Should preserve file encoding', () => {
    const testFile = path.join(tempWorkspace, 'unicode.txt');
    const content = 'Hello 世界 🎉';
    fs.writeFileSync(testFile, content, 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(testFile);

    const snapshotContent = fs.readFileSync(snapshotPath, 'utf8');
    assert.strictEqual(snapshotContent, content);
  });
  test('Should clear stored snapshots', () => {
    const testFile = path.join(tempWorkspace, 'test.txt');
    fs.writeFileSync(testFile, 'content', 'utf8');

    const snapshotPath = snapshotManager.createSnapshot(testFile);
    assert.ok(fs.existsSync(snapshotPath));

    snapshotManager.clearSnapshots();

    assert.ok(!fs.existsSync(snapshotPath));
    assert.ok(fs.existsSync(path.join(tempStorage, 'snapshots')));
  });
});
