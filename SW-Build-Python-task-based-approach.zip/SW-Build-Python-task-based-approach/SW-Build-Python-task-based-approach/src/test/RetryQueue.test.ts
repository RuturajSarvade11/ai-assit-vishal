import * as assert from 'assert';
import * as fs from 'fs';
import * as path from 'path';
import { RetryQueue } from '../utils/RetryQueue';

suite('RetryQueue Test Suite', () => {
  let tempDir: string;
  let retryQueue: RetryQueue;

  setup(() => {
    // Create temp directory for testing
    tempDir = path.join(__dirname, '..', '..', '..', 'test-temp');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    retryQueue = new RetryQueue(tempDir);
  });

  teardown(() => {
    // Clean up temp directory
    try {
      if (fs.existsSync(tempDir)) {
        const queueFile = path.join(tempDir, 'retry_queue.json');
        if (fs.existsSync(queueFile)) {
          fs.unlinkSync(queueFile);
        }
        fs.rmdirSync(tempDir, { recursive: true });
      }
    } catch (err) {
      // Ignore cleanup errors
    }
  });

  test('Should enqueue new items', () => {
    retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    
    const items = retryQueue.getRetryableItems();
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].batchId, 'batch-123');
    assert.strictEqual(items[0].type, 'batch');
    assert.strictEqual(items[0].attemptCount, 1);
  });

  test('Should update existing items', () => {
    retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    retryQueue.enqueue('batch-123', { test: 'data' }, 'batch'); // Re-enqueue same batch
    
    const items = retryQueue.getRetryableItems();
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].attemptCount, 2);
  });

  test('Should respect max queue size', () => {
    // Enqueue more than maxQueueSize (50)
    for (let i = 0; i < 55; i++) {
      retryQueue.enqueue(`batch-${i}`, { index: i }, 'batch');
    }
    
    assert.ok(retryQueue.size() <= 50);
  });

  test('Should remove items from queue', () => {
    retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    retryQueue.enqueue('batch-456', { test: 'data' }, 'binary');
    
    assert.strictEqual(retryQueue.size(), 2);
    
    retryQueue.remove('batch-123', 'batch');
    
    assert.strictEqual(retryQueue.size(), 1);
    const items = retryQueue.getRetryableItems();
    assert.strictEqual(items[0].batchId, 'batch-456');
  });

  test('Should filter out items exceeding max retries', () => {
    retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    
    // Simulate multiple failures
    for (let i = 0; i < 3; i++) {
      retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    }
    
    const items = retryQueue.getRetryableItems();
    assert.strictEqual(items.length, 0); // Should be filtered out (>= 3 retries)
  });

  test('Should clear expired items', () => {
    retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    
    // Exceed max retries
    for (let i = 0; i < 3; i++) {
      retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    }
    
    retryQueue.clearExpired();
    
    assert.strictEqual(retryQueue.size(), 0);
  });

  test('Should handle different types (batch vs binary)', () => {
    retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    retryQueue.enqueue('batch-123', { test: 'data' }, 'binary');
    
    assert.strictEqual(retryQueue.size(), 2);
    
    retryQueue.remove('batch-123', 'batch');
    
    const items = retryQueue.getRetryableItems();
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].type, 'binary');
  });

  test('Should persist queue to disk', () => {
    retryQueue.enqueue('batch-123', { test: 'data' }, 'batch');
    
    // Create new instance pointing to same storage
    const newQueue = new RetryQueue(tempDir);
    const items = newQueue.getRetryableItems();
    
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].batchId, 'batch-123');
  });
});
