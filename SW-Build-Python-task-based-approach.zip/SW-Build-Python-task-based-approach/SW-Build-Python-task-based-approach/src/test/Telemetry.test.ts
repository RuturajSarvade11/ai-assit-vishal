import * as assert from 'assert';
import * as fs from 'fs';
import * as path from 'path';
import { Telemetry } from '../utils/Telemetry';

suite('Telemetry Test Suite', () => {
  let tempDir: string;
  let telemetry: Telemetry;

  setup(() => {
    tempDir = path.join(__dirname, '..', '..', '..', 'test-temp-telemetry');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    telemetry = new Telemetry(tempDir);
  });

  teardown(() => {
    try {
      if (fs.existsSync(tempDir)) {
        const files = fs.readdirSync(tempDir);
        for (const file of files) {
          fs.unlinkSync(path.join(tempDir, file));
        }
        fs.rmdirSync(tempDir);
      }
    } catch (err) {
      // Ignore cleanup errors
    }
  });

  test('Should initialize with default metrics', () => {
    const metrics = telemetry.getMetrics();
    
    assert.ok(metrics.timestamp);
    assert.strictEqual(metrics.fileWatcherStats?.filesWatched, 0);
    assert.strictEqual(metrics.uploadStats?.successfulUploads, 0);
    assert.strictEqual(metrics.errorStats?.buildErrorsDetected, 0);
  });

  test('Should record file processing', () => {
    telemetry.recordFileProcessed(false); // text file
    telemetry.recordFileProcessed(true);  // binary file
    
    const metrics = telemetry.getMetrics();
    assert.strictEqual(metrics.fileWatcherStats?.textFilesProcessed, 1);
    assert.strictEqual(metrics.fileWatcherStats?.binaryFilesProcessed, 1);
  });

  test('Should record upload results', () => {
    telemetry.recordUpload(true, 1024);
    telemetry.recordUpload(true, 2048);
    telemetry.recordUpload(false);
    
    const metrics = telemetry.getMetrics();
    assert.strictEqual(metrics.uploadStats?.successfulUploads, 2);
    assert.strictEqual(metrics.uploadStats?.failedUploads, 1);
    assert.strictEqual(metrics.uploadStats?.totalBytesUploaded, 3072);
  });

  test('Should record retry uploads', () => {
    telemetry.recordUpload(true, 1024, true);
    
    const metrics = telemetry.getMetrics();
    assert.strictEqual(metrics.uploadStats?.retriedUploads, 1);
    assert.strictEqual(metrics.uploadStats?.successfulUploads, 1);
  });

  test('Should record error sessions', () => {
    telemetry.recordErrorSession(true);  // created
    telemetry.recordErrorSession(true);  // created
    telemetry.recordErrorSession(false); // completed
    
    const metrics = telemetry.getMetrics();
    assert.strictEqual(metrics.errorStats?.sessionsCreated, 2);
    assert.strictEqual(metrics.errorStats?.sessionsCompleted, 1);
  });

  test('Should record build errors', () => {
    telemetry.recordBuildErrors(5);
    telemetry.recordBuildErrors(3);
    
    const metrics = telemetry.getMetrics();
    assert.strictEqual(metrics.errorStats?.buildErrorsDetected, 8);
  });

  test('Should update cache statistics', () => {
    telemetry.updateCacheStats(80, 100);
    
    const metrics = telemetry.getMetrics();
    assert.strictEqual(metrics.fileWatcherStats?.cacheHitRate, 80);
  });

  test('Should update circuit breaker state', () => {
    telemetry.recordCircuitBreakerStateChange('OPEN');
    
    const metrics = telemetry.getMetrics();
    assert.strictEqual(metrics.circuitBreakerStats?.state, 'OPEN');
    assert.strictEqual(metrics.circuitBreakerStats?.openCount, 1);
    assert.ok(metrics.circuitBreakerStats?.lastOpenTime);
  });

  test('Should track circuit breaker open count', () => {
    telemetry.recordCircuitBreakerStateChange('OPEN');
    telemetry.recordCircuitBreakerStateChange('CLOSED');
    telemetry.recordCircuitBreakerStateChange('OPEN');
    
    const metrics = telemetry.getMetrics();
    assert.strictEqual(metrics.circuitBreakerStats?.openCount, 2);
  });

  test('Should record processing times', () => {
    telemetry.recordProcessingTime(100, false); // file processing
    telemetry.recordProcessingTime(200, false);
    telemetry.recordProcessingTime(500, true);  // upload
    
    const metrics = telemetry.getMetrics();
    assert.ok(metrics.performanceStats && metrics.performanceStats.avgFileProcessingTime > 0);
    assert.ok(metrics.performanceStats && metrics.performanceStats.avgUploadTime > 0);
  });

  test('Should calculate session duration', () => {
    const metrics1 = telemetry.getMetrics();
    
    // Wait a bit
    setTimeout(() => {
      const metrics2 = telemetry.getMetrics();
      assert.ok(metrics2.sessionDuration! > metrics1.sessionDuration!);
    }, 100);
  });

  test('Should save metrics to disk', () => {
    telemetry.recordFileProcessed(false);
    telemetry.save();
    
    const metricsFile = path.join(tempDir, 'telemetry.json');
    assert.ok(fs.existsSync(metricsFile));
    
    const content = JSON.parse(fs.readFileSync(metricsFile, 'utf8'));
    assert.strictEqual(content.fileWatcherStats.textFilesProcessed, 1);
  });
});
