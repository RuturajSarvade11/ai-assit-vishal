import * as assert from 'assert';
import * as fs from 'fs';
import * as path from 'path';
import { FileUtils } from '../utils/FileUtils';

suite('FileUtils Validation Test Suite', () => {
  let tempDir: string;

  setup(() => {
    tempDir = path.join(__dirname, '..', '..', '..', 'test-temp-fileutils');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
  });

  teardown(() => {
    try {
      if (fs.existsSync(tempDir)) {
        const files = fs.readdirSync(tempDir);
        for (const file of files) {
          fs.unlinkSync(path.join(tempDir, file));
        }
        fs.rmdirSync(tempDir);
      }
    } catch (err) {
      // Ignore cleanup errors
    }
  });

  test('Should validate small text files', () => {
    const testFile = path.join(tempDir, 'small.txt');
    fs.writeFileSync(testFile, 'Hello World');
    
    assert.strictEqual(FileUtils.validateFileSize(testFile), true);
  });

  test('Should reject files exceeding text file limit', () => {
    const testFile = path.join(tempDir, 'large.txt');
    // Create 11MB file (exceeds 10MB default limit)
    const largeContent = Buffer.alloc(11 * 1024 * 1024);
    fs.writeFileSync(testFile, largeContent);
    
    assert.strictEqual(FileUtils.validateFileSize(testFile), false);
  });

  test('Should validate binary files with higher limit', () => {
    const testFile = path.join(tempDir, 'medium.jar');
    // Create 50MB file (within default 1024MB binary limit)
    const content = Buffer.alloc(50 * 1024 * 1024);
    fs.writeFileSync(testFile, content);
    
    assert.strictEqual(FileUtils.validateFileSize(testFile), true);
  });

  test('Should reject binary files exceeding custom limit', () => {
    const testFile = path.join(tempDir, 'huge.jar');
    // Create 21MB file and validate against custom 20MB cap
    const content = Buffer.alloc(21 * 1024 * 1024);
    fs.writeFileSync(testFile, content);
    
    assert.strictEqual(FileUtils.validateFileSize(testFile, 20 * 1024 * 1024), false);
  });

  test('Should accept custom size limits', () => {
    const testFile = path.join(tempDir, 'custom.txt');
    fs.writeFileSync(testFile, Buffer.alloc(500));
    
    // Should pass with 1KB limit
    assert.strictEqual(FileUtils.validateFileSize(testFile, 1024), true);
    
    // Should fail with 100 byte limit
    assert.strictEqual(FileUtils.validateFileSize(testFile, 100), false);
  });

  test('Should return false for non-existent files', () => {
    const testFile = path.join(tempDir, 'nonexistent.txt');
    
    assert.strictEqual(FileUtils.validateFileSize(testFile), false);
  });

  test('Should safely read validated files', async () => {
    const testFile = path.join(tempDir, 'safe.txt');
    const content = 'Safe content';
    fs.writeFileSync(testFile, content);
    
    const result = await FileUtils.readFileSafeWithValidation(testFile);
    assert.strictEqual(result, content);
  });

  test('Should throw error when reading oversized files', async () => {
    const testFile = path.join(tempDir, 'oversized.txt');
    const largeContent = Buffer.alloc(11 * 1024 * 1024);
    fs.writeFileSync(testFile, largeContent);
    
    try {
      await FileUtils.readFileSafeWithValidation(testFile);
      assert.fail('Should have thrown error');
    } catch (err: any) {
      assert.ok(err.message.includes('exceeds size limit'));
    }
  });

  test('Should safely read binary files', () => {
    const testFile = path.join(tempDir, 'binary.dat');
    const content = Buffer.from([0x00, 0x01, 0x02, 0x03]);
    fs.writeFileSync(testFile, content);
    
    const result = FileUtils.readBinarySafe(testFile);
    assert.deepStrictEqual(result, content);
  });

  test('Should throw error for oversized binary files with custom limit', () => {
    const testFile = path.join(tempDir, 'oversized.dat');
    const largeContent = Buffer.alloc(21 * 1024 * 1024);
    fs.writeFileSync(testFile, largeContent);
    
    try {
      FileUtils.readBinarySafe(testFile, 20 * 1024 * 1024);
      assert.fail('Should have thrown error');
    } catch (err: any) {
      assert.ok(err.message.includes('exceeds size limit'));
    }
  });

  test('Should format file sizes correctly', () => {
    assert.strictEqual(FileUtils.formatFileSize(512), '512 B');
    assert.strictEqual(FileUtils.formatFileSize(1024), '1.00 KB');
    assert.strictEqual(FileUtils.formatFileSize(1024 * 1024), '1.00 MB');
    assert.strictEqual(FileUtils.formatFileSize(1024 * 1024 * 2.5), '2.50 MB');
  });
});
