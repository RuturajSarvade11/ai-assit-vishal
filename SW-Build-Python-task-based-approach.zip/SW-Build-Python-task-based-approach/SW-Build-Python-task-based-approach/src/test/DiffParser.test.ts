import * as assert from 'assert';
import { DiffParser } from '../utils/DiffParser';

suite('DiffParser C/C++ Test Suite', () => {
  test('Should parse C function', async () => {
    const code = `
int add(int a, int b) {
  return a + b;
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    
    assert.strictEqual(ranges.length, 1);
    assert.strictEqual(ranges[0].name, 'add');
  });

  test('Should parse multiple C functions', async () => {
    const code = `
int add(int a, int b) {
  return a + b;
}

int subtract(int a, int b) {
  return a - b;
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    
    assert.strictEqual(ranges.length, 2);
    assert.strictEqual(ranges[0].name, 'add');
    assert.strictEqual(ranges[1].name, 'subtract');
  });

  test('Should parse static functions', async () => {
    const code = `
static int helper() {
  return 42;
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    
    assert.ok(ranges.length > 0);
    assert.strictEqual(ranges[0].name, 'helper');
  });

  test('Should parse functions with pointer returns', async () => {
    const code = `
char* getString() {
  return "hello";
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    
    assert.ok(ranges.length > 0);
    assert.strictEqual(ranges[0].name, 'getString');
  });

  test('Should handle nested braces', async () => {
    const code = `
void complex() {
  if (true) {
    for (int i = 0; i < 10; i++) {
      printf("%d", i);
    }
  }
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    
    assert.strictEqual(ranges.length, 1);
    assert.strictEqual(ranges[0].name, 'complex');
  });
});

suite('DiffParser Kotlin Test Suite', () => {
  test('Should parse Kotlin function', async () => {
    const code = `
fun add(a: Int, b: Int): Int {
  return a + b
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.kt', 'test.kt');
    
    assert.strictEqual(ranges.length, 1);
    assert.strictEqual(ranges[0].name, 'add');
  });

  test('Should parse private Kotlin function', async () => {
    const code = `
private fun helper() {
  println("helper")
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.kt', 'test.kt');
    
    assert.ok(ranges.length > 0);
    assert.strictEqual(ranges[0].name, 'helper');
  });

  test('Should parse suspend function', async () => {
    const code = `
suspend fun fetchData(): String {
  return "data"
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.kt', 'test.kt');
    
    assert.ok(ranges.length > 0);
    assert.strictEqual(ranges[0].name, 'fetchData');
  });

  test('Should parse expression body function', async () => {
    const code = `
fun square(x: Int) = x * x
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.kt', 'test.kt');
    
    assert.ok(ranges.length > 0);
    assert.strictEqual(ranges[0].name, 'square');
  });
});

suite('DiffParser XML Test Suite', () => {
  test('Should parse XML tags', async () => {
    const code = `
<root>
  <child id="1">
    <item>Value</item>
  </child>
</root>
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.xml', 'test.xml');
    
    assert.ok(ranges.length >= 0); // XML parsing returns blocks
  });

  test('Should parse nested XML tags', async () => {
    const code = `
<configuration>
  <section name="test">
    <item>Value</item>
  </section>
</configuration>
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.xml', 'test.xml');
    
    assert.ok(ranges.length >= 0);
  });
});

suite('DiffParser Header File Test Suite', () => {
  test('Should parse header function declarations', async () => {
    const code = `
int add(int a, int b);
void process();
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.h', 'test.h');
    
    assert.ok(ranges.length >= 0);
  });

  test('Should parse inline functions in headers', async () => {
    const code = `
inline int max(int a, int b) {
  return (a > b) ? a : b;
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.h', 'test.h');
    
    assert.ok(ranges.length > 0);
  });
});

suite('DiffParser Kotlin Script Test Suite', () => {
  test('Should parse Kotlin script blocks', async () => {
    const code = `
tasks.register("hello") {
  doLast {
    println("Hello")
  }
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.kts', 'build.gradle.kts');
    
    assert.ok(ranges.length >= 0);
  });
});

suite('DiffParser LaTeX Test Suite', () => {
  test('Should parse LaTeX sections', async () => {
    const code = `
\\section{Introduction}
Content here

\\subsection{Background}
More content
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.tex', 'document.tex');
    
    assert.ok(ranges.length >= 0);
  });
});

suite('DiffParser Edge Cases Test Suite', () => {
  test('Should handle empty content', async () => {
    const ranges = await DiffParser.getFunctionRanges('', '.c', 'test.c');
    assert.strictEqual(ranges.length, 0);
  });

  test('Should handle content without functions', async () => {
    const code = `
// Just comments
/* More comments */
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    assert.strictEqual(ranges.length, 0);
  });

  test('Should handle malformed function signatures', async () => {
    const code = `
int broken( {
  return 0;
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    // Should not crash, might or might not parse
    assert.ok(Array.isArray(ranges));
  });

  test('Should handle unknown file extensions', async () => {
    const code = 'some content';
    const ranges = await DiffParser.getFunctionRanges(code, '.unknown', 'test.unknown');
    // Should fall back to VS Code symbol provider or return empty
    assert.ok(Array.isArray(ranges));
  });

  test('Should handle very long function bodies', async () => {
    let code = 'void longFunc() {\n';
    for (let i = 0; i < 1000; i++) {
      code += `  line${i}();\n`;
    }
    code += '}';
    
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    assert.ok(ranges.length > 0);
  });

  test('Should handle functions with string literals containing braces', async () => {
    const code = `
void test() {
  printf("{ } braces in string");
  return;
}
`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    assert.strictEqual(ranges.length, 1);
  });
});

suite('DiffParser Range Accuracy Test Suite', () => {
  test('Should return correct line numbers', async () => {
    const code = `line0
void func1() {
  statement;
}
void func2() {
  statement;
}`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    
    if (ranges.length >= 2) {
      assert.ok(ranges[0].start < ranges[0].end);
      assert.ok(ranges[1].start < ranges[1].end);
      assert.ok(ranges[0].end < ranges[1].start);
    }
  });

  test('Should handle functions starting at line 0', async () => {
    const code = `int first() {
  return 1;
}`;
    const ranges = await DiffParser.getFunctionRanges(code, '.c', 'test.c');
    
    assert.ok(ranges.length > 0);
    assert.strictEqual(ranges[0].start, 0);
  });
});
