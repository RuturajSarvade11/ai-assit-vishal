import * as assert from 'assert';
import { ChangeStore } from '../session/ChangeStore';
import { TaskBasedErrorSessionManager } from '../session/TaskBasedErrorSessionManager';
import { BuildError } from '../session/TaskSessionTypes';

suite('TaskBasedErrorSessionManager Test Suite', () => {
  const workspaceRoot = 'D:/workspace';

  function createManager(changeStore?: ChangeStore): TaskBasedErrorSessionManager {
    return new TaskBasedErrorSessionManager(changeStore ?? new ChangeStore(workspaceRoot));
  }

  function buildError(taskPath: string, message: string): BuildError {
    return {
      taskPath,
      message,
      severity: 'ERROR',
    };
  }

  /* ------------------------------------------------------------------ same build type
   *
   * A task that failed in one build type and passed in another must not be considered
   * resolved.
   *
   * The canonical case is the first test below. RMS fails under one requested task; the developer
   * changes something and runs a DIFFERENT task that also executes RMS; RMS comes back clean
   * there. That build never tested the original failure, so the session must stay open.
   *
   * The condition already existed but sat only on the forceResolveAbsent branch, so a clean
   * SEVERITY resolved the session whatever the build type - which is the exact path that case
   * takes. These pin both routes, and pin that the comparison does not block honest resolutions.
   */

  function reconcileClean(manager: TaskBasedErrorSessionManager, taskKey: string,
                          requestedTasksRaw: string, severity = 'ADVICE') {
    return manager.reconcileTaskErrors(new Map(), {
      currentTaskStatuses: new Map([[taskKey, severity]]),
      currentRequestedTasksRaw: requestedTasksRaw,
    } as any);
  }

  test('A clean severity under a DIFFERENT build type does not resolve the failure', () => {
    const manager = createManager();
    const taskKey = ':TARGETS:master:rms';

    manager.reconcileTaskErrors(new Map([[taskKey, [buildError(taskKey, 'RMS failed')]]]),
      { currentRequestedTasksRaw: ':TARGETS:master:1_normal_without_arproc' } as any);
    assert.strictEqual(manager.getActiveSessions().length, 1);

    const resolved = reconcileClean(manager, taskKey, ':TARGETS:master:2_full_with_arproc');

    assert.strictEqual(resolved.length, 0, 'a different build type must not resolve the failure');
    assert.strictEqual(manager.getActiveSessions().length, 1, 'the original failure must stay open');
  });

  test('A clean severity under the SAME build type still resolves the failure', () => {
    const manager = createManager();
    const taskKey = ':TARGETS:master:rms';

    manager.reconcileTaskErrors(new Map([[taskKey, [buildError(taskKey, 'RMS failed')]]]),
      { currentRequestedTasksRaw: ':TARGETS:master:1_normal_without_arproc' } as any);

    const resolved = reconcileClean(manager, taskKey, ':TARGETS:master:1_normal_without_arproc');

    assert.strictEqual(resolved.length, 1, 'the ordinary fix flow must be untouched');
  });

  test('Build type comparison ignores flags, case, leading colons and task order', () => {
    const manager = createManager();
    const taskKey = ':TARGETS:master:rms';

    manager.reconcileTaskErrors(new Map([[taskKey, [buildError(taskKey, 'RMS failed')]]]),
      { currentRequestedTasksRaw: ':TARGETS:master:build :TARGETS:master:check --info' } as any);

    // Same two tasks: other order, no leading colons, different case, extra flag.
    const resolved = reconcileClean(manager, taskKey,
      'targets:master:CHECK targets:master:BUILD --stacktrace');

    assert.strictEqual(resolved.length, 1,
      'the same build type written differently must not be read as a different one');
  });

  test('A session with no recorded launch command still resolves (fail-open)', () => {
    const manager = createManager();
    const taskKey = ':TARGETS:master:rms';

    // No currentRequestedTasksRaw at failure time - TD5, or a session from before this change.
    manager.reconcileTaskErrors(new Map([[taskKey, [buildError(taskKey, 'RMS failed')]]]));

    const resolved = reconcileClean(manager, taskKey, ':TARGETS:master:anything');

    assert.strictEqual(resolved.length, 1,
      'an unknown build type must behave exactly as before, never silently stop recording fixes');
  });

  test('Should revive recently uploaded task session for the same task key', () => {
    const manager = createManager();
    const taskKey = ':TARGETS:HIP26:aramis';

    manager.reconcileTaskErrors(new Map([[taskKey, [buildError(taskKey, 'first failure')]]]));
    const firstSession = manager.getActiveSessions()[0];

    assert.ok(firstSession);

    manager.markTaskUploaded(taskKey);
    assert.strictEqual(manager.getActiveSessions().length, 0);

    manager.reconcileTaskErrors(new Map([[taskKey, [buildError(taskKey, 'same task reappeared')]]]));
    const revivedSession = manager.getActiveSessions()[0];

    assert.ok(revivedSession);
    assert.strictEqual(revivedSession.occurrenceId, firstSession.occurrenceId);
    assert.strictEqual(revivedSession.requestId, firstSession.requestId);
    assert.strictEqual(revivedSession.errorHistory.length, 2);
    assert.deepStrictEqual(
      revivedSession.errors.map((error) => error.message),
      ['first failure', 'same task reappeared']
    );
  });

  test('Should create a new session for a different task after upload', () => {
    const manager = createManager();
    const originalTaskKey = ':TARGETS:HIP26:aramis';
    const nextTaskKey = ':TARGETS:HIP26:copy_missing_images';

    manager.reconcileTaskErrors(new Map([[originalTaskKey, [buildError(originalTaskKey, 'first failure')]]]));
    const firstSession = manager.getActiveSessions()[0];

    manager.markTaskUploaded(originalTaskKey);
    manager.reconcileTaskErrors(new Map([[nextTaskKey, [buildError(nextTaskKey, 'different task failure')]]]));

    const nextSession = manager.getActiveSessions()[0];

    assert.ok(nextSession);
    assert.notStrictEqual(nextSession.occurrenceId, firstSession.occurrenceId);
    assert.strictEqual(nextSession.taskKey, nextTaskKey);
    assert.strictEqual(nextSession.errorHistory.length, 1);
  });

  // GBE 9.5 field bug: switching tasks popped the previous failed task's
  // confirm preview. A clean report resolves a pending task ONLY with same-task evidence.
  test('Clean report from a DIFFERENT task must NOT resolve a pending failed task', () => {
    const manager = createManager();
    const failedTask = ':TARGETS:HIP26:aramis';

    manager.reconcileTaskErrors(
      new Map([[failedTask, [buildError(failedTask, 'task failed')]]]),
      { forceResolveAbsent: false, resolveAllAbsent: false, currentRequestedTasksRaw: 'aramis' }
    );
    assert.strictEqual(manager.getActiveSessions().length, 1);

    // User switches to another task; its build succeeds -> clean report for 'copy_missing_images'.
    const resolved = manager.reconcileTaskErrors(new Map(), {
      forceResolveAbsent: true,
      resolveAllAbsent: false,
      currentRequestedTasksRaw: 'copy_missing_images'
    });

    assert.strictEqual(resolved.length, 0, 'other task success must not resolve the pending task');
    assert.strictEqual(manager.getActiveSessions().length, 1, 'failed task must stay pending');
  });

  test('Clean report after re-running the SAME task resolves it', () => {
    const manager = createManager();
    const failedTask = ':TARGETS:HIP26:aramis';

    manager.reconcileTaskErrors(
      new Map([[failedTask, [buildError(failedTask, 'task failed')]]]),
      { forceResolveAbsent: false, resolveAllAbsent: false, currentRequestedTasksRaw: 'aramis' }
    );

    const resolved = manager.reconcileTaskErrors(new Map(), {
      forceResolveAbsent: true,
      resolveAllAbsent: false,
      currentRequestedTasksRaw: 'aramis'   // short name of :TARGETS:HIP26:aramis
    });

    assert.strictEqual(resolved.length, 1, 'same-task success must resolve the pending task');
    assert.strictEqual(resolved[0].task.taskKey, failedTask);
  });

  test('Clean report after re-running the same AGGREGATE launch command resolves its failed task', () => {
    const manager = createManager();
    const failedTask = ':app:compileJava';

    // Failure happened in a build launched as 'build' (compileJava ran as a dependency).
    manager.reconcileTaskErrors(
      new Map([[failedTask, [buildError(failedTask, 'compilation failed')]]]),
      { forceResolveAbsent: false, resolveAllAbsent: false, currentRequestedTasksRaw: 'build' }
    );

    const resolved = manager.reconcileTaskErrors(new Map(), {
      forceResolveAbsent: true,
      resolveAllAbsent: false,
      currentRequestedTasksRaw: 'build'    // same launch command re-run, now clean
    });

    assert.strictEqual(resolved.length, 1, 're-running the failing launch command must resolve its task');
  });

  // Fail-safe for FUTURE report shapes: only severities positively known as non-error
  // (ADVICE/WARNING/INFO) may resolve a pending task. A severity we've never seen keeps the
  // session pending instead of falsely popping its confirm preview.
  test('UNKNOWN severity for the task must NOT resolve it (fail-safe)', () => {
    const manager = createManager();
    const failedTask = ':TARGETS:HIP26:aramis';

    manager.reconcileTaskErrors(
      new Map([[failedTask, [buildError(failedTask, 'task failed')]]]),
      { forceResolveAbsent: false, resolveAllAbsent: false, currentRequestedTasksRaw: 'aramis' }
    );

    const resolved = manager.reconcileTaskErrors(new Map(), {
      forceResolveAbsent: true,
      resolveAllAbsent: false,
      currentRequestedTasksRaw: 'other_task',
      currentTaskStatuses: new Map([[failedTask, 'FATAL']])   // severity we do not know
    });

    assert.strictEqual(resolved.length, 0, 'unknown severity is not success evidence');
    assert.strictEqual(manager.getActiveSessions().length, 1, 'session must stay pending');
  });

  test('Non-error severity for the task itself resolves it even in another task build', () => {
    const manager = createManager();
    const failedTask = ':TARGETS:HIP26:aramis';

    manager.reconcileTaskErrors(
      new Map([[failedTask, [buildError(failedTask, 'task failed')]]]),
      { forceResolveAbsent: false, resolveAllAbsent: false, currentRequestedTasksRaw: 'aramis' }
    );

    // Another task's build, but THIS task appears in the report with WARNING -> it ran and passed.
    const resolved = manager.reconcileTaskErrors(new Map(), {
      forceResolveAbsent: true,
      resolveAllAbsent: false,
      currentRequestedTasksRaw: 'copy_missing_images',
      currentTaskStatuses: new Map([[failedTask, 'WARNING']])
    });

    assert.strictEqual(resolved.length, 1, 'own non-error severity is same-task evidence');
  });

  test('Should link only file changes made after the task becomes failed', () => {
    const changeStore = new ChangeStore(workspaceRoot);
    const manager = createManager(changeStore);
    const taskKey = ':TARGETS:HIP26:aramis';
    const filePath = `${workspaceRoot}/src/example.ts`;

    const beforeFailure = changeStore.recordTextChange({
      absolutePath: filePath,
      action: 'modified',
      beforeContent: 'const a = 1;',
      afterContent: 'const a = 2;',
    });
    manager.recordFileChange(beforeFailure, filePath);

    manager.reconcileTaskErrors(new Map([[taskKey, [buildError(taskKey, 'task failed')]]]));
    assert.deepStrictEqual(manager.getFilesForTask(taskKey), []);

    const afterFailure = changeStore.recordTextChange({
      absolutePath: filePath,
      action: 'modified',
      beforeContent: 'const a = 2;',
      afterContent: 'const a = 3;',
    });
    manager.recordFileChange(afterFailure, filePath);

    assert.deepStrictEqual(manager.getFilesForTask(taskKey), ['src/example.ts']);
  });
});
