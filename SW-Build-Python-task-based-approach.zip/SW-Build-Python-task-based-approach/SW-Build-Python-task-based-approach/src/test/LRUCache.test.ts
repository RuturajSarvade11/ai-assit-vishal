import * as assert from 'assert';
import { LRUCache } from '../utils/LRUCache';

suite('LRUCache Test Suite', () => {
  test('Should store and retrieve values', () => {
    const cache = new LRUCache<string, number>(3);
    cache.set('a', 1);
    cache.set('b', 2);
    cache.set('c', 3);

    assert.strictEqual(cache.get('a'), 1);
    assert.strictEqual(cache.get('b'), 2);
    assert.strictEqual(cache.get('c'), 3);
  });

  test('Should evict oldest item when capacity exceeded', () => {
    const cache = new LRUCache<string, number>(3);
    cache.set('a', 1);
    cache.set('b', 2);
    cache.set('c', 3);
    cache.set('d', 4); // Should evict 'a'

    assert.strictEqual(cache.get('a'), undefined);
    assert.strictEqual(cache.get('b'), 2);
    assert.strictEqual(cache.get('c'), 3);
    assert.strictEqual(cache.get('d'), 4);
  });

  test('Should update item position on access', () => {
    const cache = new LRUCache<string, number>(3);
    cache.set('a', 1);
    cache.set('b', 2);
    cache.set('c', 3);
    
    cache.get('a'); // Move 'a' to end
    
    cache.set('d', 4); // Should evict 'b', not 'a'

    assert.strictEqual(cache.get('a'), 1);
    assert.strictEqual(cache.get('b'), undefined);
    assert.strictEqual(cache.get('c'), 3);
    assert.strictEqual(cache.get('d'), 4);
  });

  test('Should update existing values without changing position', () => {
    const cache = new LRUCache<string, number>(3);
    cache.set('a', 1);
    cache.set('b', 2);
    cache.set('c', 3);
    
    cache.set('a', 10); // Update 'a'
    
    assert.strictEqual(cache.get('a'), 10);
    assert.strictEqual(cache.size, 3);
  });

  test('Should handle delete operations', () => {
    const cache = new LRUCache<string, number>(3);
    cache.set('a', 1);
    cache.set('b', 2);

    assert.strictEqual(cache.has('a'), true);
    cache.delete('a');
    assert.strictEqual(cache.has('a'), false);
    assert.strictEqual(cache.size, 1);
  });

  test('Should clear all items', () => {
    const cache = new LRUCache<string, number>(3);
    cache.set('a', 1);
    cache.set('b', 2);
    cache.set('c', 3);

    cache.clear();
    
    assert.strictEqual(cache.size, 0);
    assert.strictEqual(cache.get('a'), undefined);
  });

  test('Should handle edge case of size 1', () => {
    const cache = new LRUCache<string, number>(1);
    cache.set('a', 1);
    cache.set('b', 2);

    assert.strictEqual(cache.get('a'), undefined);
    assert.strictEqual(cache.get('b'), 2);
    assert.strictEqual(cache.size, 1);
  });

  test('Should evict oldest item when byte budget exceeded', () => {
    const cache = new LRUCache<string, string>({
      maxEntries: 10,
      maxBytes: 5,
      sizeCalculator: (value) => value.length
    });

    cache.set('a', 'aa');
    cache.set('b', 'bb');
    cache.set('c', 'cc');

    assert.strictEqual(cache.get('a'), undefined);
    assert.strictEqual(cache.get('b'), 'bb');
    assert.strictEqual(cache.get('c'), 'cc');
    assert.strictEqual(cache.bytes, 4);
  });

  test('Should skip caching entries larger than byte budget', () => {
    const cache = new LRUCache<string, string>({
      maxEntries: 10,
      maxBytes: 3,
      sizeCalculator: (value) => value.length
    });

    cache.set('a', 'ab');
    cache.set('b', 'toolarge');

    assert.strictEqual(cache.get('a'), 'ab');
    assert.strictEqual(cache.get('b'), undefined);
    assert.strictEqual(cache.size, 1);
    assert.strictEqual(cache.bytes, 2);
  });

  test('Should keep oversized entries when allowOversizedEntries is enabled', () => {
    const cache = new LRUCache<string, string>({
      maxEntries: 10,
      maxBytes: 3,
      sizeCalculator: (value) => value.length,
      allowOversizedEntries: true
    });

    cache.set('a', 'ab');
    cache.set('b', 'toolarge');

    assert.strictEqual(cache.get('a'), undefined);
    assert.strictEqual(cache.get('b'), 'toolarge');
    assert.strictEqual(cache.size, 1);
    assert.strictEqual(cache.bytes, 'toolarge'.length);
  });
});
