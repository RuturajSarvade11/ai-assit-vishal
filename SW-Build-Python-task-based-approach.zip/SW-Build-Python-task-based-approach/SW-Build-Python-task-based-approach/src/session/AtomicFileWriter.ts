import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

export class AtomicFileWriter {
    public static async writeText(filePath: string, content: string): Promise<void> {
        await this.writeBuffer(filePath, Buffer.from(content, 'utf8'));
    }

    public static async writeJson(filePath: string, value: unknown): Promise<void> {
        await this.writeText(filePath, JSON.stringify(value, null, 2));
    }

    public static async appendJsonLine(filePath: string, value: unknown): Promise<void> {
        await fs.promises.mkdir(path.dirname(filePath), { recursive: true });
        await fs.promises.appendFile(filePath, `${JSON.stringify(value)}\n`, 'utf8');
    }

    public static async writeBuffer(filePath: string, content: Buffer): Promise<void> {
        await fs.promises.mkdir(path.dirname(filePath), { recursive: true });
        const tmpPath = `${filePath}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
        await fs.promises.writeFile(tmpPath, content);
        await this.replaceFile(tmpPath, filePath);
    }

    // On Windows, renaming over an existing file throws EPERM while the destination is
    // momentarily locked (antivirus scan, search indexer, roaming-profile sync, a second VSCode
    // window). Retry briefly, then fall back to copy-over (not atomic, but succeeds against a
    // share-lock). The tmp file is always removed — failures must not litter .tmp files.
    private static readonly RETRYABLE_CODES = new Set(['EPERM', 'EACCES', 'EBUSY', 'ENOTEMPTY']);
    private static readonly REPLACE_RETRY_DELAYS_MS = [25, 50, 100, 250, 500];

    public static async replaceFile(tmpPath: string, filePath: string): Promise<void> {
        for (let attempt = 0; ; attempt++) {
            try {
                await fs.promises.rename(tmpPath, filePath);
                return;
            } catch (error: any) {
                if (this.RETRYABLE_CODES.has(String(error?.code || '')) &&
                    attempt < this.REPLACE_RETRY_DELAYS_MS.length) {
                    await new Promise((resolve) => setTimeout(resolve, this.REPLACE_RETRY_DELAYS_MS[attempt]));
                    continue;
                }
                this.replaceFallbackSync(tmpPath, filePath, error);
                return;
            }
        }
    }

    public static replaceFileSync(tmpPath: string, filePath: string): void {
        for (let attempt = 0; ; attempt++) {
            try {
                fs.renameSync(tmpPath, filePath);
                return;
            } catch (error: any) {
                if (this.RETRYABLE_CODES.has(String(error?.code || '')) &&
                    attempt < this.REPLACE_RETRY_DELAYS_MS.length) {
                    // brief synchronous wait — this path only runs on rare lock contention
                    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, this.REPLACE_RETRY_DELAYS_MS[attempt]);
                    continue;
                }
                this.replaceFallbackSync(tmpPath, filePath, error);
                return;
            }
        }
    }

    // Last-resort replacement when rename keeps failing. A PERSISTENT EPERM (as seen on
    // corporate machines) usually means the destination carries the read-only attribute or a
    // restrictive ACL — Windows refuses rename-over in both cases. Clear read-only and try
    // once more, then copy over the destination (works against share-locks). The tmp file is
    // always removed so failures never litter .tmp files next to the target.
    private static replaceFallbackSync(tmpPath: string, filePath: string, originalError: unknown): void {
        try {
            if (fs.existsSync(filePath)) {
                fs.chmodSync(filePath, 0o666);   // drop read-only; no-op if already writable
                fs.renameSync(tmpPath, filePath);
                return;
            }
        } catch { /* fall through to copy */ }
        try {
            fs.copyFileSync(tmpPath, filePath);
        } catch {
            try { fs.rmSync(tmpPath, { force: true }); } catch { /* best effort */ }
            throw originalError;
        }
        try { fs.rmSync(tmpPath, { force: true }); } catch { /* best effort */ }
    }

    public static readJsonSafe<T>(filePath: string, fallback: T): T {
        try {
            if (!fs.existsSync(filePath)) {
                return fallback;
            }

            return JSON.parse(fs.readFileSync(filePath, 'utf8')) as T;
        } catch {
            return fallback;
        }
    }

    public static readTextSafe(filePath: string, fallback = ''): string {
        try {
            if (!fs.existsSync(filePath)) {
                return fallback;
            }

            return fs.readFileSync(filePath, 'utf8').replace(/\r\n/g, '\n');
        } catch {
            return fallback;
        }
    }
}
