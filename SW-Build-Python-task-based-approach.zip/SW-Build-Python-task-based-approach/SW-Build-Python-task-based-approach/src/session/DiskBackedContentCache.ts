import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { FileUtils } from '../utils/FileUtils';
import { AtomicFileWriter } from './AtomicFileWriter';

type TextEntry = {
  key: string;
  filePath: string;
  bytes: number;
  updatedAt: number;
};

type BufferEntry = TextEntry;

type CacheOptions = {
  maxEntries: number;
  maxBytes?: number;
};

/**
 * Disk-backed cache used to keep large text/binary payloads out of extension memory.
 * The in-memory map stores only small metadata and LRU ordering; content is read
 * from disk only when old code paths explicitly call get().
 */
export class DiskBackedTextCache {
  private readonly entries = new Map<string, TextEntry>();
  private totalBytes = 0;

  constructor(private readonly rootDir: string, private readonly options: CacheOptions) {
    fs.mkdirSync(this.rootDir, { recursive: true });
  }

  public get(key: string): string | undefined {
    const normalizedKey = this.normalizeKey(key);
    const entry = this.entries.get(normalizedKey);
    if (!entry) {
      return undefined;
    }

    this.entries.delete(normalizedKey);
    this.entries.set(normalizedKey, entry);

    try {
      if (!fs.existsSync(entry.filePath)) {
        this.entries.delete(normalizedKey);
        this.totalBytes = Math.max(0, this.totalBytes - entry.bytes);
        return undefined;
      }

      return fs.readFileSync(entry.filePath, 'utf8').replace(/\r\n/g, '\n');
    } catch {
      return undefined;
    }
  }

  public set(key: string, value: string): void {
    const normalizedKey = this.normalizeKey(key);
    const content = String(value ?? '').replace(/\r\n/g, '\n');
    const bytes = Buffer.byteLength(content, 'utf8');
    const filePath = this.getContentPath(normalizedKey);

    this.delete(normalizedKey);
    this.writeAtomic(filePath, Buffer.from(content, 'utf8'));

    this.entries.set(normalizedKey, {
      key: normalizedKey,
      filePath,
      bytes,
      updatedAt: Date.now()
    });
    this.totalBytes += bytes;
    this.evictIfNeeded();
  }

  public delete(key: string): boolean {
    const normalizedKey = this.normalizeKey(key);
    const entry = this.entries.get(normalizedKey);
    if (!entry) {
      return false;
    }

    this.entries.delete(normalizedKey);
    this.totalBytes = Math.max(0, this.totalBytes - entry.bytes);
    try { fs.rmSync(entry.filePath, { force: true }); } catch { /* ignore */ }
    return true;
  }

  public clear(): void {
    this.entries.clear();
    this.totalBytes = 0;
    try { fs.rmSync(this.rootDir, { recursive: true, force: true }); } catch { /* ignore */ }
    fs.mkdirSync(this.rootDir, { recursive: true });
  }

  public has(key: string): boolean {
    return this.entries.has(this.normalizeKey(key));
  }

  public get size(): number {
    return this.entries.size;
  }

  public get bytes(): number {
    return this.totalBytes;
  }

  private evictIfNeeded(): void {
    while (this.entries.size > this.options.maxEntries || (this.options.maxBytes !== undefined && this.totalBytes > this.options.maxBytes)) {
      const first = this.entries.entries().next().value as [string, TextEntry] | undefined;
      if (!first) { return; }
      this.delete(first[0]);
    }
  }

  private getContentPath(key: string): string {
    const safeName = crypto.createHash('sha1').update(key).digest('hex');
    return path.join(this.rootDir, `${safeName}.content`);
  }

  private normalizeKey(key: string): string {
    return FileUtils.normalizePath(String(key || '')).toLowerCase();
  }

  private writeAtomic(filePath: string, content: Buffer): void {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const tmpPath = `${filePath}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
    fs.writeFileSync(tmpPath, content);
    AtomicFileWriter.replaceFileSync(tmpPath, filePath);
  }
}

/**
 * Disk-backed replacement for Buffer LRU caches. It preserves the old synchronous
 * get/set/delete/clear API while storing binary payloads on disk.
 */
export class DiskBackedBufferCache {
  private readonly entries = new Map<string, BufferEntry>();
  private totalBytes = 0;

  constructor(private readonly rootDir: string, private readonly options: CacheOptions) {
    fs.mkdirSync(this.rootDir, { recursive: true });
  }

  public get(key: string): Buffer | undefined {
    const normalizedKey = this.normalizeKey(key);
    const entry = this.entries.get(normalizedKey);
    if (!entry) {
      return undefined;
    }

    this.entries.delete(normalizedKey);
    this.entries.set(normalizedKey, entry);

    try {
      if (!fs.existsSync(entry.filePath)) {
        this.entries.delete(normalizedKey);
        this.totalBytes = Math.max(0, this.totalBytes - entry.bytes);
        return undefined;
      }

      return fs.readFileSync(entry.filePath);
    } catch {
      return undefined;
    }
  }

  public set(key: string, value: Buffer): void {
    if (!value) { return; }

    const normalizedKey = this.normalizeKey(key);
    const filePath = this.getContentPath(normalizedKey);
    const bytes = value.byteLength;

    this.delete(normalizedKey);
    this.writeAtomic(filePath, value);

    this.entries.set(normalizedKey, {
      key: normalizedKey,
      filePath,
      bytes,
      updatedAt: Date.now()
    });
    this.totalBytes += bytes;
    this.evictIfNeeded();
  }

  public delete(key: string): boolean {
    const normalizedKey = this.normalizeKey(key);
    const entry = this.entries.get(normalizedKey);
    if (!entry) {
      return false;
    }

    this.entries.delete(normalizedKey);
    this.totalBytes = Math.max(0, this.totalBytes - entry.bytes);
    try { fs.rmSync(entry.filePath, { force: true }); } catch { /* ignore */ }
    return true;
  }

  public clear(): void {
    this.entries.clear();
    this.totalBytes = 0;
    try { fs.rmSync(this.rootDir, { recursive: true, force: true }); } catch { /* ignore */ }
    fs.mkdirSync(this.rootDir, { recursive: true });
  }

  public has(key: string): boolean {
    return this.entries.has(this.normalizeKey(key));
  }

  public get size(): number {
    return this.entries.size;
  }

  public get bytes(): number {
    return this.totalBytes;
  }

  private evictIfNeeded(): void {
    while (this.entries.size > this.options.maxEntries || (this.options.maxBytes !== undefined && this.totalBytes > this.options.maxBytes)) {
      const first = this.entries.entries().next().value as [string, BufferEntry] | undefined;
      if (!first) { return; }
      this.delete(first[0]);
    }
  }

  private getContentPath(key: string): string {
    const safeName = crypto.createHash('sha1').update(key).digest('hex');
    return path.join(this.rootDir, `${safeName}.bin`);
  }

  private normalizeKey(key: string): string {
    return FileUtils.normalizePath(String(key || '')).toLowerCase();
  }

  private writeAtomic(filePath: string, content: Buffer): void {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const tmpPath = `${filePath}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
    fs.writeFileSync(tmpPath, content);
    AtomicFileWriter.replaceFileSync(tmpPath, filePath);
  }
}
