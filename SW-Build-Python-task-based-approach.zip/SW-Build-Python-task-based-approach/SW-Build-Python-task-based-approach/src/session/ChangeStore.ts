import * as fs from 'fs';
import * as path from 'path';
import {
    BinaryFileChangeRecord,
    FileAction,
    FileChangeRecord,
    FileKey,
    TextFileChangeRecord
} from './TaskSessionTypes';
import { FileUtils } from '../utils/FileUtils';

export type TextChangeInput = {
    absolutePath: string;
    action: FileAction;
    beforeContent?: string;
    afterContent?: string;
    lastDivergedContent?: string | null;
    snapshotBeforePath?: string;
    snapshotAfterPath?: string;
    lastDivergedSnapshotPath?: string | null;
    rawBeforeHash?: string;
    rawAfterHash?: string;
    rawLastDivergedHash?: string;
    normalizedBeforeHash?: string;
    normalizedAfterHash?: string;
    normalizedLastDivergedHash?: string;
    changeType?: 'no-change' | 'formatting-only-change' | 'meaningful-change' | 'reverted-change' | 'binary-changed';
};

export type BinaryChangeInput = {
    absolutePath: string;
    action: FileAction;
    beforeHash?: string;
    afterHash?: string;
    sizeBytes?: number;
    fileContent?: Buffer;
};

export class ChangeStore {
    private readonly changes = new Map<FileKey, FileChangeRecord>();

    constructor(private readonly workspaceRoot: string) { }

    public recordTextChange(input: TextChangeInput): TextFileChangeRecord {
        const now = Date.now();
        const absolutePath = FileUtils.normalizePath(input.absolutePath);
        const fileKey = this.toFileKey(absolutePath);

        const existing = this.changes.get(fileKey);

        // Keep ChangeStore metadata-light. When snapshot paths are available,
        // content stays on disk and these legacy string fields remain empty.
        const beforeContent = input.snapshotBeforePath
            ? ''
            : (existing?.kind === 'text' ? existing.beforeContent : input.beforeContent ?? '');

        const latestBeforeContent = input.snapshotBeforePath
            ? ''
            : (existing?.kind === 'text' ? (input.beforeContent ?? existing.afterContent) : input.beforeContent ?? '');

        const afterContent = input.snapshotAfterPath
            ? ''
            : (input.action === 'deleted' ? '' : input.afterContent ?? this.safeReadTextFile(absolutePath));

        const record: TextFileChangeRecord = {
            kind: 'text',
            fileKey,
            filePath: fileKey,
            absolutePath,
            action: input.action,
            beforeContent,
            afterContent,
            latestBeforeContent,
            latestAfterContent: afterContent,
            lastDivergedContent: input.lastDivergedSnapshotPath ? null : (input.lastDivergedContent ?? (existing?.kind === 'text' ? existing.lastDivergedContent : null)),
            snapshotBeforePath: input.snapshotBeforePath ?? (existing?.kind === 'text' ? existing.snapshotBeforePath : undefined),
            snapshotAfterPath: input.snapshotAfterPath ?? (existing?.kind === 'text' ? existing.snapshotAfterPath : undefined),
            lastDivergedSnapshotPath: input.lastDivergedSnapshotPath ?? (existing?.kind === 'text' ? existing.lastDivergedSnapshotPath : undefined),
            rawBeforeHash: input.rawBeforeHash ?? (existing?.kind === 'text' ? existing.rawBeforeHash : undefined),
            rawAfterHash: input.rawAfterHash ?? (existing?.kind === 'text' ? existing.rawAfterHash : undefined),
            rawLastDivergedHash: input.rawLastDivergedHash ?? (existing?.kind === 'text' ? existing.rawLastDivergedHash : undefined),
            normalizedBeforeHash: input.normalizedBeforeHash ?? (existing?.kind === 'text' ? existing.normalizedBeforeHash : undefined),
            normalizedAfterHash: input.normalizedAfterHash ?? (existing?.kind === 'text' ? existing.normalizedAfterHash : undefined),
            normalizedLastDivergedHash: input.normalizedLastDivergedHash ?? (existing?.kind === 'text' ? existing.normalizedLastDivergedHash : undefined),
            changeType: input.changeType ?? (existing?.kind === 'text' ? existing.changeType : undefined),
            firstChangedAt: existing?.firstChangedAt || now,
            lastChangedAt: now
        };

        this.changes.set(fileKey, record);
        return record;
    }

    public recordBinaryChange(input: BinaryChangeInput): BinaryFileChangeRecord {
        const now = Date.now();
        const absolutePath = FileUtils.normalizePath(input.absolutePath);
        const fileKey = this.toFileKey(absolutePath);

        const existing = this.changes.get(fileKey);

        const record: BinaryFileChangeRecord = {
            kind: 'binary',
            fileKey,
            filePath: fileKey,
            absolutePath,
            action: input.action,
            beforeHash: existing?.kind === 'binary'
                ? existing.beforeHash
                : input.beforeHash,
            afterHash: input.afterHash,
            sizeBytes: input.sizeBytes,
            fileContent: input.fileContent,
            firstChangedAt: existing?.firstChangedAt || now,
            lastChangedAt: now
        };

        this.changes.set(fileKey, record);
        return record;
    }

    public get(fileKey: FileKey): FileChangeRecord | undefined {
        return this.changes.get(fileKey);
    }

    public getMany(fileKeys: Iterable<FileKey>): FileChangeRecord[] {
        const result: FileChangeRecord[] = [];

        for (const fileKey of fileKeys) {
            const record = this.changes.get(fileKey);

            if (record) {
                result.push(record);
            }
        }

        return result;
    }

    public getAll(): FileChangeRecord[] {
        return Array.from(this.changes.values());
    }

    public has(fileKey: FileKey): boolean {
        return this.changes.has(fileKey);
    }

    public delete(fileKey: FileKey): void {
        this.changes.delete(fileKey);
    }

    public clear(): void {
        this.changes.clear();
    }

    public resetBaseline(fileKeys: Iterable<FileKey>): void {
        const now = Date.now();

        for (const fileKey of fileKeys) {
            const record = this.changes.get(fileKey);

            if (!record) {
                continue;
            }

            if (record.kind === 'text') {
                this.changes.set(fileKey, {
                    ...record,
                    beforeContent: '',
                    afterContent: '',
                    latestBeforeContent: '',
                    latestAfterContent: '',
                    lastDivergedContent: null,
                    lastDivergedSnapshotPath: null,
                    changeType: 'no-change',
                    firstChangedAt: now,
                    lastChangedAt: now
                });

                continue;
            }

            this.changes.set(fileKey, {
                ...record,
                beforeHash: record.afterHash || record.beforeHash,
                fileContent: undefined,
                firstChangedAt: now,
                lastChangedAt: now
            });
        }
    }

    public deleteUnreferenced(activeFileKeys: Set<FileKey>): void {
        for (const fileKey of Array.from(this.changes.keys())) {
            if (!activeFileKeys.has(fileKey)) {
                this.changes.delete(fileKey);
            }
        }
    }

    public toFileKey(absolutePath: string): FileKey {
        const normalizedAbsolute = FileUtils.normalizePath(absolutePath);
        const relativePath = FileUtils.toWorkspaceRelativePath(normalizedAbsolute, this.workspaceRoot);

        if (relativePath !== null) {
            return relativePath;
        }

        return normalizedAbsolute;
    }

    public createTextDiff(record: TextFileChangeRecord): string {
        const beforeContent = this.readSnapshotText(record.snapshotBeforePath, record.beforeContent);
        const afterContent = this.readSnapshotText(record.snapshotAfterPath, record.afterContent);
        const beforeLines = beforeContent.replace(/\r\n/g, '\n').split('\n');
        const afterLines = afterContent.replace(/\r\n/g, '\n').split('\n');

        const max = Math.max(beforeLines.length, afterLines.length);
        const diffLines: string[] = [];

        for (let i = 0; i < max; i++) {
            const beforeLine = beforeLines[i] ?? '';
            const afterLine = afterLines[i] ?? '';

            if (beforeLine === afterLine) {
                continue;
            }

            if (beforeLine) {
                diffLines.push(`- [${i + 1}] ${beforeLine}`);
            }

            if (afterLine) {
                diffLines.push(`+ [${i + 1}] ${afterLine}`);
            }
        }

        return diffLines.join('\n');
    }

    private readSnapshotText(snapshotPath: string | undefined | null, fallback = ''): string {
        try {
            if (snapshotPath && fs.existsSync(snapshotPath)) {
                return fs.readFileSync(snapshotPath, 'utf8').replace(/\r\n/g, '\n');
            }
        } catch {
            return fallback || '';
        }

        return fallback || '';
    }

    private safeReadTextFile(filePath: string): string {
        try {
            if (!fs.existsSync(filePath)) {
                return '';
            }

            return fs.readFileSync(filePath, 'utf8').replace(/\r\n/g, '\n');
        } catch {
            return '';
        }
    }
}
