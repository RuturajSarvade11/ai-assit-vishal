export const UNKNOWN_GRADLE_TASK_KEY = '__UNKNOWN_GRADLE_TASK__';

export type TaskKey = string;
export type FileKey = string;

export type FileAction = 'added' | 'modified' | 'deleted';

export type BuildError = {
    path?: string;
    message: string;
    severity?: string;
    taskPath?: string;
    taskName?: string;
    requestedTask?: string;
    line?: number;
    column?: number;
    raw?: any;
};

export type TaskErrorInput = {
    taskKey: TaskKey;
    taskName?: string;
    errors: BuildError[];
};

export type TaskSessionStatus =
    | 'active_failed'
    | 'not_seen_once'
    | 'resolved_pending_upload'
    | 'uploaded';

export type TaskFileLinkType = 'direct' | 'shared' | 'inferred';

export type TaskTextChangeSnapshot = {
    changedAt: number;
    action: FileAction;
    beforeContent: string;
    afterContent: string;
    snapshotBeforePath?: string;
    snapshotAfterPath?: string;
    lastDivergedSnapshotPath?: string | null;
    changeType?: 'no-change' | 'formatting-only-change' | 'meaningful-change' | 'reverted-change' | 'binary-changed';
};

export type TaskFileLink = {
    fileKey: FileKey;
    linkType: TaskFileLinkType;
    linkedAt: number;
    lastChangedAt: number;
    activityCount: number;
    fileKind?: 'text' | 'binary';
    initialTextContent?: string;
    initialBinaryHash?: string;
    latestTextBeforeContent?: string;
    latestTextAfterContent?: string;
    latestAction?: FileAction;
    textChangeTrail?: TaskTextChangeSnapshot[];
    snapshotBeforePath?: string;
    snapshotAfterPath?: string;
    lastDivergedSnapshotPath?: string | null;
    changeType?: 'no-change' | 'formatting-only-change' | 'meaningful-change' | 'reverted-change' | 'binary-changed';
};

export type TaskErrorHistoryEntry = {
    seenAt: number;
    errors: BuildError[];
};

export type TaskSession = {
    taskKey: TaskKey;
    taskName: string;
    occurrenceId: string;
    status: TaskSessionStatus;
    errors: BuildError[];
    errorHistory: TaskErrorHistoryEntry[];
    firstSeenAt: number;
    lastSeenAt: number;
    notSeenCount: number;
    requestId: string;
    // Raw requestedTasks of the build in which this task last FAILED. Same-task resolution
    // evidence: a later CLEAN report resolves this session only if that build requested the same
    // task(s) again (switching to another task must never pop this task's confirm preview).
    // Optional so sessions persisted before this field exists still revive.
    requestedTasksAtFailure?: string;
};

export type TextFileChangeRecord = {
    kind: 'text';
    fileKey: FileKey;
    filePath: string;
    absolutePath: string;
    action: FileAction;
    beforeContent: string;
    afterContent: string;
    latestBeforeContent: string;
    latestAfterContent: string;
    lastDivergedContent?: string | null;
    snapshotBeforePath?: string;
    snapshotAfterPath?: string;
    lastDivergedSnapshotPath?: string | null;
    rawBeforeHash?: string;
    rawAfterHash?: string;
    rawLastDivergedHash?: string;
    normalizedBeforeHash?: string;
    normalizedAfterHash?: string;
    normalizedLastDivergedHash?: string;
    changeType?: 'no-change' | 'formatting-only-change' | 'meaningful-change' | 'reverted-change' | 'binary-changed';
    firstChangedAt: number;
    lastChangedAt: number;
};

export type BinaryFileChangeRecord = {
    kind: 'binary';
    fileKey: FileKey;
    filePath: string;
    absolutePath: string;
    action: FileAction;
    beforeHash?: string;
    afterHash?: string;
    sizeBytes?: number;
    fileContent?: Buffer;
    firstChangedAt: number;
    lastChangedAt: number;
};

export type FileChangeRecord = TextFileChangeRecord | BinaryFileChangeRecord;

export type ResolvedTaskPackage = {
    task: TaskSession;
    files: FileChangeRecord[];
    fileLinks: TaskFileLink[];
    resolutionReason?: 'severity_changed' | 'not_seen_twice' | 'all_clear';
};

export type TaskSessionSnapshot = {
    activeTasks: TaskSession[];
    taskFileMap: Record<string, string[]>;
    taskFileLinks?: Record<string, TaskFileLink[]>;
    changedFiles: FileChangeRecord[];
};

export function normalizeTaskKey(taskPath?: string, taskName?: string): TaskKey {
    const raw = String(taskPath || taskName || '').trim();

    if (!raw) {
        return UNKNOWN_GRADLE_TASK_KEY;
    }

    if (raw === UNKNOWN_GRADLE_TASK_KEY) {
        return raw;
    }

    return raw.startsWith(':') ? raw : `:${raw}`;
}

export function getTaskDisplayName(taskKey: TaskKey): string {
    if (taskKey === UNKNOWN_GRADLE_TASK_KEY) {
        return 'Unknown Gradle Task';
    }

    return taskKey;
}

export function normalizeSeverity(severity?: string): string {
    return String(severity || '').trim().toUpperCase();
}

export function isErrorSeverity(severity?: string): boolean {
    return normalizeSeverity(severity || 'ERROR') === 'ERROR';
}

// Severities that are POSITIVELY known to mean "the task ran and is not failing" (Gradle problems
// report vocabulary as of 8.x/9.x). Resolution of a pending failed task may only trust these.
// A severity NOT in this set (e.g. a value a future Gradle version introduces) must NEVER resolve
// a task — fail-safe: unknown evidence keeps the session pending instead of popping a preview.
const NON_ERROR_SEVERITIES = new Set(['ADVICE', 'WARNING', 'INFO']);

export function isKnownNonErrorSeverity(severity?: string): boolean {
    return NON_ERROR_SEVERITIES.has(normalizeSeverity(severity));
}

export function groupBuildErrorsByTask(errors: BuildError[]): Map<TaskKey, BuildError[]> {
    const grouped = new Map<TaskKey, BuildError[]>();
    const seen = new Set<string>();

    for (const error of errors || []) {
        if (!isErrorSeverity(error.severity || 'ERROR')) {
            continue;
        }

        const taskKey = normalizeTaskKey(error.taskPath, error.taskName || error.requestedTask);
        const message = String(error.message || '').trim();

        if (!message) {
            continue;
        }

        const key = [
            taskKey,
            String(error.path || '').replace(/\\/g, '/').trim(),
            message.replace(/\s+/g, ' ').trim().toLowerCase()
        ].join('|');

        if (seen.has(key)) {
            continue;
        }

        seen.add(key);

        const existing = grouped.get(taskKey) || [];
        existing.push({
            ...error,
            message,
            severity: normalizeSeverity(error.severity || 'ERROR'),
            taskPath: taskKey
        });

        grouped.set(taskKey, existing);
    }

    return grouped;
}
