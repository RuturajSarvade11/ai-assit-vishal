import * as crypto from 'crypto';

export type TextChangeType = 'no-change' | 'formatting-only-change' | 'meaningful-change' | 'reverted-change' | 'binary-changed';

export type ContentHashes = {
    rawHash: string;
    normalizedHash: string;
};

export class ChangeHashUtil {
    public static createRawHash(content: string | Buffer): string {
        return crypto.createHash('sha256').update(content).digest('hex');
    }

    public static normalizeForComparison(content: string): string {
        return String(content || '')
            .replace(/^\uFEFF/, '')
            .replace(/\r\n/g, '\n')
            .replace(/\r/g, '\n')
            .split('\n')
            .map((line) => line.trim())
            .filter((line) => line.length > 0)
            .join('\n');
    }

    public static createNormalizedHash(content: string): string {
        return this.createRawHash(this.normalizeForComparison(content));
    }

    public static createTextHashes(content: string): ContentHashes {
        return {
            rawHash: this.createRawHash(content),
            normalizedHash: this.createNormalizedHash(content)
        };
    }

    public static getChangeType(beforeContent: string, afterContent: string, lastDivergedContent?: string | null): TextChangeType {
        const before = this.createTextHashes(beforeContent || '');
        const after = this.createTextHashes(afterContent || '');
        const hasLastDiverged = typeof lastDivergedContent === 'string' && lastDivergedContent.length > 0;

        if (before.rawHash === after.rawHash && !hasLastDiverged) {
            return 'no-change';
        }

        if (before.normalizedHash === after.normalizedHash && hasLastDiverged) {
            return 'reverted-change';
        }

        if (before.normalizedHash === after.normalizedHash) {
            return 'formatting-only-change';
        }

        return 'meaningful-change';
    }

    public static isMeaningfulTextChange(beforeContent: string, afterContent: string): boolean {
        return this.createNormalizedHash(beforeContent || '') !== this.createNormalizedHash(afterContent || '');
    }
}
