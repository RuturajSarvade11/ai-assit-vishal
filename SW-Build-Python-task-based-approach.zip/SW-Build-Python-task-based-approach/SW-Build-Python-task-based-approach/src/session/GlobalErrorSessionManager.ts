import * as crypto from 'crypto';
import {
    BuildError,
    FileChangeRecord,
    FileKey
} from './TaskSessionTypes';
import { ChangeStore } from './ChangeStore';

export type GlobalErrorSession = {
    requestId: string;
    errors: BuildError[];
    errorSet: Set<string>;
    firstSeenAt: number;
    lastSeenAt: number;
    requestedTasks: string;
    rootErrorMessage: string;
};

export type ResolvedGlobalErrorPackage = {
    session: GlobalErrorSession;
    files: FileChangeRecord[];
};

export type GlobalErrorSessionSnapshot = {
    active: boolean;
    requestId: string;
    errors: BuildError[];
    requestedTasks: string;
    rootErrorMessage: string;
    fileKeys: string[];
    changedFiles: FileChangeRecord[];
};

export class GlobalErrorSessionManager {
    private activeSession: GlobalErrorSession | null = null;
    private readonly fileKeys = new Set<FileKey>();

    constructor(private readonly changeStore: ChangeStore) { }
    public reconcileErrors(
        currentErrors: BuildError[],
        requestedTasks: string = ''
    ): ResolvedGlobalErrorPackage | null {
        const normalizedErrors = this.normalizeErrors(currentErrors);
        const now = Date.now();

        if (normalizedErrors.length > 0) {
            if (!this.activeSession) {
                this.activeSession = {
                    requestId: this.createRequestId(),
                    errors: normalizedErrors,
                    errorSet: this.createErrorSet(normalizedErrors),
                    firstSeenAt: now,
                    lastSeenAt: now,
                    requestedTasks,
                    rootErrorMessage: this.getRootErrorMessage(normalizedErrors)
                };

                return null;
            }

            this.activeSession = {
                ...this.activeSession,
                errors: this.mergeErrors(this.activeSession.errors, normalizedErrors),
                errorSet: this.createErrorSet([
                    ...this.activeSession.errors,
                    ...normalizedErrors
                ]),
                lastSeenAt: now,
                requestedTasks: requestedTasks || this.activeSession.requestedTasks,
                rootErrorMessage:
                    this.activeSession.rootErrorMessage ||
                    this.getRootErrorMessage(normalizedErrors)
            };

            return null;
        }

        if (!this.activeSession) {
            return null;
        }

        const files = this.changeStore.getMany(this.fileKeys);

        return {
            session: this.activeSession,
            files
        };
    }

    public recordFileChange(fileKey: FileKey): void {
        if (!this.activeSession) {
            return;
        }

        if (!fileKey) {
            return;
        }

        this.fileKeys.add(fileKey);
    }

    public markUploaded(): void {
        this.activeSession = null;
        this.fileKeys.clear();
        this.changeStore.deleteUnreferenced(new Set<FileKey>());
    }

    public markUploadFailed(): void {
        // Keep active session and file references as-is.
    }

    public hasActiveSession(): boolean {
        return !!this.activeSession;
    }

    public getActiveSession(): GlobalErrorSession | null {
        return this.activeSession;
    }

    public getActiveFileKeys(): FileKey[] {
        return Array.from(this.fileKeys);
    }

    public getSnapshot(): GlobalErrorSessionSnapshot {
        return {
            active: !!this.activeSession,
            requestId: this.activeSession?.requestId || '',
            errors: this.activeSession?.errors || [],
            requestedTasks: this.activeSession?.requestedTasks || '',
            rootErrorMessage: this.activeSession?.rootErrorMessage || '',
            fileKeys: Array.from(this.fileKeys),
            changedFiles: this.changeStore.getMany(this.fileKeys)
        };
    }

    public clear(): void {
        this.activeSession = null;
        this.fileKeys.clear();
        this.changeStore.clear();
    }

    private normalizeErrors(errors: BuildError[]): BuildError[] {
        return (errors || [])
            .filter((error) => !!error)
            .map((error) => ({
                ...error,
                message: String(error.message || '').trim()
            }))
            .filter((error) => !!error.message);
    }

    private mergeErrors(existing: BuildError[], incoming: BuildError[]): BuildError[] {
        const merged: BuildError[] = [];
        const seen = new Set<string>();

        for (const error of [...existing, ...incoming]) {
            const key = this.getErrorKey(error);

            if (seen.has(key)) {
                continue;
            }

            seen.add(key);
            merged.push(error);
        }

        return merged;
    }

    private createErrorSet(errors: BuildError[]): Set<string> {
        return new Set(errors.map((error) => this.getErrorKey(error)));
    }

    private getErrorKey(error: BuildError): string {
        return [
            error.taskPath || '',
            error.path || '',
            error.line || '',
            error.column || '',
            error.message || ''
        ].join('|');
    }

    private getRootErrorMessage(errors: BuildError[]): string {
        return String(errors?.[0]?.message || '').trim();
    }

    private createRequestId(): string {
        if (typeof crypto.randomUUID === 'function') {
            return crypto.randomUUID();
        }

        return crypto
            .createHash('sha1')
            .update(`${Date.now()}-${Math.random()}`)
            .digest('hex');
    }
}