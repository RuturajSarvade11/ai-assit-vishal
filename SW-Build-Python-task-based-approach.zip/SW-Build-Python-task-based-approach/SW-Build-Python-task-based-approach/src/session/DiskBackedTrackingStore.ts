import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { AtomicFileWriter } from './AtomicFileWriter';
import { ChangeHashUtil, TextChangeType } from './ChangeHashUtil';
import { FileUtils } from '../utils/FileUtils';
import { FileAction } from './TaskSessionTypes';

export type TrackingSessionMode = 'task' | 'global';
export type TrackingProjectType = 'gradle' | 'td5' | 'generic';

export type TrackingSessionDescriptor = {
    sessionId: string;
    sessionMode: TrackingSessionMode;
    projectType: TrackingProjectType;
    scopeKey: string;
    taskName?: string;
    startedAt?: string;
    baselineFrozenAt?: string;
};

export type RollingBaselineMetadata = {
    filePath: string;
    fileKey: string;
    safeFileKey: string;
    updatedAt: string;
    baselineContentPath: string;
    rawHash: string;
    normalizedHash: string;
    size: number;
    mtimeMs: number;
};

export type SessionTextSnapshotMetadata = {
    changeId: string;
    sessionId: string;
    sessionMode: TrackingSessionMode;
    projectType: TrackingProjectType;
    scopeKey: string;
    taskName?: string;
    filePath: string;
    fileKey: string;
    safeFileKey: string;
    eventType: FileAction;
    snapshotBeforePath: string;
    snapshotAfterPath: string;
    lastDivergedSnapshotPath: string | null;
    rawBeforeHash: string;
    rawAfterHash: string;
    rawLastDivergedHash?: string;
    normalizedBeforeHash: string;
    normalizedAfterHash: string;
    normalizedLastDivergedHash?: string;
    changeType: TextChangeType;
    snapshotBeforeUnavailable?: boolean;
    createdAt: string;
    updatedAt: string;
};

export type SessionTextSnapshot = SessionTextSnapshotMetadata & {
    beforeContent: string;
    afterContent: string;
    lastDivergedContent?: string | null;
};

export type BaselineCleanupOptions = {
    /** Default: true. Cleanup is skipped if any active session still exists on disk or in memory. */
    skipWhenActiveSessions?: boolean;
    /** Optional active session ids from the caller's in-memory state. */
    activeSessionIds?: Iterable<string>;
    /** Default: 3 days. Old baselines become eligible after this age. */
    retentionMs?: number;
    /** Default: 200 MB. Oldest safe baselines are removed if storage exceeds this size. */
    maxStorageBytes?: number;
    /** Default: 5000 files. Oldest safe baselines are removed if file count exceeds this limit. */
    maxBaselineFiles?: number;
    /** If true, bypasses active-session skip. Use only for explicit maintenance/debug cleanup. */
    force?: boolean;
};

export type BaselineCleanupResult = {
    skipped: boolean;
    reason?: string;
    deletedCount: number;
    deletedBytes: number;
    remainingCount: number;
    remainingBytes: number;
};

export type TrackingSessionInfo = TrackingSessionDescriptor & {
    status?: string;
    sessionDir: string;
    hasChanges: boolean;
    changeCount: number;
    updatedAt?: string;
    updatedAtMs: number;
};

export class DiskBackedTrackingStore {
    private static readonly DEFAULT_BASELINE_RETENTION_MS = 3 * 24 * 60 * 60 * 1000;
    private static readonly DEFAULT_MAX_BASELINE_STORAGE_BYTES = 200 * 1024 * 1024;
    private static readonly DEFAULT_MAX_BASELINE_FILES = 500;

    private readonly rootDir: string;
    private readonly baselineIndexPath: string;
    private readonly journalPath: string;

    constructor(
        storageRoot: string,
        private readonly workspaceRoot: string,
        workspaceId: string
    ) {
        const safeWorkspaceId = workspaceId || this.hashPath(workspaceRoot || 'unknown-workspace');
        this.rootDir = path.join(storageRoot, 'ai-assisted-tracking', 'workspaces', safeWorkspaceId);
        this.baselineIndexPath = path.join(this.rootDir, 'baselines', 'index.json');
        this.journalPath = path.join(this.rootDir, 'journal', 'journal.jsonl');
        fs.mkdirSync(path.dirname(this.baselineIndexPath), { recursive: true });
        fs.mkdirSync(path.dirname(this.journalPath), { recursive: true });
    }

    public toFileKey(absolutePath: string): string {
        const normalizedAbsolute = FileUtils.normalizePath(absolutePath);
        const relativePath = FileUtils.toWorkspaceRelativePath(normalizedAbsolute, this.workspaceRoot);

        if (relativePath !== null) {
            return relativePath;
        }

        return normalizedAbsolute;
    }

    public toSafeFileKey(fileKeyOrPath: string): string {
        return this.hashPath(FileUtils.normalizePath(fileKeyOrPath));
    }

    public async ensureSession(session: TrackingSessionDescriptor): Promise<void> {
        if (!session?.sessionId) {
            return;
        }

        const sessionPath = this.getSessionMetaPath(session.sessionId);
        const existing = AtomicFileWriter.readJsonSafe<any>(sessionPath, null);
        const now = new Date().toISOString();
        const next = {
            ...(existing || {}),
            sessionId: session.sessionId,
            sessionMode: session.sessionMode,
            projectType: session.projectType,
            scopeKey: session.scopeKey,
            taskName: session.taskName,
            status: existing?.status || 'active',
            startedAt: existing?.startedAt || session.startedAt || now,
            baselineFrozenAt: existing?.baselineFrozenAt || session.baselineFrozenAt || now,
            snapshotMode: 'rolling-baseline',
            updatedAt: now
        };

        await AtomicFileWriter.writeJson(sessionPath, next);
        await this.appendJournal('session-created-or-updated', next);
    }

    public async markSessionResolved(sessionId: string): Promise<void> {
        if (!sessionId) {
            return;
        }

        const sessionPath = this.getSessionMetaPath(sessionId);
        const existing = AtomicFileWriter.readJsonSafe<any>(sessionPath, null);
        if (!existing) {
            return;
        }

        const next = {
            ...existing,
            status: 'resolved',
            resolvedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        await AtomicFileWriter.writeJson(sessionPath, next);
        await this.appendJournal('session-resolved', { sessionId });
    }

    /**
     * Deletes the self-contained session folder after the session has been safely uploaded/resolved.
     * This removes session.json, changes metadata, before/after snapshots, and last-diverged snapshots
     * for the specific session only. Rolling baselines are intentionally kept at workspace level and
     * are cleaned separately by retention/TTL logic so other active sessions are not affected.
     */
    public async deleteSessionFolder(sessionId: string): Promise<void> {
        if (!sessionId) {
            return;
        }

        const sessionDir = this.getSessionDir(sessionId);
        try {
            await fs.promises.rm(sessionDir, { recursive: true, force: true });
            await this.appendJournal('session-folder-deleted', { sessionId, sessionDir });
        } catch (error) {
            await this.appendJournal('session-folder-delete-failed', {
                sessionId,
                sessionDir,
                error: error instanceof Error ? error.message : String(error)
            });
        }
    }

    public listTrackingSessions(): TrackingSessionInfo[] {
        const sessionsDir = path.join(this.rootDir, 'sessions');
        if (!fs.existsSync(sessionsDir)) {
            return [];
        }

        const sessions: TrackingSessionInfo[] = [];

        try {
            for (const entry of fs.readdirSync(sessionsDir, { withFileTypes: true })) {
                if (!entry.isDirectory()) {
                    continue;
                }

                const sessionDir = path.join(sessionsDir, entry.name);
                const session = AtomicFileWriter.readJsonSafe<any>(path.join(sessionDir, 'session.json'), null);
                if (!session?.sessionId) {
                    continue;
                }

                const changesDir = path.join(sessionDir, 'changes');
                let changeCount = 0;
                try {
                    changeCount = fs.existsSync(changesDir)
                        ? fs.readdirSync(changesDir).filter((name) => name.endsWith('.json')).length
                        : 0;
                } catch {
                    changeCount = 0;
                }

                sessions.push({
                    sessionId: String(session.sessionId || ''),
                    sessionMode: session.sessionMode,
                    projectType: session.projectType,
                    scopeKey: String(session.scopeKey || ''),
                    taskName: session.taskName,
                    startedAt: session.startedAt,
                    baselineFrozenAt: session.baselineFrozenAt,
                    status: session.status,
                    sessionDir,
                    hasChanges: changeCount > 0,
                    changeCount,
                    updatedAt: session.updatedAt,
                    updatedAtMs: Date.parse(session.updatedAt || session.startedAt || '') || 0
                });
            }
        } catch {
            return [];
        }

        return sessions;
    }

    public findActiveSessionByScope(
        projectType: TrackingProjectType,
        sessionMode: TrackingSessionMode,
        scopeKey: string,
        preferredSessionId?: string
    ): TrackingSessionInfo | null {
        const normalizedScopeKey = String(scopeKey || '').trim();
        const candidates = this.listTrackingSessions()
            .filter((session) =>
                session.projectType === projectType
                && session.sessionMode === sessionMode
                && String(session.scopeKey || '').trim() === normalizedScopeKey
                && session.status !== 'resolved'
            )
            .sort((a, b) => {
                const aPreferred = preferredSessionId && a.sessionId === preferredSessionId ? 1 : 0;
                const bPreferred = preferredSessionId && b.sessionId === preferredSessionId ? 1 : 0;
                const aHasChanges = a.hasChanges ? 1 : 0;
                const bHasChanges = b.hasChanges ? 1 : 0;

                // Restart case: prefer the older active disk session that already has snapshots.
                if (aHasChanges !== bHasChanges) {
                    return bHasChanges - aHasChanges;
                }

                if (aPreferred !== bPreferred) {
                    return bPreferred - aPreferred;
                }

                if (a.changeCount !== b.changeCount) {
                    return b.changeCount - a.changeCount;
                }

                return b.updatedAtMs - a.updatedAtMs;
            });

        return candidates[0] || null;
    }

    public listSessionTextSnapshots(sessionId: string): SessionTextSnapshot[] {
        if (!sessionId) {
            return [];
        }

        const changesDir = path.join(this.getSessionDir(sessionId), 'changes');
        if (!fs.existsSync(changesDir)) {
            return [];
        }

        const snapshots: SessionTextSnapshot[] = [];

        try {
            for (const entry of fs.readdirSync(changesDir, { withFileTypes: true })) {
                if (!entry.isFile() || !entry.name.endsWith('.json')) {
                    continue;
                }

                const meta = AtomicFileWriter.readJsonSafe<SessionTextSnapshotMetadata | null>(path.join(changesDir, entry.name), null);
                if (!meta) {
                    continue;
                }

                const snapshot = this.getSessionTextSnapshot(sessionId, meta.fileKey || meta.filePath);
                if (snapshot) {
                    snapshots.push(snapshot);
                }
            }
        } catch {
            return snapshots;
        }

        return snapshots.sort((a, b) => {
            const aTime = Date.parse(a.updatedAt || a.createdAt || '') || 0;
            const bTime = Date.parse(b.updatedAt || b.createdAt || '') || 0;
            return aTime - bTime;
        });
    }

    public async cleanupJournalIfSafe(activeSessionIds: Iterable<string> = []): Promise<boolean> {
        const activeIds = new Set<string>(Array.from(activeSessionIds || []).filter(Boolean));
        if (activeIds.size > 0 || this.hasActiveSessionsOnDisk()) {
            return false;
        }

        const journalDir = path.dirname(this.journalPath);
        if (!fs.existsSync(journalDir)) {
            return false;
        }

        try {
            await fs.promises.rm(journalDir, { recursive: true, force: true });
            return true;
        } catch {
            return false;
        }
    }

    public async cleanupResolvedSessionFolders(): Promise<number> {
        const sessionsDir = path.join(this.rootDir, 'sessions');
        if (!fs.existsSync(sessionsDir)) {
            return 0;
        }

        let deletedCount = 0;

        try {
            for (const entry of fs.readdirSync(sessionsDir, { withFileTypes: true })) {
                if (!entry.isDirectory()) {
                    continue;
                }

                const sessionDir = path.join(sessionsDir, entry.name);
                const session = AtomicFileWriter.readJsonSafe<any>(path.join(sessionDir, 'session.json'), null);

                if (!session || session.status !== 'resolved') {
                    continue;
                }

                await fs.promises.rm(sessionDir, { recursive: true, force: true });
                deletedCount++;
            }

            if (deletedCount > 0) {
                await this.appendJournal('resolved-session-folders-cleaned', { deletedCount });
            }

            this.removeDirectoryIfEmpty(sessionsDir);
        } catch (error) {
            await this.appendJournal('resolved-session-folder-cleanup-failed', {
                error: error instanceof Error ? error.message : String(error)
            });
        }

        return deletedCount;
    }

    public async updateRollingBaselineFromFile(absolutePath: string): Promise<RollingBaselineMetadata | null> {
        if (!fs.existsSync(absolutePath)) {
            return null;
        }

        const content = await fs.promises.readFile(FileUtils.normalizePath(absolutePath), 'utf8');
        return this.updateRollingBaseline(absolutePath, content.replace(/\r\n/g, '\n'));
    }

    public async updateRollingBaseline(absolutePath: string, content: string): Promise<RollingBaselineMetadata> {
        const filePath = FileUtils.normalizePath(absolutePath);
        const fileKey = this.toFileKey(filePath);
        const safeFileKey = this.toSafeFileKey(fileKey);
        const contentPath = this.getBaselineContentPath(safeFileKey);
        const metaPath = this.getBaselineMetaPath(safeFileKey);
        const hashes = ChangeHashUtil.createTextHashes(content || '');
        let stat: fs.Stats | null = null;

        try {
            stat = fs.existsSync(filePath) ? fs.statSync(filePath) : null;
        } catch {
            stat = null;
        }

        const meta: RollingBaselineMetadata = {
            filePath,
            fileKey,
            safeFileKey,
            updatedAt: new Date().toISOString(),
            baselineContentPath: contentPath,
            rawHash: hashes.rawHash,
            normalizedHash: hashes.normalizedHash,
            size: stat?.size ?? Buffer.byteLength(content || '', 'utf8'),
            mtimeMs: stat?.mtimeMs ?? Date.now()
        };

        await AtomicFileWriter.writeText(contentPath, content || '');
        await AtomicFileWriter.writeJson(metaPath, meta);
        await this.updateBaselineIndex(fileKey, meta);
        await this.appendJournal('baseline-updated', { fileKey, filePath, rawHash: meta.rawHash, normalizedHash: meta.normalizedHash });
        return meta;
    }

    public getRollingBaseline(absolutePath: string): { meta: RollingBaselineMetadata; content: string } | null {
        const fileKey = this.toFileKey(absolutePath);
        const safeFileKey = this.toSafeFileKey(fileKey);
        const meta = AtomicFileWriter.readJsonSafe<RollingBaselineMetadata | null>(this.getBaselineMetaPath(safeFileKey), null);

        if (!meta?.baselineContentPath) {
            return null;
        }

        const content = AtomicFileWriter.readTextSafe(meta.baselineContentPath, '');
        return { meta, content };
    }

    public async recordSessionTextChange(
        session: TrackingSessionDescriptor,
        absolutePath: string,
        action: FileAction,
        afterContent: string,
        fallbackBeforeContent?: string
    ): Promise<SessionTextSnapshot> {
        await this.ensureSession(session);

        const filePath = FileUtils.normalizePath(absolutePath);
        const fileKey = this.toFileKey(filePath);
        const safeFileKey = this.toSafeFileKey(fileKey);
        const snapshotDir = this.getSessionSnapshotDir(session.sessionId, safeFileKey);
        const beforePath = path.join(snapshotDir, 'before.content');
        const afterPath = path.join(snapshotDir, 'after.content');
        const lastDivergedPath = path.join(snapshotDir, 'last-diverged.content');
        const changePath = this.getSessionChangeMetaPath(session.sessionId, safeFileKey);
        const existing = AtomicFileWriter.readJsonSafe<SessionTextSnapshotMetadata | null>(changePath, null);

        let beforeContent = '';
        let snapshotBeforeUnavailable = false;

        if (existing?.snapshotBeforePath && fs.existsSync(existing.snapshotBeforePath)) {
            beforeContent = AtomicFileWriter.readTextSafe(existing.snapshotBeforePath, '');
        } else {
            const baseline = this.getRollingBaseline(filePath);
            if (baseline) {
                beforeContent = baseline.content;
            } else if (typeof fallbackBeforeContent === 'string') {
                beforeContent = fallbackBeforeContent;
            } else {
                // beforeContent = afterContent || '';
                beforeContent = '';
                snapshotBeforeUnavailable = true;
            }

            await AtomicFileWriter.writeText(beforePath, beforeContent);
            await this.appendJournal('snapshot-before-created', {
                sessionId: session.sessionId,
                fileKey,
                source: this.getRollingBaseline(filePath) ? 'rolling-baseline' : 'fallback'
            });
        }

        const normalizedAfterContent = action === 'deleted' ? '' : (afterContent || '');
        await AtomicFileWriter.writeText(afterPath, normalizedAfterContent);

        const beforeHashes = ChangeHashUtil.createTextHashes(beforeContent || '');
        const afterHashes = ChangeHashUtil.createTextHashes(normalizedAfterContent || '');
        let lastDivergedContent: string | null = existing?.lastDivergedSnapshotPath
            ? AtomicFileWriter.readTextSafe(existing.lastDivergedSnapshotPath, '')
            : null;
        let rawLastDivergedHash = existing?.rawLastDivergedHash;
        let normalizedLastDivergedHash = existing?.normalizedLastDivergedHash;

        if (beforeHashes.normalizedHash !== afterHashes.normalizedHash) {
            lastDivergedContent = normalizedAfterContent;
            const lastHashes = ChangeHashUtil.createTextHashes(lastDivergedContent || '');
            rawLastDivergedHash = lastHashes.rawHash;
            normalizedLastDivergedHash = lastHashes.normalizedHash;
            await AtomicFileWriter.writeText(lastDivergedPath, lastDivergedContent || '');
            await this.appendJournal('last-diverged-updated', { sessionId: session.sessionId, fileKey });
        }

        const hasLastDiverged = typeof lastDivergedContent === 'string'
            && lastDivergedContent.length > 0
            && normalizedLastDivergedHash !== beforeHashes.normalizedHash;
        const changeType = ChangeHashUtil.getChangeType(
            beforeContent || '',
            normalizedAfterContent || '',
            hasLastDiverged ? lastDivergedContent : null
        );
        const now = new Date().toISOString();
        const meta: SessionTextSnapshotMetadata = {
            changeId: existing?.changeId || crypto.randomUUID(),
            sessionId: session.sessionId,
            sessionMode: session.sessionMode,
            projectType: session.projectType,
            scopeKey: session.scopeKey,
            taskName: session.taskName,
            filePath,
            fileKey,
            safeFileKey,
            eventType: action,
            snapshotBeforePath: beforePath,
            snapshotAfterPath: afterPath,
            lastDivergedSnapshotPath: fs.existsSync(lastDivergedPath) ? lastDivergedPath : null,
            rawBeforeHash: beforeHashes.rawHash,
            rawAfterHash: afterHashes.rawHash,
            rawLastDivergedHash,
            normalizedBeforeHash: beforeHashes.normalizedHash,
            normalizedAfterHash: afterHashes.normalizedHash,
            normalizedLastDivergedHash,
            changeType,
            snapshotBeforeUnavailable: existing?.snapshotBeforeUnavailable || snapshotBeforeUnavailable,
            createdAt: existing?.createdAt || now,
            updatedAt: now
        };

        await AtomicFileWriter.writeJson(changePath, meta);
        await this.appendJournal('snapshot-after-updated', {
            sessionId: session.sessionId,
            fileKey,
            changeType
        });

        return {
            ...meta,
            beforeContent,
            afterContent: normalizedAfterContent,
            lastDivergedContent: hasLastDiverged ? lastDivergedContent : null
        };
    }

    public getSessionTextSnapshot(sessionId: string, absoluteOrFileKey: string): SessionTextSnapshot | null {
        const fileKey = path.isAbsolute(absoluteOrFileKey)
            ? this.toFileKey(absoluteOrFileKey)
            : FileUtils.normalizePath(absoluteOrFileKey);
        const safeFileKey = this.toSafeFileKey(fileKey);
        const meta = AtomicFileWriter.readJsonSafe<SessionTextSnapshotMetadata | null>(this.getSessionChangeMetaPath(sessionId, safeFileKey), null);

        if (!meta) {
            return null;
        }

        return {
            ...meta,
            beforeContent: AtomicFileWriter.readTextSafe(meta.snapshotBeforePath, ''),
            afterContent: AtomicFileWriter.readTextSafe(meta.snapshotAfterPath, ''),
            lastDivergedContent: meta.lastDivergedSnapshotPath
                ? AtomicFileWriter.readTextSafe(meta.lastDivergedSnapshotPath, '')
                : null
        };
    }

    public async cleanupRollingBaselines(options: BaselineCleanupOptions = {}): Promise<BaselineCleanupResult> {
        const skipWhenActiveSessions = options.skipWhenActiveSessions !== false;
        const activeSessionIds = new Set<string>(Array.from(options.activeSessionIds || []).filter(Boolean));

        if (!options.force && skipWhenActiveSessions && (activeSessionIds.size > 0 || this.hasActiveSessionsOnDisk())) {
            await this.appendJournal('baseline-cleanup-skipped', { reason: 'active-sessions-present' });
            return {
                skipped: true,
                reason: 'active-sessions-present',
                deletedCount: 0,
                deletedBytes: 0,
                ...this.calculateBaselineIndexTotals()
            };
        }

        const retentionMs = options.retentionMs ?? DiskBackedTrackingStore.DEFAULT_BASELINE_RETENTION_MS;
        const maxStorageBytes = options.maxStorageBytes ?? DiskBackedTrackingStore.DEFAULT_MAX_BASELINE_STORAGE_BYTES;
        const maxBaselineFiles = options.maxBaselineFiles ?? DiskBackedTrackingStore.DEFAULT_MAX_BASELINE_FILES;
        const cutoffMs = Date.now() - retentionMs;
        const index = AtomicFileWriter.readJsonSafe<Record<string, RollingBaselineMetadata>>(this.baselineIndexPath, {});
        const referencedSafeFileKeys = this.collectReferencedBaselineSafeKeys();
        let deletedCount = 0;
        let deletedBytes = 0;

        const entries = Object.entries(index)
            .filter(([, meta]) => !!meta?.safeFileKey)
            .map(([fileKey, meta]) => ({
                fileKey,
                meta,
                updatedAtMs: Date.parse(meta.updatedAt || '') || 0,
                bytes: this.getBaselineEntrySize(meta)
            }));

        for (const entry of entries) {
            if (referencedSafeFileKeys.has(entry.meta.safeFileKey)) {
                continue;
            }

            const fileMissing = !!entry.meta.filePath && !fs.existsSync(entry.meta.filePath);
            const ignored = !!entry.meta.filePath && FileUtils.shouldIgnore(entry.meta.filePath);
            const outsideWorkspace = !!entry.meta.filePath
                && !!this.workspaceRoot
                && !FileUtils.isFileInsideWorkspace(entry.meta.filePath, this.workspaceRoot);
            const contentMissing = !entry.meta.baselineContentPath || !fs.existsSync(entry.meta.baselineContentPath);
            const expired = entry.updatedAtMs > 0 && entry.updatedAtMs < cutoffMs;

            if (fileMissing || ignored || outsideWorkspace || contentMissing || expired) {
                const removed = await this.deleteBaselineEntry(entry.fileKey, entry.meta, index, 'ttl-or-invalid');
                if (removed.deleted) {
                    deletedCount += 1;
                    deletedBytes += removed.bytes;
                }
            }
        }

        let remaining = Object.entries(index)
            .filter(([, meta]) => !!meta?.safeFileKey && !referencedSafeFileKeys.has(meta.safeFileKey))
            .map(([fileKey, meta]) => ({
                fileKey,
                meta,
                updatedAtMs: Date.parse(meta.updatedAt || '') || 0,
                bytes: this.getBaselineEntrySize(meta)
            }))
            .sort((a, b) => a.updatedAtMs - b.updatedAtMs);

        let totals = this.calculateBaselineIndexTotals(index);
        for (const entry of remaining) {
            if (totals.remainingBytes <= maxStorageBytes && totals.remainingCount <= maxBaselineFiles) {
                break;
            }

            const removed = await this.deleteBaselineEntry(entry.fileKey, entry.meta, index, 'size-limit');
            if (removed.deleted) {
                deletedCount += 1;
                deletedBytes += removed.bytes;
                totals = this.calculateBaselineIndexTotals(index);
            }
        }

        await AtomicFileWriter.writeJson(this.baselineIndexPath, index);
        totals = this.calculateBaselineIndexTotals(index);
        await this.appendJournal('baseline-cleanup-completed', {
            deletedCount,
            deletedBytes,
            remainingCount: totals.remainingCount,
            remainingBytes: totals.remainingBytes,
            retentionMs,
            maxStorageBytes,
            maxBaselineFiles
        });

        return {
            skipped: false,
            deletedCount,
            deletedBytes,
            remainingCount: totals.remainingCount,
            remainingBytes: totals.remainingBytes
        };
    }

    private hasActiveSessionsOnDisk(): boolean {
        const sessionsDir = path.join(this.rootDir, 'sessions');
        if (!fs.existsSync(sessionsDir)) {
            return false;
        }

        try {
            for (const entry of fs.readdirSync(sessionsDir, { withFileTypes: true })) {
                if (!entry.isDirectory()) {
                    continue;
                }

                const sessionPath = path.join(sessionsDir, entry.name, 'session.json');
                const session = AtomicFileWriter.readJsonSafe<any>(sessionPath, null);
                if (session && session.status !== 'resolved') {
                    return true;
                }
            }
        } catch {
            return true;
        }

        return false;
    }

    private collectReferencedBaselineSafeKeys(): Set<string> {
        const refs = new Set<string>();
        const sessionsDir = path.join(this.rootDir, 'sessions');
        if (!fs.existsSync(sessionsDir)) {
            return refs;
        }

        try {
            for (const sessionEntry of fs.readdirSync(sessionsDir, { withFileTypes: true })) {
                if (!sessionEntry.isDirectory()) {
                    continue;
                }

                const sessionDir = path.join(sessionsDir, sessionEntry.name);
                const session = AtomicFileWriter.readJsonSafe<any>(path.join(sessionDir, 'session.json'), null);
                if (!session || session.status === 'resolved') {
                    continue;
                }

                const changesDir = path.join(sessionDir, 'changes');
                if (!fs.existsSync(changesDir)) {
                    continue;
                }

                for (const changeEntry of fs.readdirSync(changesDir, { withFileTypes: true })) {
                    if (!changeEntry.isFile() || !changeEntry.name.endsWith('.json')) {
                        continue;
                    }
                    const change = AtomicFileWriter.readJsonSafe<SessionTextSnapshotMetadata | null>(path.join(changesDir, changeEntry.name), null);
                    if (change?.safeFileKey) {
                        refs.add(change.safeFileKey);
                    }
                }
            }
        } catch {
            refs.add('__cleanup_reference_scan_failed__');
        }

        return refs;
    }

    private async deleteBaselineEntry(
        fileKey: string,
        meta: RollingBaselineMetadata,
        index: Record<string, RollingBaselineMetadata>,
        reason: string
    ): Promise<{ deleted: boolean; bytes: number }> {
        const bytes = this.getBaselineEntrySize(meta);
        const baselineDir = meta?.baselineContentPath
            ? path.dirname(meta.baselineContentPath)
            : path.join(this.rootDir, 'baselines', 'files', meta.safeFileKey || this.toSafeFileKey(fileKey));

        try {
            await fs.promises.rm(baselineDir, { recursive: true, force: true });
            delete index[fileKey];
            await this.appendJournal('baseline-deleted', {
                fileKey,
                safeFileKey: meta.safeFileKey,
                baselineDir,
                reason,
                bytes
            });
            return { deleted: true, bytes };
        } catch (error) {
            await this.appendJournal('baseline-delete-failed', {
                fileKey,
                safeFileKey: meta.safeFileKey,
                baselineDir,
                reason,
                error: error instanceof Error ? error.message : String(error)
            });
            return { deleted: false, bytes: 0 };
        }
    }

    private calculateBaselineIndexTotals(index?: Record<string, RollingBaselineMetadata>): { remainingCount: number; remainingBytes: number } {
        const source = index || AtomicFileWriter.readJsonSafe<Record<string, RollingBaselineMetadata>>(this.baselineIndexPath, {});
        const values = Object.values(source || {}).filter(Boolean);
        return {
            remainingCount: values.length,
            remainingBytes: values.reduce((sum, meta) => sum + this.getBaselineEntrySize(meta), 0)
        };
    }

    private getBaselineEntrySize(meta: RollingBaselineMetadata): number {
        let total = 0;
        for (const filePath of [meta?.baselineContentPath, this.getBaselineMetaPath(meta?.safeFileKey || '')]) {
            if (!filePath) {
                continue;
            }
            try {
                total += fs.existsSync(filePath) ? fs.statSync(filePath).size : 0;
            } catch { /* ignore */ }
        }
        return total;
    }

    private getBaselineContentPath(safeFileKey: string): string {
        return path.join(this.rootDir, 'baselines', 'files', safeFileKey, 'baseline.content');
    }

    private getBaselineMetaPath(safeFileKey: string): string {
        return path.join(this.rootDir, 'baselines', 'files', safeFileKey, 'baseline.meta.json');
    }

    private getSessionDir(sessionId: string): string {
        return path.join(this.rootDir, 'sessions', this.safeSegment(sessionId));
    }

    /** Failure errors captured AT FAILURE TIME: the previous-session
     *  window must show the last session's own data — report.html may already be deleted by the
     *  time the next build runs, so the errors are persisted with the session, not re-read from
     *  the report. */
    public saveSessionErrors(sessionId: string, errors: unknown[]): void {
        try {
            const dir = this.getSessionDir(sessionId);
            fs.mkdirSync(dir, { recursive: true });
            AtomicFileWriter.writeJson(path.join(dir, 'last-errors.json'), {
                savedAt: new Date().toISOString(),
                errors,
            });
        } catch { /* bookkeeping must never break a parse */ }
    }

    public loadSessionErrors(sessionId: string): any[] {
        try {
            const data = AtomicFileWriter.readJsonSafe<any>(
                path.join(this.getSessionDir(sessionId), 'last-errors.json'), null);
            return Array.isArray(data?.errors) ? data.errors : [];
        } catch {
            return [];
        }
    }

    private getSessionMetaPath(sessionId: string): string {
        return path.join(this.getSessionDir(sessionId), 'session.json');
    }

    private getSessionSnapshotDir(sessionId: string, safeFileKey: string): string {
        return path.join(this.getSessionDir(sessionId), 'snapshots', safeFileKey);
    }

    private getSessionChangeMetaPath(sessionId: string, safeFileKey: string): string {
        return path.join(this.getSessionDir(sessionId), 'changes', `${safeFileKey}.json`);
    }

    private async updateBaselineIndex(fileKey: string, meta: RollingBaselineMetadata): Promise<void> {
        const index = AtomicFileWriter.readJsonSafe<Record<string, RollingBaselineMetadata>>(this.baselineIndexPath, {});
        index[fileKey] = meta;
        await AtomicFileWriter.writeJson(this.baselineIndexPath, index);
    }

    private async appendJournal(event: string, payload: Record<string, unknown>): Promise<void> {
        // The journal folder may be cleaned after all sessions are complete.
        // Recreate it only when a future tracking operation actually needs to write again.
        fs.mkdirSync(path.dirname(this.journalPath), { recursive: true });
        await AtomicFileWriter.appendJsonLine(this.journalPath, {
            event,
            timestamp: new Date().toISOString(),
            ...payload
        });
    }

    private removeDirectoryIfEmpty(directoryPath: string): void {
        try {
            if (fs.existsSync(directoryPath) && fs.readdirSync(directoryPath).length === 0) {
                fs.rmdirSync(directoryPath);
            }
        } catch { /* ignore cleanup failure */ }
    }

    private hashPath(value: string): string {
        return crypto.createHash('sha1').update(FileUtils.normalizePath(value || '')).digest('hex');
    }

    private safeSegment(value: string): string {
        return String(value || 'unknown').replace(/[^a-zA-Z0-9_.-]/g, '_');
    }
}
