import * as crypto from 'crypto';
import { Logger } from '../utils/Logger';
import {
    BuildError,
    FileChangeRecord,
    FileKey,
    ResolvedTaskPackage,
    TaskFileLink,
    TaskFileLinkType,
    TaskTextChangeSnapshot,
    TaskKey,
    TaskSession,
    TaskSessionSnapshot,
    getTaskDisplayName,
    isErrorSeverity,
    isKnownNonErrorSeverity,
    normalizeSeverity,
    normalizeTaskKey
} from './TaskSessionTypes';
import { ChangeStore } from './ChangeStore';

export type ReconcileTaskErrorsOptions = {
    forceResolveAbsent?: boolean;
    resolveAllAbsent?: boolean;
    currentTaskStatuses?: Map<TaskKey, string>;
    requestedTaskKeys?: Set<TaskKey>;
    // Raw requestedTasks string of the CURRENT report. On a clean report a pending task resolves
    // only with SAME-TASK evidence: the task itself was requested (direct name or short name), or
    // this build re-ran the same launch command that failed it (requestedTasksAtFailure overlap).
    currentRequestedTasksRaw?: string;
};

export class TaskBasedErrorSessionManager {
    private readonly taskSessions = new Map<TaskKey, TaskSession>();
    private readonly taskFileMap = new Map<TaskKey, Map<FileKey, TaskFileLink>>();
    private static readonly RECENT_UPLOAD_TTL_MS = 2 * 60 * 1000;
    private readonly recentlyUploadedSessions = new Map<TaskKey, {
        task: TaskSession;
        uploadedAt: number;
    }>();

    constructor(private readonly changeStore: ChangeStore) { }

    public reconcileTaskErrors(
        currentTaskErrors: Map<TaskKey, BuildError[]>,
        options: ReconcileTaskErrorsOptions = {}
    ): ResolvedTaskPackage[] {
        const now = Date.now();
        this.cleanupRecentlyUploadedSessions(now);
        const normalizedCurrent = this.normalizeCurrentErrors(currentTaskErrors);
        const currentTaskKeys = new Set(normalizedCurrent.keys());
        const currentTaskStatuses = this.normalizeTaskStatuses(options.currentTaskStatuses);
        const currentRequestedTokens = this.tokenizeRequestedTasks(options.currentRequestedTasksRaw);
        const resolvedPackages: ResolvedTaskPackage[] = [];

        for (const [taskKey, session] of Array.from(this.taskSessions.entries())) {
            if (currentTaskKeys.has(taskKey)) {
                continue;
            }

            // Already resolved and queued for upload (its Review preview may be open right now).
            // Gradle 9.x writes the problems report several times per build, so a second
            // reconcile can arrive before the user confirms — re-emitting here opened DUPLICATE
            // preview panels for the same task. One resolution -> one package -> one preview;
            // the pending upload always ends in markTaskUploaded, which clears the session.
            if (session.status === 'resolved_pending_upload') {
                continue;
            }

            // Fail-safe: only severities POSITIVELY known as non-error (ADVICE/WARNING/INFO)
            // resolve a task. Anything else — including severities future Gradle versions may
            // introduce — keeps the session pending rather than falsely popping its preview.
            const currentSeverity = currentTaskStatuses.get(taskKey);
            const resolvedBySeverity = !!currentSeverity && isKnownNonErrorSeverity(currentSeverity);
            // SAME-TASK evidence only (GBE 9.5 field bug): a clean report resolves this session
            // only if the current build actually ran this task — it was requested by name/short
            // name, or the build re-ran the same launch command that failed it. A clean report
            // from a DIFFERENT task's build (Gradle 9.x rewrites the report per build) must keep
            // this session pending, never pop its confirm preview.
            const isRequestedTask = options.resolveAllAbsent
                || !!options.requestedTaskKeys?.has(taskKey)
                || this.taskMatchesRequested(taskKey, currentRequestedTokens)
                || this.requestedTasksOverlap(session.requestedTasksAtFailure, currentRequestedTokens);

            // SAME BUILD TYPE: a task that failed in one build type and passed in another must
            // not be considered resolved. For Gradle the build type IS the requested task, so the
            // launch command that failed this task must be the one that now reports it clean.
            //
            // Compared canonically - flags dropped, lowercased, leading colons stripped, order
            // ignored - because ':app:build' and 'app:build' are the same build type, and so is
            // the same pair of tasks named in the other order. Raw string equality made those read
            // as DIFFERENT, which would silently stop recording genuine fixes: a false block here
            // costs a real fix, which is worse than the mismatch being guarded against.
            const canonicalRequested = (raw?: string) => this.tokenizeRequestedTasks(raw)
                .map(token => this.canonicalTaskToken(token))
                .filter(token => token.length > 0)
                .sort()
                .join(' ');
            const previousTokens = canonicalRequested(session.requestedTasksAtFailure);
            const currentTokens = currentRequestedTokens
                .map(token => this.canonicalTaskToken(token))
                .filter(token => token.length > 0)
                .sort()
                .join(' ');
            // Fail-open when the failing build's launch command was never captured (TD5, or a
            // session started before this was recorded): behave exactly as before.
            const isSameBuildType = !session.requestedTasksAtFailure || (previousTokens === currentTokens);

            // The build-type condition gates BOTH routes to resolution. It previously sat only on
            // the forceResolveAbsent branch, so `resolvedBySeverity` walked straight past it - and
            // that is precisely the failure case: RMS fails under one requested task, the developer
            // runs a DIFFERENT task that also executes RMS, RMS reports a non-error severity there,
            // and the original failure was recorded as fixed by a build that never tested it.
            const shouldResolve = isSameBuildType
                && (resolvedBySeverity || (isRequestedTask && !!options.forceResolveAbsent));

            if (shouldResolve) {
                const fileLinks = this.taskFileMap.get(taskKey) || new Map<FileKey, TaskFileLink>();
                const files = this.changeStore.getMany(fileLinks.keys());
                const resolvedSession: TaskSession = {
                    ...session,
                    status: 'resolved_pending_upload',
                    lastSeenAt: now
                };
                this.taskSessions.set(taskKey, resolvedSession);
                const resolutionReason = resolvedBySeverity
                    ? 'severity_changed'
                    : (options.forceResolveAbsent ? 'all_clear' : 'not_seen_twice');

                resolvedPackages.push({
                    task: resolvedSession,
                    files,
                    fileLinks: Array.from(fileLinks.values()),
                    resolutionReason
                });

                this.logTaskSession('RESOLVED', taskKey, resolvedSession, {
                    reason: resolutionReason,
                    severity: currentSeverity || '',
                    linkedFiles: files.length,
                    errors: resolvedSession.errors.length
                });

                continue;
            }

            if (!isRequestedTask && !resolvedBySeverity) {
                const preservedSession: TaskSession = {
                    ...session,
                    lastSeenAt: now
                };

                this.taskSessions.set(taskKey, preservedSession);

                this.logTaskSession('TASK_REMOVED_FROM_REPORT', taskKey, preservedSession, {
                    requested: false,
                    errors: preservedSession.errors.length
                });

                continue;
            }

            const notSeenSession: TaskSession = {
                ...session,
                status: 'not_seen_once',
                notSeenCount: session.notSeenCount + 1,
                lastSeenAt: now
            };

            this.taskSessions.set(taskKey, notSeenSession);

            this.logTaskSession('NOT_SEEN_ONCE', taskKey, notSeenSession, {
                notSeenCount: notSeenSession.notSeenCount,
                errors: notSeenSession.errors.length
            });
        }

        for (const [taskKey, errors] of normalizedCurrent.entries()) {
            const existing = this.taskSessions.get(taskKey);
            const preparedErrors = this.uniqueErrors(errors, taskKey);

            if (preparedErrors.length === 0) {
                continue;
            }

            if (existing) {
                const updatedSession: TaskSession = {
                    ...existing,
                    status: 'active_failed',
                    errors: preparedErrors,
                    errorHistory: this.appendErrorHistory(existing.errorHistory, preparedErrors, now),
                    lastSeenAt: now,
                    notSeenCount: 0,
                    requestedTasksAtFailure: options.currentRequestedTasksRaw || existing.requestedTasksAtFailure
                };

                this.taskSessions.set(taskKey, updatedSession);

                this.logTaskSession('UPDATED', taskKey, updatedSession, {
                    currentErrors: preparedErrors.length,
                    totalErrors: updatedSession.errors.length,
                    history: updatedSession.errorHistory.length
                });
            } else {
                const revivedSession = this.takeRecentlyUploadedSession(taskKey, now);
                const newSession: TaskSession = revivedSession
                    ? {
                        ...revivedSession,
                        status: 'active_failed',
                        errors: preparedErrors,
                        errorHistory: this.appendErrorHistory(revivedSession.errorHistory, preparedErrors, now),
                        lastSeenAt: now,
                        notSeenCount: 0,
                        requestedTasksAtFailure: options.currentRequestedTasksRaw || revivedSession.requestedTasksAtFailure
                    }
                    : {
                        taskKey,
                        taskName: getTaskDisplayName(taskKey),
                        occurrenceId: this.createOccurrenceId(taskKey),
                        status: 'active_failed',
                        errors: preparedErrors,
                        errorHistory: [{ seenAt: now, errors: preparedErrors }],
                        firstSeenAt: now,
                        lastSeenAt: now,
                        notSeenCount: 0,
                        requestId: this.createRequestId(),
                        requestedTasksAtFailure: options.currentRequestedTasksRaw || undefined
                    };

                this.taskSessions.set(taskKey, newSession);

                this.logTaskSession(revivedSession ? 'REVIVED' : 'CREATED', taskKey, newSession, {
                    errors: preparedErrors.length,
                    history: newSession.errorHistory.length
                });
            }

            if (!this.taskFileMap.has(taskKey)) {
                this.taskFileMap.set(taskKey, new Map<FileKey, TaskFileLink>());
            }
        }

        return resolvedPackages;
    }

    /** 'clean :app:compileJava --info' -> ['clean', ':app:compileJava'] (flags dropped). */
    private tokenizeRequestedTasks(raw?: string): string[] {
        return String(raw || '')
            .trim()
            .split(/\s+/)
            .map(token => token.trim())
            .filter(token => token.length > 0 && !token.startsWith('-'));
    }

    /** Leading-colon-insensitive, lowercased comparison form of a task token/key. */
    private canonicalTaskToken(value: string): string {
        return String(value || '').trim().toLowerCase().replace(/^:+/, '');
    }

    /** Was THIS task requested in the current build? Exact key or Gradle short name
     *  (requested 'compileJava' runs ':app:compileJava'). */
    private taskMatchesRequested(taskKey: TaskKey, requestedTokens: string[]): boolean {
        const key = this.canonicalTaskToken(taskKey);
        if (!key) { return false; }
        for (const token of requestedTokens) {
            const requested = this.canonicalTaskToken(token);
            if (!requested) { continue; }
            if (key === requested || key.endsWith(':' + requested)) { return true; }
        }
        return false;
    }

    /** Did the current build re-run the same launch command that failed this task (e.g. failed
     *  via 'build', re-ran 'build')? Any shared requested-task token counts. */
    private requestedTasksOverlap(requestedAtFailure: string | undefined, currentTokens: string[]): boolean {
        if (!requestedAtFailure || currentTokens.length === 0) { return false; }
        const current = new Set(currentTokens.map(token => this.canonicalTaskToken(token)));
        return this.tokenizeRequestedTasks(requestedAtFailure)
            .some(token => current.has(this.canonicalTaskToken(token)));
    }

    public recordFileChange(record: FileChangeRecord, absoluteOrRelativePath: string = ''): void {
        if (!this.hasActiveTasks() || !record?.fileKey) {
            return;
        }

        const activeTaskKeys = this.getEligibleActiveFailedTaskKeys(record.lastChangedAt);

        if (activeTaskKeys.length === 0) {
            return;
        }

        const directMatches = activeTaskKeys.filter((taskKey) => {
            return this.taskFileMap.get(normalizeTaskKey(taskKey))?.get(record.fileKey)?.linkType === 'direct';
        });

        for (const taskKey of directMatches) {
            this.linkFileToTask(taskKey, record, 'direct');
        }

        const sourcePath = absoluteOrRelativePath || record.fileKey;
        const linkType: TaskFileLinkType = this.isSharedFile(sourcePath) ? 'shared' : 'inferred';

        for (const taskKey of activeTaskKeys) {
            if (directMatches.includes(taskKey)) {
                continue;
            }
            this.linkFileToTask(taskKey, record, linkType);
        }
    }

    public markTaskUploaded(taskKey: TaskKey, uploadedChanges = 0): void {
        const normalizedTaskKey = normalizeTaskKey(taskKey);
        const session = this.taskSessions.get(normalizedTaskKey);
        const fileCount = this.taskFileMap.get(normalizedTaskKey)?.size || 0;

        this.logTaskSession('UPLOADED', normalizedTaskKey, session, {
            linkedFiles: fileCount,
            uploadedChanges
        });

        if (session) {
            this.recentlyUploadedSessions.set(normalizedTaskKey, {
                task: {
                    ...session,
                    status: 'uploaded'
                },
                uploadedAt: Date.now()
            });
        }

        this.taskSessions.delete(normalizedTaskKey);
        this.taskFileMap.delete(normalizedTaskKey);

        const stillReferencedFiles = this.getAllReferencedFileKeys();
        this.changeStore.resetBaseline(stillReferencedFiles);
        this.changeStore.deleteUnreferenced(stillReferencedFiles);
    }

    public markTaskUploadFailed(taskKey: TaskKey, task: TaskSession, files: FileKey[]): void {
        const normalizedTaskKey = normalizeTaskKey(taskKey);

        this.taskSessions.set(normalizedTaskKey, {
            ...task,
            status: 'not_seen_once'
        });

        const fileMap = this.taskFileMap.get(normalizedTaskKey) || new Map<FileKey, TaskFileLink>();

        for (const fileKey of files) {
            const existing = fileMap.get(fileKey);
            fileMap.set(fileKey, {
                fileKey,
                linkType: existing?.linkType || 'inferred',
                linkedAt: existing?.linkedAt || Date.now(),
                lastChangedAt: existing?.lastChangedAt || Date.now(),
                activityCount: existing?.activityCount || 1,
                fileKind: existing?.fileKind,
                initialTextContent: existing?.initialTextContent,
                initialBinaryHash: existing?.initialBinaryHash,
                latestTextBeforeContent: existing?.latestTextBeforeContent,
                latestTextAfterContent: existing?.latestTextAfterContent,
                latestAction: existing?.latestAction,
                textChangeTrail: existing?.textChangeTrail,
                snapshotBeforePath: existing?.snapshotBeforePath,
                snapshotAfterPath: existing?.snapshotAfterPath,
                lastDivergedSnapshotPath: existing?.lastDivergedSnapshotPath,
                changeType: existing?.changeType
            });
        }

        this.taskFileMap.set(normalizedTaskKey, fileMap);
        this.logTaskSession('UPLOAD_FAILED_RESTORED', normalizedTaskKey, task, { files: fileMap.size });
    }

    public hasActiveTasks(): boolean {
        return this.taskSessions.size > 0;
    }

    public getActiveTaskKeys(): TaskKey[] {
        return Array.from(this.taskSessions.keys());
    }

    public getActiveSessions(): TaskSession[] {
        return Array.from(this.taskSessions.values());
    }

    public getFilesForTask(taskKey: TaskKey): FileKey[] {
        return Array.from(this.taskFileMap.get(normalizeTaskKey(taskKey))?.keys() || []);
    }

    public getSnapshot(): TaskSessionSnapshot {
        const taskFileMap: Record<string, string[]> = {};
        const taskFileLinks: Record<string, TaskFileLink[]> = {};

        for (const [taskKey, files] of this.taskFileMap.entries()) {
            taskFileMap[taskKey] = Array.from(files.keys());
            taskFileLinks[taskKey] = Array.from(files.values());
        }

        return {
            activeTasks: this.getActiveSessions(),
            taskFileMap,
            taskFileLinks,
            changedFiles: this.changeStore.getAll()
        };
    }

    public clear(): void {
        this.taskSessions.clear();
        this.taskFileMap.clear();
        this.recentlyUploadedSessions.clear();
        this.changeStore.clear();
    }

    public logActiveTaskSummary(context: string = ''): void {
        const sessions = this.getActiveSessions();
        const suffix = context ? ` ${context}` : '';

        Logger.log(`[TaskSession] ACTIVE_SUMMARY${suffix}: ${sessions.length} active task session(s)`);

        for (const session of sessions) {
            const files = this.taskFileMap.get(session.taskKey)?.size || 0;
            Logger.log(
                `[TaskSession]   task=${session.taskKey}, session=${session.occurrenceId}, ` +
                `status=${session.status}, errors=${session.errors.length}, linkedFiles=${files}`
            );
        }
    }

    private normalizeCurrentErrors(currentTaskErrors: Map<TaskKey, BuildError[]>): Map<TaskKey, BuildError[]> {
        const normalized = new Map<TaskKey, BuildError[]>();

        for (const [rawTaskKey, errors] of currentTaskErrors.entries()) {
            const taskKey = normalizeTaskKey(rawTaskKey);
            const preparedErrors = this.uniqueErrors(
                (errors || [])
                    .filter((error) => isErrorSeverity(error.severity || 'ERROR'))
                    .map((error) => ({
                        ...error,
                        severity: normalizeSeverity(error.severity || 'ERROR'),
                        taskPath: taskKey
                    })),
                taskKey
            );

            if (preparedErrors.length > 0) {
                normalized.set(taskKey, preparedErrors);
            }
        }

        return normalized;
    }

    private normalizeTaskStatuses(statuses?: Map<TaskKey, string>): Map<TaskKey, string> {
        const normalized = new Map<TaskKey, string>();

        if (!statuses) {
            return normalized;
        }

        for (const [rawTaskKey, rawSeverity] of statuses.entries()) {
            const taskKey = normalizeTaskKey(rawTaskKey);
            const severity = normalizeSeverity(rawSeverity);

            if (taskKey && severity) {
                normalized.set(taskKey, severity);
            }
        }

        return normalized;
    }

    private mergeErrors(existing: BuildError[], incoming: BuildError[]): BuildError[] {
        return this.uniqueErrors([...(existing || []), ...(incoming || [])]);
    }

    private appendErrorHistory(
        existingHistory: TaskSession['errorHistory'],
        incomingErrors: BuildError[],
        seenAt: number
    ): TaskSession['errorHistory'] {
        const normalizedErrors = this.uniqueErrors(incomingErrors);

        if (normalizedErrors.length === 0) {
            return existingHistory || [];
        }

        const latest = existingHistory?.[existingHistory.length - 1];

        if (latest && this.areSameErrorSet(latest.errors, normalizedErrors)) {
            return existingHistory;
        }

        return [
            ...(existingHistory || []),
            {
                seenAt,
                errors: normalizedErrors
            }
        ];
    }

    private uniqueErrors(errors: BuildError[], fallbackTaskKey?: string): BuildError[] {
        const unique = new Map<string, BuildError>();

        for (const error of errors || []) {
            const message = String(error.message || '').trim();
            if (!message) { continue; }

            const taskKey = normalizeTaskKey(error.taskPath || fallbackTaskKey, error.taskName || error.requestedTask);
            const normalizedError: BuildError = {
                ...error,
                message,
                severity: normalizeSeverity(error.severity || 'ERROR'),
                taskPath: taskKey
            };

            const key = [
                taskKey,
                String(error.path || '').replace(/\\/g, '/').trim(),
                message.replace(/\s+/g, ' ').trim().toLowerCase()
            ].join('|');

            if (!unique.has(key)) {
                unique.set(key, normalizedError);
            }
        }

        return Array.from(unique.values());
    }

    private getEligibleActiveFailedTaskKeys(changedAt: number): TaskKey[] {
        return Array.from(this.taskSessions.values())
            .filter((session) => (
                (session.status === 'active_failed' || session.status === 'not_seen_once')
                && session.firstSeenAt <= changedAt
            ))
            .map((session) => session.taskKey);
    }

    private linkFileToTask(taskKey: TaskKey, record: FileChangeRecord, linkType: TaskFileLinkType): void {
        const normalizedTaskKey = normalizeTaskKey(taskKey);
        const fileMap = this.taskFileMap.get(normalizedTaskKey) || new Map<FileKey, TaskFileLink>();
        const existing = fileMap.get(record.fileKey);
        const mergedLinkType = this.mergeLinkType(existing?.linkType, linkType);
        const nextTrail = record.kind === 'text'
            ? this.appendTextChangeTrail(existing?.textChangeTrail, {
                changedAt: record.lastChangedAt,
                action: record.action,
                // Keep task links metadata-light when disk snapshots exist.
                beforeContent: record.snapshotBeforePath ? '' : record.latestBeforeContent,
                afterContent: record.snapshotAfterPath ? '' : record.latestAfterContent,
                snapshotBeforePath: record.snapshotBeforePath,
                snapshotAfterPath: record.snapshotAfterPath,
                lastDivergedSnapshotPath: record.lastDivergedSnapshotPath,
                changeType: record.changeType
            })
            : existing?.textChangeTrail;

        fileMap.set(record.fileKey, {
            fileKey: record.fileKey,
            linkType: mergedLinkType,
            linkedAt: existing?.linkedAt || Date.now(),
            lastChangedAt: record.lastChangedAt,
            activityCount: (existing?.activityCount || 0) + 1,
            fileKind: existing?.fileKind || record.kind,
            initialTextContent: existing?.initialTextContent ?? (record.kind === 'text' && !record.snapshotBeforePath ? record.latestBeforeContent : undefined),
            initialBinaryHash: existing?.initialBinaryHash ?? (record.kind === 'binary' ? record.beforeHash : undefined),
            latestTextBeforeContent: record.kind === 'text' && !record.snapshotBeforePath ? record.latestBeforeContent : existing?.latestTextBeforeContent,
            latestTextAfterContent: record.kind === 'text' && !record.snapshotAfterPath ? record.latestAfterContent : existing?.latestTextAfterContent,
            latestAction: record.kind === 'text' ? record.action : existing?.latestAction,
            textChangeTrail: nextTrail,
            snapshotBeforePath: record.kind === 'text' ? record.snapshotBeforePath : existing?.snapshotBeforePath,
            snapshotAfterPath: record.kind === 'text' ? record.snapshotAfterPath : existing?.snapshotAfterPath,
            lastDivergedSnapshotPath: record.kind === 'text' ? record.lastDivergedSnapshotPath : existing?.lastDivergedSnapshotPath,
            changeType: record.kind === 'text' ? record.changeType : existing?.changeType
        });

        this.taskFileMap.set(normalizedTaskKey, fileMap);

        return;
    }

    private isSharedFile(filePath: string): boolean {
        const normalizedPath = String(filePath || '').replace(/\\/g, '/').toLowerCase();
        const fileName = normalizedPath.split('/').pop() || '';

        return (
            fileName === 'build.gradle' ||
            fileName === 'build.gradle.kts' ||
            fileName === 'settings.gradle' ||
            fileName === 'settings.gradle.kts' ||
            fileName.includes('common') ||
            normalizedPath.includes('/config/') ||
            normalizedPath.includes('/shared/')
        );
    }

    private getAllReferencedFileKeys(): Set<FileKey> {
        const result = new Set<FileKey>();

        for (const fileMap of this.taskFileMap.values()) {
            for (const fileKey of fileMap.keys()) {
                result.add(fileKey);
            }
        }

        return result;
    }

    private appendTextChangeTrail(
        existingTrail: TaskTextChangeSnapshot[] | undefined,
        nextSnapshot: TaskTextChangeSnapshot
    ): TaskTextChangeSnapshot[] {
        const trail = Array.isArray(existingTrail) ? [...existingTrail] : [];
        const previous = trail[trail.length - 1];

        if (
            previous
            && previous.changedAt === nextSnapshot.changedAt
            && previous.action === nextSnapshot.action
            && previous.beforeContent === nextSnapshot.beforeContent
            && previous.afterContent === nextSnapshot.afterContent
            && previous.snapshotBeforePath === nextSnapshot.snapshotBeforePath
            && previous.snapshotAfterPath === nextSnapshot.snapshotAfterPath
        ) {
            return trail;
        }

        trail.push(nextSnapshot);

        if (trail.length > 20) {
            return trail.slice(-20);
        }

        return trail;
    }

    private mergeLinkType(existing: TaskFileLinkType | undefined, incoming: TaskFileLinkType): TaskFileLinkType {
        if (existing === 'direct' || incoming === 'direct') {
            return 'direct';
        }

        if (existing === 'shared' || incoming === 'shared') {
            return 'shared';
        }

        return existing || incoming;
    }

    private takeRecentlyUploadedSession(taskKey: TaskKey, now: number): TaskSession | undefined {
        const normalizedTaskKey = normalizeTaskKey(taskKey);
        const uploaded = this.recentlyUploadedSessions.get(normalizedTaskKey);

        if (!uploaded) {
            return undefined;
        }

        if ((now - uploaded.uploadedAt) > TaskBasedErrorSessionManager.RECENT_UPLOAD_TTL_MS) {
            this.recentlyUploadedSessions.delete(normalizedTaskKey);
            return undefined;
        }

        this.recentlyUploadedSessions.delete(normalizedTaskKey);
        return uploaded.task;
    }

    private cleanupRecentlyUploadedSessions(now: number): void {
        for (const [taskKey, uploaded] of this.recentlyUploadedSessions.entries()) {
            if ((now - uploaded.uploadedAt) > TaskBasedErrorSessionManager.RECENT_UPLOAD_TTL_MS) {
                this.recentlyUploadedSessions.delete(taskKey);
            }
        }
    }

    private areSameErrorSet(left: BuildError[], right: BuildError[]): boolean {
        const normalize = (errors: BuildError[]) =>
            (errors || [])
                .map((error) => `${normalizeTaskKey(error.taskPath, error.taskName)}|${String(error.message || '').trim().replace(/\s+/g, ' ').toLowerCase()}`)
                .sort()
                .join('\n');

        return normalize(left) === normalize(right);
    }

    private logTaskSession(action: string, taskKey: TaskKey, session?: Partial<TaskSession>, extra: Record<string, unknown> = {}): void {
        const safeTaskKey = normalizeTaskKey(taskKey);
        const sessionId = String(session?.occurrenceId || 'unknown');
        const status = String(session?.status || 'unknown');

        const extraText = Object.entries(extra)
            .filter(([, value]) => value !== undefined && value !== null && value !== '')
            .map(([key, value]) => `${key}=${value}`).join(', ');

        if (action === 'CREATED' || action === 'REVIVED') {
            Logger.debug('---------------------------------------------------------------');
        } else if (action === 'RESOLVED') {
            Logger.debug('===============================================================');
        }

        Logger.debug(
            `[TaskSession] ${action} task=${safeTaskKey}, session=${sessionId}, status=${status}${extraText ? `, ${extraText}` : ''}`
        );
    }

    private createRequestId(length = 6): string {
        return Math.random().toString(36).slice(2, 2 + length);
    }

    private createOccurrenceId(taskKey: TaskKey): string {
        return `${normalizeTaskKey(taskKey)}#${this.createRequestId()}`;
    }
}
