import * as vscode from 'vscode';
import { Logger } from '../utils/Logger';
import { ApiService } from '../services/api.service';
import { collectUsageSignals } from './UsageSignals';

/**
 * Tells the server this installation exists.
 *
 * Adoption is otherwise counted only when a build completes, which leaves the most useful
 * rollout case invisible: somebody installs the extension and never builds with it. Those are
 * exactly the people worth following up, and without this they produce no record at all.
 *
 * Sent ONCE per installed version, not on every activation and never on a timer. So it says
 * "this installation exists and is on version X" and nothing about whether anyone is sitting at
 * the machine - the rule that this product counts builds rather than presence still holds.
 *
 * A failure here is ignored on purpose. A missing adoption figure is worth nothing next to
 * delaying or breaking the extension's start-up.
 */
const PINGED_VERSION_KEY = 'usage.pingedVersion';

export async function reportInstallationOnce(
  context: vscode.ExtensionContext,
  apiService: ApiService
): Promise<void> {
  try {
    const signals = collectUsageSignals();
    if (!signals.installId) {
      return;   // nothing to key the installation on; never invent one
    }

    // Once per installed version. There is no capture state to react to any more - the key
    // is always derived locally and always sent, because it identifies nobody.
    const marker = String(signals.extVersion || '');
    if (context.globalState.get<string>(PINGED_VERSION_KEY) === marker) {
      return;   // nothing has changed - staying quiet is the whole point
    }

    await apiService.post('extension-usage/ping', signals, 10000);
    await context.globalState.update(PINGED_VERSION_KEY, marker);
    Logger.debug(`[UsagePing] installation announced for version ${signals.extVersion}`);
  } catch (error) {
    // Deliberately swallowed: adoption reporting must never affect start-up.
    Logger.debug(`[UsagePing] not sent (${error instanceof Error ? error.message : String(error)})`);
  }
}


/**
 * One build outcome, success or failure. The usage page must say how many builds happened
 * and how many failed over a period. Until now the server heard about a build
 * only when a fix was uploaded, so every build that never failed was invisible. This is a
 * count keyed on the installation id, like the install ping; it carries no file content.
 * Fire-and-forget: a lost count must never delay or break the failure handling it sits beside.
 */
export function reportBuildOutcome(apiService: ApiService, projectName: string, failed: boolean, issues = 0): void {
  try {
    const signals = collectUsageSignals();
    if (!signals.installId) {
      return;
    }
    // issues = the errors captured from this failed build (the dashboard's "Issues Captured").
    const body = { ...signals, projectName: String(projectName || ''), failed: !!failed, issues: failed ? Math.max(0, Number(issues) || 0) : 0 };
    apiService.post('extension-usage/build', body, 10000).catch((error: unknown) => {
      Logger.debug(`[UsagePing] build outcome not sent (${error instanceof Error ? error.message : String(error)})`);
    });
  } catch (error) {
    Logger.debug(`[UsagePing] build outcome not sent (${error instanceof Error ? error.message : String(error)})`);
  }
}
