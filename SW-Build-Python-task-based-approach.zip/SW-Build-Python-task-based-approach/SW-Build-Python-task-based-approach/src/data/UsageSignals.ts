import * as crypto from 'crypto';
import * as os from 'os';
import * as vscode from 'vscode';

/**
 * Adoption signals sent with each analysed build.
 *
 * `installId` is vscode.env.machineId - an id VS Code generates per installation. It is not
 * derived from any person and cannot be turned back into one.
 *
 * `usageKey` replaces sending the login itself. The requirement is that no user id is stored
 * or encrypted on the server; only a key derived from an identifier leaves the machine, so
 * that a unique user can be recognised and nothing more.
 *
 * The login is therefore never sent. It is turned into a key HERE, on the developer's own machine,
 * and only the key leaves. The server therefore never receives a login, which is a stronger
 * position than receiving one and promising not to keep it: there is nothing to keep.
 *
 * The key exists for one purpose - recognising the same person twice, so a developer working on
 * two machines counts once. It is never displayed anywhere and nothing reverses it.
 *
 * An honest limit, worth knowing rather than discovering: because the salt ships inside the
 * extension, somebody holding both the extension and the database could match a key back to a
 * login they already suspected, since Schaeffler ids are short and predictable. That is a
 * deliberate trade. Keeping the salt server-side would mean sending the login to the server,
 * which is exactly what this design exists to avoid.
 */
export interface UsageSignals {
  installId: string;
  extVersion: string;
  envKind: string;
  usageKey?: string;
}

const EXTENSION_ID = 'Schaeffler.gradle-error-assistant';

/** Namespaces the key so it cannot collide with any other identifier in the product. */
const KEY_SALT = 'aiasb:extension-usage:v1:';

/** Turn the local login into the value that leaves the machine. The login itself never does. */
function deriveUsageKey(): string {
  try {
    const login = String(os.userInfo().username || process.env.USERNAME || '')
      .trim()
      .toLowerCase();
    if (!login) {
      return '';
    }
    return crypto.createHash('sha256').update(KEY_SALT + login).digest('hex');
  } catch {
    // No key simply means this build is not attributed to a person. The build still counts.
    return '';
  }
}

export function collectUsageSignals(): UsageSignals {
  const signals: UsageSignals = { installId: '', extVersion: '', envKind: 'local' };

  try {
    signals.installId = String(vscode.env.machineId || '');
  } catch {
    /* a missing install id means this build is simply not counted, never guessed at */
  }

  try {
    signals.extVersion = String(
      vscode.extensions.getExtension(EXTENSION_ID)?.packageJSON?.version || ''
    );
  } catch {
    /* the server reports an unknown version rather than one being invented here */
  }

  try {
    signals.envKind = String(vscode.env.remoteName || 'local');
  } catch {
    /* default already set */
  }

  const key = deriveUsageKey();
  if (key) {
    signals.usageKey = key;
  }

  return signals;
}
