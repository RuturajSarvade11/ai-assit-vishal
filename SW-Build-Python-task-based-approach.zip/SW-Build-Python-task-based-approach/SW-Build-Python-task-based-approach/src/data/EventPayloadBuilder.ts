import * as crypto from 'crypto';
import * as fs from 'fs';
import { FileUtils } from '../utils/FileUtils';
import { FileChangeEvent } from '../types/events';
import { DiffGenerator } from '../processors/DiffGenerator';

type SolutionEntry = {
  fileName: string;
  filePath: string;
  changes: string[];
  changeObjects: Array<{
    id: string;
    line: number;
    hunk: number;
    change: string;
    patch: string;
    riskSide?: 'before' | 'after';
  }>;
};

export class EventPayloadBuilder {
  public transformPayloadForAPI(data: FileChangeEvent[], batchId: string, requestedTasks: string): any {
    // Prediction matches files across developers' machines by their PROJECT-RELATIVE path.
    // Events carry absolute watcher paths (d:/UAT_PROJECTS/TestGbe/work/tools/config.xml);
    // stored like that, the path only matches when another developer's clone has the exact
    // same folder name (the TestGB "0 patterns" bug). Normalize once at the event level so
    // every downstream field (all_changes, solution, snapshots) uploads machine-independent
    // paths like work/tools/config.xml.
    const normalized = (data || []).map((event) => this.normalizeEventPaths(event));
    return {
      solution: this.buildSolution(normalized),
      all_changes: normalized,
      batchId,
      requestedTasks
    };
  }

  private toWorkspaceRelative(rawPath: string, workspace: string): string {
    const p = String(rawPath || '').replace(/\\/g, '/');
    const ws = String(workspace || '').replace(/\\/g, '/').replace(/\/+$/, '');
    if (!p || !ws) { return p; }
    if (p.toLowerCase().startsWith(ws.toLowerCase() + '/')) {
      return p.slice(ws.length + 1);
    }
    return p; // already relative, or outside the workspace - leave unchanged
  }

  private normalizeEventPaths(event: FileChangeEvent): FileChangeEvent {
    const ws = String((event as any)?.workspace || '');
    if (!ws) { return event; }
    const clone: any = { ...event };
    if (clone.filePath) { clone.filePath = this.toWorkspaceRelative(clone.filePath, ws); }
    if (clone.snapshotBefore && clone.snapshotBefore.path) {
      clone.snapshotBefore = { ...clone.snapshotBefore, path: this.toWorkspaceRelative(clone.snapshotBefore.path, ws) };
    }
    if (clone.snapshotAfter && clone.snapshotAfter.path) {
      clone.snapshotAfter = { ...clone.snapshotAfter, path: this.toWorkspaceRelative(clone.snapshotAfter.path, ws) };
    }
    return clone as FileChangeEvent;
  }

  // Above this size, a deleted file's before-content is omitted from the upload. The
  // content stays in the local snapshot cache (snapshotBeforeContentPath) and is fetched
  // on demand only if the user opens the diff — this avoids oversized archive payloads
  // (e.g. a 2.5 MB deleted file) that fail to store / trip the upload circuit breaker.
  private static readonly MAX_BEFORE_CONTENT_BYTES = 512 * 1024; // 512 KB

  // A "deletion-style" change has removed content but nothing added. Returns the total
  // before-content size in chars, or -1 if the event also has additions (a modification).
  private deletionBeforeBytes(event: any): number {
    const fns = Array.isArray(event?.modifiedFunctions) ? event.modifiedFunctions : [];
    const hasAfter = fns.some((fn: any) => (fn?.linesAfterChanges?.length ?? 0) > 0);
    if (hasAfter) { return -1; }
    let bytes = 0;
    for (const fn of fns) {
      for (const lc of (fn?.linesBeforeChanges || [])) {
        bytes += String(lc?.content || '').length;
      }
    }
    return bytes;
  }

  public preparePayload(data: any): string {
    const payload = JSON.parse(JSON.stringify(data));
    const now = new Date().toISOString();

    if (Array.isArray(payload)) {
      payload.forEach((item: any) => item.timestamp ??= now);
    } else if (!payload?.all_changes) {
      payload.timestamp ??= now;
    }

    if (Array.isArray(payload?.all_changes)) {
      payload.all_changes.forEach((event: any) => {
        if (Array.isArray(event.modifiedFunctions)) {
          event.modifiedFunctions.forEach((fn: any) => {
            if (fn.before) {
              fn.before.functionCode = null;
            }

            if (fn.after) {
              fn.after.functionCode = null;
            }
          });
        }

        // Deleted file with large before-content: omit it from the upload. It remains in
        // the local snapshot cache (snapshotBeforeContentPath) for on-demand viewing.
        const beforeBytes = this.deletionBeforeBytes(event);
        if (beforeBytes > EventPayloadBuilder.MAX_BEFORE_CONTENT_BYTES) {
          if (Array.isArray(event.modifiedFunctions)) {
            event.modifiedFunctions.forEach((fn: any) => { fn.linesBeforeChanges = []; });
          }
          if (event.snapshotBefore && typeof event.snapshotBefore === 'object') {
            event.snapshotBefore.content = null; // keep the path, drop inline content
          }
          event.action = 'deleted';
          event.beforeContentOmitted = true;
          event.beforeBytes = beforeBytes;
        }
      });
    }

    return JSON.stringify(payload);
  }

  public trimPayloadIfOversized<T extends { solution: any; projectName: string; taskName: string; errorDetails?: { message: string }[] }>(payload: T): T {
    const MAX_BYTES = 4 * 1024 * 1024;
    const raw = JSON.stringify(payload);

    if (raw.length <= MAX_BYTES) {
      return payload;
    }

    const trimmed = JSON.parse(raw);

    if (Array.isArray(trimmed.solution)) {
      for (const file of trimmed.solution) {
        if (Array.isArray(file.changeObjects)) {
          for (const changeObject of file.changeObjects) {
            changeObject.patch = '';
          }
        }
      }
    }

    const trimmedRaw = JSON.stringify(trimmed);

    if (trimmedRaw.length <= MAX_BYTES) {
      return trimmed;
    }

    if (Array.isArray(trimmed.solution)) {
      trimmed.solution = trimmed.solution.slice(0, 30);

      for (const file of trimmed.solution) {
        if (Array.isArray(file.changes)) {
          file.changes = file.changes.slice(0, 50);
        }

        if (Array.isArray(file.changeObjects)) {
          file.changeObjects = file.changeObjects.slice(0, 50);
        }
      }
    }

    return trimmed;
  }

  public isArchivePayloadReady(payload: any): boolean {
    if (!payload || typeof payload !== 'object') {
      return false;
    }

    if (this.hasMeaningfulErrorDetails(payload.errorDetails)) {
      return true;
    }

    if (this.hasMeaningfulModifiedFunctions(payload.modifiedFunctions)) {
      return true;
    }

    if (this.hasMeaningfulSnapshot(payload.snapshotBefore) || this.hasMeaningfulSnapshot(payload.snapshotAfter)) {
      return true;
    }

    return false;
  }

  public getUniqueErrorsWithoutTimestamp(errors: string[]): { message: string }[] {
    const seen = new Set<string>();
    const result: { message: string }[] = [];

    for (const err of errors) {
      if (!err) {
        continue;
      }

      const withoutTimestamp = FileUtils.stripTimestamp(err);

      if (!seen.has(withoutTimestamp)) {
        seen.add(withoutTimestamp);
        result.push({ message: err });
      }
    }

    return result;
  }

  public getSolutionSubsetForPayload(payload: any, solution: any[]): any[] {
    const payloadFilePath = String(payload?.filePath || '').trim();
    const payloadFileName = String(payload?.fileName || '').trim();

    if (!Array.isArray(solution)) {
      return [];
    }

    return solution.filter((item: any) => {
      if (!item || typeof item !== 'object') {
        return false;
      }

      const itemPath = String(item.filePath || '').trim();
      const itemName = String(item.fileName || '').trim();

      return (payloadFilePath && itemPath === payloadFilePath)
        || (payloadFileName && itemName === payloadFileName)
        || (payloadFileName && itemPath && this.basename(itemPath) === payloadFileName);
    });
  }

  private buildSolution(events: FileChangeEvent[]): SolutionEntry[] {
    const byFile = new Map<string, SolutionEntry>();

    for (const event of events) {
      const key = event.filePath || event.fileName;
      let entry = byFile.get(key);

      if (!entry) {
        entry = {
          fileName: event.fileName,
          filePath: event.filePath,
          changes: [],
          changeObjects: []
        };
        byFile.set(key, entry);
      } else {
        // Final payload should reflect the latest effective diff for this file,
        // not accumulate stale intermediate snapshots from earlier events.
        entry.fileName = event.fileName;
        entry.filePath = event.filePath;
        entry.changes = [];
        entry.changeObjects = [];
      }

      // Deleted file with large before-content: don't expand it into the solution diff.
      // It is cached locally and fetched on demand only when the user opens the diff.
      const deletedBytes = this.deletionBeforeBytes(event);
      if (deletedBytes > EventPayloadBuilder.MAX_BEFORE_CONTENT_BYTES) {
        entry.changes = [`[deleted] before-content omitted from upload (${deletedBytes} bytes, cached locally — open the diff to view)`];
        entry.changeObjects = [];
        continue;
      }

      const hasFunctionDiffs = event.modifiedFunctions?.some(
        (fn) => (fn.linesBeforeChanges?.length ?? 0) > 0 || (fn.linesAfterChanges?.length ?? 0) > 0
      );

      if (hasFunctionDiffs) {
        const snapshotBefore = this.getSnapshotContent(event, 'before');
        const snapshotAfter = this.getSnapshotContent(event, 'after');

        for (const fn of event.modifiedFunctions) {
          const before = fn.linesBeforeChanges ?? [];
          const after = fn.linesAfterChanges ?? [];

          if (before.length > 0 || after.length > 0) {
            this.applyDiffToChanges(
              { added: after, removed: before },
              entry,
              snapshotBefore,
              snapshotAfter
            );
          }
        }

        continue;
      }

      const before = this.getSnapshotContent(event, 'before');
      const after = this.getSnapshotContent(event, 'after');

      if (typeof before === 'string' && typeof after === 'string') {
        const diff = DiffGenerator.getDiffStats(before, after);
        this.applyDiffToChanges(diff, entry, before, after);
        continue;
      }

      for (const fn of event.modifiedFunctions) {
        if (fn.linesAfterChanges && fn.linesAfterChanges.length > 0) {
          entry.changes.push(...fn.linesAfterChanges.map((lineChange) => lineChange.content));
        } else if (fn.linesBeforeChanges && fn.linesBeforeChanges.length > 0) {
          entry.changes.push(...fn.linesBeforeChanges.map((lineChange) => lineChange.content));
        }
      }
    }

    return Array.from(byFile.values());
  }


  private getSnapshotContent(event: FileChangeEvent, side: 'before' | 'after'): string {
    const direct = side === 'before' ? event.snapshotBefore?.content : event.snapshotAfter?.content;
    if (typeof direct === 'string') {
      return direct;
    }

    const diskPath = side === 'before' ? event.snapshotBeforeContentPath : event.snapshotAfterContentPath;
    if (diskPath) {
      try {
        if (fs.existsSync(diskPath)) {
          return fs.readFileSync(diskPath, 'utf8').replace(/\r\n/g, '\n');
        }
      } catch {
        return '';
      }
    }

    return '';
  }

  private applyDiffToChanges(
    diff: { added: { line: number; content: string }[]; removed: { line: number; content: string }[] },
    entry: SolutionEntry,
    beforeContent: string = '',
    afterContent: string = ''
  ): void {
    const sortedAdded = [...diff.added].sort((a, b) => a.line - b.line);
    const sortedRemoved = [...diff.removed].sort((a, b) => a.line - b.line);
    const hunkByAddedLine = this.buildHunkMap(sortedAdded.map((line) => line.line));
    const hunkByRemovedLine = this.buildHunkMap(sortedRemoved.map((line) => line.line));
    const processedRemovals = new Set<number>();

    sortedAdded.forEach((addedLine) => {
      const addedText = (addedLine.content ?? '').trim();

      if (addedText.length === 0) {
        return;
      }

      let bestMatchIndex = -1;
      let highestSimilarity = 0;
      let bestRemovedLineNo = 0;

      sortedRemoved.forEach((removedLine, index) => {
        if (processedRemovals.has(index)) {
          return;
        }

        const similarity = this.calculateSimilarity((removedLine.content ?? '').trim(), addedText);

        if (similarity > highestSimilarity) {
          highestSimilarity = similarity;
          bestMatchIndex = index;
          bestRemovedLineNo = removedLine.line;
        }
      });

      if (highestSimilarity > 0.5) {
        const hunkId = hunkByAddedLine.get(addedLine.line) ?? hunkByRemovedLine.get(bestRemovedLineNo) ?? 1;
        const beforeText = (bestMatchIndex >= 0 ? sortedRemoved[bestMatchIndex]?.content : '')?.trim() || addedText;

        entry.changes.push(this.formatChange('[MOD]', addedText, addedLine.line, hunkId));
        entry.changeObjects.push({
          id: this.makeChangeId(entry.filePath, bestRemovedLineNo || addedLine.line, hunkId, '[MOD]', beforeText),
          line: bestRemovedLineNo || addedLine.line,
          hunk: hunkId,
          change: `[[${bestRemovedLineNo || addedLine.line}]][MOD]\t${beforeText}`,
          patch: this.getPatchContext(beforeContent, bestRemovedLineNo || addedLine.line, 10),
          riskSide: 'before'
        });
        entry.changeObjects.push({
          id: this.makeChangeId(entry.filePath, addedLine.line, hunkId, '[MOD_AFTER]', addedText),
          line: addedLine.line,
          hunk: hunkId,
          change: `[[${addedLine.line}]][MOD_AFTER]\t${addedText}`,
          patch: this.getPatchContext(afterContent, addedLine.line, 10),
          riskSide: 'after'
        });
        processedRemovals.add(bestMatchIndex);
        return;
      }

      const hunkId = hunkByAddedLine.get(addedLine.line) ?? 1;
      entry.changes.push(this.formatChange('[+]', addedText, addedLine.line, hunkId));
      entry.changeObjects.push({
        id: this.makeChangeId(entry.filePath, addedLine.line, hunkId, '[+]', addedText),
        line: addedLine.line,
        hunk: hunkId,
        change: `[[${addedLine.line}]][+]\t${addedText}`,
        patch: this.getPatchContext(afterContent, addedLine.line, 10),
        riskSide: 'after'
      });
    });

    sortedRemoved.forEach((removedLine, index) => {
      if (processedRemovals.has(index)) {
        return;
      }

      const text = (removedLine.content ?? '').trim();

      if (text.length === 0) {
        return;
      }

      const hunkId = hunkByRemovedLine.get(removedLine.line) ?? 1;
      entry.changes.push(this.formatChange('[-]', text, removedLine.line, hunkId));
      entry.changeObjects.push({
        id: this.makeChangeId(entry.filePath, removedLine.line, hunkId, '[-]', text),
        line: removedLine.line,
        hunk: hunkId,
        change: `[[${removedLine.line}]][-]\t${text}`,
        patch: this.getPatchContext(beforeContent, removedLine.line, 10),
        riskSide: 'before'
      });
    });
  }

  private buildHunkMap(lines: number[]): Map<number, number> {
    const out = new Map<number, number>();

    if (!lines.length) {
      return out;
    }

    const sorted = [...lines].sort((a, b) => a - b);
    let hunkId = 1;
    let prev = sorted[0];
    out.set(prev, hunkId);

    for (let i = 1; i < sorted.length; i++) {
      const current = sorted[i];

      if (current - prev > 3) {
        hunkId += 1;
      }

      out.set(current, hunkId);
      prev = current;
    }

    return out;
  }

  private formatChange(prefix: '[MOD]' | '[+]' | '[-]', text: string, line: number, hunkId: number): string {
    return `${prefix} ${text} [[line:${line}]][[hunk:${hunkId}]]`;
  }

  private makeChangeId(filePath: string, line: number, hunkId: number, kind: string, text: string): string {
    const raw = `${filePath}|${line}|${hunkId}|${kind}|${text}`;
    const hex = crypto.createHash('sha1').update(raw).digest('hex').slice(0, 32);
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20, 32)}`;
  }

  private getPatchContext(content: string, line: number, radius: number): string {
    if (!content || !Number.isFinite(line) || line <= 0) {
      return '';
    }

    const lines = content.replace(/\r\n/g, '\n').split('\n');
    const start = Math.max(0, line - 1 - radius);
    const end = Math.min(lines.length - 1, line - 1 + radius);

    return lines.slice(start, end + 1).join('\n');
  }

  private calculateSimilarity(s1: string, s2: string): number {
    const len1 = s1.length;
    const len2 = s2.length;
    const maxLen = Math.max(len1, len2);

    if (maxLen === 0) {
      return 1;
    }

    const editDistance = this.levenshtein(s1, s2);
    return (maxLen - editDistance) / maxLen;
  }

  private levenshtein(a: string, b: string): number {
    const matrix: number[][] = [];

    for (let i = 0; i <= b.length; i++) {
      matrix[i] = [i];
    }

    for (let j = 0; j <= a.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        if (b.charAt(i - 1) === a.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }

    return matrix[b.length][a.length];
  }

  private hasMeaningfulErrorDetails(errorDetails: any): boolean {
    if (!Array.isArray(errorDetails)) {
      return false;
    }

    return errorDetails.some((item: any) => this.hasNonEmptyString(item?.message));
  }

  private hasMeaningfulModifiedFunctions(modifiedFunctions: any): boolean {
    if (!Array.isArray(modifiedFunctions)) {
      return false;
    }

    return modifiedFunctions.some((fn: any) => {
      const beforeLines = Array.isArray(fn?.linesBeforeChanges)
        ? fn.linesBeforeChanges.filter((line: any) => this.hasNonEmptyString(line))
        : [];
      const afterLines = Array.isArray(fn?.linesAfterChanges)
        ? fn.linesAfterChanges.filter((line: any) => this.hasNonEmptyString(line))
        : [];

      return beforeLines.length > 0 || afterLines.length > 0;
    });
  }

  private hasMeaningfulSnapshot(snapshot: any): boolean {
    return this.hasNonEmptyString(snapshot?.content);
  }

  private hasNonEmptyString(value: any): boolean {
    return typeof value === 'string' && value.trim().length > 0;
  }

  private basename(filePath: string): string {
    return String(filePath || '').replace(/\\/g, '/').split('/').pop() || '';
  }
}
