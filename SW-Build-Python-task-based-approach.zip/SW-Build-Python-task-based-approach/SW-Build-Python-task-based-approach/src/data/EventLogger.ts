import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { Logger } from '../utils/Logger';
import { FileUtils } from '../utils/FileUtils';
import { Telemetry } from '../utils/Telemetry';
import { ApiService } from '../services/api.service';
import { FileChangeEvent } from '../types/events';
import { EventPayloadBuilder } from './EventPayloadBuilder';
import { collectUsageSignals } from './UsageSignals';
import { UploadStatusBar } from '../ui/UploadStatusBar';

type UploadableFileEvent = {
  filePath: string;
  absolutePath: string;
  action: 'added' | 'modified' | 'deleted';
  fileContent?: Buffer;
  projectName?: string;
  artifactGroup?: string;
  taskPath?: string;
  sourceFolder?: string;
  uploadName?: string;
  originalFileName?: string;
};

function pickDeveloperId(passed: string | undefined | null): string {
  const value = String(passed || '').trim();
  return value || 'unknown';
}

export class EventLogger {
  private readonly logDir: string;
  private readonly binaryBackupDir: string;
  private readonly createRequestPath = 'final-build';
  private readonly finalBuildByRequestPath = 'archive-payload';

  private readonly payloadBuilder = new EventPayloadBuilder();
  private readonly requestIdCache = new Map<string, string>();
  // GBE target discovered from the report location (client integration doc). ADDITIVE upload
  // field only - taskName/requestedTasks and every existing key stay exactly as they are.
  private gbeTargetName = '';
  private readonly requestIdInFlight = new Map<string, Promise<string>>();
  private readonly completedBatchIds = new Map<string, number>();
  private static readonly COMPLETED_BATCH_TTL_MS = 2 * 60 * 1000;
  private static readonly FINAL_BUILD_TIMEOUT_MS = 120000;

  constructor(
    private readonly storagePath: string,
    private readonly apiService: ApiService,
    private readonly telemetry?: Telemetry
  ) {
    this.logDir = path.join(storagePath, 'event_logs');
    this.binaryBackupDir = path.join(storagePath, 'binary_backup');
    this.retryDir = path.join(storagePath, 'upload_retry');
    this.ensureDirectory(this.logDir);
    this.ensureDirectory(this.retryDir);
    this.cleanupLocalUploadStorage();
    this.startRetryLoop();
  }

  // ---------------------------------------------------------------------------
  // PERSISTENT upload retry queue: confirmed data must NEVER be discarded
  // after the in-session attempts — save it and re-upload automatically once
  // the network is back, across sessions too.
  // Model: every enqueue writes one JSON file under upload_retry/. Replays
  // DELETE the file first and call the normal send method again — the method
  // re-enqueues itself on a genuine failure, so refused/duplicate payloads
  // leave the queue while network failures stay in it. Buffers are base64-
  // encoded so artifact/binary content survives the disk round-trip.
  // ---------------------------------------------------------------------------
  private readonly retryDir: string;
  private retryTimer: ReturnType<typeof setInterval> | null = null;
  private retryInFlight = false;

  private static readonly RETRY_KIND_ORDER = ['batch', 'error-only', 'binary', 'runtime'];

  private retrySerialize(obj: unknown): string {
    return JSON.stringify(obj, (_k, v) => {
      if (v && typeof v === 'object' && (v as any).type === 'Buffer' && Array.isArray((v as any).data)) {
        return { __b64: Buffer.from((v as any).data).toString('base64') };
      }
      if (Buffer.isBuffer(v)) { return { __b64: v.toString('base64') }; }
      return v;
    });
  }

  private retryRevive(text: string): any {
    return JSON.parse(text, (_k, v) =>
      v && typeof v === 'object' && typeof (v as any).__b64 === 'string'
        ? Buffer.from((v as any).__b64, 'base64')
        : v
    );
  }

  private retryFilePath(kind: string, batchId: string): string {
    return path.join(this.retryDir, `${kind}__${batchId}.json`);
  }

  private writeRetryFile(kind: string, batchId: string, data: unknown): void {
    try {
      fs.writeFileSync(this.retryFilePath(kind, batchId), this.retrySerialize({ kind, batchId, data }), 'utf8');
      Logger.log(`[EventLogger] retry queue: saved ${kind} ${batchId.slice(0, 8)} for automatic re-upload`);
    } catch (err) {
      Logger.log('[EventLogger] retry queue: SAVE FAILED', err);
    }
  }

  private deleteRetryFile(kind: string, batchId: string): void {
    try { fs.unlinkSync(this.retryFilePath(kind, batchId)); } catch { /* already gone */ }
  }

  public pendingRetryCount(): number {
    try { return fs.readdirSync(this.retryDir).filter(f => f.endsWith('.json')).length; } catch { return 0; }
  }

  private listRetryFiles(): string[] {
    let names: string[] = [];
    try { names = fs.readdirSync(this.retryDir).filter(f => f.endsWith('.json')); } catch { return []; }
    const rank = (n: string) => {
      const kind = n.split('__')[0];
      const idx = EventLogger.RETRY_KIND_ORDER.indexOf(kind);
      return idx === -1 ? EventLogger.RETRY_KIND_ORDER.length : idx;
    };
    return names.sort((a, b) => rank(a) - rank(b)).map(n => path.join(this.retryDir, n));
  }

  private startRetryLoop(): void {
    // Network-recovery loop: as long as saved uploads exist, try again every 2 minutes.
    // Cheap when empty (one readdir), safe against overlap via retryInFlight.
    this.retryTimer = setInterval(() => {
      if (this.pendingRetryCount() > 0) {
        void this.processRetryQueue('network-recovery');
      }
    }, 120000);
  }

  private async processRetryQueue(reason: string): Promise<void> {
    if (this.retryInFlight) { return; }
    this.retryInFlight = true;
    try {
      const files = this.listRetryFiles();
      if (files.length === 0) { return; }
      Logger.log(`[EventLogger] retry queue: ${files.length} saved upload(s) — attempting delivery (${reason})`);
      UploadStatusBar.uploading(`${files.length} saved upload${files.length === 1 ? '' : 's'}`);

      for (const file of files) {
        let entry: any;
        try { entry = this.retryRevive(fs.readFileSync(file, 'utf8')); } catch {
          try { fs.unlinkSync(file); } catch { /* unreadable leftovers */ }
          continue;
        }
        try { fs.unlinkSync(file); } catch { /* replay methods re-enqueue on failure */ }

        const d = entry?.data || {};
        try {
          switch (entry?.kind) {
            case 'batch':
              await this.logBatchEvents(d.events, d.allErrors, entry.batchId, d.requestedTasks, d.developerId, d.resolutionDescription);
              break;
            case 'error-only':
              await this.logErrorOnlyBatch(d.errors, entry.batchId, d.requestedTasks, d.developerId, d.projectName, d.resolutionDescription);
              break;
            case 'binary':
              await this.sendBinaryFiles(entry.batchId, d.events, d.developerId, d.requestId);
              break;
            case 'runtime':
              await this.sendRuntimeArtifacts(entry.batchId, d.events, d.developerId, d.requestId);
              break;
            default:
              Logger.log(`[EventLogger] retry queue: unknown kind ${entry?.kind} — dropped`);
          }
        } catch {
          // The send method already re-enqueued itself and logged the failure.
        }
      }

      const remaining = this.pendingRetryCount();
      if (remaining === 0) {
        Logger.log('[EventLogger] retry queue: all saved uploads delivered');
        UploadStatusBar.uploaded('saved uploads delivered');
      } else {
        Logger.log(`[EventLogger] retry queue: ${remaining} upload(s) still pending — will retry automatically`);
        UploadStatusBar.retryPending(remaining);
      }
    } finally {
      this.retryInFlight = false;
    }
  }

  public setGbeTarget(target: string): void {
    const t = String(target || '').trim();
    if (t) { this.gbeTargetName = t; }
  }

  public async sendBinaryFiles(batchId: string, binaryEvents: UploadableFileEvent[], developerId: string = 'unknown', requestId: string): Promise<void> {
    if (!binaryEvents || binaryEvents.length === 0) {
      return;
    }

    const safeDeveloperId = pickDeveloperId(developerId);

    UploadStatusBar.uploading(`${binaryEvents.length} binary file${binaryEvents.length === 1 ? '' : 's'}`);
    try {
      await this.apiService.uploadFiles('binary-store', batchId, binaryEvents, 60000, safeDeveloperId, requestId);
      Logger.log('[EventLogger] Binary files uploaded successfully to server');

      this.telemetry?.recordUpload(true, this.getTotalBytes(binaryEvents));
      await this.backupUploadedFiles(batchId, binaryEvents);
      this.cleanupLocalUploadStorage();
      UploadStatusBar.uploaded(`${binaryEvents.length} binary file${binaryEvents.length === 1 ? '' : 's'}`);
    } catch (error) {
      this.telemetry?.recordUpload(false);
      this.writeRetryFile('binary', batchId, { events: binaryEvents, developerId: safeDeveloperId, requestId });
      UploadStatusBar.retryPending(this.pendingRetryCount());
      throw error;
    }
  }

  public async sendRuntimeArtifacts(batchId: string, runtimeEvents: UploadableFileEvent[], developerId: string = 'unknown', requestId: string): Promise<void> {
    if (!runtimeEvents || runtimeEvents.length === 0) {
      return;
    }

    const safeDeveloperId = pickDeveloperId(developerId);
    const chunkSize = 25;
    const chunkTimeoutMs = 120000;
    const uploadedEvents: UploadableFileEvent[] = [];
    const failedEvents: UploadableFileEvent[] = [];

    UploadStatusBar.uploading(`${runtimeEvents.length} artifact${runtimeEvents.length === 1 ? '' : 's'}`);
    for (let index = 0; index < runtimeEvents.length; index += chunkSize) {
      const chunk = runtimeEvents.slice(index, index + chunkSize);

      try {
        await this.apiService.uploadFiles('task-runtime-artifacts', batchId, chunk, chunkTimeoutMs, safeDeveloperId, requestId);
        uploadedEvents.push(...chunk);
      } catch {
        // Failed chunks are DATA, not noise — keep them for the
        // persistent retry (the server's fingerprint dedup makes a full re-send safe).
        failedEvents.push(...chunk);
      }
    }

    if (uploadedEvents.length > 0) {
      await this.backupUploadedFiles(batchId, uploadedEvents);
      this.cleanupLocalUploadStorage();
      Logger.log(`[EventLogger] ${uploadedEvents.length} runtime artifact(s) uploaded successfully.`);
    }
    if (failedEvents.length > 0) {
      this.writeRetryFile('runtime', batchId, { events: failedEvents, developerId: safeDeveloperId, requestId });
      UploadStatusBar.retryPending(this.pendingRetryCount());
      throw new Error(`${failedEvents.length} runtime artifact(s) not uploaded — saved for automatic retry`);
    }
    UploadStatusBar.uploaded(`${uploadedEvents.length} artifact${uploadedEvents.length === 1 ? '' : 's'}`);
  }

  /** Storage doc §8 (rollout step 5): duplicate pre-check BEFORE the confirm popup. Builds
   *  the same payload shape logBatchEvents would send and asks the server; true ONLY when the
   *  server confidently says everything (error + solution + artifacts) is already stored.
   *  Any error, timeout or missing data returns false - the popup opens exactly as today. */
  public async precheckDuplicate(
    events: FileChangeEvent[],
    allErrors: string[],
    batchId: string,
    requestedTasks: string
  ): Promise<boolean> {
    try {
      if (!events || events.length === 0) { return false; }
      const uniqueErrorDetails = this.payloadBuilder.getUniqueErrorsWithoutTimestamp(allErrors);
      this.attachErrorDetailsToEvents(events, allErrors);
      const transformed = this.payloadBuilder.transformPayloadForAPI(events, batchId, requestedTasks);
      transformed.batchId = batchId;
      const finalPayload = JSON.parse(this.payloadBuilder.preparePayload(transformed));
      const projectName = finalPayload?.all_changes?.[0]?.projectName ?? '';
      if (!projectName || !Array.isArray(finalPayload?.solution) || finalPayload.solution.length === 0) {
        return false;
      }
      const res = await this.apiService.precheckUpload({
        solution: finalPayload.solution,
        projectName,
        taskName: requestedTasks,
        errorDetails: uniqueErrorDetails,
      });
      return res?.skip_upload === true;
    } catch (err) {
      Logger.log('[EventLogger] upload pre-check failed - opening the popup as usual (fail-open)', err);
      return false;
    }
  }

  public async logBatchEvents(
    events: FileChangeEvent[],
    allErrors: string[],
    batchId: string,
    requestedTasks: string,
    developerId: string = 'unknown',
    resolutionDescription: string = ''
  ): Promise<string | undefined> {
    if (!events || events.length === 0) {
      return undefined;
    }

    if (this.isRecentlyCompletedBatch(batchId)) {
      Logger.log(`[EventLogger] logBatchEvents: skipped duplicate completed`);
      return undefined;
    }

    const safeDeveloperId = pickDeveloperId(developerId);
    const date = new Date().toISOString().split('T')[0];
    const allChangesFile = path.join(this.logDir, `allChanges_${date}.jsonl`);
    const uniqueErrorDetails = this.payloadBuilder.getUniqueErrorsWithoutTimestamp(allErrors);

    this.attachErrorDetailsToEvents(events, allErrors);

    const transformedPayload = this.payloadBuilder.transformPayloadForAPI(events, batchId, requestedTasks);
    transformedPayload.batchId = batchId;

    const finalPayload = JSON.parse(this.payloadBuilder.preparePayload(transformedPayload));
    const projectName = finalPayload?.all_changes?.[0]?.projectName ?? '';
    const projectType = this.getCurrentProjectType();
    const allChanges = finalPayload.all_changes ?? [];
    const sendableChanges = allChanges.filter((payload: any) => this.payloadBuilder.isArchivePayloadReady(payload));

    if (sendableChanges.length === 0) {
      Logger.log('[EventLogger] logBatchEvents: skipped — no archive-ready data to send');
      return undefined;
    }

    const requestPayload = {
      solution: finalPayload.solution,
      projectName,
      taskName: requestedTasks,
      errorDetails: uniqueErrorDetails,
      developer_id: safeDeveloperId,
      uuid: batchId,
      projectType,
      ...(this.gbeTargetName ? { targetName: this.gbeTargetName } : {}),
    };

    // Diagnostic snapshot of exactly what is about to be sent to the server. If a
    // request is later created with empty error/artifacts, this line (persisted to
    // disk, date-wise) shows what was empty and the context. See the empty-payload bug.
    Logger.debug('[EventLogger] PRE-UPLOAD snapshot (batch)', {
      batchId,
      task: requestedTasks,
      projectName,
      projectType,
      errorCount: uniqueErrorDetails.length,
      errorChars: uniqueErrorDetails.reduce((n: number, e: any) => n + String(e?.message || '').length, 0),
      emptyError: uniqueErrorDetails.length === 0,
      firstErrorPreview: String(uniqueErrorDetails?.[0]?.message || '').replace(/\s+/g, ' ').slice(0, 140),
      sendableChanges: sendableChanges.length,
      totalChanges: allChanges.length,
      files: sendableChanges.map((c: any) => String(c?.fileName || c?.filePath || '?')).slice(0, 12),
      solutionItems: Array.isArray(finalPayload?.solution) ? finalPayload.solution.length : 0,
    });

    UploadStatusBar.uploading(`task ${requestedTasks || projectName}`);
    try {
      const requestId = await this.getOrCreateRequestId(batchId, requestPayload, 'batch');

      if (requestId && resolutionDescription) {
        await this.apiService.updateFinalBuildResolutionDescription(requestId, resolutionDescription).catch(err => {
            Logger.log(`[EventLogger] Failed to save resolution description for ${requestId}`, err);
        });
      }

      const uploadResult = await this.uploadArchivePayloads({
        requestId,
        sendableChanges,
        solution: finalPayload.solution,
        projectType,
        developerId: safeDeveloperId,
      });

      Logger.log(
        `[EventLogger] Upload complete — ${uploadResult.successCount} succeeded, ${uploadResult.failureCount} failed (${sendableChanges.length} total)`
      );

      if (uploadResult.successCount > 0) {
        await this.writeLocalAuditLogs({
          date,
          finalPayload,
          requestPayload,
          allChangesFile,
        });
        this.cleanupOldLocalLogsSometimes();
        this.telemetry?.recordUpload(true);
      }

      if (uploadResult.failureCount === 0) {
        this.markBatchCompleted(batchId);
        this.requestIdCache.delete(batchId);
        this.deleteRetryFile('batch', batchId);
        UploadStatusBar.uploaded(`task ${requestedTasks || projectName}`);
        return requestId;
      }

      this.telemetry?.recordUpload(false);
      throw new Error(`Archive upload failed for ${uploadResult.failureCount} item(s)`);
    } catch (error) {
      this.telemetry?.recordUpload(false);
      // The confirmed data — errors, changes, the description the
      // developer took time to write — must NOT be discarded when the network is down.
      // Save the full replay payload; the retry loop delivers it when the server is back.
      this.writeRetryFile('batch', batchId, { events, allErrors, requestedTasks, developerId, resolutionDescription });
      UploadStatusBar.retryPending(this.pendingRetryCount());
      throw error;
    }
  }

  public async logErrorOnlyBatch(
    errors: string[],
    batchId: string,
    requestedTasks: string,
    developerId: string = 'unknown',
    projectName: string = '',
    resolutionDescription: string = ''
  ): Promise<{ success: boolean; requestId?: string }> {
    const safeDeveloperId = pickDeveloperId(developerId);
    const uniqueErrors = this.payloadBuilder.getUniqueErrorsWithoutTimestamp(errors);

    if (!this.hasRealError(uniqueErrors)) {
      Logger.log('[EventLogger] logErrorOnlyBatch: refused — no real error to send');
      return { success: false };
    }

    if (this.isRecentlyCompletedBatch(batchId)) {
      Logger.log(`[EventLogger] logErrorOnlyBatch: skipped duplicate completed batch ${batchId.slice(0, 8)}`);
      return { success: false };
    }

    const requestPayload = {
      solution: [],
      projectName,
      taskName: requestedTasks,
      errorDetails: uniqueErrors,
      developer_id: safeDeveloperId,
      uuid: batchId,
      projectType: this.getCurrentProjectType(),
      ...(this.gbeTargetName ? { targetName: this.gbeTargetName } : {}),
    };

    Logger.debug('[EventLogger] PRE-UPLOAD snapshot (error-only)', {
      batchId,
      task: requestedTasks,
      projectName,
      errorCount: uniqueErrors.length,
      errorChars: uniqueErrors.reduce((n: number, e: any) => n + String(e?.message || '').length, 0),
      emptyError: uniqueErrors.length === 0,
      firstErrorPreview: String(uniqueErrors?.[0]?.message || '').replace(/\s+/g, ' ').slice(0, 140),
    });

    UploadStatusBar.uploading(`task ${requestedTasks || projectName}`);
    try {
      const requestId = await this.getOrCreateRequestId(batchId, requestPayload, 'error-only batch');

      if (requestId && resolutionDescription) {
        await this.apiService.updateFinalBuildResolutionDescription(requestId, resolutionDescription).catch(err => {
             Logger.log(`[EventLogger] Failed to save resolution description for ${requestId}`, err);
        });
      }

      this.deleteRetryFile('error-only', batchId);
      UploadStatusBar.uploaded(`task ${requestedTasks || projectName}`);
      return { success: true, requestId };
    } catch {
      // Never discard — save and re-upload when the network is back.
      this.writeRetryFile('error-only', batchId, { errors, requestedTasks, developerId, projectName, resolutionDescription });
      UploadStatusBar.retryPending(this.pendingRetryCount());
      return { success: false };
    }
  }

  public async startupRetry(): Promise<void> {
    // Called at activation (ProjectWatchers): deliver everything saved in earlier sessions.
    await this.processRetryQueue('startup');
  }

  public enqueueArtifactRetry(
    type: 'binary' | 'runtime',
    batchId: string,
    events: UploadableFileEvent[],
    developerId: string,
    requestId: string,
  ): void {
    this.writeRetryFile(type, batchId, { events, developerId, requestId });
  }

  public removeArtifactRetry(type: 'binary' | 'runtime', batchId: string): void {
    this.deleteRetryFile(type, batchId);
  }

  public cleanupLocalUploadStorage(retentionDays: number = 5): void {
    try {
      FileUtils.cleanupOldJsonlFiles(this.logDir, retentionDays);
      FileUtils.cleanupOldFolders(this.binaryBackupDir, retentionDays);
    } catch {
    }
  }

  public dispose(): void {
    if (this.retryTimer) {
      clearInterval(this.retryTimer);
      this.retryTimer = null;
    }
  }

  private async getOrCreateRequestId(
    batchId: string,
    requestPayload: any,
    label: string
  ): Promise<string> {
    const cachedRequestId = this.requestIdCache.get(batchId);

    if (cachedRequestId) {
      Logger.debug(`[EventLogger] Reusing cached request for ${label} ${batchId.slice(0, 8)}`);
      return cachedRequestId;
    }

    const existingInFlight = this.requestIdInFlight.get(batchId);

    if (existingInFlight) {
      Logger.debug(`[EventLogger] Waiting for in-flight /final-build request for ${label} ${batchId.slice(0, 8)}`);
      return existingInFlight;
    }

    const requestPromise = this.createRequestAndGetId(requestPayload)
      .then((apiResponse) => {
        if (!apiResponse.status || !apiResponse.requestId) {
          throw new Error('request_id missing or failed');
        }

        this.requestIdCache.set(batchId, apiResponse.requestId);
        Logger.log(`[EventLogger] Created new request for ${label} ${apiResponse.requestId}`);

        return apiResponse.requestId;
      })
      .finally(() => {
        this.requestIdInFlight.delete(batchId);
      });

    this.requestIdInFlight.set(batchId, requestPromise);

    return requestPromise;
  }

  private markBatchCompleted(batchId: string): void {
    if (!batchId) {
      return;
    }

    this.completedBatchIds.set(batchId, Date.now());
    this.cleanupCompletedBatchIds();
  }

  private isRecentlyCompletedBatch(batchId: string): boolean {
    if (!batchId) {
      return false;
    }

    this.cleanupCompletedBatchIds();

    const completedAt = this.completedBatchIds.get(batchId);

    if (!completedAt) {
      return false;
    }

    return Date.now() - completedAt <= EventLogger.COMPLETED_BATCH_TTL_MS;
  }

  private cleanupCompletedBatchIds(): void {
    const now = Date.now();

    for (const [batchId, completedAt] of this.completedBatchIds.entries()) {
      if (now - completedAt > EventLogger.COMPLETED_BATCH_TTL_MS) {
        this.completedBatchIds.delete(batchId);
      }
    }
  }

  private async createRequestAndGetId(payload: any): Promise<{ requestId: string; status: boolean }> {
    // Adoption signals. Added AFTER trimming so an oversized payload can never
    // drop them, and last so they cannot displace an existing key. Roughly 100 bytes, and every
    // /final-build call reaches the server through here, so no build path is missed.
    const body = { ...this.payloadBuilder.trimPayloadIfOversized(payload), ...collectUsageSignals() };

    const response = await this.apiService.post(
      this.createRequestPath,
      body,
      EventLogger.FINAL_BUILD_TIMEOUT_MS
    );

    const requestId = response?.request_id ?? '';
    const status = response?.status === true;

    if (status && typeof requestId === 'string' && requestId) {
      return { requestId, status };
    }

    return { requestId: '', status: false };
  }

  private async uploadArchivePayloads(input: {
    requestId: string;
    sendableChanges: any[];
    solution: any[];
    projectType: string;
    developerId: string;
  }): Promise<{ successCount: number; failureCount: number }> {
    let successCount = 0;
    let failureCount = 0;

    for (let index = 0; index < input.sendableChanges.length; index++) {
      const payload = input.sendableChanges[index];
      const payloadWithProjectType = {
        ...payload,
        solution: this.payloadBuilder.getSolutionSubsetForPayload(payload, input.solution),
        projectType: (payload?.projectType && String(payload.projectType).trim()) || input.projectType,
        developer_id: input.developerId,
      };

      const isLastRequest = index === input.sendableChanges.length - 1 ? 1 : 0;
      const apiUrl = `${this.finalBuildByRequestPath}/${input.requestId}/${isLastRequest}`;
      const fileLabel = payloadWithProjectType.fileName || 'unknown';
      const projectTypeLabel = payloadWithProjectType.projectType || 'unknown';
      // Body size of this single archive upload — the prime suspect for store failures
      // (large deleted files, 5 MB endpoint cap, timeouts).
      let payloadBytes = -1;
      try { payloadBytes = JSON.stringify(payloadWithProjectType).length; } catch { /* ignore */ }
      const total = input.sendableChanges.length;

      try {
        const response = await this.apiService.post(apiUrl, payloadWithProjectType);
        const isSuccess = response?.status === true;

        if (isSuccess) {
          successCount++;
          Logger.log(`[EventLogger] ${index + 1}/${total} Saved: ${fileLabel} [${projectTypeLabel}] (${payloadBytes} bytes)`);
        } else {
          failureCount++;
          let responsePreview = '';
          try { responsePreview = JSON.stringify(response).slice(0, 500); } catch { responsePreview = String(response); }
          Logger.log(`[EventLogger] ${index + 1}/${total} STORE FAILED: ${fileLabel}`, {
            requestId: input.requestId,
            file: fileLabel,
            action: payloadWithProjectType?.action,
            projectType: projectTypeLabel,
            payloadBytes,
            response: responsePreview,
          });
        }
      } catch (err: any) {
        failureCount++;
        Logger.log(`[EventLogger] ${index + 1}/${total} STORE ERROR: ${fileLabel}`, {
          requestId: input.requestId,
          file: fileLabel,
          action: payloadWithProjectType?.action,
          projectType: projectTypeLabel,
          payloadBytes,
          error: err?.message || String(err),
        });
      }
    }

    return { successCount, failureCount };
  }

  private async backupUploadedFiles(batchId: string, events: UploadableFileEvent[]): Promise<void> {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
      const batchFolder = path.join(this.binaryBackupDir, `${timestamp}_${batchId.slice(0, 8)}`);
      this.ensureDirectory(batchFolder);

      for (const event of events) {
        await this.backupSingleUploadedFile(batchFolder, event);
      }
    } catch {
      // Local backup is best-effort only.
    }
  }

  private async backupSingleUploadedFile(batchFolder: string, event: UploadableFileEvent): Promise<void> {
    const fileName = path.basename(event.absolutePath);
    const destinationName = event.action === 'deleted' ? `DELETED_${fileName}` : fileName;
    const destinationPath = path.join(batchFolder, destinationName);

    try {
      if (event.action === 'deleted' && event.fileContent) {
        await fs.promises.writeFile(destinationPath, event.fileContent);
        return;
      }

      if (event.action !== 'deleted' && fs.existsSync(event.absolutePath)) {
        await fs.promises.copyFile(event.absolutePath, destinationPath);
        return;
      }

      if (event.fileContent) {
        await fs.promises.writeFile(destinationPath, event.fileContent);
      }
    } catch {
      // Ignore individual backup failure.
    }
  }

  private attachErrorDetailsToEvents(events: FileChangeEvent[], allErrors: string[]): void {
    for (const event of events) {
      const existingMessages = (event.errorDetails ?? []).map((error) => error.message);
      const combinedMessages = [...existingMessages, ...allErrors];
      event.errorDetails = this.payloadBuilder.getUniqueErrorsWithoutTimestamp(combinedMessages);
    }
  }

  private async writeLocalAuditLogs(input: {
    date: string;
    finalPayload: any;
    requestPayload: any;
    allChangesFile: string;
  }): Promise<void> {
    const finalPayloadFile = path.join(this.logDir, `finalPayload_${input.date}.jsonl`);
    const solutionPayloadFile = path.join(this.logDir, `solution_${input.date}.jsonl`);

    await this.appendJsonLineBestEffort(finalPayloadFile, input.finalPayload);
    await this.appendJsonLineBestEffort(input.allChangesFile, input.finalPayload.all_changes ?? []);
    await this.appendJsonLineBestEffort(solutionPayloadFile, input.requestPayload);
  }

  private async appendJsonLineBestEffort(filePath: string, payload: any): Promise<void> {
    try {
      await fs.promises.appendFile(filePath, `${JSON.stringify(payload)}\n`, 'utf8');
    } catch {
      // Local audit log is best-effort only.
    }
  }

  private cleanupOldLocalLogsSometimes(): void {
    this.cleanupLocalUploadStorage();
    try {
      FileUtils.cleanupOldJsonlFiles(this.logDir, 5);
      FileUtils.cleanupOldFolders(this.binaryBackupDir, 5);
    } catch {
    }
  }

  private getTotalBytes(events: UploadableFileEvent[]): number {
    return events.reduce((sum, event) => {
      if (event.fileContent) {
        return sum + event.fileContent.length;
      }

      try {
        if (fs.existsSync(event.absolutePath)) {
          return sum + fs.statSync(event.absolutePath).size;
        }
      } catch {
        // ignore size read failure
      }

      return sum;
    }, 0);
  }

  private hasRealError(errors: Array<{ message: string }>): boolean {
    return errors.some((error) => String(error?.message || '').trim().length > 0);
  }

  private getCurrentProjectType(): string {
    const rootPath = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
    return rootPath ? FileUtils.detectProjectType(rootPath) : 'td5';
  }

  private ensureDirectory(directoryPath: string): void {
    try {
      if (!fs.existsSync(directoryPath)) {
        fs.mkdirSync(directoryPath, { recursive: true });
      }
    } catch {
      // Ignore disk full/read-only. Uploads should still proceed.
    }
  }
}