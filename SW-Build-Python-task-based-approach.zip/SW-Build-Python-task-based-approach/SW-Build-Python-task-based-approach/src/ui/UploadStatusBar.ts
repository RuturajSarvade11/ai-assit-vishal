import * as vscode from 'vscode';

/** Small status-bar indicator for uploads: uploads run in the
 *  BACKGROUND — the user never waits and never gets an interrupting window. This item is the
 *  only always-visible signal, like the VS Code update indicator at the bottom:
 *  uploading -> uploaded (auto-hides) -> or N upload(s) pending (stays until the saved data
 *  is delivered once the network is back). */
export class UploadStatusBar {
  private static item: vscode.StatusBarItem | null = null;
  private static hideTimer: ReturnType<typeof setTimeout> | null = null;
  private static lastToastKey = '';
  private static lastToastAt = 0;

  /** Small bottom-right toast, VS Code-update style: information severity with NO
   *  buttons, so it appears and auto-dismisses by itself — never blocks, never interrupts.
   *  Throttled per state so one upload (batch + artifacts + binaries) shows ONE toast, and a
   *  failure cascade (batch catch, then error-only catch) shows one, not three. */
  private static toast(key: string, message: string, minGapMs = 30000): void {
    const now = Date.now();
    if (this.lastToastKey === key && now - this.lastToastAt < minGapMs) { return; }
    this.lastToastKey = key;
    this.lastToastAt = now;
    void vscode.window.showInformationMessage(message);
  }

  private static ensure(): vscode.StatusBarItem {
    if (!this.item) {
      this.item = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 0);
    }
    if (this.hideTimer) { clearTimeout(this.hideTimer); this.hideTimer = null; }
    return this.item;
  }

  /** Fires the MOMENT the user clicks Confirm & Upload, as the popup closes:
   *  instant feedback that the upload runs in the background, before any network result
   *  exists — users who never open logs still see that something is happening. */
  public static uploadStarted(detail = ''): void {
    this.uploading(detail);
    this.toast('started', 'AI Build: uploading in the background — you will be notified when it completes.', 10000);
  }

  public static uploading(detail = ''): void {
    const item = this.ensure();
    item.text = '$(sync~spin) AI Build: uploading…';
    item.tooltip = `AI Assisted Build is uploading in the background${detail ? ` (${detail})` : ''}. You can keep working — no need to wait.`;
    item.show();
  }

  public static uploaded(detail = ''): void {
    const item = this.ensure();
    item.text = '$(check) AI Build: uploaded';
    item.tooltip = `Upload finished${detail ? ` (${detail})` : ''}.`;
    item.show();
    this.hideTimer = setTimeout(() => { this.item?.hide(); }, 15000);
    this.toast('uploaded', `AI Build: upload completed${detail ? ` — ${detail}` : ''} ✓`);
  }

  public static retryPending(count: number): void {
    if (count <= 0) { this.clear(); return; }
    const item = this.ensure();
    item.text = `$(cloud-upload) AI Build: ${count} upload${count === 1 ? '' : 's'} pending`;
    item.tooltip =
      'The server could not be reached (network/VPN?). Your data is SAVED on this machine and ' +
      'will be re-uploaded automatically when the connection is back — nothing is lost. ' +
      'Details: Ctrl+Shift+P → AI Assisted: Open Logs.';
    item.show();
    this.toast(
      'pending',
      'AI Build: server not reachable (network issue) — your upload is SAVED and will be sent automatically when the connection is back.'
    );
  }

  public static clear(): void {
    if (this.hideTimer) { clearTimeout(this.hideTimer); this.hideTimer = null; }
    this.item?.hide();
  }
}
