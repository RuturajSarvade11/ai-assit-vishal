import * as vscode from 'vscode';
import { ExtensionRuntime } from './ExtensionRuntime';

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  await ExtensionRuntime.activate(context);
}

export function deactivate(): void {
  ExtensionRuntime.deactivate();
}
