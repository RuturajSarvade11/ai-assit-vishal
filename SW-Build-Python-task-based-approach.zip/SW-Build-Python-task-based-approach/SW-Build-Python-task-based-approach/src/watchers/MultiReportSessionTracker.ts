import * as path from 'path';
import { Logger } from '../utils/Logger';
import { RawBuildError } from '../types/events';

export interface IErrorReconciler {
    reconcileErrors(
        errors: RawBuildError[],
        requestedTasks: string,
        taskStatuses?: Map<string, string>
    ): Promise<void>;
}

export class MultiReportSessionTracker {
    private readonly reportStates = new Map<string, RawBuildError[]>();
    private readonly reportTaskStatuses = new Map<string, Map<string, string>>();
    private parentReportPath: string | null = null;
    private parentRequestedTasks = '';
    private hasFlushedAllClear = false;
    private lastFlushedRequestedTasks = '';

    constructor(private readonly fileWatcher: IErrorReconciler) { }

    getReconcilerFor(reportPath: string): IErrorReconciler {
        return {
            reconcileErrors: (errors, tasks, taskStatuses) =>
                this.update(reportPath, errors, tasks, taskStatuses),
        };
    }

    removeReport(reportPath: string): void {
        this.reportStates.delete(reportPath);
        this.reportTaskStatuses.delete(reportPath);

        if (this.parentReportPath === reportPath) {
            this.parentReportPath = null;
            this.parentRequestedTasks = '';
            this.hasFlushedAllClear = false;
            this.lastFlushedRequestedTasks = '';
        }
    }

    resetParent(): void {
        if (this.parentReportPath) {
            Logger.log(`[MultiReport] Parent lock reset (new build cycle started) — was: ${path.basename(this.parentReportPath)}`);
        }

        this.parentReportPath = null;
        this.parentRequestedTasks = '';
        this.hasFlushedAllClear = false;
        this.lastFlushedRequestedTasks = '';
    }

    private async update(
        reportPath: string,
        errors: RawBuildError[],
        requestedTasks: string,
        taskStatuses?: Map<string, string>
    ): Promise<void> {
        const uniqueErrors = this.uniqueErrors(errors);
        this.reportStates.set(reportPath, uniqueErrors);
        this.reportTaskStatuses.set(reportPath, this.normalizeTaskStatuses(taskStatuses));

        if (uniqueErrors.length > 0 && !this.parentReportPath) {
            this.parentReportPath = reportPath;
            this.parentRequestedTasks = requestedTasks;
            this.hasFlushedAllClear = false;
            this.lastFlushedRequestedTasks = '';
        }

        const allClear = [...this.reportStates.values()].every(e => e.length === 0);
        const mergedTaskStatuses = this.mergeTaskStatuses();

        if (allClear) {
            if (this.hasFlushedAllClear && this.lastFlushedRequestedTasks === requestedTasks) {
                return;
            }

            this.hasFlushedAllClear = true;
            this.lastFlushedRequestedTasks = requestedTasks;

            const tasks = requestedTasks || this.parentRequestedTasks;
            this.parentReportPath = null;
            this.parentRequestedTasks = '';
            await this.fileWatcher.reconcileErrors([], tasks, mergedTaskStatuses);
            return;
        }

        const parentErrors = this.parentReportPath
            ? (this.reportStates.get(this.parentReportPath) ?? [])
            : [];

        if (uniqueErrors.length === 0 && parentErrors.length > 0) {
            // Do not swallow clean reports if they belong to a completely different task
            if (requestedTasks && requestedTasks !== this.parentRequestedTasks) {
                // Pass through
            } else {
                return;
            }
        }

        await this.fileWatcher.reconcileErrors(uniqueErrors, requestedTasks, mergedTaskStatuses);
    }

    private uniqueErrors(errors: RawBuildError[]): RawBuildError[] {
        const unique = new Map<string, RawBuildError>();

        for (const error of errors || []) {
            const message = String(error.message || '').trim();
            if (!message) { continue; }

            const taskPath = this.normalizeTaskKey(String(error.taskPath || '').trim());
            const key = [
                String(error.path || '').replace(/\\/g, '/').trim(),
                taskPath,
                message.replace(/\s+/g, ' ').trim().toLowerCase()
            ].join('|');

            if (!unique.has(key)) {
                unique.set(key, {
                    ...error,
                    message,
                    taskPath,
                });
            }
        }

        return Array.from(unique.values());
    }

    private normalizeTaskStatuses(taskStatuses?: Map<string, string>): Map<string, string> {
        const normalized = new Map<string, string>();

        if (!taskStatuses) {
            return normalized;
        }

        for (const [rawTaskKey, rawSeverity] of taskStatuses.entries()) {
            const taskKey = this.normalizeTaskKey(rawTaskKey);
            const severity = String(rawSeverity || '').trim().toUpperCase();

            if (!taskKey || !severity) { continue; }

            const existing = normalized.get(taskKey);
            if (!existing || this.getSeverityRank(severity) > this.getSeverityRank(existing)) {
                normalized.set(taskKey, severity);
            }
        }

        return normalized;
    }

    private mergeTaskStatuses(): Map<string, string> {
        const merged = new Map<string, string>();

        for (const statuses of this.reportTaskStatuses.values()) {
            for (const [taskKey, severity] of statuses.entries()) {
                const existing = merged.get(taskKey);
                if (!existing || this.getSeverityRank(severity) > this.getSeverityRank(existing)) {
                    merged.set(taskKey, severity);
                }
            }
        }

        return merged;
    }

    private normalizeTaskKey(taskKey: string): string {
        const value = String(taskKey || '').trim();
        if (!value) { return ''; }
        return value.startsWith(':') ? value : `:${value}`;
    }

    private getSeverityRank(severity: string): number {
        switch (String(severity || '').trim().toUpperCase()) {
            case 'ERROR': return 4;
            case 'WARNING': return 3;
            case 'ADVICE': return 2;
            case 'INFO': return 1;
            default: return 0;
        }
    }
}
