import * as fs from "fs";
import * as path from "path";
import * as crypto from "crypto";
import { Logger } from "../utils/Logger";
import { IErrorReconciler } from "./MultiReportSessionTracker";
import { RawBuildError } from "../types/events";

const CONTEXT_LINES_BEFORE_ERROR = 8;
const DEBOUNCE_DELAY_MS = 300;
const POLLING_INTERVAL_MS = 1200;
const STABLE_CHECK_INTERVAL_MS = 250;
const REQUIRED_STABLE_TICKS = 3;

export class TD5BuildLogWatcher {
    private watcher: fs.FSWatcher | undefined;
    private debounceTimer: NodeJS.Timeout | undefined;
    private fallbackTimer: NodeJS.Timeout | undefined;

    private processing = false;
    private lastErrorStateString = "";

    private lastSize = -1;
    private lastMtime = 0;
    private lastHash = "";
    private primed = false;

    constructor(
        private readonly logFilePath: string,
        private readonly reconciler: IErrorReconciler
    ) {
        Logger.debug(`[TD5BuildLogWatcher] Watching: ${this.logFilePath}`);

        if (fs.existsSync(this.logFilePath)) {
            this.initializeState();
        }

        this.startFSWatcher();
        this.startPollingWatcher();
    }

    private initializeState(): void {
        try {
            const stat = fs.statSync(this.logFilePath);
            this.lastSize = stat.size;
            this.lastMtime = stat.mtimeMs;
        } catch {
            // Ignore initialization race.
        }

        this.computeHash(this.logFilePath).then((hash) => {
            this.lastHash = hash;
            this.primed = true;
        });
    }

    private startFSWatcher(): void {
        if (!fs.existsSync(this.logFilePath)) {
            return;
        }

        try {
            this.watcher = fs.watch(this.logFilePath, () => {
                this.scheduleProcessing();
            });
        } catch (error) {
            if ((error as NodeJS.ErrnoException)?.code !== "ENOENT") {
                Logger.log("[TD5BuildLogWatcher] fs.watch failed", error);
            }
        }
    }

    private startPollingWatcher(): void {
        this.fallbackTimer = setInterval(async () => {
            if (!fs.existsSync(this.logFilePath)) {
                return;
            }

            let stat: fs.Stats;

            try {
                stat = fs.statSync(this.logFilePath);
            } catch {
                return;
            }

            const newSize = stat.size;
            const newMtime = stat.mtimeMs;
            const newHash = await this.computeHash(this.logFilePath);

            if (!this.primed) {
                this.lastSize = newSize;
                this.lastMtime = newMtime;
                this.lastHash = newHash;
                this.primed = true;
                return;
            }

            if (this.hasFileChanged(newSize, newMtime, newHash)) {
                // State is updated by processIfContentChanged (the debounced gate) — updating it
                // here as well would make the gate see "no change" and drop the build event.
                this.scheduleProcessing();
            }
        }, POLLING_INTERVAL_MS);
    }

    private scheduleProcessing(): void {
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }

        this.debounceTimer = setTimeout(() => {
            void this.processIfContentChanged();
        }, DEBOUNCE_DELAY_MS);
    }

    /** Parse ONLY content that changed after registration. fs.watch fires on any file touch
     *  (indexer/antivirus), which replayed months-old variant logs as fresh builds at startup —
     *  the stale failure OPENED the error cycle and ITS error got uploaded instead of the real
     *  one (Copy_PrePro_Files was stored while TestEnv_10 actually failed).
     *  The poller already gates on size/mtime/hash; the fs.watch path now gates identically. */
    private async processIfContentChanged(): Promise<void> {
        try {
            if (!fs.existsSync(this.logFilePath)) { return; }
            const stat = fs.statSync(this.logFilePath);
            const hash = await this.computeHash(this.logFilePath);
            if (!this.primed) {
                this.lastSize = stat.size;
                this.lastMtime = stat.mtimeMs;
                this.lastHash = hash;
                this.primed = true;
                return;
            }
            if (!this.hasFileChanged(stat.size, stat.mtimeMs, hash)) {
                Logger.debug(`[TD5BuildLogWatcher] touch without content change ignored: ${path.basename(this.logFilePath)}`);
                return;
            }
            this.lastSize = stat.size;
            this.lastMtime = stat.mtimeMs;
            this.lastHash = hash;
        } catch {
            return;
        }
        await this.processLogSafe(this.logFilePath);
    }

    private hasFileChanged(size: number, mtime: number, hash: string): boolean {
        return size !== this.lastSize || mtime !== this.lastMtime || hash !== this.lastHash;
    }

    private computeHash(filePath: string): Promise<string> {
        return new Promise((resolve) => {
            try {
                const hash = crypto.createHash("md5");
                const stream = fs.createReadStream(filePath, {
                    highWaterMark: 1024 * 1024,
                });

                stream.on("data", (chunk) => hash.update(chunk));
                stream.on("end", () => resolve(hash.digest("hex")));
                stream.on("error", () => resolve(""));
            } catch {
                resolve("");
            }
        });
    }

    private waitUntilStable(filePath: string): Promise<void> {
        return new Promise((resolve) => {
            let lastSize = -1;
            let stableTicks = 0;

            const timer = setInterval(() => {
                if (!fs.existsSync(filePath)) {
                    clearInterval(timer);
                    resolve();
                    return;
                }

                let currentSize = -1;

                try {
                    currentSize = fs.statSync(filePath).size;
                } catch {
                    clearInterval(timer);
                    resolve();
                    return;
                }

                if (currentSize === lastSize) {
                    stableTicks++;

                    if (stableTicks >= REQUIRED_STABLE_TICKS) {
                        clearInterval(timer);
                        resolve();
                    }
                } else {
                    stableTicks = 0;
                }

                lastSize = currentSize;
            }, STABLE_CHECK_INTERVAL_MS);
        });
    }

    private async processLogSafe(filePath: string): Promise<void> {
        if (this.processing) {
            return;
        }

        this.processing = true;

        try {
            await this.waitUntilStable(filePath);

            const content = this.safeReadLogFile(filePath);

            if (!content || content.trim().length === 0) {
                return;
            }

            const terminalStatus = this.extractTerminalStatus(content);
            if (!terminalStatus) {
                return;
            }

            const requestedTasks = this.extractRequestedTasks(content);
            const logName = path.basename(filePath);

            if (terminalStatus === "SUCCESS") {
                await this.handleSuccessState(logName, requestedTasks);
                return;
            }

            await this.handleFailedState(content, logName, requestedTasks);
        } catch (error) {
            Logger.log("[TD5BuildLogWatcher] Processor error", error);
        } finally {
            this.processing = false;
        }
    }

    private safeReadLogFile(filePath: string): string {
        try {
            return fs.readFileSync(filePath, "utf8");
        } catch (error) {
            if ((error as NodeJS.ErrnoException)?.code !== "ENOENT") {
                Logger.log("[TD5BuildLogWatcher] Failed to read log file", error);
            }

            return "";
        }
    }

    private extractTerminalStatus(content: string): "SUCCESS" | "FAILED" | null {
        const terminalMatch = content.match(/(?:Build|Buildprj)\s+Status:\s*(SUCCESS|FAILED)/i);

        if (!terminalMatch) {
            return null;
        }

        return terminalMatch[1].toUpperCase() === "SUCCESS" ? "SUCCESS" : "FAILED";
    }

    private async handleSuccessState(
        logName: string,
        requestedTasks: string
    ): Promise<void> {
        const newState = "SUCCESS";

        if (newState === this.lastErrorStateString) {
            return;
        }

        this.lastErrorStateString = newState;

        Logger.log(`[TD5] Build SUCCESS — ${logName} | entering standard success pipeline`);
        await this.reconciler.reconcileErrors([], requestedTasks);
    }

    private async handleFailedState(
        content: string,
        logName: string,
        requestedTasks: string
    ): Promise<void> {
        const errors = this.extractErrors(content);
        const newState = JSON.stringify(errors);

        if (newState === this.lastErrorStateString) {
            return;
        }

        this.lastErrorStateString = newState;

        const taskPath = errors[0]?.taskPath || "unknown process";

        // For TD5 the confirm webview shows the LAST build failure — the
        // log's tail lines carry the actual cause (the [ERR!] tool-init lines higher up are
        // noise the build survived). Attached display-only; stored errors stay unchanged.
        if (errors.length > 0) {
            errors[0].failureTail = this.buildFailureTail(content);
        }

        Logger.log(`[TD5] Build FAILED — ${logName} | ${errors.length} error(s) in [${taskPath}]`);
        await this.reconciler.reconcileErrors(errors, requestedTasks);
    }

    /** Last ~15 meaningful lines of the log (separator-only lines dropped), bottom-up — these
     *  mostly tell why the build failed and the actual error. */
    private buildFailureTail(content: string, maxLines = 15): string {
        const meaningful = content
            .replace(/\r\n/g, "\n")
            .split("\n")
            .filter((line) => {
                const bare = line.trim().replace(/^\[[^\]]+\]\s*/, "");
                if (!bare) { return false; }              // blank / tag-only lines
                return !/^[-+=]{8,}$/.test(bare);         // [INFO] ----- separator rows
            });
        return meaningful.slice(-maxLines).join("\n").slice(0, 6000);
    }

    private extractRequestedTasks(content: string): string {
        const targetMatch = content.match(/\[INFO\]\s+Build\s+\[([^\]]+)\]/);
        const typeMatch = content.match(/\[INFO\]\s+-\s+Build Type\s*:\s*(\S+)/);

        return [targetMatch?.[1], typeMatch?.[1]]
            .filter(Boolean)
            .join(" ");
    }

    private extractErrors(content: string): RawBuildError[] {
        const lines = content.split(/\r?\n/);
        const errors: RawBuildError[] = [];
        const seen = new Set<string>();

        // Find where tool-init ends so we can skip init-phase [ERR!] lines.
        const initDoneIdx = lines.findIndex((line) =>
            line.includes("Finished initializing tools")
        );

        for (let i = 0; i < lines.length; i++) {
            if (!lines[i].includes("[ERR!]")) {
                continue;
            }
            if (initDoneIdx > 0 && i < initDoneIdx) {
                continue;
            }

            const message = this.extractErrorBlock(lines, i);

            if (!message || seen.has(message)) {
                continue;
            }

            seen.add(message);

            errors.push({
                path: this.logFilePath,
                message,
                taskPath: this.extractTaskPath(lines, i),
            });
        }

        return errors;
    }

    private extractErrorBlock(lines: string[], errorLineIndex: number): string {
        const contextStart = Math.max(0, errorLineIndex - CONTEXT_LINES_BEFORE_ERROR);
        const block = lines.slice(contextStart, errorLineIndex + 1);

        let index = errorLineIndex + 1;

        while (
            index < lines.length &&
            lines[index].trim().length > 0 &&
            !this.isTimestampedLogLine(lines[index])
        ) {
            block.push(lines[index]);
            index++;
        }

        return block.join("\n").trim();
    }

    private isTimestampedLogLine(line: string): boolean {
        return /\d{2}:\d{2}:\d{2}:\d{3}\s+\[/.test(line);
    }

    private extractTaskPath(lines: string[], errLineIdx: number): string {
        for (let i = errLineIdx; i >= 0; i--) {
            const match = lines[i].match(/Executing\s+\[([^\]]+)\]\s+build process/);

            if (match) {
                return match[1];
            }
        }

        return "";
    }

    public dispose(): void {
        this.watcher?.close();

        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }

        if (this.fallbackTimer) {
            clearInterval(this.fallbackTimer);
        }
    }
}