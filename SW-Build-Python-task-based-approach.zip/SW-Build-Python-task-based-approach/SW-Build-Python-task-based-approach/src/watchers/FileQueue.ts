import { Logger } from "../utils/Logger";

export class JobQueue {
    private queues = new Map<string, Promise<void>>();

    enqueue(filePath: string, task: () => Promise<void>): Promise<void> {
        const prev = this.queues.get(filePath) || Promise.resolve();

        const safeTask = async () => {
            try {
                await Promise.resolve(task());
            } catch (err) {
                Logger.log(`[JobQueue] Task failed for ${filePath}`, err);
            }
        };

        const next = prev.catch(err => {
            Logger.log(`[JobQueue] Previous task failed for ${filePath}`, err);
        })
            .then(safeTask)
            .catch(err => {
                Logger.log(`[JobQueue] Chained task failed for ${filePath}`, err);
            });

        this.queues.set(filePath, next);

        next.finally(() => {
            if (this.queues.get(filePath) === next) {
                this.queues.delete(filePath);
            }
        });

        return next;
    }
}