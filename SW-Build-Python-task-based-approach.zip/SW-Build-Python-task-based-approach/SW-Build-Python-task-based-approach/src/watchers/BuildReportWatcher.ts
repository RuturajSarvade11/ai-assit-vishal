import * as fs from "fs";
import * as crypto from "crypto";
import { Logger } from "../utils/Logger";
import { IErrorReconciler } from "./MultiReportSessionTracker";

type ExtractedGradleError = {
    path: string;
    message: string;
    taskPath: string;
    severity?: string;
};

type ExtractErrorsResult = {
    errors: ExtractedGradleError[];
    requestedTasks: string;
    severityCounts: Record<string, number>;
    taskStatuses: Record<string, string>;
};

export class BuildReportWatcher {
    private static readonly lastProcessedStateByPath = new Map<string, string>();

    private watcher: fs.FSWatcher | undefined;
    private debounceTimer: NodeJS.Timeout | undefined;
    private fallbackTimer: NodeJS.Timeout | undefined;

    private ready = false;
    private disposed = false;
    private processing = false;
    private pendingReprocess = false;
    private lastErrorStateString = "";

    private lastSize = -1;
    private lastMtime = 0;
    private lastHash = "";

    /** Last SHAPE line printed — identical re-parses within a minute go to debug. */
    private lastShapeLine = "";
    private lastShapeLineAt = 0;

    constructor(private reportFilePath: string, private fileWatcher: IErrorReconciler) {
        Logger.debug(`[BuildReportWatcher] Watching: ${this.reportFilePath}`);
        this.initialize();
    }

    private async initialize() {
        if (this.disposed) { return; }

        if (fs.existsSync(this.reportFilePath)) {
            try {
                const stat = fs.statSync(this.reportFilePath);
                this.lastSize = stat.size;
                this.lastMtime = stat.mtimeMs;
            } catch { }
            this.lastHash = await this.computeFullFileHash(this.reportFilePath);
        }

        this.ready = true;
        this.startFSWatcher();
        this.startPollingWatcher();

        if (fs.existsSync(this.reportFilePath)) {
            void this.processReportSafe(this.reportFilePath);
        }
    }

    private startFSWatcher() {
        if (this.disposed || !fs.existsSync(this.reportFilePath)) { return; }

        try {
            this.watcher = fs.watch(this.reportFilePath, () => {
                if (this.disposed) { return; }
                if (this.debounceTimer) { clearTimeout(this.debounceTimer); }

                this.debounceTimer = setTimeout(() => {
                    if (this.disposed) { return; }
                    this.processReportSafe(this.reportFilePath);
                }, 300);
            });
        } catch (err) {
            Logger.log("[BuildReportWatcher] fs.watch failed", err);
        }
    }

    private computeFullFileHash(path: string): Promise<string> {
        return new Promise((resolve) => {
            try {
                const hash = crypto.createHash("md5");
                const stream = fs.createReadStream(path, { highWaterMark: 1024 * 1024 });

                stream.on("data", (chunk) => hash.update(chunk));
                stream.on("end", () => resolve(hash.digest("hex")));
                stream.on("error", () => resolve(""));
            } catch {
                resolve("");
            }
        });
    }

    private startPollingWatcher() {
        this.fallbackTimer = setInterval(async () => {
            if (this.disposed) { return; }
            if (!this.ready) { return; }
            if (!fs.existsSync(this.reportFilePath)) { return; }
            if (!this.watcher) { this.startFSWatcher(); }

            const stat = fs.statSync(this.reportFilePath);
            const newSize = stat.size;
            const newMtime = stat.mtimeMs;
            const newHash = await this.computeFullFileHash(this.reportFilePath);

            if (newSize !== this.lastSize || newMtime !== this.lastMtime || newHash !== this.lastHash) {
                this.lastSize = newSize;
                this.lastMtime = newMtime;
                this.lastHash = newHash;

                this.processReportSafe(this.reportFilePath);
            }
        }, 1200);
    }

    private async waitUntilStable(path: string) {
        return new Promise((resolve) => {
            let last = -1;
            let stable = 0;
            let ticks = 0;

            const timer = setInterval(() => {
                ticks++;
                if (!fs.existsSync(path)) {
                    clearInterval(timer);
                    return resolve(true);
                }

                const size = fs.statSync(path).size;

                if (size === last) {
                    stable++;
                    if (stable >= 3) {
                        clearInterval(timer);
                        resolve(true);
                    }
                } else {
                    stable = 0;
                }

                last = size;

                // Safety timeout — never block processing forever.
                if (ticks > 40) {
                    clearInterval(timer);
                    resolve(true);
                }
            }, 250);
        });
    }

    private async processReportSafe(path: string) {
        if (this.disposed) {
            return;
        }

        if (this.processing) {
            this.pendingReprocess = true;
            return;
        }
        this.processing = true;

        try {
            await this.waitUntilStable(path);

            const script = await this.extractScriptBlock(path);
            if (!script || script.length < 20) {
                Logger.log('[BuildReportWatcher] SHAPE: report file has no configurationCacheProblems script block — skipped (report format may have changed)');
                return;
            }

            const jsonString = this.extractJson(script);
            if (!jsonString) {
                Logger.log("[BuildReportWatcher] JSON block missing");
                return;
            }

            let json: any;
            try {
                json = JSON.parse(jsonString);
            } catch (err) {
                Logger.log("[BuildReportWatcher] JSON parse failed", err);
                return;
            }

            const result = this.extractErrors(json);
            const finalErrors = this.normalizeErrors(result.errors);
            const normalizedTaskStatuses = this.normalizeTaskStatuses(result.taskStatuses);

            const newState = JSON.stringify({
                errors: finalErrors,
                taskStatuses: normalizedTaskStatuses,
            });

            const lastProcessedState = BuildReportWatcher.lastProcessedStateByPath.get(this.reportFilePath) || "";
            if (newState === this.lastErrorStateString || newState === lastProcessedState) { return; }

            await this.fileWatcher.reconcileErrors(
                finalErrors,
                result.requestedTasks,
                new Map(Object.entries(normalizedTaskStatuses))
            );
            this.lastErrorStateString = newState;
            BuildReportWatcher.lastProcessedStateByPath.set(this.reportFilePath, newState);

        } catch (err) {
            Logger.log("[BuildReportWatcher] Processor error", err);
        } finally {
            this.processing = false;

            if (!this.disposed && this.pendingReprocess) {
                this.pendingReprocess = false;
                setImmediate(() => this.processReportSafe(path));
            }
        }
    }

    private extractScriptBlock(path: string): Promise<string> {
        return new Promise((resolve) => {
            const stream = fs.createReadStream(path, {
                encoding: "utf8",
                highWaterMark: 1024 * 1024,
            });

            let buf = "";
            let capturing = false;

            stream.on("data", (raw: string | Buffer) => {
                const chunk = typeof raw === "string" ? raw : raw.toString("utf8");
                buf += chunk;

                if (!capturing) {
                    const start = buf.indexOf("function configurationCacheProblems");
                    if (start !== -1) {
                        capturing = true;
                        buf = buf.slice(start);
                    } else if (buf.length > 8000) {
                        buf = buf.slice(-8000);
                    }
                }

                if (capturing) {
                    const end = buf.indexOf("</script>");
                    if (end !== -1) {
                        stream.close();
                        return resolve(buf.slice(0, end));
                    }
                }
            });

            stream.on("end", () => resolve(buf));
            stream.on("error", () => resolve(""));
        });
    }

    private extractJson(script: string): string | null {
        const regex =
            /function\s+configurationCacheProblems\s*\(\)\s*{\s*return\s*\(\s*([\s\S]*?)\s*\);\s*}/m;

        const match = script.match(regex);
        if (match && match[1]) {
            return match[1]
                .replace(/^\s*\/\/.*$/gm, "") // remove line comments
                .replace(/\/\*[\s\S]*?\*\//g, "") // remove block comments
                .replace(/,\s*([}\]])/g, "$1") // trailing commas
                .trim();
        }

        // 2) NEW FORMAT — large report:
        // // begin-report-data
        // { JSON here }
        const startKey = "// begin-report-data";
        const idx = script.indexOf(startKey);
        if (idx !== -1) {
            const jsonPart = script
                .slice(idx + startKey.length)
                .replace(/^\s*\/\/.*$/gm, "")
                .trim();

            // find first JSON object
            const startBrace = jsonPart.indexOf("{");
            const endBrace = jsonPart.lastIndexOf("}");

            if (startBrace !== -1 && endBrace !== -1) {
                return jsonPart.slice(startBrace, endBrace + 1);
            }
        }

        return null;
    }

    private extractErrors(data: any): ExtractErrorsResult {
        const result: ExtractErrorsResult = {
            errors: [],
            requestedTasks: '',
            severityCounts: {},
            taskStatuses: {},
        };

        if (!data || !Array.isArray(data.diagnostics)) {
            Logger.log('[BuildReportWatcher] SHAPE: report has no diagnostics array — treated as no-evidence (nothing captured, nothing resolved)');
            return result;
        }

        if (data?.problemsReport?.requestedTasks) {
            result.requestedTasks = String(data.problemsReport.requestedTasks || '').trim();
        }

        // Defensive-contract counters: every degraded/unknown shape is counted and logged below,
        // so when a future Gradle/GBE version changes the report, field logs identify it directly.
        const KNOWN_SEVERITIES = new Set(['ERROR', 'WARNING', 'ADVICE', 'INFO']);
        const unknownSeverities = new Set<string>();
        let rescuedNoSeverity = 0;
        let errorsWithoutTaskPath = 0;

        for (const diag of data.diagnostics) {
            let severity = this.normalizeSeverity(diag?.severity);

            // Never drop a failure: a diagnostic with no severity but carrying error evidence
            // (an `error` object, as GBE emits for failed process executions) IS a failure.
            if (!severity && diag?.error) {
                severity = 'ERROR';
                rescuedNoSeverity++;
            }
            if (severity && !KNOWN_SEVERITIES.has(severity)) {
                unknownSeverities.add(severity);
            }

            if (severity) {
                result.severityCounts[severity] = (result.severityCounts[severity] || 0) + 1;
            }

            const taskPath = this.extractTaskPath(diag);

            if (taskPath && severity) {
                this.setTaskStatus(result.taskStatuses, taskPath, severity);
            }


            if (severity !== 'ERROR') { continue; }

            if (!taskPath) { errorsWithoutTaskPath++; }

            const paths = this.extractDiagnosticPaths(diag);
            const messages = this.extractDiagnosticMessages(diag);

            for (const message of messages) {
                for (const p of paths) {
                    result.errors.push({
                        path: p,
                        message,
                        taskPath,
                        severity,
                    });
                }
            }
        }

        // One shape-telemetry line per parsed report. Degradations are non-fatal by design:
        // no taskPath -> error grouped under the unknown-task session; unknown severity -> counted
        // in statuses but NEVER resolves a pending task; no requestedTasks -> resolution falls
        // back to per-task severity evidence only.
        const shapeLine =
            `[BuildReportWatcher] SHAPE: diags=${data.diagnostics.length}, errors=${result.errors.length}, ` +
            `statuses=${Object.keys(result.taskStatuses).length}, requestedTasks=${result.requestedTasks ? `'${result.requestedTasks}'` : 'MISSING'}` +
            (rescuedNoSeverity ? `, rescuedNoSeverityErrors=${rescuedNoSeverity}` : '') +
            (errorsWithoutTaskPath ? `, errorsWithoutTaskPath=${errorsWithoutTaskPath} (grouped under unknown-task)` : '') +
            (unknownSeverities.size ? `, UNKNOWN severities=[${Array.from(unknownSeverities).join(', ')}] (never resolve tasks)` : '');
        // Gradle writes report.html several times per build — an identical shape moments later
        // is the same report re-parsed, not a new build. Repeats go to debug to keep the story clean.
        const nowMs = Date.now();
        if (shapeLine === this.lastShapeLine && (nowMs - this.lastShapeLineAt) < 60000) {
            Logger.debug(`${shapeLine} (repeat parse)`);
        } else {
            this.lastShapeLine = shapeLine;
            this.lastShapeLineAt = nowMs;
            Logger.log(shapeLine);
        }

        return result;
    }

    private normalizeErrors(errors: ExtractedGradleError[]): ExtractedGradleError[] {
        const unique = new Map<string, ExtractedGradleError>();

        for (const error of errors || []) {
            const normalizedError: ExtractedGradleError = {
                path: typeof error.path === 'string' ? error.path.replace(/\\/g, '/').trim() : '',
                message: String(error.message || '').trim(),
                taskPath: typeof error.taskPath === 'string' ? this.normalizeTaskPath(error.taskPath) : '',
                severity: this.normalizeSeverity(error.severity || 'ERROR'),
            };

            if (!normalizedError.message) { continue; }

            const key = [
                normalizedError.path,
                normalizedError.taskPath,
                this.normalizeMessageKey(normalizedError.message),
            ].join('|');

            if (!unique.has(key)) {
                unique.set(key, normalizedError);
            }
        }

        return Array.from(unique.values()).sort((a, b) =>
            `${a.path}|${a.taskPath}|${a.message}`.localeCompare(`${b.path}|${b.taskPath}|${b.message}`)
        );
    }

    private normalizeTaskStatuses(statuses: Record<string, string>): Record<string, string> {
        const normalized: Record<string, string> = {};

        for (const [taskPath, severity] of Object.entries(statuses || {})) {
            const normalizedTask = this.normalizeTaskPath(taskPath);
            const normalizedSeverity = this.normalizeSeverity(severity);

            if (!normalizedTask || !normalizedSeverity) { continue; }

            const existing = normalized[normalizedTask];
            if (!existing || this.getSeverityRank(normalizedSeverity) > this.getSeverityRank(existing)) {
                normalized[normalizedTask] = normalizedSeverity;
            }
        }

        return normalized;
    }

    private setTaskStatus(statuses: Record<string, string>, taskPath: string, severity: string): void {
        const normalizedTask = this.normalizeTaskPath(taskPath);
        const normalizedSeverity = this.normalizeSeverity(severity);

        if (!normalizedTask || !normalizedSeverity) { return; }

        const existing = statuses[normalizedTask];
        if (!existing || this.getSeverityRank(normalizedSeverity) > this.getSeverityRank(existing)) {
            statuses[normalizedTask] = normalizedSeverity;
        }
    }

    private getSeverityRank(severity: string): number {
        switch (this.normalizeSeverity(severity)) {
            case 'ERROR': return 4;
            case 'WARNING': return 3;
            case 'ADVICE': return 2;
            case 'INFO': return 1;
            default: return 0;
        }
    }

    private extractTaskPath(diag: any): string {
        if (typeof diag?.taskPath === 'string' && diag.taskPath.trim()) {
            return this.normalizeTaskPath(diag.taskPath);
        }

        if (typeof diag?.task === 'string' && diag.task.trim()) {
            return this.normalizeTaskPath(diag.task);
        }

        if (Array.isArray(diag?.locations)) {
            for (const loc of diag.locations) {
                if (typeof loc?.taskPath === 'string' && loc.taskPath.trim()) {
                    return this.normalizeTaskPath(loc.taskPath);
                }

                if (typeof loc?.task === 'string' && loc.task.trim()) {
                    return this.normalizeTaskPath(loc.task);
                }
            }
        }

        return '';
    }

    private extractDiagnosticPaths(diag: any): string[] {
        const paths = new Set<string>();

        if (typeof diag?.path === 'string' && diag.path.trim()) {
            paths.add(diag.path.replace(/\\/g, '/').trim());
        }

        if (typeof diag?.filePath === 'string' && diag.filePath.trim()) {
            paths.add(diag.filePath.replace(/\\/g, '/').trim());
        }

        if (Array.isArray(diag?.locations)) {
            for (const loc of diag.locations) {
                if (typeof loc?.path === 'string' && loc.path.trim()) {
                    paths.add(loc.path.replace(/\\/g, '/').trim());
                }

                if (typeof loc?.filePath === 'string' && loc.filePath.trim()) {
                    paths.add(loc.filePath.replace(/\\/g, '/').trim());
                }
            }
        }

        return paths.size > 0 ? Array.from(paths) : ['<unknown>'];
    }

    private extractDiagnosticMessages(diag: any): string[] {
        const sections: string[] = [];

        this.appendTextSection(sections, diag?.message);
        this.appendTextSection(sections, diag?.problem);
        this.appendTextSection(sections, diag?.details);
        this.appendTextSection(sections, diag?.error?.message);
        this.appendTextArraySection(sections, diag?.problemDetails);
        this.appendTextArraySection(sections, diag?.error?.parts);

        // Do not include solutions here. Recommendation/solution text should not
        // become part of the failed task error sent to backend.
        const uniqueLines = this.dedupeMessageLines(sections);
        // Gradle 9.x/GBE puts the failing process's ENTIRE log into problemDetails, so the
        // captured error starts with tool-setup noise ("Creating snapshot for [7-zip]...",
        // "... is UP-TO-DATE"). Strip only those known setup/progress lines — every other
        // line is kept verbatim. If nothing but noise remains, keep the original text so an
        // error is never dropped entirely.
        const meaningfulLines = this.stripGbeSetupNoiseLines(uniqueLines);
        const combined = (meaningfulLines.join('\n') || uniqueLines.join('\n')).trim();

        return [combined || 'Gradle task failed'];
    }

    // Known GBE tool-setup/progress lines (never actual failure text). Anchored + conservative:
    // anything that does not match EXACTLY stays in the captured error.
    private static readonly GBE_SETUP_NOISE_PATTERNS: RegExp[] = [
        /^Creating snapshot for \[[^\]]*\]\.?$/i,
        /^Created\s+snapshot for \[[^\]]*\] in \[[^\]]*\] ms\.?$/i,
        /^Created inputs snapshot in \[[^\]]*\] ms\.?$/i,
        /^Copied input files in \[[^\]]*\] ms\.?$/i,
        /^Local installation of tool .* is UP-TO-DATE\.?$/i,
        /^Finished installing all relevant tools for the GBE process .*$/i,
        /^\S+ finished in \d+ ms\.?$/i,
    ];

    private stripGbeSetupNoiseLines(lines: string[]): string[] {
        const kept = lines.filter(
            (line) => !BuildReportWatcher.GBE_SETUP_NOISE_PATTERNS.some((rx) => rx.test(line.trim()))
        );
        if (kept.length !== lines.length) {
            Logger.debug(`[BuildReportWatcher] Stripped ${lines.length - kept.length} GBE setup/progress noise lines from captured error (${kept.length} lines kept)`);
        }
        return kept;
    }

    private appendTextSection(sections: string[], value: any): void {
        if (typeof value === 'string' && value.trim()) {
            sections.push(value.trim());
        }
    }

    private appendTextArraySection(sections: string[], value: any): void {
        // Gradle 9.x emits problemDetails as a single multi-line STRING (the real [ERROR] line is
        // inside it); Gradle 8.x emits a list of {text} dicts. Handle both so we never drop the
        // actual error text. (error.parts stays an array — unaffected by the string branch.)
        if (typeof value === 'string') {
            if (value.trim()) { sections.push(value.trim()); }
            return;
        }

        if (!Array.isArray(value)) { return; }

        for (const item of value) {
            const text = typeof item === 'string' ? item : item?.text;
            if (typeof text === 'string' && text.trim()) {
                sections.push(text.trim());
            }
        }
    }

    private dedupeMessageLines(sections: string[]): string[] {
        const lines: string[] = [];
        const seen = new Set<string>();

        for (const section of sections) {
            for (const raw of String(section || '').replace(/\r\n/g, '\n').split('\n')) {
                const line = raw.trim();
                const key = this.normalizeMessageKey(line);

                if (!line || seen.has(key)) { continue; }
                seen.add(key);
                lines.push(line);
            }
        }

        return lines;
    }

    private normalizeMessageKey(message: string): string {
        return String(message || '')
            .replace(/\r\n/g, '\n')
            .replace(/\s+/g, ' ')
            .replace(/\[[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?\]/g, '')
            .trim()
            .toLowerCase();
    }

    private normalizeTaskPath(rawTaskPath: string): string {
        const value = String(rawTaskPath || '').trim();
        if (!value) { return ''; }
        return value.startsWith(':') ? value : `:${value}`;
    }

    private normalizeSeverity(rawSeverity: any): string {
        return String(rawSeverity || '').trim().toUpperCase();
    }

    dispose() {
        this.disposed = true;
        this.watcher?.close();
        if (this.debounceTimer) { clearTimeout(this.debounceTimer); }
        if (this.fallbackTimer) { clearInterval(this.fallbackTimer); }
    }
}
