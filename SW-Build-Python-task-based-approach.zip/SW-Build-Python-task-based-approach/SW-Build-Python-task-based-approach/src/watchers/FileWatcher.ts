import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import * as vscode from 'vscode';
import * as chokidar from 'chokidar';
import { JobQueue } from './FileQueue';
import { Logger } from '../utils/Logger';
import { UploadStatusBar } from '../ui/UploadStatusBar';
import { FileUtils } from '../utils/FileUtils';
import { FileHandlingConfig } from '../utils/FileHandlingConfig';
import { LRUCache } from '../utils/LRUCache';
import { DiskBackedBufferCache, DiskBackedTextCache } from '../session/DiskBackedContentCache';
import { Telemetry } from '../utils/Telemetry';
import { DiffParser } from '../utils/DiffParser';
import { EventLogger } from '../data/EventLogger';
import { ApiService } from '../services/api.service';
import { reportBuildOutcome } from '../data/UsagePing';
import { DiffGenerator } from '../processors/DiffGenerator';
import { SnapshotManager } from '../processors/SnapshotManager';
import { ErrorSession, FileChangeEvent, LineChange } from '../types/events';
import { renderRecommendationMarkdown } from '../utils/RecommendationFormat';
import { collectUsageSignals } from '../data/UsageSignals';
import { PredictionRiskAnalyzer } from '../prediction/PredictionRiskAnalyzer';
import { RuntimeArtifactCollector } from '../artifacts/RuntimeArtifactCollector';
import { ArtifactConfigService } from '../artifacts/ArtifactConfigService';
import { TrackingConfigService } from '../utils/TrackingConfigService';
import { ChangeStore } from '../session/ChangeStore';
import { TaskBasedErrorSessionManager } from '../session/TaskBasedErrorSessionManager';
import { BuildError, FileChangeRecord, FileKey, ResolvedTaskPackage, TaskSession, TaskTextChangeSnapshot, groupBuildErrorsByTask } from '../session/TaskSessionTypes';
import { DiskBackedTrackingStore, SessionTextSnapshot, TrackingSessionDescriptor, TrackingSessionInfo } from '../session/DiskBackedTrackingStore';
import { UploadPreviewPanel } from '../webviews/UploadPreviewPanel';

type RawBuildError = {
  path: string;
  message: string;
  taskPath?: string;
  /** TD5 only: the failing build's log tail, display-only (see types/events.ts). */
  failureTail?: string;
};

type BinaryEvent = {
  filePath: string;
  absolutePath: string;
  action: 'added' | 'modified' | 'deleted';
  fileContent?: Buffer;
  projectName?: string;
};

export class FileWatcher {
  private static readonly FILE_STABILITY_THRESHOLD = 300;
  private static readonly FILE_POLL_INTERVAL = 100;
  private static readonly MAX_MEMORY_CACHE_SIZE = 500; // Max 500 file contents in memory
  private static readonly MAX_MEMORY_CACHE_BYTES = 25 * 1024 * 1024; // Cap cached text content to 25MB total
  private static readonly MAX_BINARY_HASH_CACHE_SIZE = 200; // Max 200 binary file hashes
  private static readonly MAX_BINARY_DELETION_CACHE_SIZE = 50; // Max 50 deleted binary files (can be large)
  private static readonly MAX_BINARY_DELETION_CACHE_BYTES = 75 * 1024 * 1024; // Cap deleted binary content cache to 75MB total
  private static readonly RENAME_WINDOW_MS = 5000;
  private static readonly BASELINE_RETENTION_MS = 3 * 24 * 60 * 60 * 1000;
  private static readonly MAX_BASELINE_STORAGE_BYTES = 200 * 1024 * 1024;
  private static readonly MAX_BASELINE_FILES = 500;
  // Stores only short-lived rename candidates; main file content cache is disk-backed.
  private recentUnlinkedText = new Map<string, { contentPath: string; expiry: number }>();
  private logger: EventLogger;
  private apiService: ApiService;
  private predictionRiskAnalyzer!: PredictionRiskAnalyzer;
  private runtimeArtifactCollector!: RuntimeArtifactCollector;
  private changeStore!: ChangeStore;
  private taskSessionManager!: TaskBasedErrorSessionManager;
  private trackingStore!: DiskBackedTrackingStore;
  private telemetry: Telemetry;
  private workspaceRoot: string;
  private watcher: chokidar.FSWatcher;
  private snapshotManager: SnapshotManager;
  private fileQueue = new JobQueue();
  private globalErrors: string[] = [];
  private globalErrorSet = new Set<string>();
  private latestRequestedTasks = '';
  // TD5 authoritative user-run identity: TargetName_BuildTypeName from
  // buildtime.xml - the TD5 counterpart of Gradle's requestedTasks. Live-only, never stored.
  private latestTd5BuildIdentity = '';

  // Disk-backed text cache: memory keeps only metadata, content lives on disk.
  private memory!: DiskBackedTextCache;
  private filenameIndex = new Map<string, string>();
  private activeSessions = new Map<string, ErrorSession>();
  private startedTrackingFilesInCycle = new Set<string>();
  private modifiedFilesInCycle = new Set<string>();
  private batchQueue: FileChangeEvent[] = [];

  private binaryEvents: BinaryEvent[] = [];
  private binaryFileHashes = new LRUCache<string, string>(FileWatcher.MAX_BINARY_HASH_CACHE_SIZE);
  // Disk-backed binary deletion cache: keeps deleted binary payloads off heap.
  private binaryDeletionCache!: DiskBackedBufferCache;
  private isWatcherReady = false;
  private buildSuccessInFlight = false;

  private isInErrorCycle = false;
  private hasUserChangesSinceErrorCycle = false;
  private parentErrorTaskPath: string | null = null;
  private rootCycleErrorMessage: string | null = null;

  private trackedFolder: string | null = null;
  private context: vscode.ExtensionContext;
  private copilotClientId: string;
  private workspaceId: string;
  private lastActiveErrorMessage = '';
  private predictPollTimer: NodeJS.Timeout | null = null;
  private predictPollInFlight = false;
  private lastProcessedPredictionSessionId = '';
  /** Watcher start time: failures parsed within the startup window come from STALE logs/reports
   *  found on disk when the IDE opened (log replay), not from a live build. */
  private readonly watcherStartedAtMs = Date.now();
  /** Last reconcile summary printed — identical re-parses within a minute go to debug. */
  private lastReconcileLine = '';
  private lastReconcileLineAt = 0;
  /** TD5: tail block of the failing build's log ("last build failure") — shown in the confirm
   *  webview instead of the raw error list (display-only; stored errors unchanged). */
  private lastTd5FailureTail: string | null = null;
  /** TRUE "before" per file per error cycle: disk content captured at the FIRST keystroke —
   *  at that moment the disk holds exactly what the failing build saw. The persisted rolling
   *  baseline can be stale (edits made while no watcher ran: other window, closed IDE), which
   *  made Compare Changes show identical sides in TD5. */
  private readonly cycleTypingBaselines = new Map<string, string>();
  private typingBaselineSubscription: vscode.Disposable | undefined;
  /** FAILURE-STATE baselines (TD5 tool editing): the developer edits files in the TD5
   *  tool, NOT VS Code — keystroke capture never fires and the cross-session memory can be
   *  stale, so a real fix hydrated as before==after and was pruned. At every failure parse the
   *  DISK is by definition the state that failed: recently-modified tracked files are
   *  snapshotted then, and that content outranks every other "before" source for the cycle. */
  private readonly cycleFailureBaselines = new Map<string, string>();
  private knownDiskTrackingSessions = new Set<string>();
  /** Previous-session failures with no saved data — logged once, never shown. */
  private readonly skippedEmptyPrevSessions = new Set<string>();
  private globalTrackingSessionId: string | null = null;
  private baselineCleanupInFlight = false;

  // NEW: Track the last modified/opened file to use as a fallback
  private lastModifiedFile: string | null = null;

  private readonly developerId = 'unknown';

  private isTd5Mode(): boolean {
    return !!this.trackedFolder;
  }

  private isInsideTrackedFolder(filePath: string): boolean {
    if (this.trackedFolder) {
      // TD5: the work/ folder stays the outer boundary, and the SAME
      // admin System Tracking inclusion list that governs GBE applies INSIDE it — GBE and TD5
      // share the work folder, so they share its configuration (work/ is a mandatory include
      // there). Previously TD5 bypassed the admin list and tracked everything under work/.
      // With no admin config reachable, the plain folder-prefix behavior remains as before.
      if (!filePath.toLowerCase().startsWith(this.trackedFolder.toLowerCase() + '/')) {
        return false;
      }
      if (TrackingConfigService.getActivePatterns()) {
        return FileUtils.isIncludedForTracking(filePath, this.workspaceRoot);
      }
      return true;
    }
    // Gradle mode: INCLUSION list — work/ + gradle/ + root gradle/settings
    // files only. Fail-closed: unknown/generated folders never enter the upload payload.
    return FileUtils.isIncludedForTracking(filePath, this.workspaceRoot);
  }

  async startupRetry(): Promise<void> {
    try {
      if (fs.existsSync(this.inflightWalPath)) {
        fs.unlinkSync(this.inflightWalPath);
      }
    } catch { /* ignore */ }
    await this.logger.startupRetry();
  }

  private get inflightWalPath(): string {
    return path.join(this.context.globalStorageUri.fsPath, 'inflight-cycle.json');
  }

  private persistInflightCycle(): void {
    return;
  }

  constructor(context: vscode.ExtensionContext, telemetry: Telemetry) {
    this.context = context;
    this.telemetry = telemetry;
    this.workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || '';
    if (!this.workspaceRoot) { Logger.log('No workspace open FileWatcher not initialized.'); }

    this.apiService = new ApiService(telemetry);
    this.workspaceRoot = FileUtils.normalizePath(this.workspaceRoot);
    // Admin System Tracking Configuration: load early (fire-and-forget, fail-open) so file-change
    // tracking follows the dashboard's inclusion list from the first event; refreshed at every
    // build-failure cycle alongside the artifact config (60s cache).
    void TrackingConfigService.load(this.apiService);
    this.predictionRiskAnalyzer = new PredictionRiskAnalyzer(this.workspaceRoot, this.apiService, this.filenameIndex);
    this.runtimeArtifactCollector = new RuntimeArtifactCollector({ workspaceRoot: this.workspaceRoot });
    this.changeStore = new ChangeStore(this.workspaceRoot);
    this.taskSessionManager = new TaskBasedErrorSessionManager(this.changeStore);
    this.workspaceId = this.computeWorkspaceId();
    this.memory = new DiskBackedTextCache(
      path.join(context.globalStorageUri.fsPath, 'ai-assisted-disk-cache', this.workspaceId || 'workspace', 'text'),
      { maxEntries: FileWatcher.MAX_MEMORY_CACHE_SIZE, maxBytes: FileWatcher.MAX_MEMORY_CACHE_BYTES }
    );
    this.binaryDeletionCache = new DiskBackedBufferCache(
      path.join(context.globalStorageUri.fsPath, 'ai-assisted-disk-cache', this.workspaceId || 'workspace', 'binary-deleted'),
      { maxEntries: FileWatcher.MAX_BINARY_DELETION_CACHE_SIZE, maxBytes: FileWatcher.MAX_BINARY_DELETION_CACHE_BYTES }
    );
    this.trackingStore = new DiskBackedTrackingStore(context.globalStorageUri.fsPath, this.workspaceRoot, this.workspaceId);
    this.snapshotManager = new SnapshotManager(this.workspaceRoot, context.globalStorageUri.fsPath);
    this.snapshotManager.clearSnapshots();
    this.logger = new EventLogger(context.globalStorageUri.fsPath, this.apiService, telemetry);
    this.cleanupStartupDiskCaches();
    this.copilotClientId = this.ensureCopilotClientId();

    this.watcher = chokidar.watch(this.workspaceRoot, {
      ignoreInitial: false,
      persistent: true,
      awaitWriteFinish: {
        stabilityThreshold: FileWatcher.FILE_STABILITY_THRESHOLD,
        pollInterval: FileWatcher.FILE_POLL_INTERVAL
      },
      ignored: (filePath: string) => FileUtils.shouldIgnore(filePath)
    });

    for (const doc of vscode.workspace.textDocuments) {
      const p = FileUtils.normalizePath(doc.uri.fsPath);
      if (!FileUtils.shouldIgnore(p) && FileUtils.isFileInsideWorkspace(doc.uri.fsPath, this.workspaceRoot)) {
        this.filenameIndex.set(path.basename(p).toLowerCase(), p);
      }
    }

    // First keystroke of a file during an error cycle: the DISK still holds the content the
    // failing build saw — capture it once as this cycle's true "before" (see cycleTypingBaselines).
    this.typingBaselineSubscription = vscode.workspace.onDidChangeTextDocument((e) => {
      try {
        if (!this.isInErrorCycle || e.document.uri.scheme !== 'file') { return; }
        const p = FileUtils.normalizePath(e.document.uri.fsPath);
        if (!p || this.cycleTypingBaselines.has(p) || !this.isInsideTrackedFolder(p)) { return; }
        if (!fs.existsSync(p)) { return; }
        const diskContent = fs.readFileSync(p, 'utf8');
        this.cycleTypingBaselines.set(p, diskContent);
        // The disk AT FIRST KEYSTROKE is ground truth for "content before this fix". The
        // disk-backed memory cache can disagree when the break was made while no watcher ran
        // (file broken BEFORE VS Code opened -> memory still held the previous
        // session's fixed text -> the fix event hydrated as before==after and was pruned as
        // "no net change"). Sync memory to the disk truth so every later fallback agrees.
        if (this.memory.get(p.toLowerCase()) !== diskContent) {
          this.memory.set(p.toLowerCase(), diskContent);
        }
      } catch { /* capture is best-effort; the baseline chain still applies */ }
    });

    this.initWatcherEvents();
    this.cleanupBaselinesIfSafe('startup').catch(() => { });
  }

  private async cleanupBaselinesIfSafe(reason: string): Promise<void> {
    if (!this.trackingStore || this.baselineCleanupInFlight) {
      return;
    }

    this.baselineCleanupInFlight = true;
    try {
      await this.trackingStore.cleanupResolvedSessionFolders();
      const result = await this.trackingStore.cleanupRollingBaselines({
        activeSessionIds: this.getKnownActiveDiskSessionIds(),
        skipWhenActiveSessions: true,
        retentionMs: FileWatcher.BASELINE_RETENTION_MS,
        maxStorageBytes: FileWatcher.MAX_BASELINE_STORAGE_BYTES,
        maxBaselineFiles: FileWatcher.MAX_BASELINE_FILES
      });

      if (result.skipped) {
        return;
      }

      if (result.deletedCount > 0) {
        Logger.log(
          `[AI Assistant] Rolling baseline cleanup completed (${reason}): ` +
          `deleted=${result.deletedCount}, ` +
          `freed=${Math.round(result.deletedBytes / 1024)}KB, ` +
          `remaining=${result.remainingCount}, ` +
          `remainingSize=${Math.round(result.remainingBytes / 1024)}KB`
        );
      }

      await this.trackingStore.cleanupJournalIfSafe(this.getKnownActiveDiskSessionIds());
      this.cleanupDiskBackedContentCachesIfSafe(reason);
    } catch (error) {
      Logger.log(`[AI Assistant] Rolling baseline cleanup failed (${reason})`, error);
    } finally {
      this.baselineCleanupInFlight = false;
    }
  }

  private cleanupStartupDiskCaches(): void {
    this.cleanupMemoryLightPayloadRoot();
    this.memory.clear();
    this.resetDirectory(this.getDiskBackedTextCacheRoot());
    this.binaryDeletionCache.clear();
    this.resetDirectory(this.getDiskBackedBinaryDeletionCacheRoot());
    this.logger.cleanupLocalUploadStorage();
  }

  private cleanupDiskBackedContentCachesIfSafe(reason: string): void {
    if (this.hasActiveOrPendingDiskCacheWork()) {
      return;
    }

    try { this.memory.clear(); } catch { /* ignore cleanup failure */ }
    this.resetDirectory(this.getDiskBackedTextCacheRoot());

    try { this.binaryDeletionCache.clear(); } catch { /* ignore cleanup failure */ }
    this.resetDirectory(this.getDiskBackedBinaryDeletionCacheRoot());

    this.cleanupMemoryLightPayloadRoot();
  }

  private hasActiveOrPendingDiskCacheWork(): boolean {
    if (this.isInErrorCycle || this.globalTrackingSessionId || this.activeSessions.size > 0) {
      return true;
    }

    if (this.taskSessionManager?.hasActiveTasks?.()) {
      return true;
    }

    if (this.getKnownActiveDiskSessionIds().length > 0) {
      return true;
    }

    if (this.batchQueue.length > 0 || this.binaryEvents.length > 0 || this.recentUnlinkedText.size > 0) {
      return true;
    }

    if (this.runtimeArtifactCollector?.hasPendingArtifacts?.()) {
      return true;
    }

    return false;
  }

  private cleanupCompletedUploadDiskArtifacts(
    reason: string,
    textEvents: FileChangeEvent[] = [],
    binaryEvents: BinaryEvent[] = []
  ): void {
    this.cleanupEventPayloadFiles(textEvents);
    this.cleanupDeletedBinaryPayloads(binaryEvents);
    this.logger.cleanupLocalUploadStorage();
    Logger.log(`[AI Assistant] Local disk cleanup completed (${reason})`);
  }

  private cleanupMemoryLightPayloadRoot(): void {
    this.resetDirectory(this.getMemoryLightPayloadRoot());
  }

  private getDiskBackedTextCacheRoot(): string {
    return path.join(this.context.globalStorageUri.fsPath, 'ai-assisted-disk-cache', this.workspaceId || 'workspace', 'text');
  }

  private getDiskBackedBinaryDeletionCacheRoot(): string {
    return path.join(this.context.globalStorageUri.fsPath, 'ai-assisted-disk-cache', this.workspaceId || 'workspace', 'binary-deleted');
  }

  private resetDirectory(directoryPath: string): void {
    try { fs.rmSync(directoryPath, { recursive: true, force: true }); } catch { /* ignore cleanup failure */ }
    try { fs.mkdirSync(directoryPath, { recursive: true }); } catch { /* ignore mkdir failure */ }
  }

  private cleanupEventPayloadFiles(events: FileChangeEvent[] = []): void {
    for (const event of events || []) {
      this.deleteMemoryLightPayloadIfSafe(event.snapshotBeforeContentPath);
      this.deleteMemoryLightPayloadIfSafe(event.snapshotAfterContentPath);
    }
  }

  private cleanupDeletedBinaryPayloads(events: BinaryEvent[] = []): void {
    for (const event of events || []) {
      if (event.action !== 'deleted') {
        continue;
      }
      const key = FileUtils.normalizePath(event.absolutePath || event.filePath || '').toLowerCase();
      if (key) {
        this.binaryDeletionCache.delete(key);
      }
    }
  }

  private deleteMemoryLightPayloadIfSafe(filePath?: string | null): void {
    if (!filePath) {
      return;
    }

    const root = FileUtils.normalizePath(this.getMemoryLightPayloadRoot());
    const target = FileUtils.normalizePath(filePath);
    const relative = path.relative(root, target);

    if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
      return;
    }

    try { fs.rmSync(target, { force: true }); } catch { /* ignore cleanup failure */ }
    this.removeEmptyParents(path.dirname(target), root);
  }

  private removeEmptyParents(startDir: string, stopDir: string): void {
    let current = FileUtils.normalizePath(startDir);
    const stop = FileUtils.normalizePath(stopDir);

    while (current && current !== stop && current.startsWith(stop)) {
      try { fs.rmdirSync(current); } catch { break; }
      current = path.dirname(current);
    }
  }

  private getKnownActiveDiskSessionIds(): string[] {
    const ids = new Set<string>();

    if (this.isTd5Mode() && this.isInErrorCycle && this.globalTrackingSessionId) {
      ids.add(this.globalTrackingSessionId);
    }

    for (const session of this.taskSessionManager?.getActiveSessions?.() || []) {
      if (session.status !== 'active_failed' && session.status !== 'not_seen_once') {
        continue;
      }

      const id = session.occurrenceId || session.requestId || session.taskKey;
      if (id) { ids.add(id); }
    }

    return Array.from(ids);
  }

  private ensureCopilotClientId(): string {
    const existing = this.context.globalState.get<string>('copilot.clientId');
    if (existing && existing.trim()) {
      return existing.trim();
    }
    const generated = crypto.randomUUID();
    this.context.globalState.update('copilot.clientId', generated).then(undefined, () => { /* ignore */ });
    return generated;
  }

  private computeWorkspaceId(): string {
    const normalized = FileUtils.normalizePath(this.workspaceRoot || '');
    if (!normalized) { return ''; }
    return crypto.createHash('sha1').update(normalized).digest('hex');
  }

  private clearCopilotSession() {
    this.lastActiveErrorMessage = '';
  }

  /** TD5 GBE-parity: TD5 has no report.html — the failing build's own log is the
   *  error source. Newest _td5/log/*.log whose content says Build Status: FAILED. */
  private async findLatestFailedTd5Log(): Promise<string | null> {
    try {
      const found = await vscode.workspace.findFiles('**/_td5/log/*.log', '**/node_modules/**', 100);
      // TD5 names its log deterministically: <PROJ_PATH>/_td5/log/<TargetName>_<BuildTypeName>.log,
      // and buildtime.xml gives us exactly that identity (setTd5BuildIdentity). A workspace can
      // hold several targets and build types, each with its own failed log, so 'newest failed' can
      // answer a failure the developer never ran - the same defect that had a five-day-old dev
      // report answering master failures on the Gradle side. Prefer the identity; fall back to
      // newest-failed only when the identity is not known yet, so nothing regresses.
      const _identity = String(this.latestTd5BuildIdentity
        || String(this.latestRequestedTasks || '').trim().replace(/\s+/g, '_')).trim().toLowerCase();
      let best: { p: string; mtime: number } | null = null;
      let pinned: { p: string; mtime: number } | null = null;
      for (const f of found) {
        try {
          const st = fs.statSync(f.fsPath);
          if (st.size > 20 * 1024 * 1024) { continue; }
          const text = fs.readFileSync(f.fsPath, 'utf8');
          if (!/Build(?:prj)?\s+Status:\s*FAILED/i.test(text)) { continue; }
          const here = { p: FileUtils.normalizePath(f.fsPath), mtime: st.mtimeMs };
          if (!best || st.mtimeMs > best.mtime) { best = here; }
          if (_identity) {
            const base = path.basename(f.fsPath).replace(/\.log$/i, '').toLowerCase();
            if (base === _identity && (!pinned || st.mtimeMs > pinned.mtime)) { pinned = here; }
          }
        } catch { /* unreadable log - skip */ }
      }
      if (pinned) {
        Logger.log(`[AI Assistant] TD5 recommendation log: ${pinned.p} (pinned to build ${_identity})`);
        return pinned.p;
      }
      if (best) {
        Logger.log(`[AI Assistant] TD5 recommendation log: ${best.p} (newest failed; build identity `
          + `${_identity || 'unknown'} matched no log, so the target could not be pinned)`);
      }
      return best ? best.p : null;
    } catch {
      return null;
    }
  }

  public getRecommendationLaunchContext(): {
    project_name: string;
    failed_task: string;
    error_message: string;
    has_error: boolean;
  } {
    const projectName = this.getProjectName();
    const failedTask = String(this.parentErrorTaskPath || '').trim();

    const primaryError = String(this.rootCycleErrorMessage || '').trim();
    const activeError = String(this.lastActiveErrorMessage || '').trim();
    const globalFallback = Array.isArray(this.globalErrors) && this.globalErrors.length > 0
      ? String(this.globalErrors[0] || '').trim()
      : '';

    const errorMessage = primaryError || activeError || globalFallback;

    return {
      project_name: projectName,
      failed_task: failedTask,
      error_message: errorMessage,
      has_error: errorMessage.length > 0,
    };
  }

  /** The artifact logs of the failure THIS report describes, one entry per file.
   *
   *  A workspace can hold several failed cycles at once (dev:task4 still failed from an old test
   *  AND master:task4 failing now), and a stale task's log in the query actively decides the wrong
   *  fix. Anchor = the report being sent: an artifact is kept when its task segments match that
   *  report's path best (the TARGET segment separates master from dev). TD5 anchors on the failing
   *  build process instead, because a TD5 log path never contains a process name. When nothing
   *  belongs to this report, another task's log is worse than none - all artifacts are kept only
   *  when they come from one single task. Only .log/.txt files carry text worth comparing. */
  private buildRecommendationEvidence(reportPath: string): { name: string; text: string }[] {
    const pending = this.runtimeArtifactCollector.getPendingArtifacts();
    if (pending.length === 0) { return []; }

    const reportSegs = new Set(String(reportPath || '').toLowerCase().split(/[\\/]+/).filter(Boolean));
    const td5Proc = this.isTd5Mode() ? String(this.parentErrorTaskPath || '').trim().toLowerCase() : '';
    const segScore = (a: { taskPath?: string }): number => {
      if (td5Proc) {
        const base = String(a.taskPath || '').trim().toLowerCase();
        return base && (base.includes(td5Proc) || td5Proc.includes(base)) ? 1 : 0;
      }
      return String(a.taskPath || '').toLowerCase().split(':')
        .map(s => s.trim()).filter(s => s && s !== 'targets')
        .reduce((n, s) => n + (reportSegs.has(s) ? 1 : 0), 0);
    };
    const scores = pending.map(segScore);
    const maxScore = Math.max(0, ...scores);
    let pool = maxScore > 0 ? pending.filter((_a, i) => scores[i] === maxScore) : [];
    if (pool.length === 0) {
      const failingTaskKey = String(this.parentErrorTaskPath || '').trim().toLowerCase();
      pool = failingTaskKey
        ? pending.filter(a => String(a.taskPath || '').trim().toLowerCase() === failingTaskKey)
        : [];
    }
    if (pool.length === 0) {
      const tasks = new Set(pending.map(a => String(a.taskPath || '').trim().toLowerCase()));
      pool = tasks.size <= 1 ? pending : [];
    }
    Logger.log(`[AI Assistant] recommendation evidence pool for this report: ${pool.length}/${pending.length} kept ` +
      `[${pool.map(a => String(a.taskPath || '?') + '/' + String(a.originalFileName || a.filePath || '')).join(', ')}]`);

    const excerpts: { name: string; text: string }[] = [];
    const seenText = new Set<string>();
    for (const a of pool) {
      const name = String(a.originalFileName || a.filePath || 'artifact');
      if (!a.fileContent || !/\.(log|txt)$/i.test(name)) { continue; }
      const text = FileWatcher.cleanArtifactText((a.fileContent as Buffer).toString('utf8'));
      if (!text.trim() || seenText.has(text)) { continue; }
      seenText.add(text);
      excerpts.push({ name, text });
    }
    return excerpts;
  }

  /** Basenames of the files changed in this cycle. The breaking edit usually lands BEFORE the
   *  first failure and a new error cycle clears modifiedFilesInCycle, so the failure baselines
   *  (recently-modified tracked files captured from disk at every failure parse) are unioned in. */
  private getCycleChangedFileNames(): string[] {
    const names = new Set<string>();
    for (const p of [...this.modifiedFilesInCycle, ...this.cycleFailureBaselines.keys()]) {
      const n = path.basename(String(p || '')).trim();
      if (n) { names.add(n); }
    }
    return Array.from(names).slice(0, 20);
  }

  public async getCurrentCopilotRecommendation(queryText?: string, selectedScope?: string, abortSignal?: AbortSignal): Promise<any> {
    const projectName = this.getProjectName();
    const scope = String(selectedScope || '').trim().toLowerCase() || 'project';

    // Same endpoint, same pipeline for both project types - only the error SOURCE differs:
    // Gradle sends report.html, TD5 sends the failing build's own log (report_format flag).
    let reportPath: string | null;
    let reportFormat: string | undefined;
    if (this.isTd5Mode()) {
      reportPath = await this.findLatestFailedTd5Log();
      reportFormat = 'td5-log';
      if (!reportPath) {
        return {
          status: 'error',
          project_name: projectName,
          display_markdown: 'No failed TD5 build log found. Run a build so the failure is recorded, then try the recommendation again.',
        };
      }
    } else {
      // The report of the task the developer actually ran - not whichever target's report
      // happens to be found first (a 5-day-old dev report was answering master failures).
      reportPath = await FileUtils.findBuildReportForTask(
        this.workspaceRoot, this.latestRequestedTasks || this.parentErrorTaskPath || '');
      if (!reportPath) {
        return {
          status: 'error',
          project_name: projectName,
          display_markdown: 'No **report.html** found. Run a build so a report.html is generated, then try the recommendation again.',
        };
      }
    }

    // Evidence is best effort: a failure to collect it must never block the recommendation.
    let artifactExcerpts: { name: string; text: string }[] = [];
    let changedFiles: string[] = [];
    try { artifactExcerpts = this.buildRecommendationEvidence(reportPath); } catch (err) {
      Logger.log('[AI Assistant] recommendation evidence collection failed (sent without logs)', err);
    }
    try { changedFiles = this.getCycleChangedFileNames(); } catch { /* sent without changed files */ }
    const liveUserTask = this.isTd5Mode()
      ? (this.latestTd5BuildIdentity || path.basename(String(reportPath || '')).replace(/\.log$/i, ''))
      : String(this.latestRequestedTasks || '').trim();
    let usage: any = {};
    try { usage = collectUsageSignals(); } catch { /* usage counting is optional */ }

    Logger.log(`[AI Assistant] recommendation request: report=${reportPath}` +
      `, format=${reportFormat || 'gradle'}, logs=${artifactExcerpts.length}` +
      `, changedFiles=[${changedFiles.join(', ')}], task=${liveUserTask || '-'}, scope=${scope}`);

    let envelope: any;
    try {
      envelope = await this.apiService.getWorkspaceReportRecommendation({
        project_name: projectName,
        report_path: reportPath,
        query_text: queryText,
        recommendation_scope: scope,
        report_format: reportFormat,
        artifact_excerpts: artifactExcerpts,
        changed_files: changedFiles,
        user_task: liveUserTask,
        usage,
        abortSignal,
      });
    } catch (err: any) {
      // Turn the known report-related failures into a clear, actionable message instead of the
      // generic "backend unreachable" 500.
      const msg = String(err?.message || err || '');
      const source = reportFormat === 'td5-log' ? 'the TD5 build log' : '**report.html**';
      if (/report file not found/i.test(msg)) {
        return {
          status: 'error',
          project_name: projectName,
          display_markdown: `No ${source} found. Run a build so it is generated, then try again.`,
        };
      }
      if (/no errors found in report/i.test(msg)) {
        return {
          status: 'error',
          project_name: projectName,
          display_markdown: `No error message could be read from ${source} - please check it.`,
        };
      }
      throw err; // a genuine service/connection error - let the caller show the "backend unreachable" message
    }

    return {
      status: 'success',
      project_name: projectName,
      query_text: String(queryText || ''),
      selected_scope: scope,
      result: Array.isArray(envelope?.recommendations) ? envelope.recommendations : [],
      // Full envelope fields so the webview can render analysis + selection + how-it-matched
      // + the matching documentation (combines recommendation and document lookup).
      recommendations: Array.isArray(envelope?.recommendations) ? envelope.recommendations : [],
      llm_analysis: String(envelope?.llm_analysis || ''),
      // Why analysis may be missing (ok | timeout | error | disabled) + a human message, so the
      // UI can explain a degraded recommendation instead of showing a confusing blank section.
      llm_analysis_status: String(envelope?.llm_analysis_status || 'ok'),
      llm_analysis_message: String(envelope?.llm_analysis_message || ''),
      llm_selection: envelope?.llm_selection || {},
      context_enrichment: envelope?.context_enrichment || {},
      document_context: envelope?.document_context || {},
      // Carried through so the webview can attach them to Helpful / Not-helpful feedback.
      feedback_token: String(envelope?.feedback_token || ''),
      query_signature_hashes: Array.isArray(envelope?.query_signature_hashes) ? envelope.query_signature_hashes : [],
      // The webview footer (Trace ID copy), the below-threshold verdict and the same-task
      // confirmation depend on these - the previous rebuild dropped them.
      trace_id: String(envelope?.trace_id || ''),
      match_status: String(envelope?.match_status || ''),
      confidence_score: envelope?.confidence_score,
      task_match: envelope?.task_match || {},
      // clear / likely / ambiguous - the webview warns when several fixes are tied.
      decision: envelope?.decision || {},
      display_markdown: renderRecommendationMarkdown(envelope),
    };
  }
  public async submitRecommendationFeedback(payload: {
    request_id: string;
    project_name?: string;
    is_helpful: boolean;
    feedback_token?: string;
    query_signature_hashes?: string[];
  }): Promise<any> {
    return this.apiService.postRecommendationFeedback({
      request_id: payload.request_id,
      is_helpful: payload.is_helpful,
      project_name: payload.project_name || this.getProjectName(),
      feedback_token: payload.feedback_token,
      query_signature_hashes: payload.query_signature_hashes,
    });
  }

  private startPredictionPolling() {
    if (!this.workspaceRoot) { return; }
    if (this.predictPollTimer) {
      clearInterval(this.predictPollTimer);
    }
    this.predictPollTimer = setInterval(() => {
      if (this.predictPollInFlight) { return; }
      this.predictPollInFlight = true;
      this.pollPredictionScope().catch(() => { /* ignore */ }).finally(() => {
        this.predictPollInFlight = false;
      });
    }, 15000);
  }

  private async pollPredictionScope() {
    const projectName = this.getProjectName();

    const predictionClientId = 'global';
    const pending = await this.apiService.getPredictPendingScope({
      project_name: projectName,
      client_id: predictionClientId,
      actor_id: 'global'
    });
    if (!pending || pending.status !== true) { return; }
    if (pending.has_result === true) { return; }
    const predictionSessionId = String(pending.prediction_session_id || '').trim();
    if (!predictionSessionId) { return; }
    if (predictionSessionId === this.lastProcessedPredictionSessionId) { return; }

    const scope = pending.scope || {};
    const local = await this.runLocalPrediction(scope);
    await this.apiService.postPredictResult({
      prediction_session_id: predictionSessionId,
      project_name: projectName,
      client_id: predictionClientId,
      actor_id: 'global',
      matches: local.matches,
      summary: local.summary
    });
    this.lastProcessedPredictionSessionId = predictionSessionId;
  }

  public async generateBuildFailureRiskReport(selectedFilePaths: string[] = []): Promise<any> {
    return this.predictionRiskAnalyzer.generateBuildFailureRiskReport(selectedFilePaths);
  }

  /** GBE target discovered from the report location (additive upload field, see EventLogger). */
  public setGbeTarget(target: string): void {
    this.logger.setGbeTarget(target);
  }

  /** TD5 build window from buildtime.xml — scopes proc artifact collection to files this build
   *  wrote. The xml path also pins the ACTIVE build folder (evidence beats name matching). */
  public setTd5BuildIdentity(target: string | null, buildType: string | null): void {
    const identity = [String(target || '').trim(), String(buildType || '').trim()]
      .filter(Boolean).join('_');
    if (identity) { this.latestTd5BuildIdentity = identity; }
  }

  public setTd5BuildWindow(startMs: number, endMs: number | null, xmlPath?: string): void {
    this.runtimeArtifactCollector.setTd5BuildWindow(startMs, endMs, xmlPath);
  }

  private async runLocalPrediction(scope: any, selectedFilePaths: string[] = [], opts: { silent?: boolean } = {}): Promise<{ matches: any[]; summary: any }> {
    return this.predictionRiskAnalyzer.runLocalPrediction(scope, selectedFilePaths, opts);
  }

  // Shadow-mode prediction capture (prediction-feedback enhancement, step A).
  // On the FIRST failure report of an error cycle, run the normal local prediction silently on
  // the broken workspace state and store the report server-side (report_kind=shadow) together
  // with the failure-cycle context, so it can be judged later when the SAME task goes green.
  // Zero user impact: fire-and-forget, no UI, every failure swallowed. Code never leaves the
  // machine — the scan runs locally, only the resulting warnings are reported.
  private runShadowPredictionCapture(rawErrors: RawBuildError[], requestedTasks: string): void {
    (async () => {
      // Startup replay guard: right after activation the watchers parse WHATEVER logs/reports
      // already sit on disk (TD5 log folder, existing report.html). Those "failures" happened
      // before the IDE opened — capturing a shadow prediction for them only creates unjudgeable
      // noise rows. Live builds always finish well after this window.
      if (Date.now() - this.watcherStartedAtMs < 15000) {
        Logger.debug('[ShadowPrediction] skipped — failure came from the startup log scan (stale replay, not a live build)');
        return;
      }
      const projectName = this.getProjectName();
      if (!projectName) { return; }

      const scopeResp = await this.apiService.getPredictReportScope({
        project_name: projectName,
        actor_id: 'global',
        selected_files: [],
      });
      if (scopeResp?.status !== true) { return; }

      const local = await this.runLocalPrediction(scopeResp.scope || {}, [], { silent: true });

      const errorsByTask = new Map<string, string[]>();
      for (const err of rawErrors || []) {
        const key = String(err?.taskPath || 'unknown').trim() || 'unknown';
        const list = errorsByTask.get(key) || [];
        if (err?.message) { list.push(String(err.message)); }
        errorsByTask.set(key, list);
      }
      const snapshot = this.buildErrorSnapshot(errorsByTask);
      const failingTasks = Array.from(errorsByTask.keys()).filter((t) => t && t !== 'unknown');

      await this.apiService.postPredictReport({
        project_name: projectName,
        actor_id: 'global',
        client_id: 'shadow',
        developer_id: this.developerId,
        matches: local.matches,
        summary: local.summary,
        shadow: true,
        shadow_context: {
          requested_tasks: (requestedTasks || '').trim(),
          failing_tasks: failingTasks,
          error_signature: snapshot.signature,
          primary_error_message: (snapshot.primaryMessage || '').slice(0, 500),
          captured_at: new Date().toISOString(),
        },
      });
      Logger.log(`[ShadowPrediction] silent capture stored — ${local.matches.length} match(es), failing task(s): [${failingTasks.join(', ') || '-'}]`);
    })().catch((err: any) => {
      Logger.debug('[ShadowPrediction] capture skipped', { error: err?.message || String(err) });
    });
  }

  private buildErrorSnapshot(currentErrorsMap: Map<string, string[]>): { signature: string; combinedMessage: string; primaryMessage: string } {
    const unique = new Map<string, string>();

    for (const [, messages] of currentErrorsMap) {
      for (const raw of messages || []) {
        const text = (raw || '').trim();
        if (!text) { continue; }
        const normalized = FileUtils.stripTimestamp(text).toLowerCase();
        if (!unique.has(normalized)) {
          unique.set(normalized, text);
        }
      }
    }

    if (unique.size === 0) {
      for (const raw of this.globalErrors) {
        const text = (raw || '').trim();
        if (!text) { continue; }
        const normalized = FileUtils.stripTimestamp(text).toLowerCase();
        if (!unique.has(normalized)) {
          unique.set(normalized, text);
        }
      }
    }

    const orderedMessages = Array.from(unique.values());
    const primaryMessage = orderedMessages[0] || '';
    const combinedRaw = orderedMessages.slice(0, 8).join('\n');
    const combinedMessage = combinedRaw.length > 6000 ? combinedRaw.slice(0, 6000) : combinedRaw;
    const signatureSource = orderedMessages.map(m => FileUtils.stripTimestamp(m).toLowerCase()).join('|');
    const signature = crypto.createHash('sha256').update(signatureSource || '<empty>').digest('hex');

    return { signature, combinedMessage, primaryMessage };
  }

  private getProjectName(): string {
    const name = path.basename(this.workspaceRoot || '').trim().toLowerCase();
    return name || 'unknown-project';
  }

  private async collectTaskRuntimeArtifacts(rawErrors: RawBuildError[]): Promise<void> {
    // Admin Artifact Configuration rules (cached 60s); null on any failure => legacy rules apply.
    // Refresh the System Tracking inclusion list in the same cycle (also 60s cache, fail-open).
    void TrackingConfigService.load(this.apiService);
    this.runtimeArtifactCollector.setRemoteFolders(await ArtifactConfigService.load(this.apiService));
    const addedCount = await this.runtimeArtifactCollector.collectTaskRuntimeArtifacts(rawErrors);
    if (addedCount > 0) {
      this.logCollectedArtifacts(addedCount);
      this.persistInflightCycle();
    }
  }

  private async collectTd5ProcArtifacts(rawErrors: RawBuildError[], requestedTasks: string): Promise<void> {
    this.runtimeArtifactCollector.setRemoteFolders(await ArtifactConfigService.load(this.apiService));
    // Pass the cycle's failure so TD5 artifacts carry the same stamp the upload filter checks
    // against. globalErrors in TD5 holds exactly this one message.
    const addedCount = await this.runtimeArtifactCollector.collectTd5ProcArtifacts(
      rawErrors, requestedTasks, String(this.rootCycleErrorMessage || rawErrors[0]?.message || '').trim());
    if (addedCount > 0) {
      this.logCollectedArtifacts(addedCount);
      this.persistInflightCycle();
    } else {
      // An empty result is a VALID state (not every task has artifacts) — say so in the
      // story log, so it reads as a checked fact, not a silent failure.
      Logger.log('[AI Assistant] No changed artifact files this build cycle — task workspace checked, only files this build wrote are collected');
    }
  }

  // Visible activity line: what artifacts were gathered this cycle (out/log/wrk logs). Developers
  // want to see this happen; the file NAMES are the useful signal (not the internal s3/paths).
  private logCollectedArtifacts(addedCount: number): void {
    try {
      const names = this.runtimeArtifactCollector.getPendingArtifacts()
        .map((a) => `${a.sourceFolder ? a.sourceFolder + '/' : ''}${a.originalFileName || ''}`)
        .filter((n) => n.length > 0);
      if (names.length === 0) { return; }
      const shown = names.slice(0, 8);
      const more = names.length > shown.length ? ` (+${names.length - shown.length} more)` : '';
      Logger.log(`[AI Assistant] Collected ${addedCount} runtime artifact(s) this cycle — total ${names.length}: ${shown.join(', ')}${more}`);
    } catch { /* logging must never break collection */ }
  }

  private markUserChangeDuringErrorCycle(): void {
    if (!this.isInErrorCycle || this.hasUserChangesSinceErrorCycle) {
      return;
    }

    this.hasUserChangesSinceErrorCycle = true;
    this.persistInflightCycle();
  }

  private filterTaskErrorsWithTrackedFiles(rawErrors: RawBuildError[]): RawBuildError[] {
    return rawErrors.filter((error) => {
      const taskKey = this.normalizeGradleTaskKey(String(error.taskPath || '').trim());
      if (!taskKey) {
        return false;
      }

      return this.taskSessionManager.getFilesForTask(taskKey).length > 0;
    });
  }

  private extractSignalTokens(errorMessage: string): string[] {
    const out: string[] = [];
    const seen = new Set<string>();
    const re = /[A-Z_]{3,}|[A-Za-z][A-Za-z0-9_.-]{4,}/g;
    for (const raw of errorMessage.match(re) || []) {
      const token = String(raw || '').trim();
      const key = token.toLowerCase();
      if (!token || seen.has(key)) { continue; }
      seen.add(key);
      out.push(token);
      if (out.length >= 12) { break; }
    }
    return out;
  }

  private buildSnippetAroundLine(lines: string[], centerIndex: number, radius: number = 10): string {
    const start = Math.max(0, centerIndex - radius);
    const end = Math.min(lines.length - 1, centerIndex + radius);
    return lines.slice(start, end + 1).join('\n').trim();
  }

  private async buildLocalPatchContexts(currentErrorsMap: Map<string, string[]>, errorMessage: string): Promise<string[]> {
    const contexts: string[] = [];
    const seen = new Set<string>();
    const tokens = this.extractSignalTokens(errorMessage);

    for (const [filePath] of currentErrorsMap) {
      if (contexts.length >= 5) { break; }
      try {
        if (!fs.existsSync(filePath) || FileHandlingConfig.isBinaryFile(filePath)) { continue; }
        const content = await FileUtils.readFileSafe(filePath, 3);
        const lines = content.split('\n');
        if (lines.length === 0) { continue; }

        let matched = false;
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i] || '';
          const lower = line.toLowerCase();
          if (!tokens.some(t => lower.includes(t.toLowerCase()))) { continue; }
          const snippet = this.buildSnippetAroundLine(lines, i, 10);
          const key = crypto.createHash('sha1').update(snippet).digest('hex');
          if (!snippet || seen.has(key)) { continue; }
          seen.add(key);
          contexts.push(snippet);
          matched = true;
          if (contexts.length >= 5) { break; }
        }

        if (!matched && contexts.length < 5) {
          const fallback = this.buildSnippetAroundLine(lines, Math.min(lines.length - 1, Math.floor(lines.length / 2)), 10);
          const key = crypto.createHash('sha1').update(fallback).digest('hex');
          if (fallback && !seen.has(key)) {
            seen.add(key);
            contexts.push(fallback);
          }
        }
      } catch { /* ignore */ }
    }

    return contexts;
  }

  private calculateFileHash(content: Buffer): string {
    return crypto.createHash('sha256').update(content).digest('hex');
  }

  private storeBinaryEvent(
    filePath: string,
    action: 'added' | 'modified' | 'deleted',
    fileContent?: Buffer,
    hashSnapshot?: { beforeHash?: string; afterHash?: string }
  ) {
    if (!FileHandlingConfig.isBinaryFile(filePath)) { return; }

    const rel = path.relative(this.workspaceRoot, filePath).replace(/\\/g, '/');
    const displayPath = rel.startsWith('..') ? filePath : rel;
    Logger.log(`[AI Assistant] Watching file: ${displayPath} [${action}]`);
    const projectName = this.getProjectName();
    this.recordGradleBinaryChange(filePath, action, fileContent, hashSnapshot);
    if (action === 'deleted') {
      this.binaryEvents.push({ filePath, absolutePath: filePath, action: 'deleted', fileContent, projectName });
      this.persistInflightCycle();
      return;
    }
    const existing = this.binaryEvents.find(e => e.filePath === filePath);
    if (!existing) {
      this.binaryEvents.push({ filePath, absolutePath: filePath, action, fileContent, projectName });
      this.persistInflightCycle();
      return;
    }
    
    if (existing.action === 'added' && action === 'modified') {
      if (fileContent) { existing.fileContent = fileContent; }
      this.persistInflightCycle();
      return;
    }

    if (existing.action === 'modified' && action === 'modified') {
      if (fileContent) { existing.fileContent = fileContent; }
      this.persistInflightCycle();
      return;
    }

    if (existing.action === 'deleted' && action === 'added') {
      this.binaryEvents.push({ filePath, absolutePath: filePath, action: 'added', fileContent, projectName });
      this.persistInflightCycle();
      return;
    }

    existing.action = action;
    if (fileContent) { existing.fileContent = fileContent; }
    this.persistInflightCycle();
  }

  private initWatcherEvents() {
    this.watcher.on('add', async (filePath) => {
      const norm = FileUtils.normalizePath(filePath);
      const fileName = path.basename(norm);
      this.filenameIndex.set(fileName.toLowerCase(), norm);

      if (FileHandlingConfig.isBinaryFile(norm) && fs.existsSync(norm)) {
        try {
          const content = FileUtils.readBinarySafe(norm);
          this.binaryFileHashes.set(norm, this.calculateFileHash(content));
          this.binaryDeletionCache.set(norm, content);
          if (this.isWatcherReady && this.isInErrorCycle && this.isInsideTrackedFolder(norm)) {
            this.markUserChangeDuringErrorCycle();
            this.storeBinaryEvent(norm, 'added', content, {
              beforeHash: undefined,
              afterHash: this.binaryFileHashes.get(norm)
            });
          }
        } catch { /* ignore */ }
        return;
      }

      if (!FileUtils.shouldIgnore(norm)
        && this.isWatcherReady
        && fs.existsSync(norm)) {
        try {
          const currentContent = await FileUtils.readFileSafe(norm);

          if (this.isInErrorCycle && this.isInsideTrackedFolder(norm)) {
            const matchedOriginal = this.consumeRecentUnlink(currentContent, norm);
            const diskSnapshot = await this.recordTextChangeForActiveTrackingSessions(
              norm,
              'added',
              currentContent,
              matchedOriginal ?? ''
            );
            this.markUserChangeDuringErrorCycle();
            this.modifiedFilesInCycle.add(norm);
            const originalContent = diskSnapshot?.beforeContent ?? matchedOriginal ?? '';
            this.memory.set(norm.toLowerCase(), currentContent);
            this.markUserChangeDuringErrorCycle();
            this.recordGradleTextChange(norm, 'added', originalContent, currentContent, diskSnapshot);
            await this.startSession(norm, null, originalContent);
            if (originalContent !== currentContent) {
              await this.handleIntermediateSave(norm, currentContent);
            }
          } else {
            await this.updateRollingBaselineAfterTextChange(norm, currentContent);
            this.memory.set(norm.toLowerCase(), currentContent);
          }
        } catch { /* ignore */ }
      }
    });

    this.watcher.on('ready', () => { this.isWatcherReady = true; });

    this.watcher.on('unlink', async (filePath) => {
      const norm = FileUtils.normalizePath(filePath);
      let fileContent: Buffer | undefined;

      if (FileHandlingConfig.isBinaryFile(norm)) {
        fileContent = this.binaryDeletionCache.get(norm);

        if (this.isInErrorCycle && this.isInsideTrackedFolder(norm)) {
          this.markUserChangeDuringErrorCycle();
          this.modifiedFilesInCycle.add(norm);
          this.storeBinaryEvent(norm, 'deleted', fileContent ?? Buffer.from(''), {
            beforeHash: this.binaryFileHashes.get(norm),
            afterHash: undefined
          });
        }
        this.binaryFileHashes.delete(norm);
      } else if (this.isInErrorCycle && this.isInsideTrackedFolder(norm)) {
        const session = this.activeSessions.get(norm);
        const sessionContent = session ? this.getSessionLastSavedContent(session) : undefined;
        const diskBaselineForFile = this.trackingStore.getRollingBaseline(norm);
        const cached = this.memory.get(norm.toLowerCase()) ?? sessionContent ?? diskBaselineForFile?.content ?? '';

        this.modifiedFilesInCycle.add(norm);
        this.markUserChangeDuringErrorCycle();

        this.recordTextChangeForActiveTrackingSessions(norm, 'deleted', '', cached)
          .then((diskSnapshot) => {
            this.recordGradleTextChange(norm, 'deleted', diskSnapshot?.beforeContent ?? cached, '', diskSnapshot);
          })
          .catch(() => {
            this.recordGradleTextChange(norm, 'deleted', cached, '');
          });

        try {
          const event = await this.buildEventObject(norm, cached, '', []);
          event.eventType = 'deleted';

          if (event.modifiedFunctions.length === 0) {
            if (cached === '') {
              event.modifiedFunctions = [{
                functionName: 'file-level-change',
                before: { functionCode: null },
                after: { functionCode: null },
                linesBeforeChanges: [{ line: 1, content: '// [File deleted but original content was not cached by extension]' }],
                linesAfterChanges: []
              }];
            } else {
              event.modifiedFunctions = [{
                functionName: 'file-level-change',
                before: { functionCode: null },
                after: { functionCode: null },
                linesBeforeChanges: DiffGenerator.getDiffStats(cached, '').removed,
                linesAfterChanges: []
              }];
            }
          }

          this.addToBatchOrMerge(event);
        } catch {
          // preserve deletion event handling even if event construction fails
        }

        this.cleanupExpiredUnlinks();
        const renameCachePath = this.writeMemoryLightTextPayload(norm, 'rename-unlink', cached);
        const hashKey = crypto.createHash('sha1').update(cached).digest('hex');
        const pathKey = `path:${norm.toLowerCase()}`;
        const metadata = {
          contentPath: renameCachePath,
          expiry: Date.now() + FileWatcher.RENAME_WINDOW_MS,
        };
        this.recentUnlinkedText.set(hashKey, metadata);
        this.recentUnlinkedText.set(pathKey, metadata);
      }

      this.filenameIndex.delete(path.basename(norm).toLowerCase());
      this.activeSessions.delete(norm);

      this.memory.delete(norm.toLowerCase());
    });

    vscode.workspace.onDidOpenTextDocument(doc => {
      const p = FileUtils.normalizePath(doc.uri.fsPath);
      if (!FileUtils.shouldIgnore(p) && FileUtils.isFileInsideWorkspace(doc.uri.fsPath, this.workspaceRoot)) {
        this.filenameIndex.set(path.basename(p).toLowerCase(), p);
        this.lastModifiedFile = p;
      }
    });

    this.watcher.on('change', async (filePath) => {
      if (FileUtils.shouldIgnore(filePath)) { return; }
      const normPath = FileUtils.normalizePath(filePath);
      this.filenameIndex.set(path.basename(normPath).toLowerCase(), normPath);

      if (!FileHandlingConfig.isBinaryFile(normPath)) {
        this.lastModifiedFile = normPath;
      }

      if (FileHandlingConfig.isBinaryFile(normPath) && fs.existsSync(normPath)) {
        try {
          const content = FileUtils.readBinarySafe(normPath);
          const newHash = this.calculateFileHash(content);
          const oldHash = this.binaryFileHashes.get(normPath);

          if (newHash !== oldHash) {
            const hashSnapshot = {
              beforeHash: oldHash,
              afterHash: newHash
            };

            this.binaryFileHashes.set(normPath, newHash);
            this.binaryDeletionCache.set(normPath, content);
            if (this.isInErrorCycle && this.isInsideTrackedFolder(normPath)) {
              this.markUserChangeDuringErrorCycle();
              this.storeBinaryEvent(normPath, 'modified', content, hashSnapshot);
            }
          }
        } catch { /* ignore */ }
        return;
      }

      await this.fileQueue.enqueue(normPath, async () => {
        try {
          if (!fs.existsSync(normPath)) {
            return;
          }

          const currentContent = await FileUtils.readFileSafe(normPath);
          const session = this.activeSessions.get(normPath);
          const sessionContent = session ? this.getSessionLastSavedContent(session) : undefined;
          const diskBaselineForFile = this.trackingStore.getRollingBaseline(normPath);
          // Precedence: the FAILURE-STATE snapshot (disk at the moment the build failed — the
          // authoritative broken state, editor-independent) > what the watcher saw this
          // session > first-keystroke capture > session/rolling baseline.
          const failureSnapPath = this.cycleFailureBaselines.get(normPath);
          const failureBaselineContent = failureSnapPath !== undefined
            ? this.getOptionalSnapshotContent(failureSnapPath, '')
            : undefined;
          const memoryContent = this.memory.get(normPath.toLowerCase());
          const typingContent = this.cycleTypingBaselines.get(normPath);
          const lastContent = failureBaselineContent
            ?? memoryContent
            ?? typingContent
            ?? sessionContent
            ?? diskBaselineForFile?.content
            ?? '';
          const lastContentSource = failureBaselineContent !== undefined ? 'failure-state'
            : memoryContent !== undefined ? 'memory'
            : typingContent !== undefined ? 'keystroke'
            : sessionContent !== undefined ? 'session'
            : diskBaselineForFile ? 'rolling-baseline' : 'none';
          const hasExactContentChange = lastContent === undefined || lastContent !== currentContent;
          const hasMeaningfulContentChange = !lastContent || !FileUtils.isPracticallySame(lastContent, currentContent);

          this.telemetry.recordFileProcessed(false);
          const inTrackedFolder = this.isInsideTrackedFolder(normPath);
          const shouldTrackExactChange = this.isInErrorCycle && inTrackedFolder;

          if (!hasExactContentChange) {
            return;
          }

          if (!shouldTrackExactChange && !hasMeaningfulContentChange) {
            return;
          }

          let diskSnapshot: SessionTextSnapshot | null = null;

          if (shouldTrackExactChange) {
            // PRINT, don't assume: the exact "before" identity of every tracked
            // change — which source supplied it and whether it differs from the new content.
            const h = (s: string) => crypto.createHash('sha1').update(s || '').digest('hex').slice(0, 8);
            Logger.log(
              `[FileWatcher] change baseline | ${path.basename(normPath)} | source=${lastContentSource} | `
              + `before=${(lastContent || '').length}ch/${h(lastContent || '')} | `
              + `current=${currentContent.length}ch/${h(currentContent)} | `
              + `differs=${lastContent !== currentContent}`
            );
            this.markUserChangeDuringErrorCycle();
            this.modifiedFilesInCycle.add(normPath);
            diskSnapshot = await this.recordTextChangeForActiveTrackingSessions(
              normPath,
              'modified',
              currentContent,
              lastContent ?? currentContent
            );
            this.recordGradleTextChange(
              normPath,
              'modified',
              failureBaselineContent ?? diskSnapshot?.beforeContent ?? lastContent ?? currentContent,
              currentContent,
              diskSnapshot
            );
          }

          if (this.activeSessions.has(normPath)) {
            await this.handleIntermediateSave(normPath, currentContent);
          } else if (shouldTrackExactChange) {
            // The FAILURE-STATE snapshot is authoritative for "before" (log proof: the
            // change-baseline line said differs=true, yet the event uploaded as no-op because
            // diskSnapshot.beforeContent — the persisted tracking store's own stale value —
            // outranked the corrected lastContent right here at the use-site).
            const original = failureBaselineContent ?? diskSnapshot?.beforeContent ?? lastContent ?? currentContent;
            await this.startSession(normPath, null, original);

            if (hasExactContentChange) {
              await this.handleIntermediateSave(normPath, currentContent);
            }
          } else if (this.batchQueue.length > 0 && inTrackedFolder) {
            const original = lastContent || currentContent;
            await this.startSession(normPath, null, original);

            if (hasMeaningfulContentChange) {
              await this.handleIntermediateSave(normPath, currentContent);
            }
          }

          this.memory.set(normPath.toLowerCase(), currentContent);

          if (hasMeaningfulContentChange) {
            await this.updateRollingBaselineAfterTextChange(normPath, currentContent);
          }

        } catch { /* ignore */ }
      });
    });
  }

  public setTrackedFolder(folderPath: string | null): void {
    const nextTrackedFolder = folderPath ? FileUtils.normalizePath(folderPath) : null;
    if (this.trackedFolder === nextTrackedFolder) { return; }
    this.trackedFolder = nextTrackedFolder;

    if (this.trackedFolder) {
      const trackedPrefix = this.trackedFolder.toLowerCase() + '/';
      for (const filePath of Array.from(this.activeSessions.keys())) {
        if (!filePath.toLowerCase().startsWith(trackedPrefix)) {
          this.activeSessions.delete(filePath);
        }
      }

      for (const filePath of Array.from(this.modifiedFilesInCycle)) {
        if (!filePath.toLowerCase().startsWith(trackedPrefix)) {
          this.modifiedFilesInCycle.delete(filePath);
        }
      }
    }

  }

  public async reconcileErrors(rawErrors: RawBuildError[], requestedTasks: string, taskStatuses?: Map<string, string>) {
    // Usage count: every parsed build outcome, success or failure, so the dashboard can
    // say how many builds happened and how many failed. Report rewrites are already de-duplicated
    // by the watchers, so one distinct report state = one build.
    reportBuildOutcome(this.apiService, this.getProjectName(), (rawErrors || []).length > 0, (rawErrors || []).length);
    if (this.isTd5Mode()) {
      await this.reconcileLegacyGlobalErrors(rawErrors, requestedTasks);
      return;
    }

    await this.reconcileGradleTaskErrors(rawErrors, requestedTasks, taskStatuses);
  }

  private async reconcileGradleTaskErrors(rawErrors: RawBuildError[], requestedTasks: string, taskStatuses?: Map<string, string>): Promise<void> {
    this.telemetry.recordBuildErrors(rawErrors.length);
    this.latestRequestedTasks = requestedTasks.trim();

    const currentTaskErrors = groupBuildErrorsByTask(this.toBuildErrors(rawErrors));
    const currentTaskStatuses = this.normalizeGradleTaskStatuses(taskStatuses);
    this.reviveGradleTaskSessionsFromDiskBeforeReconcile(currentTaskErrors);
    // A clean report alone is NOT proof a pending failed task succeeded: Gradle 9.x rewrites the
    // problems report during OTHER tasks' builds, so blanket resolveAllAbsent popped the previous
    // task's confirm preview when the user merely switched tasks (GBE 9.5 field bug).
    // Resolution now needs SAME-TASK evidence — the session manager resolves a
    // pending task only when its own severity turns non-error, the task itself was requested, or
    // the build re-ran the same launch command that failed it.
    const resolvedTasks = this.taskSessionManager.reconcileTaskErrors(currentTaskErrors, {
      forceResolveAbsent: rawErrors.length === 0,
      resolveAllAbsent: false,
      currentTaskStatuses,
      currentRequestedTasksRaw: requestedTasks
    });

    // Visibility: exactly which tasks this cycle is watching, and which just resolved. Each
    // pending task resolves ONLY on its own success (its non-error report entry, or a clean
    // build that requested it) — other tasks' successes never touch it.
    {
      const watching = this.taskSessionManager.getActiveSessions()
        .filter(s => s.status === 'active_failed' || s.status === 'not_seen_once')
        .map(s => s.taskKey);
      const resolvedKeys = resolvedTasks.map(rt => rt.task.taskKey);
      const reconcileLine =
        `[TaskSession] reconcile: requested='${requestedTasks || '-'}', reportErrors=${rawErrors.length}` +
        `${resolvedKeys.length ? `, RESOLVED now: [${resolvedKeys.join(', ')}]` : ''}` +
        `, still watching ${watching.length} failed task(s)${watching.length ? `: [${watching.join(', ')}]` : ''}`;
      // Gradle rewrites the report several times per build; a reconcile that says exactly the
      // same thing as moments ago is a re-parse, not news — keep the user story to one line.
      const now = Date.now();
      if (reconcileLine === this.lastReconcileLine && (now - this.lastReconcileLineAt) < 60000) {
        Logger.debug(`${reconcileLine} (repeat parse)`);
      } else {
        this.lastReconcileLine = reconcileLine;
        this.lastReconcileLineAt = now;
        Logger.log(reconcileLine);
      }
    }
    await this.syncGradleDiskTrackingSessions();
    this.backfillGradleTaskLinksForTrackedFiles();
    const wasInErrorCycle = this.isInErrorCycle;

    if (rawErrors.length > 0 && !wasInErrorCycle) {
      this.isInErrorCycle = true;
      this.hasUserChangesSinceErrorCycle = false;
      this.startedTrackingFilesInCycle.clear();
      this.cycleTypingBaselines.clear();
      this.cycleFailureBaselines.clear();
      this.modifiedFilesInCycle.clear();
      const firstError = rawErrors[0];
      this.parentErrorTaskPath = String(firstError?.taskPath || '').trim() || null;
      this.rootCycleErrorMessage = String(firstError?.message || '').trim() || null;
      Logger.log(`[AI Assistant] Gradle task failure detected (${rawErrors.length} error${rawErrors.length !== 1 ? 's' : ''})`);
      this.persistInflightCycle();
      // Once per new error cycle: silent shadow prediction on the broken state (no UI).
      this.runShadowPredictionCapture(rawErrors, requestedTasks);
    }

    if (rawErrors.length > 0 && this.isTd5Mode()) {
      await this.ensureGlobalDiskTrackingSession(rawErrors);
      if (this.globalTrackingSessionId) {
        // The errors and the failure tail travel with the disk session, so a revive after a
        // restart can show the real failure in the popup instead of a placeholder.
        this.trackingStore.saveSessionErrors(this.globalTrackingSessionId, rawErrors);
      }
    }

    if (rawErrors.length > 0) {
      // Collect artifacts for ALL failing tasks, not just those with tracked files
      // Artifacts (logs, temp files) are most valuable on first failure for debugging
      await this.collectTaskRuntimeArtifacts(rawErrors);
    }

    const currentErrorsMap = await this.buildGradleCurrentErrorsMap(rawErrors);
    this.updateGradleActiveSessions(currentErrorsMap);

    if (resolvedTasks.length > 0) {
      await this.uploadResolvedGradleTasks(resolvedTasks);
    }

    if (currentErrorsMap.size === 0) {
      await this.handleGradleAllTasksClear();
      return;
    }

    this.handleBuildErrors(currentErrorsMap);
  }

  private async reconcileLegacyGlobalErrors(rawErrors: RawBuildError[], requestedTasks: string) {
    this.telemetry.recordBuildErrors(rawErrors.length);
    this.latestRequestedTasks = requestedTasks.trim();

    // TD5 field case: a failure, then VS Code reopened, then a green build - no
    // popup. The TD5 cycle (errors, log tail, the queued changes) lived only in memory, while the
    // Gradle path revives its task sessions from the disk tracking store. Same treatment here:
    // with no cycle in memory, look for the unresolved TD5 global session on disk first.
    if (!this.isInErrorCycle) {
      this.reviveTd5GlobalCycleFromDisk();
    }

    const wasInErrorCycle = this.isInErrorCycle;

    if (rawErrors.length > 0 && !wasInErrorCycle) {
      this.isInErrorCycle = true;
      this.hasUserChangesSinceErrorCycle = false;
      this.startedTrackingFilesInCycle.clear();
      this.cycleTypingBaselines.clear();
      this.cycleFailureBaselines.clear();
      this.modifiedFilesInCycle.clear();
      const firstError = rawErrors[0];
      this.parentErrorTaskPath = String(firstError?.taskPath || '').trim() || null;
      this.rootCycleErrorMessage = String(firstError?.message || '').trim() || null;
      Logger.log(`[AI Assistant] Build failure detected (${rawErrors.length} error${rawErrors.length !== 1 ? 's' : ''}) — tracking changes in${this.trackedFolder ? ' work/' : ''} workspace`);

      // Clear previous error state when starting a new error cycle
      this.globalErrors = [];
      this.globalErrorSet.clear();

      if (this.isTd5Mode()) {
        if (this.rootCycleErrorMessage) {
          this.globalErrors = [this.rootCycleErrorMessage];
          this.globalErrorSet.add(FileUtils.stripTimestamp(this.rootCycleErrorMessage));
        }
      }
    }

    // The TD5 confirm webview shows the LAST failure's log tail — refresh it on
    // every failed parse of the cycle so the popup always describes the latest failed build.
    if (rawErrors.length > 0 && this.isTd5Mode()) {
      const tail = rawErrors.find(e => e.failureTail)?.failureTail;
      if (tail) { this.lastTd5FailureTail = tail; }
      this.persistInflightCycle();
      // Once per new error cycle: silent shadow prediction on the broken state (no UI).
      this.runShadowPredictionCapture(rawErrors, requestedTasks);
    }

    if (rawErrors.length > 0 && this.isTd5Mode()) {
      await this.ensureGlobalDiskTrackingSession(rawErrors);
      if (this.globalTrackingSessionId) {
        // The errors and the failure tail travel with the disk session, so a revive after a
        // restart can show the real failure in the popup instead of a placeholder.
        this.trackingStore.saveSessionErrors(this.globalTrackingSessionId, rawErrors);
      }
    }

    // TD5 field case (compare showed "no difference"): a file broken and then fixed
    // inside one already-open cycle merged into original->original. The build just FAILED, so
    // the file content RIGHT NOW is the failing state — re-anchor every queued event's "before"
    // to it: the fix that follows then records broken->fixed, which is what the stored
    // knowledge needs. Runs on every failed parse, so repeated fail cycles re-anchor
    // to each latest broken state.
    if (rawErrors.length > 0 && this.batchQueue.length > 0) {
      this.reanchorGlobalQueueToFailureState();
    }

    // The disk at failure time is the authoritative broken state — capture it for recently
    // modified tracked files, no matter which editor produced them (TD5 tool included).
    if (rawErrors.length > 0) {
      this.captureFailureBaselinesForRecentFiles();
    }

    if (rawErrors.length > 0) {
      if (this.isTd5Mode()) {
        // GBE parity (whatever is there is captured): artifacts are the
        // FAILURE's evidence and are captured at failure time — like GBE, NOT gated on the
        // user having edited something first. Field proof: proc/TestEnv_10/log gets fresh
        // files on every failing build, but the classic fail→fix→green cycle collected
        // nothing because its only failure parse arrived before any user edit. The buildtime
        // window still scopes collection to files THIS build wrote.
        await this.collectTd5ProcArtifacts(rawErrors, requestedTasks);
      } else if (this.hasUserChangesSinceErrorCycle) {
        const parentErrors = this.parentErrorTaskPath
          ? rawErrors.filter(e => String(e.taskPath || '').trim() === this.parentErrorTaskPath)
          : (rawErrors[0] ? [rawErrors[0]] : []);
        await this.collectTaskRuntimeArtifacts(parentErrors.length > 0 ? parentErrors : rawErrors.slice(0, 1));
      }
    }

    const currentErrorsMap = await this.buildCurrentErrorsMap(rawErrors);
    await this.updateActiveSessions(currentErrorsMap);

    if (currentErrorsMap.size === 0) {
      await this.handleBuildSuccess();
    } else {
      this.handleBuildErrors(currentErrorsMap);
    }

    await this.startNewErrorSessions(currentErrorsMap);
  }

  /** TD5 only. When VS Code was restarted between the failure and the green build, the cycle
   *  in memory is gone but the disk tracking store still holds the unresolved global session:
   *  its text snapshots (the developer's changes) and its errors and log tail.
   *  Rebuild the in-memory cycle from it so the success parse finds work and opens the popup.
   *  Runtime artifacts are memory-only and are not revived; the fix still uploads without them. */
  private reviveTd5GlobalCycleFromDisk(): boolean {
    if (!this.isTd5Mode() || this.isInErrorCycle) {
      return false;
    }
    let diskSession: TrackingSessionInfo | null = null;
    try {
      diskSession = this.trackingStore.findActiveSessionByScope('td5', 'global', 'td5-global-error-cycle');
    } catch {
      return false;
    }
    if (!diskSession?.sessionId) {
      return false;
    }
    const savedErrors = this.trackingStore.loadSessionErrors(diskSession.sessionId);
    const revivedEvents = this.buildGlobalQueueFromDiskSession(diskSession.sessionId);
    if (savedErrors.length === 0 && revivedEvents.length === 0) {
      return false;
    }

    this.isInErrorCycle = true;
    this.hasUserChangesSinceErrorCycle = revivedEvents.length > 0;
    this.globalTrackingSessionId = diskSession.sessionId;
    this.knownDiskTrackingSessions.add(diskSession.sessionId);
    this.globalErrors = [];
    this.globalErrorSet.clear();
    const first = (savedErrors[0] || {}) as { message?: unknown; taskPath?: unknown };
    const message = String(first.message || '').trim();
    if (message) {
      this.globalErrors = [message];
      this.globalErrorSet.add(FileUtils.stripTimestamp(message));
      this.rootCycleErrorMessage = message;
    }
    this.parentErrorTaskPath = String(first.taskPath || '').trim() || null;
    const tail = savedErrors
      .map((e: { failureTail?: unknown }) => String(e?.failureTail || '').trim())
      .find(Boolean);
    if (tail) {
      this.lastTd5FailureTail = tail;
    }
    for (const event of revivedEvents) {
      if (!this.batchQueue.some((queued) => queued.filePath === event.filePath)) {
        this.batchQueue.push(event);
      }
    }
    Logger.log(
      `[TD5] REVIVED global error cycle from disk: session=${diskSession.sessionId}, ` +
      `changes=${revivedEvents.length}, errors=${savedErrors.length} ` +
      `(the failure was captured before this window started)`
    );
    return true;
  }

  /** The disk session's text snapshots as upload events - the same source the Gradle path
   *  uses after a restart (buildResolvedTaskFilesFromDiskSession), shaped for the global queue.
   *  Content stays on disk; hydrateEventForUpload reads it at upload time. */
  private buildGlobalQueueFromDiskSession(sessionId: string): FileChangeEvent[] {
    const events: FileChangeEvent[] = [];
    let snapshots: SessionTextSnapshot[] = [];
    try {
      snapshots = this.trackingStore.listSessionTextSnapshots(sessionId);
    } catch {
      return events;
    }
    for (const snapshot of snapshots) {
      const before = snapshot.beforeContent || '';
      const after = snapshot.afterContent || '';
      const lastDiverged = snapshot.lastDivergedContent || '';
      const useDiverged = before === after && !!lastDiverged && before !== lastDiverged;
      const uploadAfter = useDiverged ? lastDiverged : after;
      if (before === uploadAfter) {
        continue;   // no net change: nothing to learn from
      }
      const afterPath = useDiverged
        ? (snapshot.lastDivergedSnapshotPath || snapshot.snapshotAfterPath)
        : snapshot.snapshotAfterPath;
      const absolutePath = FileUtils.normalizePath(snapshot.filePath);
      events.push({
        timestamp: snapshot.updatedAt || snapshot.createdAt || new Date().toISOString(),
        eventType: snapshot.eventType || 'modified',
        filePath: absolutePath,
        fileName: path.basename(absolutePath),
        category: 'code',
        workspace: this.workspaceRoot,
        language: path.extname(absolutePath),
        projectName: path.basename(this.workspaceRoot),
        snapshotBefore: { path: absolutePath, content: null },
        snapshotAfter: { path: absolutePath, content: null },
        snapshotBeforeContentPath: snapshot.snapshotBeforePath,
        snapshotAfterContentPath: afterPath,
        lastDivergedSnapshotPath: snapshot.lastDivergedSnapshotPath,
        diffFile: null,
        modifiedFunctions: [],
        errorDetails: []
      });
    }
    return events;
  }

  private buildTaskTrackingDescriptor(session: TaskSession): TrackingSessionDescriptor {
    return {
      sessionId: session.occurrenceId || session.requestId || session.taskKey,
      sessionMode: 'task',
      projectType: 'gradle',
      scopeKey: session.taskKey,
      taskName: session.taskName,
      startedAt: new Date(session.firstSeenAt || Date.now()).toISOString(),
      baselineFrozenAt: new Date(session.firstSeenAt || Date.now()).toISOString()
    };
  }

  private reviveGradleTaskSessionsFromDiskBeforeReconcile(currentTaskErrors: Map<string, BuildError[]>): void {
    if (this.isTd5Mode() || !currentTaskErrors) {
      return;
    }

    const manager = this.taskSessionManager as any;
    const taskSessions = manager?.taskSessions;
    const taskFileMap = manager?.taskFileMap;

    if (!(taskSessions instanceof Map) || !(taskFileMap instanceof Map)) {
      return;
    }

    // Persist THIS parse's failure errors with their disk sessions (the data is gathered in
    // the last session itself). If the user later deletes the build folder,
    // report.html is gone — but the errors live with the session and the next session can show
    // the real data instead of a bare placeholder message.
    for (const [rawTaskKey, errors] of currentTaskErrors.entries()) {
      const taskKey = this.normalizeGradleTaskKey(rawTaskKey);
      if (!taskKey || !Array.isArray(errors) || errors.length === 0) { continue; }
      const diskSession = this.trackingStore.findActiveSessionByScope('gradle', 'task', taskKey);
      if (diskSession?.sessionId) {
        this.trackingStore.saveSessionErrors(diskSession.sessionId, errors);
      }
    }

    for (const [rawTaskKey, errors] of currentTaskErrors.entries()) {
      const taskKey = this.normalizeGradleTaskKey(rawTaskKey);

      if (!taskKey || taskSessions.has(taskKey)) {
        continue;
      }

      const diskSession = this.trackingStore.findActiveSessionByScope(
        'gradle',
        'task',
        taskKey
      );

      if (!diskSession?.sessionId) {
        continue;
      }

      const now = Date.now();
      const firstSeenAt = Date.parse(diskSession.startedAt || '') || now;
      const preparedErrors = Array.isArray(errors) ? errors : [];
      const taskName = diskSession.taskName
        || taskKey.split(':').filter(Boolean).pop()
        || taskKey;

      const revivedTask: TaskSession = {
        taskKey,
        taskName,
        occurrenceId: diskSession.sessionId,
        status: 'active_failed',
        errors: preparedErrors,
        errorHistory: [{ seenAt: now, errors: preparedErrors }],
        firstSeenAt,
        lastSeenAt: now,
        notSeenCount: 0,
        requestId: diskSession.sessionId
      };

      taskSessions.set(taskKey, revivedTask);

      if (!taskFileMap.has(taskKey)) {
        taskFileMap.set(taskKey, new Map<FileKey, any>());
      }

      this.knownDiskTrackingSessions.add(diskSession.sessionId);

      Logger.log(
        `[TaskSession] REVIVED task=${taskKey}, ` +
        `session=${diskSession.sessionId}, status=active_failed, ` +
        `errors=${preparedErrors.length}, changes=${diskSession.changeCount}`
      );
    }

    const unresolvedDiskSessions = this.trackingStore.listTrackingSessions()
      .filter((session) => (
        session.projectType === 'gradle'
        && session.sessionMode === 'task'
        && session.status !== 'resolved'
      ));

    for (const diskSession of unresolvedDiskSessions) {
      const taskKey = this.normalizeGradleTaskKey(diskSession.scopeKey);

      if (!taskKey || taskSessions.has(taskKey) || !diskSession.sessionId) {
        continue;
      }

      // A previous-session failure may only be surfaced
      // WITH its data, and that data is gathered IN the last session itself — the session
      // persists both its file changes and its failure errors, so nothing depends on
      // report.html still existing. No saved errors AND no saved changes => nothing to show
      // => no window at all (a terminated session with no data must not pop up a window).
      const storedErrors = this.trackingStore.loadSessionErrors(diskSession.sessionId);
      const hasChanges = !!diskSession.changeCount && diskSession.changeCount > 0;
      if (storedErrors.length === 0 && !hasChanges) {
        if (!this.skippedEmptyPrevSessions.has(diskSession.sessionId)) {
          this.skippedEmptyPrevSessions.add(diskSession.sessionId);
          Logger.log(
            `[TaskSession] previous-session failure for ${taskKey} has NO saved data — ` +
            `not shown (session ${diskSession.sessionId})`
          );
        }
        continue;
      }

      const now = Date.now();
      const firstSeenAt = Date.parse(diskSession.startedAt || '') || now;
      const taskName = diskSession.taskName
        || taskKey.split(':').filter(Boolean).pop()
        || taskKey;
      // The REAL errors of the previous session when we have them; the descriptive line is
      // only the last resort when the session recorded changes but predates error persistence.
      const fallbackErrors: BuildError[] = storedErrors.length > 0
        ? storedErrors.map((e: any) => ({
            message: String(e?.message || e || '').trim() || 'Task failed in a previous session',
            severity: String(e?.severity || 'ERROR'),
            taskPath: String(e?.taskPath || taskKey),
          }))
        : [{
            message:
              `Task failed in a previous session (interrupted before upload) — ` +
              `${diskSession.changeCount} saved file change(s) from that session are included`,
            severity: 'ERROR',
            taskPath: taskKey
          }];

      const revivedTask: TaskSession = {
        taskKey,
        taskName,
        occurrenceId: diskSession.sessionId,
        status: 'not_seen_once',
        errors: fallbackErrors,
        errorHistory: [{ seenAt: now, errors: fallbackErrors }],
        firstSeenAt,
        lastSeenAt: now,
        notSeenCount: 1,
        requestId: diskSession.sessionId
      };

      taskSessions.set(taskKey, revivedTask);

      if (!taskFileMap.has(taskKey)) {
        taskFileMap.set(taskKey, new Map<FileKey, any>());
      }

      this.knownDiskTrackingSessions.add(diskSession.sessionId);

      Logger.log(
        `[TaskSession] REVIVED task=${taskKey}, ` +
        `session=${diskSession.sessionId}, status=not_seen_once, ` +
        `errors=${fallbackErrors.length}, changes=${diskSession.changeCount}, source=absent_from_current_report`
      );
    }
  }

  private async syncGradleDiskTrackingSessions(): Promise<void> {
    if (this.isTd5Mode()) { return; }

    for (const session of this.taskSessionManager.getActiveSessions()) {
      const currentSessionId = session.occurrenceId || session.requestId || session.taskKey;
      const revivedSession = this.trackingStore.findActiveSessionByScope(
        'gradle',
        'task',
        this.normalizeGradleTaskKey(session.taskKey),
        currentSessionId
      );

      if (revivedSession?.sessionId && revivedSession.sessionId !== currentSessionId) {

        session.occurrenceId = revivedSession.sessionId;
        Logger.log(
          `[TaskSession] REVIVED disk session task=${session.taskKey}, ` +
          `session=${revivedSession.sessionId}, changes=${revivedSession.changeCount}`
        );
      }

      const descriptor = this.buildTaskTrackingDescriptor(session);
      if (this.knownDiskTrackingSessions.has(descriptor.sessionId)) {
        continue;
      }

      await this.trackingStore.ensureSession(descriptor);
      this.knownDiskTrackingSessions.add(descriptor.sessionId);
    }
  }

  private async ensureGlobalDiskTrackingSession(rawErrors: RawBuildError[] = []): Promise<TrackingSessionDescriptor | null> {
    if (!this.isTd5Mode() || !this.isInErrorCycle) {
      return null;
    }

    if (!this.globalTrackingSessionId) {
      this.globalTrackingSessionId = crypto.randomUUID();
    }

    const firstError = rawErrors[0];
    const descriptor: TrackingSessionDescriptor = {
      sessionId: this.globalTrackingSessionId,
      sessionMode: 'global',
      projectType: 'td5',
      scopeKey: 'td5-global-error-cycle',
      startedAt: new Date().toISOString(),
      baselineFrozenAt: new Date().toISOString(),
      taskName: String(firstError?.taskPath || '').trim() || undefined
    };

    if (!this.knownDiskTrackingSessions.has(descriptor.sessionId)) {
      await this.trackingStore.ensureSession(descriptor);
      this.knownDiskTrackingSessions.add(descriptor.sessionId);
    }

    return descriptor;
  }

  private async getActiveTrackingDescriptors(): Promise<TrackingSessionDescriptor[]> {
    if (this.isTd5Mode()) {
      const descriptor = await this.ensureGlobalDiskTrackingSession();
      return descriptor ? [descriptor] : [];
    }

    await this.syncGradleDiskTrackingSessions();
    return this.taskSessionManager.getActiveSessions()
      .filter((session) => session.status === 'active_failed' || session.status === 'not_seen_once')
      .sort((a, b) => (b.firstSeenAt || 0) - (a.firstSeenAt || 0))
      .map((session) => this.buildTaskTrackingDescriptor(session));
  }

  private async recordTextChangeForActiveTrackingSessions(
    filePath: string,
    action: 'added' | 'modified' | 'deleted',
    afterContent: string,
    fallbackBeforeContent?: string
  ): Promise<SessionTextSnapshot | null> {
    const descriptors = await this.getActiveTrackingDescriptors();
    let preferredSnapshot: SessionTextSnapshot | null = null;

    for (const descriptor of descriptors) {
      const snapshot = await this.trackingStore.recordSessionTextChange(
        descriptor,
        filePath,
        action,
        afterContent,
        fallbackBeforeContent
      );

      if (!preferredSnapshot) {
        preferredSnapshot = snapshot;
      }
    }

    return preferredSnapshot;
  }

  private async updateRollingBaselineAfterTextChange(filePath: string, content: string): Promise<void> {
    try {
      await this.trackingStore.updateRollingBaseline(filePath, content);
    } catch (error) {
      Logger.debug('[FileWatcher] Failed to update disk-backed rolling baseline', error);
    }
  }

  private toBuildErrors(rawErrors: RawBuildError[]): BuildError[] {
    return (rawErrors || []).map((error) => {
      // Error paths from the build report are absolute machine paths; store them
      // workspace-relative so error records match across developers' machines.
      let normalizedPath = String(error.path || '');
      if (normalizedPath && path.isAbsolute(normalizedPath)) {
        const rel = FileUtils.toWorkspaceRelativePath(normalizedPath, this.workspaceRoot);
        if (rel) { normalizedPath = rel; }
      }
      return {
        path: normalizedPath,
        message: String(error.message || '').trim(),
        taskPath: String(error.taskPath || '').trim(),
        severity: 'ERROR' as const
      };
    }).filter((error) => !!error.message);
  }

  private recordGradleTextChange(
    filePath: string,
    action: 'added' | 'modified' | 'deleted',
    beforeContent?: string,
    afterContent?: string,
    diskSnapshot?: SessionTextSnapshot | null
  ): void {
    if (this.isTd5Mode()) {
      return;
    }

    if (FileHandlingConfig.isBinaryFile(filePath)) {
      return;
    }

    const record = this.changeStore.recordTextChange({
      absolutePath: filePath,
      action,
      beforeContent: diskSnapshot?.beforeContent ?? beforeContent,
      afterContent: diskSnapshot?.afterContent ?? afterContent,
      lastDivergedContent: diskSnapshot?.lastDivergedContent ?? null,
      snapshotBeforePath: diskSnapshot?.snapshotBeforePath,
      snapshotAfterPath: diskSnapshot?.snapshotAfterPath,
      lastDivergedSnapshotPath: diskSnapshot?.lastDivergedSnapshotPath,
      rawBeforeHash: diskSnapshot?.rawBeforeHash,
      rawAfterHash: diskSnapshot?.rawAfterHash,
      rawLastDivergedHash: diskSnapshot?.rawLastDivergedHash,
      normalizedBeforeHash: diskSnapshot?.normalizedBeforeHash,
      normalizedAfterHash: diskSnapshot?.normalizedAfterHash,
      normalizedLastDivergedHash: diskSnapshot?.normalizedLastDivergedHash,
      changeType: diskSnapshot?.changeType
    });

    if (this.taskSessionManager.hasActiveTasks()) {
      this.taskSessionManager.recordFileChange(record, filePath);
    }
  }

  private recordGradleBinaryChange(
    filePath: string,
    action: 'added' | 'modified' | 'deleted',
    fileContent?: Buffer,
    hashSnapshot?: { beforeHash?: string; afterHash?: string }
  ): void {
    if (this.isTd5Mode()) {
      return;
    }

    const afterHash = hashSnapshot?.afterHash ?? (action === 'deleted'
      ? undefined
      : (fileContent ? this.calculateFileHash(fileContent) : undefined));
    const beforeHash = hashSnapshot?.beforeHash;

    const record = this.changeStore.recordBinaryChange({
      absolutePath: filePath,
      action,
      beforeHash,
      afterHash,
      fileContent,
      sizeBytes: fileContent?.byteLength
    });

    if (this.taskSessionManager.hasActiveTasks()) {
      this.taskSessionManager.recordFileChange(record, filePath);
    }
  }

  private backfillGradleTaskLinksForTrackedFiles(): void {
    if (!this.taskSessionManager.hasActiveTasks()) {
      return;
    }

    for (const filePath of this.modifiedFilesInCycle) {
      const fileKey = this.changeStore.toFileKey(filePath);
      if (!this.changeStore.has(fileKey)) {
        continue;
      }

      const record = this.changeStore.get(fileKey);
      if (!record) {
        continue;
      }
      this.taskSessionManager.recordFileChange(record, filePath);
    }
  }

  private normalizeGradleTaskStatuses(taskStatuses?: Map<string, string>): Map<string, string> {
    const normalized = new Map<string, string>();

    if (!taskStatuses) {
      return normalized;
    }

    for (const [rawTaskKey, rawSeverity] of taskStatuses.entries()) {
      const taskKey = this.normalizeGradleTaskKey(rawTaskKey);
      const severity = String(rawSeverity || '').trim().toUpperCase();

      if (!taskKey || !severity) {
        continue;
      }

      const existing = normalized.get(taskKey);
      if (!existing || this.getGradleSeverityRank(severity) > this.getGradleSeverityRank(existing)) {
        normalized.set(taskKey, severity);
      }
    }

    return normalized;
  }

  private normalizeGradleTaskKey(taskKey: string): string {
    const value = String(taskKey || '').trim();

    if (!value) {
      return '';
    }

    return value.startsWith(':') ? value : `:${value}`;
  }

  private getGradleSeverityRank(severity: string): number {
    switch (String(severity || '').trim().toUpperCase()) {
      case 'ERROR': return 4;
      case 'WARNING': return 3;
      case 'ADVICE': return 2;
      case 'INFO': return 1;
      default: return 0;
    }
  }

  private async buildCurrentErrorsMap(rawErrors: RawBuildError[]): Promise<Map<string, string[]>> {
    const currentErrorsMap = new Map<string, string[]>();

    if (this.isTd5Mode()) {
      if (this.rootCycleErrorMessage && this.globalErrors.length === 0) {
        this.globalErrors = [this.rootCycleErrorMessage];
        this.persistInflightCycle();
      }
    } else {
      let errorsChanged = false;

      for (const err of rawErrors) {
        const msg = err.message?.trim();
        if (!msg) { continue; }

        const strippedKey = FileUtils.stripTimestamp(msg);
        if (!this.globalErrorSet.has(strippedKey)) {
          this.globalErrorSet.add(strippedKey);
          this.globalErrors.push(msg);
          errorsChanged = true;
        }
      }

      if (errorsChanged) {
        this.persistInflightCycle();
      }
    }

    for (const err of rawErrors) {
      let absPath = await FileUtils.resolveErrorPath(err.path, this.workspaceRoot, this.filenameIndex);

      if (!absPath || err.path === '<unknown>') {
        if (this.lastModifiedFile && fs.existsSync(this.lastModifiedFile)) {
          absPath = this.lastModifiedFile;
        }
      }

      if (absPath && absPath.endsWith('report.ts')) { continue; }
      if (!absPath) { continue; }

      const normPath = FileUtils.normalizePath(absPath);
      const existing = currentErrorsMap.get(normPath);

      if (existing) {
        existing.push(err.message);
      } else {
        currentErrorsMap.set(normPath, [err.message]);
      }
    }

    return currentErrorsMap;
  }

  private async updateActiveSessions(currentErrorsMap: Map<string, string[]>): Promise<void> {
    for (const [filePath, session] of this.activeSessions) {
      const newErrorMessages = currentErrorsMap.get(filePath);

      if (!newErrorMessages || newErrorMessages.length === 0) {
        const event = await this.finalizeSessionObject(filePath, session);

        if (event) {
          this.addToBatchOrMerge(event);
        }

        this.activeSessions.delete(filePath);
        continue;
      }

      for (const msg of newErrorMessages) {
        const strippedNew = FileUtils.stripTimestamp(msg.trim());
        const alreadyTracked = session.errorMessages.some(
          (m) => FileUtils.stripTimestamp(m.trim()) === strippedNew
        );

        if (!alreadyTracked) {
          session.errorMessages.push(msg);
        }
      }
    }
  }

  private updateGradleActiveSessions(currentErrorsMap: Map<string, string[]>): void {
    for (const [filePath, session] of this.activeSessions) {
      const newErrorMessages = currentErrorsMap.get(filePath);

      if (!newErrorMessages || newErrorMessages.length === 0) {
        continue;
      }

      for (const msg of newErrorMessages) {
        const strippedNew = FileUtils.stripTimestamp(msg.trim());
        const alreadyTracked = session.errorMessages.some(
          (m) => FileUtils.stripTimestamp(m.trim()) === strippedNew
        );

        if (!alreadyTracked) {
          session.errorMessages.push(msg);
        }
      }
    }
  }

  private async buildGradleCurrentErrorsMap(rawErrors: RawBuildError[]): Promise<Map<string, string[]>> {
    const currentErrorsMap = new Map<string, string[]>();

    for (const err of rawErrors) {
      let absPath = await FileUtils.resolveErrorPath(err.path, this.workspaceRoot, this.filenameIndex);

      if (!absPath || err.path === '<unknown>') {
        if (this.lastModifiedFile && fs.existsSync(this.lastModifiedFile)) {
          absPath = this.lastModifiedFile;
        }
      }

      if (absPath && absPath.endsWith('report.ts')) { continue; }
      if (!absPath) { continue; }

      const normPath = FileUtils.normalizePath(absPath);
      const existing = currentErrorsMap.get(normPath);
      if (existing) {
        existing.push(err.message);
      } else {
        currentErrorsMap.set(normPath, [err.message]);
      }
    }

    return currentErrorsMap;
  }

  // Defense-in-depth against duplicate Review previews: tasks currently in the preview/upload
  // flow. The reconciler already refuses to re-emit resolved_pending_upload sessions; this set
  // additionally drops any duplicate package that still slips through concurrent reconciles.
  private readonly tasksInUploadFlow = new Set<string>();

  private async uploadResolvedGradleTasks(resolvedTasksInput: ResolvedTaskPackage[]): Promise<void> {
    const resolvedTasks = (resolvedTasksInput || []).filter((rt) => {
      const key = rt.task.taskKey;
      if (this.tasksInUploadFlow.has(key)) {
        Logger.log(`[AI Assistant] Skipping duplicate resolved package (preview/upload already in flight): task=${key}`);
        return false;
      }
      this.tasksInUploadFlow.add(key);
      return true;
    });
    try {
      await this.processResolvedGradleTasks(resolvedTasks);
    } finally {
      for (const rt of resolvedTasks) { this.tasksInUploadFlow.delete(rt.task.taskKey); }
    }
  }

  private async processResolvedGradleTasks(resolvedTasks: ResolvedTaskPackage[]): Promise<void> {
    Logger.log(`[AI Assistant] Processing ${resolvedTasks.length} resolved tasks for upload`);
    
    // Phase 1: Prepare all task data (disk I/O, file reading - do this upfront for all tasks)
    Logger.log(`[AI Assistant] Phase 1: Preparing data for ${resolvedTasks.length} tasks (disk I/O)`);
    const preparedTasks: Array<{ resolvedTask: ResolvedTaskPackage; taskData: any }> = [];
    for (const resolvedTask of resolvedTasks) {
      const taskData = await this.prepareTaskDataForPreview(resolvedTask);
      if (taskData) {
        preparedTasks.push({ resolvedTask, taskData });
      }
    }
    
    // Phase 2: Show all previews rapidly and collect user decisions (fast - data already in memory)
    Logger.log(`[AI Assistant] Phase 2: Showing ${preparedTasks.length} previews`);
    const approvedTasks: Array<{ resolvedTask: ResolvedTaskPackage; previewData: any }> = [];
    for (let i = 0; i < preparedTasks.length; i++) {
      const { resolvedTask, taskData } = preparedTasks[i];
      Logger.log(`[AI Assistant] Showing preview ${i + 1} of ${preparedTasks.length} for task: ${resolvedTask.task.taskKey}`);
      const previewData = await this.showTaskPreviewAndGetApproval(taskData);
      if (previewData) {
        approvedTasks.push({ resolvedTask, previewData });
      } else {
        // User cancelled - restore data
        // for (const event of taskData.eventsForTask) { this.addToBatchOrMerge(event); }
        // this.binaryEvents.push(...taskData.binaryEventsForTask);
        // this.taskSessionManager.markTaskUploadFailed(taskData.taskKey, resolvedTask.task, Array.from(taskData.taskFileKeys));
        // User discarded this preview. Treat it as intentionally skipped so it does not reappear.
        await this.discardResolvedTaskWithoutUpload(taskData, 'user-discarded-preview');
      }
    }
    
    // Phase 3: Upload all approved tasks (may take time due to API calls)
    Logger.log(`[AI Assistant] Phase 3: Uploading ${approvedTasks.length} approved tasks`);
    for (const { resolvedTask, previewData } of approvedTasks) {
      await this.executeTaskUpload(resolvedTask, previewData);
    }
  }

  private async prepareTaskDataForPreview(resolvedTask: ResolvedTaskPackage): Promise<any | null> {
    const taskKey = resolvedTask.task.taskKey;
    const diskSessionId = this.resolveDiskSessionIdForTask(
      taskKey,
      resolvedTask.task.occurrenceId || resolvedTask.task.requestId || taskKey
    );
    const taskErrors = this.uniqueErrorMessages(
      resolvedTask.task.errors
        .map((error) => String(error.message || '').trim())
        .filter(Boolean)
    );
    const diskBackedFallback = this.buildResolvedTaskFilesFromDiskSession(diskSessionId, taskKey);

    // PRE-MERGE FIX: The in-memory ChangeStore singleton may hold a snapshotBeforePath
    // pointing to a different task's session folder. If that task uploads first, the folder is deleted,
    // leaving this task with a dead path. We merge the correct, surviving disk session paths
    // specific to THIS task before ensuring files, so the diff builds correctly.
    for (const dLink of diskBackedFallback.fileLinkMap.values()) {
      const existingLink = resolvedTask.fileLinks.find(l => l.fileKey === dLink.fileKey);
      if (existingLink) {
        existingLink.snapshotBeforePath = dLink.snapshotBeforePath;
        existingLink.snapshotAfterPath = dLink.snapshotAfterPath;
        existingLink.lastDivergedSnapshotPath = dLink.lastDivergedSnapshotPath;
      } else {
        resolvedTask.fileLinks.push(dLink);
      }
    }

    let taskFileLinkMap = new Map<FileKey, any>(resolvedTask.fileLinks.map((link) => [link.fileKey, link]));
    let resolvedTaskFiles = await this.ensureResolvedTaskFiles(resolvedTask.files, resolvedTask.fileLinks);

    // Ensure any files strictly from the disk fallback are included
    for (const df of diskBackedFallback.files) {
      if (!resolvedTaskFiles.some(f => f.fileKey === df.fileKey)) {
        resolvedTaskFiles.push(df);
      }
    }

    const taskFileKeys = new Set<FileKey>(resolvedTaskFiles.map((file) => file.fileKey));
    await this.finalizeActiveSessionsForTaskFiles(resolvedTaskFiles, taskErrors);

    Logger.debug(`[FileWatcher] prepareTaskDataForPreview: resolvedTaskFiles=${resolvedTaskFiles.length}, taskFileLinks=${taskFileLinkMap.size}`);
    for (const rf of resolvedTaskFiles) {
      if ((rf as any).kind === 'text') {
        const tf = rf as Extract<FileChangeRecord, { kind: 'text' }>;
        Logger.debug(`[FileWatcher] resolved file: ${tf.absolutePath} action=${tf.action} snapshotBeforePath=${String(tf.snapshotBeforePath||'')} snapshotAfterPath=${String(tf.snapshotAfterPath||'')}`);
      } else {
        Logger.debug(`[FileWatcher] resolved binary file: ${rf.absolutePath} action=${rf.action}`);
      }
    }

    const replacedBatchEventsForTask = this.takeBatchEventsForFileKeys(taskFileKeys);
    this.cleanupEventPayloadFiles(replacedBatchEventsForTask);
    const binaryEventsForTask = this.takeBinaryEventsForFileKeys(taskFileKeys);
    const eventsForTask = await this.buildTaskScopedTextEvents(resolvedTaskFiles, taskFileLinkMap, taskErrors);
    Logger.debug(`[FileWatcher] buildTaskScopedTextEvents produced ${eventsForTask.length} text events for task=${taskKey}`);
    for (const e of eventsForTask) { Logger.debug(`[FileWatcher] event: ${e.filePath} type=${e.eventType} funcs=${e.modifiedFunctions.length}`); }

    const allPendingArtifacts = this.runtimeArtifactCollector.getPendingArtifacts();
    const taskScopedArtifacts = allPendingArtifacts.filter(artifact => 
      String(artifact.taskPath || '').trim() === taskKey
    );

    return {
      taskKey,
      diskSessionId,
      taskErrors,
      taskFileKeys,
      eventsForTask,
      binaryEventsForTask,
      taskScopedArtifacts
    };
  }

  private async showTaskPreviewAndGetApproval(taskData: any): Promise<any | null> {
    const { taskKey, diskSessionId, taskErrors, taskFileKeys, eventsForTask, binaryEventsForTask, taskScopedArtifacts } = taskData;
    
    Logger.log(`[AI Assistant] Showing preview for task=${taskKey}: textFiles=${eventsForTask.length}, binaryFiles=${binaryEventsForTask.length}, artifacts=${taskScopedArtifacts.length}, errors=${taskErrors.length}`);

    // Storage doc §8 (rollout step 5): when the server confirms EVERYTHING is already stored,
    // the popup does not open at all - the developer is not disturbed. The consequence path is
    // identical to a user cancel (already safe). Fail-open: any doubt shows the popup as today.
    if (eventsForTask.length > 0) {
      const alreadyStored = await this.logger.precheckDuplicate(
        this.hydrateEventsForUpload(eventsForTask),
        taskErrors.slice(0, 1),
        diskSessionId || `${Date.now()}`,
        taskKey
      );
      if (alreadyStored) {
        Logger.log(`[AI Assistant] Pre-check: identical fix already stored for task=${taskKey} - popup skipped`);
        vscode.window.setStatusBarMessage(`AI Assistant: identical fix already stored for ${taskKey} - nothing new to upload`, 8000);
        return null;
      }
    }

    const previewResult = await UploadPreviewPanel.requestConfirmation({
        contextLabel: `Gradle Task: ${taskKey}`,
        errors: taskErrors,
        textFiles: eventsForTask.map((e: any, i: number) => ({ id: i.toString(), path: e.filePath, action: e.eventType })),
        binaryFiles: binaryEventsForTask.map((e: any, i: number) => ({ id: i.toString(), path: e.filePath, action: e.action })),
        artifacts: taskScopedArtifacts.map((e: any, i: number) => ({ id: i.toString(), path: e.filePath, group: e.artifactGroup || 'artifact' }))
    });

    if (!previewResult || !previewResult.confirmed) {
        Logger.log(`[AI Assistant] Upload cancelled by user for task: ${taskKey}`);
        return null;
    }

    // Instant feedback the moment the popup closes.
    UploadStatusBar.uploadStarted(`task ${taskKey}`);

    const approvedTextEvents = eventsForTask.filter((e: any, i: number) => previewResult.approvedTextIds.includes(i.toString()));
    const approvedBinaryEvents = binaryEventsForTask.filter((e: any, i: number) => previewResult.approvedBinaryIds.includes(i.toString()));
    const approvedArtifacts = taskScopedArtifacts.filter((e: any, i: number) => previewResult.approvedArtifactIds.includes(i.toString()));

    const discardedTextEvents = eventsForTask.filter((e: any, i: number) => !previewResult.approvedTextIds.includes(i.toString()));
    const discardedBinaryEvents = binaryEventsForTask.filter((e: any, i: number) => !previewResult.approvedBinaryIds.includes(i.toString()));
    this.cleanupCompletedUploadDiskArtifacts('user-discarded-text', discardedTextEvents, discardedBinaryEvents);

    const hasSolutionWork = approvedTextEvents.length > 0 || approvedBinaryEvents.length > 0 || approvedArtifacts.length > 0;

    if (!hasSolutionWork) {
      Logger.log(`[AI Assistant] Resolved Gradle task has no approved changes or artifacts — skipping upload: task=${taskKey}`);
      this.taskSessionManager.markTaskUploaded(taskKey, 0);
      for (const key of taskFileKeys) {
        const absolutePath = this.changeStore.get(key)?.absolutePath;
        if (absolutePath) {
          const normalized = FileUtils.normalizePath(absolutePath);
          this.modifiedFilesInCycle.delete(normalized);
          this.startedTrackingFilesInCycle.delete(normalized);
        }
      }
      await this.trackingStore.markSessionResolved(diskSessionId);
      await this.trackingStore.deleteSessionFolder(diskSessionId);
      this.knownDiskTrackingSessions.delete(diskSessionId);
      this.cleanupCompletedUploadDiskArtifacts(`gradle-task-skipped:${taskKey}`, eventsForTask, binaryEventsForTask);
      await this.cleanupBaselinesIfSafe(`gradle-task-skipped:${taskKey}`);
      this.persistInflightCycle();
      return null;
    }

    return {
      taskKey,
      diskSessionId,
      taskErrors,
      taskFileKeys,
      approvedTextEvents,
      approvedBinaryEvents,
      approvedArtifacts,
      previewResult
    };
  }

    private async discardResolvedTaskWithoutUpload(taskData: any, reason: string): Promise<void> {
    const { taskKey, diskSessionId, taskFileKeys, eventsForTask, binaryEventsForTask } = taskData;
    Logger.log(`[AI Assistant] Discarding resolved task without upload: task=${taskKey}, reason=${reason}`);

    this.taskSessionManager.markTaskUploaded(taskKey, 0);
    for (const key of taskFileKeys) {
      const absolutePath = this.changeStore.get(key)?.absolutePath;
      if (absolutePath) {
        const normalized = FileUtils.normalizePath(absolutePath);
        this.modifiedFilesInCycle.delete(normalized);
        this.startedTrackingFilesInCycle.delete(normalized);
      }
    }

    await this.trackingStore.markSessionResolved(diskSessionId);
    await this.trackingStore.deleteSessionFolder(diskSessionId);
    this.knownDiskTrackingSessions.delete(diskSessionId);
    this.runtimeArtifactCollector.removeArtifactsByTaskPath(taskKey);
    this.cleanupCompletedUploadDiskArtifacts(`gradle-task-discarded:${taskKey}`, eventsForTask, binaryEventsForTask);
    await this.cleanupBaselinesIfSafe(`gradle-task-discarded:${taskKey}:${reason}`);
    this.persistInflightCycle();
  }

  private async executeTaskUpload(resolvedTask: ResolvedTaskPackage, previewData: any): Promise<void> {
    const { taskKey, diskSessionId, taskErrors, taskFileKeys, approvedTextEvents, approvedBinaryEvents, approvedArtifacts, previewResult } = previewData;

    Logger.log(`[AI Assistant] Uploading resolved Gradle task: task=${taskKey}, text=${approvedTextEvents.length}, binary=${approvedBinaryEvents.length}, artifacts=${approvedArtifacts.length}`);

    // One batch id across the bounded retries below: EventLogger caches the created request per
    // batchId, so a retry reuses the same request row instead of creating a duplicate.
    const batchId = crypto.randomUUID();
    let requestId: string | undefined;
    const requestedTaskLabel = this.composeTaskRequestedTasks(taskKey);

    // Bounded IN-FLOW retries for a transiently unreachable backend ("fetch failed"). Retrying
    // here is safe because the approved payload is still exclusively owned by this call and NO
    // cleanup or session-state change runs between attempts — nothing can interfere with (or be
    // clobbered by) a newer build cycle. After the final attempt the unchanged previous behavior
    // applies (restore data + seal the disk session for the next cycle).
    const retryDelaysMs = [30_000, 60_000];
    for (let attempt = 0; ; attempt++) {
    try {
      if (approvedTextEvents.length > 0) {
        requestId = await this.logger.logBatchEvents(
          this.hydrateEventsForUpload(approvedTextEvents),
          taskErrors.slice(0, 1),
          batchId,
          requestedTaskLabel,
          this.developerId,
          previewResult.resolutionDescription
        );
      } else if (taskErrors.length > 0) {
        const result = await this.logger.logErrorOnlyBatch(
          taskErrors,
          batchId,
          requestedTaskLabel,
          this.developerId,
          this.getProjectName(),
          previewResult.resolutionDescription
        );
        requestId = result.requestId;
      }

      if (!requestId && (approvedBinaryEvents.length > 0 || approvedArtifacts.length > 0)) {
        const fallbackErrors = taskErrors.length > 0 ? taskErrors : ["Artifact/Binary Upload for Task"];
        try {
          const result = await this.logger.logErrorOnlyBatch(
            fallbackErrors, batchId, requestedTaskLabel, this.developerId, this.getProjectName(), previewResult.resolutionDescription
          );
          requestId = result.requestId;
        } catch {}
      }

      if (approvedBinaryEvents.length > 0 && requestId) {
        this.logger.enqueueArtifactRetry('binary', batchId, approvedBinaryEvents, this.developerId, requestId);
        await this.logger.sendBinaryFiles(batchId, approvedBinaryEvents, this.developerId, requestId);
        this.logger.removeArtifactRetry('binary', batchId);
      }

      if (approvedArtifacts.length > 0 && requestId) {
        this.logger.enqueueArtifactRetry('runtime', batchId, approvedArtifacts, this.developerId, requestId);
        await this.logger.sendRuntimeArtifacts(batchId, approvedArtifacts, this.developerId, requestId);
        this.logger.removeArtifactRetry('runtime', batchId);
      }
      // Remove only artifacts for this task (preserve artifacts from other concurrent tasks)
      this.runtimeArtifactCollector.removeArtifactsByTaskPath(taskKey);

      this.taskSessionManager.markTaskUploaded(taskKey, approvedTextEvents.length);
      for (const key of taskFileKeys) {
        const absolutePath = this.changeStore.get(key)?.absolutePath;
        if (absolutePath) {
          const normalized = FileUtils.normalizePath(absolutePath);
          this.modifiedFilesInCycle.delete(normalized);
          this.startedTrackingFilesInCycle.delete(normalized);
        }
      }
      await this.trackingStore.markSessionResolved(diskSessionId);
      await this.trackingStore.deleteSessionFolder(diskSessionId);
      this.knownDiskTrackingSessions.delete(diskSessionId);
      this.cleanupCompletedUploadDiskArtifacts(`gradle-task-uploaded:${taskKey}`, approvedTextEvents, approvedBinaryEvents);
      await this.cleanupBaselinesIfSafe(`gradle-task-uploaded:${taskKey}`);
      this.persistInflightCycle();
      return;
    } catch (error) {
      if (attempt < retryDelaysMs.length) {
        const delayMs = retryDelaysMs[attempt];
        Logger.log(`[AI Assistant] Upload attempt ${attempt + 1} failed for task=${taskKey} — retrying in ${Math.round(delayMs / 1000)}s (backend unreachable?)`, error);
        await new Promise<void>((resolve) => setTimeout(resolve, delayMs));
        continue;
      }
      // STRICT TASK ISOLATION (product decision): a task's data belongs to that task's build
      // cycle ONLY. If the upload could not be delivered after the in-flow retries above, the
      // data is DROPPED from memory — never re-queued into the shared batch and never restored
      // for a later cycle — so a previous task's values can never leak into another task's
      // upload. The sealed disk session folder is kept for on-demand viewing only.
      this.runtimeArtifactCollector.removeArtifactsByTaskPath(taskKey);
      this.taskSessionManager.markTaskUploaded(taskKey, 0);
      for (const key of taskFileKeys) {
        const absolutePath = this.changeStore.get(key)?.absolutePath;
        if (absolutePath) {
          const normalized = FileUtils.normalizePath(absolutePath);
          this.modifiedFilesInCycle.delete(normalized);
          this.startedTrackingFilesInCycle.delete(normalized);
        }
      }
      try {
        await this.trackingStore.markSessionResolved(diskSessionId);
        this.knownDiskTrackingSessions.delete(diskSessionId);
      } catch {
        // best-effort sealing; never mask the original upload error
      }
      this.persistInflightCycle();
      Logger.log(`[AI Assistant] Upload failed after ${attempt + 1} attempts — task data dropped per task isolation (kept on disk for viewing only, will NOT carry into any later cycle): task=${taskKey}`, error);
      this.notifyTaskUploadFailure(taskKey, error);
      return;
    }
    }
  }

  // User-visible failure notice (product decision): a developer must never lose an upload
  // silently. Server-unreachable gets a plain "not submitted, try again later" message; any
  // other error is treated as a potential BUG and asks the user to screenshot + contact the
  // AI Assist developers. "Copy Details" puts task/time/reason on the clipboard for reporting.
  private notifyTaskUploadFailure(taskKey: string, error: unknown): void {
    const detail = String((error as any)?.message || error || 'unknown error');
    // Circuit-breaker wording is an INTERNAL retry mechanism — to the user it means exactly
    // "server not reachable"; it must never surface as a cryptic bug popup (BA feedback).
    const isServerUnreachable =
      /fetch failed|ECONNREFUSED|ECONNRESET|ENOTFOUND|ETIMEDOUT|EAI_AGAIN|ENETUNREACH|socket hang up|network|timeout|circuit breaker|saved for automatic retry|503|502|504/i.test(detail);

    const summary = isServerUnreachable
      ? `AI Assist: Task "${taskKey}" could not be uploaded right now (server/network not reachable). ` +
        `Your data is SAVED on this machine and will be re-uploaded automatically when the connection is back — ` +
        `nothing is lost. Watch the status bar below for "uploads pending".`
      : `AI Assist: Task "${taskKey}" was NOT submitted due to an unexpected error — this may be a bug. ` +
        `Please take a screenshot of this message and send it to the AI Assist developers so we can fix it. ` +
        `Error: ${detail.slice(0, 200)}`;

    void vscode.window.showErrorMessage(summary, 'Copy Details').then((choice) => {
      if (choice !== 'Copy Details') { return; }
      const report = [
        'AI Assist upload failure report',
        `time: ${new Date().toISOString()}`,
        `task: ${taskKey}`,
        `project: ${this.getProjectName()}`,
        `reason: ${detail}`,
      ].join('\n');
      void vscode.env.clipboard.writeText(report).then(() => {
        void vscode.window.showInformationMessage(
          'AI Assist: failure details copied to clipboard — please paste them when contacting the AI Assist team.');
      });
    });
  }

  private resolveDiskSessionIdForTask(taskKey: string, preferredSessionId: string): string {
    const normalizedTaskKey = this.normalizeGradleTaskKey(taskKey);
    const revivedSession = this.trackingStore.findActiveSessionByScope(
      'gradle',
      'task',
      normalizedTaskKey,
      preferredSessionId
    );

    return revivedSession?.sessionId || preferredSessionId || normalizedTaskKey;
  }

  private buildResolvedTaskFilesFromDiskSession(
    sessionId: string,
    taskKey: string
  ): { files: FileChangeRecord[]; fileLinkMap: Map<FileKey, any> } {
    const normalizedTaskKey = this.normalizeGradleTaskKey(taskKey);
    const snapshots = this.trackingStore.listSessionTextSnapshots(sessionId)
      .filter((snapshot) => !normalizedTaskKey || String(snapshot.scopeKey || '').trim() === normalizedTaskKey);
    const files: FileChangeRecord[] = [];
    const fileLinkMap = new Map<FileKey, any>();

    for (const snapshot of snapshots) {
      const beforeContent = snapshot.beforeContent || '';
      const afterContent = snapshot.afterContent || '';
      const lastDivergedContent = snapshot.lastDivergedContent || '';
      const exactBefore = beforeContent;
      const exactAfter = afterContent;
      const exactLastDiverged = lastDivergedContent || '';
      const shouldUseLastDiverged = exactBefore === exactAfter && !!exactLastDiverged && exactBefore !== exactLastDiverged;
      const uploadAfterContent = shouldUseLastDiverged ? exactLastDiverged : exactAfter;

      if (exactBefore === uploadAfterContent) {
        continue;
      }

      const changedAt = Date.parse(snapshot.updatedAt || snapshot.createdAt || '') || Date.now();
      const action = snapshot.eventType || 'modified';
      const snapshotAfterPath = shouldUseLastDiverged
        ? (snapshot.lastDivergedSnapshotPath || snapshot.snapshotAfterPath)
        : snapshot.snapshotAfterPath;

      files.push({
        kind: 'text',
        fileKey: snapshot.fileKey,
        filePath: snapshot.fileKey,
        absolutePath: FileUtils.normalizePath(snapshot.filePath),
        action,
        beforeContent,
        afterContent: uploadAfterContent,
        latestBeforeContent: beforeContent,
        latestAfterContent: uploadAfterContent,
        firstChangedAt: Date.parse(snapshot.createdAt || '') || changedAt,
        lastChangedAt: changedAt,
        snapshotBeforePath: snapshot.snapshotBeforePath,
        snapshotAfterPath,
        lastDivergedSnapshotPath: snapshot.lastDivergedSnapshotPath
      } as any);

      fileLinkMap.set(snapshot.fileKey, {
        fileKey: snapshot.fileKey,
        linkType: 'direct',
        linkedAt: Date.parse(snapshot.createdAt || '') || changedAt,
        lastChangedAt: changedAt,
        activityCount: 1,
        fileKind: 'text',
        initialTextContent: beforeContent,
        latestTextBeforeContent: beforeContent,
        latestTextAfterContent: uploadAfterContent,
        latestAction: action,
        snapshotBeforePath: snapshot.snapshotBeforePath,
        snapshotAfterPath,
        lastDivergedSnapshotPath: snapshot.lastDivergedSnapshotPath,
        textChangeTrail: [{
          changedAt,
          action,
          beforeContent,
          afterContent: uploadAfterContent,
          snapshotBeforePath: snapshot.snapshotBeforePath,
          snapshotAfterPath,
          lastDivergedSnapshotPath: snapshot.lastDivergedSnapshotPath
        }]
      });
    }

    return { files, fileLinkMap };
  }

  private uniqueErrorMessages(messages: string[]): string[] {
    const result: string[] = [];
    const seen = new Set<string>();

    for (const message of messages || []) {
      const normalized = String(message || '').replace(/\s+/g, ' ').trim();
      const key = normalized.toLowerCase();

      if (!normalized || seen.has(key)) {
        continue;
      }

      seen.add(key);
      result.push(String(message || '').trim());
    }

    return result;
  }

  private async buildTextEventsFromChangeStore(files: FileChangeRecord[], taskErrors: string[]): Promise<FileChangeEvent[]> {
    const events: FileChangeEvent[] = [];

    for (const file of files) {
      if (file.kind !== 'text') {
        continue;
      }

      if (FileHandlingConfig.isBinaryFile(file.absolutePath)) {
        continue;
      }

      const beforeContent = this.getRecordBeforeContent(file);
      const afterContent = this.getRecordAfterContent(file);
      const action = file.action;

      if (action === 'deleted' && !beforeContent && !afterContent) {
        const event = await this.buildEventObject(FileUtils.normalizePath(file.absolutePath), '', '', taskErrors.slice(0, 1));
        event.eventType = 'deleted';
        event.modifiedFunctions = [{
          functionName: 'file-level-change',
          before: { functionCode: null },
          after: { functionCode: null },
          linesBeforeChanges: [{ line: 1, content: '// [File deleted but original content was not cached by extension]' }],
          linesAfterChanges: []
        }];
        events.push(event);
        continue;
      }

      if (beforeContent === afterContent) {
        events.push(this.buildDiscardedTextEvent(file, taskErrors.slice(0, 1)));
        continue;
      }

      if (!file.absolutePath || (!fs.existsSync(file.absolutePath) && !file.snapshotAfterPath)) {
        continue;
      }

      const event = await this.buildEventObject(
        FileUtils.normalizePath(file.absolutePath),
        beforeContent,
        afterContent,
        taskErrors.slice(0, 1)
      );

      if (event.modifiedFunctions.length === 0) {
        const diff = DiffGenerator.getDiffStats(beforeContent || '', afterContent || '');
        Logger.debug(`[FileWatcher] buildTextEventsFromChangeStore: no modifiedFunctions for ${file.absolutePath}; diff.added=${diff.added.length} removed=${diff.removed.length}`);
        if (diff.added.length > 0 || diff.removed.length > 0) {
          event.modifiedFunctions = [{
            functionName: 'file-level-change',
            before: { functionCode: null },
            after: { functionCode: null },
            linesBeforeChanges: diff.removed,
            linesAfterChanges: diff.added
          }];
        } else {
          continue;
        }
      }

      events.push(event);
    }

    return events;
  }

  private async buildTaskScopedTextEvents(
    files: FileChangeRecord[],
    taskFileLinkMap: Map<FileKey, {
      linkType?: 'direct' | 'shared' | 'inferred';
      initialTextContent?: string;
      activityCount?: number;
      latestTextBeforeContent?: string;
      latestTextAfterContent?: string;
      latestAction?: 'added' | 'modified' | 'deleted';
      textChangeTrail?: TaskTextChangeSnapshot[];
      snapshotBeforePath?: string;
      snapshotAfterPath?: string;
      lastDivergedSnapshotPath?: string | null;
    }>,
    taskErrors: string[]
  ): Promise<FileChangeEvent[]> {
    const events: FileChangeEvent[] = [];

    for (const file of files) {
      if (file.kind !== 'text') {
        continue;
      }

      const link = taskFileLinkMap.get(file.fileKey);
      if (!link) {
        continue;
      }

      const baselineContent = this.getLinkBeforeContent(link, file);
      const currentContent = this.getLinkAfterContent(link, file);
      const action = link?.latestAction || file.action;
      const exactSame = baselineContent === currentContent;
      const practicallySame = FileUtils.isPracticallySame(baselineContent || '', currentContent || '');
      Logger.debug(`[FileWatcher] buildTaskScopedTextEvents: file=${file.absolutePath} action=${action} linkType=${String(link.linkType)} baselineLen=${String((baselineContent||'').length)} currentLen=${String((currentContent||'').length)} exactSame=${exactSame} practicalSame=${practicallySame}`);
      if (action === 'deleted' && !baselineContent && !currentContent) {
        const event = await this.buildEventObject(FileUtils.normalizePath(file.absolutePath), '', '', taskErrors.slice(0, 1));
        event.eventType = 'deleted';
        event.modifiedFunctions = [{
          functionName: 'file-level-change',
          before: { functionCode: null },
          after: { functionCode: null },
          linesBeforeChanges: [{ line: 1, content: '// [File deleted but original content was not cached by extension]' }],
          linesAfterChanges: []
        }];
        events.push(event);
        continue;
      }
      const isMeaningfullySameAsBaseline = exactSame;
      const preservedSnapshot = this.selectPreservedTextSnapshot(link, currentContent);
      const preservedBefore = preservedSnapshot ? this.getTaskSnapshotBeforeContent(preservedSnapshot) : this.getOptionalSnapshotContent(link.snapshotBeforePath, link.latestTextBeforeContent);
      const preservedAfter = preservedSnapshot ? this.getTaskSnapshotAfterContent(preservedSnapshot) : this.getOptionalSnapshotContent(link.snapshotAfterPath, link.latestTextAfterContent);
      Logger.debug(`[FileWatcher] preservedSnapshot? ${preservedSnapshot ? 'yes' : 'no'} preservedBeforeLen=${String((preservedBefore||'').length)} preservedAfterLen=${String((preservedAfter||'').length)}`);

      if (isMeaningfullySameAsBaseline) {
        const preservedSame = preservedBefore === preservedAfter;
        Logger.debug(`[FileWatcher] preservedEquality: same=${preservedSame} latestBefore=${String(link.latestTextBeforeContent?.length||0)} latestAfter=${String(link.latestTextAfterContent?.length||0)}`);
        if (
          typeof preservedBefore === 'string'
          && typeof preservedAfter === 'string'
          && !FileUtils.isPracticallySame(preservedBefore, preservedAfter)
        ) {
          const preservedEvent = await this.buildEventObject(
            FileUtils.normalizePath(file.absolutePath),
            preservedBefore,
            preservedAfter,
            taskErrors.slice(0, 1)
          );
          Logger.debug(`[FileWatcher] preservedEvent built: ${preservedEvent.filePath} funcs=${preservedEvent.modifiedFunctions.length}`);
          if (preservedEvent.modifiedFunctions.length === 0) {
            const diff = DiffGenerator.getDiffStats(preservedBefore, preservedAfter);
            Logger.debug(`[FileWatcher] preservedEvent has 0 modifiedFunctions; diff.added=${diff.added.length} removed=${diff.removed.length}`);
          }
          events.push(preservedEvent);
        }
        continue;
      }

      if (baselineContent === currentContent) {
        if ((link.activityCount || 0) > 0) {
          if (typeof preservedBefore === 'string'
            && typeof preservedAfter === 'string'
            && preservedBefore !== preservedAfter) {
            const preservedEvent = await this.buildEventObject(
              FileUtils.normalizePath(file.absolutePath),
              preservedBefore,
              preservedAfter,
              taskErrors.slice(0, 1)
            );

            events.push(preservedEvent);
            continue;
          }

          if (typeof link.latestTextBeforeContent === 'string'
            && typeof link.latestTextAfterContent === 'string'
            && link.latestTextBeforeContent !== link.latestTextAfterContent) {
            Logger.debug(`[FileWatcher] buildTaskScopedTextEvents fallback to latestTextBefore/After for shared link: ${file.absolutePath}`);
            const preservedEvent = await this.buildEventObject(
              FileUtils.normalizePath(file.absolutePath),
              link.latestTextBeforeContent,
              link.latestTextAfterContent,
              taskErrors.slice(0, 1)
            );
            events.push(preservedEvent);
            continue;
          }

          events.push(this.buildDiscardedTextEventFromContents(file.absolutePath, baselineContent, currentContent, taskErrors.slice(0, 1)));
        }
        continue;
      }

      const event = await this.buildEventObject(
        FileUtils.normalizePath(file.absolutePath),
        baselineContent,
        currentContent,
        taskErrors.slice(0, 1)
      );
      Logger.debug(`[FileWatcher] built event for ${event.filePath} funcs=${event.modifiedFunctions.length}`);
      if (event.modifiedFunctions.length === 0) {
        const diff = DiffGenerator.getDiffStats(baselineContent || '', currentContent || '');
        Logger.debug(`[FileWatcher] event has no modifiedFunctions but diff.added=${diff.added.length} removed=${diff.removed.length}`);
        if (diff.added.length > 0 || diff.removed.length > 0) {
          event.modifiedFunctions = [{
            functionName: 'file-level-change',
            before: { functionCode: null },
            after: { functionCode: null },
            linesBeforeChanges: diff.removed,
            linesAfterChanges: diff.added
          }];
        } else {
          Logger.debug(`[FileWatcher] skipping event because no diff and no modifiedFunctions for ${event.filePath}`);
          continue;
        }
      }

      events.push(event);
    }

    return events;
  }

  private async ensureResolvedTaskFiles(
    files: FileChangeRecord[],
    fileLinks: Array<{
      fileKey: FileKey;
      linkType?: 'direct' | 'shared' | 'inferred';
      fileKind?: 'text' | 'binary';
      linkedAt: number;
      lastChangedAt: number;
      initialTextContent?: string;
      latestTextBeforeContent?: string;
      latestTextAfterContent?: string;
      latestAction?: 'added' | 'modified' | 'deleted';
      textChangeTrail?: TaskTextChangeSnapshot[];
      snapshotBeforePath?: string;
      snapshotAfterPath?: string;
      lastDivergedSnapshotPath?: string | null;
    }>
  ): Promise<FileChangeRecord[]> {
    const byFileKey = new Map<FileKey, FileChangeRecord>((files || []).map((file) => [file.fileKey, file]));

    for (const link of fileLinks || []) {
      if (!link?.fileKey || byFileKey.has(link.fileKey) || link.fileKind === 'binary') {
        continue;
      }

      const absolutePath = this.toAbsolutePathFromFileKey(link.fileKey);
      const exists = fs.existsSync(absolutePath);
      const currentContent = exists ? await FileUtils.readFileSafe(absolutePath) : '';
      const baselineContent = this.getOptionalSnapshotContent(link.snapshotBeforePath, link.initialTextContent ?? currentContent) || '';
      const afterContent = this.getOptionalSnapshotContent(link.snapshotAfterPath, link.latestTextAfterContent ?? currentContent) || '';
      const action = link.latestAction || (exists ? 'modified' : 'deleted');

      byFileKey.set(link.fileKey, {
        kind: 'text',
        fileKey: link.fileKey,
        filePath: link.fileKey,
        absolutePath,
        action,
        beforeContent: baselineContent,
        afterContent,
        latestBeforeContent: typeof link.latestTextBeforeContent === 'string' ? link.latestTextBeforeContent : baselineContent,
        latestAfterContent: afterContent,
        firstChangedAt: link.linkedAt || link.lastChangedAt || Date.now(),
        lastChangedAt: link.lastChangedAt || link.linkedAt || Date.now()
      });
    }

    return Array.from(byFileKey.values());
  }

  private getOptionalSnapshotContent(snapshotPath?: string | null, fallback = ''): string {
    if (snapshotPath) {
      try {
        if (fs.existsSync(snapshotPath)) {
          return fs.readFileSync(snapshotPath, 'utf8').replace(/\r\n/g, '\n');
        }
      } catch { /* ignore */ }
    }

    return fallback || '';
  }

  private getRecordBeforeContent(record: Extract<FileChangeRecord, { kind: 'text' }>): string {
    return this.getOptionalSnapshotContent(record.snapshotBeforePath, record.beforeContent || record.latestBeforeContent || '');
  }

  private getRecordAfterContent(record: Extract<FileChangeRecord, { kind: 'text' }>): string {
    return this.getOptionalSnapshotContent(record.snapshotAfterPath, record.afterContent || record.latestAfterContent || '');
  }

  private getTaskSnapshotBeforeContent(snapshot: TaskTextChangeSnapshot): string {
    return this.getOptionalSnapshotContent(snapshot.snapshotBeforePath, snapshot.beforeContent || '');
  }

  private getTaskSnapshotAfterContent(snapshot: TaskTextChangeSnapshot): string {
    return this.getOptionalSnapshotContent(snapshot.snapshotAfterPath, snapshot.afterContent || '');
  }

  private getLinkBeforeContent(
    link: {
      snapshotBeforePath?: string;
      initialTextContent?: string;
      latestTextBeforeContent?: string;
    },
    file: Extract<FileChangeRecord, { kind: 'text' }>
  ): string {
    return this.getOptionalSnapshotContent(
      link.snapshotBeforePath || file.snapshotBeforePath,
      link.initialTextContent ?? link.latestTextBeforeContent ?? file.beforeContent ?? file.latestBeforeContent ?? ''
    );
  }

  private getLinkAfterContent(
    link: {
      snapshotAfterPath?: string;
      latestTextAfterContent?: string;
      latestAction?: 'added' | 'modified' | 'deleted';
    },
    file: Extract<FileChangeRecord, { kind: 'text' }>
  ): string {
    if (file.action === 'deleted' || link.latestAction === 'deleted') {
      return this.getOptionalSnapshotContent(link.snapshotAfterPath || file.snapshotAfterPath, '');
    }

    return this.getOptionalSnapshotContent(
      link.snapshotAfterPath || file.snapshotAfterPath,
      link.latestTextAfterContent ?? file.afterContent ?? file.latestAfterContent ?? ''
    );
  }

  private toAbsolutePathFromFileKey(fileKey: FileKey): string {
    const normalizedKey = FileUtils.normalizePath(fileKey);

    if (path.isAbsolute(normalizedKey)) {
      return normalizedKey;
    }

    return FileUtils.normalizePath(path.join(this.workspaceRoot, normalizedKey));
  }

  private buildDiscardedTextEvent(file: Extract<FileChangeRecord, { kind: 'text' }>, taskErrors: string[]): FileChangeEvent {
    return this.buildDiscardedTextEventFromContents(file.absolutePath, this.getRecordBeforeContent(file), this.getRecordAfterContent(file), taskErrors);
  }

  private buildDiscardedTextEventFromContents(
    absolutePath: string,
    beforeContent: string,
    afterContent: string,
    taskErrors: string[]
  ): FileChangeEvent {
    const normalizedPath = FileUtils.normalizePath(absolutePath);

    return {
      timestamp: new Date().toISOString(),
      eventType: 'modified',
      filePath: normalizedPath,
      fileName: path.basename(normalizedPath),
      category: 'code',
      workspace: this.workspaceRoot,
      language: path.extname(normalizedPath),
      projectName: path.basename(this.workspaceRoot),
      snapshotBefore: { path: normalizedPath, content: beforeContent },
      snapshotAfter: { path: normalizedPath, content: afterContent },
      diffFile: null,
      modifiedFunctions: [{
        functionName: 'discarded-cycle-change',
        before: { functionCode: null },
        after: { functionCode: null },
        linesBeforeChanges: [],
        linesAfterChanges: []
      }],
      errorDetails: taskErrors.map((msg) => ({ message: msg }))
    };
  }

  private selectPreservedTextSnapshot(
    link: {
      textChangeTrail?: TaskTextChangeSnapshot[];
      latestTextBeforeContent?: string;
      latestTextAfterContent?: string;
    },
    currentContent: string
  ): TaskTextChangeSnapshot | null {
    const trail = Array.isArray(link.textChangeTrail) ? link.textChangeTrail : [];

    for (let index = trail.length - 1; index >= 0; index--) {
      const snapshot = trail[index];

      if (!snapshot || this.getTaskSnapshotBeforeContent(snapshot) === this.getTaskSnapshotAfterContent(snapshot)) {
        continue;
      }

      const snapshotBefore = this.getTaskSnapshotBeforeContent(snapshot);
      const snapshotAfter = this.getTaskSnapshotAfterContent(snapshot);
      if (snapshotAfter === currentContent || snapshotBefore === currentContent) {
        return snapshot;
      }
    }

    for (let index = trail.length - 1; index >= 0; index--) {
      const snapshot = trail[index];

      if (snapshot && this.getTaskSnapshotBeforeContent(snapshot) !== this.getTaskSnapshotAfterContent(snapshot)) {
        return snapshot;
      }
    }

    return null;
  }

  private async finalizeActiveSessionsForTaskFiles(files: FileChangeRecord[], taskErrors: string[]): Promise<void> {
    for (const file of files) {
      const filePath = FileUtils.normalizePath(file.absolutePath);
      const session = this.activeSessions.get(filePath);

      if (!session) {
        continue;
      }

      if (session.errorMessages.length === 0 && taskErrors.length > 0) {
        session.errorMessages = taskErrors.slice(0, 1);
      }

      const event = await this.finalizeSessionObject(filePath, session);
      if (event) {
        this.addToBatchOrMerge(event);
      }

      this.activeSessions.delete(filePath);
    }
  }

  private takeBatchEventsForFileKeys(fileKeys: Set<FileKey>): FileChangeEvent[] {
    if (fileKeys.size === 0) {
      return [];
    }

    const selected: FileChangeEvent[] = [];
    const remaining: FileChangeEvent[] = [];

    for (const event of this.batchQueue) {
      const key = this.changeStore.toFileKey(event.filePath);

      if (fileKeys.has(key)) {
        selected.push(event);
      } else {
        remaining.push(event);
      }
    }

    this.batchQueue = remaining;
    return selected;
  }

  private takeBinaryEventsForFileKeys(fileKeys: Set<FileKey>): BinaryEvent[] {
    if (fileKeys.size === 0) {
      return [];
    }

    const selected: BinaryEvent[] = [];
    const remaining: BinaryEvent[] = [];

    for (const event of this.binaryEvents) {
      const key = this.changeStore.toFileKey(event.absolutePath || event.filePath);

      if (fileKeys.has(key)) {
        selected.push(event);
      } else {
        remaining.push(event);
      }
    }

    this.binaryEvents = remaining;
    return selected;
  }

  private composeTaskRequestedTasks(taskKey: string): string {
    return String(taskKey || '').trim();
  }

  private async handleGradleAllTasksClear(): Promise<void> {
    if (this.taskSessionManager.hasActiveTasks()) {
      return;
    }

    if (this.batchQueue.length > 0 || this.binaryEvents.length > 0 || this.runtimeArtifactCollector.hasPendingArtifacts()) {
      Logger.log(
        `[AI Assistant] Gradle task cycle clear — dropping orphaned non-task data: ` +
        `${this.batchQueue.length} change(s), ` +
        `${this.binaryEvents.length} binary file(s), ` +
        `${this.runtimeArtifactCollector.getPendingCount()} artifact(s)`
      );

      this.cleanupCompletedUploadDiskArtifacts('gradle-orphaned-data-dropped', this.batchQueue, this.binaryEvents);
      this.batchQueue = [];
      this.binaryEvents = [];
      this.runtimeArtifactCollector.clear();
    }

    this.latestRequestedTasks = '';
    this.hasUserChangesSinceErrorCycle = false;
    this.startedTrackingFilesInCycle.clear();
    this.cycleTypingBaselines.clear();
    this.cycleFailureBaselines.clear();
    this.modifiedFilesInCycle.clear();
    this.parentErrorTaskPath = null;
    this.rootCycleErrorMessage = null;
    this.globalErrors = [];
    this.globalErrorSet.clear();
    this.isInErrorCycle = false;
    this.snapshotManager.clearSnapshots();
    this.clearCopilotSession();
    this.persistInflightCycle();
    await this.cleanupBaselinesIfSafe('gradle-all-tasks-clear');
  }

  private async handleBuildSuccess() {
    if (this.buildSuccessInFlight) {
      // A previous confirm panel is still open (or stuck: a webview that failed to render never
      // resolves its confirmation). Without this line the next success is skipped in silence.
      Logger.log('[AI Assistant] Build success detected — but the previous review popup is still open/unresolved. Close it (or restart the window) to get the next popup.');
      return;
    }
    this.buildSuccessInFlight = true;

    try {
      // No-net-change events (broken and fixed back to identical content, or an unrelated file
      // whose re-anchored baseline never diverged again) carry no knowledge: drop them so the
      // popup and the stored diff stay honest. Fix files keep broken->fixed via the
      // failure-time re-anchor.
      const keepEvents: FileChangeEvent[] = [];
      const noOpEvents: FileChangeEvent[] = [];
      for (const e of this.batchQueue) {
        (this.isNoOpChangeEvent(e) ? noOpEvents : keepEvents).push(e);
      }
      if (noOpEvents.length > 0) {
        this.batchQueue = keepEvents;
        // Hydrate for the diagnostic BEFORE cleanup deletes the snapshot files (the diagnostic
        // showed 0ch/0ch only because the hashes were computed post-cleanup).
        const hh = (s: string) => crypto.createHash('sha1').update(s || '').digest('hex').slice(0, 8);
        const skippedNames = noOpEvents.map((e) => {
          try {
            const hydrated = this.hydrateEventForUpload(e);
            const b = String(hydrated.snapshotBefore?.content ?? '');
            const a = String(hydrated.snapshotAfter?.content ?? '');
            return `${path.basename(String(e.filePath || ''))}(before=${b.length}ch/${hh(b)}, after=${a.length}ch/${hh(a)})`;
          } catch {
            return path.basename(String(e.filePath || ''));
          }
        }).filter(Boolean).join(', ');
        this.cleanupCompletedUploadDiskArtifacts('no-op-net-change-dropped', noOpEvents);
        Logger.log(`[AI Assistant] Skipped ${noOpEvents.length} file(s) with no net change this cycle${skippedNames ? `: ${skippedNames}` : ''}`);
        this.persistInflightCycle();
      }

      const hasWork = this.batchQueue.length > 0
        || this.binaryEvents.length > 0
        || this.runtimeArtifactCollector.hasPendingArtifacts()
        || this.globalErrors.length > 0;

      if (hasWork) {
        // UPLOAD-SIDE SCOPING (proven by the stored data: two ctc_aurix fixes were
        // holding python debug.logs, so a python failure got answered with a ctc fix).
        // The per-task upload path has always been task-scoped; THIS global path took every
        // pending artifact, so a log left over from an earlier UNFINISHED failure was stapled
        // to whatever fix was confirmed next. globalErrors is reset at the start of each error
        // cycle, so it names exactly the failures this upload resolves - an artifact belongs
        // here only if it was collected FOR one of them. Same ladder the query side already
        // uses: match by failure, else keep everything when there is no ambiguity to resolve
        // (all pending artifacts from one task), else keep none - attaching another failure's
        // log is worse than attaching none, because wrong evidence actively picks the wrong
        // solution while missing evidence just falls back to the error text.
        const _pending = this.runtimeArtifactCollector.getPendingArtifacts();
        const _cycleFailures = new Set(this.globalErrors.map(e => FileUtils.stripTimestamp(String(e || '').trim())).filter(Boolean));
        // An artifact is excluded only when its stamp proves it belongs to a DIFFERENT failure.
        // An artifact with no stamp cannot be disproved, so it is kept: that is exactly how this
        // behaved before stamping existed, which is what an older build of this extension still
        // produces. Only a positive contradiction removes anything.
        // With no known failure for this upload there is nothing to disprove anything against,
        // so everything is kept - a stamped artifact must never fail an empty-set lookup.
        const allPendingArtifacts = _cycleFailures.size === 0 ? _pending : _pending.filter(a => {
          const _fm = String((a as any).failureMessage || '').trim();
          return _fm ? _cycleFailures.has(FileUtils.stripTimestamp(_fm)) : true;
        });
        if (_pending.length !== allPendingArtifacts.length) {
          Logger.log(`[AI Assistant] Artifact scoping: ${allPendingArtifacts.length}/${_pending.length} artifact(s) belong to this failure — the rest stay pending for their own cycle`);
        }
        if (_pending.length > 0 && allPendingArtifacts.length === 0) {
          Logger.log(`[AI Assistant] Artifact scoping: none of the ${_pending.length} pending artifact(s) belong to this failure — uploading the fix without artifacts rather than attaching another failure's logs`);
        }

        const previewResult = await UploadPreviewPanel.requestConfirmation({
            contextLabel: `Global Build / TD5`,
            errors: this.globalErrors,
            // TD5: show the failing build's log tail — the actual cause — instead
            // of the raw extracted error list. GBE payloads never set this; their webview is unchanged.
            ...(this.isTd5Mode() && this.lastTd5FailureTail ? { failureSummary: this.lastTd5FailureTail } : {}),
            textFiles: this.batchQueue.map((e, i) => ({ id: i.toString(), path: e.filePath, action: e.eventType })),
            binaryFiles: this.binaryEvents.map((e, i) => ({ id: i.toString(), path: e.filePath, action: e.action })),
            artifacts: allPendingArtifacts.map((e, i) => ({ id: i.toString(), path: e.filePath, group: e.artifactGroup || 'artifact' }))
        });

        if (!previewResult || !previewResult.confirmed) {
            Logger.log(`[AI Assistant] Global upload cancelled by user.`);
            return;
        }

        // Instant feedback the moment the popup closes: the user sees the
        // upload is running in the background before any network result exists.
        UploadStatusBar.uploadStarted('build data');

        const approvedTextEvents = this.batchQueue.filter((e, i) => previewResult.approvedTextIds.includes(i.toString()));
        const approvedBinaryEvents = this.binaryEvents.filter((e, i) => previewResult.approvedBinaryIds.includes(i.toString()));
        const approvedArtifacts = allPendingArtifacts.filter((e, i) => previewResult.approvedArtifactIds.includes(i.toString()));

        const discardedTextEvents = this.batchQueue.filter((e, i) => !previewResult.approvedTextIds.includes(i.toString()));
        const discardedBinaryEvents = this.binaryEvents.filter((e, i) => !previewResult.approvedBinaryIds.includes(i.toString()));
        this.cleanupCompletedUploadDiskArtifacts('user-discarded-text', discardedTextEvents, discardedBinaryEvents);

        Logger.log(`[AI Assistant] Build success — text=${approvedTextEvents.length}, binary=${approvedBinaryEvents.length}, artifacts=${approvedArtifacts.length} — uploading`);
        const batchId = crypto.randomUUID();
        let requestId: string | undefined;

        if (approvedTextEvents.length > 0) {
          try {
            requestId = await this.logger.logBatchEvents(
                this.hydrateEventsForUpload(approvedTextEvents), 
                this.globalErrors.slice(0, 1), 
                batchId, 
                this.latestRequestedTasks, 
                this.developerId,
                previewResult.resolutionDescription
            );
            this.cleanupCompletedUploadDiskArtifacts('global-text-uploaded', approvedTextEvents);
            this.batchQueue = [];
            this.globalErrors = [];
            this.globalErrorSet.clear();
            this.lastTd5FailureTail = null;
            this.persistInflightCycle();
          } catch { /* queued for retry */ }
        } else if (this.globalErrors.length > 0) {
          const result = await this.logger.logErrorOnlyBatch(
              this.globalErrors, 
              batchId, 
              this.latestRequestedTasks, 
              this.developerId, 
              this.getProjectName(),
              previewResult.resolutionDescription
          );
          requestId = result.requestId;
          this.globalErrors = [];
          this.globalErrorSet.clear();
          this.lastTd5FailureTail = null;
          this.persistInflightCycle();
        }

        if (!requestId && (approvedBinaryEvents.length > 0 || approvedArtifacts.length > 0)) {
          const fallbackErrors = this.globalErrors.length > 0 ? this.globalErrors : ["Artifact/Binary Upload for Build"];
          try {
            const result = await this.logger.logErrorOnlyBatch(
                fallbackErrors, 
                batchId, 
                this.latestRequestedTasks, 
                this.developerId, 
                this.getProjectName(), 
                previewResult.resolutionDescription
            );
            requestId = result.requestId;
          } catch {}
        }

        if (approvedBinaryEvents.length > 0 && requestId) {
          this.logger.enqueueArtifactRetry('binary', batchId, approvedBinaryEvents, this.developerId, requestId);
          try {
            await this.logger.sendBinaryFiles(batchId, approvedBinaryEvents, this.developerId, requestId);
            this.logger.removeArtifactRetry('binary', batchId);
            this.cleanupCompletedUploadDiskArtifacts('global-binary-uploaded', [], approvedBinaryEvents);
            this.binaryEvents = [];
            this.persistInflightCycle();
          } catch { /* stays in disk-backed retry queue */ }
        }

        if (approvedArtifacts.length > 0 && requestId) {
          try {
            this.logger.enqueueArtifactRetry('runtime', batchId, approvedArtifacts, this.developerId, requestId);
            await this.logger.sendRuntimeArtifacts(batchId, approvedArtifacts, this.developerId, requestId);
            this.logger.removeArtifactRetry('runtime', batchId);
            this.persistInflightCycle();
          } catch { /* stays in disk-backed retry queue */ }
        }
        
        this.runtimeArtifactCollector.clear();
        this.batchQueue = [];
        this.binaryEvents = [];
        this.latestRequestedTasks = '';
        this.hasUserChangesSinceErrorCycle = false;
        this.startedTrackingFilesInCycle.clear();
        this.cycleTypingBaselines.clear();
        this.cycleFailureBaselines.clear();
        this.modifiedFilesInCycle.clear();
        this.parentErrorTaskPath = null;
        this.rootCycleErrorMessage = null;
        this.isInErrorCycle = false;
        
        if (this.globalTrackingSessionId) {
          const resolvedGlobalSessionId = this.globalTrackingSessionId;
          await this.trackingStore.markSessionResolved(resolvedGlobalSessionId);
          await this.trackingStore.deleteSessionFolder(resolvedGlobalSessionId);
          this.knownDiskTrackingSessions.delete(resolvedGlobalSessionId);
          this.globalTrackingSessionId = null;
          await this.cleanupBaselinesIfSafe('td5-global-uploaded');
        }
        this.snapshotManager.clearSnapshots();
        this.clearCopilotSession();
        this.persistInflightCycle();

      } else if (this.isInErrorCycle) {
        this.hasUserChangesSinceErrorCycle = false;
        this.startedTrackingFilesInCycle.clear();
        this.cycleTypingBaselines.clear();
        this.cycleFailureBaselines.clear();
        this.modifiedFilesInCycle.clear();
        this.parentErrorTaskPath = null;
        this.rootCycleErrorMessage = null;
        this.runtimeArtifactCollector.clear();
        this.globalErrors = [];
        this.globalErrorSet.clear();
        this.isInErrorCycle = false;
        if (this.globalTrackingSessionId) {
          const resolvedGlobalSessionId = this.globalTrackingSessionId;
          await this.trackingStore.markSessionResolved(resolvedGlobalSessionId);
          await this.trackingStore.deleteSessionFolder(resolvedGlobalSessionId);
          this.knownDiskTrackingSessions.delete(resolvedGlobalSessionId);
          this.globalTrackingSessionId = null;
          await this.cleanupBaselinesIfSafe('td5-global-uploaded');
        }
        this.snapshotManager.clearSnapshots();
        this.clearCopilotSession();
        this.persistInflightCycle();
      }
    } finally {
      this.buildSuccessInFlight = false;
    }
  }

  private handleBuildErrors(currentErrorsMap: Map<string, string[]>) {
    if (!this.isInErrorCycle) {
      this.isInErrorCycle = true;
      this.persistInflightCycle();
    }

    const snapshot = this.buildErrorSnapshot(currentErrorsMap);
    this.lastActiveErrorMessage = snapshot.combinedMessage || snapshot.primaryMessage || '';

    for (const normPath of this.modifiedFilesInCycle) {
      if (this.activeSessions.has(normPath)) { continue; }
      if (!fs.existsSync(normPath)) { continue; }
      if (FileHandlingConfig.isBinaryFile(normPath)) { continue; }
      if (!FileUtils.isFileInsideWorkspace(normPath, this.workspaceRoot)) { continue; }

      this.startSession(normPath, null).catch(() => { /* ignore */ });
    }

  }

  private async startNewErrorSessions(currentErrorsMap: Map<string, string[]>) {
    for (const [filePath, messages] of currentErrorsMap) {

      if (this.trackedFolder && !filePath.toLowerCase().startsWith(this.trackedFolder.toLowerCase() + '/')) {
        continue;
      }

      if (!this.activeSessions.has(filePath)) {
        await this.startSession(filePath, messages[0] ?? null);
        const session = this.activeSessions.get(filePath);
        if (session) {
          for (let i = 1; i < messages.length; i++) {
            const strippedNew = FileUtils.stripTimestamp(messages[i].trim());
            const alreadyTracked = session.errorMessages.some(
              (m) => FileUtils.stripTimestamp(m.trim()) === strippedNew
            );
            if (!alreadyTracked) { session.errorMessages.push(messages[i]); }
          }
        }
      }
    }
  }

  private cleanupExpiredUnlinks() {
    const now = Date.now();
    for (const [key, value] of this.recentUnlinkedText) {
      if (value.expiry < now) {
        try { if (value.contentPath) { fs.rmSync(value.contentPath, { force: true }); } } catch { /* ignore */ }
        this.recentUnlinkedText.delete(key);
      }
    }
  }

  private consumeRecentUnlink(currentContent: string, filePath: string): string | null {
    this.cleanupExpiredUnlinks();
    const hash = crypto.createHash('sha1').update(currentContent).digest('hex');
    const pathKey = `path:${filePath.toLowerCase()}`;
    const entry = this.recentUnlinkedText.get(hash) ?? this.recentUnlinkedText.get(pathKey);
    if (entry) {
      const contentPath = entry.contentPath;
      for (const [key, value] of this.recentUnlinkedText) {
        if (value.contentPath === contentPath) {
          this.recentUnlinkedText.delete(key);
        }
      }
      return this.getOptionalSnapshotContent(contentPath, '');
    }
    return null;
  }

  private getMemoryLightPayloadRoot(): string {
    return path.join(this.context.globalStorageUri.fsPath, 'ai-assisted-disk-cache', this.workspaceId || 'workspace', 'queued-events');
  }

  private writeMemoryLightTextPayload(filePath: string, label: string, content: string): string {
    const safeFile = crypto.createHash('sha1').update(FileUtils.normalizePath(filePath || '')).digest('hex');
    const safePayload = crypto.createHash('sha1').update(`${label}:${content || ''}:${Date.now()}:${Math.random()}`).digest('hex');
    const outPath = path.join(this.getMemoryLightPayloadRoot(), safeFile, `${label}-${safePayload}.content`);

    try {
      const normalized = String(content ?? '').replace(/\r\n/g, '\n');
      fs.mkdirSync(path.dirname(outPath), { recursive: true });
      const tmpPath = `${outPath}.${process.pid}.${Date.now()}.${crypto.randomBytes(4).toString('hex')}.tmp`;
      fs.writeFileSync(tmpPath, normalized, 'utf8');
      fs.renameSync(tmpPath, outPath);
    } catch {
      return '';
    }

    return outPath;
  }

  private makeMemoryLightEvent(event: FileChangeEvent): FileChangeEvent {
    const cloned: FileChangeEvent = {
      ...event,
      errorDetails: [...(event.errorDetails || [])],
      modifiedFunctions: (event.modifiedFunctions || []).map((fn) => ({
        ...fn,
        before: { functionCode: fn.before?.functionCode ?? null },
        after: { functionCode: fn.after?.functionCode ?? null },
        linesBeforeChanges: [...(fn.linesBeforeChanges || [])],
        linesAfterChanges: [...(fn.linesAfterChanges || [])],
      }))
    };

    const beforeContent = event.snapshotBefore?.content;
    const afterContent = event.snapshotAfter?.content;

    if (typeof beforeContent === 'string') {
      cloned.snapshotBeforeContentPath = event.snapshotBeforeContentPath
        || this.writeMemoryLightTextPayload(event.filePath, 'before', beforeContent);
      cloned.snapshotBefore = { path: event.snapshotBefore?.path || event.filePath, content: null };
    }

    if (typeof afterContent === 'string') {
      cloned.snapshotAfterContentPath = event.snapshotAfterContentPath
        || this.writeMemoryLightTextPayload(event.filePath, 'after', afterContent);
      cloned.snapshotAfter = { path: event.snapshotAfter?.path || event.filePath, content: null };
    }

    return cloned;
  }

  /** Basic noise cleaning for an artifact sent as recommendation evidence: the
   *  whole file goes up, so this only drops what carries no information at all - blank lines,
   *  separator-only lines and a line that merely repeats the previous one. Kept lines are
   *  byte-identical to the file. No pattern-based selection and no size budget: we cannot know
   *  where the decisive line sits in a log, so nothing is picked and nothing is cut here. */
  private static cleanArtifactText(text: string): string {
    const out: string[] = [];
    let previous = '';
    for (const raw of String(text || '').split(/\r?\n/)) {
      const line = raw.replace(/\s+$/, '');
      if (!line.trim()) { continue; }
      if (/^[-=_*#~.+|]{3,}$/.test(line.trim())) { continue; }
      if (line === previous) { continue; }
      out.push(line);
      previous = line;
    }
    return out.join('\n');
  }

  /** At failure detection, snapshot the content of RECENTLY-MODIFIED tracked files: the disk
   *  right now IS the state the build failed on, captured independently of WHERE the edit was
   *  made (TD5 tool, another editor, closed VS Code). These snapshots become the cycle's
   *  authoritative "before" for any file edited afterwards. Bounded: files touched within the
   *  last hour, max 50, max 2MB each. */
  private captureFailureBaselinesForRecentFiles(): void {
    if (!this.trackedFolder) { return; }
    const RECENT_MS = 60 * 60 * 1000;
    const MAX_FILES = 50;
    const now = Date.now();
    let captured = 0;
    const walk = (dir: string, depth: number) => {
      if (captured >= MAX_FILES || depth > 8) { return; }
      let entries: fs.Dirent[];
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const ent of entries) {
        if (captured >= MAX_FILES) { return; }
        const full = path.join(dir, ent.name);
        if (ent.isDirectory()) {
          if (!FileUtils.shouldIgnore(full)) { walk(full, depth + 1); }
          continue;
        }
        const norm = FileUtils.normalizePath(full);
        if (this.cycleFailureBaselines.has(norm)) { continue; }
        if (FileUtils.shouldIgnore(norm) || !this.isInsideTrackedFolder(norm)) { continue; }
        try {
          const st = fs.statSync(full);
          if (now - st.mtimeMs > RECENT_MS) { continue; }
          if (st.size > 2 * 1024 * 1024) { continue; }
          const content = fs.readFileSync(full, 'utf8');
          const snap = this.snapshotManager.createSnapshot(norm, 'failure-state');
          fs.writeFileSync(snap, content, 'utf8');
          this.cycleFailureBaselines.set(norm, snap);
          captured++;
        } catch { /* unreadable file — skip */ }
      }
    };
    walk(this.trackedFolder, 0);
    if (captured > 0) {
      Logger.log(`[AI Assistant] Failure-state baseline captured for ${captured} recently changed file(s) in work/`);
    }
  }

  /** Re-anchor queued events' "before" snapshot to the CURRENT disk content — called at TD5
   *  failure detection, when the disk holds exactly the state the build failed on. See the
   *  call site in reconcileLegacyGlobalErrors for the scenario this fixes. */
  private reanchorGlobalQueueToFailureState(): void {
    let reanchored = 0;
    for (const event of this.batchQueue) {
      try {
        const abs = path.isAbsolute(event.filePath)
          ? event.filePath
          : path.join(this.workspaceRoot, event.filePath);
        if (!fs.existsSync(abs)) { continue; }
        const failingContent = fs.readFileSync(abs, 'utf8');
        const snapshotPath = this.snapshotManager.createSnapshot(FileUtils.normalizePath(abs), 'reanchor');
        fs.writeFileSync(snapshotPath, failingContent, 'utf8');
        event.snapshotBeforeContentPath = snapshotPath;
        event.snapshotBefore = { path: event.filePath, content: null };
        reanchored++;
      } catch { /* keep the event's existing baseline */ }
    }
    if (reanchored > 0) {
      this.persistInflightCycle();
      Logger.debug(`[FileWatcher] re-anchored ${reanchored} queued change(s) to the failing build state`);
    }
  }

  /** A file broken and fixed back within one cycle nets to "no change" — its hydrated before and
   *  after are identical. Such events carry no knowledge and are dropped at upload time. */
  private isNoOpChangeEvent(event: FileChangeEvent): boolean {
    try {
      const hydrated = this.hydrateEventForUpload(event);
      const before = hydrated.snapshotBefore?.content;
      const after = hydrated.snapshotAfter?.content;
      return typeof before === 'string' && typeof after === 'string'
        && before.length > 0 && before === after;
    } catch {
      return false;
    }
  }

  private hydrateEventForUpload(event: FileChangeEvent): FileChangeEvent {
    const beforeContent = event.snapshotBefore?.content
      ?? this.getOptionalSnapshotContent(event.snapshotBeforeContentPath, '');
    const afterContent = event.snapshotAfter?.content
      ?? this.getOptionalSnapshotContent(event.snapshotAfterContentPath, '');

    return {
      ...event,
      snapshotBefore: event.snapshotBefore
        ? { path: event.snapshotBefore.path, content: beforeContent }
        : null,
      snapshotAfter: event.snapshotAfter
        ? { path: event.snapshotAfter.path, content: afterContent }
        : null,
      errorDetails: [...(event.errorDetails || [])],
      modifiedFunctions: (event.modifiedFunctions || []).map((fn) => ({
        ...fn,
        before: { functionCode: fn.before?.functionCode ?? null },
        after: { functionCode: fn.after?.functionCode ?? null },
        linesBeforeChanges: [...(fn.linesBeforeChanges || [])],
        linesAfterChanges: [...(fn.linesAfterChanges || [])],
      }))
    };
  }

  private hydrateEventsForUpload(events: FileChangeEvent[]): FileChangeEvent[] {
    return (events || []).map((event) => this.hydrateEventForUpload(event));
  }

  private addToBatchOrMerge(newEvent: FileChangeEvent) {
    const memoryLightEvent = this.makeMemoryLightEvent(newEvent);
    const existingIndex = this.batchQueue.findIndex((e) => e.filePath === memoryLightEvent.filePath);

    if (existingIndex === -1) {
      this.batchQueue.push(memoryLightEvent);
      this.persistInflightCycle();
      return;
    }
    const existing = this.batchQueue[existingIndex];

    existing.timestamp = memoryLightEvent.timestamp;
    existing.snapshotAfter = memoryLightEvent.snapshotAfter;
    existing.snapshotAfterContentPath = memoryLightEvent.snapshotAfterContentPath;
    existing.lastDivergedSnapshotPath = memoryLightEvent.lastDivergedSnapshotPath ?? existing.lastDivergedSnapshotPath;

    if (!existing.snapshotBeforeContentPath && memoryLightEvent.snapshotBeforeContentPath) {
      existing.snapshotBeforeContentPath = memoryLightEvent.snapshotBeforeContentPath;
      existing.snapshotBefore = memoryLightEvent.snapshotBefore;
    }

    for (const err of memoryLightEvent.errorDetails) {
      if (!existing.errorDetails.some((e) => e.message === err.message)) {
        existing.errorDetails.push(err);
      }
    }

    for (const newFn of memoryLightEvent.modifiedFunctions) {
      const existingFn = existing.modifiedFunctions.find((f) => f.functionName === newFn.functionName);

      if (existingFn) {
        existingFn.linesBeforeChanges.push(...newFn.linesBeforeChanges);
        existingFn.linesAfterChanges.push(...newFn.linesAfterChanges);
        existingFn.after = newFn.after;
      } else {
        existing.modifiedFunctions.push(newFn);
      }
    }
    this.persistInflightCycle();
  }

  private async startSession(filePath: string, message: string | null, explicitOriginalContent?: string) {
    const normPath = FileUtils.normalizePath(filePath);
    if (this.activeSessions.has(normPath)) { return; }
    if (!fs.existsSync(normPath)) { return; }
    if (this.trackedFolder && !normPath.toLowerCase().startsWith(this.trackedFolder.toLowerCase() + '/')) { return; }
    if (!this.startedTrackingFilesInCycle.has(normPath)) {
      Logger.log(`[AI Assistant] Watching file: ${path.basename(normPath)}`);
      this.startedTrackingFilesInCycle.add(normPath);
    }

    this.telemetry.recordErrorSession(true);

    const diskBaseline = explicitOriginalContent === undefined ? this.trackingStore.getRollingBaseline(normPath) : null;
    const content = explicitOriginalContent ?? diskBaseline?.content ?? await FileUtils.readFileSafe(normPath);
    const snapshotPath = this.snapshotManager.createSnapshot(normPath, 'before');
    try { fs.writeFileSync(snapshotPath, content, 'utf8'); } catch { /* ignore */ }

    this.activeSessions.set(normPath, {
      timestamp: new Date().toISOString(),
      originalContent: '',
      snapshotBeforePath: snapshotPath,
      errorMessages: message ? [message] : [],
      lastSavedContent: '',
      lastSnapshotPath: snapshotPath,
      lastDivergedContent: null,
      lastDivergedSnapshotPath: null,
      functionHistory: new Map()
    });
  }

  private recordDiffChanges(
    session: ErrorSession,
    diff: { added: LineChange[]; removed: LineChange[] },
    ranges: Array<{ name: string; start: number; end: number }>
  ) {
    const record = (fnName: string, before?: LineChange, after?: LineChange) => {
      if (!session.functionHistory.has(fnName)) {
        session.functionHistory.set(fnName, { before: [], after: [] });
      }
      const entry = session.functionHistory.get(fnName)!;
      if (before) { entry.before.push(before); }
      if (after) { entry.after.push(after); }
    };

    for (const r of diff.removed) {
      if (!r.content.trim()) { continue; }
      const fn = ranges.find((f) => r.line - 1 >= f.start && r.line - 1 <= f.end);
      record(fn?.name ?? 'global', { line: r.line, content: r.content.trim() }, undefined);
    }

    for (const a of diff.added) {
      if (!a.content.trim()) { continue; }
      const fn = ranges.find((f) => a.line - 1 >= f.start && a.line - 1 <= f.end);
      record(fn?.name ?? 'global', undefined, { line: a.line, content: a.content.trim() });
    }
  }

  private async handleIntermediateSave(filePath: string, currentContent: string) {
    const session = this.activeSessions.get(filePath);
    if (!session) { return; }

    const lastSavedContent = this.getSessionLastSavedContent(session);
    if (currentContent === lastSavedContent) { return; }

    const canonicalCurrentContent = this.coalesceSessionContent(session, currentContent);

    const diff = DiffGenerator.getDiffStats(lastSavedContent, canonicalCurrentContent);
    const ext = path.extname(filePath).toLowerCase();
    const ranges = await DiffParser.getFunctionRanges(lastSavedContent, ext, filePath);

    this.recordDiffChanges(session, diff, ranges);

    this.writeSessionLastSavedContent(session, filePath, canonicalCurrentContent);

    const originalContent = this.getSessionOriginalContent(session);
    if (!FileUtils.isPracticallySame(originalContent, canonicalCurrentContent)) {
      this.writeSessionLastDivergedContent(session, filePath, canonicalCurrentContent);
    }
  }

  private async finalizeSessionObject(filePath: string, session: ErrorSession): Promise<FileChangeEvent | null> {
    const normPath = FileUtils.normalizePath(filePath);
    if (!fs.existsSync(normPath)) { return null; }

    this.telemetry.recordErrorSession(false);

    if (session.errorMessages.length === 0 && this.globalErrors.length > 0 && this.modifiedFilesInCycle.has(normPath)) {
      session.errorMessages = [...this.globalErrors];
    }

    const contentFixed = await this.getLatestTrackedContent(normPath, session);
    const originalContent = this.getSessionOriginalContent(session);
    const lastDivergedContent = this.getSessionLastDivergedContent(session);
    const ext = path.extname(filePath).toLowerCase();

    if (session.functionHistory.size === 0) {
      const diff = DiffGenerator.getDiffStats(originalContent, contentFixed);
      if (diff.added.length === 0 && diff.removed.length === 0) {
        return null;
      } else {
        const ranges = await DiffParser.getFunctionRanges(originalContent, ext, filePath);
        this.recordDiffChanges(session, diff, ranges);
      }
    }

    const shouldUseLastDivergedSnapshot = FileUtils.isPracticallySame(originalContent, contentFixed)
      && !!lastDivergedContent;
    const eventAfterContent = shouldUseLastDivergedSnapshot
      ? lastDivergedContent || contentFixed
      : contentFixed;

    const event = await this.buildEventObject(
      normPath,
      originalContent,
      eventAfterContent,
      session.errorMessages.slice(0, 1)
    );
    this.injectFunctionHistory(event, session);

    if (event.modifiedFunctions.length === 0) {
      if (originalContent === contentFixed) {
        return null;
      }
      const fullDiff = DiffGenerator.getDiffStats(originalContent, contentFixed);
      const linesBeforeChanges = fullDiff.removed
        .filter(l => l.content.trim())
        .map(l => ({ line: l.line, content: l.content.trim() }));
      const linesAfterChanges = fullDiff.added
        .filter(l => l.content.trim())
        .map(l => ({ line: l.line, content: l.content.trim() }));
      if (linesBeforeChanges.length === 0 && linesAfterChanges.length === 0) {
        return null;
      }
      event.modifiedFunctions = [{
        functionName: 'file-level-change',
        before: { functionCode: null },
        after: { functionCode: null },
        linesBeforeChanges,
        linesAfterChanges,
      }];
    }

    this.memory.set(normPath.toLowerCase(), contentFixed);
    return event;
  }

  private async getLatestTrackedContent(normPath: string, session: ErrorSession): Promise<string> {
    const cachedContent = this.memory.get(normPath.toLowerCase());
    if (typeof cachedContent === 'string') {
      return this.coalesceSessionContent(session, cachedContent);
    }

    const diskContent = await FileUtils.readFileSafe(normPath);
    return this.coalesceSessionContent(session, diskContent);
  }

  private getSessionOriginalContent(session: ErrorSession): string {
    return this.getOptionalSnapshotContent(session.snapshotBeforePath, session.originalContent || '');
  }

  private getSessionLastSavedContent(session: ErrorSession): string {
    return this.getOptionalSnapshotContent(session.lastSnapshotPath, session.lastSavedContent || this.getSessionOriginalContent(session));
  }

  private getSessionLastDivergedContent(session: ErrorSession): string | null {
    const content = this.getOptionalSnapshotContent(session.lastDivergedSnapshotPath, session.lastDivergedContent || '');
    return content ? content : null;
  }

  private writeSessionLastSavedContent(session: ErrorSession, filePath: string, content: string): void {
    const snapshotPath = this.snapshotManager.createSnapshot(filePath, 'last');
    try { fs.writeFileSync(snapshotPath, content, 'utf8'); } catch { /* ignore */ }
    session.lastSavedContent = '';
    session.lastSnapshotPath = snapshotPath;
  }

  private writeSessionLastDivergedContent(session: ErrorSession, filePath: string, content: string): void {
    const snapshotPath = this.snapshotManager.createSnapshot(filePath, 'diverged');
    try { fs.writeFileSync(snapshotPath, content, 'utf8'); } catch { /* ignore */ }
    session.lastDivergedContent = null;
    session.lastDivergedSnapshotPath = snapshotPath;
  }

  private coalesceSessionContent(
    session: ErrorSession,
    content: string
  ): string {
    const lastSavedContent = this.getSessionLastSavedContent(session);
    const originalContent = this.getSessionOriginalContent(session);
    const lastDivergedContent = this.getSessionLastDivergedContent(session);

    if (content === lastSavedContent) {
      return lastSavedContent;
    }

    if (content === originalContent) {
      return originalContent;
    }

    if (typeof lastDivergedContent === 'string' && content === lastDivergedContent) {
      return lastDivergedContent;
    }

    return content;
  }

  private injectFunctionHistory(event: FileChangeEvent, session: ErrorSession) {
    const finalFunctions: FileChangeEvent['modifiedFunctions'] = [];

    for (const [fnName, history] of session.functionHistory.entries()) {
      if (history.before.length === 0 && history.after.length === 0) {
        continue;
      }

      const existing = event.modifiedFunctions.find((f) => f.functionName === fnName);

      if (existing) {
        existing.linesBeforeChanges = [...history.before];
        existing.linesAfterChanges = [...history.after];
        finalFunctions.push(existing);
      } else {
        finalFunctions.push({
          functionName: fnName,
          before: { functionCode: null },
          after: { functionCode: null },
          linesBeforeChanges: [...history.before],
          linesAfterChanges: [...history.after]
        });
      }
    }
    if (finalFunctions.length > 0) {
      event.modifiedFunctions = finalFunctions;
    }
  }

  private async buildEventObject(filePath: string, contentOld: string, contentNew: string, messages: string[]): Promise<FileChangeEvent> {
    const diff = DiffGenerator.getDiffStats(contentOld, contentNew);
    const modifiedFunctions = await this.generateModifiedFunctions(filePath, contentOld, contentNew, diff);
    return {
      timestamp: new Date().toISOString(),
      eventType: 'modified',
      filePath,
      fileName: path.basename(filePath),
      category: 'code',
      workspace: this.workspaceRoot,
      language: path.extname(filePath),
      projectName: path.basename(this.workspaceRoot),
      snapshotBefore: { path: filePath, content: contentOld },
      snapshotAfter: { path: filePath, content: contentNew },
      diffFile: null,
      modifiedFunctions,
      errorDetails: messages.map((msg) => ({ message: msg }))
    };
  }

  private async generateModifiedFunctions(filePath: string, oldContent: string, newContent: string, diff: { added: LineChange[]; removed: LineChange[] }) {
    const modifiedFunctions: FileChangeEvent['modifiedFunctions'] = [];
    const ext = path.extname(filePath).toLowerCase();

    const oldRanges = await DiffParser.getFunctionRanges(oldContent, ext, filePath);
    const newRanges = await DiffParser.getFunctionRanges(newContent, ext, filePath);

    const affectedFunctionNames = new Set<string>();

    for (const entry of diff.removed) {
      const fn = oldRanges.find((f) => entry.line - 1 >= f.start && entry.line - 1 <= f.end);
      if (fn) { affectedFunctionNames.add(fn.name); }
    }

    for (const entry of diff.added) {
      const fn = newRanges.find((f) => entry.line - 1 >= f.start && entry.line - 1 <= f.end);
      if (fn) { affectedFunctionNames.add(fn.name); }
    }

    for (const name of affectedFunctionNames) {
      const oldFn = oldRanges.find((f) => f.name === name);
      const newFn = newRanges.find((f) => f.name === name);
      const beforeCode = oldFn ? FileUtils.slice(oldContent, oldFn.start, oldFn.end) : '';
      const afterCode = newFn ? FileUtils.slice(newContent, newFn.start, newFn.end) : '';
      modifiedFunctions.push({
        functionName: name,
        before: { functionCode: beforeCode },
        after: { functionCode: afterCode },
        linesBeforeChanges: [],
        linesAfterChanges: []
      });
    }

    if (modifiedFunctions.length === 0 && (diff.added.length > 0 || diff.removed.length > 0)) {
      modifiedFunctions.push({
        functionName: 'null',
        before: { functionCode: '' },
        after: { functionCode: '' },
        linesBeforeChanges: [],
        linesAfterChanges: []
      });
    }
    return modifiedFunctions;
  }

  dispose() {
    this.watcher.close();
    this.typingBaselineSubscription?.dispose();
    this.cycleTypingBaselines.clear();
    this.cycleFailureBaselines.clear();
    this.binaryFileHashes.clear();
    this.binaryDeletionCache.clear();
    this.cleanupMemoryLightPayloadRoot();
    this.runtimeArtifactCollector.clear();
    this.logger.cleanupLocalUploadStorage();
    if (this.predictPollTimer) {
      clearInterval(this.predictPollTimer);
      this.predictPollTimer = null;
    }
  }
}