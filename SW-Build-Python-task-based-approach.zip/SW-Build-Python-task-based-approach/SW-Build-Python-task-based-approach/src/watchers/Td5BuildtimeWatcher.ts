import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { Logger } from '../utils/Logger';
import { FileUtils } from '../utils/FileUtils';

/**
 * TD5 build-finished signal from buildtime.xml (client integration doc):
 *   - "Search for the file buildtime.xml that was changed. All information pertaining to a
 *      particular build can be seen in that xml file."
 *   - "Based on that info look for the log file in <PROJ_PATH>/_td5/log/<TargetName>_<BuildTypeName>.log"
 *
 * This watcher is ADDITIVE on top of the existing TD5 log watchers: it declares the build result
 * (status/target/buildType/duration) in the output log and makes sure the build's OWN log file is
 * being watched, so errors are parsed from exactly this build's log. Project-type detection and
 * the TD5/Gradle startup declarations are untouched.
 *
 * Parsing is deliberately tolerant (lesson from the Gradle report shape variants): every field is
 * matched against several candidate tag names, and target/buildType fall back to a
 * "<target>_<buildtype>" path segment near the xml when the tags are absent.
 */
export type Td5BuildFinishedInfo = {
  xmlPath: string;
  status: string;            // SUCCESS | FAILED | ... ('' when the tag is absent)
  target: string | null;
  buildType: string | null;
  durationMs: number | null;
  uniqueBuildId: string | null;
  logPath: string | null;    // resolved <Target>_<BuildType>.log when found
  // The build's time window per the doc ("all information pertaining to a particular build"):
  // end = the xml's own mtime (written at build end), start = end - BuildTimeMilliSeconds.
  // Derived from file time + duration instead of the BuildStartTime text (locale-bound "IST" dates).
  buildStartMs: number | null;
  buildEndMs: number | null;
};

export class Td5BuildtimeWatcher {
  private readonly watcher: vscode.FileSystemWatcher;
  private readonly debounce = new Map<string, NodeJS.Timeout>();

  constructor(
    context: vscode.ExtensionContext,
    private readonly onBuildFinished: (info: Td5BuildFinishedInfo) => void
  ) {
    this.watcher = vscode.workspace.createFileSystemWatcher('**/buildtime.xml');
    this.watcher.onDidCreate((uri) => this.schedule(uri.fsPath));
    this.watcher.onDidChange((uri) => this.schedule(uri.fsPath));
    context.subscriptions.push(this.watcher);
  }

  private schedule(rawPath: string): void {
    // The build tool writes the xml in chunks; debounce so the finished file is parsed once.
    const key = FileUtils.normalizePath(rawPath);
    const existing = this.debounce.get(key);
    if (existing) { clearTimeout(existing); }
    this.debounce.set(key, setTimeout(() => {
      this.debounce.delete(key);
      void this.process(key);
    }, 750));
  }

  private async process(xmlPath: string): Promise<void> {
    try {
      const xml = fs.readFileSync(xmlPath, 'utf8');
      const info = this.parse(xml, xmlPath);
      if (!info.status && !info.target) { return; }   // not a build-status xml shape we recognize
      try {
        info.buildEndMs = Math.round(fs.statSync(xmlPath).mtimeMs);
        info.buildStartMs = info.durationMs != null ? info.buildEndMs - info.durationMs : null;
      } catch { /* window stays unknown — collection simply runs unscoped */ }
      info.logPath = await this.resolveTargetLog(info.target, info.buildType);
      this.onBuildFinished(info);
    } catch (err: any) {
      Logger.debug('[TD5] buildtime.xml processing skipped', { xmlPath, error: err?.message || String(err) });
    }
  }

  private parse(xml: string, xmlPath: string): Td5BuildFinishedInfo {
    const tag = (...names: string[]): string | null => {
      for (const n of names) {
        const m = xml.match(new RegExp(`<${n}>\\s*([^<]*?)\\s*</${n}>`, 'i'));
        if (m && m[1].trim()) { return m[1].trim(); }
      }
      return null;
    };

    const status = (tag('BuildStatus', 'Status') || '').toUpperCase();
    const durationRaw = tag('BuildTimeMilliSeconds', 'BuildTimeMillis', 'BuildTimeMs');
    let target = tag('TargetName', 'Target', 'BuildTargetName');
    let buildType = tag('BuildTypeName', 'BuildType');

    // Fallback: a "<target>_<buildtype>" segment in the xml's own path (same suffixes the
    // primary-log filter recognizes).
    if (!target || !buildType) {
      const segs = FileUtils.normalizePath(xmlPath).split('/');
      for (let i = segs.length - 2; i >= 0 && i >= segs.length - 4; i--) {
        const m = segs[i].match(/^(.+)_(normal|release|normal-dev|td5)$/i);
        if (m) {
          target = target || m[1];
          buildType = buildType || m[2];
          break;
        }
      }
    }

    return {
      xmlPath,
      status,
      target,
      buildType,
      durationMs: durationRaw && /^\d+$/.test(durationRaw) ? parseInt(durationRaw, 10) : null,
      uniqueBuildId: tag('UniqueBuildID', 'UniqueBuildId', 'BuildID'),
      logPath: null,
      buildStartMs: null,
      buildEndMs: null,
    };
  }

  /** The build's own log per the doc: <PROJ_PATH>/_td5/log/<TargetName>_<BuildTypeName>.log */
  private async resolveTargetLog(target: string | null, buildType: string | null): Promise<string | null> {
    if (!target || !buildType) { return null; }
    const wanted = `${target}_${buildType}.log`.toLowerCase();
    try {
      const found = await vscode.workspace.findFiles('**/*_td5/log/*.log', '**/node_modules/**', 200);
      for (const f of found) {
        if (path.basename(f.fsPath).toLowerCase() === wanted) {
          return FileUtils.normalizePath(f.fsPath);
        }
      }
    } catch {
      // Discovery is best-effort; the existing log watchers remain the fallback.
    }
    return null;
  }

  public dispose(): void {
    for (const t of this.debounce.values()) { clearTimeout(t); }
    this.debounce.clear();
    this.watcher.dispose();
  }
}
