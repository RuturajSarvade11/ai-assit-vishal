import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { Logger } from '../utils/Logger';
import { FileUtils } from '../utils/FileUtils';
import { TrackingConfigService } from '../utils/TrackingConfigService';
import { ApiService } from '../services/api.service';

/**
 * Raised when the embedding service (predict/embed-texts) is not reachable / returns nothing.
 * Product decision: build risk MUST be computed by running every stage (exact line + context
 * above/below + cosine + dice + RRF). If embeddings cannot run we do NOT silently degrade to
 * exact-line-only — we STOP and tell the webview it is currently unavailable. The `code` lets the
 * webview command distinguish this from a generic failure without importing the class.
 */
export class EmbeddingUnavailableError extends Error {
    public readonly code = 'EMBEDDING_UNAVAILABLE';
    constructor(message = 'The build-risk embedding service is currently unavailable. Please try again later.') {
        super(message);
        this.name = 'EmbeddingUnavailableError';
    }
}

export class PredictionRiskAnalyzer {
    private static readonly PHASE2_MISSING_LINE_RISK = 100;
    private static readonly PHASE2_RELOCATED_LINE_RISK = 70;
    private static readonly PHASE2_STAGE1_WEIGHT = 100;
    private static readonly PHASE2_STAGE2_WEIGHT = 50;
    private static readonly PHASE2_STAGE3_WEIGHT = 30;
    private static readonly PHASE2_MAX_CANDIDATES_PER_RULE = 120;
    private static readonly PHASE2_MAX_STAGE3_CANDIDATES = 40;
    private static readonly PHASE2_EMBED_MAX_CONCURRENCY = 2;
    private static readonly PHASE2_PATCH_STRONG_THRESHOLD = 0.78;
    private static readonly PHASE2_PATCH_MIN_LINES = 3;
private static readonly LOW_RISK_THRESHOLD = 30;
private static readonly MEDIUM_RISK_THRESHOLD = 70;
    private embedRequestsInFlight = 0;
    private embedWaiters: Array<() => void> = [];

    // Live tunables fetched from the dashboard (GET /build-prediction/config). Defaults match the
    // constants above, so behaviour is unchanged until an admin sets values on the Settings page.
    private cfgContextWindow = 10;          // radius: N lines above & below the matched line
    private cfgCosineWeight = 0.7;
    private cfgDiceWeight = 0.3;
    private cfgLowRisk = 30;
    private cfgMediumRisk = 70;

    constructor(
        private readonly workspaceRoot: string,
        private readonly apiService: ApiService,
        private readonly filenameIndex: Map<string, string>
    ) { }

    /** Key of the last full config banner printed — the banner repeats only when the admin
     *  actually changed something; unchanged scans keep the story to the one-line scan summary. */
    private lastBannerKey = '';

    /** Fetch the admin-set prediction config and PRINT it, so it is visible that the dashboard
     *  configuration is actually driving the scan. Falls back to defaults if the backend is unreachable.
     *  silent = background scan (shadow capture): apply the config but keep the log quiet. */
    private async loadConfig(silent = false): Promise<void> {
        let fetched = false;
        try {
            const resp: any = await this.apiService.getBuildPredictionConfig();
            const d = (resp && (resp.data || resp)) || {};
            const cw = Number(d.contextWindow);
            const cos = Number(d.cosineWeight);
            const dice = Number(d.diceWeight);
            const low = Number(d.lowRiskUpperLimit);
            const med = Number(d.mediumRiskUpperLimit);
            if (Number.isFinite(cw) && cw >= 5 && cw <= 100) { this.cfgContextWindow = cw; }
            if (Number.isFinite(cos) && Number.isFinite(dice) && (cos + dice) === 100) {
                this.cfgCosineWeight = cos / 100;
                this.cfgDiceWeight = dice / 100;
            }
            if (Number.isFinite(low) && Number.isFinite(med) && low < med) {
                this.cfgLowRisk = low;
                this.cfgMediumRisk = med;
            }
            fetched = Number.isFinite(cw) || Number.isFinite(cos) || Number.isFinite(low);
        } catch (err) {
            Logger.log('[Prediction][Config] could not fetch dashboard config — using defaults', { error: String(err) });
        }
        const cosPct = Math.round(this.cfgCosineWeight * 100);
        const dicePct = Math.round(this.cfgDiceWeight * 100);
        const bannerKey = `${this.cfgContextWindow}|${cosPct}|${dicePct}|${this.cfgLowRisk}|${this.cfgMediumRisk}|${fetched}`;
        if (silent) {
            // Background (shadow) scan: config applied identically, but the story log stays quiet.
            Logger.debug(`[Prediction] admin config applied to silent scan (${bannerKey})`);
            return;
        }
        if (bannerKey === this.lastBannerKey) {
            // Same settings as the banner already shown this session — the scan-summary line
            // repeats the applied values anyway; a second full banner is just noise.
            Logger.debug('[Prediction] admin config unchanged — applied same configuration as shown above');
            return;
        }
        this.lastBannerKey = bannerKey;
        const block = [
            '',
            '==================================================================',
            '  BUILD PREDICTION  —  ACTIVE CONFIGURATION (set by Admin on the dashboard)',
            '==================================================================',
            `  [Context Window]      radius = ${this.cfgContextWindow} line(s)  ->  collects ${this.cfgContextWindow * 2 + 1} lines  (${this.cfgContextWindow} above + matched line + ${this.cfgContextWindow} below)`,
            `  [Similarity Weights]  Cosine = ${cosPct}%   |   Dice = ${dicePct}%   (total ${cosPct + dicePct}%)`,
            `  [Risk Thresholds]     Low 0-${this.cfgLowRisk}   |   Medium ${this.cfgLowRisk + 1}-${this.cfgMediumRisk}   |   High ${this.cfgMediumRisk + 1}-100`,
            '------------------------------------------------------------------',
            `  Source: ${fetched ? 'LIVE from dashboard (GET /build-prediction/config)' : 'DEFAULTS (dashboard not reachable)'}  —  applied to this scan`,
            '==================================================================',
            '',
        ].join('\n');
        Logger.log(block);
    }

    /**
     * Pre-flight the embedding service BEFORE the (slow) file scan. Stage 2 (cosine + dice + RRF)
     * cannot run without it, and product policy is fail-closed: rather than silently degrade to
     * exact-line-only matching, we stop immediately and let the webview say "currently unavailable".
     * Doing this up front means the developer is told right away instead of waiting through the
     * whole scan only to hit the failure. Throws {@link EmbeddingUnavailableError} when unreachable.
     */
    private async ensureEmbeddingServiceAvailable(): Promise<void> {
        let embeddings: any = null;
        try {
            const resp: any = await this.apiService.postPredictEmbedTexts({
                texts: ['__build_risk_embedding_health_check__'],
            });
            embeddings = resp?.embeddings || resp?.data || [];
        } catch (error) {
            Logger.log('[Prediction] Embedding service pre-flight FAILED — stopping (fail-closed)', { error: String(error) });
            throw new EmbeddingUnavailableError(
                'Build prediction is currently unavailable: the embedding service is not reachable. Please try again once it is back online.'
            );
        }
        if (!Array.isArray(embeddings) || embeddings.length === 0) {
            Logger.log('[Prediction] Embedding service pre-flight returned no data — stopping (fail-closed)');
            throw new EmbeddingUnavailableError(
                'Build prediction is currently unavailable: the embedding service returned no data. Please try again shortly.'
            );
        }
        Logger.log('[Prediction] Embedding service available — every stage (cosine + dice + RRF) will run.');
    }

    public async runLocalPrediction(scope: any, selectedFilePaths: string[] = [], opts: { silent?: boolean } = {}): Promise<{ matches: any[]; summary: any }> {
        await this.loadConfig(!!opts.silent);   // fetch + print the admin-set configuration before scanning
        // Refresh the admin System Tracking inclusion list too (60s cache, fail-open): the
        // per-file gate below follows the SAME list as change tracking.
        await TrackingConfigService.load(this.apiService);
        const matches: any[] = [];
        const rulesByFile = (scope?.rules_by_file && typeof scope.rules_by_file === 'object') ? scope.rules_by_file : {};
        const targetFiles: string[] = Array.isArray(scope?.target_files) ? scope.target_files : [];
        const selectedSet = new Set(
            (selectedFilePaths || [])
                .map((raw) => FileUtils.normalizePath(raw))
                .filter((raw) => !!raw)
        );
        let filesScanned = 0;

        for (const rawTarget of targetFiles) {
            const target = this.resolvePredictionPath(String(rawTarget || ''));
            if (!target || !fs.existsSync(target)) { continue; }
            if (selectedSet.size > 0 && !selectedSet.has(FileUtils.normalizePath(target))) { continue; }
            // Prediction uses the SAME inclusion list as change tracking: only predict on real
            // source files (work/ + gradle + root gradle files). Generated/config files
            // (tmp/**.upda XML, etc.) carry no reliable build-failure signal and produced garbage
            // predictions — whole XML files flagged line by line. Quality of prediction depends on
            // quality of what phase 1 collected; keep both scoped to real code.
            if (!FileUtils.isIncludedForTracking(target, this.workspaceRoot)) {
                Logger.debug(`[Prediction] skipped non-source file (not in inclusion list): ${target}`);
                continue;
            }
            const content = await FileUtils.readFileSafeWithValidation(target);
            const lines = content.replace(/\r\n/g, '\n').split('\n');
            // DSA: pre-normalize the file's lines ONCE (the regex-heavy normalize ran per-pattern
            // before => O(lines x patterns); now O(lines)), + an exact-match index for O(1) lookups.
            const normLines = lines.map((l) => this.normalizeCompareText((l || '').trim()));
            const lineIndex = new Map<string, number[]>();
            for (let i = 0; i < normLines.length; i++) {
                const k = normLines[i];
                if (!k) { continue; }
                const arr = lineIndex.get(k);
                if (arr) { arr.push(i); } else { lineIndex.set(k, [i]); }
            }
            filesScanned++;

            const rules = Array.isArray(rulesByFile[rawTarget]) ? rulesByFile[rawTarget] : [];
            const ruleResults: any[] = [];
            for (const rule of rules) {
                if (!rule || typeof rule !== 'object') { continue; }
                // Prediction learns from what CAUSES FAILURE — the failing ("before") side. Skip fix
                // ("after") features: matching a past FIX would flag applied fixes as risky
                // (inverted). The backend already filters these out; this is defense-in-depth.
                if (String(rule.risk_side || '').trim().toLowerCase() === 'after') { continue; }
                const expectedLine = Number(rule.line || 0);
                const expectedHunk = Number(rule.hunk || 0);
                const changeId = String(rule.change_id || '');
                const requestId = String(rule.request_id || '');
                const featureCreatedDate = String(rule.created_date || '');
                const changeText = String(rule.before_path || rule.change || '');
                const patchText = String(rule.patch || '');
                // How many DISTINCT past builds this pattern broke (from the backend). Confidence
                // grows with it — prediction is a probability from history, never a 100% guarantee.
                const failCount = Math.max(1, Number(rule.fail_count || 1));
                const conf = this.historyConfidence(failCount);
                const core = this.extractCoreChange(changeText);
                // Skip boilerplate: comment/header/separator lines (copyright banners, aligned
                // "* ..." lines, blank separators) are identical across thousands of files and
                // carry NO build-failure signal — matching them flagged every file's header 100%.
                if (!this.isMeaningfulPredictionLine(core)) { continue; }
                const ruleEmbedding = Array.isArray(rule.patch_embedding) ? rule.patch_embedding : [];
                const occurrenceIndexes = core ? this.findMatchingLineIndexesFast(normLines, lineIndex, core) : [];
                const occurrenceCount = occurrenceIndexes.length;

                // CASE A: Exact Match (Highest Confidence). Exact text match counts as Stage 1
                // wherever it appears in the file — edits shift line numbers, so position is not
                // required. "Same historical position" is reported only when it truly lines up.
                const exactIndex = expectedLine - 1;
                const samePosition = expectedLine > 0 && occurrenceIndexes.includes(exactIndex);
                if (occurrenceCount > 0) {
                    const foundIdx = samePosition ? exactIndex : occurrenceIndexes[0];
                    const pct = Math.round(100 * conf);   // exact match, scaled by history frequency
                    const times = `${failCount} time${failCount !== 1 ? 's' : ''}`;
                    Logger.debug(`[PredictReport][Stage1] Exact match: ${requestId} | fails=${failCount} conf=${pct}`);
                    ruleResults.push({
                        file_path: target,
                        change_id: changeId,
                        request_id: requestId,
                        stage: 1,
                        dominant_stage: 1,
                        risk_score: pct,
                        score: conf,
                        stage1_found: true,
                        historical_hits: failCount,
                        match_reason: (samePosition
                            ? 'Exact line matched at the same position'
                            : 'Exact line from a past build failure is present in this file')
                            + ` — this pattern broke the build ${times} before.`,
                        line_expected: expectedLine,
                        line_found: foundIdx + 1,
                        line_text_found: (lines[foundIdx] || '').trim(),
                        historical_pattern: core,
                    });
                    continue; // Stage 1 hit — highest confidence, done with this rule.
                }

                // STAGE 2: no exact line, but the historical CHANGE's context block may still align
                // with a region of this file (edited/renamed). Score = CosineWeight*cosine +
                // DiceWeight*dice of the best window vs the stored patch (admin weights + context
                // window radius), bucketed by the Low/Med/High thresholds. Bounded scan (band around
                // the historical position) so big files stay fast.
                const stage2 = this.evaluatePatchContextStage(lines, patchText || changeText, expectedLine);
                if (stage2) {
                    const pct = Math.round(stage2.score * 100 * conf);   // similarity x history confidence
                    if (pct >= this.cfgLowRisk) {
                        const times = `${failCount} time${failCount !== 1 ? 's' : ''}`;
                        Logger.debug(`[PredictReport][Stage2] Context match: ${requestId} | sim=${Math.round(stage2.score * 100)} fails=${failCount} risk=${pct}`);
                        ruleResults.push({
                            file_path: target,
                            change_id: changeId,
                            request_id: requestId,
                            stage: 2,
                            dominant_stage: 2,
                            risk_score: pct,
                            score: stage2.score * conf,
                            stage2_found: true,
                            historical_hits: failCount,
                            match_reason: (pct > this.cfgMediumRisk
                                ? 'Change context strongly matches a past build failure'
                                : 'Change context partially matches a past build failure')
                                + ` — this pattern broke the build ${times} before.`,
                            line_expected: expectedLine,
                            line_found: stage2.lineFound,
                            line_text_found: stage2.lineText,
                            historical_pattern: core,
                        });
                        continue;
                    }
                }
                // STAGE 3 (semantic/embedding via rule.patch_embedding) — next increment.
                continue;
            }

            for (const r of ruleResults) {
                if (r) { matches.push(r); }
            }
        }

        // Deduplicate repeated hits from same request/change/file; keep strongest one.
        const dedup = new Map<string, any>();
        for (const m of matches) {
            const key = `${m.file_path || ''}|${m.request_id || ''}|${m.change_id || ''}`;
            const prev = dedup.get(key);
            if (!prev) {
                dedup.set(key, m);
                continue;
            }
            const prevScore = Number(prev.score || 0);
            const currScore = Number(m.score || 0);
            const prevRiskScore = Number(prev.risk_score || 0);
            const currRiskScore = Number(m.risk_score || 0);
            const prevStage = Number(prev.stage || 99);
            const currStage = Number(m.stage || 99);
            if (currRiskScore > prevRiskScore || (currRiskScore === prevRiskScore && (currScore > prevScore || currStage < prevStage))) {
                dedup.set(key, m);
            }
        }
        const uniqueMatches = Array.from(dedup.values());

        const stage1Unique = uniqueMatches.filter((m) => Number(m.stage || 0) === 1).length;
        const stage2Unique = uniqueMatches.filter((m) => Number(m.stage || 0) === 2).length;
        const stage3Unique = uniqueMatches.filter((m) => Number(m.stage || 0) === 3).length;
        const averageRiskScore = uniqueMatches.length
            ? Number((uniqueMatches.reduce((sum, m) => sum + Number(m.risk_score || 0), 0) / uniqueMatches.length).toFixed(2))
            : 0;

        // Proof the admin config actually DROVE this scan (not just a settings screen): echo the
        // applied values next to the outcome, so the log shows dashboard config -> real behaviour.
        const highN = uniqueMatches.filter((m) => Number(m.risk_score || 0) > this.cfgMediumRisk).length;
        const medN = uniqueMatches.filter((m) => { const r = Number(m.risk_score || 0); return r > this.cfgLowRisk && r <= this.cfgMediumRisk; }).length;
        const lowN = uniqueMatches.length - highN - medN;
        const scanSummary =
            `[Prediction] Scan complete — APPLIED admin config: contextWindow=${this.cfgContextWindow}, `
            + `cosine=${Math.round(this.cfgCosineWeight * 100)}% / dice=${Math.round(this.cfgDiceWeight * 100)}%, `
            + `thresholds Low≤${this.cfgLowRisk} < Medium≤${this.cfgMediumRisk} < High. `
            + `Result: ${uniqueMatches.length} match(es) across ${filesScanned} file(s) — `
            + `High=${highN} Medium=${medN} Low=${lowN}, avg risk ${averageRiskScore}%.`;
        // Silent (shadow) scans keep the user log clean — their outcome is the single
        // "[ShadowPrediction] silent capture stored" story line; details go to debug.
        if (opts.silent) { Logger.debug(scanSummary); } else { Logger.log(scanSummary); }

        return {
            matches: uniqueMatches,
            summary: {
                total_files_scanned: filesScanned,
                total_matches: uniqueMatches.length,
                stage1_hits: stage1Unique,
                stage2_hits: stage2Unique,
                stage3_hits: stage3Unique,
                average_risk_score: averageRiskScore
            }
        };
    }

    private limitPredictionCandidates(
        candidateIndexes: number[],
        maxCount: number,
        priorityIndexes: number[] = [],
        expectedIndex?: number
    ): number[] {
        if (candidateIndexes.length <= maxCount) {
            return candidateIndexes;
        }

        const available = new Set(candidateIndexes);
        const picked: number[] = [];
        const seen = new Set<number>();
        const add = (value: number | undefined) => {
            if (value === undefined || !available.has(value) || seen.has(value)) {
                return;
            }
            seen.add(value);
            picked.push(value);
        };

        add(expectedIndex);
        for (const idx of priorityIndexes) {
            add(idx);
            if (picked.length >= maxCount) {
                return picked.sort((a, b) => a - b);
            }
        }

        const remaining = candidateIndexes.filter((idx) => !seen.has(idx));
        const slotsLeft = maxCount - picked.length;
        if (slotsLeft > 0 && remaining.length > 0) {
            const step = Math.max(1, Math.ceil(remaining.length / slotsLeft));
            for (let i = 0; i < remaining.length && picked.length < maxCount; i += step) {
                add(remaining[i]);
            }
        }

        if (picked.length < maxCount) {
            for (const idx of remaining) {
                add(idx);
                if (picked.length >= maxCount) {
                    break;
                }
            }
        }

        return picked.sort((a, b) => a - b);
    }

    private formatElapsedMs(startedAt: number): string {
        return `${Date.now() - startedAt}ms`;
    }

    private async acquireEmbedSlot(): Promise<void> {
        if (this.embedRequestsInFlight < PredictionRiskAnalyzer.PHASE2_EMBED_MAX_CONCURRENCY) {
            this.embedRequestsInFlight++;
            return;
        }

        await new Promise<void>((resolve) => {
            this.embedWaiters.push(() => {
                this.embedRequestsInFlight++;
                resolve();
            });
        });
    }

    private releaseEmbedSlot(): void {
        this.embedRequestsInFlight = Math.max(0, this.embedRequestsInFlight - 1);
        const next = this.embedWaiters.shift();
        if (next) {
            next();
        }
    }

    public async generateBuildFailureRiskReport(selectedFilePaths: string[] = []): Promise<any> {
        const overallStart = Date.now();
        // Fetch + APPLY the live admin config (Context Window, Cosine/Dice weights, Risk Thresholds)
        // from the dashboard BEFORE scanning, so the report genuinely runs on the admin settings and
        // not defaults. loadConfig also prints the active values (proof the config drives the scan).
        // Previously only runLocalPrediction (a background path) loaded it, so the actual Build Risk
        // Check report ignored the dashboard settings.
        await this.loadConfig();
        // Fail-closed: every stage (cosine + dice + RRF) must run. If the embedding service is down,
        // stop NOW (before the slow scan) so the webview can show "currently unavailable" instead of
        // silently falling back to exact-line-only matching. Throws EmbeddingUnavailableError.
        await this.ensureEmbeddingServiceAvailable();
        const projectName = this.getProjectName();
        const selectedRelativePaths = Array.from(new Set(
            (selectedFilePaths || [])
                .map((raw) => FileUtils.normalizePath(raw))
                .filter((raw) => !!raw)
                .map((raw) => FileUtils.toWorkspaceRelativePath(raw, this.workspaceRoot))
                .filter((raw): raw is string => !!raw)
        ));

        const aggregatedSummary = {
            selected_files_count: selectedRelativePaths.length,
            average_risk_score: 0,
            files_skipped_due_to_error: 0,
        };
        const allMatches: any[] = [];

        let knownFiles: string[] = [];

        try {
            await vscode.window.withProgress(
                {
                    location: vscode.ProgressLocation.Notification,
                    title: 'Generating build failure risk report...',
                    cancellable: true,
                },
                async (progress, token) => {
                    progress.report({ message: 'Validating selected files and fetching bulk scope...' });

                    if (token.isCancellationRequested) {
                        throw new Error('Cancelled');
                    }

                    const bulkResp = await this.apiService.getPredictionFilesBulkData({
                        project_name: this.getProjectName(),
                        actor_id: 'global',
                        selected_files: selectedRelativePaths,
                    });

                    if (bulkResp?.status === true && Array.isArray(bulkResp?.file_paths)) {
                        knownFiles = bulkResp.file_paths.map((value: any) => String(value || '')).filter((value: string) => value.length > 0);
                    } else {
                        Logger.log('[PredictReport][Task2] Bulk API response did not include usable file paths', {
                            status: bulkResp?.status,
                            payloadKeys: bulkResp && typeof bulkResp === 'object' ? Object.keys(bulkResp) : [],
                        });
                    }

                    if (knownFiles.length > 0) {
                        const CONCURRENCY_LIMIT = 5;
                        const MAX_RETRIES = 3;
                        let currentIndex = 0;
                        let filesCompleted = 0;

                        const processKnownFile = async (relativePath: string): Promise<void> => {
                            if (token.isCancellationRequested) {
                                return;
                            }

                            let attempt = 0;
                            let success = false;
                            const normalizedRelative = FileUtils.normalizePath(relativePath);
                            const rawTarget = (selectedFilePaths || []).find((rawSelected) => {
                                const normalizedSelected = FileUtils.normalizePath(rawSelected);
                                const selectedRelative = FileUtils.toWorkspaceRelativePath(normalizedSelected, this.workspaceRoot);
                                return FileUtils.normalizePath(selectedRelative || '') === normalizedRelative;
                            }) || relativePath;

                            // (verbose per-file dev log trimmed for readability)

                            while (attempt < MAX_RETRIES && !success) {
                                if (token.isCancellationRequested) {
                                    return;
                                }

                                attempt++;
                                try {
                                    const fileDataResp = await this.apiService.getPredictionFileData({
                                        project_name: projectName,
                                        actor_id: 'global',
                                        file_paths: [relativePath],
                                    });

                                    await new Promise((resolve) => setTimeout(resolve, 50));
    
                                    
                                                                     const workspaceFolder = vscode.workspace.workspaceFolders?.[0];

if (!workspaceFolder) {
    Logger.log('[PredictReport] No workspace folder found');
    return;
}

const fullFilePath = path.join(
    workspaceFolder.uri.fsPath,
    relativePath
);

if (!fs.existsSync(fullFilePath)) {
    Logger.log(`[PredictReport] File not found: ${fullFilePath}`);
    return;
}

// Inclusion list: only predict on real source files (work/ + gradle + root gradle). Generated
// config files (tmp/**.upda XML, etc.) carry no reliable build-failure signal and flooded the
// report with whole-file XML matches. Same allowlist as change tracking.
if (!FileUtils.isIncludedForTracking(fullFilePath, this.workspaceRoot)) {
    Logger.debug(`[PredictReport] skipped non-source file (not in inclusion list): ${relativePath}`);
    return;
}

const fileContent = fs.readFileSync(fullFilePath, 'utf8');
const fileLines = fileContent.split(/\r?\n/);

// Drop the fix ("after") side up front — we predict on what CAUSED the failure (the original
// "before" file we captured), NOT on the applied solution. Filtering here (before dedup) also
// stops an "after" row from shadowing a "before" row that shares the same line/before_path key.
// Legacy rows with no risk_side are kept as failure side.
const records = (Object.values(fileDataResp).flat() as any[])
    .filter((record: any) => String(record?.risk_side || '').trim().toLowerCase() !== 'after');

// Remove duplicate records
const uniqueRecords = Array.from(
    new Map(
        records.map((record: any) => [
            `${record.line}_${record.before_path}`,
            record
        ])
    ).values()
);

const finalResult: Record<string, any[]> = {
    [relativePath]: []
};

// =====================================================
// STAGE 1
// =====================================================
for (const record of uniqueRecords) {

    // const apiLineIndex = record.line;

    // FAILURE side only. We predict on what CAUSED the failure — the ORIGINAL file we captured
    // BEFORE the fix (risk_side="before"). The "after" record is the applied fix/solution; matching
    // it would flag ALREADY-RESOLVED code as risky (inverted). Backend serves both sides (so a
    // fix-side-only file isn't emptied to a 404); the ENFORCEMENT of "before" lives here. Legacy
    // rows with no risk_side are treated as failure side (match), same as runLocalPrediction.
    if (String(record.risk_side || '').trim().toLowerCase() === 'after') { continue; }

    const targetLine = (record.before_path || '')
        .replace(/^\[\[\d+\]\]\[[^\]]+\]\s*/, '')
        .replace(/\s+/g, ' ')
        .trim();

    // Noise gate: skip boilerplate / comment / XML historical lines. Copyright banners, "* ...",
    // separators, and XML markup (<Core>, <config .../>) match everywhere and carry NO failure
    // signal — this is what flooded acm.h (238 header matches) and the .upda XML files.
    if (!this.isMeaningfulPredictionLine(targetLine)) { continue; }

    const matchedLineIndexes: number[] = [];

    fileLines.forEach((line, index) => {
        const normalizedLine = line
            .replace(/\s+/g, ' ')
            .trim();

        if (normalizedLine === targetLine) {
            matchedLineIndexes.push(index + 1);
        }
    });

    const lineMatchCount = matchedLineIndexes.length;
    const lineFound = lineMatchCount > 0;

    // Client-spec Stage 1: exact text at the SAME historical line index (record.line) is a
    // definitive 100% risk. Stage 2 still runs below for explainability (cosine/dice/RRF).
    const apiLineIndex = Number(record.line || 0);
    const exactIndexMatch = lineFound && apiLineIndex > 0 && matchedLineIndexes.includes(apiLineIndex);

    finalResult[relativePath].push({
        before_path: record.before_path,
        patch: record.patch,
        patch_embedding: record.patch_embedding,
        request_id: record.request_id,

        line: targetLine,
        api_line_index: apiLineIndex,

        matched_line_indexes: matchedLineIndexes,
        line_match_count: lineMatchCount,

        line_found: lineFound,
        exact_index_match: exactIndexMatch,

        // Stage 2 placeholders
       candidate_matches: [],
best_match_index: null,
best_cosine_similarity: null,
best_dice_similarity: null
    });
}

const buildTrigramSet = (
    text: string
): Set<string> => {

    const normalized = String(text || '')
        .toLowerCase()
        .replace(/\s+/g, ' ')
        .trim();

    const trigrams = new Set<string>();

    if (normalized.length < 3) {
        if (normalized.length > 0) {
            trigrams.add(normalized);
        }
        return trigrams;
    }

    for (
        let i = 0;
        i <= normalized.length - 3;
        i++
    ) {
        trigrams.add(
            normalized.substring(i, i + 3)
        );
    }

    return trigrams;
};
// =====================================================
// STAGE 2 — runs for EVERY matched record (do NOT stop at Stage 1).
// Every line_found record is scored by embedding cosine + trigram Sørensen-Dice + RRF, so the
// final report shows the full picture for the whole project scan. Exact same-index matches get a
// 100% HIGH override applied AFTER this (see below), keeping their cosine/dice/RRF for detail.
// Only records with NO line match are skipped (nothing to score).
// =====================================================
for (const result of finalResult[relativePath]) {

    if (!result.line_found) {
        continue;
    }
    const windows: string[] = [];
    const candidateIndexes: number[] = [];

    for (const matchedIndex of result.matched_line_indexes) {

        // N above + current + N below (radius = cfgContextWindow, set on the dashboard)
        const start = Math.max(0, matchedIndex - (this.cfgContextWindow + 1));
        const end = Math.min(
            fileLines.length,
            matchedIndex + this.cfgContextWindow
        );

        const contextBlock = fileLines
            .slice(start, end)
            .join('\n');

        windows.push(contextBlock);
        candidateIndexes.push(matchedIndex);
    }

    if (windows.length === 0) {
        continue;
    }

    // The embedding CALL is isolated from the scoring below: a service outage here is fail-closed
    // (stop the whole report + tell the webview "currently unavailable"), deliberately different
    // from a scoring bug on a single record (logged, scan continues). The pre-flight already
    // checked availability; this covers the service dropping mid-scan.
    let embeddings: any[];
    try {
        const embResp =
            await this.apiService.postPredictEmbedTexts({
                texts: windows
            });
        embeddings = embResp?.embeddings || embResp?.data || [];
    } catch (embedError) {
        Logger.log('[PredictReport] Stage 2 embedding call failed mid-scan — stopping (fail-closed)', {
            file: relativePath,
            error: String(embedError),
        });
        throw new EmbeddingUnavailableError(
            'Build prediction is currently unavailable: the embedding service stopped responding during the scan. Please try again shortly.'
        );
    }
    if (!Array.isArray(embeddings) || embeddings.length === 0) {
        throw new EmbeddingUnavailableError(
            'Build prediction is currently unavailable: the embedding service returned no data. Please try again shortly.'
        );
    }

    try {

        // DSA: the historical patch's trigrams are identical for every candidate of this rule —
        // build the set ONCE here instead of rebuilding it per candidate inside the loop.
        const patchTrigrams = buildTrigramSet(result.patch || '');

        const candidateMatches: any[] = [];

        for (let i = 0; i < candidateIndexes.length; i++) {

            const contextEmbedding = embeddings[i];

            if (
                !contextEmbedding ||
                !result.patch_embedding ||
                !Array.isArray(result.patch_embedding)
            ) {
                continue;
            }

            // Cosine Similarity
            let dotProduct = 0;
            let magnitudeA = 0;
            let magnitudeB = 0;

            const vecA = result.patch_embedding;
            const vecB = contextEmbedding;

            const length = Math.min(
                vecA.length,
                vecB.length
            );

            for (let j = 0; j < length; j++) {
                dotProduct += vecA[j] * vecB[j];
                magnitudeA += vecA[j] * vecA[j];
                magnitudeB += vecB[j] * vecB[j];
            }

            magnitudeA = Math.sqrt(magnitudeA);
            magnitudeB = Math.sqrt(magnitudeB);

            const cosineSimilarity =
                magnitudeA > 0 && magnitudeB > 0
                    ? dotProduct / (magnitudeA * magnitudeB)
                    : 0;

            const candidateStart = Math.max(
    0,
    candidateIndexes[i] - (this.cfgContextWindow + 1)
);

const candidateEnd = Math.min(
    fileLines.length,
    candidateIndexes[i] + this.cfgContextWindow
);

const candidateContext = fileLines
    .slice(candidateStart, candidateEnd)
    .join('\n');

const setX = patchTrigrams;

const setY = buildTrigramSet(
    candidateContext
);

let intersectionCount = 0;

for (const trigram of setX) {
    if (setY.has(trigram)) {
        intersectionCount++;
    }
}

const diceSimilarity =
    (setX.size + setY.size) > 0
        ? (
            2 * intersectionCount
          ) /
          (
            setX.size +
            setY.size
          )
        : 0;

const riskScore =
(
    cosineSimilarity * this.cfgCosineWeight
) +
(
    diceSimilarity * this.cfgDiceWeight
);

const riskPercentage = Number(
    (riskScore * 100).toFixed(2)
);

// const finalRiskScore = Number(
//     riskScore.toFixed(3)
// );
const finalRiskScore = riskPercentage;

candidateMatches.push({
    candidate_id: `candidate_${i}`,

    matched_line_index: candidateIndexes[i],

    cosine_similarity: Number(
        cosineSimilarity.toFixed(3)
    ),

    dice_similarity: Number(
        diceSimilarity.toFixed(3)
    ),

       risk_score: finalRiskScore,  

    risk_level: this.getRiskLevel(
        finalRiskScore
    )
});

// candidateMatches.push({
//     // object_index: `#${i + 1}`,
//     candidate_id: `candidate_${i}`,
//     matched_line_index: candidateIndexes[i],

//     // exact_index_candidate:
//     // candidateIndexes[i] === result.api_line_index,

//     cosine_similarity: Number(
//         cosineSimilarity.toFixed(3)
//     ),

//     dice_similarity: Number(
//         diceSimilarity.toFixed(3)
//     ),

//   risk_score: Number(
//         riskScore.toFixed(2)
//     )
// });
        }

   // ===========================================
// RRF Ranking
// ===========================================

const cosineRanking = [...candidateMatches]
    .sort(
        (a, b) =>
            b.cosine_similarity -
            a.cosine_similarity
    );

const diceRanking = [...candidateMatches]
    .sort(
        (a, b) =>
            b.dice_similarity -
            a.dice_similarity
    );

const cosineRanks =
new Map<string, number>();

const diceRanks =
new Map<string, number>();

cosineRanking.forEach(
    (item, index) => {
        cosineRanks.set(
             item.candidate_id,
                 index + 1
        );
        
    }
);

diceRanking.forEach(
    (item, index) => {
        diceRanks.set(
             item.candidate_id,
    index+1
        );
    }
);

candidateMatches.forEach(
    (candidate) => {

        const cosineRank =
            cosineRanks.get(
               candidate.candidate_id
            ) || 999;

        const diceRank =
            diceRanks.get(
              candidate.candidate_id
            ) || 999;

        candidate.cosine_rank =
            cosineRank;

        candidate.dice_rank =
            diceRank;

        candidate.rrf_score = Number(
            (
                (
                    (1 / (20 + cosineRank)) * this.cfgCosineWeight
                ) +
                (
                    (1 / (20 + diceRank)) * this.cfgDiceWeight
                )
            ).toFixed(6)
        );
    }
);

// Final Sort by RRF
candidateMatches.sort(
    (a, b) =>
        b.rrf_score -
        a.rrf_score
);

candidateMatches.forEach(
    (candidate, index) => {
        candidate.object_index =
            `#${index + 1}`;
    }
);

        result.candidate_matches = candidateMatches;
// result.best_match_index =
//     candidateMatches.length > 0
//         ? candidateMatches[0].matched_line_index
//         : null;
// result.best_candidate_line =
//     candidateMatches[0].matched_line_index;
result.best_candidate = {

    candidate_id:
    candidateMatches[0].candidate_id,

    matched_line:
    candidateMatches[0].matched_line_index,

    cosine:
    candidateMatches[0].cosine_similarity,

    dice:
    candidateMatches[0].dice_similarity,

    risk_score:
    candidateMatches[0].risk_score,

    risk_level:
    candidateMatches[0].risk_level,

    rrf_score:
    candidateMatches[0].rrf_score

};
result.best_cosine_similarity =
    candidateMatches.length > 0
        ? candidateMatches[0].cosine_similarity
        : null;

result.best_dice_similarity =
    candidateMatches.length > 0
        ? candidateMatches[0].dice_similarity
        : null;

result.best_rrf_score =
    candidateMatches.length > 0
        ? candidateMatches[0].rrf_score
        : null;

result.best_risk_level =
    candidateMatches.length > 0
        ? candidateMatches[0].risk_level
        : null;
    //             result.best_dice_similarity =
    // candidateMatches.length > 0
    //     ? Math.max(
    //         ...candidateMatches.map(
    //             (c: any) =>
    //                 c.dice_similarity || 0
    //         )
    //     )
    //     : null;

    } catch (error) {

        // Never swallow an embedding-unavailable signal — it must stop the whole report so the
        // webview can show "currently unavailable" (fail-closed). Only genuine per-record scoring
        // bugs are logged and skipped.
        if (error instanceof EmbeddingUnavailableError) {
            throw error;
        }
        Logger.log(
            '[PredictReport] Stage 2 scoring error (record skipped, scan continues)',
            {
                file: relativePath,
                line: result.line,
                error
            }
        );
    }
}

// =====================================================
// FINAL OUTPUT
// =====================================================
// Concise, user-readable result — ONE line per match (cosine + dice + risk level + band),
// instead of dumping the full JSON. The full detail still goes to the report webview.
try {
    for (const [filePath, recs] of Object.entries((finalResult as Record<string, any[]>) || {})) {
        for (const rec of (recs || [])) {
            const level = String(rec?.best_risk_level || 'LOW');
            const band = level === 'HIGH' ? `${this.cfgMediumRisk + 1}-100`
                       : level === 'MEDIUM' ? `${this.cfgLowRisk + 1}-${this.cfgMediumRisk}`
                       : `0-${this.cfgLowRisk}`;
            Logger.log(`[Prediction] ${path.basename(String(filePath))}  ->  cosine ${Number(rec?.best_cosine_similarity ?? 0).toFixed(3)} | dice ${Number(rec?.best_dice_similarity ?? 0).toFixed(3)} | risk ${level} (${Number(rec?.best_candidate?.risk_score ?? 0)}%, band ${band})`);
        }
    }
} catch { /* ignore summary formatting errors */ }

    const rulesArray = fileDataResp && typeof fileDataResp === 'object'
                                        ? Object.values(fileDataResp)[0]
                                        : null;
                                    const rulesCount = Array.isArray(rulesArray) ? rulesArray.length : 0;
                                    

    // (verbose per-file dev log trimmed for readability)
                                     if (Array.isArray(rulesArray) && rulesArray.length > 0) {
                                        const stagedRows: any[] = Array.isArray(finalResult?.[relativePath]) ? finalResult[relativePath] : [];
                                        const stagedMatchesRaw = stagedRows
                                            .filter((row: any) => row?.line_found === true)
                                            .map((row: any) => {
                                                const candidateRisk = Number(
                                                    row?.best_candidate?.risk_score
                                                        ?? row?.candidate_matches?.[0]?.risk_score
                                                        ?? 0
                                                );
                                                const normalizedRisk = Number.isFinite(candidateRisk)
                                                    ? Number(Math.max(0, Math.min(100, candidateRisk)).toFixed(2))
                                                    : 0;
                                                const expectedLineMatch = String(row?.before_path || '').match(/\[\[(\d+)\]\]/);
                                                const expectedLine = expectedLineMatch ? Number(expectedLineMatch[1]) : 0;
                                                // Report the RRF-SELECTED occurrence, NOT the first
                                                // textual match. When the historical line appears
                                                // multiple times (duplicates), Stage 2 + RRF pick the
                                                // actual failure location, and the risk_score above
                                                // already comes from it — so the reported line MUST be
                                                // that same occurrence, or it points at the wrong line.
                                                const foundLine = Number(
                                                    row?.best_candidate?.matched_line
                                                        ?? row?.candidate_matches?.[0]?.matched_line_index
                                                        ?? (Array.isArray(row?.matched_line_indexes) && row.matched_line_indexes.length > 0
                                                            ? row.matched_line_indexes[0] : 0)
                                                ) || 0;
                                                const lineTextFound = foundLine > 0 && foundLine <= fileLines.length
                                                    ? String(fileLines[foundLine - 1] || '').trim()
                                                    : '';
                                                // Per the developer's flow doc: risk is ALWAYS the
                                                // Stage 2 weighted similarity (cosine×0.7 + dice×0.3),
                                                // ranked by RRF. exact_index_match is Check 2 — a
                                                // display flag only, it does NOT set the risk.
                                                const exact = row?.exact_index_match === true;
                                                const cosine = Number(row?.best_cosine_similarity ?? 0);
                                                const dice = Number(row?.best_dice_similarity ?? 0);
                                                const rrf = Number(row?.best_rrf_score ?? 0);
                                                return {
                                                    file_path: fullFilePath,
                                                    change_id: '',
                                                    request_id: String(row?.request_id || ''),
                                                    stage: 1,
                                                    dominant_stage: 1,
                                                    risk_score: normalizedRisk,
                                                    score: Number((normalizedRisk / 100).toFixed(4)),
                                                    stage1_found: true,
                                                    stage1_score: 0,
                                                    stage2_score: normalizedRisk,
                                                    stage3_score: 0,
                                                    stage4_score: 0,
                                                    stage5_score: 0,
                                                    exact_index_match: exact,
                                                    cosine_similarity: cosine,
                                                    dice_similarity: dice,
                                                    rrf_score: rrf,
                                                    match_reason: 'Risk from context similarity — cosine × 0.7 + dice × 0.3, ranked by RRF.',
                                                    line_expected: expectedLine,
                                                    line_found: foundLine,
                                                    line_text_found: lineTextFound,
                                                    historical_pattern: String(row?.line || '').trim(),
                                                };
                                            });

                                        const dedup = new Map<string, any>();
                                        for (const match of stagedMatchesRaw) {
                                            const key = `${match.file_path || ''}|${match.request_id || ''}|${match.line_expected || 0}|${match.historical_pattern || ''}`;
                                            const prev = dedup.get(key);
                                            if (!prev || Number(match.risk_score || 0) > Number(prev.risk_score || 0)) {
                                                dedup.set(key, match);
                                            }
                                        }
                                        const stagedMatches = Array.from(dedup.values());

                                        if (stagedMatches.length > 0) {
                                            allMatches.push(...stagedMatches);
                                        }

                                        const avgRisk = stagedMatches.length > 0
                                            ? Number((stagedMatches.reduce((sum, m) => sum + Number(m?.risk_score || 0), 0) / stagedMatches.length).toFixed(2))
                                            : 0;
                                        const localSummary = {
                                            total_files_scanned: 1,
                                            total_matches: stagedMatches.length,
                                            stage1_hits: stagedMatches.length,
                                            stage2_hits: 0,
                                            stage3_hits: 0,
                                            average_risk_score: avgRisk,
                                        };
                                        for (const [key, value] of Object.entries(localSummary)) {
                                            if (typeof value !== 'number' || Number.isNaN(value)) {
                                                continue;
                                            }
                                            if (key === 'average_risk_score') {
                                                continue;
                                            }
                                            if (key === 'selected_files_count') {
                                                continue;
                                            }
                                            const current = Number((aggregatedSummary as any)[key] || 0);
                                            (aggregatedSummary as any)[key] = current + value;
                                        }
                                        // (verbose per-file dev log trimmed for readability)
                                    } else {
                                        // (verbose per-file dev log trimmed for readability)
                                    }


                                    // const rulesArray = fileDataResp && typeof fileDataResp === 'object'
                                    //     ? Object.values(fileDataResp)[0]
                                    //     : null;
                                    // const rulesCount = Array.isArray(rulesArray) ? rulesArray.length : 0;

                                    // Logger.log('[PredictReport][Task2] Parsed file-data response', {
                                    //     relativePath,
                                    //     attempt,
                                    //     responseKeys: fileDataResp && typeof fileDataResp === 'object' ? Object.keys(fileDataResp) : [],
                                    //     rulesCount,
                                    // });

                                    // if (Array.isArray(rulesArray) && rulesArray.length > 0) {
                                    //     const mockScope = {
                                    //         target_files: [rawTarget],
                                    //         rules_by_file: { [rawTarget]: rulesArray },
                                    //     };
                                    //     const local = await this.runLocalPrediction(mockScope, [rawTarget]);

                                    //     if (Array.isArray(local?.matches) && local.matches.length > 0) {
                                    //         allMatches.push(...local.matches);
                                    //     }

                                    //     const localSummary = local?.summary && typeof local.summary === 'object' ? local.summary : {};
                                    //     for (const [key, value] of Object.entries(localSummary)) {
                                    //         if (typeof value !== 'number' || Number.isNaN(value)) {
                                    //             continue;
                                    //         }
                                    //         if (key === 'average_risk_score') {
                                    //             continue;
                                    //         }
                                    //         if (key === 'selected_files_count') {
                                    //             continue;
                                    //         }
                                    //         const current = Number((aggregatedSummary as any)[key] || 0);
                                    //         (aggregatedSummary as any)[key] = current + value;
                                    //     }

                                    //     Logger.log('[PredictReport][Task2] Local prediction finished for file', {
                                    //         relativePath,
                                    //         rawTarget,
                                    //         matchesAdded: Array.isArray(local?.matches) ? local.matches.length : 0,
                                    //         totalMatchesSoFar: allMatches.length,
                                    //     });
                                    // } else {
                                    //     Logger.log('[PredictReport][Task2] No rules returned for file', {
                                    //         relativePath,
                                    //         attempt,
                                    //     });
                                    // }

                                    success = true;
                                } catch (fileError) {
                                    // Embedding-unavailable is fatal to the whole report — do NOT
                                    // retry it (retrying a downed service just burns time) and do NOT
                                    // count it as a skipped file. Re-throw so it propagates to the
                                    // caller, which shows the webview "currently unavailable".
                                    if (fileError instanceof EmbeddingUnavailableError) {
                                        throw fileError;
                                    }
                                    Logger.log('[PredictReport][Task2] Error while processing file', {
                                        relativePath,
                                        attempt,
                                        errorMessage: fileError instanceof Error ? fileError.message : String(fileError || ''),
                                    });
                                    await new Promise((resolve) => setTimeout(resolve, attempt * 1000));
                                    if (attempt >= MAX_RETRIES) {
                                        aggregatedSummary.files_skipped_due_to_error++;
                                        Logger.log('[PredictReport][Task2] File skipped after max retries', {
                                            relativePath,
                                            filesSkippedDueToError: aggregatedSummary.files_skipped_due_to_error,
                                        });
                                    }
                                }
                            }

                            filesCompleted++;
                            progress.report({
                                increment: knownFiles.length > 0 ? 100 / knownFiles.length : 0,
                                message: `Processed ${filesCompleted}/${knownFiles.length} known files`,
                            });
                        };

                        const workerCount = Math.min(CONCURRENCY_LIMIT, knownFiles.length);

                        const workers = Array.from({ length: workerCount }, async (_, workerIndex) => {
                            while (true) {
                                if (token.isCancellationRequested) {
                                    return;
                                }
                                const idx = currentIndex;
                                currentIndex++;
                                if (idx >= knownFiles.length) {
                                    return;
                                }
                                await processKnownFile(knownFiles[idx]);
                            }
                        });

                        await Promise.all(workers);
                    } else {
                        progress.report({ message: 'No known files returned from bulk scope.' });
                    }

                    if (token.isCancellationRequested) {
                        Logger.log('[PredictReport][Task2] Cancelled after worker pool completion');
                        throw new Error('Cancelled');
                    }
                }
            );

            // if (allMatches.length > 0) {
            //     const totalRisk = allMatches.reduce((sum, match) => sum + Number(match?.risk_score || 0), 0);
            //     aggregatedSummary.average_risk_score = Number((totalRisk / allMatches.length).toFixed(2));
            // } else {
            //     aggregatedSummary.average_risk_score = 0;
            // }
                 if (allMatches.length > 0) {
                const totalRisk = allMatches.reduce((sum, match) => sum + Number(match?.risk_score || 0), 0);
                aggregatedSummary.average_risk_score = Number((totalRisk / allMatches.length).toFixed(2));
            } else {
                aggregatedSummary.average_risk_score = 0;
            }

            const summaryForBackend = {
                ...aggregatedSummary,
                // The dashboard report APIs (GET /prediction-reports) surface these on the report
                // cards: total_files_scanned -> files_scanned, selected_relative_files -> the file
                // names shown per card. knownFiles = the files that actually went through the scan.
                // Capped so a whole-folder selection (16k+ files) can't blow the storage row.
                total_files_scanned: knownFiles.length,
                selected_relative_files: knownFiles.slice(0, 200),
            };

            Logger.log(`[Prediction] done — ${knownFiles.length} file(s), ${allMatches.length} pattern(s) checked, average risk ${aggregatedSummary.average_risk_score}% (${this.formatElapsedMs(overallStart)})`);

            const reportResp = await this.apiService.postPredictReport({
                project_name: projectName,
                actor_id: 'global',
                matches: allMatches,
                summary: summaryForBackend,
                scan_time: new Date().toISOString(),
            });

            if (!reportResp || reportResp.status !== true || !reportResp.report) {
                throw new Error('Failed to build prediction report');
            }

            return await this.enrichHistoricalRuleCoverageReport(
                reportResp.report,
                { known_files: knownFiles, selected_relative_files: selectedRelativePaths },
                selectedFilePaths
            );
        } catch (error) {
            const message = error instanceof Error ? error.message : String(error || '');
            if (message === 'Cancelled') {
                Logger.log('[PredictReport][Task2] Operation cancelled by user');
                return null;
            }

            Logger.log('[PredictReport][Task2] Report generation failed', {
                errorMessage: message,
                totalElapsed: this.formatElapsedMs(overallStart),
            });
            throw error;
        }
    }

    public getProjectName(): string {
        const workspaceRoot = String(this.workspaceRoot || '').trim();

        if (!workspaceRoot) {
            return '';
        }

        return path.basename(workspaceRoot).trim().toLowerCase();
    }

    private async enrichHistoricalRuleCoverageReport(report: any, _scope: any, _selectedFilePaths: string[] = []): Promise<any> {

        return report;
    }

    private pickHistoricalErrorMessage(response: any): string {
        const errors = Array.isArray(response?.data?.errors) ? response.data.errors : [];
        const first = errors.find((item: any) => typeof item === 'string' && item.trim().length > 0);
        return typeof first === 'string' ? first.trim() : '';
    }

    private pickHistoricalSolutionLine(response: any, rawTarget: string, resolvedPath: string): string {
        const solutionRows = Array.isArray(response?.solutions) ? response.solutions : [];
        const candidates: Array<{ fileName: string; filePath: string; changes: string[] }> = [];

        for (const row of solutionRows) {
            const solutionItems = Array.isArray(row?.solution) ? row.solution : [];
            for (const item of solutionItems) {
                if (!item || typeof item !== 'object') { continue; }
                const filePath = String(item.filePath || '').trim();
                const fileName = String(item.fileName || path.basename(filePath) || '').trim();
                const changes = Array.isArray(item.changes)
                    ? item.changes.map((change: any) => String(change || '').trim()).filter((change: string) => change.length > 0)
                    : [];
                if (!changes.length) { continue; }
                candidates.push({ fileName, filePath, changes });
            }
        }

        if (candidates.length === 0) {
            return '';
        }

        const normalizedResolved = FileUtils.normalizePath(resolvedPath);
        const normalizedRaw = FileUtils.normalizePath(String(rawTarget || ''));
        const targetName = path.basename(normalizedResolved || normalizedRaw).toLowerCase();

        const matched = candidates.find((item) => {
            const candidatePath = FileUtils.normalizePath(item.filePath || '');
            const candidateName = (item.fileName || path.basename(candidatePath)).toLowerCase();
            return candidateName === targetName
                || (candidatePath && normalizedRaw && candidatePath.toLowerCase().endsWith(normalizedRaw.toLowerCase()))
                || (candidatePath && normalizedResolved && normalizedResolved.toLowerCase().endsWith(candidatePath.toLowerCase()));
        }) || candidates[0];

        return String(matched.changes[0] || '').trim();
    }

    private resolvePredictionPath(rawPath: string): string | null {
        const norm = FileUtils.normalizePath(rawPath || '');
        const ws = FileUtils.normalizePath(this.workspaceRoot || '');
        if (!ws) { return null; }

        if (norm && path.isAbsolute(norm)) {
            if (FileUtils.isFileInsideWorkspace(norm, ws) && fs.existsSync(norm)) {
                return norm;
            }
            return null;
        }

        if (norm) {
            const relativeCandidate = FileUtils.normalizePath(path.join(ws, norm));
            if (FileUtils.isFileInsideWorkspace(relativeCandidate, ws) && fs.existsSync(relativeCandidate)) {
                return relativeCandidate;
            }
        }

        const projectFolder = path.basename(ws).toLowerCase();
        const low = norm.toLowerCase();
        const marker = `/${projectFolder}/`;
        const idx = low.indexOf(marker);
        if (idx >= 0) {
            const suffix = norm.slice(idx + marker.length);
            const candidate = FileUtils.normalizePath(path.join(ws, suffix));
            if (FileUtils.isFileInsideWorkspace(candidate, ws) && fs.existsSync(candidate)) { return candidate; }
        }
        const justName = path.basename(norm).toLowerCase();
        if (this.filenameIndex.has(justName)) {
            const p = this.filenameIndex.get(justName) || '';
            if (p && FileUtils.isFileInsideWorkspace(p, ws) && fs.existsSync(p)) { return p; }
        }
        return null;
    }

    private extractCoreChange(changeText: string): string {
        let text = String(changeText || '').trim();
        text = text.replace(/^\s*\[\[\d+\]\]\s*/, '');
        text = text.replace(/^\s*\[(?:MOD_AFTER|MOD_BEFORE|MOD|\+|-)\]\s*/i, '');
        text = text.replace(/\[\[line:\d+\]\]\s*/g, '');
        text = text.replace(/\[\[hunk:\d+\]\]\s*/g, '');
        text = text.trim();
        return text;
    }

    // A historical change line only predicts build failures if it is real code. Comment/header/
    // separator lines are identical across the whole codebase (copyright banners, aligned "* ..."
    // lines, "*****" rules), so matching them produces false 100% risk on every file. Reject them.
    private isMeaningfulPredictionLine(rawCore: string): boolean {
        const raw = String(rawCore || '').trim();
        if (!raw) { return false; }
        // Separator / punctuation-only line: ***, ----, ====, {, }, };, */, ///, etc.
        if (/^[\s*/#=\-_.<>{};:|+~^()]+$/.test(raw)) { return false; }
        // Comment lines: //… , /*… , */ , and aligned "* …" continuations — but NOT a *ptr deref
        // (which is "*" immediately followed by an identifier, no space).
        if (/^(\/\/|\/\*|\*\/)/.test(raw) || /^\*(\s|$)/.test(raw)) { return false; }
        // XML / markup line (generated config: <Core>, <config …/>, <?xml …?>, <FileName>…</FileName>).
        // C/C++ never STARTS a line with '<' (#include <x> starts with '#', a<b starts with 'a'),
        // so this targets markup only, never real code.
        // REFINED (TestGB "0 patterns" case): bare structural markup stays noise, but an
        // attribute-carrying config line like <Tool name="ctc_aurix" version="6.2r1p5" .../> IS
        // the failure signal — the whole versioning-error history lives on exactly such lines.
        // Keep an XML line only when it has at least one real key="value" attribute.
        if (raw.startsWith('<') && raw.includes('>')) {
            if (raw.startsWith('<?') || raw.startsWith('</')) { return false; }
            if (!/\w+\s*=\s*"[^"]+"/.test(raw)) { return false; }
        }
        // Known file-header banner metadata (identical across every file in the codebase).
        const lower = raw.toLowerCase();
        const HEADER_HINTS = ['copyright', 'all rights reserved', 'file name', 'author:',
            'revision', 'reproduction, transmission', 'offenders will be liable', 'patent grant',
            'utility model', 'see check in comment', 'description:', 'created by', 'template version'];
        if (HEADER_HINTS.some((h) => lower.includes(h))) { return false; }
        // Too little actual code content to be a signal (bare braces, "*/", etc.).
        if (raw.replace(/[^A-Za-z0-9_]/g, '').length < 3) { return false; }
        return true;
    }

    private pickServerFixedText(changeText: string, afterPatch: string): string {
        const normalizedAfter = this.normalizeBlockText(afterPatch);
        if (normalizedAfter) {
            return normalizedAfter;
        }
        return this.normalizeBlockText(this.extractCoreChange(changeText));
    }

    private normalizeCompareText(text: string): string {
        return String(text || '')
            .toLowerCase()
            .replace(/\s+/g, '')
            .replace(/['"`]/g, '');
    }

    private isLineMatch(lineText: string, core: string): boolean {
        const line = this.normalizeCompareText(lineText);
        const key = this.normalizeCompareText(core);
        if (!line || !key) { return false; }
        if (line === key) { return true; }
        const minLen = Math.min(line.length, key.length);
        if (minLen < 12) { return false; }
        if (line.includes(key) || key.includes(line)) {
            const ratio = minLen / Math.max(line.length, key.length);
            return ratio >= 0.72;
        }
        return false;
    }

    private patchSimilarity(fileContent: string, patch: string): number {
        const a = this.tokenFreq(fileContent);
        const b = this.tokenFreq(patch);
        return this.cosineFromFreq(a, b);
    }

    private tokenFreq(text: string): Map<string, number> {
        const out = new Map<string, number>();
        const parts = String(text || '')
            .toLowerCase()
            .split(/[^a-z0-9_.$-]+/g)
            .map((x) => x.trim())
            .filter((x) => x.length >= 3);
        for (const p of parts) {
            out.set(p, (out.get(p) || 0) + 1);
        }
        return out;
    }

    private cosineFromFreq(a: Map<string, number>, b: Map<string, number>): number {
        if (!a.size || !b.size) { return 0; }
        let dot = 0;
        let na = 0;
        let nb = 0;
        for (const [, v] of a) { na += v * v; }
        for (const [, v] of b) { nb += v * v; }
        for (const [k, va] of a) {
            const vb = b.get(k) || 0;
            if (vb) { dot += va * vb; }
        }
        const den = Math.sqrt(na) * Math.sqrt(nb);
        if (den <= 0) { return 0; }
        return dot / den;
    }

    // Confidence from history: how sure we are this pattern will break the build again, based on
    // how many DISTINCT past builds it broke. Prediction is a PROBABILITY from history, never a
    // 100% guarantee — so even an exact match of a once-failing line tops out below certainty and
    // rises toward it as the failure count grows. 1x->0.85, 2x->0.925, 3x->0.96, saturates ~1.0.
    private historyConfidence(failCount: number): number {
        const n = Math.max(1, Math.min(8, Math.floor(failCount || 1)));
        return 0.7 + 0.3 * (1 - Math.pow(0.5, n));
    }

    private diceCoefficient(a: Set<string>, b: Set<string>): number {
        if (!a.size || !b.size) { return 0; }
        let inter = 0;
        for (const k of a) { if (b.has(k)) { inter++; } }
        return (2 * inter) / (a.size + b.size);
    }

    // STAGE 2 scorer: the best combined cosine+dice similarity (admin weights) between the stored
    // historical change block and a sliding window of the file. Scanned in a BOUNDED band around
    // the historical line (radius derived from the Context Window) so big files stay fast. Returns
    // the best window's score (0..1) + its center line, or null if there is nothing to compare.
    private evaluatePatchContextStage(
        lines: string[],
        patchOrChange: string,
        expectedLine: number
    ): { score: number; lineFound: number; lineText: string } | null {
        const patchLines = this.extractPatchContextLines(patchOrChange);
        if (patchLines.length === 0) { return null; }
        const windowSize = Math.max(1, patchLines.length);
        const patchTokens = this.tokenFreq(patchLines.join('\n'));
        if (patchTokens.size === 0) { return null; }
        const patchTokenSet = new Set(patchTokens.keys());

        const radius = Math.max(this.cfgContextWindow, windowSize) * 3;
        const anchor = expectedLine > 0 ? expectedLine - 1 : Math.floor(lines.length / 2);
        const start = Math.max(0, anchor - radius);
        const end = Math.min(Math.max(0, lines.length - windowSize), anchor + radius);

        let best = { score: 0, lineFound: 0, lineText: '' };
        for (let i = start; i <= end; i++) {
            const winTokens = this.tokenFreq(lines.slice(i, i + windowSize).join('\n'));
            if (winTokens.size === 0) { continue; }
            const cos = this.cosineFromFreq(patchTokens, winTokens);
            const dice = this.diceCoefficient(patchTokenSet, new Set(winTokens.keys()));
            const combined = this.cfgCosineWeight * cos + this.cfgDiceWeight * dice;
            if (combined > best.score) {
                const center = Math.min(lines.length - 1, i + Math.floor(windowSize / 2));
                best = { score: combined, lineFound: center + 1, lineText: (lines[center] || '').trim() };
            }
        }
        return best.score > 0 ? best : null;
    }

    private normalizeBlockText(text: string): string {
        return String(text || '')
            .replace(/\r\n/g, '\n')
            .split('\n')
            .map((ln) => ln.trim())
            .filter((ln) => ln.length > 0)
            .join('\n');
    }

    private findExactNormalizedLineIndexes(lines: string[], text: string): number[] {
        const normalizedTarget = this.normalizeBlockText(text);
        if (!normalizedTarget) {
            return [];
        }

        const out: number[] = [];
        for (let i = 0; i < lines.length; i++) {
            if (this.normalizeBlockText(lines[i] || '') === normalizedTarget) {
                out.push(i);
            }
        }
        return out;
    }

    private findExactPatchMatch(
        lines: string[],
        patchText: string,
        candidateIndexes: number[],
        radius: number
    ): {
        found: boolean;
        lineFound: number;
        lineTextFound: string;
        hunkFound: number;
        contextScore?: number;
        matchedLines?: number;
        totalLines?: number;
    } {
        const patchLines = this.extractPatchContextLines(patchText);

        if (patchLines.length === 0) {
            return { found: false, lineFound: 0, lineTextFound: '', hunkFound: 0 };
        }

        const normalizedFileLines = lines.map((line) => this.normalizePatchLine(line));
        const normalizedPatchLines = patchLines.map((line) => this.normalizePatchLine(line)).filter(Boolean);

        if (normalizedPatchLines.length === 0) {
            return { found: false, lineFound: 0, lineTextFound: '', hunkFound: 0 };
        }

        /**
         * If backend sends a single-line patch, keep the existing exact-line behavior.
         */
        if (normalizedPatchLines.length === 1) {
            const target = normalizedPatchLines[0];
            const seen = new Set<number>();

            for (const idx of candidateIndexes) {
                const start = Math.max(0, idx - radius);
                const end = Math.min(lines.length - 1, idx + radius);

                for (let lineIdx = start; lineIdx <= end; lineIdx++) {
                    if (seen.has(lineIdx)) { continue; }
                    seen.add(lineIdx);

                    if (normalizedFileLines[lineIdx] && normalizedFileLines[lineIdx] === target) {
                        return {
                            found: true,
                            lineFound: lineIdx + 1,
                            lineTextFound: (lines[lineIdx] || '').trim(),
                            hunkFound: 2,
                            contextScore: 1,
                            matchedLines: 1,
                            totalLines: 1,
                        };
                    }
                }
            }

            return { found: false, lineFound: 0, lineTextFound: '', hunkFound: 0 };
        }

        /**
         * Robust deterministic patch matching:
         * Compare the stored patch context window against local file windows.
         * This is more stable than embedding for the same saved 5/10-before + 5/10-after block.
         */
        const patchCenter = Math.floor(normalizedPatchLines.length / 2);
        let best: {
            score: number;
            matchedLines: number;
            totalLines: number;
            startIndex: number;
            centerIndex: number;
        } = {
            score: 0,
            matchedLines: 0,
            totalLines: normalizedPatchLines.length,
            startIndex: -1,
            centerIndex: -1,
        };

        const seenStarts = new Set<number>();

        for (const idx of candidateIndexes) {
            const baseStart = idx - patchCenter;
            const scanStart = Math.max(0, baseStart - radius);
            const scanEnd = Math.min(lines.length - normalizedPatchLines.length, baseStart + radius);

            for (let startIndex = scanStart; startIndex <= scanEnd; startIndex++) {
                if (startIndex < 0 || startIndex >= lines.length || seenStarts.has(startIndex)) {
                    continue;
                }

                seenStarts.add(startIndex);

                const currentWindow = normalizedFileLines.slice(startIndex, startIndex + normalizedPatchLines.length);
                const score = this.calculatePatchWindowSimilarity(normalizedPatchLines, currentWindow);
                const matchedLines = this.countStrongPatchLineMatches(normalizedPatchLines, currentWindow);

                if (score > best.score || (score === best.score && matchedLines > best.matchedLines)) {
                    const centerIndex = Math.min(lines.length - 1, startIndex + patchCenter);
                    best = {
                        score,
                        matchedLines,
                        totalLines: normalizedPatchLines.length,
                        startIndex,
                        centerIndex,
                    };
                }
            }
        }

        const enoughLines = best.totalLines >= PredictionRiskAnalyzer.PHASE2_PATCH_MIN_LINES;
        const strongEnough = best.score >= PredictionRiskAnalyzer.PHASE2_PATCH_STRONG_THRESHOLD;
        const enoughLineHits = best.matchedLines >= Math.max(2, Math.ceil(best.totalLines * 0.55));

        if (best.startIndex >= 0 && enoughLines && strongEnough && enoughLineHits) {
            return {
                found: true,
                lineFound: best.centerIndex + 1,
                lineTextFound: (lines[best.centerIndex] || '').trim(),
                hunkFound: 2,
                contextScore: best.score,
                matchedLines: best.matchedLines,
                totalLines: best.totalLines,
            };
        }

        return { found: false, lineFound: 0, lineTextFound: '', hunkFound: 0 };
    }

    private extractPatchContextLines(patchText: string): string[] {
        return String(patchText || '')
            .replace(/\r\n/g, '\n')
            .split('\n')
            .map((line) => this.stripPatchLineNoise(line))
            .filter((line) => this.normalizePatchLine(line).length > 0);
    }

    private stripPatchLineNoise(line: string): string {
        return String(line || '')
            .replace(/^\s*[+-]\s?/, '')
            .replace(/^\s*\[\[\d+\]\]\s*/, '')
            .replace(/^\s*\[(?:MOD_AFTER|MOD_BEFORE|MOD|\+|-)\]\s*/i, '')
            .replace(/\[\[line:\d+\]\]\s*/g, '')
            .replace(/\[\[hunk:\d+\]\]\s*/g, '')
            .trim();
    }

    private normalizePatchLine(line: string): string {
        return this.stripPatchLineNoise(line)
            .replace(/\s+/g, ' ')
            .replace(/["'`]/g, '')
            .trim()
            .toLowerCase();
    }

    private calculatePatchWindowSimilarity(expectedLines: string[], currentLines: string[]): number {
        const total = Math.max(expectedLines.length, currentLines.length);

        if (total === 0) {
            return 0;
        }

        let score = 0;

        for (let i = 0; i < total; i++) {
            score += this.patchLineSimilarity(expectedLines[i] || '', currentLines[i] || '');
        }

        return score / total;
    }

    private countStrongPatchLineMatches(expectedLines: string[], currentLines: string[]): number {
        const total = Math.max(expectedLines.length, currentLines.length);
        let count = 0;

        for (let i = 0; i < total; i++) {
            if (this.patchLineSimilarity(expectedLines[i] || '', currentLines[i] || '') >= 0.85) {
                count++;
            }
        }

        return count;
    }

    private patchLineSimilarity(expectedLine: string, currentLine: string): number {
        const expected = this.normalizePatchLine(expectedLine);
        const current = this.normalizePatchLine(currentLine);

        if (!expected && !current) { return 1; }
        if (!expected || !current) { return 0; }
        if (expected === current) { return 1; }

        const minLen = Math.min(expected.length, current.length);
        const maxLen = Math.max(expected.length, current.length);

        if (minLen >= 12 && (expected.includes(current) || current.includes(expected))) {
            return Math.max(0.72, minLen / maxLen);
        }

        return this.cosineFromFreq(this.tokenFreq(expected), this.tokenFreq(current));
    }

    private buildPredictionMatchReason(
        dominantStage: number,
        absenceFound: boolean,
        stage1Found: boolean,
        stage2Found: boolean,
        stage3Found: boolean,
        contextScore: number
    ): string {
        if (absenceFound) {
            return 'Saved fix line was not found in the current file.';
        }

        if (stage1Found || dominantStage === 1) {
            return 'Historical change matched at the expected line.';
        }

        if (stage2Found || dominantStage === 2) {
            return `Saved patch context matched deterministically with score ${Number(contextScore || 0).toFixed(2)}.`;
        }

        if (stage3Found || dominantStage === 3) {
            return 'Embedding fallback matched after deterministic patch matching did not find a strong result.';
        }

        return 'Prediction match generated from historical rule comparison.';
    }

    private async findPatchEmbeddingBest(
        lines: string[],
        candidateIndexes: number[],
        radius: number,
        ruleEmbedding: number[]
    ): Promise<{ found: boolean; score: number; lineFound: number; lineTextFound: string; hunkFound: number }> {
        if (!Array.isArray(ruleEmbedding) || ruleEmbedding.length === 0) {
            return { found: false, score: 0, lineFound: 0, lineTextFound: '', hunkFound: 0 };
        }
        if (!candidateIndexes.length) {
            return { found: false, score: 0, lineFound: 0, lineTextFound: '', hunkFound: 0 };
        }

        const windows: string[] = [];
        const indexes: number[] = [];
        for (const i of candidateIndexes) {
            const start = Math.max(0, i - radius);
            const end = Math.min(lines.length - 1, i + radius);
            windows.push(lines.slice(start, end + 1).join('\n'));
            indexes.push(i);
        }

        let embResp: any;
        const embedStart = Date.now();
        await this.acquireEmbedSlot();
        try {
            embResp = await this.apiService.postPredictEmbedTexts({ texts: windows });
            Logger.log(`[PredictReport] Embeddings fetched in ${this.formatElapsedMs(embedStart)} for ${windows.length} window(s)`);
        } catch {
            Logger.log(`[PredictReport] Embeddings failed after ${this.formatElapsedMs(embedStart)} for ${windows.length} window(s)`);
            return { found: false, score: 0, lineFound: 0, lineTextFound: '', hunkFound: 0 };
        } finally {
            this.releaseEmbedSlot();
        }
        const embeddings: any[] = Array.isArray(embResp?.embeddings) ? embResp.embeddings : [];

        let best = 0;
        let bestIdx = -1;
        for (let j = 0; j < indexes.length; j++) {
            const vec = Array.isArray(embeddings[j]) ? embeddings[j] : [];
            const sim = this.cosineFromVectors(vec, ruleEmbedding);
            if (sim > best) {
                best = sim;
                bestIdx = indexes[j];
            }
        }
        if (bestIdx < 0) {
            return { found: false, score: 0, lineFound: 0, lineTextFound: '', hunkFound: 0 };
        }
        return {
            found: true,
            score: best,
            lineFound: bestIdx + 1,
            lineTextFound: (lines[bestIdx] || '').trim(),
            hunkFound: 3,
        };
    }

    private calculateSorensenDice(strA: string, strB: string): number {
        const a = String(strA || '');
        const b = String(strB || '');

        if (!a.length && !b.length) { return 1; }
        if (!a.length || !b.length) { return 0; }
        if (a === b) { return 1; }

        const buildTrigramCounts = (text: string): Map<string, number> => {
            const counts = new Map<string, number>();
            if (text.length < 3) {
                counts.set(text, 1);
                return counts;
            }
            for (let i = 0; i <= text.length - 3; i++) {
                const gram = text.slice(i, i + 3);
                counts.set(gram, (counts.get(gram) || 0) + 1);
            }
            return counts;
        };

        const gramsA = buildTrigramCounts(a);
        const gramsB = buildTrigramCounts(b);

        let intersection = 0;
        let totalA = 0;
        let totalB = 0;

        for (const [, count] of gramsA) { totalA += count; }
        for (const [, count] of gramsB) { totalB += count; }
        for (const [gram, countA] of gramsA) {
            const countB = gramsB.get(gram) || 0;
            if (countB > 0) {
                intersection += Math.min(countA, countB);
            }
        }

        const denominator = totalA + totalB;
        if (denominator <= 0) { return 0; }
        return (2 * intersection) / denominator;
    }

    private calculateLevenshteinSim(strA: string, strB: string): number {
        const a = String(strA || '');
        const b = String(strB || '');
        const maxLen = Math.max(a.length, b.length);
        if (maxLen === 0) { return 1; }

        const rows = a.length + 1;
        const cols = b.length + 1;
        const dp: number[][] = Array.from({ length: rows }, () => Array.from({ length: cols }, () => 0));

        for (let i = 0; i < rows; i++) { dp[i][0] = i; }
        for (let j = 0; j < cols; j++) { dp[0][j] = j; }

        for (let i = 1; i < rows; i++) {
            for (let j = 1; j < cols; j++) {
                const cost = a[i - 1] === b[j - 1] ? 0 : 1;
                dp[i][j] = Math.min(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                );
            }
        }

        const lev = dp[rows - 1][cols - 1];
        return (maxLen - lev) / maxLen;
    }

    private calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
        if (!Array.isArray(vecA) || !Array.isArray(vecB) || !vecA.length || !vecB.length) {
            return 0;
        }

        const n = Math.min(vecA.length, vecB.length);
        let dot = 0;
        let magA = 0;
        let magB = 0;
        for (let i = 0; i < n; i++) {
            const a = Number(vecA[i] || 0);
            const b = Number(vecB[i] || 0);
            dot += a * b;
            magA += a * a;
            magB += b * b;
        }

        const denominator = Math.sqrt(magA) * Math.sqrt(magB);
        if (denominator === 0) { return 0; }
        return dot / denominator;
    }

    private cosineFromVectors(a: number[], b: number[]): number {
        return this.calculateCosineSimilarity(a, b);
    }

private getRiskLevel(riskPercentage: number): string {

    if (riskPercentage <= this.cfgLowRisk) {
        return 'LOW';
    }

    if (riskPercentage <= this.cfgMediumRisk) {
        return 'MEDIUM';
    }

    return 'HIGH';
}
    // DSA: O(1) exact matches via the prebuilt per-file index + a single fuzzy pass over the
    // PRE-normalized lines (no per-pattern re-normalize). Same result as the old per-line scan.
    private findMatchingLineIndexesFast(normLines: string[], lineIndex: Map<string, number[]>, core: string): number[] {
        const key = this.normalizeCompareText(core);
        if (!key) { return []; }
        const out = new Set<number>(lineIndex.get(key) || []);   // exact matches, O(1)
        // fuzzy containment — same rule as isLineMatch (minLen>=12, substring, ratio>=0.72)
        if (key.length >= 12) {
            for (let i = 0; i < normLines.length; i++) {
                const line = normLines[i];
                if (!line || line === key) { continue; }   // empty, or already counted as exact
                const minLen = Math.min(line.length, key.length);
                if (minLen < 12) { continue; }
                if (line.includes(key) || key.includes(line)) {
                    if (minLen / Math.max(line.length, key.length) >= 0.72) { out.add(i); }
                }
            }
        }
        return Array.from(out).sort((a, b) => a - b);
    }

}
