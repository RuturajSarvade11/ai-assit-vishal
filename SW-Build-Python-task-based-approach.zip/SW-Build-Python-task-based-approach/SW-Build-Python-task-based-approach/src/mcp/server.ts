import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from '@modelcontextprotocol/sdk/types.js';
import * as fs from 'fs';
import * as path from 'path';

const LOG_FILE = process.env.STORAGE_PATH
  ? path.join(process.env.STORAGE_PATH, 'mcp-server.log')
  : path.join(process.cwd(), 'mcp-server.log');

function log(message: string, data?: unknown) {
  const stamp = new Date().toISOString();
  let line = `[${stamp}] ${message}`;
  if (data !== undefined) {
    try {
      line += ` ${typeof data === 'object' ? JSON.stringify(data, null, 2) : String(data)}`;
    } catch {
      line += ' [unserializable]';
    }
  }
  line += '\n';
  try {
    fs.appendFileSync(LOG_FILE, line);
  } catch {
    // ignore logging failures
  }
}

interface ActiveWorkspace {
  workspacePath: string;
  projectName: string;
}

function readActiveWorkspaceFile(): ActiveWorkspace | null {
  const storagePath = String(process.env.STORAGE_PATH || '').trim();
  if (!storagePath) { return null; }

  try {
    const raw = fs.readFileSync(path.join(storagePath, 'active_workspace.json'), 'utf8');
    const parsed = JSON.parse(raw);

    if (typeof parsed.workspacePath === 'string' && parsed.workspacePath) {
      return {
        workspacePath: parsed.workspacePath,
        projectName: String(parsed.projectName || path.basename(parsed.workspacePath)).toLowerCase(),
      };
    }
  } catch {
    // fall through
  }

  return null;
}

function writeActiveWorkspaceFile(workspacePath: string, projectName: string): void {
  const storagePath = String(process.env.STORAGE_PATH || '').trim();
  if (!storagePath) { return; }

  try {
    fs.writeFileSync(
      path.join(storagePath, 'active_workspace.json'),
      JSON.stringify({ workspacePath, projectName, updatedAt: new Date().toISOString() })
    );
  } catch {
    // ignore write failures
  }
}

/**
 * Two-layer workspace resolution — called at the entry of every tool handler.
 *
 * Layer 1 (primary): read active_workspace.json written by the extension on window
 * focus (onDidChangeWindowState) and on activation. This file is always written by
 * the extension instance that owns the focused window, so it is the authoritative
 * source of truth regardless of what env vars the server process was started with.
 * This covers: normal use, multi-window switching, server restarts with stale global
 * mcp.json, and any scenario where MCP_WORKSPACE_PATH env var is outdated.
 *
 * Layer 2 (bootstrap fallback): file does not exist yet (first ever run, extension not
 * yet activated, or storage path missing). Fall back to own MCP_WORKSPACE_PATH env
 * var and seed the file so the next call goes through Layer 1.
 */
function ensureActiveWorkspace(): ActiveWorkspace {
  const envPath = String(process.env.MCP_WORKSPACE_PATH || '').trim();
  const envProject = (
    String(process.env.MCP_PROJECT_NAME || '').trim().toLowerCase() ||
    path.basename(envPath).trim().toLowerCase()
  );

  // Layer 1: file is authoritative — the extension writes it on every window focus
  const fromFile = readActiveWorkspaceFile();
  if (fromFile) {
    return fromFile;
  }

  // Layer 2: no file yet — seed it from env var so subsequent calls use Layer 1
  if (envPath) {
    writeActiveWorkspaceFile(envPath, envProject);
    log('ensureActiveWorkspace: seeded from env var (no sidecar file yet)', { envWorkspace: envPath });
  }

  return { workspacePath: envPath, projectName: envProject };
}

function getWorkspacePath(): string {
  return String(process.env.MCP_WORKSPACE_PATH || '').trim();
}

function getProjectName(): string {
  const explicit = String(process.env.MCP_PROJECT_NAME || '').trim().toLowerCase();
  if (explicit) { return explicit; }

  const workspace = getWorkspacePath();
  return path.basename(workspace || '').trim().toLowerCase();
}

function detectProjectType(basePath: string): 'gradle' | 'td5' {
  if (!basePath || !fs.existsSync(basePath)) { return 'td5'; }

  try {
    const entries = fs.readdirSync(basePath, { withFileTypes: true });
    const hasRootKts = entries.some(entry => entry.isFile() && entry.name.toLowerCase().endsWith('.kts'));

    return hasRootKts ? 'gradle' : 'td5';
  } catch {
    return 'td5';
  }
}

function findReportFile(basePath: string): string | null {
  if (!basePath || !fs.existsSync(basePath)) { return null; }

  const direct = path.join(basePath, 'report.html');
  if (fs.existsSync(direct)) { return direct; }

  const buildDir = path.join(basePath, 'build');
  if (!fs.existsSync(buildDir)) { return null; }

  const stack = [buildDir];
  let bestPath: string | null = null;
  let bestMtime = 0;

  while (stack.length > 0) {
    const current = stack.pop()!;
    let entries: fs.Dirent[] = [];

    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }

    for (const entry of entries) {
      const full = path.join(current, entry.name);

      if (entry.isDirectory()) {
        stack.push(full);
        continue;
      }

      if (entry.isFile() && entry.name.toLowerCase() === 'report.html') {
        const stat = fs.statSync(full);

        if (stat.mtimeMs >= bestMtime) {
          bestMtime = stat.mtimeMs;
          bestPath = full;
        }
      }
    }
  }

  return bestPath;
}

function readTextParts(value: any): string {
  if (typeof value === 'string') {
    return value.trim();
  }

  if (Array.isArray(value)) {
    return value
      .map((item: any) => {
        if (typeof item === 'string') {
          return item.trim();
        }

        if (item && typeof item.text === 'string') {
          return item.text.trim();
        }

        return '';
      })
      .filter(Boolean)
      .join('\n')
      .trim();
  }

  if (value && typeof value.text === 'string') {
    return value.text.trim();
  }

  return '';
}

function extractDiagnosticMessage(item: any): string {
  // Collect ALL text fields — problemDetails has Gradle's high-level description,
  // error.parts contains the raw compiler/linker error lines that match stored embeddings.
  // Using .find(Boolean) would silently drop error.parts whenever problemDetails exists.
  return [
    readTextParts(item?.problemDetails),
    readTextParts(item?.error?.parts),
    readTextParts(item?.message),
    readTextParts(item?.problem),
  ].filter(Boolean).join('\n').trim();
}

function extractJsonFromReportHtml(html: string): any | null {
  const startMarker = '// begin-report-data';
  const startIdx = html.indexOf(startMarker);
  if (startIdx === -1) { return null; }

  const block = html.slice(startIdx + startMarker.length);
  const braceStart = block.indexOf('{');
  if (braceStart === -1) { return null; }

  let depth = 0;
  let inString = false;
  let escaped = false;
  let jsonEnd = -1;

  for (let i = braceStart; i < block.length; i++) {
    const ch = block[i];

    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === '\\') {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }

      continue;
    }

    if (ch === '"') {
      inString = true;
      continue;
    }

    if (ch === '{') {
      depth++;
    } else if (ch === '}') {
      depth--;

      if (depth === 0) {
        jsonEnd = i + 1;
        break;
      }
    }
  }

  if (jsonEnd === -1) { return null; }

  try {
    return JSON.parse(block.slice(braceStart, jsonEnd));
  } catch {
    return null;
  }
}

function extractCurrentError(reportPath: string): string {
  try {
    const html = fs.readFileSync(reportPath, 'utf8');
    const parsed = extractJsonFromReportHtml(html);
    if (!parsed) { return ''; }

    const diagnostics = Array.isArray(parsed?.diagnostics) ? parsed.diagnostics : [];
    const messages = diagnostics
      .filter((item: any) => String(item?.severity || '').toUpperCase() === 'ERROR')
      .map((item: any) => extractDiagnosticMessage(item))
      .filter(Boolean);

    return messages[0] || '';
  } catch {
    return '';
  }
}

function findTD5LogFile(basePath: string): string | null {
  if (!basePath || !fs.existsSync(basePath)) { return null; }

  let bestPath: string | null = null;
  let bestMtime = 0;

  try {
    const entries = fs.readdirSync(basePath, { withFileTypes: true });
    const td5Dirs = entries
      .filter(e => e.isDirectory() && /_td5$/i.test(e.name))
      .map(e => path.join(basePath, e.name));

    for (const td5Dir of td5Dirs) {
      const logDir = path.join(td5Dir, 'log');
      if (!fs.existsSync(logDir)) { continue; }

      try {
        const files = fs.readdirSync(logDir);

        for (const file of files) {
          if (!file.toLowerCase().endsWith('.log')) { continue; }

          const full = path.join(logDir, file);

          try {
            const stat = fs.statSync(full);

            if (stat.mtimeMs >= bestMtime) {
              bestMtime = stat.mtimeMs;
              bestPath = full;
            }
          } catch {
            continue;
          }
        }
      } catch {
        continue;
      }
    }
  } catch {
    return null;
  }

  return bestPath;
}

function extractErrorFromTD5Log(logPath: string): string {
  try {
    const content = fs.readFileSync(logPath, 'utf8');
    const terminalMatch = content.match(/(?:Build|Buildprj)\s+Status:\s*(SUCCESS|FAILED)/i);

    if (!terminalMatch || terminalMatch[1].toUpperCase() !== 'FAILED') { return ''; }

    const lines = content.split(/\r?\n/);
    const initDoneIdx = lines.findIndex(l => l.includes('Finished initializing tools'));
    const CONTEXT_LINES = 8;
    const seen = new Set<string>();
    const errorBlocks: string[] = [];

    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].includes('[ERR!]')) { continue; }
      if (initDoneIdx > 0 && i < initDoneIdx) { continue; }

      const contextStart = Math.max(0, i - CONTEXT_LINES);
      const block: string[] = lines.slice(contextStart, i + 1);

      let j = i + 1;
      while (
        j < lines.length &&
        lines[j].trim().length > 0 &&
        !/\d{2}:\d{2}:\d{2}:\d{3}\s+\[/.test(lines[j])
      ) {
        block.push(lines[j]);
        j++;
      }

      const message = block.join('\n').trim();
      if (!message || seen.has(message)) { continue; }

      seen.add(message);
      errorBlocks.push(message);

      if (errorBlocks.length >= 1) { break; } // first error is enough for query
    }

    return errorBlocks.join('\n\n');
  } catch {
    return '';
  }
}

function renderRecommendationMarkdown(payload: any): string {
  const recommendations = Array.isArray(payload?.recommendations) ? payload.recommendations : [];
  const llmAnalysis = String(payload?.llm_analysis || '').trim();

  const sections: string[] = [];

  if (llmAnalysis) {
    sections.push(
      '> ------------------------------------------------------------------',
      '> **LLM Analysis**',
      '> ------------------------------------------------------------------',
      '>'
    );

    const analysisLines = llmAnalysis.replace(/\r\n/g, '\n').split('\n');

    for (const line of analysisLines) {
      sections.push(`> ${line}`);
    }

    sections.push('>');
  } else {
    // Server omitted the analysis (LLM slow/down/disabled) — explain WHY so a blank analysis
    // never looks like a bug. Matched candidates below remain valid.
    const status = String(payload?.llm_analysis_status || 'ok').trim().toLowerCase();
    const notice = String(payload?.llm_analysis_message || '').trim()
      || ({
        timeout: 'AI analysis is temporarily unavailable — the language model did not respond in time '
          + '(busy/rate-limited, or slow network/auth to the AI service). The matched fixes below are still valid — try again in a moment.',
        error: 'AI analysis is temporarily unavailable — the language-model request failed '
          + '(check the AI service network and credentials). The matched fixes below are still valid.',
        disabled: 'AI analysis is turned off in this environment. The matched fixes below are based on historical matches.',
      } as Record<string, string>)[status] || '';
    if (status !== 'ok' && notice) {
      sections.push(
        '> ------------------------------------------------------------------',
        '> ⚠️ **AI analysis unavailable**',
        '> ------------------------------------------------------------------',
        '>',
        `> ${notice}`,
        '>'
      );
    }
  }

  if (recommendations.length === 0) {
    if (sections.length > 0) {
      sections.push('> No recommendation found for this build error.');
      return sections.join('\n');
    }

    return '> No recommendation found for this build error.';
  }

  // Top 3 only. The backend promotes the LLM-picked fix to the front, so index 0 is
  // Candidate 1 (recommended when there is a pick, else the closest match).
  const topRecommendations = recommendations.slice(0, 3);
  for (let recIdx = 0; recIdx < topRecommendations.length; recIdx++) {
    const recommendation = topRecommendations[recIdx];
    const compareLink = String(recommendation?.compare_diff_link || '').trim();
    const files = Array.isArray(recommendation?.solution) ? recommendation.solution : [];

    // The backend may flag the LLM-selected fix as the recommended one (promoted to
    // rank 1). Badge it with confidence + rationale; other matches render as before.
    const isRecommended = recommendation?.is_recommended === true;
    const confidence = String(recommendation?.selection_confidence || '').trim();
    const whyThisFix = String(recommendation?.why_this_fix || '').trim();

    sections.push('> ------------------------------------------------------------------');
    if (isRecommended) {
      sections.push(`> ✅ **Recommended fix${confidence ? ` (confidence: ${confidence})` : ''}**`);
      if (whyThisFix) {
        sections.push(`> _${whyThisFix}_`);
      }
      sections.push('>');
    }
    sections.push(
      `> **Candidate ${recIdx + 1}**`,
      '> ------------------------------------------------------------------',
      `> **Compare:** ${compareLink ? `[Compare Link](${compareLink})` : 'N/A'}`,
      '>'
    );

    // Honest relevance cue when there is no confident pick (rely-on-data).
    if (recommendation?.is_weak_match === true) {
      sections.push('> ⚠ **Possible match — low relevance.** Based on the closest available data; verify before applying.', '>');
    } else if (recommendation?.is_closest_match === true && !isRecommended) {
      sections.push('> _Closest available match (no high-confidence pick)._', '>');
    }

    // Developer's own description of how this fix solved the failure (entered at upload time).
    const devNote = String(recommendation?.resolution_description || '').trim();
    if (devNote) {
      sections.push(`> **📝 Developer's note:** ${devNote}`, '>');
    }

    if (files.length === 0) {
      sections.push(
        '> 📄 **1) `N/A`**',
        '>',
        '> **Patch:**',
        '>',
        '> ```diff',
        '> ```',
        '>'
      );
    } else {
      for (let fileIdx = 0; fileIdx < files.length; fileIdx++) {
        const file = files[fileIdx];
        const fileName = String(file?.fileName || 'Unknown file').trim();
        const changes = Array.isArray(file?.changes) ? file.changes : [];

        sections.push(
          `> ### ${fileIdx + 1}) 📄 \`${fileName}\``,
          '>',
          '> **Patch:**',
          '>',
          '> ```diff'
        );

        if (changes.length === 0) {
          sections.push('> ');
        } else {
          for (const change of changes) {
            const lines = String(change || '').replace(/\r\n/g, '\n').split('\n');

            for (const line of lines) {
              sections.push(`> ${line}`);
            }
          }
        }

        sections.push('> ```', '>');
      }
    }

    sections.push('> ------------------------------------------------------------------');
  }

  // Related documentation — combines the document lookup into the recommendation flow,
  // so a single recommendation response also surfaces matching documentation.
  const docResults = Array.isArray(payload?.document_context?.results) ? payload.document_context.results : [];
  if (docResults.length > 0) {
    sections.push(
      '> ------------------------------------------------------------------',
      '> **Related Documentation**',
      '> ------------------------------------------------------------------',
      '>'
    );
    for (const doc of docResults.slice(0, 5)) {
      const docName = String(doc?.file_name || doc?.title || 'Document').trim();
      const snippet = String(doc?.preview || doc?.document || '')
        .replace(/\r\n/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200);
      sections.push(`> 📚 **${docName}**`);
      if (snippet) { sections.push(`> ${snippet}…`); }
      sections.push('>');
    }
  }

  return sections.join('\n');
}

async function getJsonWithFallback(pathname: string): Promise<{ payload: any; baseUrl: string }> {
  const { response, baseUrl } = await requestWithFallback(pathname, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  return { payload: await response.json(), baseUrl };
}

async function requestWithFallback(pathname: string, init: RequestInit): Promise<{ response: Response; baseUrl: string }> {
  const bases = [
    String(process.env.BACKEND_BASE_URL || '').trim().replace(/\/$/, ''),
    String(process.env.BACKEND_FALLBACK_URL || '').trim().replace(/\/$/, ''),
  ].filter(Boolean);

  let lastErr: unknown;

  for (const base of bases) {
    try {
      const response = await fetch(`${base}${pathname}`, init);

      if (!response.ok) {
        lastErr = new Error(`HTTP ${response.status}`);
        continue;
      }

      return { response, baseUrl: base };
    } catch (err) {
      lastErr = err;
    }
  }

  throw lastErr || new Error('backend request failed');
}

class LocalWorkspaceMcpServer {
  private readonly server: Server;

  constructor() {
    this.server = new Server(
      {
        name: 'ai-assisted-current-workspace-mcp',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupHandlers();
    this.setupErrorHandling();
  }

  private setupHandlers() {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: this.getTools(),
    }));

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const name = String(request.params?.name || '');

      try {
        if (name === 'copilot_recommendation_active') {
          return await this.handleRecommend(request.params?.arguments || {});
        }

        if (name === 'copilot_document_lookup') {
          return await this.handleDocumentLookup(request.params?.arguments || {});
        }

        if (name === 'show_current_build_error') {
          return await this.handleCurrentError();
        }

        return {
          content: [{ type: 'text', text: `Unknown tool: ${name}` }],
          isError: true,
        };
      } catch (err: any) {
        log('tool execution failed', { tool: name, error: err?.message || String(err) });

        return {
          content: [{ type: 'text', text: JSON.stringify({ status: 'error', error: err?.message || String(err) }, null, 2) }],
          isError: true,
        };
      }
    });
  }

  private getTools(): Tool[] {
    return [
      {
        name: 'copilot_recommendation_active',
        description: [
          'Call this tool when the user asks for a build fix, recommendation, or solution for a build error.',
          'This tool automatically reads the current build error from the workspace and fetches the matched historical fix from the AI backend — never use your own session memory or prior context.',
          'MANDATORY OUTPUT CONTRACT (applies to ALL AI models — GPT, Claude, Gemini, or any other):',
          '1. Copy the tool response text to your reply WITHOUT any modification, addition, or rephrasing.',
          '2. If the tool output contains an LLM Analysis section, show it exactly before the Solution blocks.',
          '3. Every Solution block MUST show: Solution number, Compare link, file name, and patch changes.',
          '4. Do NOT add explanations, analysis, suggestions, or commentary before or after the tool output.',
          '5. Do NOT skip the Compare link or the Patch block even if changes appear simple.',
          '6. If the tool returns "No recommendation found for this build error." — output that exact line only.',
          '7. Never ask the user for the error text — this tool reads it automatically from the workspace report.',
        ].join(' '),
        inputSchema: {
          type: 'object',
          properties: {
            query_text: {
              type: 'string',
              description: 'Optional context from the user query (e.g. "fix aramis version error"). Enriches document search and LLM analysis. Can be omitted — tool still works using the error message alone.',
            },
          },
          additionalProperties: false,
        },
      },
      {
        name: 'show_current_build_error',
        description: 'Show the current build error from the local workspace report.html.',
        inputSchema: {
          type: 'object',
          properties: {},
          additionalProperties: false,
        },
      },
      {
        name: 'copilot_document_lookup',
        description: 'Query injected document knowledge for the current workspace project by calling /get-data-injection. Return the API response exactly as received. Do not summarize, explain, or rewrite.',
        inputSchema: {
          type: 'object',
          properties: {
            query: {
              type: 'string',
              description: 'The question or topic to search in injected documents.',
            },
            project_name: {
              type: 'string',
              description: 'Optional explicit project name. Defaults to current workspace project.',
            },
            top_k: {
              type: 'number',
              description: 'Optional number of matches to return. Defaults to 5.',
            },
          },
          required: ['query'],
          additionalProperties: false,
        },
      },
    ];
  }

  private async handleRecommend(args: any = {}) {
    const { workspacePath, projectName } = ensureActiveWorkspace();
    const queryText = String(args?.query_text || '').trim();

    if (!workspacePath || !projectName) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ status: 'error', error: 'workspace context is not available' }, null, 2) }],
        isError: true,
      };
    }

    const projectType = detectProjectType(workspacePath);

    if (projectType === 'gradle') {
      const reportPath = findReportFile(workspacePath);

      if (!reportPath) {
        return {
          content: [{ type: 'text', text: JSON.stringify({ status: 'error', error: 'report.html not found', workspace_path: workspacePath }, null, 2) }],
          isError: true,
        };
      }

      const errorMessage = extractCurrentError(reportPath);

      if (!errorMessage) {
        return {
          content: [{ type: 'text', text: JSON.stringify({ status: 'error', error: 'current error message not found', report_path: reportPath }, null, 2) }],
          isError: true,
        };
      }

      log('report recommendation start', { projectName, reportPath });

      // Upload the FULL report.html (multipart) to /error-report so the backend parses
      // all ERROR diagnostics and extracts task_path server-side (exact task matching) —
      // matching the validated /error-report behaviour. The old by-message path sent only
      // the first error and no task_path, giving Copilot weaker results than tests showed.
      // Build the multipart body manually as a Buffer to avoid relying on global
      // FormData/Blob typings in the extension build.
      const reportHtml = fs.readFileSync(reportPath);
      const boundary = `----AiBuildBoundary${Date.now().toString(16)}`;
      const field = (name: string, value: string): Buffer =>
        Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`);
      const multipartParts: Buffer[] = [field('project_name', projectName)];
      if (queryText) {
        multipartParts.push(field('query_text', queryText));
        multipartParts.push(field('copilot_query', queryText));
      }
      multipartParts.push(
        Buffer.from(
          `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${path.basename(reportPath)}"\r\n` +
          `Content-Type: text/html\r\n\r\n`,
        ),
      );
      multipartParts.push(reportHtml);
      multipartParts.push(Buffer.from(`\r\n--${boundary}--\r\n`));
      const multipartBody = Buffer.concat(multipartParts);

      const { response, baseUrl } = await requestWithFallback('/error-report', {
        method: 'POST',
        headers: {
          'Content-Type': `multipart/form-data; boundary=${boundary}`,
        },
        body: multipartBody as any,
      });

      const rawPayload = await response.json();
      const payload = Array.isArray(rawPayload)
        ? { recommendations: rawPayload }
        : rawPayload;

      log('report recommendation success', {
        tool: 'copilot_recommendation_active',
        projectName,
        reportPath,
        queryText: queryText || '(none)',
        endpoint: `${baseUrl}/error-report`,
        recommendationCount: Array.isArray((payload as any)?.recommendations) ? (payload as any).recommendations.length : 0,
        hasLlmAnalysis: !!String((payload as any)?.llm_analysis || '').trim(),
      });

      return {
        content: [{ type: 'text', text: renderRecommendationMarkdown(payload) }],
        structuredContent: payload,
        metadata: {
          source: 'error-report',
          report_path: reportPath,
          backend_base_url: baseUrl,
        },
      };
    }

    const td5LogPath = findTD5LogFile(workspacePath);

    if (!td5LogPath) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ status: 'error', error: 'TD5 build log not found', workspace_path: workspacePath }, null, 2) }],
        isError: true,
      };
    }

    const errorMessage = extractErrorFromTD5Log(td5LogPath);

    if (!errorMessage) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ status: 'error', error: 'TD5 build has no failures or is still running', log_path: td5LogPath }, null, 2) }],
        isError: true,
      };
    }

    log('td5 recommendation start', { projectName, td5LogPath });

    const { response, baseUrl } = await requestWithFallback('/report-errors/by-message', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        project_name: projectName,
        error_message: errorMessage,
        ...(queryText && { query_text: queryText, copilot_query: queryText }),
      }),
    });

    const rawPayload = await response.json();
    const payload = Array.isArray(rawPayload)
      ? { recommendations: rawPayload }
      : rawPayload;

    log('td5 recommendation success', {
      tool: 'copilot_recommendation_active',
      projectName,
      td5LogPath,
      queryText: queryText || '(none)',
      endpoint: `${baseUrl}/report-errors/by-message`,
      recommendationCount: Array.isArray((payload as any)?.recommendations) ? (payload as any).recommendations.length : 0,
      hasLlmAnalysis: !!String((payload as any)?.llm_analysis || '').trim(),
    });

    return {
      content: [{ type: 'text', text: renderRecommendationMarkdown(payload) }],
      structuredContent: payload,
      metadata: {
        source: 'report-errors/by-message',
        log_path: td5LogPath,
        backend_base_url: baseUrl,
      },
    };
  }

  private async handleCurrentError() {
    const { workspacePath } = ensureActiveWorkspace();
    const projectType = detectProjectType(workspacePath);

    if (projectType === 'gradle') {
      const reportPath = findReportFile(workspacePath);

      if (reportPath) {
        const errorMessage = extractCurrentError(reportPath);

        return {
          content: [{ type: 'text', text: errorMessage || 'No current build error found.' }],
          structuredContent: {
            workspace_path: workspacePath || null,
            report_path: reportPath || null,
            error_message: errorMessage || '',
          },
        };
      }
    } else {
      const td5LogPath = findTD5LogFile(workspacePath);

      if (td5LogPath) {
        const errorMessage = extractErrorFromTD5Log(td5LogPath);

        return {
          content: [{ type: 'text', text: errorMessage || 'No current build error found.' }],
          structuredContent: {
            workspace_path: workspacePath || null,
            report_path: null,
            error_message: errorMessage || '',
          },
        };
      }
    }

    return {
      content: [{ type: 'text', text: 'No current build error found.' }],
      structuredContent: {
        workspace_path: workspacePath || null,
        report_path: null,
        error_message: '',
      },
    };
  }

  private async handleDocumentLookup(args: any) {
    const { projectName: activeProjectName } = ensureActiveWorkspace();
    const query = String(args?.query || '').trim();
    const projectName = String(args?.project_name || '').trim().toLowerCase() || activeProjectName;
    const topKRaw = Number(args?.top_k);
    const topK = Number.isFinite(topKRaw) && topKRaw > 0 ? Math.min(20, Math.floor(topKRaw)) : 5;

    if (!query) {
      return {
        content: [{ type: 'text', text: JSON.stringify({ success: false, error: 'query is required' }, null, 2) }],
        isError: true,
      };
    }

    const params = new URLSearchParams();
    params.set('query', query);

    if (projectName) {
      params.set('project_name', projectName);
    }

    params.set('top_k', String(topK));

    log('document lookup start', { query, projectName, topK });

    const { payload, baseUrl } = await getJsonWithFallback(`/get-data-injection?${params.toString()}`);

    log('document lookup success', {
      tool: 'copilot_document_lookup',
      endpoint: `${baseUrl}/get-data-injection`,
      query,
      projectName,
      topK,
      resultCount: Number((payload as any)?.count || 0),
    });

    return {
      content: [{ type: 'text', text: JSON.stringify(payload, null, 2) }],
      structuredContent: payload,
      metadata: {
        source: 'get-data-injection',
        backend_base_url: baseUrl,
        project_name: projectName,
        top_k: topK,
      },
    };
  }

  private setupErrorHandling() {
    this.server.onerror = (error) => {
      log('server error', error);
    };

    process.on('SIGINT', async () => {
      await this.server.close();
      process.exit(0);
    });

    process.on('SIGTERM', async () => {
      await this.server.close();
      process.exit(0);
    });
  }

  async start() {
    log('starting MCP server', {
      workspace: getWorkspacePath(),
      project: getProjectName(),
    });

    const transport = new StdioServerTransport();

    await this.server.connect(transport);

    log('MCP server connected');
  }
}

const server = new LocalWorkspaceMcpServer();

server.start().catch((error) => {
  log('failed to start MCP server', error);
  process.exit(1);
});