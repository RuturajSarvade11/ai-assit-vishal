import { FileHandlingExtensionData } from './BinaryFileConfigTypes';

export function getBinaryConfigLoadingHtml(): string {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <style>
    body {
      font-family: "Segoe UI", Tahoma, sans-serif;
      background: #f3f4f6;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      color: #1f2937;
      margin: 0;
    }

    .box {
      background: #fff;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      padding: 24px 32px;
      display: flex;
      gap: 14px;
      align-items: center;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
    }

    .spinner {
      width: 24px;
      height: 24px;
      border: 3px solid #d8eee0;
      border-top-color: #0b7a43;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to {
        transform: rotate(360deg);
      }
    }
  </style>
</head>

<body>
  <div class="box">
    <div class="spinner"></div>
    <strong>Scanning workspace file extensions...</strong>
  </div>
</body>
</html>`;
}

export function getBinaryConfigWebviewHtml(
  extensionData: FileHandlingExtensionData[],
  isComplete = true
): string {
  const jsonData = JSON.stringify(extensionData).replace(/</g, '\\u003c');

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <style>
    :root {
      --green: #0b7a43;
      --green-dark: #096336;
      --border: #e5e7eb;
      --text: #1f2937;
      --muted: #6b7280;
      --bg: #f3f4f6;
      --panel: #ffffff;
      --soft: #f9fafb;
      --blue: #2563eb;
    }

    * {
      box-sizing: border-box;
    }

    html,
    body {
      height: 100%;
      margin: 0;
      padding: 0;
      font-family: "Segoe UI", Tahoma, sans-serif;
      color: var(--text);
      background: var(--bg);
      overflow: hidden;
    }

    body {
      display: flex;
      flex-direction: column;
    }

    .header {
      flex-shrink: 0;
      padding: 12px;
      padding-bottom: 8px;
    }

    .brand {
      border: 1px solid var(--border);
      border-radius: 12px;
      background: var(--soft);
      padding: 14px 16px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    .brand strong {
      display: block;
      font-size: 17px;
      font-weight: 700;
      color: var(--green);
      margin-bottom: 4px;
    }

    .brand span {
      display: block;
      font-size: 12px;
      color: var(--muted);
      line-height: 1.5;
    }

    .toolbar {
      margin-top: 12px;
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      align-items: center;
    }

    .hint {
      margin-top: 10px;
      font-size: 12px;
      color: var(--muted);
    }

    .mode-btn,
    .btn {
      border: none;
      border-radius: 8px;
      padding: 8px 14px;
      cursor: pointer;
      font-size: 12px;
      font-weight: 600;
      line-height: 16px;
      min-height: 32px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      white-space: nowrap;
      transition: all 0.15s ease;
    }
    #saveBtn {
      min-width: 104px;
    }

    .mode-btn {
      border-radius: 999px;
      border: 1px solid var(--border);
      background: var(--panel);
      color: var(--text);
      font-weight: 700;
    }

    .mode-btn.active {
      background: var(--green);
      color: #fff;
      border-color: var(--green);
    }

    .btn-primary {
      background: var(--green);
      color: #fff;
    }

    .btn-primary:hover:not(:disabled) {
      background: var(--green-dark);
    }

    .btn-secondary {
      background: #f3f4f6;
      color: var(--text);
      border: 1px solid var(--border);
    }

    .btn-secondary:hover:not(:disabled) {
      background: #e5e7eb;
    }

    button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .search {
      margin-top: 12px;
    }

    .search input {
      width: 100%;
      max-width: 420px;
      padding: 9px 12px;
      font-size: 13px;
      background: var(--panel);
      color: var(--text);
      border: 1px solid var(--border);
      border-radius: 8px;
      outline: none;
    }

    .search input:focus {
      border-color: var(--green);
      box-shadow: 0 0 0 3px rgba(11, 122, 67, 0.08);
    }

    .content {
      flex: 1;
      min-height: 0;
      padding: 0 12px 12px;
      display: flex;
      flex-direction: column;
    }

    .table-wrap {
      flex: 1;
      min-height: 0;
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 12px;
      overflow: auto;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }

    th,
    td {
      padding: 10px 14px;
      text-align: left;
      border-bottom: 1px solid #f3f4f6;
      font-size: 13px;
    }

    th {
      background: var(--soft);
      color: var(--muted);
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.07em;
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .col-selected {
      width: 90px;
      text-align: center;
    }

    .col-extension {
      width: 260px;
    }

    .col-count {
      width: 140px;
      text-align: right;
    }

    .col-applied {
      width: 120px;
      text-align: center;
    }

    .ext-name {
      font-family: Consolas, "Courier New", monospace;
      color: var(--blue);
      font-weight: 500;
    }

    .ext-count {
      color: var(--muted);
    }

    .ext-applied {
      color: #16a34a;
      font-size: 16px;
      font-weight: 700;
    }

    .footer {
      flex-shrink: 0;
      padding: 0 12px 12px;
    }

    .stats {
      padding: 12px 16px;
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 10px;
      font-size: 13px;
    }

    .stats strong {
      color: var(--green);
      font-weight: 700;
    }

    .save-spinner {
      display: inline-block;
      width: 12px;
      height: 12px;
      flex: 0 0 12px;
      border: 2px solid rgba(255, 255, 255, 0.75);
      border-top-color: transparent;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }
  </style>
</head>

<body>
  <div class="header">
    <div class="brand">
      <strong>Configure File Handling</strong>
      <span>
        Use Binary Files to control text-diff tracking. Use Artifact Files to control runtime/build artifact uploads.
      </span>

      <div class="toolbar">
        <button id="binaryTab" class="mode-btn active">Binary Files</button>
        <button id="artifactTab" class="mode-btn">Artifact Files</button>

        <button id="saveBtn" class="btn btn-primary" disabled>Save Changes</button>
        <button id="resetBtn" class="btn btn-secondary">Reset Current Tab to Defaults</button>
        <button id="selectAllBtn" class="btn btn-secondary">Select All</button>
        <button id="deselectAllBtn" class="btn btn-secondary">Deselect All</button>
      </div>

      <div class="hint" id="tabHint"></div>

      <div class="search">
        <input id="searchBox" placeholder="Search extensions..." />
      </div>
    </div>
  </div>

  <div class="content">
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th class="col-selected">Selected</th>
            <th class="col-extension">Extension</th>
            <th class="col-count">File Count</th>
            <th class="col-applied">Applied</th>
          </tr>
        </thead>
        <tbody id="extensionTable"></tbody>
      </table>
    </div>
  </div>

  <div class="footer">
    <div class="stats">
      <strong>Total extensions:</strong>
      <span id="totalCount">0</span>
      |
      <strong id="selectedLabel">Binary selected:</strong>
      <span id="selectedCount">0</span>
      <span
        id="loadingIndicator"
        style="display:${isComplete ? 'none' : 'inline'}; margin-left: 10px; color: #6b7280;"
      >
        | ⟳ Scanning...
      </span>
    </div>
  </div>

  <script>
    const vscode = acquireVsCodeApi();

    let allData = ${jsonData};
    let activeTab = 'binary';

    const binarySelections = new Map();
    const artifactSelections = new Map();
    const initialBinarySelections = new Map();
    const initialArtifactSelections = new Map();

    function escapeHtml(value) {
      return String(value)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
    }

    function normalizeData(data) {
      return (data || []).map((item) => ({
        extension: item.extension,
        count: Number(item.count || 0),
        isDefaultBinary: !!item.isDefaultBinary,
        isBinarySelected: !!item.isBinarySelected,
        isDefaultArtifact: !!item.isDefaultArtifact,
        isArtifactSelected: !!item.isArtifactSelected
      }));
    }

    function ensureSelectionMaps(data) {
      data.forEach((item) => {
        if (!binarySelections.has(item.extension)) {
          binarySelections.set(item.extension, !!item.isBinarySelected);
        }

        if (!artifactSelections.has(item.extension)) {
          artifactSelections.set(item.extension, !!item.isArtifactSelected);
        }

        if (!initialBinarySelections.has(item.extension)) {
          initialBinarySelections.set(item.extension, !!item.isBinarySelected);
        }

        if (!initialArtifactSelections.has(item.extension)) {
          initialArtifactSelections.set(item.extension, !!item.isArtifactSelected);
        }
      });
    }

    function currentSelectionMap() {
      return activeTab === 'binary' ? binarySelections : artifactSelections;
    }

    function hasChanges() {
      for (const [extension, selected] of binarySelections.entries()) {
        if ((initialBinarySelections.get(extension) || false) !== selected) {
          return true;
        }
      }

      for (const [extension, selected] of artifactSelections.entries()) {
        if ((initialArtifactSelections.get(extension) || false) !== selected) {
          return true;
        }
      }

      return false;
    }

    function updateSaveButton() {
      document.getElementById('saveBtn').disabled = !hasChanges();
    }

    function updateHint() {
      const hint = activeTab === 'binary'
        ? 'Binary files are skipped from text-based code change tracking and uploaded as binary changes.'
        : 'Artifact files are collected from task build folders / TD5 proc folders and uploaded as runtime/build artifacts.';

      document.getElementById('tabHint').textContent = hint;

      document.getElementById('selectedLabel').textContent =
        activeTab === 'binary' ? 'Binary selected:' : 'Artifact selected:';
    }

    function updateStats() {
      const selectedCount = Array.from(currentSelectionMap().values()).filter(Boolean).length;
      document.getElementById('selectedCount').textContent = String(selectedCount);
      updateSaveButton();
    }

    function sortRowsBySelection() {
      const tbody = document.getElementById('extensionTable');
      const rows = Array.from(tbody.querySelectorAll('tr'));

      rows.sort((a, b) => {
        const aChecked = a.querySelector('.ext-checkbox')?.checked ? 1 : 0;
        const bChecked = b.querySelector('.ext-checkbox')?.checked ? 1 : 0;

        if (aChecked !== bChecked) {
          return bChecked - aChecked;
        }

        const aExt = a.querySelector('.ext-name')?.textContent || '';
        const bExt = b.querySelector('.ext-name')?.textContent || '';

        return aExt.localeCompare(bExt);
      });

      rows.forEach((row) => tbody.appendChild(row));
    }

    function filterTable() {
      const query = document.getElementById('searchBox').value.toLowerCase();

      document.querySelectorAll('#extensionTable tr').forEach((row) => {
        const name = (row.querySelector('.ext-name')?.textContent || '').toLowerCase();
        row.style.display = name.includes(query) ? '' : 'none';
      });
    }

    function updateCurrentRowsFromSelection() {
      const selectionMap = currentSelectionMap();

      document.querySelectorAll('#extensionTable tr').forEach((row) => {
        const checkbox = row.querySelector('.ext-checkbox');
        const appliedCell = row.querySelector('.ext-applied');

        if (!checkbox) {
          return;
        }

        const extension = checkbox.dataset.ext || '';
        const selected = !!selectionMap.get(extension);

        checkbox.checked = selected;

        if (appliedCell) {
          appliedCell.textContent = selected ? '✓' : '';
        }
      });

      updateStats();
      filterTable();
    }

    function renderTable(options = {}) {
      updateHint();

      const sortAfterRender = !!options.sortAfterRender;
      const tbody = document.getElementById('extensionTable');
      const selectionMap = currentSelectionMap();

      tbody.innerHTML = '';

      allData.forEach((item) => {
        const extension = item.extension;
        const checked = !!selectionMap.get(extension);
        const row = document.createElement('tr');

        row.innerHTML =
          '<td class="col-selected">' +
            '<input type="checkbox" class="ext-checkbox" data-ext="' + escapeHtml(extension) + '" ' + (checked ? 'checked' : '') + ' />' +
          '</td>' +
          '<td class="col-extension ext-name">' + escapeHtml(extension) + '</td>' +
          '<td class="col-count ext-count">' + Number(item.count || 0).toLocaleString() + '</td>' +
          '<td class="col-applied ext-applied">' + (checked ? '✓' : '') + '</td>';

        tbody.appendChild(row);

        const checkbox = row.querySelector('.ext-checkbox');
        const appliedCell = row.querySelector('.ext-applied');

        checkbox.addEventListener('change', () => {
          selectionMap.set(extension, checkbox.checked);

          if (appliedCell) {
            appliedCell.textContent = checkbox.checked ? '✓' : '';
          }

          updateStats();
          filterTable();

          /**
           * Do not sort immediately on select/deselect.
           * Selected rows move to top only after Save succeeds.
           */
        });
      });

      document.getElementById('totalCount').textContent = String(allData.length);

      updateStats();

      if (sortAfterRender) {
        sortRowsBySelection();
      }

      filterTable();
    }

    function switchTab(tab) {
      activeTab = tab;

      document.getElementById('binaryTab').classList.toggle('active', tab === 'binary');
      document.getElementById('artifactTab').classList.toggle('active', tab === 'artifact');

      renderTable({ sortAfterRender: true });
    }

    function setSavingState(saving) {
      const button = document.getElementById('saveBtn');

      if (saving) {
        button.disabled = true;
        button.innerHTML = '<span class="save-spinner"></span>Saving...';
        return;
      }

      button.innerHTML = 'Save Changes';
      updateSaveButton();
    }

    document.getElementById('binaryTab').addEventListener('click', () => switchTab('binary'));
    document.getElementById('artifactTab').addEventListener('click', () => switchTab('artifact'));
    document.getElementById('searchBox').addEventListener('input', filterTable);

    document.getElementById('selectAllBtn').addEventListener('click', () => {
      allData.forEach((item) => currentSelectionMap().set(item.extension, true));
      updateCurrentRowsFromSelection();
    });

    document.getElementById('deselectAllBtn').addEventListener('click', () => {
      allData.forEach((item) => currentSelectionMap().set(item.extension, false));
      updateCurrentRowsFromSelection();
    });

    document.getElementById('resetBtn').addEventListener('click', () => {
      if (confirm('Reset current tab to default extensions?')) {
        vscode.postMessage({
          command: 'reset',
          tab: activeTab
        });
      }
    });

    document.getElementById('saveBtn').addEventListener('click', () => {
      const saveButton = document.getElementById('saveBtn');

      if (saveButton.disabled) {
        return;
      }

      setSavingState(true);

      vscode.postMessage({
        command: 'save',
        binaryExtensions: Array.from(binarySelections.entries())
          .filter(([, selected]) => selected)
          .map(([extension]) => extension),
        artifactExtensions: Array.from(artifactSelections.entries())
          .filter(([, selected]) => selected)
          .map(([extension]) => extension)
      });
    });

    window.addEventListener('message', (event) => {
      const message = event.data;

      if (message.command === 'updateData') {
        allData = normalizeData(message.data);

        if (message.replaceSelections) {
          binarySelections.clear();
          artifactSelections.clear();
          initialBinarySelections.clear();
          initialArtifactSelections.clear();
        }

        ensureSelectionMaps(allData);

        /**
         * Do not sort during progressive workspace scan updates.
         */
        renderTable({ sortAfterRender: false });

        if (message.isComplete) {
          const loadingIndicator = document.getElementById('loadingIndicator');

          if (loadingIndicator) {
            loadingIndicator.style.display = 'none';
          }
        }

        return;
      }

      if (message.command === 'resetInitialState') {
        initialBinarySelections.clear();
        initialArtifactSelections.clear();

        allData.forEach((item) => {
          initialBinarySelections.set(item.extension, !!binarySelections.get(item.extension));
          initialArtifactSelections.set(item.extension, !!artifactSelections.get(item.extension));
        });

        setSavingState(false);

        /**
         * Save/reset succeeded.
         * Now selected rows move to the top.
         */
        renderTable({ sortAfterRender: true });
      }
    });

    allData = normalizeData(allData);
    ensureSelectionMaps(allData);
    renderTable({ sortAfterRender: true });
  </script>
</body>
</html>`;
}