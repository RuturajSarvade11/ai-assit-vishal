export type FileHandlingTab = 'binary' | 'artifact';

export type FileHandlingExtensionData = {
  extension: string;
  count: number;
  isDefaultBinary: boolean;
  isBinarySelected: boolean;
  isDefaultArtifact: boolean;
  isArtifactSelected: boolean;
};

export type BinaryConfigWebviewMessage =
  | {
      command: 'save';
      binaryExtensions: string[];
      artifactExtensions: string[];
    }
  | {
      command: 'reset';
      tab: FileHandlingTab;
    };
