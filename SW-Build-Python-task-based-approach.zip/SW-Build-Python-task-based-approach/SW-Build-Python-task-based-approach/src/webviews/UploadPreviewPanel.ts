import * as vscode from 'vscode';
import * as cp from 'child_process';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { Logger } from '../utils/Logger';

export interface PreviewPayload {
    contextLabel: string;
    errors: string[];
    /** TD5 only: the failing build's log tail ("last build failure") — rendered instead of the
     *  raw error list, because the tail carries the actual cause. GBE payloads never set it. */
    failureSummary?: string;
    textFiles: { id: string; path: string; action: string }[];
    binaryFiles: { id: string; path: string; action: string }[];
    artifacts: { id: string; path: string; group: string }[];
}

export interface PreviewResult {
    confirmed: boolean;
    approvedTextIds: string[];
    approvedBinaryIds: string[];
    approvedArtifactIds: string[];
    resolutionDescription: string;
}

export class UploadPreviewPanel {
    public static async requestConfirmation(payload: PreviewPayload): Promise<PreviewResult | null> {
        // Lifecycle proof-logging: every step of the popup is logged with the
        // EXACT error, so a missing popup can be attributed — our code vs VS Code's webview renderer.
        // WEBVIEW-ONLY policy: the popup is the one confirmation surface. It is
        // tried twice (a fresh panel recovers transient glitches); if both attempts provably fail,
        // the cause is VS Code's corrupted webview cache — proven fixable by cleaning it — so the
        // extension offers to REPAIR it automatically (save files, close, clean cache, reopen)
        // instead of degrading to a non-webview confirmation.
        for (let attempt = 1; attempt <= 2; attempt++) {
            const outcome = await this.tryWebviewConfirmation(payload, attempt);
            if (outcome.kind === 'decided') { return outcome.result; }
            // render-failed -> retry once, then offer the automatic repair
        }
        return this.offerAutomaticWebviewRepair();
    }

    /** Both popup attempts failed to render: VS Code's webview cache on this machine is corrupted
     *  (verified root cause and verified cure: cleaning the cache restored the popup). On the
     *  user's consent this automates exactly the manual repair — save all files, close VS Code,
     *  clean the renderer caches once every window has exited, and reopen this project. The confirm
     *  popup appears normally on the next build cycle after the restart. */
    private static async offerAutomaticWebviewRepair(): Promise<null> {
        const REPAIR = 'Repair & Restart VS Code';
        const choice = await vscode.window.showWarningMessage(
            'The review popup could not be displayed: VS Code\'s webview cache is corrupted on this machine '
            + '(a VS Code issue, not the AI Assistant). VS Code can repair itself now — it will save your '
            + 'files, close, clean the cache and reopen this project. The review appears on the next build.',
            { modal: true },
            REPAIR
        );
        if (choice !== REPAIR) {
            Logger.log('[UploadPreview] automatic webview repair declined — the review popup stays unavailable until the cache is cleaned');
            return null;
        }
        try {
            const workspace = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || '';
            const codeExe = process.execPath;   // the running VS Code's own executable
            const script = [
                '$ErrorActionPreference = "SilentlyContinue"',
                // Wait for every VS Code window to exit (up to 60s), then make sure none is left.
                'for ($i = 0; $i -lt 60; $i++) { if (-not (Get-Process Code -ErrorAction SilentlyContinue)) { break }; Start-Sleep -Seconds 1 }',
                'Get-Process Code -ErrorAction SilentlyContinue | Stop-Process -Force',
                'Start-Sleep -Seconds 1',
                // The verified repair: renderer caches regenerate automatically on next launch.
                '$base = Join-Path $env:APPDATA "Code"',
                'foreach ($d in @("Service Worker\\CacheStorage","Service Worker\\ScriptCache","Cache","Code Cache","GPUCache")) { Remove-Item -Recurse -Force (Join-Path $base $d) }',
                workspace
                    ? `Start-Process "${codeExe}" -ArgumentList '"${workspace}"'`
                    : `Start-Process "${codeExe}"`,
            ].join('\r\n');
            const scriptPath = path.join(os.tmpdir(), `ai-assistant-webview-repair-${Date.now()}.ps1`);
            fs.writeFileSync(scriptPath, script, 'ascii');
            Logger.log('[UploadPreview] automatic webview repair scheduled — VS Code will close, clean the cache and reopen this project');
            const child = cp.spawn(
                'powershell.exe',
                ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', scriptPath],
                { detached: true, stdio: 'ignore' }
            );
            child.unref();
            await vscode.commands.executeCommand('workbench.action.files.saveAll');
            await vscode.commands.executeCommand('workbench.action.quit');
        } catch (err: any) {
            Logger.log('[UploadPreview] automatic webview repair failed to start', { error: err?.message || String(err) });
        }
        return null;
    }

    private static tryWebviewConfirmation(
        payload: PreviewPayload,
        attempt: number
    ): Promise<{ kind: 'decided'; result: PreviewResult | null } | { kind: 'render-failed' }> {
        return new Promise((resolveTry) => {
            let done = false;
            const finish = (outcome: { kind: 'decided'; result: PreviewResult | null } | { kind: 'render-failed' }) => {
                if (!done) {
                    done = true;
                    resolveTry(outcome);
                }
            };

            let panel: vscode.WebviewPanel;
            try {
                panel = vscode.window.createWebviewPanel(
                    'uploadPreview',
                    'Review Upload Payload',
                    vscode.ViewColumn.Beside,
                    { enableScripts: true, retainContextWhenHidden: true }
                );
                Logger.log(`[UploadPreview] popup panel created (attempt ${attempt}) — waiting for its content to render`);
            } catch (err: any) {
                Logger.log('[UploadPreview] FAILED to create the popup panel (VS Code refused the webview)', {
                    error: err?.message || String(err),
                    stack: String(err?.stack || '').split('\n').slice(0, 4).join(' | '),
                });
                finish({ kind: 'render-failed' });
                return;
            }

            try {
                panel.webview.html = this.getHtmlForWebview(payload, this.getNonce());
            } catch (err: any) {
                Logger.log('[UploadPreview] FAILED to set the popup content', {
                    error: err?.message || String(err),
                });
                try { panel.dispose(); } catch { /* already gone */ }
                finish({ kind: 'render-failed' });
                return;
            }

            // The renderer does not report load failures (e.g. "Could not register service
            // worker") back to the extension host. The page itself posts 'contentLoaded' as its
            // first action — if that never arrives, the panel is open but its content never
            // rendered: a VS Code renderer failure, not this extension's flow.
            let contentLoaded = false;
            let probeDisposal = false;
            const loadProbe = setTimeout(() => {
                if (contentLoaded || done) { return; }
                Logger.log(
                    `[UploadPreview] popup content did NOT render within 10s (attempt ${attempt}) — the panel exists `
                    + 'but VS Code never loaded it (typical: "Could not register service worker" in that window). '
                    + 'Our flow reached the popup; the failure is in the VS Code webview renderer. '
                    // Which EXACT VS Code is failing: a portable/second install keeps its own cache
                    // (cleaning %APPDATA%\Code would not touch it) — appRoot exposes that install.
                    + `[env: ${vscode.env.appName} ${vscode.version}, appRoot=${vscode.env.appRoot}]`
                );
                probeDisposal = true;
                try { panel.dispose(); } catch { /* already gone */ }
                finish({ kind: 'render-failed' });
            }, 10000);

            panel.webview.onDidReceiveMessage((message) => {
                if (message.command === 'contentLoaded') {
                    contentLoaded = true;
                    clearTimeout(loadProbe);
                    Logger.log('[UploadPreview] popup content rendered — waiting for the user\'s decision');
                } else if (message.command === 'confirm') {
                    finish({
                        kind: 'decided',
                        result: {
                            confirmed: true,
                            approvedTextIds: message.selections.approvedTextIds,
                            approvedBinaryIds: message.selections.approvedBinaryIds,
                            approvedArtifactIds: message.selections.approvedArtifactIds,
                            resolutionDescription: message.selections.resolutionDescription
                        }
                    });
                    panel.dispose();
                } else if (message.command === 'cancel') {
                    finish({ kind: 'decided', result: null });
                    panel.dispose();
                }
            });

            panel.onDidDispose(() => {
                clearTimeout(loadProbe);
                if (probeDisposal || done) { return; }
                if (!contentLoaded) {
                    Logger.log('[UploadPreview] popup closed before its content ever rendered (no user decision was possible)');
                }
                // Manual close = the user's cancel, exactly as before the retry logic existed.
                finish({ kind: 'decided', result: null });
            });
        });
    }

    private static getHtmlForWebview(payload: PreviewPayload, nonce: string): string {
        const safePayload = JSON.stringify(payload).replace(/</g, '\\u003c');

        return `<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Review Upload</title>
            <style>
                :root { --green: #0b7a43; --border: #e5e7eb; --text: #1f2937; --muted: #6b7280; --bg: #f3f4f6; --panel: #ffffff; }
                *, *::before, *::after { box-sizing: border-box; }
                body { font-family: "Segoe UI", Tahoma, sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 20px; overflow-x: hidden; }
                .container { max-width: 860px; width: 100%; margin: 0 auto; display: flex; flex-direction: column; gap: 16px; height: calc(100vh - 40px); }
                .header { background: var(--panel); border: 1px solid var(--border); border-radius: 12px; padding: 16px; }
                .header h2 { margin: 0 0 4px 0; color: var(--green); font-size: 18px; }
                .header p { margin: 0; font-size: 13px; color: var(--muted); }
                .scrollable-content { flex: 1; overflow-y: auto; background: var(--panel); border: 1px solid var(--border); border-radius: 12px; padding: 16px; }
                .section { margin-bottom: 20px; }
                .section-title { font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--muted); border-bottom: 1px solid var(--border); padding-bottom: 6px; margin-bottom: 10px; display: flex; justify-content: space-between; }
                /* Big errors (1000+ lines seen in the field) must stay INSIDE their box: wrap
                   unbreakable tokens, cap height, and scroll internally so the layout never
                   blows out horizontally or pushes the footer off-screen. */
                .error-box { background: #fee2e2; border-left: 4px solid #dc2626; color: #b91c1c; padding: 10px; font-family: Consolas, monospace; font-size: 12px; line-height: 1.5; margin-bottom: 8px; border-radius: 4px; white-space: pre-wrap; overflow-wrap: anywhere; word-break: break-word; max-height: 260px; overflow: auto; }
                
                textarea { width: 100%; border: 1px solid var(--border); border-radius: 8px; padding: 12px; font-family: inherit; font-size: 13px; resize: vertical; box-sizing: border-box; background: #fafafa; color: var(--text); transition: border-color 0.2s; }
                textarea:focus { outline: none; border-color: var(--green); box-shadow: 0 0 0 3px rgba(11,122,67,0.1); background: #ffffff; }
                /* When the upload carries no project change the note is REQUIRED, and the
                   dialog must say so - a disabled button explains nothing. */
                textarea.needs-note { border-color: #d97706; background: #fffbeb; }
                .note-required { display: none; margin: 0 0 10px 0; padding: 10px 12px; border: 1px solid #fde68a; border-left: 4px solid #d97706; border-radius: 6px; background: #fffbeb; color: #78350f; font-size: 13px; line-height: 1.45; }
                .note-required.show { display: block; }
                .note-required.done { border-color: #bbf7d0; border-left-color: var(--green); background: #f0fdf4; color: #14532d; }
                .req-mark { display: none; color: #b45309; font-weight: 700; text-transform: none; }
                .req-mark.show { display: inline; }
                .confirm-hint { flex: 1; align-self: center; font-size: 12px; color: #92400e; min-width: 0; }
                
                .file-row { display: flex; align-items: center; gap: 10px; padding: 8px; border-bottom: 1px solid #f9fafb; font-size: 13px; }
                .file-row:hover { background: #f9fafb; }
                .file-row input[type="checkbox"] { accent-color: var(--green); cursor: pointer; }
                .file-path { flex: 1; min-width: 0; overflow-wrap: anywhere; word-break: break-word; }
                .badge { font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 4px; text-transform: uppercase; }
                .badge-added { background: #dcfce7; color: #15803d; }
                .badge-modified { background: #fef3c7; color: #92400e; }
                .badge-deleted { background: #fee2e2; color: #b91c1c; }
                .footer { display: flex; justify-content: flex-end; gap: 10px; background: var(--panel); border: 1px solid var(--border); border-radius: 12px; padding: 16px; }
                button { padding: 8px 16px; border-radius: 6px; border: none; font-size: 13px; font-weight: 600; cursor: pointer; transition: opacity 0.2s; }
                button:hover { opacity: 0.9; }
                button:disabled { cursor: not-allowed; opacity: 0.5; }
                .btn-cancel { background: #f3f4f6; color: var(--text); border: 1px solid var(--border); }
                .btn-confirm { background: var(--green); color: white; }
                .scrollable-content { scroll-behavior: smooth; }
                .scrollable-content::-webkit-scrollbar, .error-box::-webkit-scrollbar { width: 10px; height: 10px; }
                .scrollable-content::-webkit-scrollbar-thumb, .error-box::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 6px; }
                .scrollable-content::-webkit-scrollbar-thumb:hover, .error-box::-webkit-scrollbar-thumb:hover { background: #9ca3af; }
                /* Narrow side-panel: tighten spacing and let the footer buttons wrap full-width. */
                @media (max-width: 560px) {
                    body { padding: 12px; }
                    .container { height: calc(100vh - 24px); gap: 12px; }
                    .header, .scrollable-content, .footer { border-radius: 10px; padding: 12px; }
                    .footer { flex-wrap: wrap; }
                    .footer button { flex: 1 1 auto; }
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Review Error Data & Changes</h2>
                    <p>Context: <strong><script nonce="${nonce}">document.write((${safePayload}).contextLabel);</script></strong></p>
                    <p>Review the errors and files to be uploaded. Uncheck any files you wish to exclude.</p>
                </div>
                
                <div class="scrollable-content" id="content">
                    <div class="section">
                        <div class="section-title"><span>Resolution Note</span><span class="req-mark" id="note-req-mark">Required for this upload</span></div>
                        <div class="note-required" id="note-required" role="status" aria-live="polite"></div>
                        <textarea id="resolution-description" placeholder="Describe how you solved this issue - what you changed and where..." rows="3"></textarea>
                    </div>

                    <div class="section">
                        <div class="section-title" id="err-section-title">Captured Errors (<span id="err-count">0</span>)</div>
                        <div id="error-list"></div>
                    </div>

                    <div class="section">
                        <div class="section-title">
                            <span>Text File Changes (<span id="txt-count">0</span>)</span>
                            <label><input type="checkbox" id="toggle-text" checked> Toggle All</label>
                        </div>
                        <div id="text-files"></div>
                    </div>

                    <div class="section">
                        <div class="section-title">
                            <span>Binary File Changes (<span id="bin-count">0</span>)</span>
                            <label><input type="checkbox" id="toggle-binary" checked> Toggle All</label>
                        </div>
                        <div id="binary-files"></div>
                    </div>

                    <div class="section">
                        <div class="section-title">
                            <span>Runtime Artifacts (<span id="art-count">0</span>)</span>
                            <label><input type="checkbox" id="toggle-artifacts" checked> Toggle All</label>
                        </div>
                        <div id="artifact-files"></div>
                    </div>
                </div>

                <div class="footer">
                    <span class="confirm-hint" id="confirm-hint"></span>
                    <button class="btn-cancel" id="btn-cancel">Discard & Cancel</button>
                    <button class="btn-confirm" id="btn-confirm">Confirm & Upload</button>
                </div>
            </div>

            <script nonce="${nonce}">
                const vscode = acquireVsCodeApi();
                const payload = ${safePayload};
                // First thing the page does: tell the extension host the content actually
                // rendered. If this never arrives, the panel exists but VS Code could not
                // load its content (renderer/service-worker failure) — see requestConfirmation.
                vscode.postMessage({ command: 'contentLoaded' });

                function escapeHtml(unsafe) {
                    return (unsafe || '').toString()
                        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                        .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
                }

                function renderBadge(action) {
                    const type = action.toLowerCase();
                    if (type === 'added') return '<span class="badge badge-added">Added</span>';
                    if (type === 'deleted') return '<span class="badge badge-deleted">Deleted</span>';
                    return '<span class="badge badge-modified">Modified</span>';
                }

                function renderFileList(containerId, items, groupKey) {
                    const container = document.getElementById(containerId);
                    if(items.length === 0) {
                        container.innerHTML = '<div style="font-size:12px;color:var(--muted);padding:8px;">None</div>';
                        return;
                    }
                    container.innerHTML = items.map((item) => \`
                        <div class="file-row">
                            <input type="checkbox" checked data-group="\${groupKey}" data-id="\${item.id}">
                            \${item.action ? renderBadge(item.action) : ''}
                            \${item.group ? '<span class="badge" style="background:#e0e7ff;color:#1d4ed8">' + escapeHtml(item.group) + '</span>' : ''}
                            <span class="file-path" title="\${escapeHtml(item.path)}">\${escapeHtml(item.path)}</span>
                        </div>
                    \`).join('');
                }

                if (payload.failureSummary) {
                    // TD5: the log's tail block IS the story of the failure — show it verbatim.
                    document.getElementById('err-section-title').innerText = 'Last Build Failure';
                    document.getElementById('error-list').innerHTML =
                        \`<div class="error-box" style="white-space:pre-wrap;font-family:monospace">\${escapeHtml(payload.failureSummary)}</div>\`;
                } else {
                    document.getElementById('err-count').innerText = payload.errors.length;
                    document.getElementById('error-list').innerHTML = payload.errors.length === 0
                        ? '<div style="font-size:12px;color:var(--muted)">No errors captured.</div>'
                        : payload.errors.map(err => \`<div class="error-box">\${escapeHtml(err)}</div>\`).join('');
                }

                document.getElementById('txt-count').innerText = payload.textFiles.length;
                renderFileList('text-files', payload.textFiles, 'textFiles');
                
                document.getElementById('bin-count').innerText = payload.binaryFiles.length;
                renderFileList('binary-files', payload.binaryFiles, 'binaryFiles');
                
                document.getElementById('art-count').innerText = payload.artifacts.length;
                if (payload.artifacts.length === 0) {
                    // Not every task has artifacts: if present they are captured, otherwise
                    // nothing is. Say it explicitly so an empty list reads as a checked fact,
                    // not a collection failure (files may exist but be unchanged).
                    document.getElementById('artifact-files').innerHTML =
                        '<div style="font-size:12px;color:var(--muted);padding:8px;">'
                        + 'No artifact files changed in this build cycle — the task workspace was '
                        + 'checked; only files this build wrote are collected.</div>';
                } else {
                    renderFileList('artifact-files', payload.artifacts, 'artifacts');
                }

                function handleToggle(toggleId, groupKey) {
                    document.getElementById(toggleId).addEventListener('change', (e) => {
                        const checked = e.target.checked;
                        document.querySelectorAll(\`input[data-group="\${groupKey}"]\`).forEach(cb => cb.checked = checked);
                        updateConfirmButtonState();
                    });
                }

                handleToggle('toggle-text', 'textFiles');
                handleToggle('toggle-binary', 'binaryFiles');
                handleToggle('toggle-artifacts', 'artifacts');

                // The resolution note is optional as long as the upload carries a PROJECT change - a
                // text or binary file from the tracked project folders. Runtime artifacts are the
                // failure's evidence, not a change, so they never count. With no project change the
                // note is the only record of how the issue was solved (an environment or tool fix
                // leaves nothing in the project), so it becomes required - and the dialog says so.
                function updateConfirmButtonState() {
                    const descriptionText = document.getElementById('resolution-description').value.trim();
                    const selectedChanges = document.querySelectorAll(
                        'input[data-group="textFiles"]:checked, input[data-group="binaryFiles"]:checked').length;
                    const detectedChanges = payload.textFiles.length + payload.binaryFiles.length;
                    const noteRequired = selectedChanges === 0;
                    const isValid = !noteRequired || descriptionText.length > 0;

                    const notice = document.getElementById('note-required');
                    const field = document.getElementById('resolution-description');
                    const hint = document.getElementById('confirm-hint');
                    document.getElementById('note-req-mark').classList.toggle('show', noteRequired);
                    notice.classList.toggle('show', noteRequired);
                    notice.classList.toggle('done', noteRequired && isValid);
                    field.classList.toggle('needs-note', noteRequired && !isValid);
                    if (noteRequired) {
                        const why = detectedChanges === 0
                            ? 'No changes were detected in the project.'
                            : 'No project changes are selected for this upload.';
                        notice.textContent = isValid
                            ? why + ' Your resolution note will be uploaded as the record of how the issue was resolved.'
                            : why + ' Please provide a description explaining how the issue was resolved to enable upload.';
                    }
                    hint.textContent = isValid ? '' : 'Add a resolution note above to enable upload.';
                    document.getElementById('btn-confirm').disabled = !isValid;
                }

                // Update button state on description input
                document.getElementById('resolution-description').addEventListener('input', updateConfirmButtonState);

                // Update button state when a project change is ticked or unticked
                document.querySelectorAll('input[data-group="textFiles"], input[data-group="binaryFiles"]').forEach(checkbox => {
                    checkbox.addEventListener('change', updateConfirmButtonState);
                });

                // Initial button state
                updateConfirmButtonState();

                document.getElementById('btn-cancel').addEventListener('click', () => {
                    vscode.postMessage({ command: 'cancel' });
                });

                document.getElementById('btn-confirm').addEventListener('click', () => {
                    const getSelected = (groupKey) => {
                        return Array.from(document.querySelectorAll(\`input[data-group="\${groupKey}"]:checked\`))
                                    .map(cb => cb.getAttribute('data-id'));
                    };

                    const description = document.getElementById('resolution-description').value.trim();

                    vscode.postMessage({
                        command: 'confirm',
                        selections: {
                            approvedTextIds: getSelected('textFiles'),
                            approvedBinaryIds: getSelected('binaryFiles'),
                            approvedArtifactIds: getSelected('artifacts'),
                            resolutionDescription: description
                        }
                    });
                });
            </script>
        </body>
        </html>`;
    }

    private static getNonce(): string {
        let text = '';
        const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        for (let i = 0; i < 32; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return text;
    }
}