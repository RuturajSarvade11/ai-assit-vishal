import * as vscode from 'vscode';
import { Logger } from '../utils/Logger';
import { FileWatcher } from '../watchers/FileWatcher';

type RecommendationScope = 'customer' | 'project' | 'global';

type RecommendationLaunchContext = {
  project_name: string;
  failed_task: string;
  error_message: string;
  has_error: boolean;
};

let recommendationPanel: vscode.WebviewPanel | undefined;
let latestRecommendationPayload: any = null;
let latestSelectedScope: RecommendationScope = 'project';
let recommendationRunNonce = 0;
let recommendationAbortController: AbortController | undefined;
let latestLaunchContext: RecommendationLaunchContext = {
  project_name: 'N/A',
  failed_task: '',
  error_message: '',
  has_error: false,
};

export function registerRecommendationCommand(
  context: vscode.ExtensionContext,
  getFileWatcher: () => FileWatcher | undefined
): void {
  const recommendCurrentErrorCmd = vscode.commands.registerCommand(
    'gradleErrorAssistant.recommendCurrentError',
    async () => {
      const fileWatcher = getFileWatcher();
      if (!fileWatcher) {
        vscode.window.showErrorMessage(
          'AI Assisted Build: the project watcher is not ready yet. Open a Gradle build project, wait a moment, then try again.'
        );
        return;
      }
      latestLaunchContext = fileWatcher.getRecommendationLaunchContext();
      ensureRecommendationPanel(getFileWatcher);
      recommendationPanel!.title = 'AIASB: Error Resolution';
      recommendationPanel!.webview.html = buildScopeSelectionWebviewHtml(latestSelectedScope, latestLaunchContext);
      recommendationPanel!.reveal(vscode.ViewColumn.Beside);
    }
  );

  context.subscriptions.push(recommendCurrentErrorCmd);

  // One-click Helpful / Not-helpful from the recommendation panel (command-URI links).
  // Sends the vote to the backend feedback endpoint and reflects it in the panel.
  const recoFeedbackCmd = vscode.commands.registerCommand(
    'gradleErrorAssistant.recommendationFeedback',
    async (requestId: string, isHelpful: boolean) => {
      const fileWatcher = getFileWatcher();
      const payload = latestRecommendationPayload;
      if (!fileWatcher || !payload || !requestId) {
        return;
      }
      try {
        await fileWatcher.submitRecommendationFeedback({
          request_id: String(requestId),
          is_helpful: !!isHelpful,
          project_name: String(payload.project_name || ''),
          feedback_token: String(payload.feedback_token || ''),
          query_signature_hashes: Array.isArray(payload.query_signature_hashes) ? payload.query_signature_hashes : [],
        });
        applyLocalFeedback(payload, String(requestId), !!isHelpful);
        if (recommendationPanel) {
          recommendationPanel.webview.html = buildRecommendationWebviewHtml(payload);
        }
        vscode.window.showInformationMessage(
          `Thanks — marked ${isHelpful ? 'Helpful' : 'Not helpful'}. This teaches the assistant which fix suits this kind of error.`
        );
      } catch (err: any) {
        Logger.log('[RecommendUI] feedback submit failed', err);
        vscode.window.showErrorMessage(`Could not send feedback: ${err?.message || String(err)}`);
      }
    }
  );
  context.subscriptions.push(recoFeedbackCmd);
}

// Fetch a recommendation (optionally with a documentation query) and render it into the shared
// panel. queryText='' = fix only. Called both from the command (initial open) and from the
// in-panel search bar (docSearch message) — same code path, so results always land here.
async function runRecommendation(
  getFileWatcher: () => FileWatcher | undefined,
  queryText: string,
  scope: RecommendationScope = 'project',
  abortSignal?: AbortSignal
): Promise<void> {
  const fileWatcher = getFileWatcher();
  if (!fileWatcher) {
    vscode.window.showErrorMessage('AI Assisted Build: the project watcher is not ready yet. Open a Gradle build project, wait a moment, then try again.');
    return;
  }
  let recommendation: any;
  try {
    recommendation = await vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: queryText.trim() ? 'Searching documentation…' : 'Fetching recommendation…',
        cancellable: false,
      },
      async () => fileWatcher.getCurrentCopilotRecommendation(queryText, scope, abortSignal)
    );
  } catch (err: any) {
    if (isAbortError(err) || abortSignal?.aborted) {
      Logger.log('[RecommendUI] recommendation request cancelled by user');
      return;
    }
    Logger.log('[RecommendUI] recommendation fetch failed', err);
    // Surface the failure inside the panel (not just a toast) so the user is never confused.
    recommendation = {
      status: 'error',
      query_text: queryText,
      selected_scope: scope,
      error: `Could not reach the recommendation service. Check that the backend is running and reachable, then try again.\n\nDetails: ${err?.message || String(err)}`,
    };
  }

  if (abortSignal?.aborted) {
    return;
  }

  try {
    ensureRecommendationPanel(getFileWatcher);
    recommendation.selected_scope = String(recommendation?.selected_scope || scope);
    latestRecommendationPayload = recommendation;
    latestLaunchContext.project_name = String(recommendation?.project_name || latestLaunchContext.project_name || 'N/A');
    recommendationPanel!.webview.html = buildRecommendationWebviewHtml(recommendation);
    recommendationPanel!.reveal(vscode.ViewColumn.Beside);
  } catch (err: any) {
    Logger.log('[RecommendUI] failed to render recommendation panel', err);
    vscode.window.showErrorMessage(`Failed to display the recommendation panel: ${err?.message || String(err)}`);
  }
}

// Create the panel once and wire its message handler. Scripts are enabled so the in-panel search
// bar can post a 'docSearch' query back; command URIs stay enabled for the Helpful/Not-helpful
// feedback links.
function ensureRecommendationPanel(getFileWatcher: () => FileWatcher | undefined): void {
  if (recommendationPanel) { return; }
  recommendationPanel = vscode.window.createWebviewPanel(
    'currentErrorRecommendation',
    'AIASB: Recommendation',
    vscode.ViewColumn.Beside,
    { enableScripts: true, enableCommandUris: true, retainContextWhenHidden: true }
  );
  recommendationPanel.onDidDispose(() => {
    recommendationAbortController?.abort();
    recommendationAbortController = undefined;
    recommendationPanel = undefined;
    latestRecommendationPayload = null;
    recommendationRunNonce = 0;
  });
  recommendationPanel.webview.onDidReceiveMessage(async (message: any) => {
    if (!message) {
      return;
    }

    if (message.command === 'startRecommendation') {
      const selectedScope = normalizeScope(message.scope);
      latestSelectedScope = selectedScope;
      const fw = getFileWatcher();
      if (fw) {
        latestLaunchContext = fw.getRecommendationLaunchContext();
      }

      recommendationAbortController?.abort();
      const runAbortController = new AbortController();
      recommendationAbortController = runAbortController;

      if (recommendationPanel) {
        recommendationPanel.webview.html = buildRecommendationLoadingWebviewHtml(selectedScope);
      }

      const currentRun = ++recommendationRunNonce;
      await runRecommendation(getFileWatcher, '', selectedScope, runAbortController.signal);
      if (recommendationAbortController === runAbortController) {
        recommendationAbortController = undefined;
      }
      if (currentRun !== recommendationRunNonce) {
        return;
      }
      return;
    }

    if (message.command === 'cancelRecommendation') {
      recommendationAbortController?.abort();
      recommendationAbortController = undefined;
      recommendationRunNonce++;
      if (recommendationPanel) {
        recommendationPanel.webview.html = buildScopeSelectionWebviewHtml(latestSelectedScope, latestLaunchContext);
      }
      return;
    }

    if (message.command === 'docSearch') {
      await runRecommendation(
        getFileWatcher,
        String(message.query || '').trim(),
        normalizeScope(latestRecommendationPayload?.selected_scope || latestSelectedScope)
      );
    }
  });
}

function normalizeScope(scope: unknown): RecommendationScope {
  const value = String(scope || '').trim().toLowerCase();
  if (value === 'customer' || value === 'global') {
    return value;
  }
  return 'project';
}

function scopeLabel(scope: RecommendationScope): string {
  if (scope === 'customer') {
    return 'Customer Scope';
  }
  if (scope === 'global') {
    return 'Global Scope';
  }
  return 'Project Scope';
}

function scopeDescription(scope: RecommendationScope): string {
  if (scope === 'customer') {
    return 'Searching customer-wide repositories, internal docs, and previously validated fixes.';
  }
  if (scope === 'global') {
    return 'Searching across all available solution knowledge sources.';
  }
  return 'Searching project build history and validated fixes for this workspace.';
}

// Reflect a vote locally so the panel updates immediately (counts + "recorded" state).
function applyLocalFeedback(payload: any, requestId: string, isHelpful: boolean): void {
  const lists = [payload?.recommendations, payload?.result].filter((l: any) => Array.isArray(l));
  for (const list of lists) {
    for (const rec of list) {
      if (rec && String(rec.request_id || '').trim() === requestId) {
        const next = isHelpful ? 'helpful' : 'not_helpful';
        const prev = String(rec._feedback || '');
        // Only one vote per user/error (backend overwrites the same feedback_token). When the user
        // SWITCHES their vote, move the count off the old side and onto the new one so the displayed
        // counts shift — previously the count only updated on the first vote, so a switch left the
        // tally stuck on the original choice while only the marker colour moved. Re-clicking the
        // same side is a no-op (no double-count).
        if (prev !== next) {
          if (prev === 'helpful') { rec.thumbs_up = Math.max(0, (Number(rec.thumbs_up) || 0) - 1); }
          else if (prev === 'not_helpful') { rec.thumbs_down = Math.max(0, (Number(rec.thumbs_down) || 0) - 1); }
          if (isHelpful) { rec.thumbs_up = (Number(rec.thumbs_up) || 0) + 1; }
          else { rec.thumbs_down = (Number(rec.thumbs_down) || 0) + 1; }
        }
        rec._feedback = next;
      }
    }
  }
}

export function disposeRecommendationWebviewState(): void {
  recommendationAbortController?.abort();
  recommendationAbortController = undefined;
  recommendationPanel?.dispose();
  recommendationPanel = undefined;
  latestRecommendationPayload = null;
}

function isAbortError(err: any): boolean {
  const name = String(err?.name || '').toLowerCase();
  const msg = String(err?.message || err || '').toLowerCase();
  return name === 'aborterror' || msg.includes('abort') || msg.includes('cancelled') || msg.includes('canceled');
}

function esc(input: string): string {
  return String(input || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const RECO_WEBVIEW_STYLES = `
  :root { --green:#0b7a43; --border:#e5e7eb; --text:#1f2937; --muted:#6b7280; }
  * { box-sizing:border-box; margin:0; padding:0; }
  html,body { font-family:"Segoe UI",Tahoma,sans-serif; color:var(--text); background:#f3f4f6; }
  .brand-header {
    position:sticky; top:0; z-index:10; margin:12px 12px 0 12px;
    border:1px solid var(--border); border-radius:12px; background:#f9fafb;
    padding:12px 16px; display:flex; justify-content:space-between; align-items:center; gap:16px;
    box-shadow:0 2px 8px rgba(0,0,0,0.06);
  }
  .brand-titles strong { display:block; font-size:17px; font-weight:700; color:var(--green); }
  .brand-titles span { color:var(--muted); font-size:11px; margin-top:2px; display:block; }
  .page-content { padding:12px; display:flex; flex-direction:column; gap:12px; }
  .section-label { font-size:11px; font-weight:700; color:var(--muted); text-transform:uppercase; letter-spacing:0.07em; padding:4px 2px; }
  .verdict { border-radius:12px; padding:16px 20px; display:flex; align-items:flex-start; gap:14px; background:#ecfdf5; border:1px solid #bbf7d0; }
  .verdict-medium { background:#fffbeb; border:1px solid #fde68a; }
  .verdict-icon { font-size:24px; line-height:1; margin-top:2px; color:#16a34a; }
  .verdict-medium .verdict-icon { color:#d97706; }
  .verdict-title { font-size:15px; font-weight:700; margin-bottom:4px; color:#15803d; }
  .verdict-medium .verdict-title { color:#b45309; }
  .verdict-desc { font-size:13px; color:var(--text); line-height:1.55; }
  .card { background:#fff; border:1px solid var(--border); border-radius:12px; border-left:5px solid var(--border); overflow:hidden; }
  .card.recommended { border-left-color:var(--green); }
  .card-header { padding:14px 16px 8px 16px; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
  .card-title { font-size:15px; font-weight:700; }
  .card-meta { margin:0 16px 8px 16px; font-size:11px; color:var(--muted); }
  .badge { display:inline-flex; align-items:center; border-radius:6px; padding:3px 9px; font-size:11px; font-weight:700; }
  .badge-high { background:#dcfce7; color:#15803d; }
  .badge-medium { background:#fef3c7; color:#92400e; }
  .badge-low { background:#fee2e2; color:#b91c1c; }
  .why { padding:0 16px 10px 16px; font-size:12.5px; color:var(--text); line-height:1.5; font-style:italic; }
  .dev-note { margin:0 16px 12px 16px; padding:10px 12px; background:#f3f9f5; border:1px solid #cfe8d8; border-left:3px solid var(--green); border-radius:8px; font-size:12.5px; color:var(--text); line-height:1.5; }
  .dev-note-label { display:block; font-weight:700; color:var(--green); font-size:11px; text-transform:uppercase; letter-spacing:.3px; margin-bottom:4px; }
  .relevance-note { margin:0 16px 8px 16px; padding:6px 10px; background:#fff7ed; border:1px solid #fed7aa; border-radius:6px; font-size:11.5px; color:#9a3412; }
  .selected-evidence { margin:0 16px 12px 16px; padding:10px 12px; background:#eef5ff; border:1px solid #cdddf5; border-left:3px solid #3b82f6; border-radius:8px; }
  .sel-title { font-size:11px; font-weight:700; color:#1d4ed8; text-transform:uppercase; letter-spacing:.05em; margin-bottom:4px; }
  .sel-rrf { font-size:11.5px; color:var(--muted); font-style:italic; margin-bottom:6px; }
  .sel-list { margin:0; padding-left:18px; font-size:12px; color:var(--text); line-height:1.6; }
  .sel-why { color:var(--muted); }
  .evidence-details { margin:10px 16px 4px 16px; border:1px solid #e5e7eb; border-radius:8px; background:#f8fafc; overflow:hidden; }
  .evidence-details > summary { cursor:pointer; list-style:none; padding:8px 12px; font-size:12px; font-weight:600; color:#475569; user-select:none; }
  .evidence-details > summary::-webkit-details-marker { display:none; }
  .evidence-details > summary:hover { background:#eef2f7; }
  .evidence-details[open] > summary { border-bottom:1px solid #e5e7eb; color:var(--text); }
  .evidence-body { padding:10px 12px; }
  .ev-why { font-size:12.5px; color:#334155; margin-bottom:8px; }
  .ev-label { font-size:10.5px; font-weight:700; color:var(--muted); text-transform:uppercase; letter-spacing:.05em; margin:8px 0 3px; }
  .ev-preview { font-size:11.5px; color:#475569; font-family:ui-monospace,Menlo,Consolas,monospace; white-space:pre-wrap; word-break:break-word; background:#fff; border:1px solid #eef0f2; border-radius:6px; padding:6px 8px; }
  .ev-full { margin:5px 0 2px; max-height:280px; overflow:auto; font-size:11.5px; color:#334155; font-family:ui-monospace,Menlo,Consolas,monospace; white-space:pre-wrap; word-break:break-word; background:#fff; border:1px solid #e5e7eb; border-radius:6px; padding:8px 10px; }
  .ev-raw-link { font-size:11.5px; font-weight:600; color:var(--green); text-decoration:none; }
  .ev-raw-link:hover { text-decoration:underline; }
  .summary-item { margin:0 16px 10px 16px; }
  .summary-file { font-size:12.5px; font-weight:700; color:var(--text); margin-bottom:4px; }
  .summary-empty { margin:0 16px 10px 16px; font-size:12px; color:var(--muted); font-style:italic; }
  .ev-artifact { font-size:12px; color:#334155; margin-bottom:6px; }
  .ev-rrf { margin-top:10px; padding-top:8px; border-top:1px dashed #e5e7eb; font-size:11.5px; color:var(--muted); font-style:italic; }
  .detail-block { padding:10px 16px; border-top:1px solid #f3f4f6; }
  .detail-label { font-size:10px; font-weight:700; color:var(--muted); text-transform:uppercase; letter-spacing:0.06em; margin-bottom:6px; }
  .file-name { font-size:13px; font-weight:600; color:var(--text); }
  .file-path { font-size:11px; color:var(--muted); word-break:break-all; margin-bottom:6px; }
  pre.diff { background:#0f172a; color:#e2e8f0; border-radius:8px; padding:10px 12px; font-family:Consolas,"Courier New",monospace; font-size:12px; white-space:pre-wrap; word-break:break-word; line-height:1.5; }
  pre.diff .add { color:#86efac; } pre.diff .mod { color:#fde68a; } pre.diff .del { color:#fca5a5; }
  a.compare { display:inline-block; margin:8px 16px 12px 16px; font-size:12px; font-weight:600; color:var(--green); text-decoration:none; }
  a.compare:hover { text-decoration:underline; }
  .evidence { background:#fff; border:1px solid var(--border); border-radius:12px; overflow:hidden; }
  .ev-row { display:flex; align-items:center; gap:10px; padding:10px 14px; border-bottom:1px solid #f3f4f6; font-size:12px; }
  .ev-row:last-child { border-bottom:none; }
  .ev-rank { width:22px; height:22px; flex-shrink:0; border-radius:50%; background:var(--green); color:#fff; font-size:11px; font-weight:700; display:flex; align-items:center; justify-content:center; }
  .ev-main { flex:1; min-width:0; }
  .ev-source { font-weight:700; }
  .ev-prev { color:var(--muted); font-size:11px; line-height:1.45; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; cursor:help; }
  .pill { font-size:10px; font-weight:600; padding:2px 8px; border-radius:99px; flex-shrink:0; }
  .pill-exact { background:#dcfce7; color:#166534; }
  .pill-project { background:#dbeafe; color:#1e40af; }
  .pill-global { background:#fef3c7; color:#92400e; }
  .pill-src { background:#ede9fe; color:#5b21b6; }
  .summary-line { font-size:12px; color:var(--muted); padding:2px 2px 0; }
  .doc-list { display:flex; flex-direction:column; gap:8px; }
  .doc-item { background:#fff; border:1px solid var(--border); border-radius:10px; border-left:4px solid #6366f1; padding:10px 14px; }
  .doc-item > summary { cursor:pointer; list-style:none; outline:none; }
  .doc-item > summary::-webkit-details-marker { display:none; }
  .doc-title { font-size:13px; font-weight:700; color:var(--text); }
  .doc-hint { font-size:10px; font-weight:400; color:#9ca3af; }
  .doc-snippet { font-size:12px; color:var(--muted); line-height:1.5; margin-top:4px; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
  .doc-item[open] .doc-snippet { display:none; }
  .doc-item[open] .doc-hint::after { content:' (collapse)'; }
  .doc-full { font-size:12px; color:var(--text); line-height:1.6; margin-top:8px; max-height:340px; overflow:auto; white-space:pre-wrap; word-break:break-word; border-top:1px solid #f3f4f6; padding-top:8px; }
  .doc-empty { background:#fff; border:1px dashed var(--border); border-radius:10px; padding:10px 14px; font-size:12px; color:var(--muted); }
  .fb-bar { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin:2px 16px 14px 16px; padding-top:10px; border-top:1px dashed var(--border); }
  .fb-q { font-size:12px; color:var(--muted); }
  .fb-btn { font-size:12px; font-weight:600; text-decoration:none; border:1px solid var(--border); border-radius:8px; padding:5px 11px; color:var(--text); background:#fff; }
  .fb-btn:hover { border-color:#cbd5e1; background:#f8fafc; }
  .fb-up.voted { background:#ecfdf5; border-color:#86efac; color:#15803d; }
  .fb-down.voted { background:#fef2f2; border-color:#fca5a5; color:#b91c1c; }
  .fb-n { font-weight:800; margin-left:4px; }
  .doc-search { display:flex; gap:8px; margin:10px 12px 0 12px; }
  .doc-search input { flex:1; min-width:0; border:1px solid var(--border); border-radius:10px; padding:9px 12px; font-size:13px; font-family:inherit; color:var(--text); background:#fff; }
  .doc-search input:focus { outline:none; border-color:var(--green); box-shadow:0 0 0 3px rgba(11,122,67,0.12); }
  .doc-search button { border:none; background:var(--green); color:#fff; font-weight:600; font-size:13px; border-radius:10px; padding:9px 16px; cursor:pointer; white-space:nowrap; }
  .doc-search button:hover { opacity:0.92; }
  .doc-search button:disabled { opacity:0.6; cursor:default; }
  @media (max-width:520px){ .doc-search { flex-wrap:wrap; } .doc-search button { flex:1 1 auto; } }
`;

function documentationHtml(docContext: any, hasQuery: boolean): string {
  // Documentation only appears when the user typed a query; otherwise it stays hidden.
  if (!hasQuery) { return ''; }
  const results: any[] = Array.isArray(docContext?.results) ? docContext.results : [];
  if (results.length === 0) {
    return `
      <div class="section-label">Related documentation</div>
      <div class="doc-empty">No documentation matched your query for this project. Try different keywords, or upload the relevant document.</div>`;
  }
  const items = results.slice(0, 6).map((d: any) => {
    const fileName = esc(String(d?.file_name || d?.title || 'Document'));
    const full = String(d?.document || d?.preview || '').replace(/\s+/g, ' ').trim();
    const shortPrev = esc(full.slice(0, 200));
    const more = full.length > 200 ? '…' : '';
    return `
      <details class="doc-item">
        <summary>
          <div class="doc-title">📚 ${fileName} <span class="doc-hint">— click to expand</span></div>
          ${full ? `<div class="doc-snippet">${shortPrev}${more}</div>` : ''}
        </summary>
        ${full ? `<div class="doc-full">${esc(full)}</div>` : ''}
      </details>`;
  }).join('');
  return `
    <div class="section-label">Related documentation</div>
    <div class="doc-list">${items}</div>`;
}

function diffHtml(changes: any[]): string {
  if (!Array.isArray(changes) || changes.length === 0) { return '<pre class="diff"> </pre>'; }
  const lines: string[] = [];
  for (const change of changes) {
    for (const raw of String(change || '').replace(/\r\n/g, '\n').split('\n')) {
      const t = raw.trim();
      let cls = '';
      if (t.startsWith('[+]') || t.startsWith('+')) { cls = 'add'; }
      else if (t.startsWith('[MOD]')) { cls = 'mod'; }
      else if (t.startsWith('[-]') || t.startsWith('-')) { cls = 'del'; }
      lines.push(cls ? `<span class="${cls}">${esc(raw)}</span>` : esc(raw));
    }
  }
  return `<pre class="diff">${lines.join('\n')}</pre>`;
}

function confidenceBadge(confidence: string): string {
  const c = String(confidence || '').trim().toLowerCase();
  if (c === 'high') { return '<span class="badge badge-high">confidence: high</span>'; }
  if (c === 'medium') { return '<span class="badge badge-medium">confidence: medium</span>'; }
  if (c === 'low') { return '<span class="badge badge-low">confidence: low</span>'; }
  return '';
}

function solutionFilesHtml(solution: any[]): string {
  if (!Array.isArray(solution) || solution.length === 0) { return ''; }
  return solution.map((file: any) => {
    const fileName = esc(String(file?.fileName || 'Unknown file'));
    const filePath = esc(String(file?.filePath || '').trim());
    const changes = Array.isArray(file?.changes) ? file.changes : [];
    return `
      <div class="detail-block">
        <div class="file-name">📄 ${fileName}</div>
        ${filePath ? `<div class="file-path">${filePath}</div>` : ''}
        ${diffHtml(changes)}
      </div>`;
  }).join('');
}

function feedbackBarHtml(rec: any): string {
  const reqId = String(rec?.request_id || '').trim();
  if (!reqId) { return ''; }
  const up = Number(rec?.thumbs_up) || 0;
  const down = Number(rec?.thumbs_down) || 0;
  const voted = String(rec?._feedback || '');
  const uri = (helpful: boolean) =>
    `command:gradleErrorAssistant.recommendationFeedback?${encodeURIComponent(JSON.stringify([reqId, helpful]))}`;
  const upCls = voted === 'helpful' ? 'fb-btn fb-up voted' : 'fb-btn fb-up';
  const downCls = voted === 'not_helpful' ? 'fb-btn fb-down voted' : 'fb-btn fb-down';
  // Cumulative counts shown right beside each button (the social proof other devs see).
  return `
    <div class="fb-bar">
      <span class="fb-q">Was this helpful?</span>
      <a class="${upCls}" href="${uri(true)}">👍 Helpful <b class="fb-n">${up}</b></a>
      <a class="${downCls}" href="${uri(false)}">👎 Not helpful <b class="fb-n">${down}</b></a>
    </div>`;
}

function recommendationCardHtml(rec: any, title: string, recommended: boolean): string {
  const compareLink = String(rec?.compare_diff_link || '').trim();
  const confidence = String(rec?.selection_confidence || '').trim();
  const createdDate = formatRecommendationCreatedDate(rec?.created_date);
  const why = String(rec?.why_this_fix || '').trim();
  // Developer's own description of how they solved it (entered at upload time).
  const devNote = String(rec?.resolution_description || '').trim();
  // Honest relevance cues when there is no confident LLM pick: a "possible match" (rely-on-data,
  // low relevance) or the "closest available match" tag for the top candidate.
  const weak = rec?.is_weak_match === true;
  const closest = rec?.is_closest_match === true && !recommended;
  const relevanceNote = weak
    ? '⚠ Possible match — low relevance. Based on the closest available data; verify before applying.'
    : (closest ? 'Closest available match (no high-confidence pick).' : '');
  const solution = Array.isArray(rec?.solution) ? rec.solution : [];
  return `
    <div class="card ${recommended ? 'recommended' : ''}">
      <div class="card-header">
        <span class="card-title">${recommended ? '✅ Recommended Fix · Candidate 1' : esc(title)}</span>
        ${recommended ? confidenceBadge(confidence) : ''}
      </div>
      ${createdDate ? `<div class="card-meta">Created: ${esc(createdDate)}</div>` : ''}
      ${relevanceNote ? `<div class="relevance-note">${esc(relevanceNote)}</div>` : ''}
      ${recommended && why ? `<div class="why">${esc(why)}</div>` : ''}
      ${devNote ? `<div class="dev-note"><span class="dev-note-label">📝 Developer's note</span>${esc(devNote)}</div>` : ''}
      ${solutionFilesHtml(solution)}
      ${compareLink ? `<a class="compare" href="${esc(compareLink)}">🔗 Compare diff</a>` : ''}
      ${feedbackBarHtml(rec)}
    </div>`;
}

function recoNonce(): string {
  let text = '';
  const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < 32; i++) { text += possible.charAt(Math.floor(Math.random() * possible.length)); }
  return text;
}

function formatRecommendationCreatedDate(raw: unknown): string {
  const value = String(raw || '').trim();
  if (!value) {
    return '';
  }

  const date = new Date(value);
  if (!Number.isNaN(date.getTime())) {
    return date.toLocaleString();
  }

  return value;
}

function baseScopeHtml(body: string): string {
  const nonce = recoNonce();
  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>
          :root { --green:#0b7a43; --green-soft:#e8f5ef; --border:#e5e7eb; --muted:#6b7280; --text:#1f2937; --bg:#f3f4f6; }
          * { box-sizing:border-box; margin:0; padding:0; }
          html,body { font-family:"Segoe UI",Tahoma,sans-serif; color:var(--text); background:var(--bg); }
          .shell { max-width:980px; margin:0 auto; padding:12px; display:flex; flex-direction:column; gap:12px; }
          .card { background:#fff; border:1px solid var(--border); border-radius:12px; padding:14px 16px; }
          .head { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; }
          .title { color:var(--green); font-size:34px; font-weight:700; letter-spacing:-.01em; }
          .sub { margin-top:4px; color:var(--muted); font-size:12px; }
          .badge { border:1px solid #fecaca; color:#dc2626; background:#fff1f2; border-radius:999px; padding:6px 10px; font-size:11px; font-weight:700; white-space:nowrap; }
          .section-title { font-size:18px; font-weight:700; margin-bottom:8px; }
          .error-card { margin-bottom:12px; }
          .error-top { display:flex; align-items:flex-start; justify-content:space-between; gap:10px; margin-bottom:8px; }
          .error-k { font-size:11px; font-weight:700; color:#475569; letter-spacing:.06em; text-transform:uppercase; }
          .error-task { font-size:28px; font-weight:700; line-height:1.2; color:#0f172a; }
          .error-when { font-size:11px; color:#64748b; white-space:nowrap; }
          .error-details { border:1px solid #cbd5e1; border-radius:8px; background:#fff; overflow:hidden; }
          .error-summary { list-style:none; cursor:pointer; padding:10px; user-select:none; }
          .error-summary::-webkit-details-marker { display:none; }
          .error-msg-label { font-size:11px; font-weight:700; color:#475569; letter-spacing:.06em; text-transform:uppercase; margin-bottom:6px; }
          .error-msg-preview,
          .error-msg-full {
            background:#111827; border-radius:8px; padding:10px 12px; color:#f8fafc;
            font-family:Consolas,"Courier New",monospace; font-size:12px; line-height:1.45;
            white-space:pre-wrap; word-break:break-word;
          }
          .error-msg-preview {
            display:-webkit-box;
            -webkit-line-clamp:4;
            -webkit-box-orient:vertical;
            overflow:hidden;
          }
          .error-details[open] .error-msg-preview { display:none; }
          .error-summary-row { margin-top:8px; display:flex; align-items:center; justify-content:space-between; gap:8px; color:#64748b; }
          .error-expand-text { font-size:11px; }
          .error-chevron { font-size:12px; transition:transform .18s ease; }
          .error-details[open] .error-chevron { transform:rotate(180deg); }
          .error-msg-full-wrap { padding:0 10px 10px 10px; }
          .scope-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:12px; }
          .scope-item { border:1px solid var(--border); border-radius:10px; padding:12px; cursor:pointer; user-select:none; }
          .scope-item.active { border-color:#8dd8b0; background:var(--green-soft); }
          .scope-item .name { font-size:14px; font-weight:700; margin-bottom:6px; display:flex; gap:8px; align-items:center; }
          .scope-item .desc { font-size:12px; color:var(--muted); line-height:1.5; }
          .radio { width:14px; height:14px; border-radius:50%; border:2px solid #cbd5e1; display:inline-block; position:relative; }
          .scope-item.active .radio { border-color:var(--green); }
          .scope-item.active .radio::after { content:''; position:absolute; width:6px; height:6px; border-radius:50%; background:var(--green); top:2px; left:2px; }
          .start-btn { width:100%; margin-top:12px; border:none; border-radius:8px; background:var(--green); color:#fff; padding:10px 14px; font-size:15px; font-weight:700; cursor:pointer; }
          .start-btn:hover { opacity:.94; }
          .flow-top { display:flex; align-items:flex-start; gap:10px; }
          .spinner { width:20px; height:20px; border:3px solid #d1fae5; border-top-color:var(--green); border-radius:50%; animation:spin .8s linear infinite; margin-top:2px; }
          .loading-title { font-size:30px; font-weight:700; letter-spacing:-.01em; color:#0f172a; }
          .loading-sub { margin-top:3px; font-size:13px; color:var(--muted); }
          .progress-track { margin-top:14px; height:4px; background:#e5e7eb; border-radius:999px; overflow:hidden; }
          .progress-fill { height:100%; width:12%; background:linear-gradient(90deg,#0b7a43 0%,#10b981 100%); border-radius:999px; transition:width .65s ease; }
          .progress-fill.pulse { animation:progressPulse 1.4s ease-in-out infinite; }
          .timeline { margin-top:14px; display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:8px; }
          .step { text-align:center; }
          .num { width:22px; height:22px; border-radius:50%; margin:0 auto 6px auto; font-size:12px; font-weight:700; display:flex; align-items:center; justify-content:center; border:1px solid #d1d5db; color:#9ca3af; }
          .step.active .num { background:var(--green); border-color:var(--green); color:#fff; }
          .step.done .num { background:#e8f5ef; border-color:#8dd8b0; color:var(--green); }
          .step .label { font-size:11px; color:#9ca3af; font-weight:600; }
          .step.active .label, .step.done .label { color:var(--green); }
          .task-list { margin-top:14px; border-top:1px solid #f1f5f9; padding-top:10px; display:flex; flex-direction:column; gap:8px; }
          .task { font-size:13px; color:#334155; display:flex; align-items:center; gap:8px; }
          .task.ok::before { content:'✓'; color:var(--green); font-weight:700; }
          .task.now::before { content:'○'; color:#94a3b8; font-weight:700; }
          .task.wait::before { content:'○'; color:#cbd5e1; font-weight:700; }
          .task.wait { color:#94a3b8; }
          .cancel { margin-top:12px; width:100%; border:1px solid var(--border); border-radius:8px; background:#fff; padding:8px 10px; font-size:13px; cursor:pointer; }
          @keyframes spin { to { transform:rotate(360deg); } }
          @keyframes progressPulse {
            0% { opacity:1; }
            50% { opacity:.72; }
            100% { opacity:1; }
          }
          @media (max-width:760px) {
            .title { font-size:26px; }
            .loading-title { font-size:24px; }
            .scope-grid { grid-template-columns:1fr; }
          }
        </style>
      </head>
      <body>
        <div class="shell">${body}</div>
        <script nonce="${nonce}">
          (function () {
            const vscode = acquireVsCodeApi();
            const viewMode = String(document.body.getAttribute('data-view') || 'selection').toLowerCase();
            const scopeNodes = Array.from(document.querySelectorAll('[data-scope]'));
            let selected = (document.body.getAttribute('data-default-scope') || 'project').toLowerCase();
            function paint() {
              scopeNodes.forEach((node) => {
                const isActive = node.getAttribute('data-scope') === selected;
                node.classList.toggle('active', isActive);
              });
            }
            scopeNodes.forEach((node) => {
              node.addEventListener('click', function () {
                selected = String(node.getAttribute('data-scope') || 'project').toLowerCase();
                paint();
              });
            });
            paint();
            const startBtn = document.getElementById('start-reco');
            if (startBtn) {
              startBtn.addEventListener('click', function () {
                vscode.postMessage({ command: 'startRecommendation', scope: selected });
              });
            }
            const cancelBtn = document.getElementById('cancel-reco');
            if (cancelBtn) {
              cancelBtn.addEventListener('click', function () {
                vscode.postMessage({ command: 'cancelRecommendation' });
              });
            }

            if (viewMode === 'loading') {
              const progressEl = document.getElementById('flow-progress');
              const stepEls = Array.from(document.querySelectorAll('[data-step]'));
              const taskRead = document.getElementById('task-read');
              const taskLogs = document.getElementById('task-logs');
              const taskScope = document.getElementById('task-scope');
              const taskGen = document.getElementById('task-generate');

              function setTaskState(el, state) {
                if (!el) { return; }
                el.classList.remove('ok', 'now', 'wait');
                el.classList.add(state);
              }

              function updateStep(step) {
                stepEls.forEach((el) => {
                  const num = Number(el.getAttribute('data-step') || '0');
                  el.classList.remove('done', 'active');
                  if (num < step) {
                    el.classList.add('done');
                  } else if (num === step) {
                    el.classList.add('active');
                  }
                });
              }

              function updateFlow(step) {
                if (step === 1) {
                  updateStep(1);
                  if (progressEl) {
                    progressEl.style.width = '34%';
                    progressEl.classList.remove('pulse');
                  }
                  setTaskState(taskRead, 'ok');
                  setTaskState(taskLogs, 'now');
                  setTaskState(taskScope, 'wait');
                  setTaskState(taskGen, 'wait');
                } else if (step === 2) {
                  updateStep(2);
                  if (progressEl) {
                    progressEl.style.width = '66%';
                    progressEl.classList.remove('pulse');
                  }
                  setTaskState(taskRead, 'ok');
                  setTaskState(taskLogs, 'ok');
                  setTaskState(taskScope, 'now');
                  setTaskState(taskGen, 'wait');
                } else {
                  updateStep(3);
                  if (progressEl) {
                    progressEl.style.width = '92%';
                    progressEl.classList.add('pulse');
                  }
                  setTaskState(taskRead, 'ok');
                  setTaskState(taskLogs, 'ok');
                  setTaskState(taskScope, 'ok');
                  setTaskState(taskGen, 'now');
                }
              }

              updateFlow(1);
              setTimeout(function () { updateFlow(2); }, 850);
              setTimeout(function () { updateFlow(3); }, 1900);
            }
          })();
        </script>
      </body>
    </html>`;
}

function buildScopeSelectionWebviewHtml(selectedScope: RecommendationScope, launchContext?: RecommendationLaunchContext): string {
  const scope = normalizeScope(selectedScope);
  const launch = launchContext || latestLaunchContext;
  const projectName = esc(String(launch?.project_name || latestRecommendationPayload?.project_name || 'N/A'));
  const failedTask = esc(String(launch?.failed_task || '').trim());
  const rawError = String(launch?.error_message || '').trim();
  const errorMessage = esc(rawError);

  const errorBlock = launch?.has_error
    ? `
    <div class="card error-card">
      <div class="error-top">
        <div>
          <div class="error-k">Failed Task</div>
          <div class="error-task">${failedTask || 'Unknown task'}</div>
        </div>
        <div class="error-when">Current failure</div>
      </div>
      <details class="error-details">
        <summary class="error-summary">
          <div class="error-msg-label">Error Message</div>
          <div class="error-msg-preview">${errorMessage}</div>
          <div class="error-summary-row">
            <span class="error-expand-text">Show full error</span>
            <span class="error-chevron">▾</span>
          </div>
        </summary>
        <div class="error-msg-full-wrap">
          <div class="error-msg-full">${errorMessage}</div>
        </div>
      </details>
    </div>`
    : '';

  const body = `
    <div class="card">
      <div class="head">
        <div>
          <div class="title">AI Assisted Build — Error Resolution</div>
          <div class="sub">Project: ${projectName}</div>
        </div>
        <div class="badge">BUILD FAILED</div>
      </div>
    </div>
    ${errorBlock}
    <div class="card" data-default-scope="${scope}">
      <div class="section-title">Select Recommendation Scope</div>
      <div class="scope-grid">
        <div class="scope-item" data-scope="customer">
          <div class="name"><span class="radio"></span>Customer Scope</div>
          <div class="desc">Search customer-wide repositories, internal docs and previously validated fixes.</div>
        </div>
        <div class="scope-item" data-scope="project">
          <div class="name"><span class="radio"></span>Project Scope</div>
          <div class="desc">Prioritize solutions and build history from this project.</div>
        </div>
        <div class="scope-item" data-scope="global">
          <div class="name"><span class="radio"></span>Global Scope</div>
          <div class="desc">Search across all available solution knowledge sources.</div>
        </div>
      </div>
      <button id="start-reco" class="start-btn" type="button">Start Recommendation</button>
    </div>`;

  return baseScopeHtml(body).replace('<body>', `<body data-view="selection" data-default-scope="${scope}">`);
}

function buildRecommendationLoadingWebviewHtml(scope: RecommendationScope): string {
  const label = scopeLabel(scope);
  const body = `
    <div class="card">
      <div class="head">
        <div>
          <div class="title">AI Assisted Build — Error Resolution</div>
          <div class="sub">Scope: ${esc(label)}</div>
        </div>
        <div class="badge">BUILD FAILED</div>
      </div>
    </div>
    <div class="card">
      <div class="flow-top">
        <div class="spinner" aria-hidden="true"></div>
        <div>
          <div class="loading-title">Generating Recommendations...</div>
          <div class="loading-sub">${esc(scopeDescription(scope))}</div>
        </div>
      </div>
      <div class="progress-track"><div id="flow-progress" class="progress-fill"></div></div>
      <div class="timeline">
        <div class="step" data-step="1"><div class="num">1</div><div class="label">Collecting Context</div></div>
        <div class="step" data-step="2"><div class="num">2</div><div class="label">Searching Knowledge</div></div>
        <div class="step" data-step="3"><div class="num">3</div><div class="label">Generating Solutions</div></div>
      </div>
      <div class="task-list">
        <div class="task" id="task-read">Reading error details</div>
        <div class="task" id="task-logs">Collecting relevant logs and files</div>
        <div class="task" id="task-scope">Searching selected scope</div>
        <div class="task" id="task-generate">Generating recommendations</div>
      </div>
      <button id="cancel-reco" class="cancel" type="button">Cancel</button>
    </div>`;

  return baseScopeHtml(body).replace('<body>', '<body data-view="loading">');
}

function baseRecoHtml(projectName: string, query: string, body: string, searchValue: string): string {
  const nonce = recoNonce();
  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>${RECO_WEBVIEW_STYLES}</style>
      </head>
      <body>
        <div class="brand-header">
          <div class="brand-titles">
            <strong>AI Assisted Build — Fix Recommendation</strong>
            <span>Project: ${projectName || 'N/A'}${query ? ` · ${query}` : ''}</span>
          </div>
        </div>
        <div class="doc-search">
          <input id="doc-q" type="text" placeholder="Need more from the docs? Ask here — e.g. how to configure the interpreter path" value="${searchValue}" />
          <button id="doc-btn" type="button">Search docs</button>
        </div>
        <div class="page-content">${body}</div>
        <script nonce="${nonce}">
          (function () {
            const vscode = acquireVsCodeApi();
            const input = document.getElementById('doc-q');
            const btn = document.getElementById('doc-btn');
            function submit() {
              const q = (input.value || '').trim();
              if (!q) { input.focus(); return; }
              btn.disabled = true; btn.textContent = 'Searching…';
              vscode.postMessage({ command: 'docSearch', query: q });
            }
            btn.addEventListener('click', submit);
            input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { submit(); } });
          })();
        </script>
      </body>
    </html>`;
}

function buildRecommendationWebviewHtml(payload: any): string {
  const projectName = esc(String(payload?.project_name || 'N/A'));
  const enrichment = payload?.context_enrichment || {};
  const query = esc(String(enrichment?.copilot_query || enrichment?.query || '').replace(/\s+/g, ' ').trim().slice(0, 90));
  // Pre-fill the in-panel search box with whatever the user last typed, so it persists across
  // a search re-render (esc makes it safe inside the value="" attribute).
  const searchValue = esc(String(payload?.query_text || ''));
  const llmAnalysis = String(payload?.llm_analysis || '').trim();
  const selection = payload?.llm_selection || {};
  const hasQuery = String(payload?.query_text || '').trim().length > 0;
  const recommendations: any[] = Array.isArray(payload?.recommendations)
    ? payload.recommendations
    : (Array.isArray(payload?.result) ? payload.result : []);

  // When the server omitted the AI analysis (LLM slow/down/rate-limited/disabled), it tells
  // us WHY via llm_analysis_status/message. Surface that as a clear notice so a missing
  // analysis never looks like a bug to the developer.
  const analysisStatus = String(payload?.llm_analysis_status || 'ok').trim().toLowerCase();
  const analysisNotice = String(payload?.llm_analysis_message || '').trim()
    || ({
      timeout: 'AI analysis is temporarily unavailable — the language model did not respond in time '
        + '(it may be busy or rate-limited, or the network/auth to the AI service is slow). '
        + 'The matched fixes below are still valid — try again in a moment.',
      error: 'AI analysis is temporarily unavailable — the language-model request failed '
        + '(please check the AI service network and credentials). The matched fixes below are still valid.',
      disabled: 'AI analysis is turned off in this environment. The matched fixes below are based on historical matches.',
    } as Record<string, string>)[analysisStatus] || '';
  const analysisDegraded = !llmAnalysis && analysisStatus !== 'ok' && analysisNotice.length > 0;
  const analysisNoticeHtml = analysisDegraded
    ? `<div class="verdict verdict-medium">
         <div class="verdict-icon">${analysisStatus === 'timeout' ? '⏳' : analysisStatus === 'disabled' ? 'ℹ️' : '⚠️'}</div>
         <div><div class="verdict-title">AI analysis unavailable</div><div class="verdict-desc">${esc(analysisNotice)}</div></div>
       </div>`
    : '';

  // Hard error (no report.html, backend unreachable, etc.) — show the cause clearly.
  if (payload?.status === 'error') {
    const msg = esc(String(payload?.error || payload?.display_markdown || 'Could not generate a recommendation right now.'));
    return baseRecoHtml(projectName, query, `
      <div class="verdict verdict-medium">
        <div class="verdict-icon">⚠️</div>
        <div><div class="verdict-title">Couldn't get a recommendation</div><div class="verdict-desc">${msg}</div></div>
      </div>
      ${documentationHtml(payload?.document_context, hasQuery)}`, searchValue);
  }

  // No match found — a reassuring message, distinct from an error.
  if (!llmAnalysis && recommendations.length === 0) {
    return baseRecoHtml(projectName, query, `
      <div class="verdict verdict-medium">
        <div class="verdict-icon">🔍</div>
        <div><div class="verdict-title">No matching fix found yet</div>
        <div class="verdict-desc">No historical fix matched this build error for project <b>${projectName}</b>. Once a similar failure is fixed and learned, it will appear here.</div></div>
      </div>
      ${analysisNoticeHtml}
      ${documentationHtml(payload?.document_context, hasQuery)}`, searchValue);
  }

  // Prefer the fuller LLM analysis (it carries the root cause AND the summary of alternative
  // resolutions, e.g. the version spread) over the one-line root_cause, so the developer sees
  // the options under the promoted Candidate 1.
  const rootCause = llmAnalysis || String(selection?.root_cause || '').trim();
  const chosenId = String(selection?.chosen_request_id || '').trim();

  // Split chosen (recommended) vs the rest, preserving order.
  const recommended = recommendations.find(
    (r: any) => r?.is_recommended === true || (chosenId && String(r?.request_id || '').trim() === chosenId)
  );
  // Show the TOP 3 solutions only. When the LLM picked a fix it is Candidate 1
  // (recommended) and the next best two follow as Candidate 2 and 3. When there is
  // no LLM pick, the closest-ranked matches show as Candidate 1, 2, 3 in order.
  const TOP_N = 3;
  const others = recommendations
    .filter((r: any) => r !== recommended)
    .slice(0, recommended ? TOP_N - 1 : TOP_N);

  const parts: string[] = [];

  // Lead with the "why analysis is missing" notice when the LLM was unavailable, so the
  // developer understands the matched fixes are still valid and it isn't a failure.
  if (analysisNoticeHtml) { parts.push(analysisNoticeHtml); }

  // Several DIFFERENT fixes are supported equally well: the order between them is a tie-break,
  // so say so instead of presenting Candidate 1 as the answer.
  const decision = payload?.decision || {};
  if (decision?.ambiguous === true) {
    const tied = Array.isArray(decision?.tied_request_ids) ? decision.tied_request_ids.length : 2;
    parts.push(`
      <div class="verdict verdict-medium">
        <div class="verdict-icon">⚖️</div>
        <div><div class="verdict-title">${tied} fixes match equally well</div>
        <div class="verdict-desc">${esc(String(decision?.reason || 'Compare the candidates below before applying one.'))}</div></div>
      </div>`);
  }

  if (rootCause) {
    parts.push(`
      <div class="verdict">
        <div class="verdict-icon">🧭</div>
        <div><div class="verdict-title">Root Cause &amp; Fix</div><div class="verdict-desc">${esc(rootCause)}</div></div>
      </div>`);
  }

  if (recommended) {
    parts.push(`<div class="section-label">Recommended solution</div>`);
    parts.push(recommendationCardHtml(recommended, 'Recommended Fix', true)); // Candidate 1
    if (others.length > 0) {
      parts.push(`<div class="section-label">Other candidate fixes (ranked)</div>`);
      others.forEach((rec: any, i: number) => {
        parts.push(recommendationCardHtml(rec, `Candidate ${i + 2}`, false)); // Candidate 2, 3
      });
    }
  } else if (others.length > 0) {
    // No LLM pick — show the closest matches as Candidate 1, 2, 3 (rank order).
    parts.push(`<div class="section-label">Candidate fixes (ranked)</div>`);
    others.forEach((rec: any, i: number) => {
      parts.push(recommendationCardHtml(rec, `Candidate ${i + 1}`, false)); // Candidate 1, 2, 3
    });
  }

  // Documentation last, after the top-3 solutions.
  parts.push(documentationHtml(payload?.document_context, hasQuery));

  return baseRecoHtml(projectName, query, parts.join('\n'), searchValue);
}

