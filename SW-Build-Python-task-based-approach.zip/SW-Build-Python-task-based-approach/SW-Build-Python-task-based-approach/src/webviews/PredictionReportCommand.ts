import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { Logger } from '../utils/Logger';
import { FileWatcher } from '../watchers/FileWatcher';
import { FileUtils } from '../utils/FileUtils';

let getActiveFileWatcher: () => FileWatcher | undefined = () => undefined;
let predictionReportPanel: vscode.WebviewPanel | undefined;
let latestPredictionReport: any = null;
let latestPredictionFilePaths: string[] = [];
let latestPredictionSelectionItems: string[] = [];
let pendingPredictionSelectionRestore: string[] = [];
let predictReportInFlight = false;

type WorkspaceTreeNode = {
  name: string;
  uri: string;
  isDir: boolean;
};

const selectionCache = new Map<string, WorkspaceTreeNode[]>();
const selectedWorkspaceItems = new Set<string>();

const PHASE2_EXCLUDED_NAMES = new Set([
  'node_modules', '.git', '.vscode', '.ds_store',
  'build', '_td5', '.venv', '.github', '.gradle', '.idea',
  'dist', 'out', 'bin'
]);

const PHASE2_EXCLUDED_EXTENSIONS = new Set(['.log']);

const PHASE2_EXCLUDED_FILENAMES = new Set([
  '.gitignore', '.gitattributes', '.editorconfig',
  'gradlew', 'gradlew.bat', 'gradle.properties',
  '.env', '.npmrc', '.yarnrc'
]);

export function registerPredictionReportCommand(
  context: vscode.ExtensionContext,
  fileWatcherProvider: () => FileWatcher | undefined
): void {
  getActiveFileWatcher = fileWatcherProvider;

  const generateReportCmd = vscode.commands.registerCommand(
    'gradleErrorAssistant.generateBuildFailureRiskReport',
    async () => {
      try {
        const initialSelections = [...pendingPredictionSelectionRestore];
        pendingPredictionSelectionRestore = [];
        await openPredictionSelectionPanel(initialSelections);
      } catch (err: any) {
        Logger.log('[ReportUI] Report generation failed', err);
        vscode.window.showErrorMessage(`Failed to generate build failure risk report: ${err?.message || String(err)}`);
      }
    }
  );

  context.subscriptions.push(generateReportCmd);
}

export function disposePredictionReportWebviewState(): void {
  predictionReportPanel?.dispose();
  predictionReportPanel = undefined;
  latestPredictionReport = null;
  latestPredictionFilePaths = [];
  latestPredictionSelectionItems = [];
  pendingPredictionSelectionRestore = [];
  selectionCache.clear();
  selectedWorkspaceItems.clear();
  predictReportInFlight = false;
}

async function openPredictionSelectionPanel(initialSelections: string[] = []) {
  const activeFileWatcher = getActiveFileWatcher();
  if (!activeFileWatcher) {
    vscode.window.showErrorMessage('Build watcher not initialized.');
    return;
  }
  const selectionPanel = vscode.window.createWebviewPanel(
    'buildFailureRiskScope',
    'Build Failure Risk Scope',
    vscode.ViewColumn.One,
    { enableScripts: true, retainContextWhenHidden: true }
  );
  let predictInFlight = false;

  selectedWorkspaceItems.clear();
  for (const uri of initialSelections) {
    if (FileUtils.parseWorkspaceFileUri(uri)) { selectedWorkspaceItems.add(uri); }
  }
  selectionCache.clear();
  selectionPanel.webview.html = getSelectionWebviewHtml(selectionPanel.webview);
  await sendSelectionRoots(selectionPanel);
  if (initialSelections.length > 0) {
    await selectionPanel.webview.postMessage({
      type: 'restoreSelection',
      uris: initialSelections,
      label: `Previous selection restored (${initialSelections.length} item${initialSelections.length === 1 ? '' : 's'}). Add more files or folders as needed.`
    });
  }

  selectionPanel.webview.onDidReceiveMessage(async (msg: any) => {
    try {
      if (!msg || typeof msg !== 'object') { return; }

      if (msg.type === 'getRoots') {
        await sendSelectionRoots(selectionPanel);
        if (initialSelections.length > 0) {
          await selectionPanel.webview.postMessage({ type: 'restoreSelection', uris: initialSelections });
        }
        return;
      }

      if (msg.type === 'readDir') {
        const dirUri = FileUtils.parseWorkspaceFileUri(String(msg.uri || ''));
        if (!dirUri) { return; }
        const children = await readDirectoryFast(dirUri);
        await selectionPanel.webview.postMessage({
          type: 'dir',
          uri: msg.uri,
          children
        });
        if (initialSelections.length > 0) {
          await selectionPanel.webview.postMessage({ type: 'restoreSelection', uris: initialSelections });
        }
        return;
      }

      if (msg.type === 'open') {
        const uri = FileUtils.parseWorkspaceFileUri(String(msg.uri || ''));
        if (uri) {
          await vscode.commands.executeCommand('vscode.open', uri);
        }
        return;
      }

      if (msg.type === 'checked') {
        const uri = String(msg.uri || '');
        const checked = !!msg.checked;
        if (!FileUtils.parseWorkspaceFileUri(uri)) { return; }
        if (checked) {
          selectedWorkspaceItems.add(uri);
        } else {
          selectedWorkspaceItems.delete(uri);
        }
        return;
      }

      if (msg.type === 'refresh') {
        selectedWorkspaceItems.clear();
        selectionCache.clear();
        for (const uri of initialSelections) {
          if (FileUtils.parseWorkspaceFileUri(uri)) { selectedWorkspaceItems.add(uri); }
        }
        await sendSelectionRoots(selectionPanel);
        if (initialSelections.length > 0) {
          await selectionPanel.webview.postMessage({
            type: 'restoreSelection',
            uris: initialSelections,
            label: `Previous selection restored (${initialSelections.length} item${initialSelections.length === 1 ? '' : 's'}). Add more files or folders as needed.`
          });
        }
        return;
      }

      if (msg.type === 'selectCurrentFile') {
        const fileUri = getActiveEditorFileUri();
        if (!fileUri) {
          vscode.window.showWarningMessage('Open a file in the editor first.');
          return;
        }
        selectedWorkspaceItems.clear();
        selectedWorkspaceItems.add(fileUri.toString());
        await selectionPanel.webview.postMessage({
          type: 'selectionPreset',
          label: `Current file selected: ${path.basename(fileUri.fsPath)}`
        });
        return;
      }

      if (msg.type === 'selectCurrentFolder') {
        const folderUri = getActiveEditorFolderUri();
        if (!folderUri) {
          vscode.window.showWarningMessage('Open a file in the editor first.');
          return;
        }
        selectedWorkspaceItems.clear();
        selectedWorkspaceItems.add(folderUri.toString());
        await selectionPanel.webview.postMessage({
          type: 'selectionPreset',
          label: `Current folder selected: ${path.basename(folderUri.fsPath)}`
        });
        return;
      }

      if (msg.type === 'predict') {
        if (predictInFlight || predictReportInFlight) {
          void selectionPanel.webview.postMessage({ type: 'predictLoading', loading: true });
          return;
        }
        predictInFlight = true;
        predictReportInFlight = true;
        try {
          await selectionPanel.webview.postMessage({ type: 'predictLoading', loading: true });
          const report = await vscode.window.withProgress(
            {
              location: vscode.ProgressLocation.Notification,
              title: 'Generating Build Failure Risk Report',
              cancellable: false,
            },
            async (progress) => {
              progress.report({ message: 'Preparing selected files...' });
              const uris = Array.from(selectedWorkspaceItems)
                .map((u) => FileUtils.parseWorkspaceFileUri(u))
                .filter((uri): uri is vscode.Uri => !!uri);
              const filePaths = await collectSelectedFilePaths(uris);
              const uniqueFilePaths = Array.from(new Set(filePaths)).sort((a, b) => a.localeCompare(b));
              if (uniqueFilePaths.length === 0) {
                await selectionPanel.webview.postMessage({ type: 'predictLoading', loading: false });
                vscode.window.showWarningMessage('Select at least one file or folder from the workspace.');
                return null;
              }
              progress.report({ message: `Running prediction for ${uniqueFilePaths.length} file(s)...` });
              const builtReport = await activeFileWatcher.generateBuildFailureRiskReport(uniqueFilePaths);
              latestPredictionSelectionItems = Array.from(selectedWorkspaceItems);
              latestPredictionFilePaths = [...uniqueFilePaths];
              return builtReport;
            }
          );
          if (!report) { return; }

          await selectionPanel.webview.postMessage({ type: 'predictLoading', loading: false });
          selectionPanel.dispose();
          showPredictionReport(report);
        } finally {
          predictInFlight = false;
          predictReportInFlight = false;
        }
      }
    } catch (err: any) {
      Logger.log('[ReportScopeUI] Action failed', err);
      await selectionPanel.webview.postMessage({ type: 'predictLoading', loading: false });
      if (err?.code === 'EMBEDDING_UNAVAILABLE') {
        // Prediction stopped fail-closed because the embedding service is down. Per requirement,
        // surface it in the report webview (not just a toast) and close the file picker.
        try { selectionPanel.dispose(); } catch { /* already disposed */ }
        showPredictionUnavailable(err?.message);
        vscode.window.showWarningMessage(err?.message || 'Build prediction is currently unavailable.');
        return;
      }
      vscode.window.showErrorMessage(err?.message || String(err));
    }
  });
}

function buildReportFileName(report: any): string {
  const rawName = String(report?.project_name || '').trim();
  const safeName = rawName
    ? rawName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
    : 'build-failure-risk-report';

  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = now.toLocaleString('en-US', { month: 'short' });
  const year = now.getFullYear();

  let hours = now.getHours();
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12 || 12;

  return `${safeName}_${day}-${month}-${year}_${hours}.${minutes}_${ampm}`;
}

async function showPredictionReport(report: any) {
  if (!predictionReportPanel) {
    predictionReportPanel = vscode.window.createWebviewPanel(
      'buildFailureRiskReport',
      'Build Failure Risk Report',
      vscode.ViewColumn.One,
      { enableScripts: true, retainContextWhenHidden: true }
    );
    predictionReportPanel.webview.onDidReceiveMessage(async (msg: any) => {
      try {
        const currentReport = latestPredictionReport;
        if (!currentReport) { return; }
        if (!msg || typeof msg !== 'object') { return; }
        if (msg.type === 'saveJson') {
          const uri = await vscode.window.showSaveDialog({
            saveLabel: 'Save JSON Report',
            defaultUri: vscode.Uri.file(path.join(
              vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || '',
              `${buildReportFileName(currentReport)}.json`
            )),
            filters: { JSON: ['json'] },
          });
          if (!uri) { return; }
          await fs.promises.writeFile(uri.fsPath, JSON.stringify(currentReport, null, 2), 'utf8');
          vscode.window.showInformationMessage(`Saved report: ${uri.fsPath}`);
          return;
        }
        if (msg.type === 'saveHtml') {
          const uri = await vscode.window.showSaveDialog({
            saveLabel: 'Save HTML Report',
            defaultUri: vscode.Uri.file(path.join(
              vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || '',
              `${buildReportFileName(currentReport)}.html`
            )),
            filters: { HTML: ['html'] },
          });
          if (!uri) { return; }
          await fs.promises.writeFile(uri.fsPath, buildReportExportHtml(currentReport), 'utf8');
          vscode.window.showInformationMessage(`Saved report: ${uri.fsPath}`);
          return;
        }
        if (msg.type === 'regenerate') {
          const activeFileWatcher = getActiveFileWatcher();
          if (predictReportInFlight || !activeFileWatcher) {
            return;
          }
          if (!Array.isArray(latestPredictionFilePaths) || latestPredictionFilePaths.length === 0) {
            vscode.window.showWarningMessage('No previous file selection is available to regenerate.');
            return;
          }

          predictReportInFlight = true;
          try {
            predictionReportPanel?.webview.postMessage({ type: 'regenerateLoading', loading: true });
            const report = await vscode.window.withProgress(
              {
                location: vscode.ProgressLocation.Notification,
                title: 'Regenerating Build Failure Risk Report',
                cancellable: false,
              },
              async () => activeFileWatcher.generateBuildFailureRiskReport([...latestPredictionFilePaths])
            );
            latestPredictionReport = report;
            predictionReportPanel!.webview.html = buildReportWebviewHtml(report);
            predictionReportPanel!.reveal(vscode.ViewColumn.One);
          } catch (err: any) {
            Logger.log('[ReportUI] Regenerate action failed', err);
            if (err?.code === 'EMBEDDING_UNAVAILABLE') {
              showPredictionUnavailable(err?.message);
              vscode.window.showWarningMessage(err?.message || 'Build prediction is currently unavailable.');
            } else {
              vscode.window.showErrorMessage(err?.message || 'Failed to regenerate build failure risk report.');
            }
          } finally {
            predictReportInFlight = false;
            predictionReportPanel?.webview.postMessage({ type: 'regenerateLoading', loading: false });
          }
          return;
        }
        if (msg.type === 'changeScope') {
          const initialSelections = latestPredictionSelectionItems.length > 0
            ? [...latestPredictionSelectionItems]
            : latestPredictionFilePaths.map((filePath) => vscode.Uri.file(filePath).toString());
          pendingPredictionSelectionRestore = initialSelections;
          await vscode.commands.executeCommand('gradleErrorAssistant.generateBuildFailureRiskReport');
          return;
        }
        if (msg.type === 'openFile') {
          const rawPath = String(msg.path || '').trim();
          const line = Number(msg.line || 0);

          if (!rawPath || !FileUtils.isPathInsideAnyWorkspace(rawPath)) {
            return;
          }

          if (!fs.existsSync(rawPath)) {
            Logger.log(`[WebView Message] Cannot open file, path does not exist: ${rawPath}`);
            return;
          }

          try {
            const uri = vscode.Uri.file(rawPath);
            const doc = await vscode.workspace.openTextDocument(uri);
            const editor = await vscode.window.showTextDocument(doc, vscode.ViewColumn.One);

            if (line > 0) {
              const targetLine = Math.min(Math.max(line - 1, 0), Math.max(doc.lineCount - 1, 0));
              const pos = new vscode.Position(targetLine, 0);
              editor.selection = new vscode.Selection(pos, pos);
              editor.revealRange(new vscode.Range(pos, pos), vscode.TextEditorRevealType.InCenter);
            }
          } catch (error) {
            Logger.log(`[WebView Message] Failed to open document: ${rawPath}`, error);
          }
        }
      } catch (err) {
        Logger.log('[ReportUI] Action failed', err);
        vscode.window.showErrorMessage('Failed to process report action.');
      }
    });
    predictionReportPanel.onDidDispose(() => {
      predictionReportPanel = undefined;
      latestPredictionReport = null;
      latestPredictionFilePaths = [];
      latestPredictionSelectionItems = [];
    });
  }
  latestPredictionReport = report;
  predictionReportPanel.webview.html = buildReportWebviewHtml(report);
  predictionReportPanel.reveal(vscode.ViewColumn.One);
}

/** HTML for the "currently unavailable" state — shown when the embedding service is not reachable
 *  so no build risk could be computed. Fail-closed: the developer sees this instead of a silently
 *  degraded (exact-line-only) report. */
function buildUnavailableWebviewHtml(message: string): string {
  const safe = String(message || 'Build prediction is currently unavailable. Please try again later.')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline';">
        <style>
          body { font-family: var(--vscode-font-family, sans-serif); color: var(--vscode-foreground); background: var(--vscode-editor-background); display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; padding:24px; box-sizing:border-box; }
          .card { max-width:540px; text-align:center; border:1px solid var(--vscode-panel-border, #3c3c3c); border-radius:10px; padding:32px 28px; background: var(--vscode-editorWidget-background, rgba(255,255,255,0.03)); }
          .icon { font-size:44px; line-height:1; margin-bottom:14px; }
          .title { font-size:17px; font-weight:600; margin:0 0 10px; }
          .msg { font-size:13px; opacity:0.9; margin:0 0 16px; line-height:1.5; }
          .hint { font-size:12px; opacity:0.6; line-height:1.5; }
        </style>
      </head>
      <body>
        <div class="card">
          <div class="icon">&#9888;&#65039;</div>
          <p class="title">Build Prediction Currently Unavailable</p>
          <p class="msg">${safe}</p>
          <p class="hint">Build risk needs every stage to run (exact line + context above/below + cosine + dice), and that requires the embedding service. Nothing was silently skipped &mdash; re-run the Build Failure Risk Report once the service is back.</p>
        </div>
      </body>
    </html>`;
}

/** Show the "currently unavailable" message in the report webview (creating/reusing the panel). */
function showPredictionUnavailable(message?: string): void {
  if (!predictionReportPanel) {
    predictionReportPanel = vscode.window.createWebviewPanel(
      'buildFailureRiskReport',
      'Build Failure Risk Report',
      vscode.ViewColumn.One,
      { enableScripts: true, retainContextWhenHidden: true }
    );
    predictionReportPanel.onDidDispose(() => {
      predictionReportPanel = undefined;
      latestPredictionReport = null;
      latestPredictionFilePaths = [];
      latestPredictionSelectionItems = [];
    });
  }
  // This is not a real report — clear it so report-only actions stay inert.
  latestPredictionReport = null;
  predictionReportPanel.webview.html = buildUnavailableWebviewHtml(message || '');
  predictionReportPanel.reveal(vscode.ViewColumn.One);
}

async function sendSelectionRoots(panel: vscode.WebviewPanel) {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders || folders.length === 0) { return; }
  const roots: WorkspaceTreeNode[] = folders.map((wf) => ({
    name: wf.name,
    uri: wf.uri.toString(),
    isDir: true
  }));
  await panel.webview.postMessage({ type: 'roots', roots });
}

async function readDirectoryFast(dirUri: vscode.Uri): Promise<WorkspaceTreeNode[]> {
  if (!FileUtils.isWorkspaceFileUri(dirUri)) {
    return [];
  }

  const key = dirUri.toString();
  const cached = selectionCache.get(key);
  if (cached) { return cached; }

  const entries = await vscode.workspace.fs.readDirectory(dirUri);
  const children: WorkspaceTreeNode[] = entries.filter(([name, type]) => {
    const lower = String(name || '').toLowerCase();
    const isDir = (type & vscode.FileType.Directory) !== 0;

    if (PHASE2_EXCLUDED_NAMES.has(lower)) { return false; }
    if (!isDir && PHASE2_EXCLUDED_FILENAMES.has(lower)) { return false; }
    if (!isDir && PHASE2_EXCLUDED_EXTENSIONS.has(path.extname(lower))) { return false; }
    return true;
  })
    .map(([name, type]) => ({
      name,
      uri: vscode.Uri.joinPath(dirUri, name).toString(),
      isDir: (type & vscode.FileType.Directory) !== 0
    }))
    .sort((a, b) => {
      if (a.isDir !== b.isDir) { return a.isDir ? -1 : 1; }
      return a.name.localeCompare(b.name);
    });

  selectionCache.set(key, children);
  return children;
}

async function collectSelectedFilePaths(uris: vscode.Uri[]): Promise<string[]> {
  const results: string[] = [];
  const stack = [...uris];
  const visited = new Set<string>();

  while (stack.length > 0) {
    const current = stack.pop()!;
    const key = current.toString();
    if (visited.has(key)) {
      continue;
    }
    visited.add(key);

    try {
      if (!FileUtils.isWorkspaceFileUri(current)) {
        continue;
      }

      const stat = await vscode.workspace.fs.stat(current);
      if ((stat.type & vscode.FileType.Directory) !== 0) {
        const entries = await vscode.workspace.fs.readDirectory(current);
        for (const [name, type] of entries) {
          const lower = String(name || '').toLowerCase();
          const isDir = (type & vscode.FileType.Directory) !== 0;

          if (PHASE2_EXCLUDED_NAMES.has(lower)) { continue; }
          if (!isDir && PHASE2_EXCLUDED_FILENAMES.has(lower)) { continue; }
          if (!isDir && PHASE2_EXCLUDED_EXTENSIONS.has(path.extname(lower))) { continue; }
          stack.push(vscode.Uri.joinPath(current, name));
        }
      } else {
        if (FileUtils.isPathInsideAnyWorkspace(current.fsPath)) {
          results.push(current.fsPath);
        }
      }
    } catch (err) {
      Logger.log('[ReportScopeUI] Failed reading selected path', { path: current.fsPath, error: String(err) });
    }
  }

  return results;
}

function getActiveEditorFileUri(): vscode.Uri | null {
  const uri = vscode.window.activeTextEditor?.document?.uri;
  if (!uri || !FileUtils.isWorkspaceFileUri(uri)) { return null; }
  return uri;
}

function getActiveEditorFolderUri(): vscode.Uri | null {
  const fileUri = getActiveEditorFileUri();
  if (!fileUri) { return null; }
  return vscode.Uri.file(path.dirname(fileUri.fsPath));
}

function getSelectionWebviewHtml(webview: vscode.Webview): string {
  const nonce = getNonce();
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline' ${webview.cspSource}; script-src 'nonce-${nonce}';">
<title>Build Failure Risk Scope</title>
<style>
  :root { --green:#0b7a43; --border:#d7e6dc; --soft:#eef8f2; --text:#1f2937; --muted:#6b7280; }
  * { box-sizing:border-box; }

  html, body {
   height:100%;
   margin:0; 
   padding:0;
   font-family:"Segoe UI", Arial, sans-serif; 
   background:#fff; color:var(--text);
   overflow:hidden;
   }

  .container {
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    padding: 18px;
    gap: 14px;
  }

  .brand {
    flex-shrink: 0;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: linear-gradient(90deg, var(--soft), #fff);
    padding: 16px 18px;
  }
  .brand strong {
    display:block; 
    font-size:20px; 
    color:var(--green); 
   }

  .brand span { 
    color:var(--muted); 
    font-size:12px; 
  }

  .toolbar {
    flex-shrink: 0;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    padding: 14px 16px;
  }

  .toolbar .hint { 
    color:var(--muted); 
    font-size:12px; 
  }

  .actions { 
    display:flex; 
    gap:10px; 
  }

  button {
   border:none;
   border-radius:10px; 
   padding:10px 14px; 
   cursor:pointer; 
   font-size:13px; 
   font-weight:600;
   }

  .icon-btn { 
  width:42px; 
  height:42px; 
  padding:0; 
  background:#f3f4f6; 
  border:1px solid #e5e7eb; 
  }

  .btn-primary { 
  background:var(--green); 
  color:#fff; 
  }

  .panel {
    flex: 1;
    min-height: 0;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: #fff;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
    
  .panel-header {
    flex-shrink: 0;
    padding: 12px 14px;
    border-bottom: 1px solid var(--border);
    font-weight: 700;
    color: var(--green);
    background: #fcfffd;
    border-radius: 14px 14px 0 0;
  }

  .panel-body {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    padding: 10px;
  }

  #tree { 
    list-style:none; 
    padding:0; 
    margin:0; 
  }

  .node { 
    list-style:none; 
    margin:0; 
  }

  .row { 
    display:flex; 
    align-items:center; 
    gap:8px; 
    padding:8px 10px; 
    border-radius:10px; 
    cursor:pointer; 
    min-height:36px; 
  }

  .row:hover {
    background:#f5fbf7; 
   }

  .check {
    accent-color:var(--green); 
   }

  .twisty {
    width:14px; 
    flex:0 0 14px; 
    text-align:center; 
    color:var(--muted); 
   }

  .icon {
    width:18px; 
    flex:0 0 18px; 
    text-align:center; 
   }

  .name { 
   flex:1;
   min-width:0; 
   overflow:hidden; 
   text-overflow:ellipsis; 
   white-space:nowrap; 
  }

  .children { 
    display:none; 
    margin-left:24px; 
    padding-left:10px; 
    border-left:1px solid var(--border); 
  }

  .empty {
    padding:12px; 
    color:var(--muted); 
   }

  .overlay {
   position:fixed; 
   inset:0; 
   background:rgba(255,255,255,0.65); 
   display:none; 
   align-items:center; 
   justify-content:center; 
   z-index:10; 
   }

  .overlay.show {
    display:flex; 
   }

  .loader-box {
    background:#fff; 
    border:1px solid var(--border); 
    border-radius:12px; 
    padding:18px 22px; 
    display:flex; 
    align-items:center; 
    gap:12px; 
   }

  .spinner {
    width:20px; 
    height:20px; 
    border:3px solid #d8eee0; 
    border-top-color:var(--green); 
    border-radius:50%; 
    animation:spin .8s linear infinite; 
   }
  
  @keyframes spin { 
  to {
   transform:rotate(360deg); 
   }
  }
  
  .loading-placeholder { 
    display:flex; 
    align-items:center; 
    gap:8px; 
    color:var(--muted); 
    padding:8px 10px; 
    font-size:12px; 
  }
  
.mini-spinner { 
    width:12px; 
    height:12px; 
    border:2px solid #d8eee0; 
    border-top-color:var(--green); 
    border-radius:50%; 
    animation:spin .8s linear infinite; 
    flex-shrink:0; 
}

</style>
</head>
<body>
  <div class="overlay" id="overlay"><div class="loader-box"><div class="spinner"></div><div>Running build failure comparison...</div></div></div>
  <div class="container">
    <div class="brand">
      <strong>AI Assisted Build Failure Report</strong>
      <span>Select files or folders from the current workspace to compare against historical failure data.</span>
    </div>
    <div class="toolbar">
      <div class="hint">Selected scope only will be used for Phase 2 comparison stages.</div>
      <div class="actions">
        <button id="currentFileBtn" title="Use current file">Current File</button>
        <button id="currentFolderBtn" title="Use current folder">Current Folder</button>
        <button class="icon-btn" id="refreshBtn" title="Refresh">R</button>
        <button class="btn-primary" id="predictBtn">Generate Report</button>
      </div>
    </div>
    <div class="panel">
      <div class="panel-header">Workspace Tree</div>
      <div class="panel-body"><ul id="tree"></ul></div>
    </div>
  </div>
  <script nonce="${nonce}">
    const vscode = acquireVsCodeApi();
    const tree = document.getElementById('tree');
    const overlay = document.getElementById('overlay');
    const folderMap = new Map();
    const hint = document.querySelector('.toolbar .hint');
    const selectedUris = new Set();

    function escapeHtml(str) {
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    function createNode(node) {
      const li = document.createElement('li');
      li.className = 'node';
      li.dataset.uri = node.uri;
      li.dataset.dir = node.isDir ? '1' : '0';
      li.dataset.loaded = '0';
      const row = document.createElement('div');
      row.className = 'row';
      row.innerHTML =
        '<input type="checkbox" class="check">' +
        '<span class="twisty">' + (node.isDir ? '&gt;' : '') + '</span>' +
        '<span class="icon">' + (node.isDir ? '[D]' : '[F]') + '</span>' +
        '<span class="name" title="' + escapeHtml(node.name) + '">' + escapeHtml(node.name) + '</span>';
      li.appendChild(row);
      const check = row.querySelector('.check');
      if (selectedUris.has(node.uri)) {
        check.checked = true;
        check.indeterminate = false;
      }
      if (node.isDir) {
        const ul = document.createElement('ul');
        ul.className = 'children';
        const placeholder = document.createElement('li');
        placeholder.className = 'empty loading-placeholder';
        placeholder.innerHTML = '<span class="mini-spinner"></span> Loading...';
        ul.appendChild(placeholder);
        li.appendChild(ul);
        folderMap.set(node.uri, ul);
      }
      return li;
    }

    function renderList(container, items) {
      const frag = document.createDocumentFragment();
      for (const item of items) { frag.appendChild(createNode(item)); }
      container.appendChild(frag);
    }

    function applyRestoredSelection() {
      tree.querySelectorAll('.node').forEach((nodeEl) => {
        const uri = nodeEl.dataset.uri || '';
        const check = nodeEl.querySelector(':scope > .row .check');
        if (!check || !uri) { return; }
        if (selectedUris.has(uri)) {
          check.checked = true;
          check.indeterminate = false;
        }
      });
      tree.querySelectorAll('.children').forEach((ul) => {
        const parentLi = ul.parentElement;
        if (parentLi && parentLi.classList.contains('node')) {
          updateParentState(parentLi);
        }
      });
    }

    function updateParentState(li) {
      const parentUl = li.parentElement;
      if (!parentUl) { return; }
      if (!parentUl.classList.contains('children')) { return; }
      const parentLi = parentUl.parentElement;
      if (!parentLi || !parentLi.classList.contains('node')) { return; }

      const parentCheck = parentLi.querySelector(':scope > .row .check');
      if (!parentCheck) { return; }

      const directChildChecks = Array.from(parentUl.querySelectorAll(':scope > .node > .row .check'));
      if (directChildChecks.length === 0) { return; }

      const checkedCount = directChildChecks.filter(cb => cb.checked && !cb.indeterminate).length;
      const indeterminateCount = directChildChecks.filter(cb => cb.indeterminate).length;
      const totalCount = directChildChecks.length;

      if (checkedCount === 0 && indeterminateCount === 0) {
        parentCheck.checked = false;
        parentCheck.indeterminate = false;
        vscode.postMessage({ type: 'checked', uri: parentLi.dataset.uri, checked: false });
      } else if (checkedCount === totalCount && indeterminateCount === 0) {
        parentCheck.checked = true;
        parentCheck.indeterminate = false;
        vscode.postMessage({ type: 'checked', uri: parentLi.dataset.uri, checked: true });
      } else {
        parentCheck.checked = false;
        parentCheck.indeterminate = true;
        vscode.postMessage({ type: 'checked', uri: parentLi.dataset.uri, checked: false });
      }
      updateParentState(parentLi);
    }

    function setChildren(uri, children) {
      const ul = folderMap.get(uri);
      if (!ul) { return; }
      ul.textContent = '';
      if (!children || children.length === 0) {
        const empty = document.createElement('li');
        empty.className = 'empty';
        empty.textContent = 'Empty folder';
        ul.appendChild(empty);
        return;
      }
      renderList(ul, children);

      const parentLi = ul.parentElement;
      const parentCheck = parentLi ? parentLi.querySelector(':scope > .row .check') : null;
      if (parentCheck && parentCheck.checked) {
        ul.querySelectorAll('.check').forEach((cb) => {
          cb.checked = true;
          cb.indeterminate = false;
          const childLi = cb.closest('.node');
          if (childLi) {
            vscode.postMessage({ type: 'checked', uri: childLi.dataset.uri, checked: true });
          }
        });
      }
      if (parentLi) { updateParentState(parentLi); }
    }

    tree.addEventListener('click', (e) => {
      const target = e.target;
      const row = target.closest('.row');
      if (!row) { return; }
      const li = row.parentElement;
      const uri = li.dataset.uri;
      const isDir = li.dataset.dir === '1';

        if (target.classList.contains('check')) {
          const checked = target.checked;
          target.indeterminate = false;
          if (checked) { selectedUris.add(uri); } else { selectedUris.delete(uri); }
          vscode.postMessage({ type: 'checked', uri, checked });

          if (isDir) {
            li.querySelectorAll('.check').forEach((cb) => {
              cb.checked = checked;
              cb.indeterminate = false;
              const childLi = cb.closest('.node');
              if (childLi && childLi !== li) {
                if (checked) { selectedUris.add(childLi.dataset.uri); } else { selectedUris.delete(childLi.dataset.uri); }
                vscode.postMessage({ type: 'checked', uri: childLi.dataset.uri, checked });
              }
            });
        }
        updateParentState(li);
        return;
      }

      if (isDir) {
        const childrenUl = li.querySelector('.children');
        const twisty = li.querySelector('.twisty');
        const open = childrenUl.style.display !== 'block';
        childrenUl.style.display = open ? 'block' : 'none';
        twisty.textContent = open ? 'v' : '>';
        if (open && li.dataset.loaded === '0') {
          vscode.postMessage({ type: 'readDir', uri });
          li.dataset.loaded = '1';
        }
      } else {
        vscode.postMessage({ type: 'open', uri });
      }
    });

    document.getElementById('refreshBtn').addEventListener('click', () => vscode.postMessage({ type: 'refresh' }));
    document.getElementById('currentFileBtn').addEventListener('click', () => vscode.postMessage({ type: 'selectCurrentFile' }));
    document.getElementById('currentFolderBtn').addEventListener('click', () => vscode.postMessage({ type: 'selectCurrentFolder' }));
    document.getElementById('predictBtn').addEventListener('click', () => vscode.postMessage({ type: 'predict' }));

    window.addEventListener('message', (event) => {
      const msg = event.data;
      if (msg.type === 'roots') {
        tree.textContent = '';
        folderMap.clear();
        if (!msg.roots || msg.roots.length === 0) {
          const empty = document.createElement('li');
          empty.className = 'empty';
          empty.textContent = 'No workspace found';
          tree.appendChild(empty);
          return;
        }
        renderList(tree, msg.roots);
        applyRestoredSelection();
      }
      if (msg.type === 'dir') { setChildren(msg.uri, msg.children); }
      if (msg.type === 'predictLoading') { overlay.classList.toggle('show', !!msg.loading); }
      if (msg.type === 'selectionPreset' && hint) { hint.textContent = msg.label || 'Selected scope only will be used for Phase 2 comparison stages.'; }
      if (msg.type === 'restoreSelection') {
        selectedUris.clear();
        for (const uri of Array.isArray(msg.uris) ? msg.uris : []) {
          if (uri) { selectedUris.add(String(uri)); }
        }
        applyRestoredSelection();
        if (hint && msg.label) {
          hint.textContent = msg.label;
        }
      }
    });

    vscode.postMessage({ type: 'getRoots' });
  </script>
</body>
</html>`;
}

function getNonce(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from({ length: 32 }, () =>
    chars[Math.floor(Math.random() * chars.length)]
  ).join('');
}

function esc(input: string): string {
  return String(input || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function sanitizeExternalLink(raw: string): string {
  try {
    const parsed = new URL(String(raw || '').trim());
    return parsed.protocol === 'https:' ? parsed.toString() : '';
  } catch {
    return '';
  }
}

function toFiniteNumber(value: any): number | null {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }
  if (typeof value === 'string') {
    const cleaned = value.trim().replace(/[%,$\s]+/g, '');
    if (!cleaned) { return null; }
    const parsed = Number(cleaned);
    return Number.isFinite(parsed) ? parsed : null;
  }
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function pickFirstFiniteNumber(...values: any[]): number | null {
  for (const value of values) {
    const num = toFiniteNumber(value);
    if (num !== null) { return num; }
  }
  return null;
}

function normalizeRiskPercentage(value: any): number {
  const num = toFiniteNumber(value);
  if (num === null) { return 0; }
  const scaled = num >= 0 && num <= 1 ? num * 100 : num;
  return Math.max(0, Math.min(100, scaled));
}

function getReportSummary(report: any): any {
  return report?.summary && typeof report.summary === 'object' ? report.summary : {};
}

function buildIssueCards(report: any): string {
  const issues: any[] = Array.isArray(report?.issues) ? report.issues : [];
  const matchedRuleFilesCount = Number(report?.matched_rule_files_count || 0);
  if (!issues.length) {
    if (matchedRuleFilesCount > 0) {
      return `<div class="empty-state">&#9888; Historical failure patterns were found for ${matchedRuleFilesCount} changed file${matchedRuleFilesCount !== 1 ? 's' : ''} in the database, but no exact line-level match details are available for this report.</div>`;
    }
    return `<div class="empty-state">&#10003; No historical failure patterns matched in your changed files.</div>`;
  }

  return issues.map((row, idx) => {
    const fileName = esc(String(row?.file_name || 'Unknown file'));
    const filePath = esc(String(row?.file_path || ''));
    const lineFound = Number(row?.line_found || 0);
    const historyHits = Number(row?.historical_hits || 0);
    const riskScore = normalizeRiskPercentage(
      pickFirstFiniteNumber(
        row?.risk_score,
        row?.risk_score_percent,
        row?.score
      )
    );
    const lineText = esc(String(row?.line_text_found || '').trim());
    const whyMatched = esc(String(row?.why_matched || '').trim());
    const pattern = esc(String(row?.historical_pattern || '').trim());
    const link = sanitizeExternalLink(String(row?.view_diff_link || '').trim());
    const historicalError = esc(String(row?.error_message || '').trim());
    const solutionLine = esc(String(row?.solution_line || '').trim());
    const stage1 = Number(row?.stage1_score || 0);
    const stage2 = Number(row?.stage2_score || 0);
    const stage3 = Number(row?.stage3_score || 0);
    const stage4 = Number(row?.stage4_score || 0);
    const stage5 = Number(row?.stage5_score || 0);
    const absenceFound = row?.absence_found === true || row?.stage4_found === true || stage4 > 0;
    const relocatedFound = row?.relocated_found === true || row?.stage5_found === true || stage5 > 0;
    const dominantStage = Number(row?.dominant_stage || row?.stage || 0);
    const isAbsenceCard = absenceFound && (dominantStage === 4 || stage4 >= Math.max(stage1, stage2, stage3));

    // Risk badge + bar color
    const roundedRiskLabel = `${Math.round(riskScore)}%`;
    let badgeClass = 'badge-low', badgeLabel = 'LOW RISK', barColor = '#16a34a';
    if (riskScore >= 70) {
      badgeClass = 'badge-high'; badgeLabel = 'HIGH RISK'; barColor = '#dc2626';
    } else if (riskScore >= 30) {
      badgeClass = 'badge-medium'; badgeLabel = 'MEDIUM RISK'; barColor = '#d97706';
    }

    // History sentence
    const historySentence = historyHits > 0
      ? `This file caused build failures <strong>${historyHits}</strong> time${historyHits !== 1 ? 's' : ''} in the past.`
      : 'First match — no prior failures recorded yet.';

    // What will happen if not fixed — riskScore is 0-100
    let consequence = 'Review this file before building — it has a pattern matching past failures.';
    if (isAbsenceCard) {
      consequence = `${roundedRiskLabel} risk: this file is missing the exact line that a past fix added. Add it back at line ${lineFound > 0 ? lineFound : '?'} before building.`;
    } else if (relocatedFound) {
      consequence = `${roundedRiskLabel} risk: the exact line exists in this file, but it appears at a different location${lineFound > 0 ? ` (currently near line ${lineFound})` : ''}. Build may still fail if ordering or placement matters.`;
    } else if (riskScore >= 70) {
      consequence = 'High probability of build failure. Fix or review this file before triggering a build.';
    } else if (riskScore >= 30) {
      consequence = 'Moderate risk. If unchanged, this file may trigger the same failure again.';
    }

    const cardId = `card-${idx}`;

    return `
    <div class="issue-card ${badgeClass}-card" id="${cardId}">

      <!-- Card header -->
      <div class="card-header">
        <div class="card-title-row">
          <span class="card-icon">&#128196;</span>
          <span class="card-filename">${fileName}</span>
          <span class="badge ${badgeClass}">${badgeLabel}</span>
        </div>
        ${filePath ? `<div class="card-filepath">${filePath}${lineFound > 0 ? ` &nbsp;&#8250;&nbsp; Line ${lineFound}` : ''}</div>` : ''}
      </div>

      <!-- Risk bar -->
      <div class="risk-bar-row">
        <span class="risk-bar-label">Risk</span>
        <div class="risk-bar-track">
          <div class="risk-bar-fill" style="width:${riskScore.toFixed(1)}%; background:${barColor}"></div>
        </div>
        <span class="risk-bar-pct">${riskScore.toFixed(riskScore % 1 === 0 ? 0 : 1)}%</span>
      </div>

      <!-- Details grid -->
      <div class="detail-grid">

        <div class="detail-block">
          <div class="detail-label">&#128269; Why flagged</div>
          <div class="detail-value">${isAbsenceCard
        ? `100% risk: this file is missing the exact line that a past fix added. Adding it back resolved a previous build failure.`
        : (whyMatched || 'Historical comparison matched this file.')
      }</div>
        </div>

        ${isAbsenceCard && pattern ? `
        <div class="detail-block">
          <div class="detail-label">&#10060; Missing line</div>
          <div class="detail-code">${pattern}</div>
        </div>` : ''}

        ${!isAbsenceCard && lineText ? `
        <div class="detail-block">
          <div class="detail-label">&#128221; Code at matched line</div>
          <div class="detail-code">${lineText}</div>
        </div>` : ''}

          ${!isAbsenceCard && pattern ? `
          <div class="detail-block">
            <div class="detail-label">&#128200; Historical failure pattern</div>
            <div class="detail-code">${pattern}</div>
          </div>` : ''}

          ${historicalError ? `
          <div class="detail-block">
            <div class="detail-label">&#10060; Historical build error</div>
            <div class="detail-code">${historicalError}</div>
          </div>` : ''}

          ${solutionLine ? `
          <div class="detail-block">
            <div class="detail-label">&#128295; Historical fix line</div>
            <div class="detail-code">${solutionLine}</div>
          </div>` : ''}

          <div class="detail-block">
            <div class="detail-label">&#128202; Failure history</div>
            <div class="detail-value">${historySentence}</div>
          </div>

        <div class="detail-block consequence-block">
          <div class="detail-label">&#9888; What happens if you don't fix this</div>
          <div class="detail-value consequence-text">${consequence}</div>
        </div>

      </div>

      <!-- Actions -->
      <div class="card-actions">
        ${filePath ? `<button class="action-btn action-open" data-action="open-file" data-path="${filePath}" data-line="${lineFound > 0 ? lineFound : 0}">&#128065; Open in Editor</button>` : ''}
        ${link ? `<a class="action-btn action-diff" href="${esc(link)}" target="_blank">&#128203; View What Changed</a>` : ''}
      </div>

    </div>`;
  }).join('');
}

function buildReportBody(report: any): string {
  const summary = getReportSummary(report);
  const projectName = esc(String(report?.project_name || 'unknown-project'));
  const scanTime = esc(String(report?.scan_time || '').replace('T', ' ').replace('Z', ' UTC'));
  const selectedRelativeFiles: string[] = Array.isArray(report?.selected_relative_files) ? report.selected_relative_files : [];
  const issues: any[] = Array.isArray(report?.issues) ? report.issues : [];
  const filesScanned = Math.max(
    Number(report?.files_scanned || 0),
    Number(summary?.total_files_scanned || 0),
    selectedRelativeFiles.length
  );
  const matchesFound = Math.max(
    Number(report?.matches_found || 0),
    Number(summary?.total_matches || 0),
    issues.length
  );
  const averageRiskFromReport = pickFirstFiniteNumber(report?.average_risk_score, summary?.average_risk_score);
  const averageRiskScore = averageRiskFromReport !== null
    ? normalizeRiskPercentage(averageRiskFromReport)
    : (issues.length > 0
      ? Number((issues.reduce((sum, row) => {
        const score = normalizeRiskPercentage(
          pickFirstFiniteNumber(row?.risk_score, row?.risk_score_percent, row?.score)
        );
        return sum + score;
      }, 0) / issues.length).toFixed(2))
      : 0);

  const riskBuckets = issues.reduce((acc, row) => {
    const score = normalizeRiskPercentage(
      pickFirstFiniteNumber(row?.risk_score, row?.risk_score_percent, row?.score)
    );
    if (score >= 70) {
      acc.high += 1;
    } else if (score >= 30) {
      acc.medium += 1;
    } else {
      acc.low += 1;
    }
    return acc;
  }, { high: 0, medium: 0, low: 0 });

  // Risk verdict is driven solely by REAL matches.
  // No matches = no risk. Backend rule coverage alone is not enough.
  const hasMatches = report?.has_matches === true || matchesFound > 0 || issues.length > 0;

  // matchesFound counts risky LINES, not files — report both honestly (previously the banner said
  // "N of your changed files" using the line count, e.g. "238 changed files" from only 18 scanned).
  const distinctRiskFiles = new Set(
    issues.map((r: any) => String(r?.file_path || '')).filter((p: string) => p.length > 0)
  ).size;
  const lineWord = matchesFound === 1 ? 'line' : 'lines';
  const fileWord = distinctRiskFiles === 1 ? 'file' : 'files';

  // Overall verdict
  let verdictClass = 'verdict-ok';
  let verdictIcon = '&#10003;';
  let verdictTitle = 'Safe to build';
  let verdictDesc = 'No historical failure patterns matched in your code.';
  if (hasMatches) {
    if (averageRiskScore >= 70) {
      verdictClass = 'verdict-high';
      verdictIcon = '&#9888;';
      verdictTitle = 'High Risk';
      verdictDesc = `${matchesFound} risky ${lineWord} across ${distinctRiskFiles} ${fileWord} match patterns from past build failures. Review carefully before building.`;
    } else {
      verdictClass = 'verdict-medium';
      verdictIcon = '&#9888;';
      verdictTitle = 'Caution';
      verdictDesc = `${matchesFound} risky ${lineWord} across ${distinctRiskFiles} ${fileWord} have a failure history. Proceed with care.`;
    }
  }

  const issueCards = buildIssueCards(report);

  return `
    <div class="brand-header">
      <div class="brand-titles">
        <strong>Build Risk Check</strong>
        <span>${projectName} &bull; ${scanTime}</span>
      </div>
      <div class="page-header-actions">
        <button class="btn-secondary" data-action="change-scope">Add More Files</button>
        <button class="btn-secondary" data-action="regenerate">Regenerate</button>
        <button class="btn-secondary" data-action="save-json">Save JSON</button>
        <button class="btn-primary" data-action="save-html">Save HTML</button>
      </div>
    </div>

    <div class="page-content">

      <div class="verdict ${verdictClass}">
        <div class="verdict-icon">${verdictIcon}</div>
        <div>
          <div class="verdict-title">${verdictTitle}</div>
          <div class="verdict-desc">${verdictDesc}</div>
        </div>
      </div>

      <div class="stat-grid">
        <div class="stat-card">
          <div class="stat-label">Files Scanned</div>
          <div class="stat-value">${filesScanned}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Matches Found</div>
          <div class="stat-value">${matchesFound}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Average Risk</div>
          <div class="stat-value">${averageRiskScore.toFixed(1)}%</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Risk Counts (H / M / L)</div>
          <div class="stat-value">${riskBuckets.high} / ${riskBuckets.medium} / ${riskBuckets.low}</div>
        </div>
      </div>

      ${selectedRelativeFiles.length ? `
      <details class="file-scope-details">
        <summary class="section-label">TOTAL FILES SCANNED (${filesScanned || selectedRelativeFiles.length}) <span class="toggle-hint">click to expand</span></summary>
        <div class="file-scope">
          ${selectedRelativeFiles.map((f: string) => `<div class="scope-item">&#128196; ${esc(String(f || ''))}</div>`).join('')}
        </div>
      </details>` : ''}

        ${hasMatches ? `
        <div class="section-label">FAILURE HISTORY FOR YOUR CHANGED FILES (${(Array.isArray(report?.issues) ? report.issues : []).length})</div>
        <div class="issue-cards">${issueCards}</div>` : issueCards}

    </div>
  `;
}

function buildReportStyles(): string {
  return `
    :root {
      --green: #0b7a43;
      --border: #e5e7eb;
      --text: #1f2937;
      --muted: #6b7280;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      height: 100%;
      font-family: "Segoe UI", Tahoma, sans-serif;
      color: var(--text);
      background: #f3f4f6;
      display: flex;
      flex-direction: column;
      overflow: auto;
    }

    /* ── Sticky header ── */
    .brand-header {
      position: sticky;
      top: 0;
      z-index: 10;
      margin: 12px 12px 0 12px;
      border: 1px solid var(--border);
      border-radius: 12px;
      background: #f9fafb;
      padding: 12px 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    }
    .brand-titles strong { display: block; font-size: 17px; font-weight: 700; color: var(--green); }
    .brand-titles span { color: var(--muted); font-size: 11px; margin-top: 2px; display: block; }
    .page-header-actions { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
    .page-header-actions button {
      border: none; border-radius: 8px; padding: 7px 13px;
      cursor: pointer; font-size: 12px; font-weight: 600; transition: background 0.15s;
    }
    .btn-secondary { background: #f3f4f6; color: var(--text); border: 1px solid var(--border); }
    .btn-secondary:hover { background: #e5e7eb; }
    .btn-primary { background: var(--green); color: #fff; }
    .btn-primary:hover { background: #096336; }
    .report-overlay {
      position: fixed;
      inset: 0;
      background: rgba(255,255,255,0.7);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 30;
    }
    .report-overlay.show { display: flex; }
    .report-loader {
      background: #fff;
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 18px 22px;
      display: flex;
      align-items: center;
      gap: 12px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.08);
      font-size: 13px;
      font-weight: 600;
      color: var(--text);
    }
    .report-spinner {
      width: 20px;
      height: 20px;
      border: 3px solid #d8eee0;
      border-top-color: var(--green);
      border-radius: 50%;
      animation: spin .8s linear infinite;
    }

    /* ── Page content ── */
    .page-content { padding: 12px; display: flex; flex-direction: column; gap: 12px; }

    /* ── Verdict card ── */
    .verdict {
      border-radius: 12px; padding: 16px 20px;
      display: flex; align-items: flex-start; gap: 14px;
    }
    .verdict-ok     { background: #ecfdf5; border: 1px solid #bbf7d0; }
    .verdict-medium { background: #fffbeb; border: 1px solid #fde68a; }
    .verdict-high   { background: #fff1f2; border: 1px solid #fecdd3; }
    .verdict-icon { font-size: 26px; line-height: 1; margin-top: 2px; }
    .verdict-ok     .verdict-icon { color: #16a34a; }
    .verdict-medium .verdict-icon { color: #d97706; }
    .verdict-high   .verdict-icon { color: #dc2626; }
    .verdict-title { font-size: 16px; font-weight: 700; margin-bottom: 4px; }
    .verdict-ok     .verdict-title { color: #15803d; }
    .verdict-medium .verdict-title { color: #b45309; }
    .verdict-high   .verdict-title { color: #b91c1c; }
    .verdict-desc { font-size: 13px; color: var(--text); line-height: 1.5; }

    /* ── Summary stats ── */
    .stat-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 10px;
    }
    .stat-card {
      background: #fff;
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 10px 12px;
    }
    .stat-label {
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--muted);
      font-weight: 700;
      margin-bottom: 6px;
    }
    .stat-value {
      font-size: 22px;
      line-height: 1.1;
      font-weight: 700;
      color: var(--text);
    }

    /* ── Section label ── */
    .section-label {
      font-size: 11px; font-weight: 700; color: var(--muted);
      text-transform: uppercase; letter-spacing: 0.07em;
      padding: 4px 0;
    }

    /* ── File scope (collapsible) ── */
    .file-scope-details { background: #fff; border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }
    .file-scope-details summary {
      padding: 10px 14px; cursor: pointer; list-style: none;
      display: flex; justify-content: space-between; align-items: center;
      font-size: 11px; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: 0.07em;
    }
    .file-scope-details summary::-webkit-details-marker { display: none; }
    .toggle-hint { font-size: 10px; font-weight: 400; color: #9ca3af; text-transform: none; letter-spacing: 0; }
    .file-scope { max-height: 260px; overflow-y: auto; border-top: 1px solid var(--border); }
    .scope-item {
      padding: 7px 14px; font-size: 11px; color: #374151;
      border-bottom: 1px solid #f3f4f6;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .scope-item:last-child { border-bottom: none; }

    /* ── Issue cards ── */
    .issue-cards { display: flex; flex-direction: column; gap: 12px; }
    .issue-card {
      background: #fff;
      border-radius: 12px;
      border: 1px solid var(--border);
      border-left: 5px solid var(--border);
      overflow: hidden;
    }
    .badge-high-card   { border-left-color: #dc2626; }
    .badge-medium-card { border-left-color: #d97706; }
    .badge-low-card    { border-left-color: #16a34a; }

    /* Card header */
    .card-header { padding: 14px 16px 8px 16px; }
    .card-title-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 4px; }
    .card-icon { font-size: 16px; }
    .card-filename { font-size: 15px; font-weight: 700; color: var(--text); }
    .card-filepath { font-size: 11px; color: var(--muted); word-break: break-all; margin-top: 2px; }

    /* Risk badges */
    .badge { display: inline-flex; align-items: center; border-radius: 6px; padding: 3px 9px; font-size: 11px; font-weight: 700; }
    .badge-high   { background: #fee2e2; color: #b91c1c; }
    .badge-medium { background: #fef3c7; color: #92400e; }
    .badge-low    { background: #dcfce7; color: #15803d; }

    /* Risk bar */
    .risk-bar-row { display: flex; align-items: center; gap: 10px; padding: 0 16px 10px 16px; }
    .risk-bar-label { font-size: 11px; color: var(--muted); font-weight: 600; width: 28px; flex-shrink: 0; }
    .risk-bar-track { flex: 1; height: 6px; background: #e5e7eb; border-radius: 99px; overflow: hidden; }
    .risk-bar-fill { height: 100%; border-radius: 99px; transition: width 0.4s ease; }
    .risk-bar-pct { font-size: 11px; font-weight: 700; color: var(--text); width: 32px; text-align: right; flex-shrink: 0; }

    /* Evidence pills */
    .pill-row { display: flex; gap: 6px; flex-wrap: wrap; padding: 0 16px 10px 16px; }
    .pill { font-size: 10px; font-weight: 600; padding: 2px 8px; border-radius: 99px; }
    .pill-s1 { background: #ede9fe; color: #5b21b6; }
    .pill-s2 { background: #dbeafe; color: #1e40af; }
    .pill-s3 { background: #fce7f3; color: #9d174d; }
    .pill-s4 { background: #fef3c7; color: #92400e; }
    .pill-s5 { background: #dcfce7; color: #166534; }

    /* Detail grid */
    .detail-grid { display: flex; flex-direction: column; gap: 0; border-top: 1px solid #f3f4f6; }
    .detail-block { padding: 10px 16px; border-bottom: 1px solid #f3f4f6; }
    .detail-block:last-child { border-bottom: none; }
    .detail-label { font-size: 10px; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; }
    .detail-value { font-size: 13px; color: var(--text); line-height: 1.5; }
    .detail-code {
      font-family: "Consolas", "Courier New", monospace;
      font-size: 12px; background: #f8f9fa; border: 1px solid #e5e7eb;
      border-radius: 6px; padding: 8px 10px; color: #1f2937;
      white-space: pre-wrap; word-break: break-all; line-height: 1.5;
    }
    .consequence-block { background: #fffbeb; }
    .consequence-text { font-weight: 500; color: #92400e; }

    /* Card actions */
    .card-actions { display: flex; gap: 10px; padding: 10px 16px; background: #f9fafb; border-top: 1px solid #f3f4f6; flex-wrap: wrap; }
    .action-btn {
      display: inline-flex; align-items: center; gap: 5px;
      font-size: 12px; font-weight: 600; padding: 6px 12px;
      border-radius: 8px; cursor: pointer; border: none; text-decoration: none;
      transition: background 0.15s;
    }
    .action-open { background: #eff6ff; color: #1d4ed8; }
    .action-open:hover { background: #dbeafe; }
    .action-diff { background: #f0fdf4; color: #15803d; }
    .action-diff:hover { background: #dcfce7; }

    /* Empty state */
    .empty-state {
      text-align: center; padding: 40px 20px; color: #16a34a;
      font-size: 15px; font-weight: 600; background: #f0fdf4;
      border: 1px solid #bbf7d0; border-radius: 12px;
    }

    a { color: #2563eb; text-decoration: none; }
  `;
}

function buildReportWebviewHtml(report: any): string {
  const nonce = getNonce();
  const body = buildReportBody(report);
  const styles = buildReportStyles();
  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';">
        <style>${styles}</style>
      </head>
      <body>
        ${body}
        <div id="reportOverlay" class="report-overlay">
          <div class="report-loader">
            <div class="report-spinner"></div>
            <span>Regenerating report...</span>
          </div>
        </div>
        <script nonce="${nonce}">
          const vscode = acquireVsCodeApi();
          const reportOverlay = document.getElementById('reportOverlay');
          document.addEventListener('click', (event) => {
            const target = event.target instanceof Element ? event.target.closest('[data-action]') : null;
            if (!target) { return; }
            const action = target.getAttribute('data-action');
            if (action === 'change-scope') { vscode.postMessage({ type: 'changeScope' }); }
            if (action === 'regenerate') { vscode.postMessage({ type: 'regenerate' }); }
            if (action === 'save-json') { vscode.postMessage({ type: 'saveJson' }); }
            if (action === 'save-html') { vscode.postMessage({ type: 'saveHtml' }); }
            if (action === 'open-file') {
              vscode.postMessage({
                type: 'openFile',
                path: target.getAttribute('data-path') || '',
                line: Number(target.getAttribute('data-line') || 0)
              });
            }
          });
          window.addEventListener('message', (event) => {
            const msg = event.data;
            if (!msg || typeof msg !== 'object') { return; }
            if (msg.type === 'regenerateLoading' && reportOverlay) {
              reportOverlay.classList.toggle('show', !!msg.loading);
            }
          });
        </script>
      </body>
    </html>
  `;
}

function buildReportExportHtml(report: any): string {
  // For export we override the flex-layout so the entire report can scroll dynamically natively for printing.
  const styles = buildReportStyles() + `
    html, body {
      display: block;
      overflow: auto;
      height: auto;
      background: #f8fafc;
    }
    .brand-header { margin: 20px 20px 0 20px; }
    .page-content { overflow: visible; padding: 16px 20px 20px 20px; }
  `;
  const body = buildReportBody(report);
  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>${styles}</style>
      </head>
      <body>${body}</body>
    </html>
  `;
}
