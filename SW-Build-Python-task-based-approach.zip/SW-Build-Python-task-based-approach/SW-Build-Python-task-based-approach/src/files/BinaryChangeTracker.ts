import * as fs from 'fs';
import * as crypto from 'crypto';
import * as os from 'os';
import * as path from 'path';
import { LRUCache } from '../utils/LRUCache';
import { DiskBackedBufferCache } from '../session/DiskBackedContentCache';
import { FileUtils } from '../utils/FileUtils';
import { ChangeStore } from '../session/ChangeStore';
import { FileHandlingConfig } from '../utils/FileHandlingConfig';
import { BinaryFileChangeRecord, FileAction } from '../session/TaskSessionTypes';

export type BinaryTrackerOptions = {
    workspaceRoot: string;
    maxHashCacheSize?: number;
    maxDeletionCacheSize?: number;
    maxDeletionCacheBytes?: number;
    storageRoot?: string;
};

export class BinaryChangeTracker {
    private readonly binaryFileHashes: LRUCache<string, string>;
    private readonly binaryDeletionCache: DiskBackedBufferCache;

    constructor(
        private readonly changeStore: ChangeStore,
        private readonly options: BinaryTrackerOptions
    ) {
        this.binaryFileHashes = new LRUCache<string, string>(options.maxHashCacheSize ?? 200);
        const workspaceHash = crypto.createHash('sha1').update(FileUtils.normalizePath(options.workspaceRoot || 'workspace')).digest('hex');
        const cacheRoot = path.join(options.storageRoot || os.tmpdir(), 'ai-assisted-disk-cache', workspaceHash, 'binary-change-tracker');
        this.binaryDeletionCache = new DiskBackedBufferCache(cacheRoot, {
            maxEntries: options.maxDeletionCacheSize ?? 50,
            maxBytes: options.maxDeletionCacheBytes ?? (75 * 1024 * 1024)
        });
    }

    public isBinaryFile(filePath: string): boolean {
        return FileHandlingConfig.isBinaryFile(filePath);
    }

    public seedBinaryFile(filePath: string): void {
        const normalized = FileUtils.normalizePath(filePath);

        if (!this.isBinaryFile(normalized)) {
            return;
        }

        const hash = this.calculateFileHash(normalized);

        if (hash) {
            this.binaryFileHashes.set(normalized.toLowerCase(), hash);
        }
    }

    public recordBinaryChange(
        filePath: string,
        action: FileAction,
        fileContent?: Buffer
    ): BinaryFileChangeRecord | null {
        const normalized = FileUtils.normalizePath(filePath);

        if (!this.isBinaryFile(normalized)) {
            return null;
        }

        const cacheKey = normalized.toLowerCase();

        if (action === 'deleted') {
            const previousHash = this.binaryFileHashes.get(cacheKey);
            const deletedContent = fileContent || this.safeReadBuffer(normalized);

            if (deletedContent) {
                this.binaryDeletionCache.set(cacheKey, deletedContent);
            }

            this.binaryFileHashes.delete(cacheKey);

            return this.changeStore.recordBinaryChange({
                absolutePath: normalized,
                action,
                beforeHash: previousHash,
                afterHash: undefined,
                fileContent: deletedContent,
                sizeBytes: deletedContent?.byteLength
            });
        }

        const afterHash = this.calculateFileHash(normalized);

        if (!afterHash) {
            return null;
        }

        const beforeHash = this.binaryFileHashes.get(cacheKey);

        if (action === 'modified' && beforeHash === afterHash) {
            return null;
        }

        this.binaryFileHashes.set(cacheKey, afterHash);

        const currentContent = fileContent || this.safeReadBuffer(normalized);

        return this.changeStore.recordBinaryChange({
            absolutePath: normalized,
            action,
            beforeHash,
            afterHash,
            fileContent: currentContent,
            sizeBytes: currentContent?.byteLength
        });
    }

    public getDeletedBinaryContent(filePath: string): Buffer | undefined {
        return this.binaryDeletionCache.get(FileUtils.normalizePath(filePath).toLowerCase());
    }

    public clear(): void {
        this.binaryFileHashes.clear();
        this.binaryDeletionCache.clear();
    }

    public calculateFileHash(filePath: string): string {
        try {
            if (!fs.existsSync(filePath)) {
                return '';
            }

            const buffer = fs.readFileSync(filePath);
            return crypto.createHash('sha1').update(buffer).digest('hex');
        } catch {
            return '';
        }
    }

    private safeReadBuffer(filePath: string): Buffer | undefined {
        try {
            if (!fs.existsSync(filePath)) {
                return undefined;
            }

            return fs.readFileSync(filePath);
        } catch {
            return undefined;
        }
    }
}
