import * as vscode from 'vscode';
import { Logger } from './utils/Logger';
import { ApiService } from './services/api.service';
import { reportInstallationOnce } from './data/UsagePing';
import { Telemetry } from './utils/Telemetry';
import { registerCommands } from './commands/registerCommands';
import { disposeRecommendationWebviewState } from './webviews/RecommendationCommand';
import { disposePredictionReportWebviewState } from './webviews/PredictionReportCommand';
import { startProjectWatchers, ProjectWatcherRuntime } from './bootstrap/ProjectWatchers';
import { registerUnhandledRejectionHandler } from './bootstrap/UnhandledRejectionHandler';
import { writeActiveWorkspace, registerActiveWorkspaceListeners } from './bootstrap/ActiveWorkspace';
import { syncLocalMcpServerConfiguration, registerMcpConfigurationListeners } from './bootstrap/McpConfiguration';
import { FileHandlingConfig } from './utils/FileHandlingConfig';

export class ExtensionRuntime {
    private static current: ExtensionRuntime | undefined;

    private telemetry?: Telemetry;
    private watcherRuntime?: ProjectWatcherRuntime;

    static async activate(context: vscode.ExtensionContext): Promise<void> {
        const runtime = new ExtensionRuntime(context);
        ExtensionRuntime.current = runtime;
        await runtime.activate();
    }

    static deactivate(): void {
        ExtensionRuntime.current?.dispose();
        ExtensionRuntime.current = undefined;
    }

    private constructor(private readonly context: vscode.ExtensionContext) { }

    private async activate(): Promise<void> {
        Logger.initialize('AIASB', this.context.globalStorageUri.fsPath);
        FileHandlingConfig.initialize(this.context);
        await FileHandlingConfig.migrateWorkspaceSettingsToGlobalStorage();
        this.telemetry = new Telemetry(this.context.globalStorageUri.fsPath);

        try {
            writeActiveWorkspace(this.context);
            registerUnhandledRejectionHandler();

            this.watcherRuntime = startProjectWatchers(this.context, this.telemetry);

            registerCommands(this.context, () => this.watcherRuntime?.getFileWatcher());
            registerActiveWorkspaceListeners(this.context);
            registerMcpConfigurationListeners(this.context);

            void syncLocalMcpServerConfiguration(this.context);

            // Tell the server this installation exists. Adoption is otherwise only recorded when
            // a build completes, which leaves the most useful rollout case invisible: installed
            // and never used. Fire-and-forget, once per installed version, never on a timer.
            void reportInstallationOnce(this.context, new ApiService());

            // Visible "active in this window" indicator. VS Code runs a separate extension host per
            // window, so a freshly installed VSIX needs a one-time reload of already-open windows.
            // This status bar item lets a developer confirm at a glance that the extension is running
            // in THIS window, so a missed reload does not look like "it is not working".
            const statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
            statusBar.text = '$(check) AI Assisted SW Build';
            statusBar.tooltip = 'AI Assisted SW Build is active in this window. Click to open logs.';
            statusBar.command = 'gradleErrorAssistant.openLogs';
            statusBar.show();
            this.context.subscriptions.push(statusBar);
        } catch (err) {
            Logger.log('[Activation] Extension activation failed', err);
        }
    }

    private dispose(): void {
        try {
            this.watcherRuntime?.dispose();
            this.watcherRuntime = undefined;

            disposePredictionReportWebviewState();
            disposeRecommendationWebviewState();

            if (this.telemetry) {
                this.telemetry.logSummary();
                this.telemetry.save();
            }
        } finally {
            Logger.dispose();
        }
    }
}
