import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { getConfiguredBackendEnvironment } from '../utils/BackendConfig';
import { writeActiveWorkspace } from './ActiveWorkspace';

export async function syncLocalMcpServerConfiguration(context: vscode.ExtensionContext): Promise<void> {
  try {
    const workspacePath = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || '';
    const projectName = path.basename(workspacePath || '').trim().toLowerCase();
    const serverExe = path.join(context.extensionPath, 'bin', 'local-mcp-server.exe');
    const storagePath = context.globalStorageUri.fsPath;

    if (!fs.existsSync(serverExe)) {
      return;
    }

    const config = vscode.workspace.getConfiguration();
    const currentServers = config.get<Record<string, any>>('mcp.servers') || {};
    const nextServers = {
      ...currentServers,
      'ai-assisted-local': {
        command: serverExe,
        args: [],
        env: {
          MCP_WORKSPACE_PATH: workspacePath,
          MCP_PROJECT_NAME: projectName,
          ...getConfiguredBackendEnvironment(),
          STORAGE_PATH: storagePath
        },
        type: 'stdio'
      }
    };

    await config.update('mcp.servers', nextServers, vscode.ConfigurationTarget.Global);
  } catch {
    // MCP setup must not block extension activation.
  }
}

export function registerMcpConfigurationListeners(context: vscode.ExtensionContext): void {
  context.subscriptions.push(
    vscode.window.onDidChangeWindowState((state) => {
      if (!state.focused) {
        return;
      }

      writeActiveWorkspace(context);
      void syncLocalMcpServerConfiguration(context);
    })
  );
}
