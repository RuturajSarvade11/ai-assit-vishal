import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';

export function writeActiveWorkspace(context: vscode.ExtensionContext): void {
  try {
    const workspacePath = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || '';
    const projectName = path.basename(workspacePath || '').trim().toLowerCase();
    const storagePath = context.globalStorageUri.fsPath;

    if (!fs.existsSync(storagePath)) {
      fs.mkdirSync(storagePath, { recursive: true });
    }

    fs.writeFileSync(
      path.join(storagePath, 'active_workspace.json'),
      JSON.stringify({ workspacePath, projectName, updatedAt: new Date().toISOString() })
    );
  } catch {
    // Keep activation resilient. Workspace sidecar is useful but non-critical.
  }
}

export function registerActiveWorkspaceListeners(context: vscode.ExtensionContext): void {
  context.subscriptions.push(
    vscode.window.onDidChangeActiveTextEditor(() => {
      writeActiveWorkspace(context);
    })
  );
}
