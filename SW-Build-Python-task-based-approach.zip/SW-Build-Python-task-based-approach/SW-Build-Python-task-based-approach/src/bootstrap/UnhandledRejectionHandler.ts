import { Logger } from '../utils/Logger';

let registered = false;

export function registerUnhandledRejectionHandler(): void {
  if (registered) {
    return;
  }

  registered = true;

  process.on('unhandledRejection', (reason: any) => {
    if (isIgnorableUnhandledRejection(reason)) {
      return;
    }

    const text = getReasonText(reason);

    if (!text.includes('rnt.gradle-error-assistant')) {
      return;
    }

    Logger.log('[Unhandled Promise Rejection]', reason);
  });
}

function isIgnorableUnhandledRejection(reason: any): boolean {
  const text = getReasonText(reason);

  return (
    isCancellationError(text) ||
    isGitLensCancellationNoise(text)
  );
}

function isCancellationError(text: string): boolean {
  return (
    text.includes('CancellationError') ||
    text.includes('Operation cancelled') ||
    text.includes('Canceled') ||
    text.includes('Cancelled')
  );
}

function isGitLensCancellationNoise(text: string): boolean {
  return (
    text.includes('eamodio.gitlens') ||
    text.includes('gitlens.js') ||
    text.includes('for-each-ref') ||
    text.includes('refs/tags')
  );
}

function getReasonText(reason: any): string {
  const name = String(reason?.name || '');
  const message = String(reason?.message || '');
  const stack = String(reason?.stack || '');
  const raw = safeStringify(reason);

  return `${name}\n${message}\n${stack}\n${raw}`;
}

function safeStringify(value: any): string {
  try {
    if (typeof value === 'string') {
      return value;
    }

    return JSON.stringify(value);
  } catch {
    return String(value || '');
  }
}