import * as vscode from 'vscode';
import * as path from 'path';
import { Logger } from '../utils/Logger';
import { FileUtils } from '../utils/FileUtils';
import { Telemetry } from '../utils/Telemetry';
import { FileWatcher } from '../watchers/FileWatcher';
import { BuildReportWatcher } from '../watchers/BuildReportWatcher';
import { TD5BuildLogWatcher } from '../watchers/TD5BuildLogWatcher';
import { Td5BuildtimeWatcher } from '../watchers/Td5BuildtimeWatcher';
import { MultiReportSessionTracker } from '../watchers/MultiReportSessionTracker';

export type ProjectWatcherRuntime = {
  getFileWatcher: () => FileWatcher | undefined;
  dispose: () => void;
};

export function startProjectWatchers(
  context: vscode.ExtensionContext,
  telemetry: Telemetry
): ProjectWatcherRuntime {
  let fileWatcher: FileWatcher | undefined;
  const reportWatchers = new Map<string, BuildReportWatcher>();
  const td5LogWatchers = new Map<string, TD5BuildLogWatcher>();
  let sessionTracker: MultiReportSessionTracker | undefined;
  let reportCreationWatcher: vscode.FileSystemWatcher | undefined;
  let td5LogCreationWatcher: vscode.FileSystemWatcher | undefined;
  let td5BuildtimeWatcher: Td5BuildtimeWatcher | undefined;
  let discoveryPollTimer: NodeJS.Timeout | undefined;
  // TD5 log discovery happens in a burst at startup (every existing log at once). The story log
  // gets ONE summary line per burst; per-file detail stays at debug.
  let td5DiscoveredLogNames: string[] = [];
  let td5DiscoverySummaryTimer: NodeJS.Timeout | undefined;

  const clearDiscoveryPollTimer = () => {
    if (discoveryPollTimer) {
      clearInterval(discoveryPollTimer);
      discoveryPollTimer = undefined;
    }
  };

  const ensureSessionTracker = (): MultiReportSessionTracker | undefined => {
    if (!fileWatcher) {
      Logger.log('[WatcherBootstrap] FileWatcher is not initialized yet.');
      return undefined;
    }

    if (!sessionTracker) {
      sessionTracker = new MultiReportSessionTracker(fileWatcher);
    }

    return sessionTracker;
  };

  const startReportWatcher = (rawPath: string) => {
    const tracker = ensureSessionTracker();
    if (!tracker) {
      return;
    }

    const cleanPath = FileUtils.normalizePath(rawPath);
    clearDiscoveryPollTimer();

    const existing = reportWatchers.get(cleanPath);
    if (existing) {
      return;
    }

    reportWatchers.set(
      cleanPath,
      new BuildReportWatcher(cleanPath, tracker.getReconcilerFor(cleanPath))
    );

    // Client integration doc (additive): declare the GBE target for this report - the report's
    // parent directory, with a *.target.gradle.kts fallback. Detection/type tags are untouched.
    void FileUtils.deriveGbeTargetName(cleanPath).then((res) => {
      if (res?.target) {
        Logger.log(`[AI Assistant] GBE target detected: ${res.target} (${res.source})`);
        fileWatcher?.setGbeTarget(res.target);
      }
    }).catch(() => { /* best effort */ });
  };

  const startTD5LogWatcher = (rawPath: string, rootPath?: string) => {
    const cleanPath = FileUtils.normalizePath(rawPath);

    if (!FileUtils.isPrimaryTD5Log(cleanPath)) {
      return;
    }

    // Windows paths are case-insensitive: the discovery scan found 0ga1_0m0_NORMAL.log while the
    // buildtime.xml targeting registered 0GA1_0M0_NORMAL.log — TWO watchers on the SAME file,
    // every build parsed twice, every shadow capture stored twice.
    const watcherKey = cleanPath.toLowerCase();
    if (td5LogWatchers.has(watcherKey)) {
      return;
    }

    const tracker = ensureSessionTracker();
    if (!tracker) {
      return;
    }

    clearDiscoveryPollTimer();

    if (rootPath) {
      fileWatcher?.setTrackedFolder(path.join(rootPath, 'work'));
    }

    Logger.debug(`[AI Assistant] TD5 build log found: ${path.basename(cleanPath)}`);
    td5DiscoveredLogNames.push(path.basename(cleanPath));
    if (td5DiscoverySummaryTimer) { clearTimeout(td5DiscoverySummaryTimer); }
    td5DiscoverySummaryTimer = setTimeout(() => {
      const names = td5DiscoveredLogNames;
      td5DiscoveredLogNames = [];
      td5DiscoverySummaryTimer = undefined;
      if (names.length) {
        Logger.log(`[AI Assistant] Watching ${names.length} TD5 build log(s) for results: ${names.join(', ')}`);
      }
    }, 700);
    td5LogWatchers.set(
      watcherKey,
      new TD5BuildLogWatcher(cleanPath, tracker.getReconcilerFor(cleanPath))
    );
  };

  try {
    fileWatcher = new FileWatcher(context, telemetry);
    void fileWatcher.startupRetry().catch((err) => {
      Logger.log('[Activation] FileWatcher startup retry failed', err);
    });
  } catch (err) {
    Logger.log('[Activation] FileWatcher initialization failed', err);
  }

  const rootPath = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  const projectType = rootPath ? FileUtils.detectProjectType(rootPath) : 'td5';

  if (projectType === 'gradle') {
    Logger.log('[AI Assistant] Gradle project detected — watching for build failures');
  }

  if (projectType === 'td5') {
    Logger.log('[AI Assistant] TD5 mode detected — watching for build failure log');
  }

  if (rootPath) {
    void (async () => {
      try {
        if (projectType === 'gradle') {
          const existingReports = await FileUtils.findAllBuildReports(rootPath);

          if (existingReports.length > 0) {
            existingReports.forEach((reportPath) => startReportWatcher(reportPath));
          } else {
            discoveryPollTimer = setInterval(async () => {
              try {
                const gradleFound = await FileUtils.findAllBuildReports(rootPath, true);
                const newGradle = gradleFound.filter((reportPath) => !reportWatchers.has(FileUtils.normalizePath(reportPath)));
                newGradle.forEach((reportPath) => startReportWatcher(reportPath));

                if (reportWatchers.size > 0) {
                  clearDiscoveryPollTimer();
                }
              } catch {
                // Poll will retry on the next interval.
              }
            }, 10_000);
          }
        } else {
          const existingLogs = await FileUtils.findAllTD5Logs(rootPath, true);
          existingLogs.forEach((logPath) => startTD5LogWatcher(logPath, rootPath));
        }
      } catch (err) {
        Logger.log('[Discovery] Initial build artifact search failed', err);
      }
    })();
  }

  if (projectType === 'gradle') {
    reportCreationWatcher = vscode.workspace.createFileSystemWatcher('**/build/**/report.html');

    reportCreationWatcher.onDidCreate((uri) => startReportWatcher(uri.fsPath));
    reportCreationWatcher.onDidChange((uri) => startReportWatcher(uri.fsPath));
    reportCreationWatcher.onDidDelete((uri) => {
      const cleanPath = FileUtils.normalizePath(uri.fsPath);
      const watcher = reportWatchers.get(cleanPath);

      if (watcher) {
        watcher.dispose();
        reportWatchers.delete(cleanPath);
      }

      sessionTracker?.removeReport(cleanPath);
    });

    context.subscriptions.push(reportCreationWatcher);
  } else {
    td5LogCreationWatcher = vscode.workspace.createFileSystemWatcher('**/*_td5/log/*.log');

    td5LogCreationWatcher.onDidCreate((uri) => {
      if (!FileUtils.isPrimaryTD5Log(uri.fsPath)) {
        return;
      }

      sessionTracker?.resetParent();
      startTD5LogWatcher(uri.fsPath, rootPath);
    });

    td5LogCreationWatcher.onDidChange((uri) => {
      if (!FileUtils.isPrimaryTD5Log(uri.fsPath)) {
        return;
      }

      startTD5LogWatcher(uri.fsPath, rootPath);
    });

    td5LogCreationWatcher.onDidDelete((uri) => {
      if (!FileUtils.isPrimaryTD5Log(uri.fsPath)) {
        return;
      }

      const cleanPath = FileUtils.normalizePath(uri.fsPath);
      const watcher = td5LogWatchers.get(cleanPath);

      if (watcher) {
        watcher.dispose();
        td5LogWatchers.delete(cleanPath);
      }

      sessionTracker?.removeReport(cleanPath);
    });

    context.subscriptions.push(td5LogCreationWatcher);

    // Client integration doc: buildtime.xml is the authoritative "build finished" signal for
    // TD5 — it carries status/target/buildType, from which the build's OWN log
    // (<Target>_<BuildType>.log) is located and watched. Additive: the log watchers above keep
    // working exactly as before; this declares the result and targets the right log.
    td5BuildtimeWatcher = new Td5BuildtimeWatcher(context, (info) => {
      Logger.log(
        `[AI Assistant] TD5 build finished (buildtime.xml) — status=${info.status || 'UNKNOWN'}` +
        `, target=${info.target ?? '-'}, buildType=${info.buildType ?? '-'}` +
        (info.durationMs != null ? `, duration=${info.durationMs}ms` : '') +
        (info.uniqueBuildId ? `, buildId=${info.uniqueBuildId}` : '')
      );
      // buildtime.xml describes the particular build — its time window scopes
      // artifact collection to files this build actually wrote (570-file proc sweep fix).
      if (info.buildStartMs != null) {
        fileWatcher?.setTd5BuildWindow(info.buildStartMs, info.buildEndMs, info.xmlPath);
      }
      // TargetName_BuildTypeName is the TD5 user-run identity - carried live
      // into every recommendation request (never stored).
      fileWatcher?.setTd5BuildIdentity(info.target, info.buildType);
      if (info.logPath) {
        startTD5LogWatcher(info.logPath, rootPath);
      } else if (info.target || info.buildType) {
        Logger.log(
          `[AI Assistant] TD5 build log not found for ${info.target ?? '?'}_${info.buildType ?? '?'}` +
          ' — existing log watchers remain the fallback'
        );
      }
    });
  }

  const dispose = () => {
    clearDiscoveryPollTimer();
    if (td5DiscoverySummaryTimer) {
      clearTimeout(td5DiscoverySummaryTimer);
      td5DiscoverySummaryTimer = undefined;
    }

    fileWatcher?.dispose();
    fileWatcher = undefined;

    for (const watcher of reportWatchers.values()) {
      watcher.dispose();
    }
    reportWatchers.clear();

    for (const watcher of td5LogWatchers.values()) {
      watcher.dispose();
    }
    td5LogWatchers.clear();

    reportCreationWatcher?.dispose();
    reportCreationWatcher = undefined;

    td5LogCreationWatcher?.dispose();
    td5LogCreationWatcher = undefined;

    td5BuildtimeWatcher?.dispose();
    td5BuildtimeWatcher = undefined;

    sessionTracker = undefined;
  };

  return {
    getFileWatcher: () => fileWatcher,
    dispose
  };
}
