import * as fs from 'fs';
import * as path from 'path';
import * as jsdiff from 'diff';
import { LineChange } from '../types/events';

export class DiffGenerator {

  static generate(oldFile: string, newFile: string): string {
    const oldText = fs.existsSync(oldFile) ? fs.readFileSync(oldFile, 'utf-8') : '';
    const newText = fs.existsSync(newFile) ? fs.readFileSync(newFile, 'utf-8') : '';

    const oldName = path.basename(oldFile);
    const newName = path.basename(newFile);

    return jsdiff.createTwoFilesPatch(oldName, newName, oldText, newText);
  }

  static getDiffStats(oldText: string, newText: string): { added: LineChange[], removed: LineChange[] } {
    // Ensure both texts end with newline for consistent diffing
    if (oldText && !oldText.endsWith('\n')) {
      oldText += '\n';
    }
    if (newText && !newText.endsWith('\n')) {
      newText += '\n';
    }

    const changes = jsdiff.diffLines(oldText, newText);
    let oldLine = 1;
    let newLine = 1;
    const added: LineChange[] = [];
    const removed: LineChange[] = [];

    for (const part of changes) {
      const lines = part.value.replace(/\r\n/g, '\n').split('\n');
      
      // Remove empty trailing line from split if count doesn't match
      while (lines.length > 0 && lines[lines.length - 1] === '' && lines.length > (part.count || 0)) {
        lines.pop();
      }

      if (part.added) {
        for (let i = 0; i < (part.count || 0); i++) {
          added.push({
            line: newLine + i,
            content: lines[i] || ''
          });
        }
        newLine += part.count!;
      } else if (part.removed) {
        for (let i = 0; i < (part.count || 0); i++) {
          removed.push({
            line: oldLine + i,
            content: lines[i] || ''
          });
        }
        oldLine += part.count!;
      } else {
        // Unchanged
        newLine += part.count!;
        oldLine += part.count!;
      }
    }
    return { added, removed };
  }

  static getChangedLineNumbers(oldText: string, newText: string): number[] {
    return this.getDiffStats(oldText, newText).added.map(x => x.line);
  }
}