import * as fs from 'fs';
import * as path from 'path';

export class SnapshotManager {
  private snapshotDir: string;

  constructor(private workspaceRoot: string, storagePath: string) {
    this.snapshotDir = path.join(storagePath, 'snapshots');
    fs.mkdirSync(this.snapshotDir, { recursive: true });
  }

  /** One snapshot file per (source file, purpose). The purpose tag is ESSENTIAL: without it,
   *  every snapshot of the same source file aliased to ONE path — the session's "before", the
   *  "last saved", the failure-state baseline and the re-anchor all overwrote each other, and
   *  the last writer (the fix content) silently destroyed the captured broken state (the
   *  bug that survived three upstream fixes). */
  createSnapshot(file: string, purpose: string = ''): string {
    const rel = path.relative(this.workspaceRoot, file).replace(/[\\/]/g, '_');
    const dest = path.join(this.snapshotDir, purpose ? `${rel}.${purpose}` : rel);

    const data = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
    fs.writeFileSync(dest, data, 'utf8');
    return dest;
  }

  clearSnapshots(): void {
    if (fs.existsSync(this.snapshotDir)) {
      fs.rmSync(this.snapshotDir, { recursive: true, force: true });
    }
    fs.mkdirSync(this.snapshotDir, { recursive: true });
  }
}
