import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { FileUtils } from '../utils/FileUtils';
import { FileHandlingConfig } from '../utils/FileHandlingConfig';
import { Logger } from '../utils/Logger';
import { EventLogger } from '../data/EventLogger';
import { ArtifactConfigService, RemoteArtifactFolder } from './ArtifactConfigService';
// NOTE: per-run proof logs remain disabled pending validation; see the commented-out
// Logger.log blocks below when re-enabling them.

export type RuntimeArtifactEvent = {
  filePath: string;
  absolutePath: string;
  action: 'added' | 'modified' | 'deleted';
  fileContent?: Buffer;
  projectName?: string;
  artifactGroup?: string;
  taskPath?: string;
  sourceFolder?: string;
  uploadName?: string;
  originalFileName?: string;
  /** The failure this artifact was collected FOR. A fix is always confirmed one cycle
   *  AFTER the failure it resolves, so "collected this cycle" is the wrong anchor - the right
   *  one is which failure the file belongs to. Upload keeps only artifacts whose failure is
   *  actually being resolved, so a stale log from an unfinished earlier problem can no longer
   *  be stapled to an unrelated fix. */
  failureMessage?: string;
};

export type RuntimeArtifactBuildError = {
  path?: string;
  message: string;
  taskPath?: string;
};

export type RuntimeArtifactCollectorOptions = {
  workspaceRoot: string;
};

export class RuntimeArtifactCollector {
  // Noise/metadata artifact basenames (lowercase) excluded at capture — no failure signal.
  // Extend this list as more junk files are identified (kept in sync with the backend guard).
  private static readonly NOISE_ARTIFACT_FILES = new Set<string>(['process-id.txt']);

  // EMPTY files (zero bytes, or whitespace-only text) carry no failure signal — the S3 audit
  // showed 22% of uploaded artifacts were empty. NOTE: an empty Buffer is truthy in JS, so a
  // plain `if (!content)` check does NOT catch them; the explicit length check is required.
  private static isEmptyArtifactContent(filePath: string, content: Buffer): boolean {
    if (content.length === 0) { return true; }
    const ext = path.extname(filePath).toLowerCase();
    if ((ext === '.txt' || ext === '.log') && content.toString('utf8').trim().length === 0) { return true; }
    return false;
  }
  private readonly workspaceRoot: string;
  private readonly runtimeArtifactHashes = new Map<string, string>();
  private readonly runtimeArtifactEvents: RuntimeArtifactEvent[] = [];

  // Admin-configured collection rules from the dashboard Artifact Configuration page. When set,
  // they govern WHICH folders are scanned and WHICH files are collected; when null (backend
  // unreachable / page never configured differs from defaults), the legacy hardcoded rules below
  // apply unchanged. Set per collection cycle by FileWatcher via setRemoteFolders().
  private remoteFolders: RemoteArtifactFolder[] | null = null;

  constructor(options: RuntimeArtifactCollectorOptions) {
    this.workspaceRoot = FileUtils.normalizePath(options.workspaceRoot);
  }

  public setRemoteFolders(folders: RemoteArtifactFolder[] | null): void {
    this.remoteFolders = folders;
  }

  public async collectTaskRuntimeArtifacts(rawErrors: RuntimeArtifactBuildError[]): Promise<number> {
    const projectName = this.getProjectName();
    const seenTaskPaths = new Set<string>();
    let addedCount = 0;

    // Content-hash dedup is scoped to ONE collection pass (same file reachable via two scan
    // dirs). It used to persist across failure cycles, which HID unchanged artifacts from the
    // confirm popup ("not detecting runtime artifacts" report) — the popup must show what was
    // collected; the SERVER's fingerprint dedup decides duplicate storage and logs it visibly.
    this.runtimeArtifactHashes.clear();

    // Disabled pending validation: per-build proof logs read as noise in
    // field logs. Re-enable by uncommenting once artifact configuration is validated.
    // Proof log: which rule set governs THIS collection run.
    // if (this.remoteFolders) {
    //   const enabled = this.remoteFolders.filter(f => f.isEnabled).map(f => f.folderPath);
    //   const disabled = this.remoteFolders.filter(f => !f.isEnabled).map(f => f.folderPath);
    //   Logger.log(
    //     `[RuntimeArtifacts] collection rules: ADMIN configuration - scanning [${enabled.join(', ') || 'none'}]` +
    //     (disabled.length ? `; disabled by admin (skipped): [${disabled.join(', ')}]` : '')
    //   );
    // } else {
    //   Logger.log('[RuntimeArtifacts] collection rules: LEGACY defaults (admin config unavailable) - out/log/wrk, .txt/.log');
    // }

    for (const err of rawErrors) {
      const taskPath = String(err.taskPath || '').trim();
      if (!taskPath || seenTaskPaths.has(taskPath)) { continue; }
      seenTaskPaths.add(taskPath);
      const failureMessage = String(err.message || '').trim();

      const buildDir = this.resolveTaskBuildDir(taskPath);
      if (!buildDir) { continue; }

      // Capture runtime artifacts from the task's build dir (build/<target>/<task>/). Which
      // folders and which files: the admin's Artifact Configuration page when available
      // (remoteFolders; 'proc' is the TD5 path below, not a build-dir subfolder), else the
      // legacy hardcoded rules — OUT/LOG/WRK, .log/.txt recursively.
      // The 'in' folder holds build INPUTS (not evidence of why a build failed) and is
      // excluded; 'tmp' is scratch and '.gbe' is tooling — excluded too.
      const remoteTaskFolders = this.remoteFolders
        ? this.remoteFolders.filter(f => f.isEnabled && f.folderPath.trim().toLowerCase() !== 'proc')
        : null;
      const folderConfigs: Array<{ name: string; remote?: RemoteArtifactFolder }> = remoteTaskFolders
        ? remoteTaskFolders.map(f => ({ name: f.folderPath, remote: f }))
        : [{ name: 'out' }, { name: 'log' }, { name: 'wrk' }];

      for (const { name: folderName, remote } of folderConfigs) {
        const folderPath = FileUtils.normalizePath(path.join(buildDir, folderName));
        if (!this.isDirectory(folderPath)) { continue; }

        const files = this.collectFilesRecursive(folderPath);
        // const addedBefore = addedCount;   // only used by the disabled proof log below
        for (const filePath of files) {
          const fileName = path.basename(filePath);
          const ext = path.extname(filePath).toLowerCase();

          if (remote) {
            // Admin rules govern: include/exclude patterns on the file name, exclude wins.
            if (!ArtifactConfigService.fileMatchesFolder(fileName, remote)) { continue; }
          } else {
            if (ext === '.gbe') { continue; }
            if (/lock/i.test(fileName)) { continue; }
            // Noise/metadata artifacts (no failure signal) — exclude at capture so they're never
            // uploaded or embedded, and RRF can never pick them. Add more names to this list as
            // needed (kept in sync with the backend ARTIFACT_NOISE_FILES guard).
            if (RuntimeArtifactCollector.NOISE_ARTIFACT_FILES.has(fileName.toLowerCase())) { continue; }
            if (!FileHandlingConfig.isArtifactFile(filePath)) { continue; }
          }

          const fileContent = await this.readStableBuffer(filePath);
          if (!fileContent) { continue; }
          if (RuntimeArtifactCollector.isEmptyArtifactContent(filePath, fileContent)) { continue; }

          const relativePath = FileUtils.normalizePath(path.relative(this.workspaceRoot, filePath));
          // Remote folder paths may contain slashes (e.g. "build/custom") — keep labels flat.
          const folderLabel = folderName.replace(/[\\/]+/g, '_');
          const uploadName = `${folderLabel}__${relativePath.replace(/[\\/]+/g, '__')}`;

          if (this.addArtifactEvent({
            filePath: relativePath,
            absolutePath: filePath,
            action: 'modified',
            fileContent,
            projectName,
            artifactGroup: 'task-runtime-artifacts',
            taskPath,
            failureMessage,
            sourceFolder: folderLabel,
            uploadName,
            originalFileName: path.basename(filePath),
          }, `${taskPath}|${relativePath}`, fileContent)) {
            addedCount++;
          }
        }

        // Disabled pending validation: per-folder proof log — noisy in field
        // logs. Re-enable together with the 'addedBefore' counter above once validated.
        // Logger.log(
        //   `[RuntimeArtifacts] folder '${folderName}'` +
        //   (remote
        //     ? ` (admin include [${remote.includePatterns.join(', ') || '-'}], exclude [${remote.excludePatterns.join(', ') || '-'}])`
        //     : ' (legacy rules)') +
        //   `: ${files.length} files scanned, ${addedCount - addedBefore} collected`
        // );
      }
    }

    return addedCount;
  }

  /** Start of the latest TD5 build per buildtime.xml (end = xml mtime, start = end - duration).
   *  Files older than this were not written by the current cycle — stale leftovers from earlier
   *  builds — and are skipped. Monotonic lower bound: even if collection races ahead of the
   *  buildtime event, the previous build's start still cuts the stale bulk. */
  private td5BuildStartMs: number | null = null;
  /** proc folder of the build that ACTUALLY ran, derived from its own buildtime.xml path —
   *  evidence, not name reconstruction. With several _<target>_<buildType> siblings on a
   *  machine, name-based fallbacks can pick the wrong one; the xml the build wrote cannot. */
  private td5ActiveProcFolder: string | null = null;

  public setTd5BuildWindow(startMs: number, _endMs: number | null, xmlPath?: string): void {
    if (Number.isFinite(startMs) && startMs > 0) {
      this.td5BuildStartMs = startMs;
    }
    if (xmlPath) {
      // The build folder is the nearest ancestor of buildtime.xml that has a proc/ subfolder.
      let dir = path.dirname(xmlPath);
      for (let i = 0; i < 6 && dir && dir !== path.dirname(dir); i++) {
        const procDir = path.join(dir, 'proc');
        if (this.isDirectory(procDir)) {
          this.td5ActiveProcFolder = procDir;
          return;
        }
        dir = path.dirname(dir);
      }
    }
  }

  /** TD5 collection: the admin artifact
   *  configuration is defined RELATIVE TO THE TASK WORKSPACE, and TD5's task workspace is
   *  proc/<processName> inside the running build's folder (_<target>_<buildType>) — RMS fails,
   *  look in proc/RMS. The SAME enabled folder entries (out/log/...) as GBE apply there with
   *  IDENTICAL semantics: each folder's include/exclude patterns, inside the process workspace.
   *  Plus the buildtime.xml window: only files the failing build wrote. A whole-tree sweep
   *  (570-file case) is impossible by construction. GBE collection is a separate path. */
  public async collectTd5ProcArtifacts(rawErrors: RuntimeArtifactBuildError[], requestedTasks: string,
                                       cycleFailureMessage: string = ''): Promise<number> {
    const tokens = requestedTasks.trim().split(/\s+/);
    const targetName = tokens[0];
    const buildType = tokens[1] || '';
    if (!targetName) { return 0; }

    // Same per-pass scoping as collectTaskRuntimeArtifacts: never hide unchanged artifacts
    // from the popup across cycles; the server's fingerprint dedup owns duplicate storage.
    this.runtimeArtifactHashes.clear();

    // Admin config present => the enabled folder entries drive collection (deleted/disabled on
    // the dashboard => not collected). Config unreachable => legacy .log/.txt allow-list.
    let adminFolders: RemoteArtifactFolder[] | null = null;
    if (this.remoteFolders) {
      adminFolders = this.remoteFolders.filter(f => f.isEnabled);
      if (adminFolders.length === 0) { return 0; }
    }

    const procFolder = this.resolveTd5ProcFolder(targetName, buildType);
    if (!procFolder) { return 0; }

    const taskPaths = [...new Set(rawErrors.map(e => String(e.taskPath || '').trim()).filter(Boolean))];
    // TD5 proc artifacts are deliberately NOT stamped with a failure. TD5
    // collection is proven behaviour and is left exactly as it was: an unstamped artifact is
    // always kept by the upload filter, so TD5 attaches the same artifacts it always has.
    // Wrong-log protection for TD5 comes from the server instead, which needs no client change.
    void cycleFailureMessage;
    return this.collectTd5ProcFiles(procFolder, taskPaths, adminFolders);
  }

  public hasPendingArtifacts(): boolean {
    return this.runtimeArtifactEvents.length > 0;
  }

  public getPendingCount(): number {
    return this.runtimeArtifactEvents.length;
  }

  public getPendingArtifacts(): RuntimeArtifactEvent[] {
    return [...this.runtimeArtifactEvents];
  }

  public async flushArtifacts(
    batchId: string,
    logger: EventLogger,
    developerId: string = 'unknown',
    requestId?: string
  ): Promise<void> {
    if (!this.hasPendingArtifacts() || !requestId) {
      return;
    }

    const pending = this.getPendingArtifacts();
    logger.enqueueArtifactRetry('runtime', batchId, pending, developerId, requestId);

    await logger.sendRuntimeArtifacts(batchId, pending, developerId, requestId);

    logger.removeArtifactRetry('runtime', batchId);
    this.clear();
  }

  public clear(): void {
    this.runtimeArtifactEvents.length = 0;
    this.runtimeArtifactHashes.clear();
  }

  /**
   * Remove artifacts for a specific task (used when task is uploaded)
   * Preserves artifacts from other concurrent tasks to prevent race condition
   */
  public removeArtifactsByTaskPath(taskPath: string): void {
    const taskKey = String(taskPath || '').trim();
    const remainingArtifacts = this.runtimeArtifactEvents.filter(artifact => 
      String(artifact.taskPath || '').trim() !== taskKey
    );
    this.runtimeArtifactEvents.length = 0;
    this.runtimeArtifactEvents.push(...remainingArtifacts);
  }

  public clearHashes(): void {
    this.runtimeArtifactHashes.clear();
  }

  private async collectTd5ProcFiles(procFolder: string, taskPaths: string[], adminFolders: RemoteArtifactFolder[] | null = null): Promise<number> {
    const projectName = this.getProjectName();
    let addedCount = 0;

    let procSubdirs: string[];
    try {
      procSubdirs = fs.readdirSync(procFolder)
        .map(e => path.join(procFolder, e))
        .filter(p => this.isDirectory(p));
    } catch { return 0; }

    // Failing-process match, BOTH directions: the [ERR!] banner name can be the bare process
    // ('compile_link') or a decorated form ('0GA1_0M0_NORMAL_compile_link') — a one-way
    // includes() missed the decorated form and triggered a 75-file all-process sweep.
    const matched = taskPaths.length > 0
      ? procSubdirs.filter(d => taskPaths.some(tp => {
          const base = path.basename(d).toLowerCase();
          const t = tp.toLowerCase();
          return base.includes(t) || t.includes(base);
        }))
      : [];
    // The model is 'RMS fails -> look in proc/RMS'. When the failing process is UNKNOWN
    // (no banner before the error), sweeping every process's admin folders (out/ included)
    // is exactly the 75-file bug — the whole build legitimately wrote those files. Unknown
    // process => bounded evidence only: the .log/.txt allow-list across processes.
    const processKnown = matched.length > 0;
    const dirsToScan = processKnown ? matched : procSubdirs;
    Logger.log(
      `[AI Assistant] TD5 artifacts: procFolder=${procFolder} | failing=${JSON.stringify(taskPaths)} | ` +
      `matched=${JSON.stringify(matched.map(d => path.basename(d)))} | ` +
      `mode=${processKnown ? (adminFolders ? 'admin-folders' : 'legacy') : 'logs-only (process unknown)'}`
    );

    for (const subdir of dirsToScan) {
      const processName = path.basename(subdir);

      if (adminFolders && processKnown) {
        // Same model with GBE-identical semantics: each ENABLED admin folder entry (out/log/...)
        // is looked up INSIDE the process workspace (proc/<process>/<folder>) and its own
        // include/exclude patterns apply there. A folder the workspace doesn't have is skipped.
        for (const folder of adminFolders) {
          const folderDir = path.join(subdir, folder.folderPath);
          if (!this.isDirectory(folderDir)) { continue; }
          for (const filePath of this.collectFilesRecursive(folderDir)) {
            if (!ArtifactConfigService.fileMatchesFolder(path.basename(filePath), folder)) { continue; }
            if (await this.tryAddTd5ProcArtifact(filePath, processName, projectName)) { addedCount++; }
          }
        }
      } else {
        // Legacy allow-list path: admin config unreachable, OR the failing process is unknown
        // (see above — bounded .log/.txt evidence instead of an all-process out/ sweep):
        // process log dir + workspace root with the shipped .log/.txt allow-list.
        const logDir = path.join(subdir, 'log');
        const scanDirs = [
          ...(this.isDirectory(logDir) ? [logDir] : []),
          subdir,
        ];
        for (const scanDir of scanDirs) {
          for (const filePath of this.collectFilesRecursive(scanDir)) {
            if (!FileHandlingConfig.isArtifactFile(filePath)) { continue; }
            if (await this.tryAddTd5ProcArtifact(filePath, processName, projectName)) { addedCount++; }
          }
        }
      }
    }

    Logger.log(`[AI Assistant] TD5 artifacts: collected ${addedCount} file(s) from ${dirsToScan.length} process folder(s)`);
    return addedCount;
  }

  /** Shared per-file tail of TD5 collection: the buildtime.xml cycle window (only files the
   *  failing build wrote — anything older than build start minus 60s grace is a leftover),
   *  empty-content skip, and the artifact event itself. */
  private async tryAddTd5ProcArtifact(filePath: string, processName: string, projectName: string): Promise<boolean> {
    if (this.td5BuildStartMs !== null) {
      try {
        if (fs.statSync(filePath).mtimeMs < this.td5BuildStartMs - 60000) { return false; }
      } catch { return false; }
    }

    const fileContent = await this.readStableBuffer(filePath);
    if (!fileContent) { return false; }
    if (RuntimeArtifactCollector.isEmptyArtifactContent(filePath, fileContent)) { return false; }

    const relativePath = FileUtils.normalizePath(path.relative(this.workspaceRoot, filePath));
    const uploadName = `proc__${processName}__${path.basename(filePath)}`;

    return this.addArtifactEvent({
      filePath: relativePath,
      absolutePath: filePath,
      action: 'modified',
      fileContent,
      projectName,
      artifactGroup: 'td5-proc-artifacts',
      taskPath: processName,
      sourceFolder: 'proc',
      uploadName,
      originalFileName: path.basename(filePath),
    }, `td5-proc|${relativePath}`, fileContent);
  }

  private addArtifactEvent(event: RuntimeArtifactEvent, dedupeKey: string, fileContent: Buffer): boolean {
    const contentHash = crypto.createHash('sha256').update(fileContent).digest('hex');
    if (this.runtimeArtifactHashes.get(dedupeKey) === contentHash) { return false; }
    this.runtimeArtifactHashes.set(dedupeKey, contentHash);

    const existingIndex = this.runtimeArtifactEvents.findIndex(e => e.filePath === event.filePath && e.artifactGroup === event.artifactGroup && e.taskPath === event.taskPath);
    if (existingIndex >= 0) {
      this.runtimeArtifactEvents[existingIndex] = event;
    } else {
      this.runtimeArtifactEvents.push(event);
    }
    return true;
  }

  private resolveTaskBuildDir(taskPath: string): string | null {
    const raw = String(taskPath || '').trim();
    if (!raw) { return null; }
    const parts = raw.split(':').map(p => p.trim()).filter(Boolean);
    if (parts.length === 0) { return null; }
    const buildParts = parts[0].toLowerCase() === 'targets' ? parts.slice(1) : parts;
    if (buildParts.length === 0) { return null; }

    const buildRoot = FileUtils.normalizePath(path.join(this.workspaceRoot, 'build'));
    if (!this.isDirectory(buildRoot)) { return null; }

    const taskFolderName = buildParts[buildParts.length - 1];
    const parentHint = buildParts.length > 1 ? buildParts[buildParts.length - 2] : '';

    const directCandidate = FileUtils.normalizePath(path.join(buildRoot, taskFolderName));
    if (this.isDirectory(directCandidate)) { return directCandidate; }

    if (parentHint) {
      const hintedCandidate = FileUtils.normalizePath(path.join(buildRoot, parentHint, taskFolderName));
      if (this.isDirectory(hintedCandidate)) { return hintedCandidate; }
    }

    const queue: Array<{ dir: string; depth: number }> = [{ dir: buildRoot, depth: 0 }];
    const maxDepth = 4;

    while (queue.length > 0) {
      const current = queue.shift();
      if (!current || current.depth > maxDepth) { continue; }

      let entries: fs.Dirent[] = [];
      try { entries = fs.readdirSync(current.dir, { withFileTypes: true }); } catch { continue; }

      for (const entry of entries) {
        if (!entry.isDirectory()) { continue; }
        const fullPath = FileUtils.normalizePath(path.join(current.dir, entry.name));
        if (entry.name.toLowerCase() === taskFolderName.toLowerCase()) { return fullPath; }
        if (current.depth < maxDepth) { queue.push({ dir: fullPath, depth: current.depth + 1 }); }
      }
    }

    return null;
  }

  private collectFilesRecursive(rootDir: string, bucket: string[] = []): string[] {
    if (!this.isDirectory(rootDir)) { return bucket; }
    let entries: fs.Dirent[] = [];
    try { entries = fs.readdirSync(rootDir, { withFileTypes: true }); } catch { return bucket; }

    for (const entry of entries) {
      const fullPath = FileUtils.normalizePath(path.join(rootDir, entry.name));
      if (this.shouldIgnoreArtifactPath(fullPath)) { continue; }
      if (entry.isDirectory()) {
        this.collectFilesRecursive(fullPath, bucket);
      } else if (entry.isFile()) {
        bucket.push(fullPath);
      }
    }
    return bucket;
  }

  /** The RUNNING build's own folder, GBE-analogous: _<target>_<buildType> (e.g. _0GA1_0M0_NORMAL),
   *  matched case-insensitively (the log-derived target casing varies on Windows). Falls back to
   *  any _<target>_* build folder for the target, then to the legacy _*_normal scan. */
  private resolveTd5ProcFolder(targetName: string, buildType = ''): string | null {
    // Evidence first: the proc folder of the build that actually ran, from its own
    // buildtime.xml location. Name reconstruction below stays as the fallback only.
    if (this.td5ActiveProcFolder && this.isDirectory(this.td5ActiveProcFolder)) {
      return this.td5ActiveProcFolder;
    }
    let entries: string[] = [];
    try { entries = fs.readdirSync(this.workspaceRoot); } catch { return null; }
    const byLower = new Map(entries.map((e) => [e.toLowerCase(), e]));

    const candidates = [
      ...(buildType ? [`_${targetName}_${buildType}`] : []),
      `_${targetName}_normal`,
      `_${targetName}`,
    ];
    for (const candidate of candidates) {
      const hit = byLower.get(candidate.toLowerCase());
      if (hit) {
        const candidatePath = path.join(this.workspaceRoot, hit, 'proc');
        if (this.isDirectory(candidatePath)) { return candidatePath; }
      }
    }

    const targetPrefix = `_${targetName.toLowerCase()}_`;
    for (const entry of entries) {
      if (entry.toLowerCase().startsWith(targetPrefix)) {
        const candidatePath = path.join(this.workspaceRoot, entry, 'proc');
        if (this.isDirectory(candidatePath)) { return candidatePath; }
      }
    }

    for (const entry of entries) {
      if (entry.startsWith('_') && entry.toLowerCase().endsWith('_normal')) {
        const candidatePath = path.join(this.workspaceRoot, entry, 'proc');
        if (this.isDirectory(candidatePath)) { return candidatePath; }
      }
    }
    return null;
  }

  private shouldIgnoreArtifactPath(filePath: string): boolean {
    const normalized = FileUtils.normalizePath(filePath).toLowerCase();
    const name = path.basename(normalized);

    if (
      normalized.includes('/node_modules/') ||
      normalized.includes('/.git/') ||
      normalized.includes('/.gradle/') ||
      normalized.includes('/.idea/') ||
      normalized.includes('/.vscode/')
    ) {
      return true;
    }

    return name.endsWith('.lock') || name.endsWith('.lck') || name.endsWith('.tmp');
  }

  private isDirectory(dirPath: string): boolean {
    try { return fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory(); } catch { return false; }
  }

  private safeReadBuffer(filePath: string): Buffer | null {
    try {
      if (!fs.existsSync(filePath)) { return null; }
      const stat = fs.statSync(filePath);
      if (!stat.isFile()) { return null; }
      return fs.readFileSync(filePath);
    } catch { return null; }
  }

  /** Mid-write stability guard: a log read in the instant its writer is still flushing loses
   *  its tail — typically the [ERROR] and root-cause lines of a debug.log. Re-stat after the
   *  read; while the size disagrees with what was
   *  read or the file was modified within the last 750ms, wait briefly and read again
   *  (bounded retries). The full file is always read as-is — nothing is ever cut here. */
  private async readStableBuffer(filePath: string): Promise<Buffer | null> {
    let buf = this.safeReadBuffer(filePath);
    for (let attempt = 0; buf && attempt < 3; attempt++) {
      let stat: fs.Stats;
      try { stat = fs.statSync(filePath); } catch { break; }
      if (stat.size === buf.length && Date.now() - stat.mtimeMs >= 750) { break; }
      await new Promise<void>(resolve => setTimeout(resolve, 300));
      const again = this.safeReadBuffer(filePath);
      if (!again) { break; }
      buf = again;
    }
    return buf;
  }

  private getProjectName(): string {
    const name = path.basename(this.workspaceRoot || '').trim().toLowerCase();
    return name || 'unknown-project';
  }
}
