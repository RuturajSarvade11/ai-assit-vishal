import { ApiService } from '../services/api.service';
import { FileHandlingConfig } from '../utils/FileHandlingConfig';
import { Logger } from '../utils/Logger';

/**
 * Remote artifact-collection rules from the dashboard "Artifact Configuration" admin page
 * (GET /api/artifact-configurations). Decides WHICH folders are scanned and WHICH files are
 * collected when a build fails.
 *
 * Matching semantics (must stay identical to the backend service artifact_config.py):
 *   - patterns match the file NAME only (not the path), '*' wildcard, case-insensitive
 *   - EXCLUDE always beats include
 *   - disabled folders are skipped entirely
 *
 * FAIL-OPEN: if the backend is unreachable or the payload is malformed, load() returns null and
 * the collector falls back to its legacy hardcoded behavior (out/log/wrk + .txt/.log allow-list),
 * so artifact collection never breaks because the dashboard is down.
 */
export type RemoteArtifactFolder = {
  folderName: string;
  folderPath: string;
  isEnabled: boolean;
  includePatterns: string[];
  excludePatterns: string[];
};

export class ArtifactConfigService {
  private static readonly CACHE_TTL_MS = 60_000;
  private static cache: RemoteArtifactFolder[] | null = null;
  private static cacheAt = 0;

  /** Fetch (with a short cache so one build cycle = one request). null => use legacy behavior.
   *  Source priority: the NATIVE rules model (/api/artifact-rules — what the admin page edits),
   *  then the legacy /api/artifact-configurations view (itself served from the rules on current
   *  backends), then the possibly-stale cache, then legacy hardcoded behavior. */
  public static async load(apiService: ApiService): Promise<RemoteArtifactFolder[] | null> {
    const now = Date.now();
    if (this.cache && (now - this.cacheAt) < this.CACHE_TTL_MS) {
      return this.cache;
    }

    try {
      const rulesResp = await apiService.getArtifactRules();
      const rules = rulesResp?.data?.rules ?? rulesResp?.rules;
      const rulesFolders = this.foldersFromRules(rules);
      if (rulesFolders) {
        this.cache = rulesFolders;
        this.cacheAt = now;
        return rulesFolders;
      }
    } catch {
      // Older backend without the rules API — fall through to the legacy endpoint.
    }

    try {
      const resp = await apiService.getArtifactConfigurations();
      const data = resp?.data || resp;
      const folders = this.parseFolders(data?.folders);
      if (!folders) {
        Logger.log('[ArtifactConfig] malformed remote config - using legacy collection rules');
        return this.cache; // possibly-stale cache beats hardcoded fallback if we ever had config
      }
      this.cache = folders;
      this.cacheAt = now;
      // Disabled pending validation: per-build proof logs read as noise in
      // field logs. Re-enable by uncommenting once artifact configuration is validated.
      // Proof log: the exact admin rules this collection cycle will run under, so the Output
      // panel shows verbatim what the dashboard Artifact Configuration page dictated.
      // Logger.log(`[ArtifactConfig] ADMIN configuration loaded (${folders.length} folders):`);
      // for (const f of folders) {
      //   Logger.log(
      //     `[ArtifactConfig]   ${f.folderPath} [${f.isEnabled ? 'ENABLED' : 'DISABLED'}] ` +
      //     `include: [${f.includePatterns.join(', ') || '-'}] ` +
      //     `exclude: [${f.excludePatterns.join(', ') || '-'}]`
      //   );
      // }
      return folders;
    } catch (err) {
      Logger.log(`[ArtifactConfig] fetch failed - using legacy collection rules: ${err}`);
      return this.cache;
    }
  }

  /** Map the NATIVE rules model onto the collector's folder shape (same semantics as the
   *  backend bridge): enabled folder-level INCLUDE rules become enabled folders; enabled
   *  folder-level EXCLUDE rules remove that folder; enabled file-level EXCLUDE rules become
   *  per-folder name excludes. File-level INCLUDE rules NARROW their folder's collection to
   *  those name patterns (570-file TD5 field report: wildcard swept whole proc trees).
   *  A folder with NO folder-scoped file-level include collects the shipped artifact types only
   *  (*.log, *.txt - or the user's own list from Configure File Handling) plus any folder-less
   *  file-level INCLUDE the admin added. It used to collect everything ('*'), which is how files
   *  that are neither .log nor .txt reached the confirm dialog. */
  private static foldersFromRules(raw: unknown): RemoteArtifactFolder[] | null {
    if (!Array.isArray(raw)) { return null; }
    const heads: string[] = [];
    const excludedHeads = new Set<string>();
    const fileExcludes: string[] = [];
    const fileIncludesByHead = new Map<string, string[]>();
    const globalFileIncludes: string[] = [];
    const seen = new Set<string>();
    for (const entry of raw) {
      if (!entry || typeof entry !== 'object') { continue; }
      const r = entry as Record<string, unknown>;
      if (r.enabled !== true) { continue; }
      const ruleType = String(r.ruleType || '').toUpperCase();
      const resource = String(r.resourceType || '').toUpperCase();
      const glob = String(r.globPattern || '').trim().replace(/\\/g, '/');
      if (!glob) { continue; }
      if ((resource === 'FOLDER' || resource === 'FOLDER_RECURSIVE')) {
        const head = glob.replace(/^\/+|\/+$/g, '').split('/')[0].replace(/\*/g, '').trim();
        if (!head) { continue; }
        if (ruleType === 'INCLUDE') {
          if (!seen.has(head.toLowerCase())) {
            seen.add(head.toLowerCase());
            heads.push(head);
          }
        } else if (ruleType === 'EXCLUDE') {
          excludedHeads.add(head.toLowerCase());
        }
      } else if (resource === 'FILE' && ruleType === 'EXCLUDE') {
        const base = glob.replace(/\/+$/g, '').split('/').pop()?.trim() || '';
        if (base && !fileExcludes.includes(base)) { fileExcludes.push(base); }
      } else if (resource === 'FILE' && ruleType === 'INCLUDE') {
        // Only FOLDER-SCOPED file includes ('proc/*.log') narrow their folder. Folder-less ones
        // ('*.txt', '**/x.log') are additive hints and must NEVER shrink a folder's coverage —
        // narrowing on them re-broke log/debug.log collection as soon as any
        // global rule existed in the store.
        const parts = glob.replace(/^\/+|\/+$/g, '').split('/').filter(Boolean);
        const base = parts[parts.length - 1]?.trim() || '';
        if (!base) { continue; }
        const headKey = parts.length > 1 ? parts[0].replace(/\*/g, '').trim().toLowerCase() : '';
        if (headKey) {
          const list = fileIncludesByHead.get(headKey) || [];
          if (!list.includes(base)) { list.push(base); }
          fileIncludesByHead.set(headKey, list);
        } else if (!globalFileIncludes.includes(base)) {
          globalFileIncludes.push(base);
        }
      }
    }
    const kept = heads.filter(h => !excludedHeads.has(h.toLowerCase()));
    if (kept.length === 0) { return null; }
    const defaultNames = this.defaultNamePatterns();
    return kept.map(head => {
      const specific = fileIncludesByHead.get(head.toLowerCase()) || [];
      return {
        folderName: head,
        folderPath: head,
        isEnabled: true,
        includePatterns: specific.length > 0
          ? specific
          : [...defaultNames, ...globalFileIncludes.filter(p => !defaultNames.includes(p))],
        excludePatterns: [...fileExcludes],
      };
    });
  }

  /** The artifact types collected when the admin rules name a folder but no file pattern for it:
   *  the shipped .log/.txt list, or the user's own list from Configure File Handling. */
  private static defaultNamePatterns(): string[] {
    const exts = Array.from(FileHandlingConfig.getEffectiveArtifactExtensions());
    return exts.map(e => `*${e.startsWith('.') ? e : `.${e}`}`);
  }

  private static parseFolders(raw: unknown): RemoteArtifactFolder[] | null {
    if (!Array.isArray(raw)) { return null; }
    const folders: RemoteArtifactFolder[] = [];
    for (const entry of raw) {
      if (!entry || typeof entry !== 'object') { continue; }
      const e = entry as Record<string, unknown>;
      const folderPath = String(e.folder_path || '').trim();
      if (!folderPath) { continue; }
      folders.push({
        folderName: String(e.folder_name || folderPath).trim(),
        folderPath,
        isEnabled: e.is_enabled === true,
        includePatterns: this.parsePatterns(e.include_patterns),
        excludePatterns: this.parsePatterns(e.exclude_patterns),
      });
    }
    return folders.length > 0 ? folders : null;
  }

  private static parsePatterns(raw: unknown): string[] {
    if (!Array.isArray(raw)) { return []; }
    return raw
      .map(p => String((p as Record<string, unknown>)?.pattern ?? p ?? '').trim())
      .filter(Boolean);
  }

  /** '*.log' -> /^.*\.log$/i — file-name matching identical to the backend's fnmatch use. */
  private static patternToRegex(pattern: string): RegExp {
    const escaped = pattern.trim().replace(/[.+^${}()|[\]\\?]/g, '\\$&').replace(/\*/g, '.*');
    return new RegExp(`^${escaped}$`, 'i');
  }

  /** Exclude beats include; no include match => not collected. */
  public static fileMatchesFolder(fileName: string, folder: RemoteArtifactFolder): boolean {
    const name = String(fileName || '');
    for (const pattern of folder.excludePatterns) {
      if (this.patternToRegex(pattern).test(name)) { return false; }
    }
    for (const pattern of folder.includePatterns) {
      if (this.patternToRegex(pattern).test(name)) { return true; }
    }
    return false;
  }
}
