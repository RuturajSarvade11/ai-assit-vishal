import * as vscode from 'vscode';

export class DiffParser {

  public static async getFunctionRanges(content: string, ext: string, filePath: string): Promise<Array<{ name: string; start: number; end: number }>> {
    let ranges: Array<{ name: string; start: number; end: number }> = [];

    if (ext === '.h') {
      ranges = this.parseHeaderFile(content);
    } else if (['.c', '.cpp', '.hpp'].includes(ext)) {
      ranges = this.parseCFunctions(content);
    } else if (ext === '.kt') {
      ranges = this.parseKotlinFunctions(content);
    } else if (ext === '.kts') {
      ranges = this.parseKtsBlocks(content);
    } else if (['.xml', '.logxml', '.lockxml', '.cdb', '.afx'].includes(ext)) {
      ranges = this.parseXmlBlocks(content);
    } else if (ext === '.ant') {
      ranges = this.parseAntFile(content);
    }
    else if (ext === '.grl') {
      ranges = this.parseGrlBlocks(content);
    } else if (ext === '.tex') {
      ranges = this.parseLatexSections(content);
    } else {
      try {
        // Use VS Code built-in symbol provider for other languages (TS, JS, etc.)
        const symbols = await vscode.commands.executeCommand<vscode.DocumentSymbol[]>(
          'vscode.executeDocumentSymbolProvider',
          vscode.Uri.file(filePath)
        );
        if (symbols) { this.collectSymbols(symbols, ranges); }
      } catch { }
    }
    return ranges;
  }

  // VS Code Symbol fallback
  private static collectSymbols(symbols: vscode.DocumentSymbol[], out: any[]) {
    for (const s of symbols) {
      if (s.kind === vscode.SymbolKind.Function || s.kind === vscode.SymbolKind.Method || s.kind === vscode.SymbolKind.Constructor) {
        out.push({ name: s.name, start: s.range.start.line, end: s.range.end.line });
      }
      if (s.children.length) { this.collectSymbols(s.children, out); }
    }
  }

  // C / C++
  private static parseCFunctions(code: string) {
    const lines = code.split('\n');
    const results: any[] = [];
    const signatureRegex = /^\s*(?:static\s+|extern\s+|inline\s+)?[a-zA-Z_][\w\s\*]*\s+([a-zA-Z_]\w*)\s*\([^;]*\)/;
    let i = 0;
    while (i < lines.length) {
      const match = lines[i].match(signatureRegex);
      if (!match) { i++; continue; }
      const name = match[1];
      const start = i;
      let braceLine = i;

      while (braceLine < lines.length && !lines[braceLine].includes('{')) { braceLine++; }

      if (braceLine >= lines.length) { i++; continue; }

      let braceCount = 0;
      let end = braceLine;

      for (let j = braceLine; j < lines.length; j++) {
        for (const ch of lines[j]) {
          if (ch === '{') {braceCount++;}
          if (ch === '}') {braceCount--;}
        }
        if (braceCount === 0 && j > braceLine) { end = j; break; }
      }

      results.push({ name, start, end });
      i = end + 1;
    }
    return results;
  }

  // Kotlin
  private static parseKotlinFunctions(code: string) {
    const lines = code.split('\n');
    const results: any[] = [];
    const funRegex = /^\s*(?:public|private|protected|internal)?\s*(?:suspend\s+)?fun\s+([a-zA-Z_]\w*)\s*\(/;

    let i = 0;
    while (i < lines.length) {
      const match = lines[i].match(funRegex);
      if (!match) { i++; continue; }

      const name = match[1];
      const start = i;
      let braceLine = i;
      let isExpressionBody = false;

      // Check if it's an expression body function (ends with = instead of {)
      while (braceLine < lines.length && !lines[braceLine].includes('{')) {
        if (lines[braceLine].includes('=')) {
          results.push({ name, start, end: braceLine });
          i = braceLine + 1;
          isExpressionBody = true;
          break;
        }
        braceLine++;
      }

      if (isExpressionBody) {
        continue;
      }

      // Regular function with braces
      let braceCount = 0;
      let end = braceLine;

      for (let j = braceLine; j < lines.length; j++) {
        if (lines[j].includes('{')) {braceCount++;}
        if (lines[j].includes('}')) {braceCount--;}
        if (braceCount === 0 && j > braceLine) { end = j; break; }
      }

      results.push({ name, start, end });
      i = end + 1;
    }
    return results;
  }

  // Gradle Kotlin Script
  private static parseKtsBlocks(code: string) {
    const lines = code.split('\n');
    const results: any[] = [];
    const blockRegex = /^\s*([a-zA-Z_][a-zA-Z0-9_.]*)\s*(?:\([^)]*\))?\s*\{\s*$/;

    let i = 0;
    while (i < lines.length) {
      const match = lines[i].match(blockRegex);
      if (!match) { i++; continue; }

      const name = match[1];
      let braceCount = 0;
      let end = i;

      for (let j = i; j < lines.length; j++) {
        if (lines[j].includes('{')) {braceCount++;}
        if (lines[j].includes('}')) {braceCount--;}
        if (braceCount === 0 && j > i) {
          end = j;
          break;
        }
      }

      results.push({ name, start: i, end });
      i = end + 1;
    }
    return results;
  }

  // XML / CDB / AFX / LOGXML / LOCKXML
  private static parseXmlBlocks(code: string) {
    const lines = code.split('\n');
    const results: any[] = [];
    const tagRegex = /^\s*<([a-zA-Z_][\w\-.]*)(\s[^>]*)?>/;

    const stack: Array<{ name: string; start: number }> = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      const openMatch = line.match(tagRegex);
      if (openMatch && !line.includes('/>')) {
        stack.push({ name: openMatch[1], start: i });
      }

      const closeMatch = line.match(/<\/([a-zA-Z_][\w\-.]*)>/);
      if (closeMatch) {
        const last = stack.pop();
        if (last && last.name === closeMatch[1]) {
          results.push({
            name: `<${last.name}>`,
            start: last.start,
            end: i
          });
        }
      }
    }

    return results;
  }

  // LaTeX (.tex)
  private static parseLatexSections(code: string) {
    const lines = code.split('\n');
    const results: any[] = [];
    const sectionRegex =
      /^\s*\\(section|subsection|subsubsection)\{(.+?)\}/;

    let current: any = null;

    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(sectionRegex);
      if (match) {
        if (current) {
          current.end = i - 1;
          results.push(current);
        }
        current = {
          name: `${match[1]}: ${match[2]}`,
          start: i,
          end: i
        };
      }
    }

    if (current) {
      current.end = lines.length - 1;
      results.push(current);
    }

    return results;
  }

  // Apache Ant (.ant)
  private static parseAntFile(code: string) {
    const lines = code.split('\n');
    const results: Array<{ name: string; start: number; end: number }> = [];

    // Ant-relevant tags
    const openTagRegex = /^\s*<\s*(project|target|macrodef|taskdef|presetdef|property|import)\b([^>]*)?>/i;
    const closeTagRegex = /^\s*<\/\s*(project|target|macrodef|taskdef|presetdef)\s*>/i;

    const stack: Array<{ name: string; start: number; tag: string }> = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Opening tag
      const openMatch = line.match(openTagRegex);
      if (openMatch && !line.includes('/>')) {
        const tag = openMatch[1];

        // Extract name / id / target name if present
        const nameMatch =
          line.match(/\bname\s*=\s*"([^"]+)"/) ||
          line.match(/\bid\s*=\s*"([^"]+)"/);

        const displayName = nameMatch
          ? `${tag}: ${nameMatch[1]}`
          : `<${tag}>`;

        stack.push({
          tag,
          name: displayName,
          start: i
        });
        continue;
      }

      // Closing tag
      const closeMatch = line.match(closeTagRegex);
      if (closeMatch) {
        const tag = closeMatch[1];

        // Find matching open tag (stack-safe)
        for (let s = stack.length - 1; s >= 0; s--) {
          if (stack[s].tag === tag) {
            const block = stack.splice(s, 1)[0];
            results.push({
              name: block.name,
              start: block.start,
              end: i
            });
            break;
          }
        }
      }
    }

    return results;
  }
  // GRL (.grl) – rule / graph language
  private static parseGrlBlocks(code: string) {
    const lines = code.split('\n');
    const results: Array<{ name: string; start: number; end: number }> = [];

    const blockRegex =
      /^\s*(rule|graph|node|function|action|when|then)\s+([a-zA-Z_]\w*)?.*\{\s*$/i;

    let i = 0;

    while (i < lines.length) {
      const match = lines[i].match(blockRegex);
      if (!match) {
        i++;
        continue;
      }

      const type = match[1];
      const name = match[2] ?? '<anonymous>';
      const start = i;

      let braceCount = 0;
      let end = i;

      for (let j = i; j < lines.length; j++) {
        for (const ch of lines[j]) {
          if (ch === '{') {braceCount++;}
          if (ch === '}') {braceCount--;}
        }
        if (braceCount === 0 && j > i) {
          end = j;
          break;
        }
      }

      results.push({
        name: `${type}: ${name}`,
        start,
        end
      });

      i = end + 1;
    }

    return results;
  }


  // Header (.h)
  private static parseHeaderFile(code: string) {
    const lines = code.split('\n');
    const results: any[] = [];

    const functionDecl = /^\s*(?:extern|static|inline)?\s*[a-zA-Z_][\w\s\*]*\s+([a-zA-Z_]\w*)\s*\([^;]*\)\s*;/;
    const macroDecl = /^\s*#define\s+([A-Z_][A-Z0-9_]*)/;
    const inlineFunctionStart = /^\s*(?:inline|static\s+inline)\s+[a-zA-Z_][\w\s\*]*\s+([a-zA-Z_]\w*)\s*\([^)]*\)\s*\{/;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line || line.startsWith('//') || line.startsWith('/*')) {continue;}

      // Check for inline function with body
      let match = line.match(inlineFunctionStart);
      if (match) {
        const name = match[1];
        const start = i;
        let braceCount = 0;
        let end = i;

        // Count braces to find end of function
        for (let j = i; j < lines.length; j++) {
          const l = lines[j];
          for (const char of l) {
            if (char === '{') {braceCount++;}
            if (char === '}') {braceCount--;}
          }
          if (braceCount === 0 && j >= i) {
            end = j;
            break;
          }
        }
        results.push({ name, start, end });
        i = end;
        continue;
      }

      // Check for function declarations (without body)
      match = line.match(functionDecl);
      if (match) {
        results.push({ name: `${match[1]} (decl)`, start: i, end: i });
        continue;
      }

      // Check for macros
      match = line.match(macroDecl);
      if (match) {
        results.push({ name: `macro ${match[1]}`, start: i, end: i });
      }
    }
    return results;
  }
}