function uniqueRecommendationsByRequestId(recommendations: any[]): any[] {
  const seen = new Set<string>();
  const unique: any[] = [];

  for (const recommendation of recommendations) {
    const requestId = String(recommendation?.request_id || '').trim();
    if (requestId) {
      if (seen.has(requestId)) {
        continue;
      }
      seen.add(requestId);
    }
    unique.push(recommendation);
  }

  return unique;
}

export function renderRecommendationMarkdown(payload: any): string {
  const recommendations = uniqueRecommendationsByRequestId(
    Array.isArray(payload?.recommendations) ? payload.recommendations : []
  );
  const sections: string[] = [];

  // Root-cause / analysis section (matches the Copilot panel).
  const llmAnalysis = String(payload?.llm_analysis || '').trim();
  if (llmAnalysis) {
    sections.push(
      '> ------------------------------------------------------------------',
      '> **LLM Analysis**',
      '> ------------------------------------------------------------------',
      '>'
    );
    for (const line of llmAnalysis.replace(/\r\n/g, '\n').split('\n')) {
      sections.push(`> ${line}`);
    }
    sections.push('>');
  } else {
    // Analysis was omitted by the server (LLM slow/down/disabled). Explain WHY so a missing
    // analysis never looks like a bug — the matched candidates below are still valid.
    const status = String(payload?.llm_analysis_status || 'ok').trim().toLowerCase();
    const notice = String(payload?.llm_analysis_message || '').trim()
      || ({
        timeout: 'AI analysis is temporarily unavailable — the language model did not respond in time '
          + '(busy/rate-limited, or slow network/auth to the AI service). The matched fixes below are still valid — try again in a moment.',
        error: 'AI analysis is temporarily unavailable — the language-model request failed '
          + '(check the AI service network and credentials). The matched fixes below are still valid.',
        disabled: 'AI analysis is turned off in this environment. The matched fixes below are based on historical matches.',
      } as Record<string, string>)[status] || '';
    if (status !== 'ok' && notice) {
      sections.push(
        '> ------------------------------------------------------------------',
        `> ⚠️ **AI analysis unavailable**`,
        '> ------------------------------------------------------------------',
        '>',
        `> ${notice}`,
        '>'
      );
    }
  }

  // Several different fixes tied: tell the reader (Copilot chat too) to compare them.
  if (payload?.decision?.ambiguous === true) {
    sections.push(
      `> ⚖️ **Several fixes match equally well** - ${String(payload.decision.reason || 'compare the candidates before applying one.')}`,
      '>'
    );
  }

  // Top 3 only, one "Candidate N" per recommendation. The backend promotes the
  // LLM-picked fix to the front, so Candidate 1 = recommended (or closest match when
  // there is no pick). Files are nested inside each candidate.
  const topRecommendations = recommendations.slice(0, 3);
  for (let recIdx = 0; recIdx < topRecommendations.length; recIdx++) {
    const recommendation = topRecommendations[recIdx];
    const compareLink = String(recommendation?.compare_diff_link || '').trim();
    const solutions = Array.isArray(recommendation?.solution) ? recommendation.solution : [];

    sections.push('> ------------------------------------------------------------------');
    if (recommendation?.is_recommended === true) {
      const confidence = String(recommendation?.selection_confidence || '').trim();
      const whyThisFix = String(recommendation?.why_this_fix || '').trim();
      sections.push(`> ✅ **Recommended fix${confidence ? ` (confidence: ${confidence})` : ''}**`);
      if (whyThisFix) {
        sections.push(`> _${whyThisFix}_`);
      }
      sections.push('>');
    }
    sections.push(
      `> **Candidate ${recIdx + 1}**`,
      '> ------------------------------------------------------------------',
      `> **Compare:** ${compareLink ? `[Compare Link](${compareLink})` : 'N/A'}`,
      '>'
    );

    // Honest relevance cue when there is no confident pick (rely-on-data).
    if (recommendation?.is_weak_match === true) {
      sections.push('> ⚠ **Possible match — low relevance.** Based on the closest available data; verify before applying.', '>');
    } else if (recommendation?.is_closest_match === true && recommendation?.is_recommended !== true) {
      sections.push('> _Closest available match (no high-confidence pick)._', '>');
    }

    // Developer's own description of how this fix solved the failure (entered at upload time).
    const devNote = String(recommendation?.resolution_description || '').trim();
    if (devNote) {
      sections.push(`> **📝 Developer's note:** ${devNote}`, '>');
    }

    if (solutions.length === 0) {
      sections.push('> **File:** `N/A`', '>', '> **Patch:**', '>', '> ```diff', '> ```', '>');
    } else {
      for (let fileIdx = 0; fileIdx < solutions.length; fileIdx++) {
        const solution = solutions[fileIdx];
        const fileName = String(solution?.fileName || 'Unknown file').trim();
        const changes = Array.isArray(solution?.changes) ? solution.changes : [];
        sections.push(`> ### ${fileIdx + 1}) 📄 \`${fileName}\``, '>', '> **Patch:**', '>', '> ```diff');
        if (changes.length === 0) {
          sections.push('> ');
        } else {
          for (const change of changes) {
            for (const line of String(change || '').replace(/\r\n/g, '\n').split('\n')) {
              sections.push(`> ${line}`);
            }
          }
        }
        sections.push('> ```', '>');
      }
    }
    sections.push('> ------------------------------------------------------------------');
  }

  if (sections.length === 0) {
    return '> No recommendation found for this build error.';
  }

  return sections.join('\n');
}
