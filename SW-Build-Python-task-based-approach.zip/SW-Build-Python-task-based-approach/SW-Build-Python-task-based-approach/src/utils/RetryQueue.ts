import * as fs from 'fs';
import * as path from 'path';
import { Logger } from './Logger';

export interface RetryQueueItem {
  batchId: string;
  timestamp: string;
  attemptCount: number;
  lastAttempt: string;
  data: any;
  type: 'batch' | 'binary' | 'runtime';
}

/**
 * Persistent retry queue for failed uploads
 * Stores failed uploads to disk and retries them later
 */
export class RetryQueue {
  private queueFile: string;
  private maxRetries = 10;
  private maxQueueSize = 50; // Prevent unbounded growth

  constructor(storagePath: string) {
    this.queueFile = path.join(storagePath, 'retry_queue.json');
    this.ensureQueueFile();
  }

  private ensureQueueFile(): void {
    try {
      const dir = path.dirname(this.queueFile);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      // Self-heal: if retry_queue.json accidentally exists as a directory, replace it with a file.
      if (fs.existsSync(this.queueFile) && fs.statSync(this.queueFile).isDirectory()) {
        fs.rmSync(this.queueFile, { recursive: true, force: true });
      }
      if (!fs.existsSync(this.queueFile)) {
        fs.writeFileSync(this.queueFile, JSON.stringify([]), 'utf8');
      }
    } catch (err) {
      Logger.log('[RetryQueue] Failed to ensure queue file', err);
    }
  }

  /**
   * Add a failed upload to the retry queue
   */
  enqueue(batchId: string, data: any, type: 'batch' | 'binary' | 'runtime' = 'batch'): void {
    try {
      const queue = this.loadQueue();
      
      // Check if item already exists
      const existingIndex = queue.findIndex(item => item.batchId === batchId && item.type === type);
      if (existingIndex >= 0) {
        // Update existing item
        queue[existingIndex].attemptCount++;
        queue[existingIndex].lastAttempt = new Date().toISOString();
      } else {
        // Check queue size limit
        if (queue.length >= this.maxQueueSize) {
          queue.shift(); // Remove oldest
        }

        // Add new item
        const item: RetryQueueItem = {
          batchId,
          timestamp: new Date().toISOString(),
          attemptCount: 1,
          lastAttempt: new Date().toISOString(),
          data,
          type
        };
        queue.push(item);
      }
      
      this.saveQueue(queue);
    } catch (err) {
      Logger.log('[RetryQueue] Failed to enqueue item', err);
    }
  }

  /**
   * Get all items ready for retry (not exceeding max retries)
   */
  getRetryableItems(): RetryQueueItem[] {
    try {
      const queue = this.loadQueue();
      return queue.filter(item => item.attemptCount < this.maxRetries);
    } catch (err) {
      Logger.log('[RetryQueue] Failed to get retryable items', err);
      return [];
    }
  }

  /**
   * Remove successfully uploaded item from queue
   */
  remove(batchId: string, type: 'batch' | 'binary' | 'runtime'): void {
    try {
      const queue = this.loadQueue();
      const filtered = queue.filter(item => !(item.batchId === batchId && item.type === type));
      
      if (filtered.length < queue.length) {
        this.saveQueue(filtered);
      }
    } catch (err) {
      Logger.log('[RetryQueue] Failed to remove item', err);
    }
  }

  /**
   * Clear items that exceeded max retries
   */
  clearExpired(): void {
    try {
      const queue = this.loadQueue();
      const valid = queue.filter(item => item.attemptCount < this.maxRetries);
      const removed = queue.length - valid.length;
      
      if (removed > 0) {
        this.saveQueue(valid);
      }
    } catch (err) {
      Logger.log('[RetryQueue] Failed to clear expired items', err);
    }
  }

  /**
   * Get queue size
   */
  size(): number {
    try {
      return this.loadQueue().length;
    } catch (err) {
      return 0;
    }
  }

  private loadQueue(): RetryQueueItem[] {
    try {
      if (!fs.existsSync(this.queueFile)) {
        return [];
      }
      if (fs.statSync(this.queueFile).isDirectory()) {
        fs.rmSync(this.queueFile, { recursive: true, force: true });
        fs.writeFileSync(this.queueFile, JSON.stringify([]), 'utf8');
        return [];
      }
      const content = fs.readFileSync(this.queueFile, 'utf8');
      return JSON.parse(content);
    } catch (err) {
      Logger.log('[RetryQueue] Failed to load queue, returning empty', err);
      return [];
    }
  }

  private saveQueue(queue: RetryQueueItem[]): void {
    try {
      if (fs.existsSync(this.queueFile) && fs.statSync(this.queueFile).isDirectory()) {
        fs.rmSync(this.queueFile, { recursive: true, force: true });
      }
      fs.writeFileSync(this.queueFile, JSON.stringify(queue, null, 2), 'utf8');
    } catch (err) {
      Logger.log('[RetryQueue] Failed to save queue', err);
    }
  }
}
