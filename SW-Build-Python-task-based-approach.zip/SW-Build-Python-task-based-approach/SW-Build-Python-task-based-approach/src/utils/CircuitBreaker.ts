import { Logger } from './Logger';
import { Telemetry } from './Telemetry';

/**
 * Circuit breaker states
 */
export enum CircuitState {
  CLOSED = 'CLOSED',     // Normal operation
  OPEN = 'OPEN',         // Circuit is open, requests fail fast
  HALF_OPEN = 'HALF_OPEN' // Testing if service recovered
}

/**
 * Circuit Breaker pattern implementation
 * Prevents hammering unavailable servers with exponential backoff
 */
export class CircuitBreaker {
  private state: CircuitState = CircuitState.CLOSED;
  private failureCount = 0;
  private lastFailureTime = 0;
  private successCount = 0;

  constructor(
    private threshold: number = 5,           // Failures before opening circuit
    private timeout: number = 60000,         // Time to wait before trying again (ms)
    private halfOpenSuccessThreshold: number = 2,  // Successes needed in half-open to close
    private telemetry?: Telemetry           // Optional telemetry for monitoring
  ) {}

  /**
   * Execute an operation through the circuit breaker.
   * 4xx client errors (bad request, not found, etc.) are NOT counted as failures —
   * they are server-side validation rejections, not connectivity problems.
   */
  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === CircuitState.OPEN) {
      if (Date.now() - this.lastFailureTime >= this.timeout) {
        this.state = CircuitState.HALF_OPEN;
        this.successCount = 0;
        this.telemetry?.recordCircuitBreakerStateChange(CircuitState.HALF_OPEN);
      } else {
        const remainingMs = this.timeout - (Date.now() - this.lastFailureTime);
        throw new Error(`Circuit breaker is OPEN. Retry in ${Math.ceil(remainingMs / 1000)}s`);
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      if (this.shouldCountAsFailure(error)) {
        this.onFailure();
      } else {
        this.onNonCircuitError();
      }
      throw error;
    }
  }

  private parseHttpStatus(error: unknown): number | undefined {
    try {
      const msg = (error as any)?.message || '';
      const parsed = JSON.parse(msg);
      const status = Number(parsed?.status || 0);
      return Number.isFinite(status) && status > 0 ? status : undefined;
    } catch {
      return undefined;
    }
  }

  private shouldCountAsFailure(error: unknown): boolean {
    const status = this.parseHttpStatus(error);

    if (!status) {
      return true;
    }

    return status === 408 || status === 425 || status === 429 || status === 502 || status === 503 || status === 504;
  }

  private onNonCircuitError(): void {
    if (this.state === CircuitState.HALF_OPEN) {
      this.state = CircuitState.CLOSED;
      this.failureCount = 0;
      this.successCount = 0;
      this.lastFailureTime = 0;
      this.telemetry?.recordCircuitBreakerStateChange(CircuitState.CLOSED);
    }
  }

  private onSuccess(): void {
    this.failureCount = 0;
    if (this.state === CircuitState.HALF_OPEN) {
      this.successCount++;
      if (this.successCount >= this.halfOpenSuccessThreshold) {
        this.state = CircuitState.CLOSED;
        this.successCount = 0;
        this.telemetry?.recordCircuitBreakerStateChange(CircuitState.CLOSED);
      }
    }
  }

  private onFailure(): void {
    this.failureCount++;
    this.lastFailureTime = Date.now();

    if (this.state === CircuitState.HALF_OPEN) {
      this.state = CircuitState.OPEN;
      this.successCount = 0;
      Logger.log('[CircuitBreaker] OPEN (failure in half-open)');
      this.telemetry?.recordCircuitBreakerStateChange(CircuitState.OPEN);
    } else if (this.failureCount >= this.threshold) {
      this.state = CircuitState.OPEN;
      Logger.log(`[CircuitBreaker] OPEN after ${this.failureCount} server/network failures`);
      this.telemetry?.recordCircuitBreakerStateChange(CircuitState.OPEN);
    }
  }

  getState(): CircuitState {
    return this.state;
  }

  reset(): void {
    this.state = CircuitState.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
    this.lastFailureTime = 0;
  }
}

/**
 * Exponential backoff utility for retries
 */
export class ExponentialBackoff {
  static async delay(attempt: number, baseDelayMs: number = 1000, maxDelayMs: number = 30000): Promise<void> {
    const delay = Math.min(baseDelayMs * Math.pow(2, attempt - 1), maxDelayMs);
    const jitter = Math.random() * 0.3 * delay;
    return new Promise(resolve => setTimeout(resolve, delay + jitter));
  }
}
