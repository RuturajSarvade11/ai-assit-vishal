import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';

type BackendEnv = 'dev' | 'prod';

type RootConfig = {
  env: string;
};

type EnvConfig = {
  BACKEND_BASE_URL?: string;
  BACKEND_FALLBACK_URL?: string;
};

function normalizeBaseUrl(raw: string | undefined | null): string {
  const value = String(raw || '').trim();

  if (!value) {
    return '';
  }

  return value.endsWith('/') ? value : `${value}/`;
}

function removeTrailingSlash(url: string): string {
  return normalizeBaseUrl(url).replace(/\/$/, '');
}

function getConfigSearchRoots(): string[] {
  const extensionRoot = path.resolve(__dirname, '..', '..');
  return [extensionRoot];
}

function readJsonFromRoots<T>(relativeFilePath: string): T | null {
  for (const root of getConfigSearchRoots()) {
    try {
      const filePath = path.join(root, relativeFilePath);

      if (!fs.existsSync(filePath)) {
        continue;
      }

      const content = fs.readFileSync(filePath, 'utf8').trim();

      if (!content) {
        continue;
      }

      return JSON.parse(content) as T;
    } catch {

    }
  }

  return null;
}

function getBackendEnvironment(): BackendEnv {
  const rootConfig = readJsonFromRoots<RootConfig>(path.join('config', 'config.json'));

  const env = String(rootConfig?.env || 'dev').trim().toLowerCase();

  return env === 'prod' || env === 'production' ? 'prod' : 'dev';
}

function getEnvConfig(environment: BackendEnv): EnvConfig {
  return readJsonFromRoots<EnvConfig>(
    path.join('config', `config.${environment}.json`)
  ) || {};
}

export function getConfiguredBackendUrls(): string[] {
  const vscodeConfig = vscode.workspace.getConfiguration('gradleErrorAssistant');

  const environment = getBackendEnvironment();
  const envConfig = getEnvConfig(environment);


  const primary = normalizeBaseUrl(vscodeConfig.get<string>('backendBaseUrl') || envConfig.BACKEND_BASE_URL);
  const fallback = normalizeBaseUrl(vscodeConfig.get<string>('backendFallbackUrl') || envConfig.BACKEND_FALLBACK_URL);

  return Array.from(new Set([primary, fallback].filter(Boolean)));
}

export function getConfiguredBackendEnvironment(): {
  BACKEND_BASE_URL: string;
  BACKEND_FALLBACK_URL: string;
} {
  const urls = getConfiguredBackendUrls();

  return {
    BACKEND_BASE_URL: removeTrailingSlash(urls[0] || ''),
    BACKEND_FALLBACK_URL: removeTrailingSlash(urls[1] || urls[0] || ''),
  };
}

export function getCurrentBackendEnvironment(): BackendEnv {
  return getBackendEnvironment();
}
