/**
 * LRU (Least Recently Used) Cache implementation
 * Prevents unbounded memory growth by evicting least recently used items
 */
export type LRUCacheOptions<K, V> = {
  maxEntries: number;
  maxBytes?: number;
  sizeCalculator?: (value: V, key: K) => number;
  allowOversizedEntries?: boolean;
};

export class LRUCache<K, V> {
  private cache = new Map<K, { value: V; size: number }>();
  private readonly maxEntries: number;
  private readonly maxBytes?: number;
  private readonly sizeCalculator: (value: V, key: K) => number;
  private readonly allowOversizedEntries: boolean;
  private totalBytes = 0;

  constructor(maxSizeOrOptions: number | LRUCacheOptions<K, V>) {
    if (typeof maxSizeOrOptions === 'number') {
      this.maxEntries = maxSizeOrOptions;
      this.maxBytes = undefined;
      this.sizeCalculator = () => 1;
      this.allowOversizedEntries = false;
      return;
    }

    this.maxEntries = maxSizeOrOptions.maxEntries;
    this.maxBytes = maxSizeOrOptions.maxBytes;
    this.sizeCalculator = maxSizeOrOptions.sizeCalculator || (() => 1);
    this.allowOversizedEntries = !!maxSizeOrOptions.allowOversizedEntries;
  }

  get(key: K): V | undefined {
    if (!this.cache.has(key)) {
      return undefined;
    }
    
    // Move to end (most recently used)
    const entry = this.cache.get(key)!;
    this.cache.delete(key);
    this.cache.set(key, entry);
    return entry.value;
  }

  set(key: K, value: V): void {
    const size = Math.max(0, this.sizeCalculator(value, key));

    if (this.cache.has(key)) {
      this.delete(key);
    }

    if (this.maxBytes !== undefined && size > this.maxBytes && !this.allowOversizedEntries) {
      return;
    }

    this.cache.set(key, { value, size });
    this.totalBytes += size;

    this.evictIfNeeded();
  }

  private evictIfNeeded(): void {
    while (
      this.cache.size > this.maxEntries
      || (this.maxBytes !== undefined && this.totalBytes > this.maxBytes)
    ) {
      if (
        this.allowOversizedEntries
        && this.cache.size === 1
        && this.maxBytes !== undefined
        && this.totalBytes > this.maxBytes
      ) {
        break;
      }

      const first = this.cache.entries().next().value;
      if (!first) {
        break;
      }

      const [firstKey, firstEntry] = first;
      this.cache.delete(firstKey);
      this.totalBytes -= firstEntry.size;
      if (this.totalBytes < 0) {
        this.totalBytes = 0;
      }
    }
  }

  has(key: K): boolean {
    return this.cache.has(key);
  }

  delete(key: K): boolean {
    const entry = this.cache.get(key);
    if (!entry) {
      return false;
    }

    this.cache.delete(key);
    this.totalBytes -= entry.size;
    if (this.totalBytes < 0) {
      this.totalBytes = 0;
    }
    return true;
  }

  clear(): void {
    this.cache.clear();
    this.totalBytes = 0;
  }

  get size(): number {
    return this.cache.size;
  }

  get bytes(): number {
    return this.totalBytes;
  }

  keys(): IterableIterator<K> {
    return this.cache.keys();
  }

  *values(): IterableIterator<V> {
    for (const entry of this.cache.values()) {
      yield entry.value;
    }
  }

  *entries(): IterableIterator<[K, V]> {
    for (const [key, entry] of this.cache.entries()) {
      yield [key, entry.value];
    }
  }

  forEach(callback: (value: V, key: K) => void): void {
    for (const [key, entry] of this.cache.entries()) {
      callback(entry.value, key);
    }
  }
}
