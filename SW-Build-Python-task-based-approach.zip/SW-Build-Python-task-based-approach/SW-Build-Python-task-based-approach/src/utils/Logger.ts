import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';

export class Logger {
    private static outputChannel: vscode.OutputChannel;
    private static logDir: string | undefined;
    private static readonly RETENTION_DAYS = 14;
    private static prunedThisSession = false;

    public static initialize(channelName: string, storagePath?: string) {
        if (!this.outputChannel) {
            this.outputChannel = vscode.window.createOutputChannel(channelName);
        }
        // Persist logs to disk (date-wise) so intermittent field issues are diagnosable
        // after a reload/restart, when the OutputChannel buffer is already gone.
        if (storagePath && !this.logDir) {
            try {
                this.logDir = path.join(storagePath, 'logs');
                fs.mkdirSync(this.logDir, { recursive: true });
                this.pruneOldLogs();
            } catch {
                this.logDir = undefined; // disk logging is best-effort; never break the extension
            }
        }
    }

    private static format(message: string, data?: any): string {
        const now = new Date();
        const hh = String(now.getHours()).padStart(2, '0');
        const mm = String(now.getMinutes()).padStart(2, '0');
        const ss = String(now.getSeconds()).padStart(2, '0');
        const ms = String(now.getMilliseconds()).padStart(3, '0');
        let logLine = `[${hh}:${mm}:${ss}.${ms}] ${message}`;

        if (data !== undefined && data !== null) {
            try {
                if (data instanceof Error) {
                    logLine += ` | ${data.message}\n${data.stack}`;
                } else if (typeof data === 'object') {
                    logLine += ` | ${JSON.stringify(data)}`;
                } else {
                    logLine += ` | ${String(data)}`;
                }
            } catch {
                logLine += ` | [Unserializable Data]`;
            }
        }
        return logLine;
    }

    /** User-facing milestone log: shows in the "AI Assist" output channel + disk + console. */
    public static log(message: string, data?: any) {
        const logLine = this.format(message, data);
        this.outputChannel?.appendLine(logLine);
        console.log(logLine);
        this.writeToDisk(logLine);
    }

    /**
     * Internal diagnostic log: disk + console ONLY — NOT the visible output channel. Keeps the
     * user-facing channel to clean milestones while the full trace is still persisted to
     * ai-assistant-<date>.log for support/field debugging. Use for verbose internals
     * (per-file event building, session state transitions, pre-upload snapshots, watcher internals).
     */
    public static debug(message: string, data?: any) {
        const logLine = this.format(message, data);
        console.log(logLine);
        this.writeToDisk(logLine);
    }

    private static currentLogFile(): string | undefined {
        if (!this.logDir) { return undefined; }
        // Local-day filename so it matches the local-time timestamps inside each line.
        const d = new Date();
        const date = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        return path.join(this.logDir, `ai-assistant-${date}.log`);
    }

    private static writeToDisk(line: string) {
        const file = this.currentLogFile();
        if (!file) { return; }
        try {
            fs.appendFileSync(file, line + '\n');
        } catch {
            // best-effort; never throw from logging
        }
    }

    private static pruneOldLogs() {
        if (!this.logDir || this.prunedThisSession) { return; }
        this.prunedThisSession = true;
        try {
            const cutoff = Date.now() - this.RETENTION_DAYS * 24 * 60 * 60 * 1000;
            for (const name of fs.readdirSync(this.logDir)) {
                if (!name.startsWith('ai-assistant-') || !name.endsWith('.log')) { continue; }
                const full = path.join(this.logDir, name);
                try {
                    if (fs.statSync(full).mtimeMs < cutoff) {
                        fs.unlinkSync(full);
                    }
                } catch {
                    // skip individual file errors
                }
            }
        } catch {
            // best-effort cleanup
        }
    }

    /** Absolute path of today's log file, for surfacing to the user (e.g. an "open logs" action). */
    public static getLogFilePath(): string | undefined {
        return this.currentLogFile();
    }

    /** Best log file to open: today's if it exists, otherwise the most recently modified one. */
    public static getMostRecentLogFile(): string | undefined {
        if (!this.logDir) { return undefined; }
        const today = this.currentLogFile();
        try {
            if (today && fs.existsSync(today)) { return today; }
            const candidates = fs.readdirSync(this.logDir)
                .filter((name: string) => name.startsWith('ai-assistant-') && name.endsWith('.log'))
                .map((name: string) => {
                    const full = path.join(this.logDir as string, name);
                    return { full, mtime: fs.statSync(full).mtimeMs };
                })
                .sort((a: { mtime: number }, b: { mtime: number }) => b.mtime - a.mtime);
            return candidates.length > 0 ? candidates[0].full : undefined;
        } catch {
            return today;
        }
    }

    /** The logs directory (for surfacing in messages). */
    public static getLogDir(): string | undefined {
        return this.logDir;
    }

    // Optional: Useful if you want a command to reveal the logs to the user
    public static show(preserveFocus: boolean = true) {
        this.outputChannel?.show(preserveFocus);
    }

    public static dispose() {
        this.outputChannel?.dispose();
    }
}
