import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { isBinaryFileSync } from 'isbinaryfile';
import { Logger } from './Logger';

export type FileHandlingConfigData = {
  version: number;
  binaryCustomized: boolean;
  artifactCustomized: boolean;
  customBinaryExtensions: string[];
  customArtifactExtensions: string[];
  updatedAt?: string;
};

export type FileHandlingExtensionData = {
  extension: string;
  count: number;
  isDefaultBinary: boolean;
  isBinarySelected: boolean;
  isDefaultArtifact: boolean;
  isArtifactSelected: boolean;
};

export class FileHandlingConfig {
  private static extensionContext: vscode.ExtensionContext | undefined;
  private static readonly CONFIG_FILE_NAME = 'file-handling-config.json';

  // private static readonly DEFAULT_BINARY_EXTENSIONS = ['.jar', '.zip', '.pack', '.exe', '.dll', '.so', '.dylib', '.bin', '.class', '.pyc', '.mat', '.slx', '.s19', '.tmb', '.tmbz', '.bmd', '.can', '.ptp', '.ptu', '.a2l', '.cal', '.ant', '.tdcl', '.xdm', '.cbd_template', '.h_template', '.vcxproj', '.xsd', '.mf', '.dat'
  // ];

  private static readonly DEFAULT_ARTIFACT_EXTENSIONS = ['.txt', '.log'];

  static initialize(context: vscode.ExtensionContext): void {
    this.extensionContext = context;
    this.ensureGlobalStorageFolder();
  }

  static async migrateWorkspaceSettingsToGlobalStorage(): Promise<void> {
    if (!this.extensionContext) {
      return;
    }

    const existing = this.readConfig();

    if (existing.binaryCustomized && existing.artifactCustomized) {
      return;
    }

    const workspaceConfig = vscode.workspace.getConfiguration('gradleErrorAssistant');
    const oldBinary = workspaceConfig.get<string[]>('customBinaryExtensions') || [];
    const oldArtifact = workspaceConfig.get<string[]>('customArtifactExtensions') || [];

    let changed = false;

    if (!existing.binaryCustomized && oldBinary.length > 0) {
      existing.binaryCustomized = true;
      existing.customBinaryExtensions = this.normalizeExtensions(oldBinary);
      changed = true;
    }

    if (!existing.artifactCustomized && oldArtifact.length > 0) {
      existing.artifactCustomized = true;
      existing.customArtifactExtensions = this.normalizeExtensions(oldArtifact);
      changed = true;
    }

    if (changed) {
      this.writeConfig(existing);
      Logger.log('[FileHandlingConfig] Migrated extension selections from VS Code settings to global storage');
    }
  }

  static getDefaultBinaryExtensions(): Set<string> {
    // Default binary extension detection is handled dynamically by isbinaryfile.
    // The legacy binary extension list is no longer used for actual detection.
    return new Set();
  }

  static getDefaultArtifactExtensions(): Set<string> {
    return new Set(this.DEFAULT_ARTIFACT_EXTENSIONS);
  }

  static getUserBinaryExtensions(): Set<string> {
    const config = this.readConfig();

    if (!config.binaryCustomized) {
      return new Set();
    }

    return new Set(this.normalizeExtensions(config.customBinaryExtensions || []));
  }

  static getUserArtifactExtensions(): Set<string> {
    const config = this.readConfig();

    if (!config.artifactCustomized) {
      return new Set();
    }

    return new Set(this.normalizeExtensions(config.customArtifactExtensions || []));
  }

  static isBinaryCustomized(): boolean {
    return this.readConfig().binaryCustomized;
  }

  static isArtifactCustomized(): boolean {
    return this.readConfig().artifactCustomized;
  }

  static saveUserBinaryExtensions(extensions: string[]): void {
    const config = this.readConfig();

    config.version = 1;
    config.binaryCustomized = true;
    config.customBinaryExtensions = this.normalizeExtensions(extensions);
    config.updatedAt = new Date().toISOString();

    this.writeConfig(config);
  }

  static saveUserArtifactExtensions(extensions: string[]): void {
    const config = this.readConfig();

    config.version = 1;
    config.artifactCustomized = true;
    config.customArtifactExtensions = this.normalizeExtensions(extensions);
    config.updatedAt = new Date().toISOString();

    this.writeConfig(config);
  }

  static resetBinaryExtensionsToDefaults(): void {
    const config = this.readConfig();

    config.version = 1;
    config.binaryCustomized = false;
    config.customBinaryExtensions = [];
    config.updatedAt = new Date().toISOString();

    this.writeConfig(config);
  }

  static resetArtifactExtensionsToDefaults(): void {
    const config = this.readConfig();

    config.version = 1;
    config.artifactCustomized = false;
    config.customArtifactExtensions = [];
    config.updatedAt = new Date().toISOString();

    this.writeConfig(config);
  }

  static getEffectiveBinaryExtensions(): Set<string> {
    const config = this.readConfig();

    if (config.binaryCustomized) {
      return new Set(this.normalizeExtensions(config.customBinaryExtensions || []));
    }

    return new Set();
  }

  static getEffectiveArtifactExtensions(): Set<string> {
    const config = this.readConfig();

    if (config.artifactCustomized) {
      return new Set(this.normalizeExtensions(config.customArtifactExtensions || []));
    }

    return this.getDefaultArtifactExtensions();
  }

  static isBinaryFile(filePath: string): boolean {
    try {
      if (fs.existsSync(filePath)) {
        return isBinaryFileSync(filePath);
      }
    } catch (error) {
      Logger.log('[FileHandlingConfig] Failed to detect binary file via isbinaryfile', error);
    }

    // Legacy extension-based detection preserved for rollback:
    // const ext = this.getExtension(filePath);
    // return !!ext && this.getEffectiveBinaryExtensions().has(ext);

    const ext = this.getExtension(filePath);
    return !!ext && this.getEffectiveBinaryExtensions().has(ext);
  }

  static isArtifactFile(filePath: string): boolean {
    const ext = this.getExtension(filePath);
    return !!ext && this.getEffectiveArtifactExtensions().has(ext);
  }

  static convertExtensionsToData(
    extensionCounts: Map<string, number>,
    detectedBinaryExtensions: Set<string>
  ): FileHandlingExtensionData[] {
    const defaultArtifact = this.getDefaultArtifactExtensions();

    const effectiveBinary = this.getEffectiveBinaryExtensions();
    const effectiveArtifact = this.getEffectiveArtifactExtensions();
    const selectedBinaryExtensions = effectiveBinary.size > 0 ? effectiveBinary : detectedBinaryExtensions;

    const allExtensions = new Set<string>([
      ...Array.from(extensionCounts.keys())
        .map((ext) => this.normalizeExtension(ext))
        .filter(Boolean),
      ...Array.from(defaultArtifact),
      ...Array.from(selectedBinaryExtensions),
      ...Array.from(effectiveArtifact)
    ]);

    const result = Array.from(allExtensions).map((extension) => ({
      extension,
      count: extensionCounts.get(extension) || 0,
      isDefaultBinary: false,
      isBinarySelected: selectedBinaryExtensions.has(extension),
      isDefaultArtifact: defaultArtifact.has(extension),
      isArtifactSelected: effectiveArtifact.has(extension)
    }));

    result.sort((a, b) => {
      const aSelected = a.isBinarySelected || a.isArtifactSelected;
      const bSelected = b.isBinarySelected || b.isArtifactSelected;

      if (aSelected !== bSelected) {
        return aSelected ? -1 : 1;
      }

      return a.extension.localeCompare(b.extension);
    });

    return result;
  }

  static normalizeExtensions(extensions: string[]): string[] {
    return Array.from(
      new Set(
        (extensions || [])
          .map((ext) => this.normalizeExtension(ext))
          .filter(Boolean)
      )
    ).sort();
  }

  static normalizeExtension(extension: string): string {
    const value = String(extension || '').trim().toLowerCase();

    if (!value) {
      return '';
    }

    return value.startsWith('.') ? value : `.${value}`;
  }

  static getExtension(filePath: string): string {
    const fileName = path.basename(String(filePath || '')).toLowerCase();

    const config = this.readConfig();
    const customBinaryExtensions = this.normalizeExtensions(config.customBinaryExtensions || []);
    const customArtifactExtensions = this.normalizeExtensions(config.customArtifactExtensions || []);

    const specialExtensions = [
      ...this.DEFAULT_ARTIFACT_EXTENSIONS,
      ...customBinaryExtensions,
      ...customArtifactExtensions
    ]
      .filter((ext) => ext.includes('_'))
      .sort((a, b) => b.length - a.length);

    for (const specialExt of specialExtensions) {
      if (fileName.endsWith(specialExt)) {
        return specialExt;
      }
    }

    const ext = path.extname(fileName).toLowerCase();
    if (!ext && fileName.startsWith('.')) {
      // Dotfiles have NO extname in Node — for files like Eclipse's wrk/.metadata/.log the
      // basename itself IS the extension (.log, .txt). Return it so such logs match the
      // artifact filter (previously build/<target>/<task>/wrk/.metadata/.log was skipped).
      return fileName;
    }
    return ext;
  }

  static getConfigFilePath(): string {
    if (!this.extensionContext) {
      return '';
    }

    return path.join(this.extensionContext.globalStorageUri.fsPath, this.CONFIG_FILE_NAME);
  }

  private static readConfig(): FileHandlingConfigData {
    const empty: FileHandlingConfigData = {
      version: 1,
      binaryCustomized: false,
      artifactCustomized: false,
      customBinaryExtensions: [],
      customArtifactExtensions: []
    };

    const filePath = this.getConfigFilePath();

    if (!filePath) {
      return empty;
    }

    try {
      if (!fs.existsSync(filePath)) {
        return empty;
      }

      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8')) as Partial<FileHandlingConfigData>;

      return {
        version: Number(parsed.version || 1),
        binaryCustomized: !!parsed.binaryCustomized,
        artifactCustomized: !!parsed.artifactCustomized,
        customBinaryExtensions: this.normalizeExtensions(parsed.customBinaryExtensions || []),
        customArtifactExtensions: this.normalizeExtensions(parsed.customArtifactExtensions || []),
        updatedAt: parsed.updatedAt
      };
    } catch (error) {
      Logger.log('[FileHandlingConfig] Failed to read file-handling config', error);
      return empty;
    }
  }

  private static writeConfig(config: FileHandlingConfigData): void {
    const filePath = this.getConfigFilePath();

    if (!filePath) {
      return;
    }

    try {
      this.ensureGlobalStorageFolder();

      const payload: FileHandlingConfigData = {
        version: 1,
        binaryCustomized: !!config.binaryCustomized,
        artifactCustomized: !!config.artifactCustomized,
        customBinaryExtensions: this.normalizeExtensions(config.customBinaryExtensions || []),
        customArtifactExtensions: this.normalizeExtensions(config.customArtifactExtensions || []),
        updatedAt: new Date().toISOString()
      };

      fs.writeFileSync(filePath, JSON.stringify(payload, null, 2), 'utf8');
    } catch (error) {
      Logger.log('[FileHandlingConfig] Failed to write file-handling config', error);
    }
  }

  private static ensureGlobalStorageFolder(): void {
    try {
      const folder = this.extensionContext?.globalStorageUri.fsPath;

      if (folder && !fs.existsSync(folder)) {
        fs.mkdirSync(folder, { recursive: true });
      }
    } catch {
      // ignore storage creation failures
    }
  }
}