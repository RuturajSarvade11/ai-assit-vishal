import { Logger } from './Logger';

/**
 * Admin "System Tracking Configuration" (dashboard, GET /api/system-tracking/patterns): the
 * file-change-tracking INCLUSION list. Decides WHICH workspace files/folders are monitored
 * during build-failure analysis — the dashboard-managed replacement for the hardcoded list in
 * FileUtils.isIncludedForTracking.
 *
 * Matching semantics (must stay identical to the backend service system_tracking.py):
 *   - glob on the WORKSPACE-RELATIVE path, '/'-separated, case-insensitive
 *   - '**' crosses folder boundaries, '*' stays within one segment, '?' one char in a segment
 *   - a pattern without '/' therefore matches ROOT-LEVEL entries only (e.g. settings.gradle.kts)
 *   - disabled (status=false) patterns never participate; a file is tracked if ANY enabled
 *     pattern matches; the existing noise filters (FileUtils.shouldIgnore) still apply ON TOP
 *
 * FAIL-OPEN: if the backend is unreachable or the payload is malformed/empty, the last known
 * config keeps applying; with none ever loaded, callers fall back to the legacy hardcoded list —
 * so tracking never breaks because the dashboard is down, and behavior without a reachable
 * backend is exactly the shipped package's.
 */
export type TrackingPattern = {
  status: boolean;
  resource: string;          // "Folder" | "Folder(Recursive)" | "File" (informational; the glob decides)
  globPattern: string;
};

type TrackingApi = { getSystemTrackingPatterns(): Promise<any> };

export class TrackingConfigService {
  private static readonly CACHE_TTL_MS = 60_000;
  private static cacheAt = 0;
  // The patterns consulted SYNCHRONOUSLY by FileUtils on every file event. null = never loaded
  // => legacy hardcoded rules apply.
  private static active: TrackingPattern[] | null = null;
  private static regexCache = new Map<string, RegExp>();

  public static getActivePatterns(): TrackingPattern[] | null {
    return this.active;
  }

  /** Refresh (60s cache). Never throws; on failure the previous config (or legacy) keeps applying. */
  public static async load(apiService: TrackingApi): Promise<TrackingPattern[] | null> {
    const now = Date.now();
    if (this.active && (now - this.cacheAt) < this.CACHE_TTL_MS) {
      return this.active;
    }
    try {
      const resp = await apiService.getSystemTrackingPatterns();
      const data = resp?.data || resp;
      const parsed = this.parsePatterns(data?.tracking_patterns);
      if (!parsed) {
        Logger.log('[TrackingConfig] malformed/empty remote config - keeping '
          + (this.active ? 'last known rules' : 'legacy tracking rules'));
        return this.active;
      }
      this.active = parsed;
      this.cacheAt = now;
      return parsed;
    } catch (err) {
      Logger.log(`[TrackingConfig] fetch failed - keeping ${this.active ? 'last known' : 'legacy'} tracking rules: ${err}`);
      return this.active;
    }
  }

  private static parsePatterns(raw: unknown): TrackingPattern[] | null {
    if (!Array.isArray(raw)) { return null; }
    const patterns: TrackingPattern[] = [];
    for (const entry of raw) {
      if (!entry || typeof entry !== 'object') { continue; }
      const e = entry as Record<string, unknown>;
      const globPattern = String(e.glob_pattern || '').trim().replace(/\\/g, '/');
      if (!globPattern) { continue; }
      patterns.push({
        status: e.status === true,
        resource: String(e.resource || '').trim(),
        globPattern,
      });
    }
    // Empty => treat like malformed and keep previous/legacy rules (fail-safe: a broken response
    // must never silently stop ALL tracking). Admins wanting "track nothing" disable entries.
    return patterns.length > 0 ? patterns : null;
  }

  /** '**' -> any (crosses '/'), '*' -> within-segment, '?' -> one within-segment char. */
  private static toRegex(glob: string): RegExp {
    let rx = this.regexCache.get(glob);
    if (rx) { return rx; }
    const escaped = glob
      .replace(/[.+^${}()|[\]\\]/g, '\\$&')
      .replace(/\*\*/g, '\u0000')   // placeholder: cannot occur in a real pattern
      .replace(/\*/g, '[^/]*')
      .replace(/\?/g, '[^/]')
      .replace(/\u0000/g, '.*');
    rx = new RegExp(`^${escaped}$`, 'i');
    this.regexCache.set(glob, rx);
    return rx;
  }

  /** relPath: workspace-relative, any separators. True if ANY enabled pattern matches. */
  public static isTracked(relPath: string, patterns: TrackingPattern[]): boolean {
    const rel = String(relPath || '').replace(/\\/g, '/').replace(/^\/+/, '');
    if (!rel) { return false; }
    for (const p of patterns) {
      if (!p.status) { continue; }
      if (this.toRegex(p.globPattern).test(rel)) { return true; }
    }
    return false;
  }
}
