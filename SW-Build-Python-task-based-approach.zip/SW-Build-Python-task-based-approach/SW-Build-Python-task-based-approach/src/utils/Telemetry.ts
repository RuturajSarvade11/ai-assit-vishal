import * as fs from 'fs';
import * as path from 'path';
import { Logger } from './Logger';

export interface TelemetryMetrics {
  timestamp: string;
  sessionDuration: number;
  fileWatcherStats: {
    filesWatched: number;
    textFilesProcessed: number;
    binaryFilesProcessed: number;
    cacheHitRate: number;
  };
  uploadStats: {
    successfulUploads: number;
    failedUploads: number;
    retriedUploads: number;
    totalBytesUploaded: number;
  };
  errorStats: {
    buildErrorsDetected: number;
    sessionsCreated: number;
    sessionsCompleted: number;
  };
  performanceStats: {
    avgFileProcessingTime: number;
    avgUploadTime: number;
  };
  circuitBreakerStats: {
    state: string;
    openCount: number;
    lastOpenTime?: string;
  };
}

/**
 * Telemetry and health metrics system
 * Tracks extension performance, errors, and resource usage
 */
export class Telemetry {
  private metricsFile: string;
  private startTime: number;
  private metrics: Partial<TelemetryMetrics>;

  constructor(storagePath: string) {
    this.metricsFile = path.join(storagePath, 'telemetry.json');
    this.startTime = Date.now();
    this.metrics = this.initializeMetrics();
    this.ensureMetricsFile();
  }

  private initializeMetrics(): Partial<TelemetryMetrics> {
    return {
      timestamp: new Date().toISOString(),
      sessionDuration: 0,
      fileWatcherStats: {
        filesWatched: 0,
        textFilesProcessed: 0,
        binaryFilesProcessed: 0,
        cacheHitRate: 0
      },
      uploadStats: {
        successfulUploads: 0,
        failedUploads: 0,
        retriedUploads: 0,
        totalBytesUploaded: 0
      },
      errorStats: {
        buildErrorsDetected: 0,
        sessionsCreated: 0,
        sessionsCompleted: 0
      },
      performanceStats: {
        avgFileProcessingTime: 0,
        avgUploadTime: 0
      },
      circuitBreakerStats: {
        state: 'CLOSED',
        openCount: 0
      }
    };
  }

  private ensureMetricsFile(): void {
    try {
      const dir = path.dirname(this.metricsFile);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    } catch (err) {
      Logger.log('[Telemetry] Failed to ensure metrics directory', err);
    }
  }

  /**
   * Record file processing event
   */
  recordFileProcessed(isBinary: boolean): void {
    if (isBinary) {
      this.metrics.fileWatcherStats!.binaryFilesProcessed++;
    } else {
      this.metrics.fileWatcherStats!.textFilesProcessed++;
    }
  }

  /**
   * Record upload result
   */
  recordUpload(success: boolean, bytesUploaded?: number, isRetry: boolean = false): void {
    if (success) {
      this.metrics.uploadStats!.successfulUploads++;
      if (bytesUploaded) {
        this.metrics.uploadStats!.totalBytesUploaded += bytesUploaded;
      }
    } else {
      this.metrics.uploadStats!.failedUploads++;
    }
    
    if (isRetry) {
      this.metrics.uploadStats!.retriedUploads++;
    }
  }

  /**
   * Record error session
   */
  recordErrorSession(created: boolean): void {
    if (created) {
      this.metrics.errorStats!.sessionsCreated++;
    } else {
      this.metrics.errorStats!.sessionsCompleted++;
    }
  }

  /**
   * Record build errors
   */
  recordBuildErrors(count: number): void {
    this.metrics.errorStats!.buildErrorsDetected += count;
  }

  /**
   * Update cache statistics
   */
  updateCacheStats(hits: number, total: number): void {
    if (total > 0) {
      this.metrics.fileWatcherStats!.cacheHitRate = (hits / total) * 100;
    }
  }

  /**
   * Record circuit breaker state change
   */
  recordCircuitBreakerStateChange(state: string): void {
    const wasOpen = this.metrics.circuitBreakerStats!.state === 'OPEN';
    this.metrics.circuitBreakerStats!.state = state;
    
    if (state === 'OPEN' && !wasOpen) {
      this.metrics.circuitBreakerStats!.openCount++;
      this.metrics.circuitBreakerStats!.lastOpenTime = new Date().toISOString();
    }
  }

  /**
   * Record processing time
   */
  recordProcessingTime(timeMs: number, isUpload: boolean = false): void {
    if (isUpload) {
      // Moving average
      const current = this.metrics.performanceStats!.avgUploadTime;
      this.metrics.performanceStats!.avgUploadTime = current === 0 ? timeMs : (current + timeMs) / 2;
    } else {
      const current = this.metrics.performanceStats!.avgFileProcessingTime;
      this.metrics.performanceStats!.avgFileProcessingTime = current === 0 ? timeMs : (current + timeMs) / 2;
    }
  }

  /**
   * Save metrics to disk
   */
  save(): void {
    try {
      this.metrics.sessionDuration = Date.now() - this.startTime;
      this.metrics.timestamp = new Date().toISOString();
      
      const metricsJson = JSON.stringify(this.metrics, null, 2);
      fs.writeFileSync(this.metricsFile, metricsJson, 'utf8');
    } catch (err) {
      Logger.log('[Telemetry] Failed to save metrics', err);
    }
  }

  /**
   * Get current metrics
   */
  getMetrics(): Partial<TelemetryMetrics> {
    this.metrics.sessionDuration = Date.now() - this.startTime;
    return { ...this.metrics };
  }

  /**
   * Log metrics summary
   */
  logSummary(): void {
    const summary = this.getMetrics();
    Logger.log('=== Telemetry Summary ===');
    Logger.log(`Session Duration: ${Math.round(summary.sessionDuration! / 1000)}s`);
    Logger.log(`Files Processed: Text=${summary.fileWatcherStats?.textFilesProcessed}, Binary=${summary.fileWatcherStats?.binaryFilesProcessed}`);
    Logger.log(`Uploads: Success=${summary.uploadStats?.successfulUploads}, Failed=${summary.uploadStats?.failedUploads}, Retried=${summary.uploadStats?.retriedUploads}`);
    Logger.log(`Errors: Detected=${summary.errorStats?.buildErrorsDetected}, Sessions=${summary.errorStats?.sessionsCreated}`);
    Logger.log(`Circuit Breaker: State=${summary.circuitBreakerStats?.state}, Opens=${summary.circuitBreakerStats?.openCount}`);
    Logger.log('========================');
  }
}
