import * as fs from 'fs';
import * as path from 'path';

/**
 * Local disk-cache inspection and cleanup for the extension's globalStorage area.
 * Used by the "Cache Status" and "Clear Cache" commands so the on-disk footprint is
 * visible and controllable (enterprise operability).
 */

export interface CacheEntry {
    name: string;
    path: string;
    bytes: number;
}

// Top-level cache folders under globalStorage that hold transient tracking/snapshot data.
// Logs and configuration are intentionally NOT in this list so they survive a cache clear.
export const CLEARABLE_CACHE_DIRS = [
    'ai-assisted-tracking',
    'ai-assisted-disk-cache',
];

function directorySize(dir: string): number {
    let total = 0;
    const stack: string[] = [dir];
    while (stack.length > 0) {
        const current = stack.pop() as string;
        let entries: fs.Dirent[];
        try {
            entries = fs.readdirSync(current, { withFileTypes: true });
        } catch {
            continue;
        }
        for (const entry of entries) {
            const full = path.join(current, entry.name);
            try {
                if (entry.isDirectory()) {
                    stack.push(full);
                } else {
                    total += fs.statSync(full).size;
                }
            } catch {
                // skip unreadable entries
            }
        }
    }
    return total;
}

/** Size of every top-level folder under globalStorage, largest first. */
export function getCacheStatus(storagePath: string): CacheEntry[] {
    const out: CacheEntry[] = [];
    if (!storagePath) { return out; }
    let names: string[];
    try {
        names = fs.readdirSync(storagePath);
    } catch {
        return out;
    }
    for (const name of names) {
        const full = path.join(storagePath, name);
        try {
            if (fs.statSync(full).isDirectory()) {
                out.push({ name, path: full, bytes: directorySize(full) });
            }
        } catch {
            // skip
        }
    }
    return out.sort((a, b) => b.bytes - a.bytes);
}

/** Remove the given cache folders. Returns per-folder reclaimed bytes + success. */
export function clearCacheDirs(
    storagePath: string,
    names: string[] = CLEARABLE_CACHE_DIRS,
): { name: string; cleared: boolean; bytes: number }[] {
    const results: { name: string; cleared: boolean; bytes: number }[] = [];
    for (const name of names) {
        const full = path.join(storagePath, name);
        let bytes = 0;
        let cleared = false;
        try {
            if (fs.existsSync(full)) {
                bytes = directorySize(full);
                fs.rmSync(full, { recursive: true, force: true });
                cleared = true;
            } else {
                cleared = true; // nothing to remove counts as success
            }
        } catch {
            cleared = false;
        }
        results.push({ name, cleared, bytes });
    }
    return results;
}

export function formatBytes(bytes: number): string {
    if (bytes < 1024) { return `${bytes} B`; }
    if (bytes < 1024 * 1024) { return `${(bytes / 1024).toFixed(1)} KB`; }
    if (bytes < 1024 * 1024 * 1024) { return `${(bytes / 1024 / 1024).toFixed(1)} MB`; }
    return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}
