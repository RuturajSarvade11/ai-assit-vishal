import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { Logger } from './Logger';
import { FileHandlingConfig } from './FileHandlingConfig';
import { TrackingConfigService } from './TrackingConfigService';

export class FileUtils {

    static normalizePath(p: string): string {
        let norm = p.replace(/\\/g, '/');
        if (norm.startsWith('/') && norm.includes(':')) { norm = norm.substring(1); } return norm;
    }

    static slice(text: string, s: number, e: number) { return text.split('\n').slice(s, e + 1).join('\n'); }

    static isPracticallySame(textA: string, textB: string): boolean { return textA.replace(/\s+/g, '') === textB.replace(/\s+/g, ''); }

    static async readFileSafe(filePath: string, retries = 5): Promise<string> {
        const cleanPath = this.normalizePath(filePath);
        for (let i = 0; i < retries; i++) {
            try { return fs.readFileSync(cleanPath, 'utf8').replace(/\r\n/g, '\n'); }
            catch (e: any) {
                if (i === retries - 1) { throw e; }
                await new Promise(r => setTimeout(r, 200));
            }
        }
        return '';
    }

    // File-change-tracking INCLUSION list. When the admin "System Tracking Configuration"
    // (dashboard) has been loaded, IT governs — every consumer (change tracking and
    // the prediction file gate) follows the admin's glob patterns. The hardcoded list below is
    // the FAIL-OPEN fallback (backend unreachable / never loaded) and equals the shipped
    // behavior exactly: the work/ tree, the gradle/ folder (wrapper properties) and root-level
    // gradle/settings files. Unknown folders stay ignored by
    // default (fail-closed), so a future tmp/-style generated folder can never leak in.
    // Artifacts are unaffected (RuntimeArtifactCollector has its own admin-config/out-log-wrk rules).
    static isIncludedForTracking(filePath: string, workspaceRoot: string): boolean {
        const root = FileUtils.normalizePath(workspaceRoot || '').toLowerCase().replace(/\/+$/, '');
        const p = FileUtils.normalizePath(filePath || '').toLowerCase();
        if (!root || !p.startsWith(root + '/')) { return false; }
        const rel = p.slice(root.length + 1);

        const adminPatterns = TrackingConfigService.getActivePatterns();
        if (adminPatterns) {
            return TrackingConfigService.isTracked(rel, adminPatterns);
        }

        if (rel.startsWith('work/') || rel.startsWith('gradle/')) { return true; }
        if (!rel.includes('/')) {
            return rel.endsWith('.gradle.kts') || rel.endsWith('.gradle') || rel === 'gradle.properties';
        }
        return false;
    }

    static shouldIgnore(filePath: string): boolean {
        const p = filePath.replace(/\\/g, '/');
        const name = path.basename(filePath).toLowerCase();

        // Ignore common directories. /tmp/ = GBE/TD5 process working dirs (generated .upda/.xml
        // outputs, e.g. work/**/tmp/PDA/**) — generated files must not appear as tracked source
        // CHANGES in the upload payload. Runtime artifacts (logs under tmp) are unaffected: they
        // are collected by RuntimeArtifactCollector, which has its own path rules.
        if (p.includes('/node_modules/') || p.includes('/.git/') || p.includes('/.gradle/') ||
            p.includes('/.idea/') || p.includes('/build/') || p.includes('/dist/') ||
            p.includes('/out/') || p.includes('/bin/') || p.includes('/.vscode/') ||
            p.includes('/_td5/') || p.includes('/tmp/')) {
            return true;
        }

        // Ignore lock files (package-lock.json, etc.)
        if (name.includes('-lock.') || name.includes('.lock')) {
            return true;
        }

        // Ignore file extensions
        if (name.endsWith('.log') || name.endsWith('.tmp') || name.endsWith('.lck') ||
            name.endsWith('.bin') || name.endsWith('.probe') || name.endsWith('.class') ||
            name.endsWith('.zip') || name.endsWith('.exe') || name.endsWith('.md') ||
            name.endsWith('.jsonl')) {
            return true;
        }

        return false;
    }

    static cleanupOldJsonlFiles(directory: string, retentionDays: number = 5): void {
        try {
            if (!fs.existsSync(directory)) {
                return;
            }

            const files = fs.readdirSync(directory);
            const now = new Date();

            for (const file of files) {
                if (!file.endsWith('.jsonl')) { continue; }

                const match = file.match(/_(\d{4}-\d{2}-\d{2})\.jsonl$/);
                if (!match) { continue; }

                const fileDate = new Date(match[1]);
                if (isNaN(fileDate.getTime())) { continue; }

                const diffDays = (now.getTime() - fileDate.getTime()) / (1000 * 60 * 60 * 24);

                if (diffDays > retentionDays) {
                    const fullPath = path.join(directory, file);

                    try {
                        fs.unlinkSync(fullPath);
                    } catch { /* ignore */ }
                }
            }
        } catch { /* ignore */ }
    }

    static cleanupOldFolders(directory: string, retentionDays: number = 5): void {
        try {
            if (!fs.existsSync(directory)) { return; }

            const entries = fs.readdirSync(directory);
            const now = new Date();

            for (const entry of entries) {
                const fullPath = path.join(directory, entry);

                const stats = fs.statSync(fullPath);
                if (!stats.isDirectory()) { continue; }

                const diffDays = (now.getTime() - stats.mtime.getTime()) / (1000 * 60 * 60 * 24);

                if (diffDays > retentionDays) {
                    try {
                        fs.rmSync(fullPath, { recursive: true, force: true });
                    } catch { /* ignore */ }
                }
            }
        } catch { /* ignore */ }
    }

    static async scanWorkspaceExtensions(workspaceRoot: string): Promise<{ extensionCounts: Map<string, number>, binaryExtensions: Set<string> }> {
        const extensionCounts = new Map<string, number>();
        const binaryExtensions = new Set<string>();
        let fileCount = 0;
        const maxFiles = 10000;

        const scanDir = (dir: string, depth = 0): void => {
            if (depth > 5 || fileCount >= maxFiles) { return; }

            let entries: fs.Dirent[] = [];

            try {
                entries = fs.readdirSync(dir, { withFileTypes: true });
            } catch {
                return;
            }

            for (const entry of entries) {
                if (fileCount >= maxFiles) { break; }

                const fullPath = path.join(dir, entry.name);

                if (entry.isDirectory()) {
                    if (this.shouldSkipExtensionScanDirectory(entry.name)) {
                        continue;
                    }

                    scanDir(fullPath, depth + 1);
                    continue;
                }

                if (!entry.isFile()) {
                    continue;
                }

                fileCount++;
                const ext = FileHandlingConfig.getExtension(entry.name);

                if (ext) {
                    extensionCounts.set(ext, (extensionCounts.get(ext) || 0) + 1);

                    try {
                        if (FileHandlingConfig.isBinaryFile(fullPath)) {
                            binaryExtensions.add(ext);
                        }
                    } catch {
                        // ignore binary detection failures for workspace scan
                    }
                }
            }
        };

        try {
            scanDir(workspaceRoot);
        } catch (err) {
            Logger.log('[FileUtils] Failed to scan workspace extensions', err);
        }

        return { extensionCounts, binaryExtensions };
    }

    static async scanWorkspaceExtensionsProgressive(
        workspaceRoot: string,
        onProgress: (result: { extensionCounts: Map<string, number>, binaryExtensions: Set<string> }, isComplete: boolean) => void
    ): Promise<void> {
        const extensionCounts = new Map<string, number>();
        const binaryExtensions = new Set<string>();
        let fileCount = 0;
        const maxFiles = 10000;
        const batchSize = 1000;
        let lastReportedCount = 0;

        const scanDir = (dir: string, depth = 0): void => {
            if (depth > 5 || fileCount >= maxFiles) { return; }

            let entries: fs.Dirent[] = [];

            try {
                entries = fs.readdirSync(dir, { withFileTypes: true });
            } catch {
                return;
            }

            for (const entry of entries) {
                if (fileCount >= maxFiles) { break; }

                const fullPath = path.join(dir, entry.name);

                if (entry.isDirectory()) {
                    if (this.shouldSkipExtensionScanDirectory(entry.name)) {
                        continue;
                    }

                    scanDir(fullPath, depth + 1);
                    continue;
                }

                if (!entry.isFile()) {
                    continue;
                }

                fileCount++;
                const ext = FileHandlingConfig.getExtension(entry.name);

                if (ext) {
                    extensionCounts.set(ext, (extensionCounts.get(ext) || 0) + 1);

                    try {
                        if (FileHandlingConfig.isBinaryFile(fullPath)) {
                            binaryExtensions.add(ext);
                        }
                    } catch {
                        // ignore binary detection failures for workspace scan
                    }
                }

                if (fileCount - lastReportedCount >= batchSize) {
                    lastReportedCount = fileCount;
                    onProgress({ extensionCounts: new Map(extensionCounts), binaryExtensions: new Set(binaryExtensions) }, false);
                }
            }
        };

        try {
            scanDir(workspaceRoot);
            onProgress({ extensionCounts, binaryExtensions }, true);
        } catch (err) {
            Logger.log('[FileUtils] Failed to scan workspace extensions progressively', err);
            onProgress({ extensionCounts, binaryExtensions }, true);
        }
    }

    private static shouldSkipExtensionScanDirectory(name: string): boolean {
        const lower = name.toLowerCase();
        return lower === 'node_modules' ||
            lower === '.git' ||
            lower === '.gradle' ||
            lower === 'build' ||
            lower === 'dist' ||
            lower === 'out' ||
            lower === 'bin' ||
            lower === '.vscode' ||
            lower === '.idea' ||
            lower === 'target' ||
            lower === 'coverage' ||
            lower === 'logs' ||
            lower === '__pycache__' ||
            lower === '.pytest_cache' ||
            lower === '.next' ||
            lower === '.nuxt' ||
            lower === 'vendor';
    }

    static getFileSize(filePath: string): string {
        try {
            if (fs.existsSync(filePath)) {
                const stats = fs.statSync(filePath);
                return `${(stats.size / 1024).toFixed(2)} KB`;
            }
        } catch (err) {

        }
        return 'unknown';
    }

    static getBufferSize(buffer: Buffer): string {
        try {
            return `${(buffer.length / 1024).toFixed(2)} KB`;
        }
        catch (err) {
        }
        return 'unknown';
    }

    static isFileInsideWorkspace(filePath: string, workspaceRoot: string): boolean {
        if (!filePath || !workspaceRoot) {
            return false;
        }

        try {
            const resolvedFile = path.resolve(filePath);
            const resolvedRoot = path.resolve(workspaceRoot);
            const relative = path.relative(resolvedRoot, resolvedFile);
            return relative === '' || (!!relative && !relative.startsWith('..') && !path.isAbsolute(relative));
        } catch {
            return false;
        }
    }

    static toWorkspaceRelativePath(filePath: string, workspaceRoot: string): string | null {
        if (!this.isFileInsideWorkspace(filePath, workspaceRoot)) {
            return null;
        }

        return this.normalizePath(path.relative(path.resolve(workspaceRoot), path.resolve(filePath)));
    }

    static isPathInsideAnyWorkspace(filePath: string): boolean {
        return (vscode.workspace.workspaceFolders || [])
            .some((folder) => this.isFileInsideWorkspace(filePath, folder.uri.fsPath));
    }

    static isWorkspaceFileUri(uri: vscode.Uri): boolean {
        return uri.scheme === 'file' && this.isPathInsideAnyWorkspace(uri.fsPath);
    }

    static parseWorkspaceFileUri(raw: string): vscode.Uri | null {
        try {
            const uri = vscode.Uri.parse(String(raw || ''));
            return this.isWorkspaceFileUri(uri) ? uri : null;
        } catch {
            return null;
        }
    }

    static detectProjectType(workspaceRoot: string): 'gradle' | 'td5' {
        if (!workspaceRoot || !fs.existsSync(workspaceRoot)) {
            return 'td5';
        }

        try {
            const entries = fs.readdirSync(workspaceRoot, { withFileTypes: true });
            const isGradle = entries.some(entry => {
                if (!entry.isFile()) { return false; }
                const name = entry.name.toLowerCase();
                return name.endsWith('.kts')
                    || name === 'build.gradle'
                    || name === 'settings.gradle'
                    || name === 'gradle.properties'
                    || name === 'gradlew'
                    || name === 'gradlew.bat';
            });
            return isGradle ? 'gradle' : 'td5';
        } catch {
            return 'td5';
        }
    }

    static isPrimaryTD5Log(filePath: string): boolean {
        const base = path.basename(filePath, path.extname(filePath)).toLowerCase();
        return /_(?:normal|release|normal-dev|td5)$/.test(base);
    }

    // GBE target discovery (client integration doc, additive): the target name is the report's
    // first non-generic ancestor directory under 'build', with a fallback to the first name
    // component of a <TARGET>.target.gradle.kts file. Task-path parsing stays the existing
    // source everywhere else - this only DECLARES the target and adds it as a new upload field.
    static async deriveGbeTargetName(reportPath: string): Promise<{ target: string; source: string } | null> {
        const generic = new Set(['report.html', 'reports', 'problems', 'problems-report', 'build', 'html']);
        const segs = this.normalizePath(reportPath).split('/');
        const buildIdx = segs.map(s => s.toLowerCase()).lastIndexOf('build');

        for (let i = segs.length - 2; i > buildIdx && i >= 0; i--) {
            const name = segs[i];
            if (name && !generic.has(name.toLowerCase())) {
                return { target: name, source: 'report path' };
            }
        }

        try {
            const found = await vscode.workspace.findFiles('**/*.target.gradle.kts', '**/node_modules/**', 25);
            const names = found
                .map(f => path.basename(f.fsPath))
                .map(b => b.slice(0, b.length - '.target.gradle.kts'.length))
                .filter(Boolean);
            const inPath = names.find(n => segs.some(s => s.toLowerCase() === n.toLowerCase()));
            if (inPath) { return { target: inPath, source: 'target.gradle.kts (path match)' }; }
            if (names.length === 1) { return { target: names[0], source: 'target.gradle.kts' }; }
        } catch {
            // Discovery is best-effort only.
        }
        return null;
    }

    // EXISTING: For finding source files from error paths
    static async resolveErrorPath(reportPath: string, workspaceRoot: string,
        filenameIndex: Map<string, string>): Promise<string | null> {
        if (path.isAbsolute(reportPath)) {
            const norm = this.normalizePath(reportPath);
            if (this.isFileInsideWorkspace(norm, workspaceRoot) && fs.existsSync(norm)) { return norm; }
        }
        const joined = this.normalizePath(path.join(workspaceRoot, reportPath));
        if (this.isFileInsideWorkspace(joined, workspaceRoot) && fs.existsSync(joined)) { return joined; }
        const justName = path.basename(reportPath).toLowerCase();
        if (filenameIndex.has(justName)) {
            const indexed = filenameIndex.get(justName) || null;
            if (indexed && this.isFileInsideWorkspace(indexed, workspaceRoot)) { return indexed; }
        }
        try {
            const found = await vscode.workspace.findFiles(`**/${path.basename(reportPath)}`, '**/node_modules/**', 1);
            if (found.length > 0 && this.isFileInsideWorkspace(found[0].fsPath, workspaceRoot)) {
                return this.normalizePath(found[0].fsPath);
            }
        } catch { /* ignore */ }
        return null;
    }

    // NEW: Specialized Logic to Find the Build Report (Handles .gitignore issues)
    // Returns a single path — used by MCP/recommendation flows that need one canonical report.
    static async findBuildReport(workspaceRoot: string, silent = false): Promise<string | null> {
        const all = await this.findAllBuildReports(workspaceRoot, silent);
        return all.length > 0 ? all[0] : null;
    }

    /** The report describing the failure the developer is asking about.
     *  A workspace holds one report per target (build/dev/..., build/master/...), and plain
     *  discovery order is alphabetical - so 'dev' won over 'master' and the recommendation
     *  was built from a FIVE-DAY-OLD dev report while the developer had just failed on
     *  master: wrong task, wrong artifacts, wrong candidates, all internally consistent.
     *  Preference: the report whose path matches the task the user actually ran, then the
     *  most recently written report. Falls back to plain discovery when nothing matches. */
    static async findBuildReportForTask(workspaceRoot: string, requestedTasks: string,
                                        silent = false): Promise<string | null> {
        const all = await this.findAllBuildReports(workspaceRoot, silent);
        if (all.length <= 1) { return all.length === 1 ? all[0] : null; }
        const segs = String(requestedTasks || '').toLowerCase().split(':')
            .map(s => s.trim()).filter(s => s && s !== 'targets');
        const mtime = (p: string): number => {
            try { return fs.statSync(p).mtimeMs; } catch { return 0; }
        };
        const scored = all.map(p => {
            const lower = p.toLowerCase().split(/[\/]+/).filter(Boolean);
            return { p, hits: segs.filter(s => lower.includes(s)).length, t: mtime(p) };
        });
        scored.sort((a, b) => (b.hits - a.hits) || (b.t - a.t));
        return scored[0].p;
    }

    // Returns ALL report.html files found under the workspace — used by startup scan and poll.
    static async findAllBuildReports(workspaceRoot: string, silent = false): Promise<string[]> {
        // Primary: VS Code API scoped to build/** (respects .gitignore overrides)
        const found = await vscode.workspace.findFiles('**/build/**/report.html', '**/node_modules/**', 50);
        if (found.length > 0) {
            // NEWEST FIRST: discovery order is alphabetical, so build/dev/report.html
            // shadowed build/master/report.html and callers taking [0] used a stale report.
            return this.sortByNewest(found.map(uri => this.normalizePath(uri.fsPath)));
        }
        // Fallback 1: broader search (any report.html in workspace)
        const anyReports = await vscode.workspace.findFiles('**/report.html', '**/node_modules/**', 50);
        if (anyReports.length > 0) {
            return this.sortByNewest(anyReports
                .map(uri => this.normalizePath(uri.fsPath))
                .filter(p => fs.existsSync(p)));
        }

        // Fallback 2: manual filesystem scan
        const manualPaths = this.manualScanForAllReports(this.normalizePath(workspaceRoot));
        if (manualPaths.length > 0) { return this.sortByNewest(manualPaths); }
        return [];
    }

    /** Most recently written first; unreadable files sort last. */
    private static sortByNewest(paths: string[]): string[] {
        return [...paths].sort((a, b) => {
            let ta = 0, tb = 0;
            try { ta = fs.statSync(a).mtimeMs; } catch { ta = 0; }
            try { tb = fs.statSync(b).mtimeMs; } catch { tb = 0; }
            return tb - ta;
        });
    }

    private static manualScanForAllReports(rootPath: string): string[] {
        if (!rootPath || !fs.existsSync(rootPath)) { return []; }
        const buildPath = path.join(rootPath, 'build');
        if (!fs.existsSync(buildPath)) { return []; }

        const results: string[] = [];
        try {
            // Level 1: build/report.html
            const level1 = path.join(buildPath, 'report.html');
            if (fs.existsSync(level1)) { results.push(this.normalizePath(level1)); }

            // Level 2: build/*/report.html
            const subfolders = fs.readdirSync(buildPath, { withFileTypes: true })
                .filter(dirent => dirent.isDirectory()).map(dirent => dirent.name);

            for (const folder of subfolders) {
                const level2 = path.join(buildPath, folder, 'report.html');
                if (fs.existsSync(level2)) { results.push(this.normalizePath(level2)); }

                // Level 3: build/*/*/report.html (e.g. build/master/comp/report.html)
                try {
                    const subsubPath = path.join(buildPath, folder);
                    const subsubfolders = fs.readdirSync(subsubPath, { withFileTypes: true })
                        .filter(d => d.isDirectory()).map(d => d.name);
                    for (const sub of subsubfolders) {
                        const level3 = path.join(subsubPath, sub, 'report.html');
                        if (fs.existsSync(level3)) { results.push(this.normalizePath(level3)); }
                    }
                } catch { /* skip unreadable dirs */ }
            }
        } catch { /* ignore */ }
        return results;
    }

    // Returns TD5 target log files found under *_td5/log/ in the workspace.
    // Example path:
    //   <workspace>/_td5/log/0ga1_0m0_NORMAL.log
    // or
    //   <workspace>/<something>_td5/log/<target>.log
    // We only watch these target logs, not proc/*/log/ task logs.
    static async findAllTD5Logs(workspaceRoot: string, silent = false): Promise<string[]> {
        const found = await vscode.workspace.findFiles('**/*_td5/log/*.log', '**/node_modules/**', 100);
        if (found.length > 0) {
            return found
                .map(uri => this.normalizePath(uri.fsPath))
                .filter(p => this.isPrimaryTD5Log(p));
        }

        // Manual fallback: scan workspace root for *_td5 directories
        try {
            const entries = fs.readdirSync(workspaceRoot, { withFileTypes: true });
            const td5Dirs = entries
                .filter(e => e.isDirectory() && /_td5$/i.test(e.name))
                .map(e => path.join(workspaceRoot, e.name));

            const results: string[] = [];
            for (const td5Dir of td5Dirs) {
                const logDir = path.join(td5Dir, 'log');
                if (!fs.existsSync(logDir)) { continue; }
                try {
                    const files = fs.readdirSync(logDir)
                        .filter(f => f.toLowerCase().endsWith('.log'))
                        .filter(f => this.isPrimaryTD5Log(f))
                        .map(f => this.normalizePath(path.join(logDir, f)));
                    results.push(...files);
                } catch { /* skip unreadable log dirs */ }
            }
            if (results.length > 0) { return results; }
        } catch { /* ignore */ }
        return [];
    }

    static stripTimestamp(message: string): string {
        return message.replace(/\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{2},\s+\d{4}\s+\d{1,2}:\d{2}:\d{2}\s+(?:AM|PM)\b/g, '').trim();
    }

    static formatFileSize(bytes: number): string {
        if (bytes < 1024) { return `${bytes} B`; }
        if (bytes < 1024 * 1024) { return `${(bytes / 1024).toFixed(2)} KB`; }
        return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    }

    /**
     * Validates file size before reading (security improvement)
     * @param filePath Path to file
     * @param maxSizeBytes Maximum allowed size in bytes (default: 10MB for text, 1024MB for binary)
     * @returns true if file is within size limit
     */
    static validateFileSize(filePath: string, maxSizeBytes?: number): boolean {
        try {
            if (!fs.existsSync(filePath)) {
                return false;
            }

            const stats = fs.statSync(filePath);
            const isBinary = FileHandlingConfig.isBinaryFile(filePath);
            const defaultMax = isBinary ? 1024 * 1024 * 1024 : 10 * 1024 * 1024; // 1024MB binary, 10MB text
            const maxSize = maxSizeBytes ?? defaultMax;

            if (stats.size > maxSize) {
                return false;
            }

            return true;
        } catch {
            return false;
        }
    }

    /**
     * Safe read with file size validation
     */
    static async readFileSafeWithValidation(filePath: string, maxSizeBytes?: number, retries = 5): Promise<string> {
        if (!this.validateFileSize(filePath, maxSizeBytes)) {
            throw new Error(`File exceeds size limit: ${filePath}`);
        }
        return this.readFileSafe(filePath, retries);
    }

    /**
     * Safe binary read with file size validation
     */
    static readBinarySafe(filePath: string, maxSizeBytes?: number): Buffer {
        if (!this.validateFileSize(filePath, maxSizeBytes)) {
            throw new Error(`File exceeds size limit: ${filePath}`);
        }
        return fs.readFileSync(filePath);
    }
}
