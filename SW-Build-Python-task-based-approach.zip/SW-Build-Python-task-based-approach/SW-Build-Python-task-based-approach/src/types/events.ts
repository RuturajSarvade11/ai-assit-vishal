export interface RawBuildError {
    path: string;
    message: string;
    taskPath?: string;
    /** TD5 only: the log's tail block ("last build failure") — the ~15 meaningful lines before
     *  Build Status: FAILED, which carry the actual cause. DISPLAY-ONLY (confirm webview);
     *  stored/uploaded error messages are untouched so signatures and dedup stay stable. */
    failureTail?: string;
}

export interface LineChange {
    line: number;
    content: string;
}

export interface FileChangeEvent {
    timestamp: string;
    eventType: string;
    filePath: string;
    category: string;
    projectName: string;
    fileName: string;
    workspace: string;
    language: string;

    snapshotBefore: { path: string; content: string | null } | null;
    snapshotAfter: { path: string; content: string | null } | null;
    /**
     * Disk-backed payload paths. These keep queued events memory-light while
     * preserving the existing snapshotBefore/snapshotAfter API shape for upload.
     */
    snapshotBeforeContentPath?: string | null;
    snapshotAfterContentPath?: string | null;
    lastDivergedSnapshotPath?: string | null;
    diffFile: string | null;

    modifiedFunctions: {
        functionName: string;
        before: { functionCode: string | null };
        after: { functionCode: string | null };
        linesBeforeChanges: LineChange[];
        linesAfterChanges: LineChange[];
    }[];

    errorDetails: {
        message: string;
    }[];
}

export interface ErrorSession {
    timestamp: string;
    originalContent: string;
    snapshotBeforePath: string;
    errorMessages: string[];
    lastSavedContent: string;
    lastSnapshotPath: string;
    lastDivergedContent: string | null;
    lastDivergedSnapshotPath: string | null;

    functionHistory: Map<string, {
        before: LineChange[];
        after: LineChange[];
    }>;
}