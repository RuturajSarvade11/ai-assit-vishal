param([Parameter(Mandatory = $true)][ValidateSet('dev', 'prod')][string]$Env, [string]$OutDir = "release")
# Builds one VSIX per server environment. config/config.json is the switch the extension reads at
# run time (dev -> aiasb-dev.schaeffler.cloud/agent, prod -> aiasb.schaeffler.cloud/agent), so the
# package is built with that file set and the file is put back afterwards.
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$cfg = Join-Path $root "config\config.json"
$original = Get-Content $cfg -Raw
$version = (Get-Content (Join-Path $root "package.json") -Raw | ConvertFrom-Json).version
New-Item -ItemType Directory -Force (Join-Path $root $OutDir) | Out-Null
$out = Join-Path $root "$OutDir\gradle-error-assistant-$version-$Env.vsix"
try {
    "{`n  `"env`": `"$Env`"`n}`n" | Set-Content -Encoding ascii -NoNewline $cfg
    npx vsce package --no-dependencies -o $out
    if ($LASTEXITCODE -ne 0) { throw "vsce failed with exit code $LASTEXITCODE" }
    "built: $out ($([math]::Round((Get-Item $out).Length / 1MB, 1)) MB)"
} finally {
    Set-Content -Encoding ascii -NoNewline -Path $cfg -Value $original
}
