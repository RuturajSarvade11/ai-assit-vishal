const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { builtinModules } = require('module');
const { build } = require('esbuild');

async function main() {
  const root = path.join(__dirname, '..');
  const entry = path.join(root, 'src', 'mcp', 'server.ts');
  const bundleOut = path.join(root, 'build', 'mcp', 'server.bundle.cjs');
  const exeOut = path.join(root, 'bin', 'local-mcp-server.exe');

  fs.mkdirSync(path.dirname(bundleOut), { recursive: true });
  fs.mkdirSync(path.dirname(exeOut), { recursive: true });

  const builtins = [...builtinModules, ...builtinModules.map((m) => `node:${m}`)];

  console.log(`[build-mcp-runtime] Bundling ${entry}`);
  await build({
    entryPoints: [entry],
    outfile: bundleOut,
    bundle: true,
    platform: 'node',
    format: 'cjs',
    target: ['node18'],
    external: builtins,
    logLevel: 'info',
    banner: {
      js: '#!/usr/bin/env node',
    },
  });

  // REUSE path: on locked-down corporate machines, pkg's fabricator cannot spawn (AV/EDR blocks
  // executing the fetched base Node binary -> "spawn UNKNOWN"). bin/local-mcp-server.exe is
  // committed to git, and it only changes when src/mcp/server.ts changes. So when server.ts is
  // unchanged, the committed exe is byte-identical to what pkg would build. Set REUSE_MCP_EXE=1
  // to skip pkg and package with the committed exe. (The bundle above is still rebuilt — cheap,
  // no spawn — so it stays in sync.)
  if (process.env.REUSE_MCP_EXE === '1') {
    if (fs.existsSync(exeOut)) {
      console.log(`[build-mcp-runtime] REUSE_MCP_EXE=1 -> skipping pkg, reusing committed ${exeOut}`);
      console.log(`[build-mcp-runtime] Done (reused): ${exeOut}`);
      return;
    }
    console.warn('[build-mcp-runtime] REUSE_MCP_EXE=1 but no exe present — restore it first: git checkout -- bin/local-mcp-server.exe');
  }

  console.log(`[build-mcp-runtime] Packaging ${bundleOut} -> ${exeOut}`);
  const targetArgs = `"${bundleOut}" --targets node18-win-x64 --output "${exeOut}"`;

  // Back up the committed exe before deleting, so a pkg failure never destroys it (previously a
  // failed pkg left bin/ empty, forcing a git checkout to recover).
  const backup = `${exeOut}.bak`;
  if (fs.existsSync(exeOut)) {
    fs.copyFileSync(exeOut, backup);
    fs.unlinkSync(exeOut);
  }

  try {
    if (process.platform === 'win32') {
      const pkgCmd = path.join(root, 'node_modules', '.bin', 'pkg.cmd');
      execSync(`"${pkgCmd}" ${targetArgs}`, {
        cwd: root,
        stdio: 'inherit',
        shell: 'cmd.exe',
      });
    } else {
      const pkgCmd = path.join(root, 'node_modules', '.bin', 'pkg');
      execSync(`"${pkgCmd}" ${targetArgs}`, {
        cwd: root,
        stdio: 'inherit',
      });
    }
  } catch (error) {
    if (fs.existsSync(backup)) {
      fs.copyFileSync(backup, exeOut);
      fs.unlinkSync(backup);
      console.error('[build-mcp-runtime] pkg failed — restored the previous exe. On a locked-down machine, package with REUSE_MCP_EXE=1 to skip the pkg rebuild (server.ts is unchanged, so the committed exe is valid).');
    }
    throw error;
  }

  if (fs.existsSync(backup)) {
    fs.unlinkSync(backup);
  }

  if (!fs.existsSync(exeOut)) {
    throw new Error(`Expected executable not found: ${exeOut}`);
  }

  console.log(`[build-mcp-runtime] Done: ${exeOut}`);
}

main().catch((error) => {
  console.error('[build-mcp-runtime] Failed', error);
  process.exit(1);
});



