const fs = require('fs');
const path = require('path');

const exePath = path.join(__dirname, '..', 'bin', 'local-mcp-server.exe');

if (!fs.existsSync(exePath)) {
  console.error(`[verify-mcp-runtime] Missing required file: ${exePath}`);
  console.error('[verify-mcp-runtime] Add local-mcp-server.exe to Package/bin before packaging the VSIX.');
  process.exit(1);
}

console.log(`[verify-mcp-runtime] Found ${exePath}`);
