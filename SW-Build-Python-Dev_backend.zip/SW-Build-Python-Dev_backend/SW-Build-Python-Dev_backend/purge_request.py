"""
purge_request.py - deep cleanup for a HALF-DELETED request id.

The /delete-requests endpoint sweeps everything it can REACH (scoped rows, reference rows,
vectors via reference rows, S3 via dedup ledger). After a partial failure some things become
unreachable to it - e.g. vectors whose reference rows were already deleted. This tool removes,
directly and idempotently, everything still carrying the request id:

  1. every ai_assisted_data row with PK = <request_id>  (votes, outcomes, artifacts, refs, trace pointers)
  2. the final_build_payload row
  3. error-collection vectors whose metadata request_id/batch_id = <request_id> (base + learned space)
  4. prints what was found/removed so a clean second run shows all zeros

Usage (server, backend venv):  python purge_request.py <request-id>
"""
import sys

def main():
    if len(sys.argv) != 2 or not sys.argv[1].strip():
        print("usage: python purge_request.py <request-id>")
        return 2
    request_id = sys.argv[1].strip()
    print(f"purging request_id={request_id}")

    # 1. every data row under the request id
    from src.utils.project_details import ai_assisted_data_table
    from boto3.dynamodb.conditions import Key
    deleted_rows = 0
    try:
        kwargs = {"KeyConditionExpression": Key("PK").eq(request_id)}
        while True:
            res = ai_assisted_data_table.query(**kwargs)
            for item in res.get("Items", []):
                ai_assisted_data_table.delete_item(Key={"PK": item["PK"], "SK": item["SK"]})
                deleted_rows += 1
            last = res.get("LastEvaluatedKey")
            if not last:
                break
            kwargs["ExclusiveStartKey"] = last
    except Exception as exc:
        print(f"  data-row sweep failed: {exc}")
    print(f"  ai_assisted_data rows deleted: {deleted_rows}")

    # 2. final build payload row
    try:
        from src.utils.project_details import delete_final_build_payload
        ok = delete_final_build_payload(request_id)
        print(f"  final_build_payload row: {'deleted' if ok else 'not found'}")
    except Exception as exc:
        print(f"  final_build_payload delete failed: {exc}")

    # 3. vectors carrying the request id (base error collection + learned space)
    def _purge_collection(col, label):
        removed = 0
        try:
            for field in ("request_id", "batch_id"):
                try:
                    rows = col.get(where={field: request_id}, include=["metadatas"])
                except Exception:
                    continue
                ids = rows.get("ids") or []
                if ids:
                    col.delete(ids=ids)
                    removed += len(ids)
        except Exception as exc:
            print(f"  {label}: purge failed: {exc}")
        print(f"  {label}: vectors deleted: {removed}")

    try:
        from src.utils import recommended
        _purge_collection(recommended.collection, "error collection")
        try:
            learned = getattr(recommended, "learned_collection", None) or getattr(recommended, "_learned_collection", None)
            if learned is not None:
                _purge_collection(learned, "learned space")
            else:
                print("  learned space: no handle exposed - skipped (rebuilt on next training cycle anyway)")
        except Exception as exc:
            print(f"  learned space: {exc}")
    except Exception as exc:
        print(f"  vector purge unavailable: {exc}")

    # 4. tombstone: the request's shared vectors may legitimately survive (other requests
    # reference them) - the marker stops the hydrate backfill from ever rebuilding this entry.
    try:
        import time as _t
        from datetime import datetime as _dt, timezone as _tz
        ai_assisted_data_table.put_item(Item={
            "PK": request_id, "SK": "TOMBSTONE",
            "deleted_at": _dt.now(_tz.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "expires_at": int(_t.time()) + 180 * 24 * 3600,
        })
        print("  tombstone written (never resurrects)")
    except Exception as exc:
        print(f"  tombstone write failed: {exc}")

    # 5. drop dashboard read caches so the row vanishes immediately
    try:
        from src.utils import ttl_cache
        ttl_cache.clear()
        print("  dashboard read caches cleared")
    except Exception as exc:
        print(f"  cache clear failed: {exc}")

    print("done - rerun this script: all counts should be 0 / not found")
    return 0

if __name__ == "__main__":
    sys.exit(main())
