"""
Backfill token_usage onto EXISTING artifact summaries — WITHOUT re-running the LLM.

WHY: the per-artifact token audit (get-total-errors -> binary.artifacts[].token_usage) is captured
at summary time. Artifacts summarised before that feature carry token_usage = {}. This script
RECOMPUTES the audit from the raw file in S3 (re-deriving the same deterministic noise/structural
reduction) + the already-stored summary, using a tokeniser. No LLM call, no re-summarisation — it
only adds the token_usage so the dashboard shows token numbers for files already uploaded.

ACCURACY (see oai_client.recompute_artifact_token_audit):
  - single-call (small) files: EXACT — same prompt that was sent, and the stored summary.
  - large map-reduce files: inputs and the final summary are exact, but the intermediate per-part
    OUTPUTS were never stored, so they show as null. token_basis is "tiktoken" if available, else
    an "approx" ~4 chars/token estimate.

SCOPE (default = "this week", safe to re-run):
  - only records from the last N days (DAYS env, default 7) unless --all,
  - only records with no token_usage yet, unless --force.

RUN WITH THE BACKEND STOPPED (single writer to ChromaDB), in the venv, with the target .env:
    python backfill_artifact_token_audit.py --dry-run     # scan + report, no LLM, no changes
    python backfill_artifact_token_audit.py               # write recomputed token_usage
    python backfill_artifact_token_audit.py --all          # ignore the date window
"""
import json
import logging
import os
import sys
from datetime import datetime, timedelta, timezone
from io import BytesIO
from zipfile import ZipFile

import src.utils.log_setup  # noqa: F401

from src.utils.payload_archive import get_s3_client, S3_BUCKET
from src.services import handlers
from src.utils import oai_client

log = logging.getLogger("backfill_token_audit")
DRY_RUN = "--dry-run" in sys.argv
ALL = "--all" in sys.argv
FORCE = "--force" in sys.argv
DAYS = max(1, int(os.getenv("DAYS", "7")))
PAGE = max(100, int(os.getenv("MIGRATION_PAGE", "1000")))
WRITE_BATCH = max(1, int(os.getenv("MIGRATION_WRITE_BATCH", "200")))


def _clean_key(s3_key) -> str:
    return str(s3_key or "").strip().rstrip('"').rstrip("%22")


def _last_modified(s3_key: str):
    try:
        return get_s3_client().head_object(Bucket=S3_BUCKET, Key=s3_key).get("LastModified")
    except Exception:
        return None


def _raw_text(s3_key: str) -> str:
    resp = get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key)
    body = resp["Body"].read()
    with ZipFile(BytesIO(body), "r") as zf:
        names = zf.namelist()
        raw = zf.read(names[0]) if names else b""
    return raw.decode("utf-8", errors="replace")


def collect_groups(col):
    """Group every artifact record by s3_key (a file may be >1 chunk record). Returns
    {s3_key: {"file_name", "has_audit", "records": [(id, meta, doc)]}}."""
    groups: dict[str, dict] = {}
    scanned = 0
    offset = 0
    while True:
        res = col.get(include=["documents", "metadatas"], limit=PAGE, offset=offset)
        ids = res.get("ids") or []
        metas = res.get("metadatas") or []
        docs = res.get("documents") or []
        if not ids:
            break
        for i, rid in enumerate(ids):
            scanned += 1
            meta = metas[i] if i < len(metas) else {}
            if not isinstance(meta, dict):
                continue
            s3 = _clean_key(meta.get("s3_key"))
            if not s3:
                continue
            g = groups.setdefault(s3, {"file_name": "", "has_audit": False, "records": []})
            g["records"].append((rid, dict(meta), str(docs[i] if i < len(docs) else "")))
            if not g["file_name"]:
                g["file_name"] = str(meta.get("file_name") or "")
            if str(meta.get("token_audit_json") or "").strip():
                g["has_audit"] = True
        if len(ids) < PAGE:
            break
        offset += PAGE
    return scanned, groups


def main():
    col = handlers.get_artifact_chroma_collection()
    scanned, groups = collect_groups(col)
    log.info("artifact records scanned=%d | unique s3 objects=%d | token_basis=%s",
             scanned, len(groups), oai_client.TOKEN_BASIS)

    cutoff = datetime.now(timezone.utc) - timedelta(days=DAYS)
    todo = []
    skipped_have = skipped_old = 0
    for s3, g in groups.items():
        if g["has_audit"] and not FORCE:
            skipped_have += 1
            continue
        if not ALL:
            lm = _last_modified(s3)
            if lm is not None and lm < cutoff:
                skipped_old += 1
                continue
        todo.append((s3, g))

    log.info("to recompute=%d | skipped_already_have=%d | skipped_older_than_%dd=%d",
             len(todo), skipped_have, skipped_old, DAYS)

    if DRY_RUN:
        for s3, g in todo[:10]:
            log.info("[dry-run] file=%s | records=%d | %s", g["file_name"], len(g["records"]), s3)
        if len(todo) > 10:
            log.info("[dry-run] ... and %d more", len(todo) - 10)
        log.info("[dry-run] would recompute %d file(s). No LLM calls, no changes.", len(todo))
        return

    updated_files = updated_records = failed = 0
    batch_ids: list[str] = []
    batch_metas: list[dict] = []

    def flush():
        nonlocal updated_records, failed, batch_ids, batch_metas
        if not batch_ids:
            return
        try:
            col.update(ids=batch_ids, metadatas=batch_metas)
            updated_records += len(batch_ids)
        except Exception as exc:
            failed += len(batch_ids)
            log.error("batch update failed (%d records) — re-run to retry: %s", len(batch_ids), exc)
        batch_ids, batch_metas = [], []

    for s3, g in todo:
        try:
            text = _raw_text(s3)
            full_summary = "\n".join(doc for _, _, doc in g["records"] if doc).strip()
            audit = oai_client.recompute_artifact_token_audit(
                file_name=g["file_name"], artifact_text=text, summary_text=full_summary)
            if not audit:
                failed += 1
                log.warning("empty audit (empty artifact?) | %s", s3)
                continue
            audit_json = json.dumps(audit, ensure_ascii=False, separators=(",", ":"))
            total_tokens = int((audit.get("totals") or {}).get("total", 0) or 0)
            for rid, meta, _doc in g["records"]:
                m = dict(meta)
                m["token_audit_json"] = audit_json
                m["summary_total_tokens"] = total_tokens
                batch_ids.append(rid)
                batch_metas.append(m)
            updated_files += 1
            if len(batch_ids) >= WRITE_BATCH:
                flush()
                log.info("progress | files=%d | records=%d | failed=%d", updated_files, updated_records, failed)
        except Exception as exc:
            failed += 1
            log.error("recompute failed | %s | %s", s3, exc)
    flush()

    log.info("TOKEN-AUDIT BACKFILL done | files=%d | records=%d | failed=%d | token_basis=%s",
             updated_files, updated_records, failed, oai_client.TOKEN_BASIS)


if __name__ == "__main__":
    main()
