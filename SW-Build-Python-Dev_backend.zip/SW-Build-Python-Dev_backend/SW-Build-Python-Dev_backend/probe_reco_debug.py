"""
probe_reco_debug.py — stage-by-stage recommendation debugger (READ-ONLY).

Run this ON the backend box (same venv/env as main.py). It drives the exact same
pipeline stages as /report-errors and prints, for an EXPECTED request_id, the first
stage where it disappears — retrieval, hydration, re-rank, or the threshold gate —
with the evidence at every step. Paste the full output back for analysis.

Usage (PowerShell, repo root, venv active):

  # Strongest probe: query with the expected entry's OWN stored error text
  # (--project defaults to TESTGBE and is lowercased automatically, like the pipeline)
  python probe_reco_debug.py --expect <request_id>

  # Or with an explicit query text / the current failing error
  python probe_reco_debug.py --expect <request_id> --text "..error text.."
  python probe_reco_debug.py --expect <request_id> --text-file err.txt
  python probe_reco_debug.py --project OtherProject --expect <request_id>

  # Optional context, same as the extension sends:
  #   --task-path ":TARGETS:master:task4"
  #   --changed-files "config.xml,foo.c"
  #   --artifact-file build_log_excerpt.txt

No LLM call, no report file, no hit tracking — retrieval/ranking/gating only.
"""
import argparse
import json
import logging
import sys

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s")

from src.configurations import config                      # noqa: E402
from src.services import handlers                          # noqa: E402
from src.services import recommendation_config as rc       # noqa: E402
from src.utils.project_details import (                    # noqa: E402
    get_final_build_payload,
    get_vector_references,
    get_error_vector_index,
    get_error_signature_summary,
    get_error_solution_references_summary_first,
    list_final_build_payloads_by_project,
)

LINE = "=" * 78


def _p(title):
    print("\n" + LINE)
    print(title)
    print(LINE)


def _rid(meta):
    m = meta if isinstance(meta, dict) else {}
    return str(m.get("request_id") or m.get("batch_id") or "").strip()


def _stored_error_text(rid, project, env, deep=False):
    """Stored error text of a request: final payload -> vector index -> (deep) archived zip.
    The final-build payload usually has NO error text (errors ride the archive zips)."""
    row = get_final_build_payload(rid) or {}
    payload = row.get("payload_json") if isinstance(row, dict) else {}
    if not isinstance(payload, dict):
        payload = row if isinstance(row, dict) else {}
    msgs = handlers._extract_error_messages(payload, include_context=False)
    if msgs:
        return str(msgs[0]), "final_build_payload"
    for r in get_vector_references(rid) or []:
        h = str((r or {}).get("error_signature_hash") or "").strip().lower()
        if not h:
            continue
        idx = get_error_vector_index(project, env, h) or {}
        m = str(idx.get("error_message") or "").strip()
        if m:
            return m, "error_vector_index"
    if deep:
        try:
            for ar in handlers.get_archived_payload_references(rid) or []:
                s3_key = str((ar or {}).get("s3_key") or "").strip()
                if not s3_key:
                    continue
                try:
                    ap = handlers.download_payload_zip(s3_key=s3_key, expected_sha256=(ar or {}).get("sha256"))
                except Exception:
                    continue
                msgs = handlers._extract_error_messages(ap, include_context=False)
                if msgs:
                    return str(msgs[0]), "archived_payload_zip"
        except Exception:
            pass
    return "", ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default="TESTGBE",
                    help="project name (default TESTGBE; lowercased automatically like the pipeline does)")
    ap.add_argument("--expect", default="", help="request_id that SHOULD appear in the results")
    ap.add_argument("--text", default="", help="query error text (else: expected request's own stored text)")
    ap.add_argument("--text-file", default="", help="file containing the query error text")
    ap.add_argument("--task-path", default="")
    ap.add_argument("--changed-files", default="", help="comma-separated file names of the current cycle")
    ap.add_argument("--artifact-file", default="", help="file with artifact excerpt text (optional)")
    ap.add_argument("--find", default="", help="list mode filter: only entries whose fix touches this file name")
    args = ap.parse_args()

    project = args.project.strip().lower()
    expect = args.expect.strip()
    env = str(config.APP_ENV or "test").strip().lower() or "test"

    # LIST MODE: no --expect and no query text -> show the stored entries so a real
    # request_id can be copied (optionally filtered by --find <file name>).
    if not expect and not args.text and not args.text_file:
        _p(f"STORED SOLUTION ENTRIES for project '{project}' (use --expect <request_id>)")
        want = args.find.strip().lower()
        shown = 0
        for row in list_final_build_payloads_by_project(project) or []:
            payload = row.get("payload_json") if isinstance(row, dict) else {}
            if not isinstance(payload, dict):
                continue
            rid = str(row.get("request_id") or "").strip()
            sol = payload.get("solution") or []
            files = sorted({
                str((s or {}).get("fileName") or (s or {}).get("filePath") or "").replace("\\", "/").split("/")[-1]
                for s in sol if isinstance(s, dict)
            } - {""})
            if want and not any(want in f.lower() for f in files):
                continue
            err_text, err_src = _stored_error_text(rid, project, env, deep=True)  # S3 zip download - a bit slow
            preview = err_text[:110].replace("\n", " ") + (f"  [{err_src}]" if err_src else "")
            print(f"request_id={rid}")
            print(f"  task={row.get('task_name') or payload.get('taskName')!r}  date={row.get('created_date')}")
            print(f"  fix files: {files}")
            print(f"  error: {preview!r}\n")
            shown += 1
        print(f"{shown} entries." + (f"  (filter: fix touches '{want}')" if want else "")
              + "\nNext: python probe_reco_debug.py --expect REQUEST_ID_FROM_ABOVE")
        return
    changed_files = [x.strip() for x in args.changed_files.split(",") if x.strip()]
    artifact_text = ""
    if args.artifact_file:
        with open(args.artifact_file, "r", encoding="utf-8", errors="replace") as f:
            artifact_text = f.read()

    # ---------------- A. environment + threshold ----------------
    _p("A. ENVIRONMENT + THRESHOLD")
    print(f"project={project}  env={env}")
    admin_cfg = {}
    try:
        admin_cfg = rc.get_config(force=True)
    except Exception as e:
        print(f"admin threshold store UNREADABLE: {type(e).__name__}: {e}")
    admin_pct = float((admin_cfg or {}).get("minSimilarityPercent") or 0)
    env_min = float(getattr(config, "RECOMMENDATION_MIN_FINAL_SCORE", 0.0) or 0.0)
    effective = (admin_pct / 100.0) * 30.0 if admin_pct > 0 else env_min
    print(f"admin minSimilarityPercent = {admin_pct}  (store: {json.dumps(admin_cfg, default=str)})")
    print(f"env RECOMMENDATION_MIN_FINAL_SCORE = {env_min}")
    print(f"EFFECTIVE min_final = {effective}  ({'OFF - everything shows' if effective <= 0 else 'gating ON'})")

    # ---------------- B. expected request health ----------------
    expected_hashes = set()
    if expect:
        _p(f"B. EXPECTED REQUEST HEALTH: {expect}")
        payload_row = get_final_build_payload(expect) or {}
        payload = payload_row.get("payload_json") if isinstance(payload_row, dict) else {}
        if not isinstance(payload, dict):
            payload = payload_row if isinstance(payload_row, dict) else {}
        if not payload:
            print("final_build_payload: MISSING  <-- no solution stored for this request at all")
        else:
            sol = payload.get("solution") or []
            files = [str((s or {}).get("fileName") or (s or {}).get("filePath") or "") for s in sol if isinstance(s, dict)]
            print(f"final_build_payload: OK  task_name={payload_row.get('task_name') or payload.get('taskName')!r}")
            print(f"solution files ({len(files)}): {files}")

        refs = get_vector_references(expect) or []
        print(f"vector_references rows: {len(refs)}")
        for r in refs:
            h = str((r or {}).get("error_signature_hash") or "").strip().lower()
            if h:
                expected_hashes.add(h)
            print(f"  vector_id={(r or {}).get('vector_id')}  sig={h[:16]}  file={(r or {}).get('file_name')}")

        # The Dynamo signature tables are keyed by (project, env) — probe every plausible
        # key spelling so a case/env mismatch is reported as such, not as missing data.
        key_variants = []
        for p in (project, args.project.strip()):
            for e in (env, "prod", "test", "dev"):
                if p and (p, e) not in key_variants:
                    key_variants.append((p, e))
        for h in sorted(expected_hashes):
            hit_key, idx, summ, rows = None, {}, {}, []
            for (p, e) in key_variants:
                idx_v = get_error_vector_index(p, e, h) or {}
                summ_v = get_error_signature_summary(p, e, h) or {}
                rows_v = get_error_solution_references_summary_first(p, e, h) or []
                if idx_v or summ_v or rows_v:
                    hit_key, idx, summ, rows = (p, e), idx_v, summ_v, rows_v
                    break
            in_refs = [str((x or {}).get("request_id") or "") for x in rows]
            pos = in_refs.index(expect) + 1 if expect in in_refs else -1
            print(f"signature {h[:16]}:")
            if hit_key is None:
                print(f"  NO index/summary/reference rows under ANY key variant {key_variants}")
                continue
            if hit_key != (project, env):
                print(f"  !! rows live under key {hit_key} instead of ({project!r}, {env!r}) — key mismatch")
            print(f"  vector index -> vector_id={idx.get('vector_id') or 'MISSING'}")
            print(f"  summary latest_request_id={summ.get('latest_request_id')!r}"
                  f"  latest_task_path={summ.get('latest_task_path')!r}")
            print(f"  solution reference rows={len(rows)}  expected at position={pos}"
                  f"  {'<-- NOT LINKED to this signature!' if pos < 0 else ''}")

    # ---------------- C. query construction ----------------
    _p("C. QUERY CONSTRUCTION")
    text = args.text
    if not text and args.text_file:
        import os
        if not os.path.isfile(args.text_file):
            print(f"ERROR: file not found: {args.text_file}")
            print("Create it first with the tester's error text, e.g.:")
            print(f"  notepad {args.text_file}   (paste the error text from the dashboard/popup, save)")
            print("Then rerun this same command.")
            sys.exit(2)
        with open(args.text_file, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    if not text and expect:
        text, src = _stored_error_text(expect, project, env, deep=True)
        if text:
            print(f"(no --text given: using expected request's OWN stored error text, source={src})")
    if not text:
        print("ERROR: no query text — pass --text/--text-file or an --expect with a stored payload")
        sys.exit(2)

    errors = [{"severity": "ERROR", "message": text, "locations": []}]
    query_candidates = handlers._build_recommendation_query_candidates(errors) or [text]
    query_candidates = query_candidates[:10]
    msg = query_candidates[0]
    query_hashes = handlers._signature_hashes_from_candidates(query_candidates, max_hashes=10)
    print(f"query text preview: {text[:200]!r}")
    print(f"query candidates: {len(query_candidates)}   anchor: {msg[:120]!r}")
    print(f"query signature hashes: {[h[:16] for h in query_hashes]}")
    if expect:
        overlap = expected_hashes.intersection({h.lower() for h in query_hashes})
        print(f"hash overlap with expected request: {[h[:16] for h in overlap] or 'NONE'}"
              f"{'  <-- exact stage CANNOT fire; texts differ after normalization' if expected_hashes and not overlap else ''}")
    print(f"task_path={args.task_path!r}  changed_files={changed_files}  artifact_text={len(artifact_text)} chars")

    # ---------------- D. raw retrieval (exact + semantic, pre-fusion top10) ----------------
    _p("D. RAW RETRIEVAL (_search_recommendation_matches, search_top_k=10)")
    sr = handlers._search_recommendation_matches(
        project_name=project, query_candidates=query_candidates, top_k=10, task_path=args.task_path or None,
    )
    matches = sr.get("vector_matches") or []
    print(f"exact_match_count={sr.get('exact_match_count')}  total raw matches={len(matches)}")
    found_raw = False
    for i, m in enumerate(matches):
        rid = _rid(m.get("meta"))
        mark = "  <== EXPECTED" if expect and rid == expect else ""
        if mark:
            found_raw = True
        doc = str((m.get("meta") or {}).get("document") or m.get("document") or "")[:90].replace("\n", " ")
        print(f"  #{i+1:>2} type={str(m.get('match_type') or '?'):<9} req={rid}  vec={str(m.get('vector_id'))[:24]}  doc={doc!r}{mark}")
    if expect and not found_raw:
        print(">>> EXPECTED REQUEST NOT IN RAW RETRIEVAL — the miss is at SEARCH, not ranking.")
        print(">>> Check section B: vector index / reference rows / hash overlap above tell you why.")

    # ---------------- E. hydration ----------------
    _p("E. HYDRATION (one request = one candidate, solution attached by request_id)")
    recommendation_context = handlers._extract_recommendation_context(errors)
    if args.task_path and args.task_path.lower() not in {t.lower() for t in recommendation_context["task_paths"]}:
        recommendation_context["task_paths"].insert(0, args.task_path)
    recs = handlers._hydrate_recommendations(
        vector_matches=matches, project_name=project, top_k=10,
        recommendation_context=recommendation_context,
        current_query_signatures=sr.get("query_signature_hashes"),
    )
    found_hyd = False
    for i, r in enumerate(recs):
        mark = "  <== EXPECTED" if expect and r.get("request_id") == expect else ""
        if mark:
            found_hyd = True
        sol_files = sorted(handlers._candidate_solution_file_names(r))
        print(f"  #{i+1:>2} req={r.get('request_id')}  final={float(r.get('final_score') or 0):6.2f}"
              f"  type={r.get('match_type')}  task={str(r.get('task_name') or '')[:30]!r}  fix_files={sol_files}{mark}")
    if expect and found_raw and not found_hyd:
        print(">>> EXPECTED was in raw retrieval but LOST AT HYDRATION (duplicate request collapsed"
              " onto an earlier vector, or empty meta). See D order — an earlier match with the same"
              " request_id keeps the slot.")

    # ---------------- F. deterministic re-rank + fix dedup ----------------
    _p("F. RE-RANK (downvote-sink > task > changed-file > relevance > thumbs) + fix dedup")
    file_signal = changed_files or (recommendation_context or {}).get("file_names") or []
    print(f"file signal used: {file_signal}  (source: {'changed_files' if changed_files else 'error locations fallback'})")
    reranked = handlers._rerank_recommendations_for_relevance(
        list(recs), query_text=msg, query_task_path=args.task_path,
        query_artifact_text=artifact_text, query_file_names=file_signal,
    )
    reranked = handlers._dedupe_recommendations_by_fix(reranked)
    found_rr = False
    for i, r in enumerate(reranked):
        dbg = r.get("relevance_rerank") or {}
        mark = "  <== EXPECTED" if expect and r.get("request_id") == expect else ""
        if mark:
            found_rr = True
        print(f"  #{i+1:>2} req={r.get('request_id')}  task_hit={dbg.get('task_hit')}"
              f"  file_hit={dbg.get('file_hit')}  relevance={dbg.get('relevance')}"
              f"  artifact={dbg.get('artifact_score')}  down={dbg.get('downvoted')}{mark}")
    if expect and found_hyd and not found_rr:
        print(">>> EXPECTED lost at FIX-DEDUP: another request carries the IDENTICAL solution content"
              " and ranked higher — the shown entry IS the same fix under a different request_id.")

    # ---------------- G. threshold gate (top-3) ----------------
    _p("G. THRESHOLD GATE (top_k=3)")
    for i, r in enumerate(reranked[:6]):
        ev = handlers._evaluate_recommendation_strength(dict(r))
        print(f"  #{i+1:>2} req={r.get('request_id')}  final={float(r.get('final_score') or 0):6.2f}"
              f"  confidence={float(ev.get('confidence_score') or 0):.3f}  match_status={ev.get('match_status')}")
    gated = handlers._gate_recommendation_results(reranked, top_k=3, track_hits=False)
    vis = gated.get("recommendations") or []
    print(f"VISIBLE={len(vis)}  match_status={gated.get('match_status')}"
          f"  confidence={gated.get('confidence_score')}")
    for i, r in enumerate(vis):
        mark = "  <== EXPECTED" if expect and r.get("request_id") == expect else ""
        print(f"  visible #{i+1}: req={r.get('request_id')}  final={float(r.get('final_score') or 0):6.2f}{mark}")

    # ---------------- H. verdict ----------------
    if expect:
        _p("H. VERDICT")
        stages = [("raw retrieval", found_raw), ("hydration", found_hyd), ("re-rank+dedup", found_rr),
                  ("visible top-3", any(r.get("request_id") == expect for r in vis))]
        for name, ok in stages:
            print(f"  {name:<15} {'PRESENT' if ok else 'ABSENT'}")
        first_missing = next((n for n, ok in stages if not ok), None)
        print(f"\n  First stage where the expected request is missing: {first_missing or 'NONE - it is visible'}")


if __name__ == "__main__":
    main()
