"""
Diagnostic script: verify Azure AI Search index + embedding storage is working.
Run: python check_azure_search.py

Checks:
  1. Can connect to Azure AI Search
  2. Index exists and has the correct schema
  3. Can insert a test document with a real embedding
  4. Can retrieve it back via vector search
  5. Cleans up the test document
"""

import os
import re
import sys
from dotenv import load_dotenv
load_dotenv(override=True)   # must happen before any os.getenv() call

APP_ENV        = os.getenv("APP_ENV", "uat").strip().lower()
_SFX           = "" if APP_ENV in ("uat", "prod", "") else f"_{APP_ENV}"
AZURE_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT", "https://cscspq001aiswbuildq.search.windows.net")


def _to_index_name(name: str) -> str:
    """Azure index names allow only lowercase letters/digits/dashes (no underscores) — same rule as
    migrate_chroma_to_azure.py. error_with_solution_dev -> error-with-solution-dev."""
    n = str(name or "").strip().lower()
    if re.fullmatch(r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", n):
        return n
    return re.sub(r"-{2,}", "-", re.sub(r"[^a-z0-9]+", "-", n)).strip("-")


TEST_INDEX     = _to_index_name(os.getenv("CHROMA_COLLECTION_ERROR", f"error_with_solution{_SFX}"))
TEST_DOC_ID    = "check-azure-search-test"   # Azure keys cannot start with a leading underscore

PASS = "\033[92m[PASS]\033[0m"
FAIL = "\033[91m[FAIL]\033[0m"
INFO = "\033[94m[INFO]\033[0m"


def _get_credential():
    from src.configurations.config import AZURE_CREDENTIAL
    return AZURE_CREDENTIAL


def step(label: str):
    print(f"\n{INFO} {label}")


def ok(msg: str):
    print(f"  {PASS} {msg}")


def fail(msg: str, exc=None):
    print(f"  {FAIL} {msg}")
    if exc:
        print(f"         {type(exc).__name__}: {exc}")
    sys.exit(1)


def main():
    print("=" * 60)
    print("  Azure AI Search — embedding storage check")
    print(f"  Endpoint : {AZURE_ENDPOINT}")
    print(f"  Index    : {TEST_INDEX}")
    print(f"  APP_ENV  : {APP_ENV}")
    print("=" * 60)

    # 1. Credential
    step("1. Building Azure credential (same as LLM/embedding calls)")
    try:
        credential = _get_credential()
        ok(f"Credential ready — type: {type(credential).__name__}")
    except Exception as e:
        fail("Failed to build credential", e)

    # 2. Connect to index client
    step("2. Connecting to Azure AI Search index client")
    try:
        from azure.search.documents.indexes import SearchIndexClient
        index_client = SearchIndexClient(endpoint=AZURE_ENDPOINT, credential=credential)
        indexes = [idx.name for idx in index_client.list_indexes()]
        ok(f"Connected. Indexes found: {indexes or '(none)'}")
    except Exception as e:
        fail("Cannot connect to Azure AI Search", e)

    # 3. Check target index exists
    step(f"3. Checking index '{TEST_INDEX}' exists")
    if TEST_INDEX not in indexes:
        print(f"  Index '{TEST_INDEX}' not found — it will be auto-created on first use by the app.")
        print(f"  Skipping embedding test. Create the index first by running migrate_chroma_to_azure.py")
        print("\nDone.")
        return
    ok(f"Index '{TEST_INDEX}' exists")

    # 4. Inspect schema
    step("4. Inspecting index schema")
    try:
        idx_def = index_client.get_index(TEST_INDEX)
        field_names = [f.name for f in idx_def.fields]
        required = ["id", "document", "embedding", "project_name", "error_signature_hash",
                    "is_artifact_summary", "content_sha256"]
        missing = [f for f in required if f not in field_names]
        if missing:
            fail(f"Schema missing fields: {missing}")
        ok(f"Schema OK — {len(field_names)} fields present")
        print(f"         Fields: {', '.join(field_names)}")
    except Exception as e:
        fail("Failed to inspect schema", e)

    # 5. Generate a real embedding
    step("5. Generating a test embedding via Azure OpenAI")
    try:
        from src.utils.oai_client import create_embedding
        test_text = "Azure AI Search embedding connectivity test"
        embedding = create_embedding(test_text)
        if not embedding or len(embedding) < 100:
            fail(f"Embedding looks wrong — length={len(embedding) if embedding else 0}")
        ok(f"Embedding generated — dim={len(embedding)}")
    except Exception as e:
        fail("Failed to generate embedding", e)

    # 6. Insert test document
    step("6. Inserting test document into Azure AI Search")
    try:
        from azure.search.documents import SearchClient
        search_client = SearchClient(endpoint=AZURE_ENDPOINT, index_name=TEST_INDEX, credential=credential)
        doc = {
            "id":                  TEST_DOC_ID,
            "document":            test_text,
            "embedding":           embedding,
            "project_name":        "__check__",
            "error_signature_hash": "",
            "is_artifact_summary": False,
            "summary_total_tokens": 0,
        }
        result = search_client.upload_documents([doc])
        if not result[0].succeeded:
            fail(f"Upload failed: {result[0].key} — {result[0].error_message}")
        ok("Document inserted successfully")
    except Exception as e:
        fail("Failed to insert test document", e)

    # 7. Retrieve via vector search
    step("7. Retrieving test document via vector search")
    try:
        import time
        time.sleep(2)  # allow indexing to propagate
        from azure.search.documents.models import VectorizedQuery
        vq = VectorizedQuery(vector=embedding, k_nearest_neighbors=3, fields="embedding")
        results = list(search_client.search(
            search_text=None,
            vector_queries=[vq],
            filter="project_name eq '__check__'",
            select=["id", "document"],
            top=3,
        ))
        hit = next((r for r in results if r.get("id") == TEST_DOC_ID), None)
        if not hit:
            fail(f"Test document not found in search results (got {len(results)} results)")
        ok(f"Vector search returned test document — score={results[0].get('@search.score', '?'):.4f}")
    except Exception as e:
        fail("Vector search failed", e)

    # 8. Cleanup
    step("8. Cleaning up test document")
    try:
        search_client.delete_documents([{"id": TEST_DOC_ID}])
        ok("Test document deleted")
    except Exception as e:
        print(f"  (cleanup failed — delete '{TEST_DOC_ID}' manually if needed): {e}")

    print()
    print("=" * 60)
    print(f"  {PASS} All checks passed — Azure AI Search is working correctly")
    print("=" * 60)


if __name__ == "__main__":
    main()
