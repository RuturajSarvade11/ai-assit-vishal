"""
Backfill the adapter-state flag on EXISTING feedback votes (adapter-impact card).

New votes record whether the W adapter was active at vote time (adapter_enabled). Votes from
before that tracking have no flag and show as "untracked" — the impact card says "Collecting
data" until both buckets fill. This tool lets you (1) SEE what vote data exists per project,
then (2) tag the untracked votes with an explicit state so the card shows real data.

Honesty rules built in:
  - Nothing is written without --apply (default is a report / dry run).
  - You choose the state; the tool never guesses. Historical default in dev is "off"
    (FEEDBACK_ADAPTER_ENABLED=0 — the adapter was not influencing recommendations).
  - Every backfilled row also gets adapter_backfilled=true, so backfilled and live-tagged
    votes stay distinguishable forever (and the backfill is identifiable/reversible).

Run in the backend venv with APP_ENV set (on the server):
    python backfill_adapter_impact_flags.py                          # report only, all projects
    python backfill_adapter_impact_flags.py --project testgbe        # report one project
    python backfill_adapter_impact_flags.py --project testgbe --apply --state off
    python backfill_adapter_impact_flags.py --apply --state off      # all untracked votes
"""
import argparse
from collections import defaultdict

from src.utils.project_details import ai_assisted_data_table, list_all_recommendation_feedback


def report(votes, project_filter):
    per_project = defaultdict(lambda: {"helpful": 0, "not_helpful": 0,
                                       "tracked": 0, "untracked": 0})
    for vote in votes:
        proj = str(vote.get("project_name") or "unknown").strip().lower()
        if project_filter and proj != project_filter:
            continue
        row = per_project[proj]
        if vote.get("is_helpful") is True:
            row["helpful"] += 1
        elif vote.get("is_helpful") is False:
            row["not_helpful"] += 1
        if "adapter_enabled" in vote:
            row["tracked"] += 1
        else:
            row["untracked"] += 1

    print(f"{'project':30} {'helpful':>8} {'not_helpful':>12} {'tracked':>8} {'untracked':>10}")
    for proj in sorted(per_project):
        row = per_project[proj]
        print(f"{proj:30} {row['helpful']:>8} {row['not_helpful']:>12} "
              f"{row['tracked']:>8} {row['untracked']:>10}")
    total_untracked = sum(r["untracked"] for r in per_project.values())
    print(f"\nuntracked votes in scope: {total_untracked}")
    return total_untracked


def apply_backfill(votes, project_filter, state: bool):
    updated = 0
    for vote in votes:
        proj = str(vote.get("project_name") or "").strip().lower()
        if project_filter and proj != project_filter:
            continue
        if "adapter_enabled" in vote:
            continue   # live-tagged or already backfilled — never overwritten
        ai_assisted_data_table.update_item(
            Key={"PK": vote["PK"], "SK": vote["SK"]},
            UpdateExpression="SET adapter_enabled = :state, adapter_backfilled = :marker",
            ExpressionAttributeValues={":state": bool(state), ":marker": True},
        )
        updated += 1
    print(f"backfilled {updated} votes as adapter_enabled={state} (marked adapter_backfilled=true)")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", default="", help="limit to one project name")
    parser.add_argument("--apply", action="store_true", help="write the flags (default: report only)")
    parser.add_argument("--state", choices=["on", "off"], default="off",
                        help="state to backfill untracked votes with (default off = historical dev state)")
    args = parser.parse_args()

    project_filter = args.project.strip().lower()
    votes = list_all_recommendation_feedback()
    print(f"total feedback votes found: {len(votes)}\n")

    untracked = report(votes, project_filter)
    if not args.apply:
        print("\nDRY RUN - nothing written. Add --apply --state off|on to backfill.")
        return
    if untracked == 0:
        print("\nnothing to backfill.")
        return
    apply_backfill(votes, project_filter, args.state == "on")
    print("\nre-run without --apply to verify; the impact card updates within its cache minute.")


if __name__ == "__main__":
    main()
