"""
debug_extension_usage.py — what did the database actually capture?

Run this on the server when the Extension Usage tab shows nothing, or shows fewer developers
than expected. It reads the real rows and says which link in the chain is missing, rather than
leaving the answer to be inferred from an empty screen.

    python debug_extension_usage.py
    python debug_extension_usage.py --days 7
    python debug_extension_usage.py --raw          # dump the rows as stored

Read-only. It writes nothing and changes no setting.

The chain it walks, in order, because a break anywhere upstream makes everything below empty:

    1. is identity capture switched on           (dashboard toggle -> settings row)
    2. has any installation reported at all       (EXTUSAGE#... / PROFILE rows)
    3. is any build counted                       (EXTUSAGE#... / USE#date#project rows)
    4. does any profile carry a sealed identity   (dev_key / identity_sealed)
    5. what the per-developer list would show
"""
import argparse
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, UTC

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _rule(title):
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--days", type=int, default=30, help="window for the counts (default 30)")
    ap.add_argument("--raw", action="store_true", help="dump every row as stored")
    args = ap.parse_args()

    from src.services import extension_usage as eu
    from src.utils.project_details import (scan_kpi_rows, EXTUSAGE_PROFILE_SK,
                                           EXTUSAGE_PK_PREFIX)

    print(f"APP_ENV={os.getenv('APP_ENV', '(unset)')}  "
          f"table suffix={os.getenv('DYNAMODB_TABLE_SUFFIX', '(unset)')}")

    # ---------------------------------------------------------------- 1. the switch
    _rule("1. Is identity capture switched on?")
    try:
        from src.services import extension_identity_settings as settings
        state = settings.get_settings(force=True)
        print(f"   stored setting : enabled={state.get('enabled')} "
              f"(last changed by {state.get('updated_by') or 'nobody'})")
    except Exception as exc:
        print(f"   settings row unreadable: {exc}")
    print(f"   env seed       : EXT_IDENTITY_CAPTURE={os.getenv('EXT_IDENTITY_CAPTURE', '(unset)')}")
    capture_on = eu.identity_enabled()
    print(f"   EFFECTIVE      : {'ON - logins are sealed on arrival' if capture_on else 'OFF - no login is stored'}")

    # ---------------------------------------------------------------- rows
    rows = scan_kpi_rows(budget_sec=30)
    usage = rows.get("usage") or []
    profiles = [r for r in usage if r.get("SK") == EXTUSAGE_PROFILE_SK]
    daily = [r for r in usage if r.get("SK") != EXTUSAGE_PROFILE_SK]
    print(f"\n   scanned {rows.get('scanned')} rows in {rows.get('seconds')}s"
          + ("  (PARTIAL - hit the time budget)" if rows.get("partial") else ""))

    # ---------------------------------------------------------------- 2. installations
    _rule("2. Has any installation reported?")
    if not profiles:
        print("   NONE.")
        print("   -> No extension has announced itself. Either no build has run since the new")
        print("      version was installed, or the installed extension predates adoption")
        print("      reporting. The backend log shows '[ext-usage] no installId on this upload'")
        print("      for every build from an older extension.")
    else:
        print(f"   {len(profiles)} installation(s):\n")
        print(f"   {'install':<14}{'version':<10}{'first seen':<12}{'last seen':<12}{'identity'}")
        for p in sorted(profiles, key=lambda r: str(r.get("last_seen") or ""), reverse=True):
            ident = ("sealed + encrypted" if p.get("identity_sealed")
                     else ("sealed only" if p.get("dev_key") else "-"))
            print(f"   {str(p.get('PK') or '')[len(EXTUSAGE_PK_PREFIX):][:12]:<14}"
                  f"{str(p.get('ext_version') or '?'):<10}"
                  f"{str(p.get('first_seen') or '')[:10]:<12}"
                  f"{str(p.get('last_seen') or '')[:10]:<12}{ident}")

    # ---------------------------------------------------------------- 3. builds
    _rule("3. Are builds being counted?")
    if not daily:
        print("   NO daily rows.")
        if profiles:
            print("   -> Installations announced themselves but no build has been counted yet.")
            print("      Run a build; the count appears on the next upload.")
    else:
        window = (datetime.now(UTC) - timedelta(days=args.days - 1)).strftime("%Y-%m-%d")
        per_day = defaultdict(lambda: [0, 0])
        for r in daily:
            if str(r.get("use_date") or "") >= window:
                per_day[str(r.get("use_date"))][0] += int(r.get("builds") or 0)
                per_day[str(r.get("use_date"))][1] += int(r.get("failures") or 0)
        print(f"   {len(daily)} daily row(s); last {args.days} days:\n")
        print(f"   {'date':<14}{'builds':>8}{'failures':>10}")
        for d in sorted(per_day):
            print(f"   {d:<14}{per_day[d][0]:>8}{per_day[d][1]:>10}")
        if not per_day:
            print("   (none inside the window - all activity is older)")

    # ---------------------------------------------------------------- 4. identity
    _rule("4. Do any installations carry a developer identity?")
    with_key = [p for p in profiles if p.get("dev_key")]
    with_seal = [p for p in profiles if p.get("identity_sealed")]
    print(f"   installations with a grouping value : {len(with_key)} of {len(profiles)}")
    print(f"   installations with a revealable copy: {len(with_seal)} of {len(profiles)}")
    if profiles and not with_key:
        print("\n   -> This is the usual cause of an empty per-developer list.")
        if not capture_on:
            print("      Capture is OFF, so arriving logins are discarded. Switch it on, then")
            print("      RELOAD the developer's window (or wait for their next build) - the")
            print("      identity is attached when the extension next reports.")
        else:
            print("      Capture is ON but no login has arrived. The extension decides whether to")
            print("      send one by asking this server, so check:")
            print("        - the extension is 2.3.10 or newer (older builds never ask, and")
            print("          versions before 2.3.9 send no installId at all)")
            print("        - GET /extension-usage/capture-state returns enabled=true")
            print("        - the developer has not set gradleErrorAssistant.usage.identifyDeveloper")
            print("          to false, which is a local refusal that overrides this server")

    # ---------------------------------------------------------------- 5. the list
    _rule("5. What the per-developer list would show")
    block = eu._developers((datetime.now(UTC) - timedelta(days=args.days - 1)).strftime("%Y-%m-%d"),
                           usage)
    if not block.get("enabled"):
        print("   Switched off, so the screen shows the explanation instead of rows.")
    elif not block.get("rows"):
        print("   Enabled, but no developer rows - see section 4.")
    else:
        print(f"   {'developer':<14}{'machines':>9}{'builds':>8}{'failures':>10}  versions")
        for r in block["rows"]:
            print(f"   {r['developer']:<14}{r['installs']:>9}{r['builds']:>8}{r['failures']:>10}"
                  f"  {', '.join(r.get('versions') or []) or '-'}")

    # ---------------------------------------------------------------- versions
    if profiles:
        _rule("Extension versions in use")
        for version, n in Counter(str(p.get("ext_version") or "unknown")
                                  for p in profiles).most_common():
            print(f"   {version:<12}{n} installation(s)")

    if args.raw:
        _rule("Raw rows")
        for r in usage:
            print("  ", {k: v for k, v in r.items() if k != "identity_sealed"})

    print()


if __name__ == "__main__":
    main()
