"""
seed_auth_users.py — create the auth_users table (if missing) and seed the dashboard users.

Each user gets an EASY default password and must_change_password=True, so they set their own
strong password (>= 8 chars, upper+lower+digit+special) on first login. Run once in the backend venv:

    python seed_auth_users.py

When SSO arrives this is replaced by SSO identity; the role mapping stays.
"""
from src.databases.database import get_dynamodb
from src.auth.security import hash_password
from src.auth.users import USERS_TABLE, put_user, SEED_USERS as USERS


def ensure_table():
    ddb = get_dynamodb()
    existing = [t.name for t in ddb.tables.all()]
    if USERS_TABLE in existing:
        print(f"  table {USERS_TABLE} already exists")
        return
    print(f"  creating table {USERS_TABLE} ...")
    ddb.create_table(
        TableName=USERS_TABLE,
        KeySchema=[{"AttributeName": "username", "KeyType": "HASH"}],
        AttributeDefinitions=[{"AttributeName": "username", "AttributeType": "S"}],
        BillingMode="PAY_PER_REQUEST",
    ).wait_until_exists()
    print("  created.")


def main():
    print("=" * 60)
    print("  Seeding dashboard auth users")
    print("=" * 60)
    ensure_table()
    for username, name, info, role, default_pw in USERS:
        put_user(username, name, info, role, hash_password(default_pw), must_change=True)
        print(f"  seeded {username:8s} role={role:6s} default={default_pw:12s} (must change on first login)")
    print("\nDone. Give each person their username + default password; they set their own on first login.")


if __name__ == "__main__":
    main()
