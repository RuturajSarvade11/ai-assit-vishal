"""
Expected vs actual, in one table. Run it after any scoring or data change.

Each scenario is a real failure (the live debug.log a developer would have) and the fix that
SHOULD come first. Expectation is matched on the fix's CONTENT - which tool it corrects - not on
a request id, so it stays valid when twins of the same fix swap places or new solutions are
stored. Scoring problems and DATA problems are reported separately, because no weighting can
fix a solution that carries the wrong log.

    python accuracy_test.py
"""
import json
import re
import sys

import src.utils.log_setup  # noqa: F401
from src.services import handlers

TASK = ":TARGETS:master:task4"
PREAMBLE = r"""Created inputs snapshot in [4] ms
Copied input files in [5] ms
Creating snapshot for [c:\LegacyApp\ctc_aurix\6.2r1p4].
Local installation of tool ctc_aurix:6.2r1p4 is UP-TO-DATE
Starting the execution of the command line(s)  for the GBE process task4
cmd /c c:/LegacyApp/python/3.10.0/python.exe
D:\Build type error\TestGbe\build\master\task4/in/read_json_config.py
Error parsing input file
"""
LOG_HEAD = r"""2026-08-25 13:45:43,064 [INFO] read_json_config.py starting...
2026-08-25 13:45:43,064 [DEBUG] Reading JSON file from disk.
2026-08-25 13:45:43,066 [DEBUG] Starting validation for config root keys: ['project', 'build', 'tools', 'targets']
2026-08-25 13:45:43,066 [ERROR] Error parsing input file
"""

SCENARIOS = [
    {"name": "python version failure",
     "root_cause": "'tools[name=python].version' must be '3.10.0' but got '3.1111.0'.",
     "expect_tool": "python"},
    {"name": "ctc_aurix version failure",
     "root_cause": "'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p5'.",
     "expect_tool": "ctc_aurix"},
]


def _solution_text(node) -> str:
    """Flatten a stored solution to plain text - it holds dicts in some records and strings in
    others, and json escaping would hide the quotes we need to read."""
    out = []

    def walk(n):
        if isinstance(n, dict):
            for v in n.values():
                walk(v)
        elif isinstance(n, list):
            for v in n:
                walk(v)
        elif n is not None:
            out.append(str(n))

    walk(node)
    return " ".join(out)


def _solution_tool(rec) -> str:
    """Which tool this fix corrects, read from its own change lines."""
    m = re.search(r'name="([^"]+)"', _solution_text(rec.get("solution") or []))
    return m.group(1) if m else "?"


def _artifact_tool(rec) -> str:
    """Which tool the artifact ATTACHED to this fix blames - the data-integrity check."""
    doc = str((rec.get("artifact_matched") or {}).get("file_name") or "")
    for tool in ("ctc_aurix", "python"):
        if tool in str(rec.get("evidence_preview") or ""):
            return tool
    return doc and "?" or "-"


def run(scenario) -> dict:
    log = LOG_HEAD + "2026-08-25 13:45:43,068 [DEBUG] " + scenario["root_cause"]
    result = handlers._run_report_error_recommendation(
        project_name="testgbe",
        errors=[{"severity": "ERROR", "message": PREAMBLE + scenario["root_cause"],
                 "task_path": TASK, "file_path": "task4.process.gradle.kts"}],
        task_path=TASK,
        query_artifact_text="debug.log\n" + log,
        query_changed_files=["config.xml"],
        user_requested_task="TARGETS:master:task4",
        query_artifact_excerpts=[{"name": "debug.log", "text": log}],
    )
    recs = (result or {}).get("recommendations") or []
    top = recs[0] if recs else {}
    runner = recs[1] if len(recs) > 1 else {}
    return {
        "trace": str((result or {}).get("trace_id") or ""),
        "actual_tool": _solution_tool(top),
        "top_id": str(top.get("request_id") or "")[:8],
        "top_score": float(top.get("final_score") or 0.0),
        "top_art": float(top.get("artifact_match_similarity") or 0.0),
        "next_id": str(runner.get("request_id") or "")[:8],
        "next_score": float(runner.get("final_score") or 0.0),
        "next_art": float(runner.get("artifact_match_similarity") or 0.0),
    }


def main() -> int:
    print(f"{'scenario':<28}{'expected':<12}{'actual':<12}{'result':<8}"
          f"{'top':<10}{'score':>8}{'art':>7}   {'runner-up':<10}{'score':>8}{'art':>7}")
    print("-" * 116)
    failures = 0
    rows = []
    for sc in SCENARIOS:
        try:
            r = run(sc)
        except Exception as exc:
            print(f"{sc['name']:<28}{sc['expect_tool']:<12}{'ERROR':<12}{'FAIL':<8}{exc}")
            failures += 1
            continue
        ok = r["actual_tool"] == sc["expect_tool"]
        failures += 0 if ok else 1
        rows.append((sc, r, ok))
        print(f"{sc['name']:<28}{sc['expect_tool']:<12}{r['actual_tool']:<12}"
              f"{'PASS' if ok else 'FAIL':<8}{r['top_id']:<10}{r['top_score']:>8.2f}{r['top_art']:>7.3f}"
              f"   {r['next_id']:<10}{r['next_score']:>8.2f}{r['next_art']:>7.3f}")
    print()
    # Data check: near-identical artifact evidence between the two families means at least one
    # solution carries a log from the OTHER failure - a data problem no weighting can fix.
    for sc, r, ok in rows:
        if r["top_art"] and r["next_art"] and abs(r["top_art"] - r["next_art"]) < 0.05:
            print(f"DATA WARNING [{sc['name']}]: {r['top_id']} and {r['next_id']} have almost the same "
                  f"artifact evidence ({r['top_art']:.3f} vs {r['next_art']:.3f}). One of them very likely "
                  f"carries the OTHER failure's log. Check with:")
            print(f"    python debug_request.py <full request id>")
    print()
    print(f"RESULT: {len(rows) - failures}/{len(rows)} scenarios correct"
          + ("" if failures else "  -  ranking decided by evidence, algorithm only"))
    for sc, r, ok in rows:
        print(f"  trace {r['trace']}  ({sc['name']})")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
