# Recommendation scoring: how every number is calculated

Scope: the report-error recommendation (`handle_report_errors` ->
`_run_report_error_recommendation_scoped` in `src/services/handlers.py`). Every value below is
the shipped default from `SCORING_DEFAULTS` in `src/services/recommendation_config.py`. An admin
can change them on the dashboard without a release; the trace page records which values were
live for a request (`scoring_config`), so always read the trace before reasoning about a result.

Written 2026-10-09 from the code as it runs, after the changes of the same day (section 8).

---

## 1. The pipeline in one view

```
report.html errors (+ artifact excerpts the extension collected)
   │
   ▼
1. QUERY       up to 10 query texts (block-prepared error text, plus "location | text" variants)
   │           query[0] is the anchor used for artifact search and the trace
   ▼
2. RETRIEVAL   three sources, merged, one candidate per stored request
   │             a. exact signature   sha1 of the normalised text      -> match_type exact,    similarity 1.0
   │             b. vector search     cosine on text-embedding-3-large -> match_type semantic, similarity = cosine
   │             c. task ledger       every stored fix of the failing task -> match_type task (or exact if the
   │                                  signature is equal), similarity = cosine computed on the spot
   ▼
3. SCORING     per candidate:  match_score  (evidence)  +  context_score  (support)  =  final_score
   ▼
4. POOL CUT    best 10 kept, identical solutions collapsed to one row
   ▼
5. ORDER       final_score desc, then similarity desc, then net votes, then same project / same task /
               user's task / file hit / token overlap
   ▼
6. GATE        top 3 whose CONFIDENCE crosses the threshold are shown; the rest are "weak" and hidden
   ▼
7. LLM PICK    computed and recorded on the trace; NOT promoted (llmPromoteEnabled = false)
               rank 1 is badged "closest match"
```

---

## 2. Similarity (the input to everything)

| source | how it is measured | range |
|---|---|---|
| exact signature | the normalised text hashes equal (timestamps, paths, durations, hex, line numbers removed first) | always 1.0 |
| vector search | cosine between the query embedding and the stored embedding, shown as `similarity = 1 - d/2` | 0..1 |
| task ledger | cosine between the query text and the stored error text, both block-prepared and embedded on the spot with the store budget. The same measure as the vector search, shown as a plain number with no label. | 0..1 |

Both sides are embedded the SAME way. The budget is the model's, in tokens (8,191 for
text-embedding-3-large, less a safety margin), counted exactly with tiktoken when installed and
by a conservative estimate otherwise. In block mode there is no character cap and no line cap:
an error longer than the budget is CHUNKED on line boundaries, one vector per chunk, every
line kept in order, so the whole message is embedded and the document is stored whole. Only a
caller that did not chunk (legacy defaults, artifacts) is cut, and then the end is kept, where
the failure is. On Azure the score is converted with `cos = 2 - 1/score`, so the similarity
shown IS the cosine.

Two stored errors with the same wording but a different literal value (`'2.1'` vs `'2.3'`)
usually have different signatures, so they are semantic, not exact, matches; a cosine near 1.0
between them is expected.

---

## 3. Match score: the evidence

| match_type | match_score |
|---|---|
| exact | 18, flat (`exactMatchBase` = 18) |
| semantic | 12 x similarity (`semanticMatchBase` = 12) |
| task | 12 x similarity; 0 when the stored row has no error text |

Both bases are admin settings. Every default the scorer can fall back to lives in one table,
`SCORING_DEFAULTS`; `get_config()` fills the same values in, so an unreadable config table
scores exactly like the default one.

Artifacts are used whenever they are present (`artifactMatchWeight` = 12, on by default; 0
switches the path off). When the candidate has artifact evidence, the similarity that earns
match points becomes a blend:

```
combined    = (1 - w) x error_similarity + w x artifact_share        w = evidenceSimilarityWeight = 0.5
match_score = 12 x combined
```

`artifact_share` is the candidate's evidence RELATIVE to its rivals (the same contrast share the
lift uses): 1 for the best-matching log in the pool, 0 for a contradicted one. Artifact
similarity is not on the error cosine's scale (two logs of one toolchain share their
boilerplate, so an unrelated log still scores about 0.5), which is why the absolute figure is
never blended. When the candidates' logs agree too closely to decide (spread below 0.15, or
only one candidate was compared) the error cosine stands and the artifact still earns the
lift. A candidate with no artifacts is never blended, so a candidate WITH artifacts is never
worse off than one without for having been compared on agreeing evidence.

The trace column `evidence_similarity` only differs from `similarity` when this blend ran;
`similarity_components.blend` spells out which rule applied.

---

## 4. Context score: the support

Each line is awarded ONCE per candidate, never once per confirmation.

| component | rule | default max |
|---|---|---|
| task | the fix belongs to the failing task | +3 (`baseTaskWeight`) |
| file | the fix touched a file the developer CHANGED this cycle (`changed_files`); the error's file locations only when the client sent none. Basenames are compared | +6 (`baseFileWeight`) |
| tokens | config tokens shared between the error and the fix, +1 each | +4 (`baseTokenWeight`) |
| usage hits | times this fix was SHOWN before, +1 each, x `usageHitsWeight` | 0 (`usageHitsWeight` = 0; 1 = old +3) |
| file content | the fix's changed lines are present in the open file | 0 (`fileContentMatchWeight` = 0) |
| patch | embedding similarity of the local patch to the fix | 0 in the report-error flow (no local patch is sent) |
| success history | 3 per confirmed success x decay + ratio bonus (max 3) + (0.25 per hit, max 3, + 0.15 per "shown" x decay) x `shownHistoryWeight`; decay = 1 / (1 + age_days/30) | 10 before the cap; views earn 0 by default |
| after-fix pattern | how often developers made this change next | 0 (`afterPatternWeight` = 0) |
| task weight | admin lift for the same task | 0 (`taskMatchWeight` = 0) |
| artifact lift | `artifactMatchWeight` x contrast share. The live artifact excerpts probe the stored artifacts; the error text is the probe when the client sent none. Best single pair wins, never a sum, so more files cannot raise it. | 12 (`artifactMatchWeight` = 12) |
| feedback support | same-error helpful votes | 0 (`feedbackSupportWeight` = 0) |

Then three trims, in this order:

1. **History cap**: success + after-fix pattern together may not exceed 4 (`historyWeightCeiling`).
   The excess is subtracted and recorded as `history_cap`.
2. **Evidence gate** (when the candidates' artifacts genuinely disagree, spread >= 0.15):
   history, the task points and same-error votes of a contradicted candidate are scaled by its
   contrast share. Recorded as `evidence_gate` and `task_identity_scaled`.
3. **Helper cap**: support may never exceed `helperEvidenceRatio` (default 0.5) x evidence.
   `helpers = context_score - artifact_lift`, `evidence = match_score + artifact_lift`,
   `helpers := min(helpers, helperEvidenceRatio x evidence)`. Recorded as `helper_cap`.

So with the defaults:

```
evidence      =  match_score + artifact_lift
helpers       <= 0.5 x evidence
final_score   =  evidence + helpers                   ->  final_score is between 1x and 1.5x the evidence
```

A candidate with no artifacts loses nothing it earned (absence is not contradiction); it
simply cannot earn the lift. A candidate whose artifacts match weakly has its match points
blended down but gains the lift, so weak evidence still outscores no evidence overall.

Two optional stages that are OFF: `distinctiveMatchWeight` (overlap on what DIFFERS between the
two messages, added last onto the final score) and `scoringMode = evidence`
(`final = 18 x overlap x (1 + context/30)`, where the error match multiplies instead of adding).

---

## 5. Confidence and the threshold

The final score ORDERS candidates. Confidence is a different thing: how similar this
candidate's error is to the one in hand. It is the similarity that earned the match points:

| candidate | confidence | `confidence_source` |
|---|---|---|
| exact signature | 1.0 | `exact_signature` |
| the candidate has artifact evidence | the error + artifact blend | `evidence_similarity` |
| any other semantic or task row | the cosine of the error text | `error_similarity` |
| nothing was compared | none (reported as 0, similarity blank) | the reason: `no_error_text`, `embedding_unavailable` or `no_query_text` |

```
strong (shown)   when confidence >= minSimilarityPercent / 100          (0 = gate off)
hidden (weak)    otherwise, or when nothing was compared and the gate is on
never shown      no solution; a semantic row whose raw error cosine is below minSemanticSimilarity;
                 or, if the env floor RECOMMENDATION_MIN_FINAL_SCORE is set, a final score below it
```

So "minimum similarity 70%" means exactly that: a candidate is shown when its error is at
least 70% similar, whatever its support. A perfect semantic match reads 100%, and an exact
signature always clears the threshold.

Before 2026-10-09 confidence was `final_score / 30`. Because support can never exceed evidence,
that capped a semantic candidate at 0.80 with full support and at 0.40 x cosine with none, and a
70% threshold hid every semantic match below cosine 0.875. That is the "cannot reach 100%" the
client saw.

---

## 6. Worked example (defaults, one request, three candidates, no artifacts sent)

| | A: semantic, cosine 0.92 | B: semantic, cosine 0.75 | C: exact signature |
|---|---|---|---|
| match_score | 12 x 0.92 = **11.04** | 12 x 0.75 = **9.00** | **18.00** |
| task / file / tokens / hits | 3 + 6 + 2 + 1 = 12 | 0 + 6 + 1 + 0 = 7 | 3 + 6 + 2 + 3 = 14 |
| success history | 6 -> capped to 4 | 0 | 10 -> capped to 4 |
| helpers before the cap | 16 | 7 | 18 |
| helper cap (<= evidence) | 16 -> **11.04** | 7 (unchanged) | 18 (unchanged) |
| context_score | 11.04 | 7.00 | 18.00 |
| **final_score** | **22.08** | **16.00** | **36.00** |
| confidence | 0.92 | 0.75 | 1.00 |
| rank | 2 | 3 | 1 |

With `minSimilarityPercent` = 70 all three are shown in this order. With 80, C and A are shown
and B is weak and hidden. The threshold never changes the order, only who crosses it.

With artifacts: if A's stored log matched the live log at 0.8 and B's at 0.3 (spread 0.5, so
contrast is on), A's share is 1 and B's is 0. A's match becomes 12 x (0.5 x 0.92 + 0.5 x 1)
= 11.52 and it earns the full lift of 12; B's match becomes 12 x (0.5 x 0.75 + 0.5 x 0) = 4.50
and earns no lift. A's evidence is then 23.52 against B's 4.50 before any helper is counted,
and A's confidence reads 0.96 against B's 0.375. Had both logs matched at about the same
level, neither would be blended: both keep their error cosine and both earn the lift.

---

## 7. Reading the trace

| column | meaning |
|---|---|
| `similarity` | the cosine of the error text (1.0 for an exact signature) |
| `similarity_source` | empty normally, for a vector-search row and for a ledger row measured the same way. Names only an abnormal case: `no_error_text` (nothing to compare, similarity blank, no match points), `embedding_unavailable`, `no_query_text` |
| `evidence_similarity` | the blend of error and artifact similarity; equals `similarity` when the candidate has no artifact evidence |
| `match_score` | section 3 |
| `context_score` | section 4, after every trim |
| `context_components` | base, patch, success, after_pattern, artifact, task_weight, then the trims history_cap, evidence_gate, task_identity_scaled, helper_cap (negative numbers) |
| `similarity_components` | the arithmetic behind the blend and the artifact fusion (vector vs rare-token overlap, best pair rule, contrast share) |
| `distinctive_points` | section 4, optional stage; 0 unless `distinctiveMatchWeight` is set |
| `final_score` | match + context (+ distinctive) |
| `confidence_score` / `confidence_source` | section 5: the similarity that earned the match points, and which one it was |
| `rank_factors` | every term of the ordering key, in order |
| `threshold_min_confidence` | minSimilarityPercent / 100 as it was for this request |
| `scoring_config` | the knob values that were live for this request |

A check that always holds: `final = match + base + patch + success + after_pattern + artifact +
task_weight + history_cap + evidence_gate + task_identity_scaled + helper_cap + distinctive`.

---

## 8. What was wrong, and what changed on 2026-10-09

Fixed in code:

1. **The query and the store embedded different text.** Stored vectors held the whole failure
   block (block mode, 400 lines / 28k chars); the query vector held the first 40 lines / 1,500
   chars, which in a build log is the command line and progress chatter. The distance then
   measured the preamble, so the same error scored differently on every run. Both sides now read
   one budget (`error_embed_budget`), and the task-ledger cosine uses it too.
2. **Over-budget text kept the start, not the end.** Logs put the failure last. The embedder now
   keeps the last lines that fit.
10. **Long errors were cut to fit the model.** The budget was 28,000 characters, but the model's
   limit is 8,191 tokens and a real build log is about 3 characters per token, so every long
   error was rejected by the model and the retry embedded only its second half; a 400-line cap
   dropped lines even when they fitted, and the stored document was capped at 28,000
   characters. The budget is now counted in tokens, text over it is chunked on line
   boundaries into one vector per chunk with nothing dropped, the line cap is gone in block
   mode, and the document is stored whole.
3. **Azure similarity was understated.** The score conversion assumed `(1 + cos)/2`; Azure's score
   is `1/(2 - cos)`. A true cosine of 0.889 was shown as 0.80, 0.75 as 0.60. Thresholds tuned
   against the old numbers need re-tuning.
4. **Confidence was a share of an arbitrary ceiling** (`final / 30`), so a semantic match could
   never reach 100% and the "minimum similarity" threshold gated the final score. Confidence is
   now the similarity that earned the match points, and the threshold gates that (section 5).
   The trace records `confidence_source` and `threshold_min_confidence`.
5. **Scoring numbers were written twice.** The exact base (18) was a literal in the scorer, the
   fallbacks for an unreadable config disagreed with the defaults (task 8 vs 3, history ceiling
   8 vs 4, semantic base 6 vs 12). One table, `SCORING_DEFAULTS`, now feeds both the config and
   every fallback, and `exactMatchBase` is an admin setting like `semanticMatchBase`.
6. **Artifact evidence was switched off** (`artifactMatchWeight` shipped at 0). Two candidates
   with the same error text were separated only by task, file, tokens and history, and the
   artifacts the extension collects never changed a score. The default is now 12: whenever
   artifacts are present they are used, the blend in section 3 and the evidence gate in
   section 4 run, and an unreadable config falls back to the same value. 0 switches it off.

7. **A compared candidate could read below an uncompared one.** The blend mixed the ABSOLUTE
   artifact similarity into the cosine, and an unrelated log still scores about 0.5 on that
   scale, so a candidate whose logs were merely compared lost confidence against a rival with
   no logs at all. The blend now uses the contrast share, the same relative measure as the
   lift: the best log raises, a contradicted log lowers, agreeing logs change nothing.

8. **The similarity column showed a task-recall label instead of a comparable number.** A
   ledger row's cosine was measured on the raw first message, not on the block-prepared text
   the store embedded, and carried a `task_recall_cosine` label into the column. The row is now
   prepared exactly like the store did, measured with the same budget, and shown as a plain
   cosine. A row with no stored error text shows a blank, not a fake 0, and earns no match
   points.
9. **The pool cut ignored the score.** The cut to 10 sorted same-task rows ahead of the final
   score, so with more than 10 candidates a low-scoring same-task row could push a
   high-scoring other-task row out of the pool before the visible ordering ran. The cut now
   follows the score; the live task's instance of an identical fix wins only within a tie.

Traced on 2026-10-10 for the AURIX-answered-with-CTC case (two report texts the same, the cause
only in debug.log), three more defects on the artifact path:

11. **The line after the error marker was invisible.** `_failure_signal_lines` kept only lines
    carrying a marker word. In these logs the marker line says THAT something failed and the
    next line says WHAT: `[ERROR] Error parsing input file` then
    `<Target><Compiler> must contain 'CTC' but found 'Diab'`. The detail line has no marker
    word, so the CTC log "named" nothing but the generic error every GBE failure shares: its
    evidence tokens, the ingest ownership gate, the wording tier and the stored summary's
    verbatim appendix never saw the cause. Up to `FAILURE_DETAIL_LINES` (default 2) lines after
    a marker line now count as part of the failure.
12. **XML element names were deleted from every token set.** `</Compiler>` was read as a path
    and `<Compiler>` as a cleaner placeholder, so the fix `<Compiler>CTC</Compiler>` reduced to
    the single token `ctc`. The ownership gate needs two shared tokens for proof, so a
    config.xml fix with a one-word value could never be matched to its own log, and the word
    `ctc` inside `ctc_aurix` could make an AURIX log look like the CTC fix's. Tags become their
    element names before cleaning.
13. **The stored artifact was embedded with the embedder's defaults** (first 40 lines) while the
    live probe was embedded whole: the same asymmetry already fixed on the error path. Both
    sides now use the artifact budget. The contrast threshold is a setting
    (`evidenceContrastMinSpread`, default 0.15) instead of a literal.

Behaviour that is by design, and configurable:

- **One stored error becomes up to three vectors** (`text`, `file | text`, `task | text`) and
  the query tries `location | text` variants. One request is one candidate, and the closest
  pair is the one reported, so the figure is the best match of the variants, which is stable
  for a given store.
- **An exact signature earns 18; a semantic match at cosine 1.0 earns 12.** Equal normalised
  text is a stronger identity than a near-identical embedding, so it carries a premium. Set
  `exactMatchBase` and `semanticMatchBase` equal if the premium is not wanted.

---

## 9. Accuracy pass (2026-10-10)

The correct fix was often shown 2nd or 3rd. Causes found and changed:

| problem | change |
|---|---|
| being SHOWN earned points three times (recommended_count, hit_count, "shown" outcomes), so the top fix kept itself on top | `usageHitsWeight` and `shownHistoryWeight` default 0; confirmed successes still count |
| helpers could equal the evidence, so a 0.85 match with history beat a 0.95 match without it | `helperEvidenceRatio` default 0.5 |
| each request kept the similarity of the FIRST query that found it, not the best | `_best_match_per_request` keeps an exact match, else the highest similarity |
| query[0] could fill the whole semantic budget and the other queries never ran; a vector seen again kept its first similarity | every query gets its own share (`RECOMMENDATION_SEMANTIC_QUERY_LIMIT`, default 10 queries); a re-found vector keeps the higher similarity |
| a semantic hit named only the FIRST upload of that error, so newer fixes of the same error were invisible | `_expand_semantic_hits_to_signature_siblings` adds every live request of the hit's signature |
| the file points used the error location (the task script) | the client's `changed_files` decide when sent |
| artifact text was cut from the HEAD; logs put the failure last | probes and the combined text keep the tail of each file |
| the extension sent only report.html (no logs, changed files, user task; no TD5 path) | restored in the extension |

Every old behaviour is one admin setting away (`usageHitsWeight` = 1, `shownHistoryWeight` = 1,
`helperEvidenceRatio` = 1).

**Measuring it.** When a developer uploads a fix (`/final-build`), the latest recommendation for
the same project and task (within `RECO_ACCURACY_WINDOW_HOURS`, default 72) is looked up and the
rank of the uploaded fix inside it is stored (`RECACCURACY` rows). `GET /recommendation-accuracy`
(admin, `?project_name=&days=`) reports Hit@1, Hit@3, in-pool rate, "retrieved but hidden"
(a ranking miss) and MRR. Compare the numbers before and after any setting change.

**Second accuracy round (2026-10-10).**

| problem | change |
|---|---|
| with no live log, the stored logs were probed with the error text and a fix whose log named the same file earned the full lift, beating an EXACT error match | that weak evidence earns `errorTextArtifactWeight` (default 0.25) of the lift, does not blend into the match score and does not gate history |
| the query sent to artifact matching used the FIRST 12 failure lines of the live log - in a long log, chatter such as `... (3 warnings)` | the LAST 12 lines |
| a stored log's "about" tokens were fixed by the error-text probe, so a fix's OWN log could be excluded as "about another fix" | the live-artifact probe decides them |
| two different fixes with the same evidence were presented as a confident rank 1 | response field `decision`: `clear` / `likely` / `ambiguous` (+ `margin`, `tied_request_ids`, `reason`); tied = final score within `ambiguityMargin` (5%) AND error + log similarity within 0.02. The extension shows a warning for `ambiguous` |

Offline check (`tests/test_offline_10_case_accuracy.py`, local embedder, 40-fix stress store with
identical error text, 3 versions per cause and a twin per cause in another task): every version that
can be told apart ranks first (15/15, clean and messy logs), no other-task twin ever wins, and fixes
that cannot be told apart (value is a date/hex or absent) stay in the top 3 and are mostly flagged
`ambiguous` (24/30; the rest read `likely` with a margin under 5%).

**Third round (2026-10-10): report.html only, same error message, different logs.**

When the developer sends only report.html and its message is shared by several stored failures,
the request carries nothing that tells them apart - no ranking can know which one this is. The
backend now says so and tells the developer how to choose:

| problem | change |
|---|---|
| without changed files, the +file points used the error location - for a Gradle task that is the task's own build script, so a fix that once edited it won every failure of the task | build scripts (`*.gradle`, `*.gradle.kts`) are ignored as error-location file evidence; real source files still count |
| log scores obtained by probing stored logs with the error text differed by chance and hid real ties | they are ignored by the tie check (`artifact_evidence_via` = `error_text`) |
| the tie check only looked at the 3 shown fixes | it looks at the whole scored pool (up to 10) |
| a tie only said "compare them" | `decision.how_to_choose`: per tied fix, the stored log line only that fix has, plus its compare link. Also written at the top of `llm_analysis`, which the shipped extension displays |

Offline (10 stored failures, one shared message, no live log): every query is flagged ambiguous and
the right fix is listed with its real root-cause line 10/10. With different messages the right fix
ranks first 10/10 and nothing is flagged.
