"""
debug_adapter_effect.py — why is the "Adapter effect" column empty?

The column shows "- -> -" when a candidate never appeared in the adapter's own search results,
so there is no second similarity to compare. That has several possible causes and a blank cell
cannot tell them apart. This walks them in order and names the one that applies.

    python debug_adapter_effect.py
    python debug_adapter_effect.py --project testgbe
    python debug_adapter_effect.py --project testgbe --query "tools[name=ctc_aurix].version"

Read-only. It trains nothing, promotes nothing and changes no setting.

The chain, in order:

    1. is a W trained and loadable            (the .npy on disk)
    2. is the runtime switch on for the project
    3. does the LEARNED-SPACE index exist and hold vectors
    4. with a real query, do both searches return the same candidates

Step 3 is the one usually missed. Training produces W; it does not fill the parallel index that
the second search reads. Until that index is built the fused search finds nothing on the learned
side, returns the base ranking untouched, and every candidate shows no adapter effect - while
the state still reports "active", because W is trained and the switch is on.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _rule(title):
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", default="", help="project to check the switch and search for")
    ap.add_argument("--query", default="", help="error text to run through both searches")
    ap.add_argument("--top-k", type=int, default=10)
    args = ap.parse_args()

    from src.configurations import config

    print(f"APP_ENV={os.getenv('APP_ENV', '(unset)')}  "
          f"AZURE_ONLY={getattr(config, 'AZURE_ONLY', '(unset)')}")

    verdicts = []

    # ---------------------------------------------------------------- 1. is W trained
    _rule("1. Is an adapter trained and loadable?")
    from src.utils import feedback_adapter
    for domain, path in (("error", config.FEEDBACK_ADAPTER_PATH),
                         ("artifact", config.FEEDBACK_ADAPTER_ARTIFACT_PATH)):
        active = False
        try:
            active = bool(feedback_adapter.is_active(domain))
        except Exception as exc:
            print(f"   {domain:<9} check failed: {exc}")
        on_disk = os.path.exists(path) or os.path.exists(str(path) + ".npy")
        print(f"   {domain:<9} loaded={active!s:<6} file={'present' if on_disk else 'ABSENT'}  ({path})")
        if domain == "error" and not active:
            verdicts.append("No error adapter is loaded, so no second search runs at all. "
                            "Train and promote one, or restore the .npy.")

    # ---------------------------------------------------------------- 2. the switch
    _rule("2. Is the runtime switch on?")
    try:
        from src.services import adapter_settings
        for domain in ("error", "artifact"):
            settings = adapter_settings.get_settings(force=True, domain=domain)
            effective = adapter_settings.adapter_enabled_for(args.project or "", domain=domain)
            print(f"   {domain:<9} global={settings.get('global_enabled')}  "
                  f"effective for '{args.project or '(any)'}'={effective}")
            if domain == "error" and not effective:
                verdicts.append("The error adapter switch is off for this project, so the fused "
                                "search returns the base ranking untouched.")
    except Exception as exc:
        print(f"   settings unreadable: {exc}")

    # ---------------------------------------------------------------- 3. the learned index
    _rule("3. Does the learned-space index hold anything?")
    print("   Training produces W. It does NOT fill this index - that is a separate step, and")
    print("   it is the step most often missed.\n")
    from src.utils import recommended
    for label, getter, name in (
        ("error", recommended._get_learned_collection,
         config.FEEDBACK_ADAPTER_LEARNED_COLLECTION),
        ("artifact", getattr(__import__("src.services.handlers", fromlist=["x"]),
                             "get_artifact_learned_collection", None),
         config.FEEDBACK_ADAPTER_ARTIFACT_LEARNED_COLLECTION),
    ):
        if getter is None:
            print(f"   {label:<9} no accessor available")
            continue
        try:
            collection = getter()
        except Exception as exc:
            collection = None
            print(f"   {label:<9} could not open '{name}': {exc}")
        if collection is None:
            print(f"   {label:<9} UNAVAILABLE  ('{name}')")
            if label == "error":
                verdicts.append(f"The learned-space index '{name}' cannot be opened, so the "
                                "second search returns nothing and there is no adapter "
                                "similarity to show.")
            continue
        try:
            count = collection.count()
            print(f"   {label:<9} {count} vector(s)  ('{name}')")
            if label == "error" and not count:
                verdicts.append(f"The learned-space index '{name}' is EMPTY. W is trained but "
                                "the parallel index it searches was never built, so every "
                                "candidate shows no adapter effect. Build it and re-check.")
        except Exception as exc:
            print(f"   {label:<9} count failed: {exc}")

    # ---------------------------------------------------------------- 4. a real query
    if args.query:
        _rule("4. Both searches, on a real query")
        base = recommended.search_similar_errors(
            args.query, args.project, top_k=args.top_k, allow_global_fallback=True)
        learned = recommended._search_learned_space(
            args.query, args.project, top_k=args.top_k, allow_global_fallback=True)
        base_ids = (base.get("ids") or [[]])[0] or []
        learned_ids = (learned.get("ids") or [[]])[0] or []
        print(f"   base search    : {len(base_ids)} candidate(s)")
        print(f"   learned search : {len(learned_ids)} candidate(s)")
        both = [v for v in base_ids if v in set(learned_ids)]
        print(f"   in BOTH        : {len(both)}  <- only these can show an adapter effect")
        if base_ids and not learned_ids:
            verdicts.append("The learned search returned nothing for this query while the base "
                            "search returned results - consistent with an empty or unbuilt "
                            "learned index.")
        elif both:
            fused = recommended._pool_from(learned, base, "learned", args.top_k)
            metas = (fused.get("metadatas") or [[]])[0] or []
            print(f"\n   {'candidate':<46}{'base d':>9}{'adapter d':>11}")
            for vid, meta in zip((fused.get("ids") or [[]])[0], metas):
                b, l = meta.get("adapter_distance_base"), meta.get("adapter_distance_learned")
                print(f"   {str(vid)[:44]:<46}"
                      f"{('-' if b is None else format(float(b), '.4f')):>9}"
                      f"{('-' if l is None else format(float(l), '.4f')):>11}")
    else:
        _rule("4. Both searches, on a real query")
        print("   Skipped. Pass --query \"<some error text>\" to compare them.")

    # ---------------------------------------------------------------- verdict
    _rule("Verdict")
    if verdicts:
        for i, v in enumerate(verdicts, 1):
            print(f"   {i}. {v}")
    else:
        print("   Nothing obviously broken. If the column is still empty, the candidates on that")
        print("   trace came from the exact-signature or task-ledger stages, which the fusion")
        print("   never touches - only semantic matches can carry an adapter effect.")
    print()


if __name__ == "__main__":
    main()
