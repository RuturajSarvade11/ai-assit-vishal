"""Replay the artifact lexical leg for one trace, token by token, and show where the score
actually comes from.

On one recorded request a PYTHON fix outranked the CTC fix on a CTC failure, and four
successive hypotheses about why were all wrong: foreign artifact linkage (the audit showed clean
linkage), lossy summaries (they preserve '6.2r1p456' verbatim), a dead content probe (it was a
stale assertion comparing a renamed label), and mis-attributed artifacts (each candidate was
scored on its own correct file).

What is left is arithmetic that should not be possible. The python summary's matching tokens are a
strict SUBSET of the ctc summary's, and the score is a sum of per-token weights over that
intersection - so the ctc candidate cannot score lower, whatever the weights are. It scored 0.451
against the python candidate's 0.623.

So this stops guessing and prints the real numbers: the probe text as stored, the query token set,
the neighbour set that produced the rarity weights, and per candidate the exact tokens that
contributed with their 1/df weights. Wherever the arithmetic diverges from the score, it will be
visible in the per-token table rather than inferred.

    python debug_artifact_scoring.py --trace 604c39440ef34b5b --rid 0a2b52c5 --rid 7a6f17c8

Reads only.
"""
import argparse
import sys

import src.utils.log_setup  # noqa: F401


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trace", required=True, help="trace id (or an error id that has traces)")
    ap.add_argument("--rid", action="append", default=[],
                    help="candidate request-id prefix to explain (repeatable)")
    ap.add_argument("--project", default="", help="override project (default: from the trace)")
    ap.add_argument("--top", type=int, default=25, help="tokens to list per candidate")
    args = ap.parse_args()

    from src.utils import recommendation_trace as rt
    from src.services import handlers

    traces = rt.get_traces_for_request(str(args.trace).strip()) or []
    if not traces:
        print(f"No trace found for {args.trace}")
        return 1
    trace = traces[0]
    project = (args.project or str(trace.get("project_name") or "")).strip().lower()

    arts = [a for a in (trace.get("query_artifacts") or []) if isinstance(a, dict)]
    if not arts:
        print("This trace stored no query artifacts, so the artifact leg had nothing to probe.")
        return 1

    print(f"trace {trace.get('trace_id')} | project={project} | "
          f"{len(arts)} query artifact(s): {[a.get('name') for a in arts]}")
    print()
    print("NOTE: the trace stores the probe text CLIPPED to 1500 chars, so a token beyond that")
    print("point will be missing here but present in the live run. If the numbers below match the")
    print("trace, the clip did not matter; if they do not, that difference is itself the finding.")

    # Exactly the tokenisation the scorer uses.
    def evidence_tokens(text):
        sig = chr(10).join(handlers._failure_signal_lines(str(text or "")))
        return handlers._distinctive_token_set(sig or str(text or ""))

    col = handlers.get_artifact_chroma_collection()

    for art in arts:
        probe_text = str(art.get("text") or "")
        name = str(art.get("name") or "?")
        print()
        print("=" * 78)
        print(f"PROBE artifact:{name}   ({len(probe_text)} chars as stored)")
        print("=" * 78)

        sig_lines = handlers._failure_signal_lines(probe_text)
        print(f"  failure-signal lines found in the probe: {len(sig_lines)}")
        for line in sig_lines[:6]:
            print(f"      {line.strip()[:150]}")
        if not sig_lines:
            print("      NONE - the tokeniser then falls back to the FULL text, which is the")
            print("      boilerplate-heavy case rarity weighting handles worst.")

        q_tokens = evidence_tokens(probe_text)
        print(f"  query tokens ({len(q_tokens)}): {sorted(q_tokens)}")

        # The same neighbour query the scorer runs, so df matches what it saw.
        from src.utils.oai_client import create_embedding
        kwargs = {"query_embeddings": [create_embedding(probe_text[:8000])],
                  "n_results": 200,
                  "include": ["metadatas", "distances", "documents"]}
        if project:
            from src.services.project_groups import scope_where
            members, _mode = handlers._reco_scope_members(project)
            kwargs["where"] = scope_where(project, members=members)
        res = col.query(**kwargs)
        metas = (res.get("metadatas") or [[]])[0] or []
        docs = (res.get("documents") or [[]])[0] or []
        dists = (res.get("distances") or [[]])[0] or []
        print(f"  neighbours returned: {len(metas)}")

        # df exactly as the scorer builds it: over EVERY neighbour, before the no-signal skip.
        doc_tokens = []
        df = {}
        for i in range(len(metas)):
            toks = evidence_tokens(str(docs[i] or "")) if i < len(docs) else set()
            doc_tokens.append(toks)
            for t in (toks & q_tokens):
                df[t] = df.get(t, 0) + 1
        weight_total = sum(1.0 / df[t] for t in q_tokens if t in df)

        missing = sorted(t for t in q_tokens if t not in df)
        print(f"  weight_total = {weight_total:.4f}")
        print(f"  query tokens present in NO neighbour (excluded from the denominator): {missing}")
        if missing:
            print("      ^ these contribute nothing. If the DISCRIMINATING token is here, the")
            print("        score reduces to shared-boilerplate overlap and cannot separate the")
            print("        two failure families - which is the whole job of this leg.")

        # Per requested candidate: which of ITS neighbour rows scored, and from which tokens.
        for want in (args.rid or []):
            want = want.strip().lower()
            print()
            print(f"  --- candidate {want} ---")
            hits = [i for i in range(len(metas))
                    if want in str((metas[i] or {}).get("request_id") or "").lower()]
            if not hits:
                print("      not among the returned neighbours at all - it could not be scored on")
                print("      this probe, whatever artifacts it owns.")
                continue
            for i in hits:
                meta = metas[i] or {}
                doc = str(docs[i] or "")
                signal = bool(handlers._failure_signal_lines(doc))
                try:
                    vec = max(0.0, min(1.0, 1.0 - float(dists[i]) / 2.0))
                except (TypeError, ValueError):
                    vec = float("nan")
                shared = sorted((doc_tokens[i] & q_tokens),
                                key=lambda t: (df.get(t, 10 ** 6), t))
                hit = sum(1.0 / df[t] for t in shared if t in df)
                tok = (hit / weight_total) if weight_total > 0 else 0.0
                print(f"      s3={str(meta.get('s3_key') or '')[-60:]}")
                print(f"      has failure signal: {signal}"
                      + ("" if signal else "   <- SKIPPED as boilerplate, cannot be evidence"))
                print(f"      vec={vec:.3f}  token={tok:.3f}  (hit {hit:.4f} / {weight_total:.4f})")
                print(f"      matched {len(shared)} query token(s), rarest first:")
                for t in shared[:args.top]:
                    print(f"          {t:<20} df={df.get(t)!s:<5} weight={1.0 / df[t]:.4f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
