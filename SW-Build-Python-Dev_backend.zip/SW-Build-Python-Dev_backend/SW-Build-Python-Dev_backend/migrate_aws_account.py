"""Copy this application's data from the OLD AWS account to the NEW one (server migration).

What the application keeps in AWS, per environment (APP_ENV drives the names, see config.py):

    DynamoDB (region eu-central-1)   <table>{sfx}   sfx = "_dev" for dev, "" for uat AND prod
    S3       (region ap-south-1)     pmt-ai-s3{-dev}

uat and prod share the SAME tables and bucket (no suffix), so there are two data sets to move:
"dev" (suffix _dev) and "shared" (no suffix). Everything else the server needs is either on the
old EC2 disk (the .env, ./SchaefflerVectorStore{sfx} if VECTOR_STORE=chroma, ./feedback_adapter/*.npy,
the embedding cache) or outside AWS (Azure AI Search, Azure OpenAI) and is not touched here.

Usage (run from a machine that has BOTH accounts as named AWS profiles, e.g. the new EC2 with its
instance role as "default" and the old account's keys under profile "old"):

    python migrate_aws_account.py --env dev    --src-profile old --dst-profile default \
        --s3 pmt-ai-s3-dev=aiasb-dev-data --create --verify
    python migrate_aws_account.py --env shared --src-profile old --dst-profile default \
        --s3 pmt-ai-s3=aiasb-data --create --verify

    --dry-run       list what would be copied, copy nothing
    --tables-only / --s3-only
    --resume        (default on) skip S3 objects that already exist in the target with the same size
    --rewrite-bucket  rewrite the stored `s3_bucket` attribute to the new bucket name (rows carry
                      the bucket name they were written with; readers use S3_BUCKET from config,
                      two download paths read the row's value - rewriting keeps both consistent)

The copy is idempotent: DynamoDB writes are puts keyed on the primary key, S3 objects are skipped
when present. Rerun after any interruption. Table TTL settings are copied (expires_at).
"""
import argparse
import sys
import time
from typing import Dict, Iterable, List

import boto3
from botocore.exceptions import ClientError

# Every table the code names (src/models/model.py, src/services/*_config.py, legacy tables kept
# for safety - copying an empty or unused table costs nothing, missing one would).
BASE_TABLES = [
    "ai_assisted_data", "final_build_payload",
    "prediction_config", "app_settings", "artifact_config", "artifact_rules", "system_tracking",
    "project_group_defs", "project_groups", "auth_users",
    "project", "solution", "error_log", "recommended", "solution_files", "binary_files",
]
DDB_REGION_DEFAULT = "eu-central-1"
S3_REGION_DEFAULT = "ap-south-1"


def log(msg: str) -> None:
    print(time.strftime("%H:%M:%S"), msg, flush=True)


# --------------------------------------------------------------------------- DynamoDB

def _table_names(suffix: str) -> List[str]:
    return [f"{b}{suffix}" for b in BASE_TABLES]


def _describe(client, name: str) -> Dict | None:
    try:
        return client.describe_table(TableName=name)["Table"]
    except ClientError as exc:
        if exc.response["Error"]["Code"] == "ResourceNotFoundException":
            return None
        raise


def _create_like(dst_client, src_desc: Dict, name: str | None = None) -> None:
    """Create the target table with the source's key schema, attribute definitions and GSIs.
    Billing is on-demand, as the application creates its own tables."""
    name = name or src_desc["TableName"]
    used_attrs = {k["AttributeName"] for k in src_desc["KeySchema"]}
    gsis = []
    for g in src_desc.get("GlobalSecondaryIndexes") or []:
        gsis.append({"IndexName": g["IndexName"], "KeySchema": g["KeySchema"], "Projection": g["Projection"]})
        used_attrs.update(k["AttributeName"] for k in g["KeySchema"])
    attrs = [a for a in src_desc["AttributeDefinitions"] if a["AttributeName"] in used_attrs]
    kwargs = {"TableName": name, "KeySchema": src_desc["KeySchema"], "AttributeDefinitions": attrs,
              "BillingMode": "PAY_PER_REQUEST"}
    if gsis:
        kwargs["GlobalSecondaryIndexes"] = gsis
    dst_client.create_table(**kwargs)
    dst_client.get_waiter("table_exists").wait(TableName=name)
    log(f"  created table {name}")


def _copy_ttl(src_client, dst_client, name: str, target: str | None = None) -> None:
    try:
        ttl = src_client.describe_time_to_live(TableName=name)["TimeToLiveDescription"]
    except ClientError:
        return
    if ttl.get("TimeToLiveStatus") in ("ENABLED", "ENABLING") and ttl.get("AttributeName"):
        try:
            dst_client.update_time_to_live(
                TableName=target or name,
                TimeToLiveSpecification={"Enabled": True, "AttributeName": ttl["AttributeName"]})
            log(f"  TTL enabled on {name} ({ttl['AttributeName']})")
        except ClientError as exc:
            if "already" not in str(exc).lower():
                log(f"  TTL on {name}: {exc}")


def _scan_all(table) -> Iterable[Dict]:
    kwargs = {}
    while True:
        page = table.scan(**kwargs)
        yield from page.get("Items", [])
        if "LastEvaluatedKey" not in page:
            return
        kwargs["ExclusiveStartKey"] = page["LastEvaluatedKey"]


def _count(table) -> int:
    total, kwargs = 0, {"Select": "COUNT"}
    while True:
        page = table.scan(**kwargs)
        total += int(page.get("Count", 0))
        if "LastEvaluatedKey" not in page:
            return total
        kwargs["ExclusiveStartKey"] = page["LastEvaluatedKey"]


def copy_tables(src, dst, suffix: str, create: bool, dry_run: bool, rewrite_bucket: Dict[str, str],
                dst_suffix: str | None = None, src_endpoint: str | None = None) -> None:
    ep = {"endpoint_url": src_endpoint} if src_endpoint else {}
    src_client, dst_client = src.client("dynamodb", **ep), dst.client("dynamodb")
    src_res, dst_res = src.resource("dynamodb", **ep), dst.resource("dynamodb")
    dst_suffix = suffix if dst_suffix is None else dst_suffix
    for base in BASE_TABLES:
        name, target = f"{base}{suffix}", f"{base}{dst_suffix}"
        src_desc = _describe(src_client, name)
        if not src_desc:
            log(f"- {name}: not in source, skipped")
            continue
        dst_desc = _describe(dst_client, target)
        approx = src_desc.get("ItemCount", 0)
        log(f"- {name} -> {target}: ~{approx} items in source; target {'exists' if dst_desc else 'MISSING'}")
        if dry_run:
            continue
        if not dst_desc:
            if not create:
                log(f"  target missing and --create not given, skipped")
                continue
            _create_like(dst_client, src_desc, target)
        _copy_ttl(src_client, dst_client, name, target)
        keys = [k["AttributeName"] for k in src_desc["KeySchema"]]
        written = 0
        with dst_res.Table(target).batch_writer(overwrite_by_pkeys=keys) as writer:
            for item in _scan_all(src_res.Table(name)):
                if rewrite_bucket and item.get("s3_bucket") in rewrite_bucket:
                    item["s3_bucket"] = rewrite_bucket[item["s3_bucket"]]
                writer.put_item(Item=item)
                written += 1
                if written % 1000 == 0:
                    log(f"  {name}: {written} items written")
        log(f"  {name}: {written} items written")


def verify_tables(src, dst, suffix: str, dst_suffix: str | None = None, src_endpoint: str | None = None) -> bool:
    ok = True
    ep = {"endpoint_url": src_endpoint} if src_endpoint else {}
    src_res, dst_res = src.resource("dynamodb", **ep), dst.resource("dynamodb")
    src_client, dst_client = src.client("dynamodb", **ep), dst.client("dynamodb")
    dst_suffix = suffix if dst_suffix is None else dst_suffix
    for base in BASE_TABLES:
        name, target = f"{base}{suffix}", f"{base}{dst_suffix}"
        if not _describe(src_client, name):
            continue
        if not _describe(dst_client, target):
            log(f"  VERIFY {name}: missing in target")
            ok = False
            continue
        a, b = _count(src_res.Table(name)), _count(dst_res.Table(target))
        flag = "ok" if a == b else "MISMATCH"
        if a != b:
            ok = False
        log(f"  VERIFY {name}: source {a} / target {b} {flag}")
    return ok


# --------------------------------------------------------------------------- S3

def _ensure_bucket(dst_s3, name: str, region: str) -> None:
    try:
        dst_s3.head_bucket(Bucket=name)
        return
    except ClientError as exc:
        if exc.response["Error"]["Code"] not in ("404", "NoSuchBucket"):
            raise
    kwargs = {"Bucket": name}
    if region != "us-east-1":
        kwargs["CreateBucketConfiguration"] = {"LocationConstraint": region}
    dst_s3.create_bucket(**kwargs)
    dst_s3.put_public_access_block(Bucket=name, PublicAccessBlockConfiguration={
        "BlockPublicAcls": True, "IgnorePublicAcls": True, "BlockPublicPolicy": True, "RestrictPublicBuckets": True})
    log(f"  created bucket {name} in {region}")


def _list_objects(s3, bucket: str) -> Iterable[Dict]:
    for page in s3.get_paginator("list_objects_v2").paginate(Bucket=bucket):
        yield from page.get("Contents", [])


def copy_bucket(src_s3, dst_s3, src_bucket: str, dst_bucket: str, dst_region: str,
                create: bool, dry_run: bool, resume: bool) -> None:
    log(f"- S3 {src_bucket} -> {dst_bucket}")
    if dry_run:
        n = sum(1 for _ in _list_objects(src_s3, src_bucket))
        log(f"  {n} objects would be copied")
        return
    if create:
        _ensure_bucket(dst_s3, dst_bucket, dst_region)
    existing: Dict[str, int] = {}
    if resume:
        existing = {o["Key"]: int(o["Size"]) for o in _list_objects(dst_s3, dst_bucket)}
    copied = skipped = 0
    for obj in _list_objects(src_s3, src_bucket):
        key, size = obj["Key"], int(obj["Size"])
        if resume and existing.get(key) == size:
            skipped += 1
            continue
        body = src_s3.get_object(Bucket=src_bucket, Key=key)
        extra = {}
        if body.get("ContentType"):
            extra["ContentType"] = body["ContentType"]
        if body.get("Metadata"):
            extra["Metadata"] = body["Metadata"]
        dst_s3.upload_fileobj(body["Body"], dst_bucket, key, ExtraArgs=extra or None)
        copied += 1
        if copied % 500 == 0:
            log(f"  {copied} objects copied")
    log(f"  {copied} objects copied, {skipped} already present")


def verify_bucket(src_s3, dst_s3, src_bucket: str, dst_bucket: str) -> bool:
    a = {o["Key"]: int(o["Size"]) for o in _list_objects(src_s3, src_bucket)}
    b = {o["Key"]: int(o["Size"]) for o in _list_objects(dst_s3, dst_bucket)}
    missing = [k for k, s in a.items() if b.get(k) != s]
    log(f"  VERIFY S3 {src_bucket}: {len(a)} objects / {sum(a.values())} bytes; "
        f"target {len(b)} objects; {len(missing)} missing or different")
    for k in missing[:10]:
        log(f"    missing: {k}")
    return not missing


# --------------------------------------------------------------------------- main

def _session(profile: str, region: str) -> boto3.Session:
    """"default" / "role" / "" = no named profile: boto3 then uses the EC2 instance role (or the
    environment), which is how the old server is authorised - it has no credentials file at all."""
    name = str(profile or "").strip().lower()
    if name == "local":
        # DynamoDB Local accepts any credentials; it only needs some to sign the request with.
        return boto3.Session(aws_access_key_id="dummy", aws_secret_access_key="dummy", region_name=region)
    if name in ("", "default", "role", "none"):
        return boto3.Session(region_name=region)
    return boto3.Session(profile_name=profile, region_name=region)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--env", choices=["dev", "shared"], required=True,
                    help="dev = tables/bucket with the _dev / -dev suffix; shared = uat+prod (no suffix)")
    ap.add_argument("--src-endpoint", default=None,
                    help="DynamoDB endpoint of the SOURCE, e.g. http://localhost:8000 for DynamoDB Local "
                         "(use with --src-profile local)")
    ap.add_argument("--dst-suffix", default=None,
                    help="table suffix in the TARGET when it differs from the source, e.g. --env shared "
                         "--dst-suffix _dev copies the uat/prod tables into <table>_dev (seeding a dev account)")
    ap.add_argument("--src-profile", required=True, help="named AWS profile, or 'default' for the instance role")
    ap.add_argument("--dst-profile", required=True, help="named AWS profile, or 'default' for the instance role")
    ap.add_argument("--src-region", default=DDB_REGION_DEFAULT, help="DynamoDB region, source")
    ap.add_argument("--dst-region", default=DDB_REGION_DEFAULT, help="DynamoDB region, target")
    ap.add_argument("--s3", action="append", default=[], metavar="SRC=DST",
                    help="bucket pair to copy; repeatable. Bucket names are global, so the target needs a new name")
    ap.add_argument("--s3-src-region", default=S3_REGION_DEFAULT)
    ap.add_argument("--s3-dst-region", default=S3_REGION_DEFAULT)
    ap.add_argument("--create", action="store_true", help="create missing tables and buckets in the target")
    ap.add_argument("--rewrite-bucket", action="store_true",
                    help="rewrite the stored s3_bucket attribute from the --s3 pairs while copying rows")
    ap.add_argument("--tables-only", action="store_true")
    ap.add_argument("--s3-only", action="store_true")
    ap.add_argument("--no-resume", action="store_true")
    ap.add_argument("--verify", action="store_true", help="compare counts after the copy")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    suffix = "_dev" if args.env == "dev" else ""
    pairs = {}
    for p in args.s3:
        if "=" not in p:
            ap.error(f"--s3 expects SRC=DST, got {p}")
        s, d = p.split("=", 1)
        pairs[s.strip()] = d.strip()

    src = _session(args.src_profile, args.src_region)
    dst = _session(args.dst_profile, args.dst_region)
    src_label = args.src_endpoint or src.client('sts').get_caller_identity()['Account']
    log(f"source {src_label} -> "
        f"target account {dst.client('sts').get_caller_identity()['Account']} | env={args.env} suffix='{suffix}'")

    all_ok = True
    if not args.s3_only:
        log("== DynamoDB")
        copy_tables(src, dst, suffix, args.create, args.dry_run, pairs if args.rewrite_bucket else {},
                    dst_suffix=args.dst_suffix, src_endpoint=args.src_endpoint)
        if args.verify and not args.dry_run:
            all_ok &= verify_tables(src, dst, suffix, args.dst_suffix, args.src_endpoint)
    if not args.tables_only and pairs:
        log("== S3")
        src_s3 = src.client("s3", region_name=args.s3_src_region)
        dst_s3 = dst.client("s3", region_name=args.s3_dst_region)
        for s, d in pairs.items():
            copy_bucket(src_s3, dst_s3, s, d, args.s3_dst_region, args.create, args.dry_run, not args.no_resume)
            if args.verify and not args.dry_run:
                all_ok &= verify_bucket(src_s3, dst_s3, s, d)
    log("done" + ("" if all_ok else " - VERIFY FOUND DIFFERENCES"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
