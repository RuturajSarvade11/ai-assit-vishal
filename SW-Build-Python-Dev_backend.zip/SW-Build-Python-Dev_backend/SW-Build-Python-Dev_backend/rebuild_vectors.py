r"""
Surgical repair of a corrupted ChromaDB error-vector collection ("Error finding id").

GOAL: keep EVERY good/safe embedding, drop ONLY the corrupted ones. Nothing else is
touched — DynamoDB and S3 history are not read or modified at all here.

How it works:
  * The corruption lives in the vector index (HNSW), not the stored records. So we
    read ALL stored entries from the collection (the dangling/corrupted id is simply
    not present in storage, so it's naturally excluded).
  * We then recreate the collection and re-add those good entries — rebuilding a clean
    index that contains all your real embeddings, minus only the corrupted ones.
  * No re-embedding (fast), no S3 dependency, no DynamoDB changes.

RUN WITH THE BACKEND STOPPED, from the backend folder, in the activated venv, with the
SAME .env (APP_ENV) as the target environment:

    python rebuild_vectors.py --dry-run   # read + report only, change nothing
    python rebuild_vectors.py             # repair

TIP: back up the store folder first (it's the only thing touched):
    Rename-Item .\SchaefflerVectorStore .\SchaefflerVectorStore.bak
"""
import logging
import sys

import src.utils.log_setup  # noqa: F401  (configures logging to console + logs/app.txt)
import chromadb

from src.configurations import config

log = logging.getLogger("rebuild_vectors")

DRY_RUN = "--dry-run" in sys.argv
_ADD_BATCH = 500


def repair_collection(client: "chromadb.ClientAPI", name: str) -> None:
    """Read all good entries from `name`, recreate it clean, and re-add them.
    Keeps every readable embedding; only corrupted/dangling ones are dropped."""
    try:
        col = client.get_collection(name)
    except Exception as exc:
        log.info("collection '%s' not present (%s) — skipping", name, exc)
        return

    # Read from storage (NOT the broken HNSW index). Corrupted/dangling ids are absent here.
    try:
        data = col.get(include=["embeddings", "metadatas", "documents"])
    except Exception as exc:
        log.error(
            "Could not READ collection '%s' (%s). Storage itself is corrupted — surgical repair "
            "can't keep its entries; this collection would need a full rebuild from S3 source.",
            name, exc,
        )
        return

    ids = list(data.get("ids") or [])
    # ChromaDB returns embeddings as a numpy array — `arr or []` raises "truth value is ambiguous",
    # so the None-check must be explicit.
    embs_raw = data.get("embeddings")
    embs = [] if embs_raw is None else list(embs_raw)
    metas = list(data.get("metadatas") or [])
    docs = list(data.get("documents") or [])
    total = len(ids)
    log.info("collection '%s' | %d good stored entries readable", name, total)

    if DRY_RUN:
        log.info("[dry-run] would rebuild '%s' from its %d good entries (corrupted/dangling ids dropped)", name, total)
        return

    if total == 0:
        log.warning("collection '%s' has 0 readable entries — leaving it as-is (nothing to keep)", name)
        return

    # Recreate clean and re-add the good entries -> fresh index, same data, minus corruption.
    client.delete_collection(name)
    new = client.create_collection(name)
    added = 0
    for i in range(0, total, _ADD_BATCH):
        sl = slice(i, i + _ADD_BATCH)
        new.add(
            ids=ids[sl],
            embeddings=embs[sl],
            metadatas=(metas[sl] if metas else None),
            documents=(docs[sl] if docs else None),
        )
        added += len(ids[sl])
        log.info("  '%s' re-added %d/%d", name, added, total)

    log.info("collection '%s' REPAIRED | kept=%d | dropped (corrupted)=%s", name, added, max(0, total - added) or "0 (+any dangling index ids)")


def main() -> None:
    log.info(
        "REPAIR start | APP_ENV=%s | chroma_path=%s | dry_run=%s",
        config.APP_ENV, config.CHROMA_VECTOR_STORE_PATH, DRY_RUN,
    )
    log.info("Keeps all good embeddings; drops only corrupted ones. DynamoDB and S3 are NOT touched.")

    client = chromadb.PersistentClient(path=config.CHROMA_VECTOR_STORE_PATH)

    # Repair the error collection (the one that threw 'Error finding id'). The artifact/document
    # collections are repaired too (harmless if they're already healthy) so the whole store is clean.
    for name in (
        config.CHROMA_COLLECTION_ERROR,
        config.CHROMA_COLLECTION_ARTIFACTS,
        config.CHROMA_COLLECTION_DOCS,
    ):
        repair_collection(client, name)

    log.info("REPAIR done.")


if __name__ == "__main__":
    main()
