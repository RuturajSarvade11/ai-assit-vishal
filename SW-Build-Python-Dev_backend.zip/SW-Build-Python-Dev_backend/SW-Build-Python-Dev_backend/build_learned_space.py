"""
Build / refresh the LEARNED-SPACE error collection.

It takes the base error_with_solution vectors, applies the current adapter
W (z = x @ W), and writes them (same ids + metadata) into a PARALLEL Chroma
collection (config.FEEDBACK_ADAPTER_LEARNED_COLLECTION). Recommendation (Phase 2)
then searches this learned space and fuses it with the base-space search via RRF.

SAFETY: read-only on the BASE collection; writes ONLY the learned-space collection.
Run with the backend STOPPED (embedded Chroma + concurrent writes can corrupt the
store), in the backend venv with APP_ENV set, AFTER train_feedback_adapter.py has
produced an adapter:
    python build_learned_space.py
    python build_learned_space.py --dry-run
"""
import argparse
import time

import numpy as np
import chromadb

from src.configurations import config
from src.utils import feedback_adapter as fa

BATCH = 1000


def _clean_meta(m):
    # Chroma rejects None metadata values on add; drop them.
    return {k: v for k, v in (m or {}).items() if v is not None}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="transform only; do not write the collection")
    args = ap.parse_args()

    W, meta = fa.load_adapter()
    if W is None:
        print(f"No adapter at {config.FEEDBACK_ADAPTER_PATH} - run train_feedback_adapter.py first.")
        return
    print(f"adapter W shape={W.shape} | base={config.CHROMA_COLLECTION_ERROR} "
          f"-> learned={config.FEEDBACK_ADAPTER_LEARNED_COLLECTION}")

    client = chromadb.PersistentClient(path=config.CHROMA_VECTOR_STORE_PATH)
    base = client.get_collection(config.CHROMA_COLLECTION_ERROR)
    data = base.get(include=["embeddings", "metadatas"])
    ids = data.get("ids") or []
    embs = data.get("embeddings")
    embs = [] if embs is None else embs
    metas = data.get("metadatas") or []
    n = len(ids)
    print(f"base records: {n}")
    if n == 0 or len(embs) == 0:
        print("nothing to build.")
        return

    X = np.asarray(embs, dtype=np.float64)
    if X.shape[1] != W.shape[0]:
        print(f"DIM MISMATCH base={X.shape[1]} vs W={W.shape[0]} - retrain the adapter for this embedding size.")
        return
    Z = fa.l2norm(X @ W).astype(np.float32)   # store unit-norm learned vectors (cosine == dot)
    print(f"transformed -> {Z.shape}")
    if args.dry_run:
        print("dry-run: not writing.")
        return

    try:
        client.delete_collection(config.FEEDBACK_ADAPTER_LEARNED_COLLECTION)
    except Exception:
        pass
    learned = client.get_or_create_collection(name=config.FEEDBACK_ADAPTER_LEARNED_COLLECTION)
    t0 = time.time()
    for i in range(0, n, BATCH):
        learned.add(
            ids=ids[i:i + BATCH],
            embeddings=[z.tolist() for z in Z[i:i + BATCH]],
            metadatas=[_clean_meta(m) for m in metas[i:i + BATCH]],
        )
    print(f"wrote {n} learned vectors to {config.FEEDBACK_ADAPTER_LEARNED_COLLECTION} in {time.time()-t0:.1f}s")
    print("This collection is not searched until Phase 2 wiring + FEEDBACK_ADAPTER_ENABLED=1.")


if __name__ == "__main__":
    main()
