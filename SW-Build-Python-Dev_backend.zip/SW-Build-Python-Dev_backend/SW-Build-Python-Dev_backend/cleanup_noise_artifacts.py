"""
Delete already-embedded NOISE artifacts (e.g. process-id.txt) from the artifact vector
collection, so RRF stops retrieving them as evidence.

This is an INGESTION-level cleanup (it removes the noise vectors from the store) — consistent
with the client's "exclude at the start" requirement, NOT a retrieval-time filter. It only
deletes vectors whose file_name is in the noise list; nothing else is touched. DynamoDB and S3
are not modified.

Run with the backend STOPPED, from the backend folder, in the activated venv, with the SAME .env
(APP_ENV) as the target environment:

    python cleanup_noise_artifacts.py --dry-run   # count only, delete nothing
    python cleanup_noise_artifacts.py             # delete

The noise list comes from ARTIFACT_NOISE_FILES (default 'process-id.txt'), same as the live guard.
"""
import logging
import os
import sys

import src.utils.log_setup  # noqa: F401  (configures logging)
from src.configurations import config
from src.services.handlers import get_artifact_chroma_collection

log = logging.getLogger("cleanup_noise_artifacts")
DRY_RUN = "--dry-run" in sys.argv


def main() -> None:
    raw = os.getenv("ARTIFACT_NOISE_FILES", "process-id.txt")
    names = [p.strip() for p in raw.split(",") if p.strip()]
    log.info(
        "CLEANUP noise artifacts | APP_ENV=%s | collection=%s | noise_files=%s | dry_run=%s",
        config.APP_ENV, config.CHROMA_COLLECTION_ARTIFACTS, names, DRY_RUN,
    )
    if not names:
        log.info("ARTIFACT_NOISE_FILES is empty — nothing to clean.")
        return

    col = get_artifact_chroma_collection()
    where = {"file_name": {"$in": names}} if len(names) > 1 else {"file_name": names[0]}

    try:
        existing = col.get(where=where)
        ids = existing.get("ids") or []
    except Exception as exc:
        log.error("could not query noise artifacts (collection may be corrupted — repair first): %s", exc)
        return

    log.info("found %d noise artifact vector(s) for %s", len(ids), names)
    if not ids:
        log.info("nothing to delete.")
        return

    if DRY_RUN:
        log.info("[dry-run] would delete %d vector(s): %s", len(ids), ids[:10] + (["..."] if len(ids) > 10 else []))
        return

    col.delete(where=where)
    log.info("DELETED %d noise artifact vector(s). RRF will no longer retrieve them.", len(ids))


if __name__ == "__main__":
    main()
