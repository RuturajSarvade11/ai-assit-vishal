"""
One-time migration: add the FULL sha256 (content_sha256) to existing artifact-summary records.

WHY: artifact-summary dedup now decides skip/reuse on the FULL sha256 (collision-safe). Records
created before that change carry only content_sha12 (the 12-char / 48-bit S3-key suffix). Without a
full hash, the live dedup (`handle_artifact_text_embedding`) cannot match them on the full hash, so
an already-stored file would be re-summarised once the next time it is seen. This backfill writes
content_sha256 onto those old records so the full-hash dedup matches them and nothing is reprocessed.

WHERE THE HASH COMES FROM (no LLM, no re-embedding):
  payload_sha256 == sha256(original file bytes) == the content_sha256 we want, and it is already
  stored in each artifact's S3 object metadata. We read it with a cheap head_object (no download).
  Fallback for any old object missing that metadata: download the zip, extract, and hash the bytes.

SAFE + IDEMPOTENT:
  - Only ADDS content_sha256; every other metadata field is preserved (we re-write the full record
    metadata with the one field added). ChromaDB documents and embeddings are not touched.
  - Records that already have content_sha256 are skipped, so re-running is harmless.
  - S3 and DynamoDB are read-only here.

RUN WITH THE BACKEND STOPPED (single writer to ChromaDB), from the backend folder, in the venv,
with the target .env (APP_ENV):

    python backfill_artifact_content_sha256.py --dry-run   # scan + report only, change nothing
    python backfill_artifact_content_sha256.py             # write content_sha256
"""
import hashlib
import logging
import os
import sys
from io import BytesIO
from zipfile import ZipFile

import src.utils.log_setup  # noqa: F401

from src.utils.payload_archive import get_s3_client, S3_BUCKET
from src.services import handlers

log = logging.getLogger("backfill_sha256")
DRY_RUN = "--dry-run" in sys.argv
PAGE = max(100, int(os.getenv("MIGRATION_PAGE", "1000")))
WRITE_BATCH = max(1, int(os.getenv("MIGRATION_WRITE_BATCH", "200")))

_HEX = set("0123456789abcdef")


def _is_full_sha256(value: str) -> bool:
    v = str(value or "").strip().lower()
    return len(v) == 64 and all(c in _HEX for c in v)


def _clean_key(s3_key: str) -> str:
    return str(s3_key or "").strip().rstrip('"').rstrip("%22")


def content_sha256_for_key(s3_key: str) -> str:
    """Full sha256 of the original file bytes for this artifact.
    Cheap path: read payload_sha256 from S3 object metadata (head, no body download).
    Fallback: download the zip, extract the single file, hash it."""
    cli = get_s3_client()
    try:
        head = cli.head_object(Bucket=S3_BUCKET, Key=s3_key)
        md = {k.lower(): v for k, v in (head.get("Metadata") or {}).items()}
        ps = str(md.get("payload_sha256") or "").strip().lower()
        if _is_full_sha256(ps):
            return ps
    except Exception:
        log.debug("head_object metadata unavailable, falling back to download | key=%s", s3_key)
    resp = cli.get_object(Bucket=S3_BUCKET, Key=s3_key)
    body = resp["Body"].read()
    with ZipFile(BytesIO(body), "r") as zf:
        names = zf.namelist()
        raw = zf.read(names[0]) if names else b""
    return hashlib.sha256(raw or b"").hexdigest()


def collect_records_needing_migration():
    """Scan the artifact collection; return (scanned, todo) where todo = [(id, meta, s3_key)]."""
    col = handlers.get_artifact_chroma_collection()
    scanned = 0
    todo = []
    offset = 0
    while True:
        res = col.get(include=["metadatas"], limit=PAGE, offset=offset)
        ids = res.get("ids") or []
        metas = res.get("metadatas") or []
        if not ids:
            break
        for rid, meta in zip(ids, metas):
            scanned += 1
            meta = meta or {}
            if str(meta.get("content_sha256") or "").strip():
                continue  # already migrated
            todo.append((rid, meta, _clean_key(meta.get("s3_key"))))
        if len(ids) < PAGE:
            break
        offset += PAGE
    return scanned, todo


def main():
    col = handlers.get_artifact_chroma_collection()
    scanned, todo = collect_records_needing_migration()
    no_key = sum(1 for _, _, k in todo if not k)
    unique_keys = {k for _, _, k in todo if k}
    log.info("artifact records scanned=%d | need content_sha256=%d | unique S3 objects=%d | no_s3_key=%d",
             scanned, len(todo), len(unique_keys), no_key)
    if no_key:
        log.warning("%d record(s) have no s3_key — cannot migrate; they keep the legacy sha12 fallback", no_key)

    if DRY_RUN:
        for rid, meta, k in todo[:10]:
            log.info("[dry-run] id=%s | sha12=%s | s3_key=%s", rid, meta.get("content_sha12"), k)
        if len(todo) > 10:
            log.info("[dry-run] ... and %d more", len(todo) - 10)
        log.info("[dry-run] would update %d record(s) from %d S3 object(s). No changes made.",
                 len(todo) - no_key, len(unique_keys))
        return

    sha_by_key: dict[str, str] = {}
    updated = failed = mismatch = 0
    batch_ids: list[str] = []
    batch_metas: list[dict] = []

    def flush():
        nonlocal updated, failed, batch_ids, batch_metas
        if not batch_ids:
            return
        try:
            col.update(ids=batch_ids, metadatas=batch_metas)
            updated += len(batch_ids)
        except Exception as exc:
            failed += len(batch_ids)
            log.error("batch update failed (%d records) — re-run to retry: %s", len(batch_ids), exc)
        batch_ids, batch_metas = [], []

    for rid, meta, s3_key in todo:
        if not s3_key:
            continue
        try:
            full = sha_by_key.get(s3_key)
            if full is None:
                full = content_sha256_for_key(s3_key)
                sha_by_key[s3_key] = full
            if not _is_full_sha256(full):
                failed += 1
                log.error("computed hash is not a full sha256 | id=%s | key=%s | got=%r", rid, s3_key, full)
                continue
            stored12 = str(meta.get("content_sha12") or "").strip().lower()
            if stored12 and stored12 != full[:12]:
                mismatch += 1
                log.warning("sha12 mismatch | id=%s | stored=%s | computed=%s — writing computed full hash",
                            rid, stored12, full[:12])
            new_meta = dict(meta)
            new_meta["content_sha256"] = full
            if not str(new_meta.get("content_sha12") or "").strip():
                new_meta["content_sha12"] = full[:12]
            batch_ids.append(rid)
            batch_metas.append(new_meta)
            if len(batch_ids) >= WRITE_BATCH:
                flush()
                log.info("progress | updated=%d | failed=%d | objects_hashed=%d", updated, failed, len(sha_by_key))
        except Exception as exc:
            failed += 1
            log.error("migrate failed | id=%s | s3_key=%s | %s", rid, s3_key, exc)
    flush()

    log.info("MIGRATION done | updated=%d | sha12_mismatch=%d | failed=%d | unique_objects=%d | no_key=%d",
             updated, mismatch, failed, len(sha_by_key), no_key)


if __name__ == "__main__":
    main()
