"""
Find stored artifacts whose RAW content looks truncated, and repair a solution's artifact
evidence by re-uploading the complete capture against its existing request_id.

WHY (the truncated debug.log case): artifacts captured before the tail-cap removal
(031d94ae era, extension side) were stored INCOMPLETE — the downloaded debug.log ends at
"Starting validation..." and is missing the root-cause line ("...must be '6.2r1p4' but got
'6.2r1p456'."). The artifact-vs-artifact match can only prove the right solution if the
stored raw carries the failure evidence. The current pipeline stores the full file
(verified: full read -> line-preserving display clean -> full zip to S3); this script deals
with the DATA that was stored before those fixes.

WHAT IT DOES:
  --report            scan every runtime/binary artifact reference, download the raw .log/.txt
                      from S3, and flag SUSPECT files: empty, or no failure-signal line at all
                      (a file captured at build failure should carry failure evidence).
                      READ-ONLY — flags for manual inspection, never deletes or modifies anything.
  --refresh-embeddings [--project X] [--dry-run]
                      BULK, all projects by default, no per-file input: for EVERY stored
                      artifact record, append the RAW failure-signal lines of its S3 raw
                      (verbatim, capped — the same appendix new uploads get) to the stored
                      search document and re-embed it. This makes whatever content each
                      existing artifact HAS fully greppable by the hybrid token leg — the
                      complete recovery possible from the server side. Idempotent: records
                      already carrying the RAW FAILURE LINES marker are skipped, so it is
                      safe to run repeatedly. One embedding call per refreshed record, NO
                      LLM summary calls. Truncated raws stay truncated (the missing bytes
                      exist nowhere server-side) — their present lines still gain exact-token
                      matching.
  --reupload RID --file PATH --project NAME [--name ORIGINAL] [--task TASKPATH]
             [--source-folder log]
                      push a complete local capture through the EXACT upload pipeline
                      (display-clean -> S3 zip -> artifact reference -> summary+embedding)
                      against the EXISTING request_id, so the stored solution gains a
                      complete artifact. The old truncated reference is kept (never
                      overwrite); recommendation matching takes the BEST artifact per
                      candidate, so the complete one wins. Only needed when a COMPLETE
                      copy exists locally (e.g. a reproduced failing build).

RUN from the backend folder, in the venv, with the target .env (APP_ENV):

    python repair_artifact_raw_content.py --report [--project testgbe]
    python repair_artifact_raw_content.py --refresh-embeddings --dry-run
    python repair_artifact_raw_content.py --refresh-embeddings
    python repair_artifact_raw_content.py --reupload <request_id> --file D:\\path\\to\\debug.log \
        --project testgbe --task :TARGETS:master:task4 --source-folder log
"""
import argparse
import logging
import sys
from io import BytesIO
from zipfile import ZipFile

import src.utils.log_setup  # noqa: F401
from boto3.dynamodb.conditions import Attr

from src.configurations import config
from src.utils import project_details as pd
from src.utils.content_fingerprint import prepare_artifact_for_storage
from src.utils.payload_archive import (
    S3_BUCKET,
    get_s3_client,
    upload_task_runtime_artifact_zip,
)
from src.services import handlers

log = logging.getLogger("repair_artifact_raw")


def _fetch_raw(s3_key: str) -> bytes:
    resp = get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key)
    with ZipFile(BytesIO(resp["Body"].read()), "r") as zf:
        names = zf.namelist()
        return zf.read(names[0]) if names else b""


def _project_of_key(s3_key: str) -> str:
    parts = [p for p in str(s3_key or "").split("/") if p]
    return parts[1].lower() if len(parts) >= 2 else ""


def report(project_filter: str) -> None:
    flt = Attr("SK").begins_with(f"{pd.BINARY_SK}#") | Attr("SK").begins_with(f"{pd.RUNTIME_SK}#")
    rows = pd._scan_all(pd.ai_assisted_data_table, filter_expression=flt)
    log.info("artifact references: %d", len(rows))

    # One download per unique s3_key; remember every request that points at it.
    by_key: dict[str, list[str]] = {}
    names: dict[str, str] = {}
    for ref in rows:
        s3_key = str(ref.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
        file_name = str(ref.get("file_name") or "").strip()
        if not s3_key or not handlers._is_semantic_artifact_file(file_name):
            continue
        if handlers._is_noise_artifact_file(file_name):
            continue
        if project_filter and _project_of_key(s3_key) != project_filter:
            continue
        by_key.setdefault(s3_key, []).append(str(ref.get("request_id") or ref.get("PK") or ""))
        names[s3_key] = file_name

    log.info("unique text artifacts to inspect: %d", len(by_key))
    suspects = 0
    for i, (s3_key, rids) in enumerate(sorted(by_key.items()), 1):
        try:
            raw = _fetch_raw(s3_key)
        except Exception as exc:
            log.warning("SKIP (download failed) | %s | %s", s3_key, exc)
            continue
        text = raw.decode("utf-8", errors="replace")
        lines = [ln for ln in text.splitlines() if ln.strip()]
        signal = handlers._failure_signal_lines(text)
        verdict = "OK"
        if not lines:
            verdict = "SUSPECT (empty)"
        elif not signal:
            # A file captured at build failure with NO failure-signal line anywhere is the
            # truncation pattern of the truncated debug.log case. Flag it — the marker
            # list is used to FLAG here, never to cut content.
            verdict = "SUSPECT (no failure signal in whole file)"
        if verdict != "OK":
            suspects += 1
            log.info(
                "%s | file=%s | bytes=%d | lines=%d | signal_lines=%d | requests=%s | key=%s",
                verdict, names.get(s3_key, "?"), len(raw), len(lines), len(signal),
                ",".join(sorted({r for r in rids if r})) or "-", s3_key,
            )
        if i % 100 == 0:
            log.info("... inspected %d/%d", i, len(by_key))
    log.info("REPORT done | inspected=%d | suspects=%d", len(by_key), suspects)
    if suspects:
        log.info(
            "Repair per solution: re-run the failing build once with the CURRENT extension "
            "(full capture), or re-upload a complete local copy with --reupload."
        )


# Same marker as handle_artifact_text_embedding writes at upload time — the idempotency
# check and the marker MUST stay identical on both sides.
RAW_LINES_MARKER = "RAW FAILURE LINES (verbatim):"


def refresh_embeddings(project_filter: str, dry_run: bool) -> None:
    from src.utils.oai_client import create_embedding

    coll = handlers.get_artifact_chroma_collection()

    # Single full pass first (upserting while paginating can shift result order).
    all_ids: list[str] = []
    all_docs: list[str] = []
    all_metas: list[dict] = []
    offset = 0
    page = 1000
    while True:
        res = coll.get(include=["metadatas", "documents"], limit=page, offset=offset)
        ids = res.get("ids") or []
        if not ids:
            break
        docs = res.get("documents") or []
        metas = res.get("metadatas") or []
        for i, rid in enumerate(ids):
            all_ids.append(str(rid or ""))
            all_docs.append(str(docs[i] if i < len(docs) else "") or "")
            all_metas.append(metas[i] if i < len(metas) and isinstance(metas[i], dict) else {})
        if len(ids) < page:
            break
        offset += page
    log.info("artifact records in collection: %d", len(all_ids))

    raw_cache: dict[str, str] = {}
    todo: list[tuple[str, str, dict, str]] = []  # (id, new_doc, meta, s3_key)
    skipped_marker = skipped_no_key = skipped_project = skipped_not_text = skipped_no_signal = 0
    for rid, doc, meta in zip(all_ids, all_docs, all_metas):
        if not rid:
            continue
        if RAW_LINES_MARKER in doc:
            skipped_marker += 1
            continue
        s3_key = str(meta.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
        if not s3_key:
            skipped_no_key += 1
            continue
        if project_filter and str(meta.get("project_name") or _project_of_key(s3_key)).lower() != project_filter:
            skipped_project += 1
            continue
        file_name = str(meta.get("file_name") or s3_key.split("/")[-1])
        if not handlers._is_semantic_artifact_file(file_name):
            skipped_not_text += 1
            continue
        if s3_key not in raw_cache:
            try:
                raw_cache[s3_key] = _fetch_raw(s3_key).decode("utf-8", errors="replace")
            except Exception as exc:
                log.warning("SKIP (raw download failed) | %s | %s", s3_key, exc)
                raw_cache[s3_key] = ""
        raw_text = raw_cache[s3_key]
        appendix = "\n".join(handlers._failure_signal_lines(raw_text)[:80])[:6000].strip()
        if not appendix:
            skipped_no_signal += 1
            continue
        todo.append((rid, doc + "\n\n" + RAW_LINES_MARKER + "\n" + appendix, meta, s3_key))

    log.info(
        "REFRESH plan | to_refresh=%d | already_refreshed=%d | no_s3_key=%d | other_project=%d | "
        "not_text=%d | no_signal_lines=%d",
        len(todo), skipped_marker, skipped_no_key, skipped_project, skipped_not_text, skipped_no_signal,
    )
    if dry_run:
        for rid, _doc, meta, s3_key in todo[:20]:
            log.info("[dry-run] would refresh: %s (%s)", meta.get("file_name") or "?", s3_key)
        if len(todo) > 20:
            log.info("[dry-run] ... and %d more", len(todo) - 20)
        log.info("[dry-run] cost: %d embedding call(s), no LLM calls. Exiting without changes.", len(todo))
        return

    ok = fail = 0
    batch = 25
    for start in range(0, len(todo), batch):
        chunk = todo[start:start + batch]
        try:
            embeddings = [create_embedding(new_doc) for _rid, new_doc, _m, _k in chunk]
            coll.upsert(
                ids=[rid for rid, _d, _m, _k in chunk],
                embeddings=embeddings,
                documents=[new_doc for _rid, new_doc, _m, _k in chunk],
                metadatas=[meta for _rid, _d, meta, _k in chunk],
            )
            ok += len(chunk)
        except Exception:
            log.exception("refresh batch failed | records %d..%d — continuing", start, start + len(chunk) - 1)
            fail += len(chunk)
        if (start // batch) % 10 == 0:
            log.info("... refreshed %d/%d", min(start + batch, len(todo)), len(todo))
    log.info("REFRESH done | refreshed=%d | failed=%d — hybrid token leg now greps every "
             "stored artifact's own failure lines verbatim", ok, fail)


def reupload(request_id: str, file_path: str, project: str, name: str,
             task_path: str, source_folder: str, developer_id: str) -> None:
    with open(file_path, "rb") as fh:
        content = fh.read()
    if not content.strip():
        log.error("local file is empty — nothing to repair with: %s", file_path)
        sys.exit(2)
    file_name = name or file_path.replace("\\", "/").split("/")[-1]
    batch_id = f"repair-{request_id[:12]}"

    stored, fingerprint = prepare_artifact_for_storage(content, file_name)
    known = {
        (str(r.get("file_name") or "").strip(), str(r.get("content_fingerprint") or "").strip())
        for r in pd.get_artifact_references(request_id, "runtime")
    }
    if (file_name, fingerprint) in known:
        log.info("identical content already referenced for request %s — nothing to do", request_id)
        return

    archive = upload_task_runtime_artifact_zip(
        batch_id=batch_id,
        file_name=file_name,
        file_bytes=stored,
        action="modified",
        project_name=project,
        source_folder=source_folder,
        task_path=task_path,
    )
    s3_key = archive.get("s3_key") or ""
    log.info("stored raw | s3_key=%s | bytes=%d", s3_key, len(stored))

    pd.save_artifact_reference(
        request_id=request_id,
        file_name=file_name,
        s3_key=s3_key,
        s3_bucket=config.S3_BUCKET,
        artifact_type="runtime",
        content_fingerprint=fingerprint,
    )
    log.info("artifact reference added | request_id=%s | file=%s", request_id, file_name)

    embed = handlers.handle_artifact_text_embedding(
        project_name=project,
        file_name=file_name,
        file_bytes=stored,
        s3_key=s3_key,
        batch_id=batch_id,
        request_id=request_id,
        artifact_type="runtime",
        action="modified",
        source_folder=source_folder,
        task_path=task_path,
        developer_id=developer_id,
    )
    log.info("summary+embedding | %s", embed)
    try:
        handlers._enqueue_vectorization(request_id, force=True)
    except Exception:
        log.warning("re-vectorization enqueue failed (summary/embedding already stored)")
    log.info("REPAIR done — request %s now carries the complete '%s'", request_id, file_name)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--report", action="store_true", help="scan stored raws and flag suspected truncation (read-only)")
    ap.add_argument("--refresh-embeddings", action="store_true",
                    help="BULK: append each stored artifact's raw failure lines to its search document and re-embed (all projects, idempotent)")
    ap.add_argument("--dry-run", action="store_true", help="with --refresh-embeddings: count and list only, change nothing")
    ap.add_argument("--project", default="", help="limit --report / --refresh-embeddings to one project (e.g. testgbe)")
    ap.add_argument("--reupload", metavar="REQUEST_ID", default="", help="re-upload a complete capture for this request")
    ap.add_argument("--file", default="", help="local path of the complete artifact file (with --reupload)")
    ap.add_argument("--name", default="", help="original file name to store under (default: basename of --file)")
    ap.add_argument("--task", default="", help="task path of the original failure (e.g. :TARGETS:master:task4)")
    ap.add_argument("--source-folder", default="log", help="source folder label (default: log)")
    ap.add_argument("--developer", default="repair-script", help="developer id recorded on the upload")
    args = ap.parse_args()

    log.info("APP_ENV=%s | bucket=%s | artifact collection=%s",
             config.APP_ENV, S3_BUCKET, config.CHROMA_COLLECTION_ARTIFACTS)

    if args.reupload:
        if not args.file or not args.project:
            ap.error("--reupload requires --file and --project")
        reupload(args.reupload, args.file, args.project.strip().lower(), args.name,
                 args.task, args.source_folder, args.developer)
    elif args.refresh_embeddings:
        refresh_embeddings(args.project.strip().lower(), args.dry_run)
    elif args.report:
        report(args.project.strip().lower())
    else:
        ap.error("pass --report, --refresh-embeddings or --reupload (see --help)")


if __name__ == "__main__":
    main()
