import os
import logging
import src.utils.log_setup  # noqa: F401

from src.models.model import ensure_tables

logger = logging.getLogger(__name__)


def run_app() -> None:
    from src.routes.route import app as flask_app
    from src.utils.url_prefix import mount_under_prefix

    # New servers: the load balancer sends /agent/* here; accept the path with or without it.
    mount_under_prefix(flask_app)

    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "9052"))
    debug = str(os.getenv("FLASK_DEBUG", "0")).strip().lower() in {"1", "true", "yes"}

    # WHICH CODE IS RUNNING: three debugging rounds were spent on a service that had
    # not been restarted after a pull - the traceback line numbers no longer matched the file,
    # which is only obvious once you look for it. The banner now states the commit the process
    # actually loaded, so "is the service current?" is answered by reading the log.
    def _running_commit() -> str:
        try:
            import subprocess
            here = os.path.dirname(os.path.abspath(__file__))
            out = subprocess.run(["git", "log", "-1", "--format=%h %cd %s", "--date=format:%Y-%m-%d %H:%M"],
                                 cwd=here, capture_output=True, text=True, timeout=5)
            return (out.stdout or "").strip() or "unknown"
        except Exception:
            return "unknown"

    logger.info(
        "Starting app | host=%s | port=%d | debug=%s | APP_ENV=%s | code=%s",
        host, port, debug, os.getenv("APP_ENV", os.getenv("ENVIRONMENT", "test")),
        _running_commit(),
    )
    
    # Try to initialize DynamoDB tables
    db_available = ensure_tables()
    if not db_available:
        logger.warning(
            "App starting without DynamoDB. Features requiring database will not work. "
            "To require DynamoDB, set DYNAMODB_REQUIRED=1 in your .env file."
        )

    # Production serving: the Flask dev server (flask_app.run) is single-process and not built
    # for concurrency — under many simultaneous users it stalls. Serve via Waitress (a production
    # WSGI server that works on Windows) with a worker-thread pool sized for the expected
    # concurrency. Fall back to the dev server only for local debugging or if Waitress is absent.
    use_dev_server = debug or str(os.getenv("USE_FLASK_DEV_SERVER", "0")).strip().lower() in {"1", "true", "yes"}
    if not use_dev_server:
        try:
            from waitress import serve
            threads = max(8, int(os.getenv("WAITRESS_THREADS", "64")))
            connection_limit = max(threads, int(os.getenv("WAITRESS_CONNECTION_LIMIT", "300")))
            channel_timeout = max(120, int(os.getenv("WAITRESS_CHANNEL_TIMEOUT", "300")))
            logger.info(
                "Serving via Waitress | threads=%d | connection_limit=%d | channel_timeout=%ds",
                threads, connection_limit, channel_timeout,
            )
            serve(
                flask_app,
                host=host,
                port=port,
                threads=threads,
                connection_limit=connection_limit,
                channel_timeout=channel_timeout,
            )
            return
        except ImportError:
            logger.warning(
                "Waitress not installed — falling back to the Flask dev server (NOT for production). "
                "Run: pip install waitress"
            )

    flask_app.run(
        host=host,
        port=port,
        debug=debug,
        threaded=True,
    )


if __name__ == "__main__":
    run_app()
