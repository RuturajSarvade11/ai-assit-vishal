"""
Inspect one stored solution end-to-end: payload row, error vectors, artifact references.

WHY (a live case): a master-task twin of the correct fix existed in DynamoDB
("0 Times Recommended") yet never appeared in any trace's top-10 — the usual cause is
missing/failed async vectorization: without vectors in the error collection the search
can never retrieve it, no matter how perfect the match would be.

    python debug_request.py <request_id>               # inspect
    python debug_request.py <request_id> --vectorize   # re-enqueue vector build, then inspect again
"""
import argparse
import sys

import src.utils.log_setup  # noqa: F401

from src.utils import project_details as pd
from src.utils import recommended
from src.services import handlers


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("request_id")
    ap.add_argument("--vectorize", action="store_true",
                    help="force re-enqueue of this request's error vectors, then re-run to confirm")
    args = ap.parse_args()
    rid = args.request_id.strip()

    payload = pd.get_final_build_payload(rid) or {}
    if not payload:
        print(f"FINAL PAYLOAD: NOT FOUND for {rid} — wrong id or deleted")
        return 1
    print(f"FINAL PAYLOAD: found | task={payload.get('task_name')} | project={payload.get('project_name')} "
          f"| created={payload.get('created_date')}")
    sol = payload.get("solution") or []
    files = [str((s or {}).get('filePath') or (s or {}).get('fileName') or '?') for s in sol if isinstance(s, dict)]
    print(f"SOLUTION: {len(sol)} file(s): {files[:5]}")

    try:
        archived = pd.get_archived_payload_references(rid)
        print(f"ARCHIVE REFS: {len(archived or [])}")
    except Exception as exc:
        print(f"ARCHIVE REFS: lookup failed ({exc})")

    total_vectors = 0
    for field in ("request_id", "batch_id"):
        try:
            res = recommended.collection.get(where={field: rid}, include=["metadatas"], limit=100)
            ids = res.get("ids") or []
            metas = res.get("metadatas") or []
            total_vectors += len(ids)
            print(f"ERROR VECTORS by {field}: {len(ids)}")
            for i, vid in enumerate(ids[:5]):
                m = metas[i] if i < len(metas) and isinstance(metas[i], dict) else {}
                print(f"   {vid} | task={m.get('task_path') or m.get('task_name')} "
                        f"| sig={str(m.get('error_signature_hash') or '')[:16]} | project={m.get('project_name')}")
        except Exception as exc:
            print(f"ERROR VECTORS by {field}: query failed ({exc})")

    # WHAT each stored artifact actually SAYS: "two debug.logs" is not the answer -
    # the question is whether their CONTENT belongs to this solution's own failure. A log from
    # a different root cause attached here makes this solution match the wrong live failures.
    from io import BytesIO
    from zipfile import ZipFile
    from src.utils.payload_archive import get_s3_client, S3_BUCKET

    def _root_cause_lines(s3_key: str, limit: int = 3) -> list:
        try:
            body = get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key)["Body"].read()
            with ZipFile(BytesIO(body), "r") as zf:
                names = zf.namelist()
                raw = zf.read(names[0]) if names else b""
            text = raw.decode("utf-8", errors="replace")
            lines = handlers._failure_signal_lines(text)
            lines.sort(key=lambda ln: (0 if ("must be" in ln.lower() or "but got" in ln.lower()) else 1))
            return [ln.strip()[:160] for ln in lines[:limit]] or ["(no failure-signal line found)"]
        except Exception as exc:
            return [f"(could not read: {exc})"]

    for at in ("runtime", "binary"):
        refs = pd.get_artifact_references(rid, at) or []
        print(f"ARTIFACT REFS ({at}): {len(refs)} — {[str(r.get('file_name')) for r in refs[:5]]}")
        for i, ref in enumerate(refs, 1):
            key = str((ref or {}).get("s3_key") or "").strip()
            if not key:
                continue
            print(f"   [{i}] {str(ref.get('file_name') or '?')}  key=...{key[-46:]}")
            for ln in _root_cause_lines(key):
                print(f"        {ln}")

    if total_vectors == 0:
        print()
        print("DIAGNOSIS: NO ERROR VECTORS — the search can NEVER retrieve this solution.")
        if args.vectorize:
            try:
                handlers._enqueue_vectorization(rid, force=True)
                print("VECTORIZE: re-enqueued (force). Wait ~30s, re-run this script to confirm "
                      "vectors appear, then re-run the recommendation.")
            except Exception:
                import traceback
                traceback.print_exc()
        else:
            print("Run again with --vectorize to force the vector build.")
    else:
        print()
        print(f"DIAGNOSIS: {total_vectors} vector(s) present — retrieval should find it; if it still "
              "does not appear in a FRESH trace, paste that trace's verify output.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
