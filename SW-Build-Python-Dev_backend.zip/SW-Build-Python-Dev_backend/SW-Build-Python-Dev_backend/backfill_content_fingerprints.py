"""
One-time migration: stamp content_fingerprint on existing archive/artifact reference rows.

WHY: the storage/duplicate-handling redesign decides duplicates by a fingerprint of the
CLEANED content (timestamps, uuids, paths removed — see src/utils/content_fingerprint.py).
New uploads carry the fingerprint from day one; rows written before the change do not.
Without a fingerprint an old row can never match a new upload, so the first re-upload after
deployment stores one extra copy. This backfill closes that gap: it computes the fingerprint
from the stored S3 content and writes it onto the DynamoDB reference row.

WHAT IT TOUCHES (ai_assisted_data table only):
  ARCHIVE#...  rows -> fingerprint of the archived per-file payload JSON (payload_content_fingerprint)
  BINARY#...   rows -> fingerprint of the artifact bytes (content_fingerprint_for_bytes)
  RUNTIME#...  rows -> fingerprint of the artifact bytes (content_fingerprint_for_bytes)

SAFE + IDEMPOTENT:
  - Only ADDS the content_fingerprint attribute; nothing else on the row changes.
  - Rows that already have content_fingerprint are skipped, so re-running is harmless.
  - S3 is read-only here. No rows are deleted, no S3 objects touched.

RUN from the backend folder with the target .env (APP_ENV decides the environment):

    python backfill_content_fingerprints.py --dry-run   # scan + report only, change nothing
    python backfill_content_fingerprints.py             # write content_fingerprint
"""
import json
import logging
import os
import sys
from io import BytesIO
from zipfile import ZipFile

import src.utils.log_setup  # noqa: F401

from src.utils.payload_archive import get_s3_client, S3_BUCKET
from src.utils.project_details import ai_assisted_data_table, ARCHIVE_SK, BINARY_SK, RUNTIME_SK
from src.utils.content_fingerprint import content_fingerprint_for_bytes, payload_content_fingerprint

log = logging.getLogger("backfill_fingerprints")
DRY_RUN = "--dry-run" in sys.argv
PAGE_LIMIT = max(100, int(os.getenv("MIGRATION_PAGE", "1000")))

_PREFIXES = (f"{ARCHIVE_SK}#", f"{BINARY_SK}#", f"{RUNTIME_SK}#")


def _clean_key(s3_key: str) -> str:
    return str(s3_key or "").strip().rstrip('"').rstrip("%22")


def _download_first_entry(s3_key: str) -> bytes:
    resp = get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key)
    body = resp["Body"].read()
    with ZipFile(BytesIO(body), "r") as zf:
        names = zf.namelist()
        return zf.read(names[0]) if names else b""


def fingerprint_for_row(row: dict) -> str:
    sk = str(row.get("SK") or "")
    s3_key = _clean_key(row.get("s3_key"))
    if not s3_key:
        return ""
    raw = _download_first_entry(s3_key)
    if sk.startswith(f"{ARCHIVE_SK}#"):
        try:
            payload = json.loads(raw.decode("utf-8", errors="replace"))
        except Exception:
            payload = {"value": raw.decode("utf-8", errors="replace")}
        return payload_content_fingerprint(payload)
    return content_fingerprint_for_bytes(raw, str(row.get("file_name") or ""))


def scan_rows_needing_fingerprint():
    scanned = 0
    todo = []
    kwargs = {"Limit": PAGE_LIMIT}
    while True:
        res = ai_assisted_data_table.scan(**kwargs)
        for row in res.get("Items", []):
            scanned += 1
            sk = str(row.get("SK") or "")
            if not sk.startswith(_PREFIXES):
                continue
            if str(row.get("content_fingerprint") or "").strip():
                continue
            todo.append(row)
        last_key = res.get("LastEvaluatedKey")
        if not last_key:
            break
        kwargs["ExclusiveStartKey"] = last_key
    return scanned, todo


def main():
    scanned, todo = scan_rows_needing_fingerprint()
    by_kind = {}
    for row in todo:
        kind = str(row.get("SK") or "").split("#", 1)[0]
        by_kind[kind] = by_kind.get(kind, 0) + 1
    log.info("rows scanned=%d | need content_fingerprint=%d | breakdown=%s", scanned, len(todo), by_kind)

    if DRY_RUN:
        for row in todo[:10]:
            log.info("[dry-run] PK=%s | SK=%s | s3_key=%s", row.get("PK"), row.get("SK"), row.get("s3_key"))
        if len(todo) > 10:
            log.info("[dry-run] ... and %d more", len(todo) - 10)
        log.info("[dry-run] would stamp %d row(s). No changes made.", len(todo))
        return

    updated = failed = no_key = 0
    for row in todo:
        pk, sk = row.get("PK"), row.get("SK")
        try:
            fingerprint = fingerprint_for_row(row)
            if not fingerprint:
                no_key += 1
                log.warning("no s3_key on row | PK=%s | SK=%s — skipped", pk, sk)
                continue
            ai_assisted_data_table.update_item(
                Key={"PK": pk, "SK": sk},
                UpdateExpression="SET content_fingerprint = :fp",
                ConditionExpression="attribute_not_exists(content_fingerprint)",
                ExpressionAttributeValues={":fp": fingerprint},
            )
            updated += 1
            if updated % 100 == 0:
                log.info("progress | updated=%d | failed=%d", updated, failed)
        except Exception as exc:
            failed += 1
            log.error("backfill failed | PK=%s | SK=%s | %s", pk, sk, exc)

    log.info("MIGRATION done | updated=%d | failed=%d | no_s3_key=%d | total_candidates=%d",
             updated, failed, no_key, len(todo))


if __name__ == "__main__":
    main()
