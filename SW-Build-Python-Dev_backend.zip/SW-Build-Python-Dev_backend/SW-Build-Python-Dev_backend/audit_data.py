"""
What the recommendation actually has to work with, for one project.

Not two records: every stored solution, what it FIXES, which task it sits under, and what each of
its artifacts SAYS. That is the data engineer's view of the knowledge base - families of identical
fixes, and any solution holding a log that belongs to a different failure.

    python audit_data.py                 # project testgbe
    python audit_data.py --project foo
"""
import argparse
import re
import sys
from io import BytesIO
from zipfile import ZipFile

import src.utils.log_setup  # noqa: F401

from src.services import handlers
from src.utils import project_details as pd
from src.utils.payload_archive import get_s3_client, S3_BUCKET


def _flat(node) -> str:
    out = []

    def walk(n):
        if isinstance(n, dict):
            for v in n.values():
                walk(v)
        elif isinstance(n, list):
            for v in n:
                walk(v)
        elif n is not None:
            out.append(str(n))

    walk(node)
    return " ".join(out)


def _fixes_what(payload) -> str:
    """Which thing this fix corrects, from its own change lines."""
    text = _flat((payload or {}).get("solution") or [])
    m = re.search(r'name="([^"]+)"', text)
    if m:
        return m.group(1)
    m = re.search(r'([A-Za-z0-9_.\-]+\.(?:xml|kts|json|py|txt))', text)
    if m:
        return m.group(1)
    # TD5 solutions carry no name="..." attribute - identify the fix by the file it changed.
    for entry in ((payload or {}).get("solution") or []):
        if isinstance(entry, dict):
            fn = str(entry.get("fileName") or entry.get("filePath") or "").strip()
            if fn:
                return fn.replace("\\", "/").split("/")[-1]
    return "?"


def _artifact_says(s3_key: str) -> str:
    """The root cause the stored artifact describes."""
    try:
        body = get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key)["Body"].read()
        with ZipFile(BytesIO(body), "r") as zf:
            names = zf.namelist()
            raw = zf.read(names[0]) if names else b""
        text = raw.decode("utf-8", errors="replace")
        lines = handlers._failure_signal_lines(text)
        best = [ln for ln in lines if "must be" in ln.lower() or "but got" in ln.lower()]
        pick = (best or lines or [""])[0].strip()
        if not pick:
            return "(no failure signal - boilerplate only)"
        m = re.search(r'name=([A-Za-z0-9_.\-]+)', pick) or re.search(r"name=([^\]]+)\]", pick)
        subject = m.group(1) if m else ""
        return (subject + " :: " if subject else "") + pick[:110]
    except Exception as exc:
        return f"(unreadable: {exc})"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default="testgbe")
    # The audit found ctc_aurix fixes holding python debug.logs. The code now refuses
    # to score a record on another fix's log, but the wrong LINK is still stored - and stored
    # wrong data outlives any scoring rule. This unlinks the reference row only: the file stays
    # in S3, the solution stays, nothing else is touched. Dry-run unless --apply.
    ap.add_argument("--unlink-foreign", action="store_true",
                    help="unlink artifacts that name ANOTHER stored fix (dry-run unless --apply)")
    ap.add_argument("--apply", action="store_true", help="actually delete the reference rows")
    args = ap.parse_args()
    project = args.project.strip().lower()

    rows = pd.list_final_build_payloads_by_project(project) or []
    print(f"\nSOLUTIONS STORED FOR {project}: {len(rows)}\n")
    print(f"{'request':<10}{'task':<26}{'fixes':<14}{'created':<22}{'artifacts'}")
    print("-" * 118)

    families, mismatched, no_artifacts, no_signal = {}, [], [], []
    all_refs = []
    gated = []
    for row in sorted(rows, key=lambda r: str(r.get("created_date") or "")):
        rid = str(row.get("request_id") or "")
        payload = row.get("payload_json") if isinstance(row.get("payload_json"), dict) else {}
        fixes = _fixes_what(payload)
        task = str(row.get("task_name") or "-")
        families.setdefault(fixes, []).append(rid[:8])

        refs = (pd.get_artifact_references(rid, "runtime") or []) + \
               (pd.get_artifact_references(rid, "binary") or [])
        print(f"{rid[:8]:<10}{task[:24]:<26}{fixes[:12]:<14}{str(row.get('created_date') or '')[:19]:<22}"
              f"{len(refs)} file(s)")
        if not refs:
            no_artifacts.append(rid[:8])
        for ref in refs:
            key = str((ref or {}).get("s3_key") or "").strip()
            if not key:
                continue
            says = _artifact_says(key)
            all_refs.append((rid, fixes, says, ref))
            flag = ""
            if (ref or {}).get("evidence_eligible") is False:
                gated.append(rid[:8])
                flag = "  <-- ingest gate: stored, not used as evidence for this fix"
            if "no failure signal" in says:
                no_signal.append(rid[:8])
                flag = "  <-- boilerplate, cannot be evidence"
            elif fixes not in ("?",) and fixes.lower() not in says.lower():
                mismatched.append((rid[:8], fixes, says[:60]))
                flag = "  <-- describes a DIFFERENT failure than this fix"
            print(f"{'':<10}  {str(ref.get('file_name') or '?')[:18]:<20}{says}{flag}")

    if args.unlink_foreign:
        # Only unlink when the log NAMES a different fix that actually exists in this project.
        # A log naming nobody - a generic build.log - is never touched: absence of a signal is
        # not evidence of a wrong link, and deleting on a guess loses real evidence forever.
        known = [k for k in families if k != "?"]
        foreign = []
        for _rid, _fixes, _says, _ref in all_refs:
            low = _says.lower()
            if _fixes == "?" or _fixes.lower() in low:
                continue
            named = [k for k in known if k != _fixes and k.lower() in low]
            if named:
                foreign.append((_rid, _fixes, named[0], _ref))
        print()
        print("FOREIGN ARTIFACT LINKS: %d" % len(foreign))
        for _rid, _fixes, _named, _ref in foreign:
            print("  %-10s fixes %-14s holds a %s log  ->  %s"
                  % (_rid[:8], _fixes, _named, _ref.get("file_name")))
        if not foreign:
            print("  none - nothing to unlink")
        elif not args.apply:
            print()
            print("  DRY RUN - re-run with --apply to unlink these reference rows.")
            print("  The files stay in S3 and the solutions stay; only the wrong link is removed.")
        else:
            n = pd.delete_table_items(pd.ai_assisted_data_table, [r for _, _, _, r in foreign])
            print()
            print("  UNLINKED %d reference row(s). Re-run the recommendation to confirm." % n)

    # ARTIFACT VECTOR INDEX (prove-it-for-TD5): a stored file only counts as ranking
    # evidence if it ALSO has a summary vector in the artifact index - S3+Dynamo alone are not
    # enough. Same lookup keys the scorer uses: s3_key and content_sha12.
    print()
    print("ARTIFACT VECTOR INDEX")
    try:
        res = handlers.get_artifact_chroma_collection().get(
            where={"project_name": project}, include=["metadatas"], limit=1000)
        vec_metas = [m for m in (res.get("metadatas") or []) if isinstance(m, dict)]
        vec_keys = {str(m.get("s3_key") or "").strip() for m in vec_metas if m.get("s3_key")}
        vec_shas = {str(m.get("content_sha12") or "").strip().lower()
                    for m in vec_metas if m.get("content_sha12")}
        print("  summary vectors stored for '%s': %d" % (project, len(vec_metas)))
        missing, by_design = [], 0
        for _rid, _fixes, _says, _ref in all_refs:
            k = str((_ref or {}).get("s3_key") or "").strip()
            sha = str((_ref or {}).get("content_fingerprint") or "").strip().lower()[:12]
            if k and k not in vec_keys and (not sha or sha not in vec_shas):
                if "no failure signal" in _says:
                    by_design += 1      # boilerplate is never embedded - the noise gate working
                else:
                    missing.append((_rid[:8], _ref.get("file_name"), k[-40:]))
        print("  boilerplate refs correctly NOT embedded (noise gate, by design): %d" % by_design)
        print("  signal-carrying refs WITHOUT a vector (these NEED repair): %d" % len(missing))
        for _r, _f, _k in missing[:12]:
            print("      %s  %s  ...%s" % (_r, _f, _k))
        if missing:
            print("  -> repair: python repair_artifact_raw_content.py --refresh-embeddings "
                  "--project %s" % project)
    except Exception as exc:
        print("  (vector index unreadable: %s)" % exc)

    print("\nFAMILIES (identical fixes stored many times):")
    for fixes, ids in sorted(families.items(), key=lambda kv: -len(kv[1])):
        print(f"  {fixes:<14} {len(ids):>3} solution(s)   {', '.join(ids[:10])}"
              + (" ..." if len(ids) > 10 else ""))

    print(f"\nDATA HEALTH")
    print(f"  solutions with NO artifact at all      : {len(no_artifacts)}  {no_artifacts[:10]}")
    print(f"  artifacts that are boilerplate only    : {len(no_signal)}  {sorted(set(no_signal))[:10]}")
    print(f"  artifacts describing a DIFFERENT failure: {len(mismatched)}")
    print(f"  blocked by the ingest gate (stored, not evidence): {len(gated)}  {sorted(set(gated))[:10]}")
    for rid, fixes, says in mismatched[:10]:
        print(f"      {rid}  fixes {fixes:<12} but its log says: {says}")
    print("\nA fix holding another failure's log can win on evidence that was never about it -")
    print("the matcher now PREFERS the log that is about the fix, so these are survivable, but")
    print("each one is a record whose evidence is weaker than it should be.\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
