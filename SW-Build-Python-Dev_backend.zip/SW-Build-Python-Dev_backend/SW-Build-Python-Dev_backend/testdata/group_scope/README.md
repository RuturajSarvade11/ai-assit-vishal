# Group-scope test data

A ready-made scenario for proving that sharing evidence across a group works **and stays safe**.

The two failures here are deliberately built like Sankar's original scenario: **the error text is
nearly identical, and only the log names the real cause.** That is what makes them a fair test —
if the ranking picks correctly, it can only be because the *evidence* decided, not the wording.

| file | the failure it describes |
|---|---|
| `error_python.txt`  | build error text, python tool version |
| `debug_python.log`  | the live log — names **python** |
| `error_ctc.txt`     | the same error text shape, ctc tool version |
| `debug_ctc.log`     | the live log — names **ctc_aurix** |

## Run it

```
python test_group_scope_api.py --discover
```

Start there. It reads the group configuration and tells you which projects can actually be
tested. Group scope does nothing where no group is defined — and that looks exactly like a
broken feature, so check first.

Then, using a project the discover step named:

```
python test_group_scope_api.py --project <project> --task <task> \
    --error-file testdata/group_scope/error_python.txt \
    --artifact-file testdata/group_scope/debug_python.log
```

and the vice-versa run with `error_ctc.txt` / `debug_ctc.log`.

## What a good result looks like

- **Both directions correct** — the python failure ranks a python fix first, the ctc failure
  ranks a ctc fix first. Same task, same error text; only the log differs.
- If a **cross-project** fix wins, it won with a real `artifact_sim` value. A cross-project
  candidate winning with **no** artifact evidence is the failure mode group scope must never
  have, and the script fails the run if it sees it.
- **Ungrouped projects never widen** — checked automatically on every run.

## What is NOT proven here

These files describe a *tool-version* failure, which is portable between projects. A fix that
edits a file path is not necessarily portable — the original reason recommendations were
project-scoped was "a cross-project fix references paths that don't exist here". Proving the
portable case does not prove the path-bound one.
