"""Inventory what a group's projects ACTUALLY hold, before trying to prove cross-project sharing.

WHY THIS EXISTS: the first real group-scope run on dev passed every safety check and
still proved nothing about sharing - it reported "cross-project candidates seen: 0". That is not
a bug. Group scope widens the SEARCH; it cannot invent a solution that no sibling has stored. A
project whose siblings hold nothing comparable will correctly keep returning zero forever, and
re-running the test never changes that.

So the question to answer FIRST is not "does sharing work" but "is sharing testable here at all":
does any sibling hold a stored fix, and does the home project lack one for it? Only a failure
whose answer lives ONLY in a sibling can tell project scope and group scope apart.

Reads only. Writes nothing, changes no configuration.

    python inspect_group_data.py --project testgbe
    python inspect_group_data.py --all            # every defined group

Read the verdict at the bottom before designing any sharing test.
"""
import argparse
import os
import sys
from collections import defaultdict

import src.utils.log_setup  # noqa: F401

from src.services import project_groups as pg


def _rule(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)


def _scan_fixes():
    """One table scan, bucketed by project. list_final_build_payloads_by_project() scans the whole
    table PER project - fine for one call, wasteful and slow for every member of a group."""
    from src.utils.project_details import (
        final_build_payload_table, _scan_all, _payload_json_dict, _normalize_project_name,
    )
    by_project = defaultdict(list)
    for row in _scan_all(final_build_payload_table) or []:
        payload = _payload_json_dict(row) or {}
        name = _normalize_project_name(row.get("project_name") or payload.get("projectName"))
        if not name:
            continue
        by_project[name].append({
            "request_id": str(row.get("request_id") or ""),
            "task_name": str(row.get("task_name") or payload.get("taskName") or ""),
            "created_date": str(row.get("created_date") or ""),
            "solution": payload.get("solution") or [],
        })
    return by_project


def _scan_artifacts(names):
    """Artifact counts per project. Artifacts are what the ranking actually decides on - a sibling
    with fixes but NO artifacts can be retrieved and then scores no evidence, which looks like
    sharing being broken when it is really the data being thin."""
    counts = {}
    try:
        from src.services.handlers import get_artifact_chroma_collection
        col = get_artifact_chroma_collection()
    except Exception as exc:
        print(f"  (artifact collection unavailable: {exc})")
        return {n: None for n in names}
    for n in names:
        try:
            res = col.get(where={"project_name": n}, include=["metadatas"], limit=2000)
            counts[n] = len(res.get("metadatas") or [])
        except Exception:
            counts[n] = None
    return counts


def _error_text_index(projects):
    """{request_id: stored error text} for these projects.

    A fix in final_build_payload does NOT guarantee its error vector still exists - the first
    donor picked from the list had a fix and no error text, so the replay could not be built. A
    donor is only usable if BOTH halves survive, so the lists are filtered by this rather than
    letting people discover it one failed attempt at a time.
    """
    from src.utils import recommended
    out = {}
    for project in projects:
        try:
            res = recommended.collection.get(where={"project_name": project},
                                             include=["documents", "metadatas"], limit=5000)
        except Exception:
            continue
        docs = res.get("documents") or []
        metas = res.get("metadatas") or []
        for i, meta in enumerate(metas):
            rid = str((meta or {}).get("request_id") or "").strip()
            doc = str(docs[i] if i < len(docs) else "")
            if rid and doc.strip() and rid not in out:
                out[rid] = doc
    return out


def _solution_files(sol):
    out = []
    for ch in (sol or [])[:40]:
        if isinstance(ch, dict):
            name = ch.get("fileName") or ch.get("file_name") or ch.get("filePath") or ""
            if name:
                out.append(str(name).replace("\\", "/").split("/")[-1])
    return out


def report_group(project, fixes, arts, err_index=None):
    err_index = err_index or {}
    members, mode = pg.resolve_scope_projects(project)
    _rule(f"GROUP OF {project}")
    print(f"  resolves to: {mode}   members: {', '.join(members)}")
    if mode != "group":
        print()
        print("  This project does not widen. Nothing here can demonstrate sharing - that is")
        print("  correct behaviour, not a defect.")
        return False

    home_tasks = {f["task_name"] for f in fixes.get(project, [])}
    _rule("WHAT EACH MEMBER HOLDS")
    donors = []
    for m in members:
        rows = fixes.get(m, [])
        art = arts.get(m)
        art_txt = "?" if art is None else str(art)
        tag = "  <- HOME" if m == project else ""
        print(f"  {m:<28} fixes={len(rows):<4} artifacts={art_txt:<6}{tag}")
        for r in sorted(rows, key=lambda x: x["created_date"], reverse=True)[:6]:
            files = _solution_files(r["solution"])
            print(f"      {r['request_id'][:8]}  {r['created_date'][:10]}  "
                  f"task={r['task_name'] or '(none)'}")
            if files:
                print(f"                changed: {', '.join(files[:6])}")
        if m != project and rows and art:
            # A usable donor needs all three: a fix, artifacts to prove it with, and a surviving
            # ERROR VECTOR to replay. The first donor picked from an unfiltered list had the fix
            # and no error text, so the replay could not be built at all.
            unique = [r for r in rows
                      if r["task_name"] not in home_tasks and r["request_id"] in err_index]
            donors.append((m, rows, unique))

    _rule("VERDICT: is cross-project sharing testable here?")
    if not donors:
        print("  NO. No sibling holds both a stored fix and artifacts to score it with.")
        print("  Group scope will keep returning zero cross-project candidates, correctly.")
        print()
        print("  To make it testable, the tester must produce ONE real fix in a sibling project:")
        for m in members:
            if m != project:
                print(f"      - break a task in '{m}', fix it, let the extension upload it")
        print("  Then re-run this inventory. No seeding script can substitute for that - a")
        print("  hand-written record would prove the test harness works, not the product.")
        return False

    print("  YES. These siblings can act as the donor:")
    for m, rows, unique in donors:
        print(f"      {m}: {len(rows)} fix(es), {arts.get(m)} artifact(s)")
        if unique:
            print(f"          {len(unique)} REPLAYABLE, on task(s) the home project never fixed:")
            for r in unique[:4]:
                # FULL id: this is the one line people copy, and --dump-donor resolves a prefix
                # only by rescanning. Printing it whole saves that round trip.
                print(f"            {r['request_id']}  task={r['task_name']}")
            print("          ^ use one of these: its answer exists ONLY in the sibling, so")
            print("            project scope must miss it and group scope must find it.")
        else:
            print("          but none of its fixes are usable as a donor: either the task is one")
            print("          the home project also fixes (its own fix would win, correctly, and")
            print("          the comparison would isolate nothing), or the error vector no longer")
            print("          exists so there is no failure text left to replay.")
    return True


def dump_donor(request_id, out_dir, home_project):
    """Write a DONOR's stored error text to a file so it can be replayed as the home project's
    failure.

    This is what turns "cross-project candidates seen: 0" into a real test. That zero was never a
    bug: the query was a testgbe python/config.xml failure while the siblings hold aramis and
    tresos_gen fixes, so there was genuinely nothing to share. The decisive query is a failure
    whose answer exists ONLY in a sibling - then project scope must miss it and group scope must
    find it, and the difference cannot be explained by anything else.
    """
    from src.utils import recommended
    from src.utils.project_details import get_final_build_payload

    rid = str(request_id or "").strip()
    _rule(f"DONOR {rid[:8] if rid != 'auto' else '(auto)'}")
    # The task as recorded on the DynamoDB ROW. get_final_build_payload reads taskName out of the
    # payload JSON, which is empty for some rows even when the row's own task_name column is set -
    # so the replay command printed "--task <task>" for a donor whose task we had just displayed.
    known_task = ""

    if rid.lower() == "auto":
        # Pick a donor that actually works, rather than making someone try ids until one does.
        # Requires all three: sibling-owned, a task the home project never fixed, and a surviving
        # error vector. Most fixes per project first - the richest sibling is the likeliest to
        # have a comparable failure.
        members, mode = pg.resolve_scope_projects(home_project)
        if mode != "group":
            print(f"  {home_project} does not widen - there is no sibling to borrow from.")
            return 1
        fixes = _scan_fixes()
        err_index = _error_text_index([m for m in members if m != home_project])
        home_tasks = {f["task_name"] for f in fixes.get(home_project, [])}
        best = None
        for m in sorted((x for x in members if x != home_project),
                        key=lambda x: -len(fixes.get(x, []))):
            for r in sorted(fixes.get(m, []), key=lambda x: x["created_date"], reverse=True):
                if r["task_name"] and r["task_name"] not in home_tasks and r["request_id"] in err_index:
                    best = (m, r)
                    break
            if best:
                break
        if not best:
            print("  No sibling has a fix that is BOTH on a task this project never fixed AND")
            print("  still has its error text stored. Run without --dump-donor to see why.")
            return 1
        owner_project, row = best
        rid = row["request_id"]
        known_task = row["task_name"]
        print(f"  chose {rid} from {owner_project} (task {known_task})")

    # The donor list prints SHORT ids for readability, so a short id is what anyone will paste
    # here - but the stored metadata holds the full UUID and an exact-match lookup on a prefix
    # finds nothing. Resolve it rather than making the caller go and find the long form.
    if len(rid) < 36:
        hits = [r for rows in _scan_fixes().values() for r in rows
                if r["request_id"].startswith(rid)]
        matches = sorted({r["request_id"] for r in hits})
        if not matches:
            print(f"  No stored fix whose request id starts with '{rid}'.")
            return 1
        if len(matches) > 1:
            print(f"  '{rid}' is ambiguous - {len(matches)} fixes start with it:")
            for m in matches[:10]:
                print(f"      {m}")
            return 1
        rid = matches[0]
        known_task = next((r["task_name"] for r in hits if r["request_id"] == rid), "")
        print(f"  resolved to: {rid}")

    try:
        res = recommended.collection.get(where={"request_id": rid},
                                         include=["documents", "metadatas"], limit=5)
    except Exception as exc:
        print(f"  lookup failed: {exc}")
        return 1
    docs = [d for d in (res.get("documents") or []) if str(d or "").strip()]
    metas = res.get("metadatas") or []
    if not docs:
        print("  No stored error text for this request id. Pick another from the donor list -")
        print("  a fix can exist without its error vector still being present.")
        return 1

    owner = str((metas[0] or {}).get("project_name") or "?") if metas else "?"
    payload = get_final_build_payload(rid) or {}
    task = str(payload.get("taskName") or "") or known_task

    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"error_donor_{rid[:8]}.txt")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(docs[0])
    print(f"  owner project: {owner}")
    print(f"  task:          {task or '(none recorded)'}")
    print(f"  written:       {path}  ({len(docs[0])} chars)")
    print()
    print("  Replay it as the HOME project's failure - the answer lives only in the sibling:")
    print(f"      python test_group_scope_api.py --project {home_project} \\")
    print(f"          --task {task or '<task>'} --error-file {path}")
    print()
    print("  No --artifact-file: the raw artifact lives in S3, not the vector store, so this")
    print("  query carries error text only. Artifact scores are then 0 for EVERY candidate, which")
    print("  is fair - it tests retrieval sharing, which is the half that was unproven.")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", default="", help="project whose group to inventory")
    ap.add_argument("--all", action="store_true", help="inventory every defined group")
    ap.add_argument("--dump-donor", default="",
                    help="'auto', or a sibling fix's request id (full or prefix): write its "
                         "error text for replay as the home project's failure")
    ap.add_argument("--out-dir", default=os.path.join("testdata", "group_scope"),
                    help="where --dump-donor writes (default testdata/group_scope)")
    args = ap.parse_args()
    if args.dump_donor:
        return dump_donor(args.dump_donor, args.out_dir, args.project or "testgbe")
    if not args.project and not args.all:
        ap.print_help()
        return 2

    print("scanning stored fixes ...")
    fixes = _scan_fixes()

    targets = []
    if args.project:
        targets = [args.project.strip().lower()]
    else:
        defs = pg.list_group_defs()
        overrides = pg.get_overrides()
        seen = set()
        for n in sorted(fixes):
            g = pg.resolve_group(n, defs, overrides)
            if g != pg.DEFAULT_GROUP and g not in seen:
                seen.add(g)
                targets.append(n)
        if not targets:
            print("No defined group has any stored fixes.")
            return 1

    all_members = set()
    for t in targets:
        m, _ = pg.resolve_scope_projects(t)
        all_members.update(m)
    print("counting artifacts ...")
    arts = _scan_artifacts(sorted(all_members))
    print("checking which fixes still have replayable error text ...")
    err_index = _error_text_index(sorted(all_members))

    any_testable = False
    for t in targets:
        any_testable = report_group(t, fixes, arts, err_index) or any_testable
    return 0 if any_testable else 1


if __name__ == "__main__":
    sys.exit(main())
