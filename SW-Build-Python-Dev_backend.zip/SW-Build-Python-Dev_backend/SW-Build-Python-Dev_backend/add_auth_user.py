"""
add_auth_user.py — ADD a single dashboard user WITHOUT touching anyone else.

Unlike seed_auth_users.py (which RESETS all four seeded users to their defaults), this script is
purely ADDITIVE and SAFE: it REFUSES to overwrite an existing user, so passwords already set by other
developers are never affected. Re-run it any time to keep adding more users.

  python add_auth_user.py jdoe --name "Jane Doe" --role user
  python add_auth_user.py jdoe --name "Jane Doe" --info "Developer" --role user --password "Welcome@123"
  python add_auth_user.py someone --role admin                  # add another admin
  python add_auth_user.py jdoe --role user --force              # DANGER: only with --force will it RESET an existing user

Roles:
  user   -> can log in and use the dashboard, but is REJECTED by admin-only endpoints
            (require_role("owner","admin")) — e.g. the adapter toggle (and data injection, once guarded).
  admin  -> full access, like the seeded users.

The new user gets must_change_password=True, so they set their own strong password on first login.
Other users are left exactly as they are.
"""
import argparse

from src.auth.security import hash_password
from src.auth.users import get_user, put_user
from seed_auth_users import ensure_table

DEFAULT_PASSWORD = "Welcome@123"


def main():
    p = argparse.ArgumentParser(description="Add ONE dashboard user (additive — never resets others).")
    p.add_argument("username", help="login id, e.g. shubham")
    p.add_argument("--name", default="", help='display name, e.g. "Shubham Deshmukh"')
    p.add_argument("--info", default="", help='title/department text, e.g. "Developer"')
    p.add_argument("--role", default="user", choices=["user", "admin", "owner"],
                   help="role: user (default, restricted) | admin | owner")
    p.add_argument("--password", default=DEFAULT_PASSWORD,
                   help=f"easy first-login password (default {DEFAULT_PASSWORD})")
    p.add_argument("--force", action="store_true",
                   help="DANGER: overwrite/RESET the user if they already exist (default is to SKIP)")
    a = p.parse_args()

    username = (a.username or "").strip().lower()
    if not username:
        print("  username is required")
        return
    name = a.name or a.username
    ensure_table()

    existing = get_user(username)
    if existing and not a.force:
        print(f"  '{username}' already exists (role={existing.get('role')}, "
              f"must_change={bool(existing.get('must_change_password'))}). SKIPPED — their password is "
              f"left untouched. Use --force ONLY if you really intend to reset this user.")
        return

    put_user(username, name, a.info, a.role, hash_password(a.password), must_change=True)
    verb = "RESET existing" if existing else "ADDED new"
    print(f"  {verb} user: {username} | name='{name}' | info='{a.info}' | role={a.role} | "
          f"default password={a.password} (must change on first login)")
    print("  All other users are untouched. Give this person their username + default password.")


if __name__ == "__main__":
    main()
