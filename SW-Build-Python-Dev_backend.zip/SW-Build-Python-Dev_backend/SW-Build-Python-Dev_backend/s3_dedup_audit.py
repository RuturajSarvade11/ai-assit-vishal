"""
READ-ONLY audit of S3 duplication — counts how many objects are duplicate copies of the same
content, per storage area, and how much storage that wastes. Changes NOTHING (no writes/deletes).

How content identity is determined per area:
  * task-runtime-artifacts/ and binary-artifacts/ — the key itself ends with the file's
    content sha256[:12] ("...-{sha12}.zip"), so grouping is free (no downloads).
  * AI-assited-data/ (error+solution payload zips) — zip bytes differ per upload (zip timestamps),
    so the uploaded object's METADATA sha256 is read via HEAD requests (bounded by AUDIT_MAX_HEADS).
  * recommendation/ — key ends with the error_hash, grouped by it.
  * prediction-features/ — METADATA payload sha via HEAD (same bound).

Run from the backend folder, in the venv, with the target .env (APP_ENV):

    python s3_dedup_audit.py
"""
import logging
import os
import re
from collections import defaultdict

import src.utils.log_setup  # noqa: F401
from src.configurations import config
from src.utils.payload_archive import get_s3_client, S3_BUCKET

log = logging.getLogger("s3_dedup_audit")
MAX_HEADS = max(100, int(os.getenv("AUDIT_MAX_HEADS", "5000")))

_SHA12_RE = re.compile(r"-([0-9a-fA-F]{12})\.zip$")


def list_objects(prefix: str):
    paginator = get_s3_client().get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=S3_BUCKET, Prefix=prefix, PaginationConfig={"PageSize": 1000}):
        for obj in page.get("Contents", []):
            yield obj


def head_sha(key: str) -> str:
    try:
        resp = get_s3_client().head_object(Bucket=S3_BUCKET, Key=key)
        meta = {k.lower(): v for k, v in (resp.get("Metadata") or {}).items()}
        return (meta.get("payload_sha256") or meta.get("sha256") or "").strip().lower()
    except Exception:
        return ""


def report(area: str, groups: dict, sizes: dict, unidentified: int = 0):
    total_objects = sum(len(v) for v in groups.values()) + unidentified
    total_bytes = sum(sizes.get(k, 0) for keys in groups.values() for k in keys)
    unique = len(groups)
    dup_objects = sum(len(v) - 1 for v in groups.values() if len(v) > 1)
    wasted = sum(
        sum(sizes.get(k, 0) for k in keys[1:])
        for keys in groups.values() if len(keys) > 1
    )
    log.info(
        "%-28s | objects=%-5d | unique_contents=%-5d | duplicate_objects=%-5d | total=%.1f MB | wasted_by_dups=%.1f MB%s",
        area, total_objects, unique, dup_objects, total_bytes / 1e6, wasted / 1e6,
        f" | unidentified={unidentified}" if unidentified else "",
    )
    top = sorted(((len(v), fp, v[0]) for fp, v in groups.items() if len(v) > 1), reverse=True)[:5]
    for count, fp, example in top:
        log.info("    x%-3d %s  e.g. %s", count, fp, example.rsplit("/", 1)[-1])


def audit_key_sha(prefix: str, area: str):
    groups: dict = defaultdict(list)
    sizes: dict = {}
    unidentified = 0
    for obj in list_objects(prefix):
        key, size = obj["Key"], int(obj.get("Size") or 0)
        sizes[key] = size
        m = _SHA12_RE.search(key)
        if m:
            groups[m.group(1).lower()].append(key)
        else:
            unidentified += 1
    report(area, groups, sizes, unidentified)


def audit_metadata_sha(prefix: str, area: str):
    groups: dict = defaultdict(list)
    sizes: dict = {}
    unidentified = 0
    heads = 0
    for obj in list_objects(prefix):
        key, size = obj["Key"], int(obj.get("Size") or 0)
        sizes[key] = size
        if heads >= MAX_HEADS:
            unidentified += 1
            continue
        heads += 1
        sha = head_sha(key)
        if sha:
            groups[sha].append(key)
        else:
            unidentified += 1
    report(area, groups, sizes, unidentified)
    if heads >= MAX_HEADS:
        log.info("    (HEAD limit %d reached — raise AUDIT_MAX_HEADS for full coverage)", MAX_HEADS)


def audit_recommendation():
    groups: dict = defaultdict(list)
    sizes: dict = {}
    for obj in list_objects("recommendation/"):
        key, size = obj["Key"], int(obj.get("Size") or 0)
        sizes[key] = size
        fp = key.rsplit("/", 1)[-1].replace(".zip", "")
        groups[fp].append(key)
    report("recommendation/", groups, sizes)


def main():
    log.info("S3 DEDUP AUDIT (read-only) | bucket=%s | APP_ENV=%s", S3_BUCKET, config.APP_ENV)
    audit_key_sha("task-runtime-artifacts/", "task-runtime-artifacts/")
    audit_key_sha("binary-artifacts/", "binary-artifacts/")
    audit_metadata_sha("AI-assited-data/", "AI-assited-data/ (payloads)")
    audit_recommendation()
    audit_metadata_sha("prediction-features/", "prediction-features/")
    log.info("AUDIT done — nothing was modified.")


if __name__ == "__main__":
    main()
