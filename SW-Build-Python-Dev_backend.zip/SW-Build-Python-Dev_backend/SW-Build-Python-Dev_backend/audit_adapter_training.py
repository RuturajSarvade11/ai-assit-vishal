"""Is the adapter REALLY trained, and if not, exactly which gate is blocking it?

The trace says "untrained" and the honest next question is why - because the answer
decides what to do about it. There are four different reasons the state can read "untrained" and
they need completely different responses:

  1. No adapter file has ever been written        -> training has never successfully run
  2. A file exists but does not load              -> corrupt/incompatible blob, retrain
  3. Not enough (error, fix) PAIRS                -> need more uploads that link an error to a fix
  4. Enough pairs, but the gain missed the gate   -> the data is thin, not absent; needs the RIGHT
                                                     kind of data (see CLUSTERS below)

Reason 4 is the one people get wrong. Training pairs are (error vector -> proven fix), and a fix
only becomes a usable training signal once at least FEEDBACK_ADAPTER_MIN_CLUSTER *distinct error
signatures* map to it. So "more uploads" does not necessarily help: what helps is the SAME fix
being applied to several genuinely different errors. This script reports that distribution, so a
backfill can target the gap instead of guessing.

Worth stating plainly because the feature name misleads: the adapter is NOT trained on
thumbs-up/down. Labels come from the stored solution of each request (final_build_payload), not
from votes. Collecting more feedback will not train it.

EMBEDDINGS: the default run makes NO embedding calls. Counting pairs and clustering them needs
only metadata - the label is the request's stored solution, the cluster key is the error
signature. That matters on Azure, where stored vectors are non-retrievable and the training path
has to re-embed the entire collection to reconstruct them: the first real dev run of this script
died with "Embedding request failed after 264728 ms" after three rate-limit retries, having
reported nothing about the data. Vectors are fetched only under --evaluate, which actually trains.

SAFETY: read-only. --evaluate additionally runs a real training evaluation to get the gain number,
but it NEVER promotes - it calls evaluate_and_train (which computes and returns) and never
save_adapter, so the live adapter and the learned space are untouched either way.

    python audit_adapter_training.py               # state + readiness, no embedding calls
    python audit_adapter_training.py --evaluate    # re-embeds and trains to measure the gain
    python audit_adapter_training.py --domain artifact
"""
import argparse
import json
import os
import sys
import time
from collections import Counter

import src.utils.log_setup  # noqa: F401

from src.configurations import config


def _rule(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)


def _fmt_age(mtime):
    if not mtime:
        return "-"
    days = (time.time() - mtime) / 86400.0
    return f"{time.strftime('%Y-%m-%d %H:%M', time.localtime(mtime))} ({days:.1f} days ago)"


def report_files():
    """The weights blob is the ground truth for trained/untrained - is_active() is literally
    'does a W exist and load'."""
    from src.utils import feedback_adapter as fa
    _rule("ADAPTER FILES (the ground truth for trained vs untrained)")
    for domain in ("error", "artifact"):
        try:
            path = fa._domain_path(domain)
        except Exception as exc:
            print(f"  {domain:<9} path unavailable: {exc}")
            continue
        real = path if os.path.exists(path) else (path + ".npy" if os.path.exists(path + ".npy") else "")
        print(f"  {domain:<9} configured path: {path}")
        if not real:
            print(f"  {'':<9} FILE ABSENT - no adapter has ever been promoted for this domain.")
            continue
        stat = os.stat(real)
        print(f"  {'':<9} file: {real}")
        print(f"  {'':<9} size: {stat.st_size} bytes   written: {_fmt_age(stat.st_mtime)}")
        try:
            W, meta = fa.load_adapter(real)
            print(f"  {'':<9} loads OK   shape: {getattr(W, 'shape', '?')}")
            metrics = (meta or {}).get("metrics") or {}
            if metrics:
                # These are the numbers the promotion decision was made on.
                print(f"  {'':<9} trained_at: {(meta or {}).get('trained_at') or '-'}")
                for key in ("gain_top1_pp", "n_fixes", "n_train", "n_heldout"):
                    if key in metrics:
                        print(f"  {'':<9}   {key}: {metrics[key]}")
                for label in ("baseline", "learned"):
                    if label in metrics:
                        print(f"  {'':<9}   {label} top1/top3: {metrics[label]}")
            else:
                print(f"  {'':<9} metadata has no metrics block (written by an older trainer?)")
        except Exception as exc:
            print(f"  {'':<9} FILE PRESENT BUT WILL NOT LOAD: {exc}")
            print(f"  {'':<9} -> this reads as 'untrained' at runtime; retraining is the fix.")


def report_runtime():
    from src.utils import feedback_adapter as fa
    _rule("RUNTIME STATE (what the trace reports)")
    for domain in ("error", "artifact"):
        try:
            active = fa.is_active(domain)
        except Exception as exc:
            print(f"  is_active({domain}) raised: {exc}")
            continue
        print(f"  is_active({domain:<8}) = {active}"
              + ("" if active else "   -> trace shows reason='not_trained'"))

    _rule("LEARNED SPACES (rebuilt on every promotion)")
    for name in (config.FEEDBACK_ADAPTER_LEARNED_COLLECTION,
                 config.FEEDBACK_ADAPTER_ARTIFACT_LEARNED_COLLECTION):
        try:
            from src.services import adapter_trainer  # noqa: F401
            import chromadb
            from src.azure_search.azure_collection import open_collection
            col = open_collection(name, lambda: chromadb.PersistentClient(
                path=config.CHROMA_VECTOR_STORE_PATH).get_or_create_collection(name=name))
            print(f"  {name}: {col.count()} vectors")
        except Exception as exc:
            print(f"  {name}: unavailable ({exc})")


def report_toggles():
    """A trained adapter still does nothing where the per-project switch is off."""
    _rule("PER-PROJECT SWITCH (adapter_enabled_for)")
    try:
        from src.services.adapter_settings import adapter_enabled_for
        from src.utils.project_details import get_all_projects
        names = sorted({str((r or {}).get("project_name") or "").strip().lower()
                        for r in (get_all_projects() or []) if (r or {}).get("project_name")})
        if not names:
            print("  (no projects found)")
        for n in names:
            try:
                print(f"  {n:<30} {'ON' if adapter_enabled_for(n) else 'off'}")
            except Exception as exc:
                print(f"  {n:<30} unknown ({exc})")
    except Exception as exc:
        print(f"  unavailable: {exc}")


def _readiness_from_metadata(domain):
    """Count pairs and cluster them WITHOUT embedding anything.

    First real run on dev: the audit died with "Embedding request failed after 264728 ms".
    On Azure the stored vectors are non-retrievable, so build_dataset re-embeds the WHOLE
    collection to reconstruct them - hundreds of calls, rate-limited, several minutes, and then a
    failure that told us nothing about the data.

    None of that is needed to answer "is there enough training data". The labels come from each
    request's stored solution and the cluster key from the error signature - both are METADATA.
    Vectors are needed only to actually train, so they are fetched only under --evaluate.
    """
    from collections import defaultdict
    from train_feedback_adapter import _solution_signature
    from src.utils.project_details import get_final_build_payload

    if domain == "artifact":
        from src.services.handlers import get_artifact_chroma_collection
        col = get_artifact_chroma_collection()
        sig_field = ("content_sha256", "content_sha12", "s3_key")
    else:
        from src.utils import recommended
        col = recommended.collection
        sig_field = ("error_signature_hash",)

    res = col.get(include=["metadatas"], limit=100000)
    metas = [m for m in (res.get("metadatas") or []) if isinstance(m, dict)]

    payloads, labels, sigs = {}, [], []
    skip = defaultdict(int)
    for m in metas:
        req = str(m.get("request_id") or "").strip()
        if not req:
            skip["no_request_id"] += 1
            continue
        if req not in payloads:
            try:
                payloads[req] = get_final_build_payload(req) or {}
            except Exception:
                payloads[req] = {}
        sig = _solution_signature(payloads[req])
        if not sig:
            skip["no_solution"] += 1
            continue
        labels.append(sig)
        sigs.append(next((str(m.get(f) or "") for f in sig_field if m.get(f)), ""))
    return len(metas), labels, sigs, dict(skip)


def report_data(domain, use_embeddings=False):
    """The heart of it: how many usable training pairs exist, why the rest were dropped, and how
    the fixes cluster - because the cluster filter is what usually starves the trainer."""
    _rule(f"TRAINING DATA READINESS ({domain})")
    X = None
    try:
        if not use_embeddings:
            total, labels, sigs, skip = _readiness_from_metadata(domain)
            print(f"  read {total} stored vectors' METADATA (no embedding calls)")
        elif domain == "artifact":
            from src.services.adapter_trainer import build_artifact_dataset
            X, labels, sigs, skip = build_artifact_dataset()
        else:
            from train_feedback_adapter import build_dataset
            from src.utils import recommended
            X, labels, sigs, skip = build_dataset(col=recommended.collection)
    except Exception as exc:
        print(f"  dataset build FAILED: {exc}")
        if use_embeddings:
            print("  (this path re-embeds the whole collection on Azure and is rate-limited -")
            print("   run without --evaluate for a readiness report that needs no embeddings)")
        return None

    print(f"  usable (error -> fix) pairs: {len(labels)}")
    if skip:
        print("  vectors dropped, by reason:")
        for reason, count in sorted(skip.items(), key=lambda kv: -kv[1]):
            print(f"      {reason:<20} {count}")
        if skip.get("no_solution"):
            print("      ^ 'no_solution' is the BACKFILL TARGET: these errors are stored but their")
            print("        request has no fix payload, so they teach the adapter nothing.")

    # Cluster survival: a fix is only a training signal once MIN_CLUSTER distinct error
    # signatures map to it. This is the gate that silently starves an otherwise healthy dataset.
    min_cluster = config.FEEDBACK_ADAPTER_MIN_CLUSTER
    by_fix = {}
    for lab, es in zip(labels, sigs):
        by_fix.setdefault(lab, set()).add(es)
    sizes = Counter(len(v) for v in by_fix.values())
    survivors = sum(1 for v in by_fix.values() if len(v) >= min_cluster)
    kept_rows = sum(1 for lab in labels if len(by_fix[lab]) >= min_cluster)

    print()
    print(f"  distinct fixes: {len(by_fix)}   cluster gate: >= {min_cluster} distinct error"
          f" signature(s) per fix")
    print("  fixes by how many DISTINCT errors map to them:")
    for size in sorted(sizes):
        marker = "  <- dropped" if size < min_cluster else "  kept"
        print(f"      {size} distinct error(s): {sizes[size]} fix(es){marker}")
    print(f"  fixes surviving the cluster gate: {survivors}")
    print(f"  training rows after the gate:     {kept_rows}   (trainer needs >= 20)")

    if survivors == 0 and len(by_fix):
        near = sizes.get(min_cluster - 1, 0)
        print()
        print(f"  Nothing survives. {near} fix(es) are ONE distinct error short of the gate -")
        print("  those are the cheapest wins: the same fix applied to one more genuinely")
        print("  different error turns each of them into training signal.")
    return {"pairs": len(labels), "kept_rows": kept_rows, "survivors": survivors,
            "X": X, "labels": labels, "sigs": sigs, "by_fix": by_fix}


def report_verdict(data, evaluated):
    _rule("VERDICT: why the adapter is untrained, and what would change it")
    if not data:
        print("  Could not build a dataset - fix the error above first.")
        return
    if data["pairs"] < 20:
        print(f"  BLOCKED at the first gate: {data['pairs']} pairs, trainer needs >= 20.")
        print("  Need more uploads where an error is linked to a stored fix.")
        return
    if data["kept_rows"] < 20:
        print(f"  BLOCKED at the CLUSTER gate: {data['kept_rows']} rows survive, needs >= 20.")
        print(f"  {data['pairs']} pairs exist, so the data is not missing - it is too SCATTERED.")
        print("  Each fix must answer several distinct errors before it counts. More one-off")
        print("  fixes will not help; repeat fixes across different errors will.")
        return
    if evaluated is None:
        print("  Both data gates PASS. The only remaining gate is the accuracy gain.")
        print("  Re-run with --evaluate to measure it (no promotion).")
        return
    if not evaluated.get("ok"):
        print(f"  Training evaluation failed: {evaluated.get('reason')}")
        return
    gate = config.FEEDBACK_ADAPTER_MIN_GAIN_PP
    gain = evaluated.get("gain_top1_pp")
    b, l = evaluated.get("baseline"), evaluated.get("learned")
    print(f"  top-1 before: {b[1] * 100:.1f}%   after: {l[1] * 100:.1f}%   gain: {gain:+.1f}pp"
          f"   gate: >= {gate}pp")
    if l[1] > b[1] and gain >= gate:
        print("  PASSES. A real training run would promote this adapter.")
        print("  Promote with the admin endpoint POST /admin/adapter-train (force not required).")
    else:
        print("  BLOCKED at the GAIN gate: the adapter learned something, but not enough to")
        print("  justify replacing the base ranking. This is the gate doing its job - promoting")
        print("  it anyway would ship a worse ranking than the one in production today.")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--evaluate", action="store_true",
                    help="also run a training EVALUATION to measure the gain (never promotes)")
    ap.add_argument("--domain", choices=["error", "artifact"], default="error")
    ap.add_argument("--json", action="store_true", help="print a machine-readable summary at the end")
    args = ap.parse_args()

    print(f"APP_ENV={config.APP_ENV}   collection={config.CHROMA_COLLECTION_ERROR}")
    report_files()
    report_runtime()
    report_toggles()
    # Readiness never needs vectors; only --evaluate does. Keeping the default embedding-free is
    # what makes this runnable on Azure at all (the embedding path rate-limited out).
    data = report_data(args.domain, use_embeddings=args.evaluate)

    evaluated = None
    if args.evaluate and data and data["kept_rows"] >= 20:
        _rule("TRAINING EVALUATION (measures the gain - does NOT promote)")
        try:
            from src.utils import feedback_adapter as fa
            from train_feedback_adapter import filter_clusters
            Xc, yc, _sizes = filter_clusters(data["X"], data["labels"], data["sigs"],
                                             config.FEEDBACK_ADAPTER_MIN_CLUSTER)
            print(f"  training on {len(yc)} rows ...")
            evaluated, _W = fa.evaluate_and_train(
                Xc, yc, dim_out=(int(os.getenv("AUTO_TRAIN_DIM", "0")) or None), verbose=False)
            print("  done - the weights were NOT saved and the learned space was NOT rebuilt.")
        except Exception as exc:
            print(f"  evaluation failed: {exc}")
    elif args.evaluate:
        _rule("TRAINING EVALUATION")
        print("  Skipped: not enough rows survive the cluster gate to train on.")

    report_verdict(data, evaluated)

    if args.json and data:
        print()
        print(json.dumps({
            "pairs": data["pairs"], "rows_after_cluster_gate": data["kept_rows"],
            "fixes_surviving": data["survivors"],
            "gain_pp": (evaluated or {}).get("gain_top1_pp"),
            "gate_pp": config.FEEDBACK_ADAPTER_MIN_GAIN_PP,
        }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
