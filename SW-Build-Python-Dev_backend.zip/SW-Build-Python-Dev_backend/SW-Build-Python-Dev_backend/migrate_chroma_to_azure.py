"""
migrate_chroma_to_azure.py
==========================
Move every ChromaDB vector collection -> Azure AI Search, production-ready.

For each Chroma collection it:
  1. Creates the Azure index with a real vector schema (HNSW + cosine, hybrid keyword+vector,
     a semantic config, typed filterable fields + a full `metadata_json` so nothing is lost).
  2. Streams all records from Chroma (paginated) and UPSERTS them into Azure in batches with
     retries. Idempotent + resumable (re-run safely). READ-ONLY on Chroma.
  3. Verifies the Azure document count against the Chroma count.

Run in the backend venv (APP_ENV + AZURE_SEARCH_ENDPOINT set), with the azure-search-documents
package installed (`pip install azure-search-documents`):

    python migrate_chroma_to_azure.py                  # all collections
    python migrate_chroma_to_azure.py --only error     # one (error | docs | artifacts)
    python migrate_chroma_to_azure.py --dry-run        # create indexes + count, no upload
    python migrate_chroma_to_azure.py --recreate       # drop + recreate the index first
"""
import os
import re
import sys
import json
import time
import base64
import argparse

import chromadb

from src.configurations.config import (
    CHROMA_VECTOR_STORE_PATH,
    CHROMA_COLLECTION_ERROR,
    CHROMA_COLLECTION_DOCS,
    CHROMA_COLLECTION_ARTIFACTS,
    AZURE_CREDENTIAL,
)
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, SimpleField, SearchableField, SearchField, SearchFieldDataType,
    VectorSearch, HnswAlgorithmConfiguration, HnswParameters, VectorSearchAlgorithmMetric,
    VectorSearchProfile, SemanticConfiguration, SemanticSearch, SemanticPrioritizedFields, SemanticField,
)

ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT", "https://cscspq001aiswbuildq.search.windows.net").rstrip("/")
READ_BATCH = 1000          # records pulled from Chroma per page
UPLOAD_BATCH = 300         # docs per Azure upload call (3072-float vectors are large)
DEFAULT_DIM = 3072         # text-embedding-3-large

COLLECTIONS = {
    "error": CHROMA_COLLECTION_ERROR,
    "docs": CHROMA_COLLECTION_DOCS,
    "artifacts": CHROMA_COLLECTION_ARTIFACTS,
}

# scalar metadata fields we promote to typed, filterable Azure fields (the rest go to metadata_json)
STR_FIELDS = ["project_name", "error_signature_hash", "content_sha256", "content_sha12",
              "task_path", "s3_key", "file_name", "request_id", "batch_id", "vector_id"]
BOOL_FIELDS = ["is_artifact_summary"]
INT_FIELDS = ["summary_total_tokens"]


def to_index_name(collection: str) -> str:
    """Azure index names: lowercase letters/digits/dashes only, no leading/trailing dash.
    error_with_solution -> error-with-solution (underscores are not allowed in index names)."""
    n = collection.strip().lower()
    if re.fullmatch(r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", n):
        return n
    return re.sub(r"-{2,}", "-", re.sub(r"[^a-z0-9]+", "-", n)).strip("-")


def safe_key(chroma_id: str) -> str:
    """Azure key chars = letters/digits/_/-/=. base64url of the id is always valid + unique."""
    return base64.urlsafe_b64encode(str(chroma_id).encode("utf-8")).decode("ascii")


def build_index(dim: int, name: str) -> SearchIndex:
    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SimpleField(name="chroma_id", type=SearchFieldDataType.String, retrievable=True),
        SearchableField(name="document", type=SearchFieldDataType.String),
        SearchField(name="embedding", type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True, vector_search_dimensions=dim, vector_search_profile_name="vprofile"),
        SimpleField(name="metadata_json", type=SearchFieldDataType.String, retrievable=True),
    ]
    for f in STR_FIELDS:
        fields.append(SimpleField(name=f, type=SearchFieldDataType.String, filterable=True, facetable=False))
    for f in BOOL_FIELDS:
        fields.append(SimpleField(name=f, type=SearchFieldDataType.Boolean, filterable=True))
    for f in INT_FIELDS:
        fields.append(SimpleField(name=f, type=SearchFieldDataType.Int64, filterable=True))

    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(
            name="hnsw",
            parameters=HnswParameters(m=4, ef_construction=400, ef_search=500,
                                      metric=VectorSearchAlgorithmMetric.COSINE))],
        profiles=[VectorSearchProfile(name="vprofile", algorithm_configuration_name="hnsw")],
    )
    semantic = SemanticSearch(configurations=[SemanticConfiguration(
        name="semantic",
        prioritized_fields=SemanticPrioritizedFields(content_fields=[SemanticField(field_name="document")]))])
    return SearchIndex(name=name, fields=fields, vector_search=vector_search, semantic_search=semantic)


def ensure_index(index_client: SearchIndexClient, name: str, dim: int, recreate: bool):
    existing = {i.name for i in index_client.list_indexes()}
    if name in existing and recreate:
        print(f"  dropping existing index '{name}' (--recreate)")
        index_client.delete_index(name)
        existing.discard(name)
    if name not in existing:
        index_client.create_index(build_index(dim, name))
        print(f"  created index '{name}' (vector dim={dim}, HNSW/cosine, hybrid + semantic)")
    else:
        # keep schema in sync (additive). create_or_update is safe for new fields.
        index_client.create_or_update_index(build_index(dim, name))
        print(f"  index '{name}' already exists (schema ensured)")


def to_azure_doc(cid, emb, doc, meta):
    meta = meta if isinstance(meta, dict) else {}
    out = {
        "id": safe_key(cid),
        "chroma_id": str(cid),
        "document": str(doc or meta.get("document") or ""),
        "embedding": [float(x) for x in emb] if emb is not None else [],
        "metadata_json": json.dumps(meta, ensure_ascii=False, default=str),
    }
    for f in STR_FIELDS:
        v = meta.get(f)
        out[f] = "" if v is None else str(v)
    for f in BOOL_FIELDS:
        out[f] = bool(meta.get(f))
    for f in INT_FIELDS:
        try:
            out[f] = int(meta.get(f) or 0)
        except Exception:
            out[f] = 0
    return out


def upload_with_retry(search_client: SearchClient, batch, attempts=4):
    for i in range(attempts):
        try:
            res = search_client.upload_documents(batch)
            failed = [r for r in res if not r.succeeded]
            if failed:
                raise RuntimeError(f"{len(failed)} doc(s) failed, e.g. {failed[0].key}: {failed[0].error_message}")
            return len(batch)
        except Exception as e:
            if i == attempts - 1:
                raise
            wait = 2 ** i
            print(f"    upload retry {i+1}/{attempts} after error: {e} (waiting {wait}s)")
            time.sleep(wait)


def migrate_one(key: str, collection_name: str, chroma_client, index_client, recreate: bool, dry_run: bool):
    print(f"\n=== {key}  (chroma '{collection_name}') ===")
    try:
        col = chroma_client.get_collection(name=collection_name)
    except Exception as e:
        print(f"  SKIP: collection not found ({e})")
        return
    total = col.count()
    print(f"  chroma records: {total}")
    if total == 0:
        print("  nothing to migrate.")
        return

    # detect embedding dimension from the first record (Chroma returns embeddings as numpy arrays,
    # so use explicit None/len checks — `array or []` raises the ambiguous-truth-value error)
    head = col.get(include=["embeddings"], limit=1)
    embs0 = head.get("embeddings")
    dim = len(embs0[0]) if embs0 is not None and len(embs0) > 0 else DEFAULT_DIM
    index_name = to_index_name(collection_name)
    print(f"  -> azure index '{index_name}' (dim={dim})")
    ensure_index(index_client, index_name, dim, recreate)
    if dry_run:
        print("  dry-run: index ensured, no documents uploaded.")
        return

    search_client = SearchClient(endpoint=ENDPOINT, index_name=index_name, credential=AZURE_CREDENTIAL)
    sent, t0 = 0, time.time()
    for offset in range(0, total, READ_BATCH):
        page = col.get(include=["embeddings", "documents", "metadatas"], limit=READ_BATCH, offset=offset)
        ids = page.get("ids") or []
        embs = page.get("embeddings")
        embs = embs if embs is not None else []
        docs = page.get("documents") or []
        metas = page.get("metadatas") or []
        azure_docs = [to_azure_doc(ids[i], embs[i] if i < len(embs) else None,
                                   docs[i] if i < len(docs) else "", metas[i] if i < len(metas) else {})
                      for i in range(len(ids))]
        for b in range(0, len(azure_docs), UPLOAD_BATCH):
            sent += upload_with_retry(search_client, azure_docs[b:b + UPLOAD_BATCH])
        print(f"    {sent}/{total} uploaded...")

    time.sleep(3)  # let indexing settle before counting
    try:
        azure_count = search_client.get_document_count()
    except Exception:
        azure_count = -1
    flag = "OK" if azure_count >= total else "VERIFY"
    print(f"  done in {time.time()-t0:.1f}s | chroma={total} azure={azure_count} [{flag}]")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=list(COLLECTIONS), help="migrate a single collection")
    ap.add_argument("--dry-run", action="store_true", help="create indexes + count, no upload")
    ap.add_argument("--recreate", action="store_true", help="drop + recreate each index first")
    args = ap.parse_args()

    print("=" * 64)
    print("  ChromaDB -> Azure AI Search migration")
    print(f"  Endpoint    : {ENDPOINT}")
    print(f"  Chroma path : {CHROMA_VECTOR_STORE_PATH}")
    print("  Index names :", {k: to_index_name(v) for k, v in COLLECTIONS.items()})
    print("=" * 64)

    chroma_client = chromadb.PersistentClient(path=CHROMA_VECTOR_STORE_PATH)
    index_client = SearchIndexClient(endpoint=ENDPOINT, credential=AZURE_CREDENTIAL)

    todo = {args.only: COLLECTIONS[args.only]} if args.only else COLLECTIONS
    for key, coll in todo.items():
        try:
            migrate_one(key, coll, chroma_client, index_client, args.recreate, args.dry_run)
        except Exception as e:
            print(f"  ERROR migrating {key}: {type(e).__name__}: {e}")

    print("\nMigration finished.")


if __name__ == "__main__":
    main()
