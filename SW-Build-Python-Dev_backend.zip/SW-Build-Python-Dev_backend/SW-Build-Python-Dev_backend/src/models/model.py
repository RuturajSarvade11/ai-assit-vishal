import logging
import os

import src.utils.log_setup  # noqa: F401
from src.databases.database import get_dynamodb
from src.configurations import config
from botocore.exceptions import BotoCoreError, ClientError
from urllib3.exceptions import ConnectTimeoutError

logger = logging.getLogger(__name__)

dynamodb = get_dynamodb()

TABLE_DEFINITIONS = [
    {
        "TableName": "ai_assisted_data",
        "KeySchema": [
            {"AttributeName": "PK", "KeyType": "HASH"},
            {"AttributeName": "SK", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "PK", "AttributeType": "S"},
            {"AttributeName": "SK", "AttributeType": "S"},
        ],
        "BillingMode": "PAY_PER_REQUEST",
    },
    {
        "TableName": "final_build_payload",
        "KeySchema": [{"AttributeName": "request_id", "KeyType": "HASH"}],
        "AttributeDefinitions": [{"AttributeName": "request_id", "AttributeType": "S"}],
        "BillingMode": "PAY_PER_REQUEST",
    },
]

def ensure_tables():
    """
    Ensures DynamoDB tables exist. Returns True if successful, False if DynamoDB is unavailable.
    Raises exception if DYNAMODB_REQUIRED=1 and connection fails.
    """
    dynamodb_required = os.getenv("DYNAMODB_REQUIRED", "0").strip().lower() in {"1", "true", "yes"}
    suffix = config.DYNAMODB_TABLE_SUFFIX
    
    try:
        existing = dynamodb.meta.client.list_tables()["TableNames"]
        logger.debug("DynamoDB ensure_tables | existing_tables=%s | suffix=%s", existing, suffix)
        for table_def in TABLE_DEFINITIONS:
            base_name = table_def["TableName"]
            table_name = base_name + suffix
            
            if table_name not in existing:
                logger.debug("DynamoDB creating table | table_name=%s", table_name)
                # Create a copy of the table definition with the suffixed name
                table_config = dict(table_def)
                table_config["TableName"] = table_name
                dynamodb.create_table(**table_config)
                logger.info("DynamoDB table created | table_name=%s", table_name)
            else:
                logger.debug("DynamoDB table already exists, skipping | table_name=%s", table_name)
        return True
    except (ConnectTimeoutError, BotoCoreError, ClientError, Exception) as e:
        error_msg = str(e)
        if "timed out" in error_msg.lower() or "connection" in error_msg.lower():
            logger.warning(
                "DynamoDB connection failed (timeout or connection error). "
                "Ensure DynamoDB Local is running on localhost:8000 or update DYNAMODB_ENDPOINT. "
                "Error: %s",
                error_msg[:200]
            )
        else:
            logger.warning("DynamoDB operation failed | error=%s", error_msg[:200])
        
        if dynamodb_required:
            logger.error("DynamoDB is required (DYNAMODB_REQUIRED=1) but unavailable. Exiting.")
            raise
        else:
            logger.warning(
                "DynamoDB unavailable but not required (DYNAMODB_REQUIRED=0). "
                "App will start without DynamoDB functionality. Set DYNAMODB_REQUIRED=1 if this should fail."
            )
            return False
