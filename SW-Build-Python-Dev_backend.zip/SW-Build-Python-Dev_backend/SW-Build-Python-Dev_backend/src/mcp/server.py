import asyncio
import glob
import json
import logging
import os
from pathlib import Path
import random
import re
import sys
import time
import uuid
from typing import Any, Optional

import requests
from requests import exceptions as req_exc
from fastmcp import FastMCP
from src.configurations import config

import src.utils.log_setup  # noqa: F401
logger = logging.getLogger("app.mcp")

mcp = FastMCP("powershell-local")


def _dbg(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def _default_powershell_exe() -> str:
    return os.environ.get("POWERSHELL_EXE") or ("powershell.exe" if os.name == "nt" else "pwsh")


def _is_allowed(script: str) -> bool:
    s = script.strip()
    deny_substrings = [
        "remove-item", "rm ", "del ", "rmdir", "format-volume",
        "start-process", "invoke-webrequest", "iwr ", "curl ",
        "set-mppreference", "reg add", "new-localuser", "add-localgroupmember",
    ]
    low = s.lower()
    if any(x in low for x in deny_substrings):
        return False

    allowed_prefixes = ("get-", "test-", "resolve-", "write-output", "echo", "dir", "gci")
    return low.startswith(allowed_prefixes)


async def _run_powershell(script: str, cwd: Optional[str] = None, timeout_ms: int = 30_000) -> dict:
    if not _is_allowed(script):
        return {"ok": False, "blocked": True, "reason": "Blocked by allowlist"}

    exe = _default_powershell_exe()
    workdir = os.path.abspath(cwd) if cwd else os.getcwd()

    proc = await asyncio.create_subprocess_exec(
        exe, "-NoProfile", "-NonInteractive", "-Command", script,
        cwd=workdir,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout_ms / 1000)
        timed_out = False
    except asyncio.TimeoutError:
        timed_out = True
        proc.kill()
        stdout_b, stderr_b = await proc.communicate()

    return {
        "ok": (not timed_out) and (proc.returncode == 0),
        "blocked": False,
        "timedOut": timed_out,
        "exitCode": proc.returncode,
        "cwd": workdir,
        "exe": exe,
        "stdout": stdout_b.decode(errors="replace"),
        "stderr": stderr_b.decode(errors="replace"),
    }


@mcp.tool()
async def run_powershell(script: str, cwd: Optional[str] = None, timeout_ms: int = 30_000) -> dict:
    """
    Execute an allow-listed PowerShell command and return structured execution output.
    """
    # IMPORTANT: don't print to stdout (even though HTTP is safer, keep clean)
    print("script to run:", repr(script), file=sys.stderr, flush=True)
    return await _run_powershell(script=script, cwd=cwd, timeout_ms=timeout_ms)


BACKEND_BASE_URL = (
    os.environ.get("BACKEND_BASE_URL")
    or os.environ.get("BACKEND_PUBLIC_BASE_URL")
    or str(config.BACKEND_PUBLIC_BASE_URL or "").strip()
).rstrip("/")
if not BACKEND_BASE_URL:
    raise RuntimeError(
        "BACKEND_BASE_URL is not configured. Set BACKEND_BASE_URL or BACKEND_PUBLIC_BASE_URL."
    )
_dbg(f"[mcp] BACKEND_BASE_URL={BACKEND_BASE_URL}")

_fallback_default = os.environ.get("BACKEND_FALLBACK_URL", str(config.BACKEND_PUBLIC_BASE_URL or "").strip()).rstrip("/")
_base_urls = [BACKEND_BASE_URL]
if _fallback_default and _fallback_default not in _base_urls:
    _base_urls.append(_fallback_default)
_dbg(f"[mcp] BACKEND_BASE_URLS={_base_urls}")
_RETRYABLE_HTTP_STATUSES = {429, 502, 503, 504}
_MAX_ATTEMPTS = max(1, int(os.environ.get("MCP_HTTP_MAX_ATTEMPTS", "3")))
_BACKOFF_BASE_SEC = max(0.1, float(os.environ.get("MCP_HTTP_BACKOFF_BASE_SEC", "0.6")))
_BACKOFF_CAP_SEC = max(_BACKOFF_BASE_SEC, float(os.environ.get("MCP_HTTP_BACKOFF_CAP_SEC", "6.0")))
_CB_FAILURE_THRESHOLD = max(1, int(os.environ.get("MCP_HTTP_CB_FAILURE_THRESHOLD", "3")))
_CB_COOLDOWN_SEC = max(1, int(os.environ.get("MCP_HTTP_CB_COOLDOWN_SEC", "45")))
_DEFAULT_CONNECT_TIMEOUT_SEC = max(3, int(os.environ.get("MCP_HTTP_CONNECT_TIMEOUT_SEC", "10")))
_default_read_timeout = max(5, int(os.environ.get("MCP_HTTP_READ_TIMEOUT_SEC", "30")))
_DEFAULT_READ_TIMEOUTS_BY_PATH = {
    "/report-errors": max(30, int(os.environ.get("MCP_TIMEOUT_REPORT_ERRORS_SEC", "180"))),
    "/copilot/session/touch": max(15, int(os.environ.get("MCP_TIMEOUT_SESSION_TOUCH_SEC", "45"))),
    "/copilot/session/recommendations/current": max(20, int(os.environ.get("MCP_TIMEOUT_RECOMMEND_SEC", "75"))),
    "/copilot/recommendations/by-uuid": max(20, int(os.environ.get("MCP_TIMEOUT_RECOMMEND_UUID_SEC", "75"))),
}
_url_health: dict[str, dict[str, float]] = {
    b: {"failures": 0.0, "open_until": 0.0} for b in _base_urls
}


def _resolve_mcp_project_name(project_name: str | None = None) -> str:
    return (project_name or "").strip().lower()


def _resolve_mcp_client_id(client_id: str | None = None) -> str:
    return (client_id or "").strip()


def _infer_project_name_from_path(path_hint: str) -> str:
    normalized = str(path_hint or "").replace("\\", "/")
    match = re.search(r"(sw-prj-[A-Za-z0-9._-]+)", normalized, re.IGNORECASE)
    return (match.group(1) if match else "").strip().lower()


def _current_mcp_actor_id(actor_id: str | None = None) -> str:
    return (actor_id or "").strip() or "global"


def _get_read_timeout(path: str, timeout_sec: int) -> int:
    if int(timeout_sec) > 0:
        return int(timeout_sec)
    normalized = "/" + path.lstrip("/")
    return int(_DEFAULT_READ_TIMEOUTS_BY_PATH.get(normalized, _default_read_timeout))


def _rewind_files(files: Optional[dict]) -> None:
    if not isinstance(files, dict):
        return
    for value in files.values():
        file_obj = None
        if isinstance(value, tuple) and len(value) >= 2:
            file_obj = value[1]
        elif hasattr(value, "read"):
            file_obj = value
        if file_obj and hasattr(file_obj, "seek"):
            try:
                file_obj.seek(0)
            except Exception:
                pass


def _record_success(base: str) -> None:
    state = _url_health.setdefault(base, {"failures": 0.0, "open_until": 0.0})
    state["failures"] = 0.0
    state["open_until"] = 0.0
    if _base_urls and _base_urls[0] != base:
        _base_urls[:] = [base] + [b for b in _base_urls if b != base]
        _dbg(f"[mcp] switched preferred backend to {base}")


def _record_failure(base: str) -> None:
    state = _url_health.setdefault(base, {"failures": 0.0, "open_until": 0.0})
    state["failures"] = float(state.get("failures", 0.0)) + 1.0
    if int(state["failures"]) >= _CB_FAILURE_THRESHOLD:
        state["open_until"] = time.monotonic() + _CB_COOLDOWN_SEC
        state["failures"] = 0.0
        _dbg(f"[mcp] circuit open for {base} ({_CB_COOLDOWN_SEC}s)")


def _available_bases() -> list[str]:
    now = time.monotonic()
    preferred = [b for b in _base_urls if float(_url_health.get(b, {}).get("open_until", 0.0)) <= now]
    return preferred or list(_base_urls)


async def _sleep_backoff(attempt: int) -> None:
    delay = min(_BACKOFF_CAP_SEC, _BACKOFF_BASE_SEC * (2 ** max(0, attempt - 1)))
    jitter = random.uniform(0.0, min(0.35, delay * 0.3))
    await asyncio.sleep(delay + jitter)


async def _request_with_fallback(
    method: str,
    path: str,
    *,
    timeout_sec: int,
    params: Optional[dict] = None,
    json_body: Optional[dict] = None,
    files: Optional[dict] = None,
    data: Optional[dict] = None,
) -> tuple[requests.Response, str]:
    last_err: Optional[Exception] = None
    read_timeout = _get_read_timeout(path, timeout_sec)
    last_resp: Optional[requests.Response] = None
    last_base: Optional[str] = None

    for attempt in range(1, _MAX_ATTEMPTS + 1):
        for base in _available_bases():
            url = f"{base}/{path.lstrip('/')}"
            try:
                _rewind_files(files)
                resp = await asyncio.to_thread(
                    requests.request,
                    method,
                    url,
                    params=params,
                    json=json_body,
                    files=files,
                    data=data,
                    timeout=(_DEFAULT_CONNECT_TIMEOUT_SEC, max(5, int(read_timeout))),
                )
                if resp.status_code in _RETRYABLE_HTTP_STATUSES:
                    last_resp = resp
                    last_base = base
                    _record_failure(base)
                    _dbg(
                        f"[mcp] retryable status {resp.status_code} for {url} "
                        f"(attempt {attempt}/{_MAX_ATTEMPTS})"
                    )
                    continue
                _record_success(base)
                return resp, base
            except (req_exc.Timeout, req_exc.ConnectionError, req_exc.SSLError) as exc:
                last_err = exc
                _record_failure(base)
                _dbg(
                    f"[mcp] request failed for {url} (attempt {attempt}/{_MAX_ATTEMPTS}): {exc!r}"
                )
                continue
        if attempt < _MAX_ATTEMPTS:
            await _sleep_backoff(attempt)

    if last_resp is not None and last_base is not None:
        return last_resp, last_base
    if last_err is not None:
        raise last_err
    raise RuntimeError("No backend base URLs configured")


def _find_report_file(base_path: str) -> str | None:
    # If caller passed file path directly.
    if os.path.isfile(base_path) and os.path.basename(base_path).lower().endswith(".html"):
        return base_path

    # 1) Exact report.html in workspace root
    p1 = os.path.join(base_path, "report.html")
    if os.path.isfile(p1):
        return p1

    # 2) Build folder dynamic path: build/**/report.html
    build_candidates = glob.glob(
        os.path.join(base_path, "build", "**", "report.html"),
        recursive=True,
    )
    if build_candidates:
        build_candidates.sort(key=lambda p: os.path.getmtime(p), reverse=True)
        return build_candidates[0]

    # 3) Fallback: newest report*.html in workspace
    candidates = glob.glob(os.path.join(base_path, "**", "report*.html"), recursive=True)
    if not candidates:
        return None
    candidates.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return candidates[0]


def _extract_error_from_report_html(html: str) -> str:
    match = re.search(
        r"// begin-report-data\s*(\{.*?\})\s*// end-report-data",
        html,
        re.DOTALL,
    )
    if not match:
        return ""
    try:
        report_data = json.loads(match.group(1))
    except Exception:
        return ""
    diagnostics = report_data.get("diagnostics") if isinstance(report_data, dict) else None
    if not isinstance(diagnostics, list):
        return ""
    messages: list[str] = []
    for item in diagnostics:
        if not isinstance(item, dict):
            continue
        severity = str(item.get("severity") or "").strip().upper()
        if severity and severity != "ERROR":
            continue
        message = str(item.get("problemDetails") or item.get("message") or "").strip()
        if message:
            messages.append(message)
    return "\n".join(messages[:3]).strip()


def _format_recommendation_rows(project_name: str, rows: list[dict[str, Any]]) -> str:
    if not rows:
        return f"No strong historical recommendation found for current error in {project_name}."
    lines = [f"Current error recommendation for {project_name}", ""]
    for idx, row in enumerate(rows[:2], start=1):
        request_id = str(row.get("request_id") or "").strip() or "N/A"
        diff_link = str(row.get("compare_diff_link") or "").strip()
        solution = row.get("solution")
        lines.append(f"{idx}. request_id={request_id}")
        if diff_link:
            lines.append(f"   diff={diff_link}")
        if isinstance(solution, list) and solution:
            lines.append(f"   solution={json.dumps(solution)}")
        lines.append("")
    return "\n".join(lines).strip()


def _resolve_local_workspace_context(
    project_name: str | None = None,
    client_id: str | None = None,
) -> dict[str, str]:
    resolved_project = (
        (project_name or "").strip().lower()
        or str(os.environ.get("MCP_PROJECT_NAME") or "").strip().lower()
    )
    resolved_client = (
        (client_id or "").strip()
        or str(os.environ.get("MCP_CLIENT_ID") or "").strip()
    )
    resolved_workspace_id = str(os.environ.get("MCP_WORKSPACE_ID") or "").strip()
    resolved_workspace = str(os.environ.get("MCP_WORKSPACE_PATH") or "").strip()
    resolved_error = str(os.environ.get("MCP_CURRENT_ERROR") or "").strip()
    return {
        "project_name": resolved_project,
        "client_id": resolved_client,
        "workspace_id": resolved_workspace_id,
        "workspace": resolved_workspace,
        "error_message": resolved_error,
    }


async def _get_current_workspace_recommendation(
    *,
    project_name: str,
    workspace_path: str,
    timeout_sec: int,
    query_text: str = "",
    doc_top_k: int = 5,
) -> dict[str, Any]:
    report_path = _find_report_file(workspace_path) if workspace_path else None
    if report_path and os.path.exists(report_path):
        with open(report_path, "rb") as f:
            files = {"file": ("report.html", f, "text/html")}
            data = {
                "project_name": project_name,
                "query_text": (query_text or "").strip(),
                "doc_top_k": str(doc_top_k),
            }
            resp, used_base = await _request_with_fallback(
                "POST",
                "/report-errors",
                timeout_sec=timeout_sec,
                files=files,
                data=data,
            )
        resp.raise_for_status()
        payload = resp.json()
        logger.debug(
            "_get_current_workspace_recommendation | /report-errors response | "
            "status=%d | response_type=%s | project_name=%s | report_path=%s",
            resp.status_code,
            type(payload).__name__,
            project_name,
            report_path,
        )
        # /report-errors now returns {"recommendations": [...], "llm_analysis": "..."}.
        # Support the legacy plain-list shape for backward compatibility.
        if isinstance(payload, list):
            logger.debug(
                "_get_current_workspace_recommendation | legacy list response detected | "
                "rows_count=%d | project_name=%s",
                len(payload),
                project_name,
            )
            rows = payload
            llm_analysis = ""
            document_context = {
                "success": False,
                "message": "document context not available in legacy response",
                "query": (query_text or "").strip(),
                "project_name": project_name,
                "count": 0,
                "results": [],
            }
            context_enrichment = {
                "enabled": False,
                "query": (query_text or "").strip(),
                "semantic_results_used": 0,
                "artifact_results_used": 0,
                "refined_context": {
                    "issue_summary": "",
                    "contextual_findings": [],
                    "recommended_actions": [],
                    "possible_resolutions": [],
                    "caveats": [],
                },
            }
        elif isinstance(payload, dict):
            rows = payload.get("recommendations", [])
            if not isinstance(rows, list):
                rows = []
            llm_analysis = str(payload.get("llm_analysis") or "")
            document_context = payload.get("document_context")
            if not isinstance(document_context, dict):
                document_context = {
                    "success": False,
                    "message": "document context missing in backend response",
                    "query": (query_text or "").strip(),
                    "project_name": project_name,
                    "count": 0,
                    "results": [],
                }
            context_enrichment = payload.get("context_enrichment")
            if not isinstance(context_enrichment, dict):
                context_enrichment = {
                    "enabled": False,
                    "query": (query_text or "").strip(),
                    "semantic_results_used": 0,
                    "artifact_results_used": 0,
                    "refined_context": {
                        "issue_summary": "",
                        "contextual_findings": [],
                        "recommended_actions": [],
                        "possible_resolutions": [],
                        "caveats": [],
                    },
                }
            logger.debug(
                "_get_current_workspace_recommendation | dict response | "
                "rows_count=%d | llm_analysis_present=%s | llm_analysis_chars=%d | project_name=%s | doc_count=%d",
                len(rows),
                bool(llm_analysis),
                len(llm_analysis),
                project_name,
                len(document_context.get("results") or []) if isinstance(document_context, dict) else 0,
            )
        else:
            logger.debug(
                "_get_current_workspace_recommendation | unexpected response type=%s | project_name=%s",
                type(payload).__name__,
                project_name,
            )
            rows = []
            llm_analysis = ""
            document_context = {
                "success": False,
                "message": "unexpected backend response shape",
                "query": (query_text or "").strip(),
                "project_name": project_name,
                "count": 0,
                "results": [],
            }
            context_enrichment = {
                "enabled": False,
                "query": (query_text or "").strip(),
                "semantic_results_used": 0,
                "artifact_results_used": 0,
                "refined_context": {
                    "issue_summary": "",
                    "contextual_findings": [],
                    "recommended_actions": [],
                    "possible_resolutions": [],
                    "caveats": [],
                },
            }
        return {
            "status": "success",
            "rows": rows,
            "llm_analysis": llm_analysis,
            "document_context": document_context,
            "context_enrichment": context_enrichment,
            "source": "report",
            "report_path": report_path,
            "backend_base_url": used_base,
            "formatted_output": json.dumps(rows, indent=2),
        }

    return {
        "status": "error",
        "error": "current workspace report.html is not available",
        "rows": [],
    }


@mcp.tool()
async def get_report_json() -> dict:
   
        """
        Calls https://jsonplaceholder.typicode.com/todos/1
        and returns the JSON response exactly as received.
       
        """
 
        resp = requests.get("https://jsonplaceholder.typicode.com/todos/1")
        data = resp.json()
        print("Fetched report data:", repr(data), file=sys.stderr, flush=True)
        return data


@mcp.tool()
async def get_report(
    workspace_path: str,
    report_path: str | None = None,
    timeout_sec: int = 180,
) -> dict[str, Any]:
    """
    Upload report.html to /report-errors and return API JSON exactly as received.

    Input:
    - workspace_path: workspace root or path hint.
    - report_path: optional explicit path to report.html.
    - timeout_sec: API read timeout seconds.

    Output:
    - On success: backend JSON response (verbatim structure).
    - On failure: {"status":"error","error":"..."}.
    """

    _dbg("[get_report] called")
    _dbg(f"[get_report] workspace_path raw={workspace_path!r}")
    _dbg(f"[get_report] report_path raw={report_path!r}")
    _dbg(f"[get_report] timeout_sec={timeout_sec!r}")
    raw_workspace = (workspace_path or "").strip().strip('"').strip("'")
    raw_report = (report_path or "").strip().strip('"').strip("'")
    _dbg(f"[get_report] workspace_path normalized={raw_workspace!r}")
    _dbg(f"[get_report] report_path normalized={raw_report!r}")

    primary = os.path.abspath(raw_workspace) if raw_workspace else os.getcwd()
    chosen_base = primary
    _dbg(f"[get_report] primary base={primary!r}")
    if not os.path.isdir(primary):
        _dbg("[get_report] workspace_path is not a valid directory")
        return {
            "status": "error",
            "error": f"workspace_path not found: {primary}",
            "workspace_path": primary,
        }

    # If explicit report path is provided, trust it first.
    resolved_report_path: str | None = None
    if raw_report:
        resolved_report_path = os.path.abspath(raw_report)
        _dbg(f"[get_report] explicit report_path absolute={resolved_report_path!r}")
        if not os.path.isfile(resolved_report_path):
            # Handle report_path given relative to workspace_path.
            joined = os.path.abspath(os.path.join(primary, raw_report))
            _dbg(f"[get_report] explicit path missing, trying relative join={joined!r}")
            if os.path.isfile(joined):
                resolved_report_path = joined
                _dbg(f"[get_report] found report via joined path={resolved_report_path!r}")
            else:
                resolved_report_path = None
                _dbg("[get_report] explicit report_path not found")
                return {
                    "status": "error",
                    "error": f"explicit report_path not found: {raw_report}",
                    "workspace_path": primary,
                    "report_path": raw_report,
                }

    # If explicit report path is not provided, run discovery only inside workspace_path.
    if not resolved_report_path:
        _dbg("[get_report] running dynamic discovery")
        candidate_bases = [primary]
        _dbg(f"[get_report] candidate bases={candidate_bases!r}")

        for base in candidate_bases:
            _dbg(f"[get_report] searching base={base!r}")
            found = _find_report_file(base)
            if found:
                resolved_report_path = found
                chosen_base = base
                _dbg(f"[get_report] found report={resolved_report_path!r} via base={chosen_base!r}")
                break

    if not resolved_report_path or not os.path.exists(resolved_report_path):
        _dbg("[get_report] report not found after discovery")
        return {
            "status": "error",
            "error": "report.html not found",
            "workspace_path": primary,
            "report_path": raw_report or None,
        }

    project_name = (
        _infer_project_name_from_path(resolved_report_path)
        or _infer_project_name_from_path(primary)
        or (os.environ.get("MCP_PROJECT_NAME") or "").strip().lower()
    )
    if not project_name:
        return {
            "status": "error",
            "error": "project_name could not be resolved from workspace/report path",
            "workspace_path": primary,
            "report_path": resolved_report_path,
        }
    _dbg(f"[get_report] project_name={project_name!r}")
    _dbg(f"[get_report] final report path={resolved_report_path!r}")

    try:
        _dbg("[get_report] opening report file and preparing multipart request")
        with open(resolved_report_path, "rb") as f:
            files = {"file": ("report.html", f, "text/html")}
            data = {"project_name": project_name}

            _dbg(f"[get_report] calling /report-errors with fallback timeout={timeout_sec!r}")
            resp, used_base = await _request_with_fallback(
                "POST",
                "/report-errors",
                timeout_sec=timeout_sec,
                files=files,
                data=data,
            )

        _dbg(f"[get_report] API status={resp.status_code}")
        resp.raise_for_status()
        payload = resp.json()
        if isinstance(payload, dict):
            payload["backend_base_url"] = used_base
        _dbg("[get_report] API JSON parsed successfully")
        return payload

    except Exception as e:
        _dbg(f"[get_report] failed with error={e!r}")
        return {
            "status": "error",
            "error": f"API call failed: {e}",
            "report_path": resolved_report_path,
            "project_name": project_name,
        }


@mcp.tool()
async def get_error_from_report() -> str:
    """
    Extracts full ERROR problemDetails text from report.html
    in current working directory.
    Returns only the complete error detail.
    """

    report_path = os.path.join(os.getcwd(), "report.html")

    if not os.path.exists(report_path):
        return "report.html not found"

    with open(report_path, "r", encoding="utf-8") as f:
        content = f.read()

    match = re.search(
        r"// begin-report-data\s*(\{.*?\})\s*// end-report-data",
        content,
        re.DOTALL,
    )

    if not match:
        return "Report JSON not found"

    data = json.loads(match.group(1))

    for item in data.get("diagnostics", []):
        if item.get("severity") == "ERROR":
            details = item.get("problemDetails", [])
            if details:
                # Return FULL text exactly as in report
                print("Extracted ERROR problemDetails:", repr(details[0].get("text", "").strip()), file=sys.stderr, flush=True)
                return details[0].get("text", "").strip()

    return "No ERROR found"


@mcp.tool()
async def copilot_session_touch(
    error_message: str,
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    uuid: str | None = None,
    timeout_sec: int = 30,
) -> dict:
    resolved_project = _resolve_mcp_project_name(project_name)
    resolved_client = _resolve_mcp_client_id(client_id)
    resolved_actor = actor_id or "global"
    payload = {
        "project_name": resolved_project,
        "error_message": error_message or "",
        "client_id": resolved_client,
        "actor_id": resolved_actor,
    }
    if uuid:
        payload["uuid"] = uuid

    resp, used_base = await _request_with_fallback(
        "POST",
        "/copilot/session/touch",
        timeout_sec=timeout_sec,
        json_body=payload,
    )
    resp.raise_for_status()
    out = resp.json()
    if isinstance(out, dict):
        out["backend_base_url"] = used_base
    return out


@mcp.tool()
async def copilot_session_active(
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    timeout_sec: int = 30,
) -> dict:
    """
    Use this tool when the user asks to check the current Copilot/build-error session,
    current active error, current workspace error, or whether a current error session exists.
    This tool only reports current session status and current error text.
    Do not use this tool to generate a solution or recommendation.
    """
    context = _resolve_local_workspace_context(project_name=project_name, client_id=client_id)
    resolved_project = context.get("project_name", "")
    resolved_client = context.get("client_id", "")
    workspace_path = context.get("workspace", "")
    report_path = _find_report_file(workspace_path) if workspace_path else None
    current_error = context.get("error_message", "")

    if report_path and os.path.exists(report_path):
        try:
            current_error = _extract_error_from_report_html(
                Path(report_path).read_text(encoding="utf-8", errors="replace")
            ) or current_error
        except Exception:
            pass

    if not resolved_client or not context.get("workspace_id"):
        return {
            "status": False,
            "session": None,
            "response_mode": "render_only",
            "render_instruction": "Do not guess another machine's active session. Show the message exactly as provided.",
            "display_markdown": "Current workspace identity is not available for MCP session lookup. Make sure the extension has synced this workspace once.",
        }
    display_lines = [
        f"Session status: {'active' if current_error.strip() else 'inactive'}",
        f"Project: {resolved_project or 'N/A'}",
        f"Workspace: {workspace_path or 'N/A'}",
        f"Current error: {current_error or 'N/A'}",
    ]
    return {
        "status": bool(current_error.strip()),
        "session": {
            "project_name": resolved_project or None,
            "client_id": resolved_client or None,
            "workspace_id": context.get("workspace_id") or None,
            "workspace": workspace_path or None,
            "error_message": current_error or "",
            "report_path": report_path or None,
        },
        "response_mode": "render_only",
        "render_instruction": "Show only session status and current error. Do not provide solution suggestions.",
        "display_markdown": "\n".join(display_lines),
    }


@mcp.tool()
async def copilot_recommend_active(
    query_text: str | None = None,
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    doc_top_k: int = 5,
    timeout_sec: int = 60,
) -> dict:
    """
    Use this tool when the user asks for:
    - recommendation for current error
    - solution for this error
    - how to solve this issue
    - fix for current build failure
    - suggestion for current active error

    Always fetch the latest backend recommendation for the current active error session.
    Do not answer from previous chat memory when this tool applies.
    Copilot should print `display_markdown` exactly as-is with no added explanation.
    """
    context = _resolve_local_workspace_context(project_name=project_name, client_id=client_id)
    resolved_project = context.get("project_name", "")
    resolved_client = context.get("client_id", "")
    resolved_workspace = context.get("workspace_id", "")
    workspace_path = context.get("workspace", "")

    if not resolved_client or not resolved_workspace:
        return {
            "status": "error",
            "error": "current workspace identity is not available for MCP recommendation lookup",
            "display_markdown": "Current workspace identity is not available for MCP recommendation lookup. Make sure the extension has synced this workspace once.",
            "formatted_output": "Current workspace identity is not available for MCP recommendation lookup. Make sure the extension has synced this workspace once.",
        }

    result = await _get_current_workspace_recommendation(
        project_name=resolved_project,
        workspace_path=workspace_path,
        timeout_sec=timeout_sec,
        query_text=(query_text or "").strip(),
        doc_top_k=max(1, min(int(doc_top_k), 20)) if isinstance(doc_top_k, int) else 5,
    )
    if result.get("status") != "success":
        return {
            "status": "error",
            "error": result.get("error") or "current workspace recommendation failed",
            "display_markdown": str(result.get("error") or "Current workspace recommendation failed."),
            "formatted_output": str(result.get("error") or "Current workspace recommendation failed."),
            "project_name": resolved_project or None,
            "client_id": resolved_client or None,
            "workspace_id": resolved_workspace or None,
        }

    rows = result.get("rows")
    if not isinstance(rows, list):
        rows = []
    document_context = result.get("document_context")
    if not isinstance(document_context, dict):
        document_context = {
            "success": False,
            "message": "document context unavailable",
            "query": (query_text or "").strip(),
            "project_name": resolved_project,
            "count": 0,
            "results": [],
        }
    context_enrichment = result.get("context_enrichment")
    if not isinstance(context_enrichment, dict):
        context_enrichment = {
            "enabled": False,
            "query": (query_text or "").strip(),
            "semantic_results_used": 0,
            "artifact_results_used": 0,
            "refined_context": {
                "issue_summary": "",
                "contextual_findings": [],
                "recommended_actions": [],
                "possible_resolutions": [],
                "caveats": [],
            },
        }
    llm_analysis = str(result.get("llm_analysis") or "").strip()
    logger.debug(
        "copilot_recommend_active | building display_markdown | "
        "project_name=%s | rows_count=%d | llm_analysis_present=%s | llm_analysis_chars=%d",
        resolved_project,
        len(rows),
        bool(llm_analysis),
        len(llm_analysis),
    )
    display_markdown = str(result.get("formatted_output") or json.dumps(rows, indent=2))
    if llm_analysis:
        display_markdown += f"\n\n---\n\n## LLM Analysis\n\n{llm_analysis}"
        logger.debug(
            "copilot_recommend_active | LLM analysis section appended | "
            "project_name=%s | display_markdown_chars=%d",
            resolved_project,
            len(display_markdown),
        )
    else:
        logger.debug(
            "copilot_recommend_active | no LLM analysis to append | project_name=%s",
            resolved_project,
        )
    return {
        "status": "success",
        "response_mode": "render_only",
        "render_instruction": "Render display_markdown exactly as provided. Do not summarize, explain, infer, or answer from chat memory.",
        "display_markdown": display_markdown,
        "formatted_output": display_markdown,
        "solutions": rows,
        "document_context": document_context,
        "context_enrichment": context_enrichment,
        "project_name": resolved_project or None,
        "client_id": resolved_client or None,
        "workspace_id": resolved_workspace or None,
        "workspace": workspace_path or None,
        "source": result.get("source"),
        "report_path": result.get("report_path"),
        "backend_base_url": result.get("backend_base_url"),
        "backend_endpoint": f"{result.get('backend_base_url')}/report-errors" if result.get("backend_base_url") else None,
    }


@mcp.tool()
async def copilot_recommendation_active(
    query_text: str,
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    doc_top_k: int = 5,
    timeout_sec: int = 60,
) -> dict:
    """
    Unified recommendation tool.
    Returns error recommendation rows and document embedding lookup context in one response.
    """
    return await copilot_recommend_active(
        query_text=query_text,
        project_name=project_name,
        client_id=client_id,
        actor_id=actor_id,
        doc_top_k=doc_top_k,
        timeout_sec=timeout_sec,
    )


@mcp.tool()
async def get_current_error_solution(
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    timeout_sec: int = 60,
) -> dict:
    """
    Natural-language alias for current error recommendation.
    Use this tool when the user asks for the solution, recommendation, or fix for the current error.
    Always fetch from backend current active error context. Do not answer from previous chat memory.
    """
    return await copilot_recommend_active(
        project_name=project_name,
        client_id=client_id,
        actor_id=actor_id,
        timeout_sec=timeout_sec,
    )


@mcp.tool()
async def recommend_fix_for_current_error(
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    timeout_sec: int = 60,
) -> dict:
    """
    User-friendly alias for current error recommendation.
    Use this tool when the user asks for a fix, recommendation, or solution for the current error or build failure.
    """
    return await copilot_recommend_active(
        project_name=project_name,
        client_id=client_id,
        actor_id=actor_id,
        timeout_sec=timeout_sec,
    )


@mcp.tool()
async def get_fix_for_build_failure(
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    timeout_sec: int = 60,
) -> dict:
    """
    User-friendly alias for current build failure recommendation.
    Use this tool when the user asks how to fix the current build failure.
    """
    return await copilot_recommend_active(
        project_name=project_name,
        client_id=client_id,
        actor_id=actor_id,
        timeout_sec=timeout_sec,
    )


@mcp.tool()
async def check_current_error_session(
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    timeout_sec: int = 30,
) -> dict:
    """
    User-friendly alias for checking the current active error session.
    Use this tool when the user asks to check the current error, active session, or build-error session.
    """
    return await copilot_session_active(
        project_name=project_name,
        client_id=client_id,
        actor_id=actor_id,
        timeout_sec=timeout_sec,
    )


@mcp.tool()
async def show_current_build_error(
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    timeout_sec: int = 30,
) -> dict:
    """
    User-friendly alias for showing the current active build error from the current session.
    """
    return await copilot_session_active(
        project_name=project_name,
        client_id=client_id,
        actor_id=actor_id,
        timeout_sec=timeout_sec,
    )


@mcp.tool()
async def copilot_recommend_by_uuid(
    project_name: str,
    uuid: str,
    error_message: str,
    timeout_sec: int = 60,
) -> dict:
    payload = {
        "project_name": (project_name or "").strip().lower(),
        "uuid": uuid,
        "error_message": error_message or "",
    }
    resp, used_base = await _request_with_fallback(
        "POST",
        "/copilot/recommendations/by-uuid",
        timeout_sec=timeout_sec,
        json_body=payload,
    )
    if resp.status_code == 404:
        return {
            "status": "error",
            "error": "recommendation not found",
            "backend_base_url": used_base,
            "backend_endpoint": f"{used_base}/copilot/recommendations/by-uuid",
        }
    resp.raise_for_status()
    out = resp.json()
    if isinstance(out, dict):
        out["backend_base_url"] = used_base
        out["backend_endpoint"] = f"{used_base}/copilot/recommendations/by-uuid"
    return out


@mcp.tool()
async def copilot_predict_build_risk(
    project_name: str | None = None,
    client_id: str | None = None,
    actor_id: str | None = None,
    timeout_sec: int = 90,
) -> dict:
    """
    Phase-2 prediction entrypoint.
    1) creates/refreshes prediction scope session
    2) fetches current prediction result (or pending status)
    """
    return {
        "status": "deprecated",
        "response_mode": "render_only",
        "display_markdown": (
            "Phase-2 prediction via MCP tool is disabled. "
            "Use VS Code extension UI report flow for prediction."
        ),
        "formatted_output": (
            "Phase-2 prediction via MCP tool is disabled. "
            "Use VS Code extension UI report flow for prediction."
        ),
        "project_name": (project_name or "").strip().lower() or None,
        "client_id": (client_id or "").strip() or "global",
        "actor_id": (actor_id or "").strip() or "global",
    }


def _log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


if __name__ == "__main__":
    transport = str(os.environ.get("MCP_TRANSPORT") or "streamable-http").strip() or "streamable-http"
    _log(f"Starting powershell-local MCP server on transport={transport}...")
    mcp.run(transport=transport)
