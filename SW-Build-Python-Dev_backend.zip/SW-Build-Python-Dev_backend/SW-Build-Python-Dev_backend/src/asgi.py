from contextlib import asynccontextmanager

from starlette.applications import Starlette
from starlette.middleware.wsgi import WSGIMiddleware
from starlette.routing import Mount

from src.routes.route import app as flask_app
from src.mcp.server import mcp
from src.models.model import ensure_tables


class _PathPrefixASGI:
    """
    Some FastMCP builds expose routes under /mcp internally and do not allow
    overriding the path. When mounted at /mcp, Starlette strips the prefix and
    the inner app sees "/" which causes 404. This adapter prepends /mcp back.
    """

    def __init__(self, app, prefix: str):
        self.app = app
        self.prefix = prefix.rstrip("/")

    async def __call__(self, scope, receive, send):
        if scope.get("type") in {"http", "websocket"}:
            path = scope.get("path", "") or "/"
            if not path.startswith(self.prefix):
                new_path = f"{self.prefix}{path if path.startswith('/') else '/' + path}"
                new_scope = dict(scope)
                new_scope["path"] = new_path
                new_scope["raw_path"] = new_path.encode("utf-8")
                scope = new_scope
        await self.app(scope, receive, send)


def _build_mcp_app():
    # FastMCP API differs across versions.
    needs_internal_mcp_prefix = False

    if hasattr(mcp, "http_app"):
        try:
            app = mcp.http_app(path="/")
            return app, needs_internal_mcp_prefix
        except TypeError:
            app = mcp.http_app()
            needs_internal_mcp_prefix = True
            return app, needs_internal_mcp_prefix
    if hasattr(mcp, "streamable_http_app"):
        try:
            app = mcp.streamable_http_app(path="/")
            return app, needs_internal_mcp_prefix
        except TypeError:
            app = mcp.streamable_http_app()
            needs_internal_mcp_prefix = True
            return app, needs_internal_mcp_prefix
    if hasattr(mcp, "sse_app"):
        try:
            app = mcp.sse_app(path="/")
            return app, needs_internal_mcp_prefix
        except TypeError:
            app = mcp.sse_app()
            needs_internal_mcp_prefix = True
            return app, needs_internal_mcp_prefix
    raise AttributeError("FastMCP instance does not expose an ASGI app builder")


mcp_app, _needs_internal_mcp_prefix = _build_mcp_app()
if _needs_internal_mcp_prefix:
    mcp_app = _PathPrefixASGI(mcp_app, "/mcp")

@asynccontextmanager
async def lifespan(app: Starlette):
    # Ensure tables on startup
    ensure_tables()

    app_lifespan = getattr(mcp_app, "lifespan", None)
    if callable(app_lifespan):
        async with app_lifespan(app):
            yield
    else:
        yield


app = Starlette(
    routes=[
        Mount("/mcp", app=mcp_app),
        Mount("/", app=WSGIMiddleware(flask_app)),
    ],
    lifespan=lifespan,
)
