import logging
import os
import re
import time
from typing import Any

from src.utils.payload_archive import (
    download_prediction_feature_json,
    list_prediction_feature_archives,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------- cost instrumentation
# The 29-Sep review set a hard budget: a prediction must not take longer than the build it guards
# (30s build -> 15s budget on TestGB), and nobody could say where the current 3-4 minutes goes.
# These counters answer that from a real request instead of from reading the code: how many stored
# patterns were listed, how many were actually fetched from S3, and how long each stage took.
#
# Read them in the log line each lookup emits. They are deliberately per-call and not aggregated -
# an average would hide the case that matters, which is the project with the most history.
def _stage_log(stage: str, *, project: str, listed: int, fetched: int, requested: int, started: float) -> None:
    logger.info(
        "prediction %s | project=%s | requested_files=%d | archives_listed=%d | archives_fetched=%d | elapsed_ms=%d",
        stage, project, requested, listed, fetched, int((time.time() - started) * 1000),
    )


_PROJECT_KEYS = {"project_name", "projectName", "project", "projectName".lower()}
_FILE_LIST_KEYS = {
    "file_paths",
    "filePaths",
    "paths",
    "files",
    "selected_files",
    "selectedFiles",
    "file_path",
    "filePath",
}
_IGNORED_KEYS = _PROJECT_KEYS | {
    "actor_id",
    "client_id",
    "request_id",
    "uuid",
    "limit",
    "ttl_hours",
}


def _normalize_project_name(value: str) -> str:
    return str(value or "").strip().lower()


def _normalize_path(value: str, project_name: str = "") -> str:
    raw = str(value or "").strip().replace("\\", "/").lower()
    if not raw:
        return ""
    project = _normalize_project_name(project_name)
    marker = f"/{project}/"
    idx = raw.find(marker)
    if idx >= 0:
        return raw[idx + len(marker):].strip("/")
    if project and raw.startswith(f"{project}/"):
        return raw[len(project) + 1:].strip("/")
    return raw.strip("/")


def _path_keys(value: str, project_name: str = "") -> set[str]:
    # Match ONLY the exact file the developer selected — its full project-relative path (e.g.
    # work/bsw/acm.h). _normalize_path already strips the machine/project prefix, so this same-file
    # match works across developers/machines. We deliberately do NOT also key on basename or the
    # last two segments: that pulled EVERY same-named file's history across the whole project
    # ("bringing lot of data"), when only the selected file's own history should match.
    normalized = _normalize_path(value, project_name)
    return {normalized} if normalized else set()


def _paths_match(a: str, b: str) -> bool:
    """True when two normalized keys refer to the same project file.

    Exact match first. Fallback: a boundary-safe FULL-relative-path suffix match. Needed
    because legacy rows stored the ABSOLUTE capture-machine path (e.g.
    d:/uat_projects/testgbe/work/tools/config.xml) and _normalize_path can only strip that
    prefix when the workspace folder name equals the registered project name — when another
    developer's clone is named differently, the stored key stays absolute and could never
    match the requester's relative path (the TestGB "1 file, 0 patterns" case). The suffix
    side must keep at least two segments, so this never degrades into basename matching
    (see the note in _path_keys: basename matching pulled every same-named file's history).
    """
    if not a or not b:
        return False
    if a == b:
        return True
    longer, shorter = (a, b) if len(a) >= len(b) else (b, a)
    if shorter.count("/") < 1:
        return False
    return longer.endswith("/" + shorter)


def _any_path_match(keys_a: set, keys_b: set) -> bool:
    return any(_paths_match(x, y) for x in keys_a for y in keys_b)


def _looks_like_path(value: str) -> bool:
    text = str(value or "").strip()
    return "/" in text or "\\" in text


def _append_path(paths: list[str], seen: set[str], value: Any) -> None:
    text = str(value or "").strip()
    if not text or text in seen:
        return
    seen.add(text)
    paths.append(text)


def _collect_paths_from_value(value: Any, paths: list[str], seen: set[str]) -> None:
    if isinstance(value, str):
        if _looks_like_path(value):
            _append_path(paths, seen, value)
        return
    if isinstance(value, list):
        for item in value:
            _collect_paths_from_value(item, paths, seen)
        return
    if isinstance(value, dict):
        direct = value.get("file_path") or value.get("filePath") or value.get("fileName")
        if direct:
            _append_path(paths, seen, direct)
        for key, nested in value.items():
            if key in _IGNORED_KEYS:
                continue
            if _looks_like_path(key):
                _append_path(paths, seen, key)
            elif key in _FILE_LIST_KEYS:
                _collect_paths_from_value(nested, paths, seen)


def extract_project_name(payload: Any) -> str:
    if isinstance(payload, dict):
        for key in ("project_name", "projectName", "project"):
            value = str(payload.get(key) or "").strip()
            if value:
                return _normalize_project_name(value)
        paths = extract_file_paths(payload)
        if paths:
            first_part = paths[0].replace("\\", "/").split("/", 1)[0]
            if first_part:
                return _normalize_project_name(first_part)
    if isinstance(payload, list):
        for item in payload:
            project_name = extract_project_name(item)
            if project_name:
                return project_name
    return ""


def extract_file_paths(payload: Any) -> list[str]:
    paths: list[str] = []
    seen: set[str] = set()
    _collect_paths_from_value(payload, paths, seen)
    return paths


def find_existing_prediction_file_paths(
    *,
    project_name: str,
    file_paths: list[str],
    limit: int = 1000,
) -> dict[str, Any]:
    project = _normalize_project_name(project_name)
    if not project:
        raise ValueError("project_name is required")
    if not file_paths:
        raise ValueError("file_paths is required")

    requested: dict[str, set[str]] = {
        file_path: _path_keys(file_path, project)
        for file_path in file_paths
        if str(file_path or "").strip()
    }
    matched_files: set[str] = set()

    started = time.time()
    fetched = 0
    refs = list_prediction_feature_archives(project_name=project, limit=max(1, int(limit or 1000)))
    for ref in refs:
        if len(matched_files) == len(requested):
            break
        s3_key = str(ref.get("s3_key") or "").strip()
        if not s3_key:
            continue
        try:
            feature = download_prediction_feature_json(s3_key)
            fetched += 1
        except Exception:
            continue
        feature_path = str(feature.get("file_path") or "").strip() if isinstance(feature, dict) else ""
        feature_keys = _path_keys(feature_path, project)
        if not feature_keys:
            continue
        for file_path, keys in requested.items():
            if file_path not in matched_files and _any_path_match(keys, feature_keys):
                matched_files.add(file_path)

    matches = [file_path for file_path in requested if file_path in matched_files]
    _stage_log("extension-files", project=project, listed=len(refs), fetched=fetched,
               requested=len(requested), started=started)

    return {
        "status": True,
        "project_name": project,
        "file_paths": matches,
    }


def _response_file_key(project_name: str, file_path: str) -> str:
    normalized = str(file_path or "").strip().replace("\\", "/").strip("/")
    project = str(project_name or "").strip()
    if not normalized:
        return project.upper()
    if normalized.lower().startswith(f"{project.lower()}/"):
        return normalized
    return f"{project.upper()}/{normalized}"


def _pattern_key(text: str) -> str:
    """Normalized key for grouping identical failing patterns (whitespace-insensitive, lowercased)."""
    return re.sub(r"\s+", "", str(text or "")).lower()


def _feature_response_row(feature: dict[str, Any]) -> dict[str, Any]:
    before_path = (
        feature.get("before_path")
        or feature.get("befour_path")
        or feature.get("change")
        or ""
    )
    return {
        "before_path": str(before_path or ""),
        "line": int(feature.get("line") or 0),
        "patch": str(feature.get("context_window") or feature.get("patch") or ""),
        "patch_embedding": feature.get("patch_embedding") if isinstance(feature.get("patch_embedding"), list) else [],
        "request_id": str(feature.get("request_id") or ""),
        # Prediction predicts on what CAUSES FAILURE. Carry risk_side so the extension can enforce
        # the failure ("before") side, and after_patch so the report can show what the fix was.
        "risk_side": str(feature.get("risk_side") or ""),
        "after_patch": str(feature.get("after_patch") or ""),
    }


def get_prediction_data_for_files(
    *,
    project_name: str,
    file_paths: list[str],
    limit: int = 1000,
) -> dict[str, list[dict[str, Any]]]:
    project = _normalize_project_name(project_name)
    if not project:
        raise ValueError("project_name is required")
    if not file_paths:
        raise ValueError("file_paths is required")

    requested: dict[str, set[str]] = {
        file_path: _path_keys(file_path, project)
        for file_path in file_paths
        if str(file_path or "").strip()
    }
    response: dict[str, list[dict[str, Any]]] = {
        _response_file_key(project, file_path): []
        for file_path in requested
    }
    key_to_response_path: dict[str, str] = {}
    for file_path, keys in requested.items():
        response_path = _response_file_key(project, file_path)
        for key in keys:
            key_to_response_path[key] = response_path

    started = time.time()
    fetched = 0
    refs = list_prediction_feature_archives(project_name=project, limit=max(1, int(limit or 1000)))
    for ref in refs:
        s3_key = str(ref.get("s3_key") or "").strip()
        if not s3_key:
            continue
        try:
            feature = download_prediction_feature_json(s3_key)
            fetched += 1
        except Exception:
            continue
        if not isinstance(feature, dict):
            continue

        feature_path = str(feature.get("file_path") or "").strip()
        feature_keys = _path_keys(feature_path, project)
        matched_response_paths = {
            response_path
            for req_key, response_path in key_to_response_path.items()
            if any(_paths_match(req_key, fk) for fk in feature_keys)
        }
        # NOTE: do NOT drop fix ("after") side features here. This endpoint's contract is "has data
        # -> 200, else 404", and extension-files (which the extension calls first) counts ALL sides;
        # filtering here can empty a file that extension-files said has data -> a 404 the extension
        # retries in a loop. Instead we CARRY risk_side on each row and the EXTENSION enforces the
        # failure ("before") side. Prediction still learns only from failures; the contract is intact.
        for response_path in matched_response_paths:
            response[response_path].append(_feature_response_row(feature))

    # Frequency-weighted confidence input: per file, count how many DISTINCT past failures
    # (request_ids) shared each failing pattern. A pattern that broke the build many times is
    # higher confidence than one that broke it once — the extension turns fail_count into confidence.
    for rows in response.values():
        groups: dict[str, set[str]] = {}
        for r in rows:
            key = _pattern_key(str(r.get("before_path") or r.get("patch") or ""))
            groups.setdefault(key, set()).add(str(r.get("request_id") or ""))
        for r in rows:
            key = _pattern_key(str(r.get("before_path") or r.get("patch") or ""))
            r["fail_count"] = max(1, len(groups.get(key) or set()))

    out = {file_path: rows for file_path, rows in response.items() if rows}
    _stage_log("file-data", project=project, listed=len(refs), fetched=fetched,
               requested=len(requested), started=started)
    logger.info(
        "prediction file-data payload | project=%s | files_with_patterns=%d | rows_returned=%d",
        project, len(out), sum(len(rows) for rows in out.values()),
    )
    return out


def handle_file_data_lookup(payload: Any, limit: int = 1000) -> dict[str, list[dict[str, Any]]]:
    project_name = extract_project_name(payload)
    file_paths = extract_file_paths(payload)
    return get_prediction_data_for_files(
        project_name=project_name,
        file_paths=file_paths,
        limit=limit,
    )


def handle_extension_file_check(payload: Any, limit: int = 1000) -> dict[str, Any]:
    project_name = extract_project_name(payload)
    file_paths = extract_file_paths(payload)
    return find_existing_prediction_file_paths(
        project_name=project_name,
        file_paths=file_paths,
        limit=limit,
    )
