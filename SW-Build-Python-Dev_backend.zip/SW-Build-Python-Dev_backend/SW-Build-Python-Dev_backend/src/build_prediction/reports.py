"""
Dashboard "Build Prediction Report" module APIs (UI spec).

  GET /prediction-reports?projectName=&startDate=&endDate=   -> report cards list
  GET /prediction-reports/<prediction_report_id>             -> full report details

Additive read-only layer over the prediction-history storage that POST /predict/report already
writes (save_prediction_history_report). No existing endpoint or storage row is modified.

Risk levels are banded by the ADMIN-configured thresholds (prediction_config: lowRiskUpperLimit /
mediumRiskUpperLimit — the same config that drives the prediction scan itself), NOT hardcoded
cut-offs, so the dashboard Settings page stays the single source of truth:
    score <= low  -> "Low Risk"    |    score <= medium -> "Medium Risk"    |    else "High Risk"
build_confidence = 100 - average_risk_score (per UI dev calculation rules).
"""
import os
import re
from typing import Any

from src.services import prediction_config as pc
from src.utils.project_details import (
    get_prediction_history_report,
    list_prediction_history_reports_with_report,
)

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_CREATED_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}:\d{2})")

_RECOMMENDATIONS = {
    "High Risk": "High Risk. If unchanged, this file is very likely to cause the same failure "
                 "again. Please review before triggering the next build.",
    "Medium Risk": "Medium Risk. This file partially matches past failure patterns. A review is "
                   "recommended before the next build.",
    "Low Risk": "Low Risk. Only weak similarity to past failures was found. Safe to proceed with "
                "normal caution.",
}


def _risk_thresholds() -> tuple[int, int]:
    """Admin-configured band limits (defaults 30/70). Never raises — reports must render even if
    the config table is briefly unreachable."""
    try:
        cfg = pc.public_view()
        low = int(cfg.get("lowRiskUpperLimit") or 30)
        med = int(cfg.get("mediumRiskUpperLimit") or 70)
        if 0 < low < med <= 100:
            return low, med
    except Exception:
        pass
    return 30, 70


def _risk_level(score: float, low: int, med: int) -> str:
    if score > med:
        return "High Risk"
    if score > low:
        return "Medium Risk"
    return "Low Risk"


def _split_created(value: Any) -> tuple[str, str]:
    """'YYYY-MM-DDTHH:MM:SSZ' -> ('YYYY-MM-DD', 'HH:MM:SS'); tolerant of offsets/millis."""
    text = str(value or "").strip()
    m = _CREATED_RE.match(text)
    if m:
        return m.group(1), m.group(2)
    if len(text) >= 10 and _DATE_RE.match(text[:10]):
        return text[:10], ""
    return "", ""


def _file_name(value: Any) -> str:
    return os.path.basename(str(value or "").strip().replace("\\", "/"))


def _match_type(issue: dict) -> str:
    """Mirrors the stage precedence of _predict_match_reason (handlers.py) as a short badge label."""
    s1 = float(issue.get("stage1_score") or 0.0)
    s2 = float(issue.get("stage2_score") or 0.0)
    s3 = float(issue.get("stage3_score") or 0.0)
    s4 = float(issue.get("stage4_score") or 0.0)
    if bool(issue.get("absence_found")) and s4 >= max(s1, s2, s3):
        return "Missing fix line"
    if s1 > 0:
        return "Exact line match"
    if s2 > 0:
        return "Context similarity match"
    if s3 > 0:
        return "Semantic similarity match"
    return "Historical pattern match"


def _issue_view(issue: dict, low: int, med: int) -> dict:
    score = round(float(issue.get("risk_score") or 0.0), 2)
    level = _risk_level(score, low, med)
    file_path = str(issue.get("file_path") or "")
    return {
        "request_id": str(issue.get("request_id") or ""),
        "file_name": str(issue.get("file_name") or "") or _file_name(file_path),
        "file_path": file_path,
        "line_found": int(issue.get("line_found") or 0),
        "line_text_found": str(issue.get("line_text_found") or ""),
        "historical_pattern": str(issue.get("historical_pattern") or ""),
        "why_matched": str(issue.get("why_matched") or ""),
        "risk_score": score,
        "risk_level": level,
        "dominant_stage": int(issue.get("dominant_stage") or issue.get("stage") or 0),
        "stage1_score": round(float(issue.get("stage1_score") or 0.0), 2),
        "stage2_score": round(float(issue.get("stage2_score") or 0.0), 2),
        "stage3_score": round(float(issue.get("stage3_score") or 0.0), 2),
        "stage4_score": round(float(issue.get("stage4_score") or 0.0), 2),
        "historical_hits": int(issue.get("historical_hits") or 0),
        "absence_found": bool(issue.get("absence_found") or False),
        "match_type": _match_type(issue),
        "recommendation": _RECOMMENDATIONS[level],
    }


def _issues_of(report: dict) -> list[dict]:
    issues = report.get("issues")
    return [i for i in issues if isinstance(i, dict)] if isinstance(issues, list) else []


def _flagged_files_count(issues: list[dict]) -> int:
    """Unique files having at least one match (file_path preferred; file_name fallback)."""
    return len({
        (str(i.get("file_path") or "") or str(i.get("file_name") or "")).lower()
        for i in issues
        if (i.get("file_path") or i.get("file_name"))
    })


def _selected_files_view(report: dict, issues: list[dict]) -> list[dict]:
    """selected_relative_files as [{file_name}] objects. Stored entries may be strings (relative
    paths from the extension) or dicts. Reports saved before the extension began sending the list
    fall back to the flagged files, so cards are never empty."""
    out: list[dict] = []
    seen: set[str] = set()

    def _add(value: Any) -> None:
        name = _file_name(value)
        if name and name.lower() not in seen:
            seen.add(name.lower())
            out.append({"file_name": name})

    raw = report.get("selected_relative_files")
    if isinstance(raw, list):
        for entry in raw:
            if isinstance(entry, dict):
                _add(entry.get("file_name") or entry.get("file_path"))
            else:
                _add(entry)
    if out:
        return out
    for issue in issues:
        _add(issue.get("file_name") or issue.get("file_path"))
    return out


def _list_item(row: dict, low: int, med: int) -> dict:
    report = row.get("report") if isinstance(row.get("report"), dict) else {}
    issues = _issues_of(report)
    avg = round(float(report.get("average_risk_score") or 0.0), 2)
    created_date, created_time = _split_created(row.get("created_date"))
    return {
        "prediction_report_id": str(row.get("prediction_report_id") or ""),
        "project_name": str(row.get("project_name") or ""),
        "created_date": created_date,
        "created_time": created_time,
        "average_risk_score": avg,
        "risk_level": _risk_level(avg, low, med),
        "files_scanned": int(report.get("files_scanned") or 0),
        "selected_files_count": int(report.get("selected_files_count") or 0),
        "flagged_files_count": _flagged_files_count(issues),
        "matches_found": int(report.get("matches_found") or len(issues)),
    }


def handle_prediction_reports_list(
    project_name: str,
    start_date: str = "",
    end_date: str = "",
    limit: int = 200,
) -> list[dict]:
    project = str(project_name or "").strip().lower()
    if not project:
        raise ValueError("projectName is required")
    start = str(start_date or "").strip()
    end = str(end_date or "").strip()
    if start and not _DATE_RE.match(start):
        raise ValueError("startDate must be YYYY-MM-DD")
    if end and not _DATE_RE.match(end):
        raise ValueError("endDate must be YYYY-MM-DD")

    low, med = _risk_thresholds()
    items: list[dict] = []
    for row in list_prediction_history_reports_with_report(project, limit=limit):
        item = _list_item(row, low, med)
        day = item["created_date"]
        if start and (not day or day < start):
            continue
        if end and (not day or day > end):
            continue
        items.append(item)
    return items


def handle_prediction_report_details(prediction_report_id: str) -> dict | None:
    record = get_prediction_history_report(prediction_report_id)
    if not isinstance(record, dict):
        return None
    report = record.get("report") if isinstance(record.get("report"), dict) else {}

    low, med = _risk_thresholds()
    issues = [_issue_view(i, low, med) for i in _issues_of(report)]
    avg = round(float(report.get("average_risk_score") or 0.0), 2)
    created_date, created_time = _split_created(record.get("created_date"))
    levels = [i["risk_level"] for i in issues]
    locations = {
        ((i["file_path"] or i["file_name"]).lower(), i["line_found"])
        for i in issues
        if i["file_path"] or i["file_name"]
    }

    return {
        "prediction_report_id": str(record.get("prediction_report_id") or ""),
        "project_name": str(record.get("project_name") or ""),
        "created_date": created_date,
        "created_time": created_time,
        "scan_time": str(report.get("scan_time") or record.get("created_date") or ""),
        "status": True,
        "result": str(report.get("result") or ""),
        "note": str(report.get("note") or ""),
        "average_risk_score": avg,
        "risk_level": _risk_level(avg, low, med),
        "build_confidence": round(100.0 - avg, 2),
        "files_scanned": int(report.get("files_scanned") or 0),
        "selected_files_count": int(report.get("selected_files_count") or 0),
        "flagged_files_count": _flagged_files_count(_issues_of(report)),
        "matches_found": int(report.get("matches_found") or len(issues)),
        "high_risk_count": levels.count("High Risk"),
        "medium_risk_count": levels.count("Medium Risk"),
        "low_risk_count": levels.count("Low Risk"),
        "locations_count": len(locations),
        "has_matches": bool(report.get("has_matches") if report.get("has_matches") is not None else issues),
        "selected_relative_files": _selected_files_view(report, issues),
        "issues": issues,
        # Shadow-mode pass-through (additive): the stored report already carries these for
        # shadow captures; surfacing them makes captures inspectable without a DB peek.
        "report_kind": str(record.get("report_kind") or report.get("report_kind") or "standard"),
        "shadow_context": report.get("shadow_context") if isinstance(report.get("shadow_context"), dict) else None,
        "judged_at": record.get("judged_at"),
        "judgement": record.get("judgement") if isinstance(record.get("judgement"), dict) else None,
    }
