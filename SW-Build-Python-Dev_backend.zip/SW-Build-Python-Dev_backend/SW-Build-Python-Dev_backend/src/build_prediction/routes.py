from flask import Blueprint, jsonify, request

from src.build_prediction.service import (
    handle_extension_file_check,
    handle_file_data_lookup,
)
from src.build_prediction.reports import (
    handle_prediction_report_details,
    handle_prediction_reports_list,
)
from src.services import prediction_config as pc
from src.routes.auth_route import require_role, require_role_if_token


build_prediction_bp = Blueprint("build_prediction", __name__)


def _envelope(data=None, message="Success", success=True):
    return {"success": success, "data": data or {}, "message": message}




@build_prediction_bp.route("/build-prediction/extension-files", methods=["POST"])
@build_prediction_bp.route("/build-predication/extension-files", methods=["POST"])
def extension_files():
    if not request.is_json:
        return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400

    payload = request.get_json(silent=True)
    if payload is None:
        return jsonify({"status": False, "error": "Invalid JSON body"}), 400

    try:
        limit = int(request.args.get("limit") or (payload.get("limit") if isinstance(payload, dict) else 1000) or 1000)
        result = handle_extension_file_check(payload, limit=limit)
        return jsonify(result), 200
    except ValueError as exc:
        return jsonify({"status": False, "error": str(exc)}), 400


@build_prediction_bp.route("/build-prediction/file-data", methods=["POST"])
@build_prediction_bp.route("/build-predication/file-data", methods=["POST"])
def file_data():
    if not request.is_json:
        return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400

    payload = request.get_json(silent=True)
    if payload is None:
        return jsonify({"status": False, "error": "Invalid JSON body"}), 400

    try:
        limit = int(request.args.get("limit") or (payload.get("limit") if isinstance(payload, dict) else 1000) or 1000)
        result = handle_file_data_lookup(payload, limit=limit)
        # No historical failure pattern for these files is NOT an error — it means NO RISK.
        # Return 200 with an empty object so the extension records zero matches and the report
        # shows "no risk / safe to build". Returning 404 here made the extension treat a clean
        # "nothing matched" as a failure: it threw, retried 3x (~6s/file), and counted the file
        # as "skipped due to error" instead of reporting no risk.
        return jsonify(result or {}), 200
    except ValueError as exc:
        return jsonify({"status": False, "error": str(exc)}), 400


# ===================================================================================================
# Build-Failure-Prediction CONFIG (Admin Configuration page).
# GET is open so the EXTENSION can fetch the live tunables at scan time; updates require admin.
# All responses use the {success, data, message} envelope the UI expects.
# ===================================================================================================
@build_prediction_bp.route("/build-prediction/config", methods=["GET"])
@require_role_if_token("admin")
def get_prediction_config():
    """Current configuration — all values. Shared read: the extension consumes this tokenlessly
    before every scan; dashboard users with a non-admin role get 403 + data: [] via the gate."""
    return jsonify(_envelope(pc.public_view())), 200


@build_prediction_bp.route("/build-prediction/config/reset", methods=["POST", "PUT"])
@require_role("admin")
def reset_prediction_config():
    """Restore all tunables to defaults ('Reset to Default' button)."""
    cfg = pc.reset_to_default()
    return jsonify(_envelope(pc.public_view(cfg), "Reset to default")), 200


@build_prediction_bp.route("/build-prediction/config/context-window", methods=["PUT", "POST"])
@require_role("admin")
def update_context_window():
    body = request.get_json(silent=True) or {}
    try:
        cfg = pc.set_context_window(body.get("contextWindow"))
        return jsonify(_envelope(pc.public_view(cfg), "Context window updated")), 200
    except (ValueError, TypeError) as exc:
        return jsonify(_envelope(None, str(exc), False)), 400


@build_prediction_bp.route("/build-prediction/config/similarity-weights", methods=["PUT", "POST"])
@require_role("admin")
def update_similarity_weights():
    body = request.get_json(silent=True) or {}
    try:
        cfg = pc.set_similarity_weights(body.get("cosineWeight"), body.get("diceWeight"))
        return jsonify(_envelope(pc.public_view(cfg), "Similarity weights updated")), 200
    except (ValueError, TypeError) as exc:
        return jsonify(_envelope(None, str(exc), False)), 400


@build_prediction_bp.route("/build-prediction/config/risk-thresholds", methods=["PUT", "POST"])
@require_role("admin")
def update_risk_thresholds():
    body = request.get_json(silent=True) or {}
    try:
        cfg = pc.set_risk_thresholds(body.get("lowRiskUpperLimit"), body.get("mediumRiskUpperLimit"))
        return jsonify(_envelope(pc.public_view(cfg), "Risk thresholds updated")), 200
    except (ValueError, TypeError) as exc:
        return jsonify(_envelope(None, str(exc), False)), 400


@build_prediction_bp.route("/build-prediction/config/scorecard-weighting", methods=["PUT", "POST"])
@require_role("admin")
def update_scorecard_weighting():
    """Rollout step C: judged-shadow reliability scorecards adjust prediction ranking."""
    body = request.get_json(silent=True) or {}
    try:
        cfg = pc.set_scorecard_weighting(body.get("enabled"))
        return jsonify(_envelope(pc.public_view(cfg), "Scorecard weighting updated")), 200
    except (ValueError, TypeError) as exc:
        return jsonify(_envelope(None, str(exc), False)), 400


# ===================================================================================================
# Build Prediction REPORT APIs (dashboard "Build Prediction Report" module — UI dev spec).
# Read-only views over the reports POST /predict/report already persists; existing /predict/history
# endpoints are untouched. Open like the sibling dashboard read endpoints (/graphData,
# /daily-activity). Full request/response schemas are documented in /docs.
# ===================================================================================================
@build_prediction_bp.route("/prediction-reports", methods=["GET"])
def prediction_reports_list():
    """Report cards list, filtered by project and optional inclusive date range."""
    try:
        data = handle_prediction_reports_list(
            project_name=request.args.get("projectName") or "",
            start_date=request.args.get("startDate") or "",
            end_date=request.args.get("endDate") or "",
        )
        return jsonify({
            "success": True,
            "message": "Prediction reports fetched successfully",
            "data": data,
        }), 200
    except ValueError as exc:
        return jsonify({"success": False, "message": str(exc), "data": []}), 400


@build_prediction_bp.route("/prediction-reports/<prediction_report_id>", methods=["GET"])
def prediction_report_details(prediction_report_id: str):
    """Full report for one card (issues, counts, risk breakdown, recommendations)."""
    details = handle_prediction_report_details(prediction_report_id)
    if not details:
        return jsonify({
            "success": False,
            "message": "Prediction report not found",
            "data": None,
        }), 404
    return jsonify({
        "success": True,
        "message": "Prediction report fetched successfully",
        "data": details,
    }), 200
