"""Build prediction extension APIs."""

