"""
Creates Azure Search index with vector embedding & semantic search.
"""

import logging
import src.utils.log_setup  # noqa: F401
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SimpleField,
    SearchableField,
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
    SemanticConfiguration,
    SemanticPrioritizedFields,
    SemanticField,
    SemanticSearch,
    SearchIndex,
)

from src.configurations import config

logger = logging.getLogger(__name__)


def create_example_index_with_embedding(index_name: str):
    logger.debug("Azure Search CREATE INDEX | index=%s", index_name)
    client = SearchIndexClient(
        endpoint=config.SEARCH_SERVICE_ENDPOINT,
        credential=config.AZURE_CREDENTIAL,
    )

    fields = [
        SimpleField(name="error_id", type=SearchFieldDataType.String, key=True),
        SearchableField(name="error_message", type=SearchFieldDataType.String),
        SearchableField(name="solution", type=SearchFieldDataType.String),
        SearchField(
            name=config.VECTOR_FIELD,
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=3072,
            vector_search_profile_name="hnswProfile",
        ),
    ]

    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="hnsw")],
        profiles=[
            VectorSearchProfile(
                name="hnswProfile",
                algorithm_configuration_name="hnsw",
            )
        ],
    )

    semantic_config = SemanticConfiguration(
        name=config.SEMANTIC_CONFIG_NAME,
        prioritized_fields=SemanticPrioritizedFields(
            title_field=SemanticField(field_name="error_id"),
            content_fields=[SemanticField(field_name="error_message")],
            keywords_fields=[SemanticField(field_name="solution")],
        ),
    )

    semantic_search = SemanticSearch(
        configurations=[semantic_config]
    )

    index = SearchIndex(
        name=index_name,
        fields=fields,
        vector_search=vector_search,
        semantic_search=semantic_search,
    )

    result = client.create_index(index)
    logger.info("Azure Search INDEX CREATED | index=%s", index_name)
    return result
