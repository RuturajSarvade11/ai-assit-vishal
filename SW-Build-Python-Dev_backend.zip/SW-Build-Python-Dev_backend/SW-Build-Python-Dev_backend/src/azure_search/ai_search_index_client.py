"""
Azure Search Index management (create / update / delete).
"""

import logging
import src.utils.log_setup  # noqa: F401
from azure.search.documents.indexes import SearchIndexClient
from src.configurations import config

logger = logging.getLogger(__name__)


def delete_index(index_name: str):
    logger.warning("Azure Search DELETE INDEX | index=%s (DESTRUCTIVE operation)", index_name)
    client = SearchIndexClient(
        endpoint=config.SEARCH_SERVICE_ENDPOINT,
        credential=config.AZURE_CREDENTIAL,
    )
    client.delete_index(index_name)
    logger.info("Azure Search DELETE INDEX done | index=%s", index_name)
