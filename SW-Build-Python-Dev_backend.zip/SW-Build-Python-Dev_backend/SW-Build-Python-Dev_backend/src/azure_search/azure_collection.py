"""
AzureCollection — a thin ChromaDB-COMPATIBLE wrapper over Azure AI Search.

It exposes the same methods the recommendation/artifact/document code already calls on a Chroma
collection (query / get / add / upsert / count), translating to Azure AI Search. This lets the
backend read+write Azure by swapping ONLY what `collection` is (behind config.USE_AZURE_SEARCH),
with no change to the call sites.

Index schema + key scheme match migrate_chroma_to_azure.py (index name = collection with '_'->'-';
key = base64url(chroma_id); typed filter fields + full metadata_json). Distances are returned as
(1 - search_score) so lower==closer, matching Chroma's ordering (RRF uses rank, not absolute value).
"""
import re
import json
import base64
import logging

from src.configurations import config

logger = logging.getLogger(__name__)

ENDPOINT = getattr(config, "AZURE_SEARCH_ENDPOINT", None) or __import__("os").getenv(
    "AZURE_SEARCH_ENDPOINT", "https://cscspq001aiswbuildq.search.windows.net")


def _search_credential():
    """API key (bypasses MFA / Conditional Access) when AZURE_SEARCH_API_KEY is set, else the AAD credential."""
    key = getattr(config, "AZURE_SEARCH_API_KEY", "")
    if key:
        from azure.core.credentials import AzureKeyCredential
        return AzureKeyCredential(key)
    return config.AZURE_CREDENTIAL

STR_FIELDS = ["project_name", "error_signature_hash", "content_sha256", "content_sha12",
              "task_path", "s3_key", "file_name", "request_id", "batch_id", "vector_id"]
BOOL_FIELDS = ["is_artifact_summary"]
INT_FIELDS = ["summary_total_tokens"]


def to_index_name(collection_name: str) -> str:
    n = str(collection_name).strip().lower()
    if re.fullmatch(r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", n):
        return n
    return re.sub(r"-{2,}", "-", re.sub(r"[^a-z0-9]+", "-", n)).strip("-")


def _key(cid) -> str:
    return base64.urlsafe_b64encode(str(cid).encode("utf-8")).decode("ascii")


def _odata_literal(v) -> str:
    return "'" + str(v).replace("'", "''") + "'"


# A filter that can never match. Used where "no candidates" is the correct answer and dropping
# the filter would instead sweep the WHOLE index - silently returning another project's rows.
_ODATA_NEVER = "search.in(project_name, '')"


def _odata(where) -> str | None:
    """Translate a Chroma `where` dict to an Azure OData $filter. Supports {field: value},
    {field: {'$eq'/'$ne'/'$in'/'$nin': v}}, and {'$and'/'$or': [...]}. Returns None for empty.

    $in / $nin: an unknown operator used to be coerced to 'eq', so
    {"project_name": {"$in": ["a", "b"]}} emitted  project_name eq '[''a'', ''b'']'  - valid
    OData that matches nothing and raises nothing. That is already latent in
    cleanup_noise_artifacts.py, and it is the shape any multi-project (group) scope reaches for
    first, so it would have passed Chroma dev testing and returned zero rows on Azure. Unknown
    operators now raise instead of being guessed at.
    """
    if not where:
        return None
    if "$and" in where:
        parts = [p for p in (_odata(c) for c in where["$and"]) if p]
        return " and ".join(f"({p})" for p in parts) if parts else None
    if "$or" in where:
        clauses = list(where["$or"] or [])
        if not clauses:
            # An empty OR means "none of these", not "no filter": returning None here would
            # drop the filter entirely and query the whole index.
            return _ODATA_NEVER
        parts = [p for p in (_odata(c) for c in clauses) if p]
        return " or ".join(f"({p})" for p in parts) if parts else _ODATA_NEVER
    clauses = []
    for field, cond in where.items():
        if isinstance(cond, dict):
            for op, val in cond.items():
                if op in ("$in", "$nin"):
                    vals = list(val or [])
                    if not vals:
                        clauses.append(_ODATA_NEVER if op == "$in" else "true")
                        continue
                    join, cmp_ = (" or ", "eq") if op == "$in" else (" and ", "ne")
                    clauses.append("(" + join.join(
                        f"{field} {cmp_} " + (str(v).lower() if isinstance(v, bool)
                                              else _odata_literal(v))
                        for v in vals) + ")")
                    continue
                if op not in ("$eq", "$ne"):
                    # Never guess: a silently coerced operator is how the $in bug shipped.
                    raise ValueError(f"unsupported filter operator {op!r} for field {field!r}")
                opx = "eq" if op == "$eq" else "ne"
                if isinstance(val, bool):
                    clauses.append(f"{field} {opx} {str(val).lower()}")
                else:
                    clauses.append(f"{field} {opx} {_odata_literal(val)}")
        elif isinstance(cond, bool):
            clauses.append(f"{field} eq {str(cond).lower()}")
        else:
            clauses.append(f"{field} eq {_odata_literal(cond)}")
    return " and ".join(clauses) if clauses else None


def _score_to_l2sq(score) -> float:
    """Convert Azure's cosine vector score to Chroma's squared-L2 distance, so absolute distance
    thresholds (e.g. SOLUTION_RELEVANCE_THRESHOLD) behave identically on Azure and Chroma.

    Azure's @search.score for the cosine metric is NOT (1 + cos)/2. Microsoft documents it as
    1 / (1 + cosine_distance) with cosine_distance = 1 - cos, i.e. score = 1 / (2 - cos), range
    0.333 (opposite) .. 1.0 (identical). The previous mapping assumed (1 + cos)/2 and so
    understated every non-identical match: a 0.90 score (true cos 0.889) was shown as
    similarity 0.80, a 0.80 score (true cos 0.75) as 0.60. Inverting the documented formula:
    cos = 2 - 1/score, and for unit-norm embeddings (text-embedding-3-*) squared-L2 =
    2*(1 - cos) = 2*(1/score - 1). Identical->0, orthogonal (score 0.5)->2, cos 0.75->0.5.
    No vector retrieval needed."""
    try:
        sc = float(score or 0.0)
    except (TypeError, ValueError):
        sc = 0.0
    if sc <= 0.0:
        return 4.0  # no score at all: as far as a vector can be
    return round(max(0.0, 2.0 * (1.0 / sc - 1.0)), 6)


def _to_azure_doc(cid, emb, doc, meta):
    meta = meta if isinstance(meta, dict) else {}
    out = {"id": _key(cid), "chroma_id": str(cid),
           "document": str(doc or meta.get("document") or ""),
           "embedding": [float(x) for x in emb] if emb is not None else [],
           "metadata_json": json.dumps(meta, ensure_ascii=False, default=str)}
    for f in STR_FIELDS:
        v = meta.get(f)
        out[f] = "" if v is None else str(v)
    for f in BOOL_FIELDS:
        out[f] = bool(meta.get(f))
    for f in INT_FIELDS:
        try:
            out[f] = int(meta.get(f) or 0)
        except Exception:
            out[f] = 0
    return out


class AzureCollection:
    def __init__(self, chroma_collection_name: str):
        from azure.search.documents import SearchClient
        self.name = chroma_collection_name
        self.index_name = to_index_name(chroma_collection_name)
        self._client = SearchClient(endpoint=ENDPOINT, index_name=self.index_name,
                                    credential=_search_credential())

    # ---- reads ----
    def query(self, query_embeddings, where=None, n_results=10, include=None):
        from azure.search.documents.models import VectorizedQuery
        q = [float(x) for x in query_embeddings[0]]
        vq = VectorizedQuery(vector=q, k_nearest_neighbors=int(n_results), fields="embedding")
        # embedding is not a retrievable field; derive Chroma squared-L2 from the cosine score instead
        select = ["chroma_id", "document", "metadata_json"]
        try:
            results = list(self._client.search(search_text=None, vector_queries=[vq],
                                               filter=_odata(where), select=select, top=int(n_results)))
        except Exception:
            logger.exception("[azure] query failed | index=%s", self.index_name)
            return {"ids": [[]], "metadatas": [[]], "distances": [[]], "documents": [[]]}
        ids, metas, dists, docs = [], [], [], []
        for r in results:
            ids.append(r.get("chroma_id") or "")
            docs.append(r.get("document") or "")
            try:
                metas.append(json.loads(r.get("metadata_json") or "{}"))
            except Exception:
                metas.append({})
            dists.append(_score_to_l2sq(r.get("@search.score", 0.0)))
        return {"ids": [ids], "metadatas": [metas], "distances": [dists], "documents": [docs]}

    def get(self, ids=None, where=None, include=None, limit=1000, offset=0, **_):
        include = include or []
        select = ["chroma_id", "document", "metadata_json"]  # embedding is not retrievable in the index
        want_emb = "embeddings" in include
        rows = []
        try:
            if ids:
                for cid in ids:
                    try:
                        rows.append(self._client.get_document(key=_key(cid), selected_fields=select))
                    except Exception:
                        continue
            else:
                # Chroma's offset pagination -> Azure Search `skip` (max 100k; fine for our sizes).
                rows = list(self._client.search(search_text="*", filter=_odata(where),
                                                select=select, top=int(limit), skip=int(offset or 0)))
        except Exception:
            logger.exception("[azure] get failed | index=%s", self.index_name)
        out_ids, out_docs, out_metas, out_embs = [], [], [], []
        for r in rows:
            out_ids.append(r.get("chroma_id") or "")
            out_docs.append(r.get("document") or "")
            try:
                out_metas.append(json.loads(r.get("metadata_json") or "{}"))
            except Exception:
                out_metas.append({})
            if want_emb:
                out_embs.append(r.get("embedding") or [])
        res = {"ids": out_ids, "documents": out_docs, "metadatas": out_metas}
        if want_emb:
            res["embeddings"] = out_embs
        return res

    def count(self):
        try:
            return int(self._client.get_document_count())
        except Exception:
            return 0

    # ---- writes ----
    def _upload(self, ids, embeddings, documents=None, metadatas=None):
        docs = []
        for i, cid in enumerate(ids):
            emb = embeddings[i] if embeddings is not None and i < len(embeddings) else None
            doc = documents[i] if documents and i < len(documents) else ""
            meta = metadatas[i] if metadatas and i < len(metadatas) else {}
            docs.append(_to_azure_doc(cid, emb, doc, meta))
        for b in range(0, len(docs), 300):
            try:
                self._client.upload_documents(docs[b:b + 300])
            except Exception:
                logger.exception("[azure] upload failed | index=%s | n=%d", self.index_name, len(docs))

    def add(self, ids, embeddings=None, documents=None, metadatas=None, **_):
        self._upload(ids, embeddings, documents, metadatas)

    def upsert(self, ids, embeddings=None, documents=None, metadatas=None, **_):
        self._upload(ids, embeddings, documents, metadatas)

    def update(self, ids, metadatas=None, **_):
        """METADATA-only update via Azure's MERGE action: only the provided fields change —
        embedding and document are untouched (upload/upsert would REPLACE the whole document and
        wipe the vector). Chroma-compatible signature, so callers like the content_sha256
        backfill work on both backends without changes."""
        if not ids or metadatas is None:
            return
        docs = []
        for i, cid in enumerate(ids):
            meta = metadatas[i] if i < len(metadatas) else None
            if not isinstance(meta, dict):
                continue
            d = {"id": _key(cid),
                 "metadata_json": json.dumps(meta, ensure_ascii=False, default=str)}
            for f in STR_FIELDS:
                v = meta.get(f)
                d[f] = "" if v is None else str(v)
            for f in BOOL_FIELDS:
                d[f] = bool(meta.get(f))
            for f in INT_FIELDS:
                try:
                    d[f] = int(meta.get(f) or 0)
                except Exception:
                    d[f] = 0
            docs.append(d)
        for b in range(0, len(docs), 300):
            try:
                self._client.merge_documents(docs[b:b + 300])
            except Exception:
                logger.exception("[azure] merge failed | index=%s | n=%d", self.index_name, len(docs))
                raise

    def delete(self, ids=None, **_):
        """Delete documents by chroma id (Chroma-compatible signature). Used by the raw-vector
        backfill to remove superseded focused-slice vectors AFTER their raw replacements exist."""
        if not ids:
            return
        docs = [{"id": _key(cid)} for cid in ids if cid]
        for b in range(0, len(docs), 300):
            try:
                self._client.delete_documents(docs[b:b + 300])
            except Exception:
                logger.exception("[azure] delete failed | index=%s | n=%d", self.index_name, len(docs))
                raise

    def delete_collection(self, *a, **k):
        pass


class DualCollection:
    """Reads from Azure; writes to BOTH Chroma and Azure (no data loss + hot rollback). Any other
    Chroma method falls through to the Chroma collection."""
    def __init__(self, chroma, azure):
        self._chroma = chroma
        self._azure = azure
        self.name = getattr(chroma, "name", getattr(azure, "name", None))

    def query(self, **kw):
        return self._azure.query(**kw)

    def get(self, **kw):
        return self._azure.get(**kw)

    def count(self):
        try:
            return self._azure.count()
        except Exception:
            return self._chroma.count()

    def add(self, **kw):
        try:
            self._chroma.add(**kw)
        except Exception:
            logger.exception("[dual] chroma add failed")
        try:
            self._azure.add(**kw)
        except Exception:
            logger.exception("[dual] azure add failed")

    def upsert(self, **kw):
        try:
            self._chroma.upsert(**kw)
        except Exception:
            logger.exception("[dual] chroma upsert failed")
        try:
            self._azure.upsert(**kw)
        except Exception:
            logger.exception("[dual] azure upsert failed")

    def update(self, **kw):
        try:
            self._chroma.update(**kw)
        except Exception:
            logger.exception("[dual] chroma update failed")
        try:
            self._azure.update(**kw)
        except Exception:
            logger.exception("[dual] azure update failed")

    def delete(self, **kw):
        try:
            self._chroma.delete(**kw)
        except Exception:
            logger.exception("[dual] chroma delete failed")
        try:
            self._azure.delete(**kw)
        except Exception:
            logger.exception("[dual] azure delete failed")

    def __getattr__(self, name):
        return getattr(self._chroma, name)


_WRAP_LOGGED = set()


def _build_index(dim, index_name):
    """Standard Azure index schema (same as migrate_chroma_to_azure.build_index, kept here so this
    module has NO dependency on the migration script / chromadb)."""
    from azure.search.documents.indexes.models import (
        SearchIndex, SimpleField, SearchableField, SearchField, SearchFieldDataType,
        VectorSearch, HnswAlgorithmConfiguration, HnswParameters, VectorSearchAlgorithmMetric,
        VectorSearchProfile, SemanticSearch, SemanticConfiguration, SemanticPrioritizedFields, SemanticField)
    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True),
        SimpleField(name="chroma_id", type=SearchFieldDataType.String, retrievable=True),
        SearchableField(name="document", type=SearchFieldDataType.String),
        SearchField(name="embedding", type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True, vector_search_dimensions=int(dim), vector_search_profile_name="vprofile"),
        SimpleField(name="metadata_json", type=SearchFieldDataType.String, retrievable=True),
    ]
    for f in STR_FIELDS:
        fields.append(SimpleField(name=f, type=SearchFieldDataType.String, filterable=True, facetable=False))
    for f in BOOL_FIELDS:
        fields.append(SimpleField(name=f, type=SearchFieldDataType.Boolean, filterable=True))
    for f in INT_FIELDS:
        fields.append(SimpleField(name=f, type=SearchFieldDataType.Int64, filterable=True))
    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="hnsw",
            parameters=HnswParameters(m=4, ef_construction=400, ef_search=500,
                                      metric=VectorSearchAlgorithmMetric.COSINE))],
        profiles=[VectorSearchProfile(name="vprofile", algorithm_configuration_name="hnsw")])
    semantic = SemanticSearch(configurations=[SemanticConfiguration(name="semantic",
        prioritized_fields=SemanticPrioritizedFields(content_fields=[SemanticField(field_name="document")]))])
    return SearchIndex(name=index_name, fields=fields, vector_search=vector_search, semantic_search=semantic)


def ensure_azure_index(collection_name, dim, recreate=False):
    """Create (or recreate) the Azure index for a collection with the standard schema. Used for the
    W-adapter LEARNED-SPACE index (dim = adapter output size, e.g. 512), built by the trainer."""
    from azure.search.documents.indexes import SearchIndexClient
    index_name = to_index_name(collection_name)
    ic = SearchIndexClient(endpoint=ENDPOINT, credential=_search_credential())
    existing = {i.name for i in ic.list_indexes()}
    if index_name in existing and recreate:
        ic.delete_index(index_name)
        existing.discard(index_name)
    if index_name not in existing:
        ic.create_index(_build_index(int(dim), index_name))
        logger.info("[azure] created learned index '%s' (dim=%d)", index_name, int(dim))
    return index_name


def open_collection(collection_name, chroma_factory):
    """Single entry point for getting a collection backend.
      AZURE_ONLY        -> pure AzureCollection; chroma_factory is NEVER called (no Chroma store opened).
      USE_AZURE_SEARCH  -> DualCollection (Azure read + dual-write).
      otherwise         -> the Chroma collection.
    chroma_factory is a zero-arg callable that creates the Chroma collection, invoked only when needed."""
    if getattr(config, "AZURE_ONLY", False):
        if collection_name not in _WRAP_LOGGED:
            logger.info("[backend] collection '%s' -> AZURE ONLY (Chroma disabled, index '%s')",
                        collection_name, to_index_name(collection_name))
            _WRAP_LOGGED.add(collection_name)
        return AzureCollection(collection_name)
    return wrap_collection(chroma_factory(), collection_name)


def wrap_collection(chroma_collection, collection_name):
    """Return the Chroma collection unchanged, OR (when USE_AZURE_SEARCH) a DualCollection that reads
    Azure and dual-writes. Falls back to Chroma on any wiring error so the live path is never broken."""
    if not getattr(config, "USE_AZURE_SEARCH", False):
        if collection_name not in _WRAP_LOGGED:
            logger.info("[backend] collection '%s' -> CHROMA (USE_AZURE_SEARCH off)", collection_name)
            _WRAP_LOGGED.add(collection_name)
        return chroma_collection
    try:
        dc = DualCollection(chroma_collection, AzureCollection(collection_name))
        if collection_name not in _WRAP_LOGGED:
            logger.info("[backend] collection '%s' -> AZURE read (index '%s') + dual-write to BOTH",
                        collection_name, to_index_name(collection_name))
            _WRAP_LOGGED.add(collection_name)
        return dc
    except Exception:
        logger.exception("[azure] wrap_collection failed, staying on Chroma | %s", collection_name)
        return chroma_collection
