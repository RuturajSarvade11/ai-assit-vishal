"""
Advanced Azure Cognitive Search scenarios using vector embeddings.
Supports vector, hybrid, and semantic search.
"""

import logging
import src.utils.log_setup  # noqa: F401
from typing import Iterator, Dict, Any

from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from azure.search.documents._generated.models import (
    QueryType,
    QueryCaptionType,
    QueryAnswerType,
)

from src.configurations import config
from src.utils.oai_client import create_embedding

from src.azure_search.ai_search_client import upload_document
from src.azure_search.ai_search_index_client_with_embedding import (
    create_example_index_with_embedding
)

logger = logging.getLogger(__name__)


def get_client() -> SearchClient:
    """
    Returns a SearchClient for the configured index.
    """
    return SearchClient(
        endpoint=config.SEARCH_SERVICE_ENDPOINT,
        credential=config.AZURE_CREDENTIAL,
        index_name=config.INDEX_NAME,
    )


def vector_search(query: str) -> Iterator[Dict[str, Any]]:
    """
    Pure vector search.
    """
    logger.debug("Azure Search VECTOR SEARCH | index=%s | k=%d | query=%.80s", config.INDEX_NAME, config.K_NEAREST_NEIGHBORS, query)
    client = get_client()
    vq = VectorizedQuery(
        vector=create_embedding(query),
        k_nearest_neighbors=config.K_NEAREST_NEIGHBORS,
        fields=config.VECTOR_FIELD,
    )

    return client.search(
        search_text=None,
        vector_queries=[vq],
        select=config.SELECT_FIELDS,
    )


def hybrid_search(query: str) -> Iterator[Dict[str, Any]]:
    """
    Hybrid text + vector search.
    """
    logger.debug("Azure Search HYBRID SEARCH | index=%s | k=%d | query=%.80s", config.INDEX_NAME, config.K_NEAREST_NEIGHBORS, query)
    client = get_client()
    vq = VectorizedQuery(
        vector=create_embedding(query),
        k_nearest_neighbors=config.K_NEAREST_NEIGHBORS,
        fields=config.VECTOR_FIELD,
    )

    return client.search(
        search_text=query,
        vector_queries=[vq],
        select=config.SELECT_FIELDS,
    )


def hybrid_semantic_search(query: str) -> Iterator[Dict[str, Any]]:
    """
    Hybrid semantic search with ranking.
    """
    logger.debug("Azure Search HYBRID SEMANTIC SEARCH | index=%s | semantic_config=%s | k=%d | query=%.80s", config.INDEX_NAME, config.SEMANTIC_CONFIG_NAME, config.K_NEAREST_NEIGHBORS, query)
    client = get_client()
    vq = VectorizedQuery(
        vector=create_embedding(query),
        k_nearest_neighbors=config.K_NEAREST_NEIGHBORS,
        fields=config.VECTOR_FIELD,
    )

    return client.search(
        search_text=query,
        vector_queries=[vq],
        select=config.SELECT_FIELDS,
        query_type=QueryType.SEMANTIC,
        semantic_configuration_name=config.SEMANTIC_CONFIG_NAME,
        query_caption=QueryCaptionType.EXTRACTIVE,
        query_answer=QueryAnswerType.EXTRACTIVE,
        top=1,
    )
