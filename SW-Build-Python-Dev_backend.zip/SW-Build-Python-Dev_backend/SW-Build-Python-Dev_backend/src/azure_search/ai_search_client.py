"""
Basic Azure Cognitive Search client utilities.
"""

import logging
import src.utils.log_setup  # noqa: F401
from azure.search.documents import SearchClient
from src.configurations import config

logger = logging.getLogger(__name__)


def upload_document(index_name: str, document: dict) -> None:
    """
    Upload a document to Azure Search index.
    """
    logger.debug("Azure Search UPLOAD | index=%s | document_id=%s", index_name, document.get("error_id") or document.get("id") or "<unknown>")
    client = SearchClient(
        endpoint=config.SEARCH_SERVICE_ENDPOINT,
        credential=config.AZURE_CREDENTIAL,
        index_name=index_name,
    )
    client.upload_documents(documents=[document])


def simple_empty_search(index_name: str):
    """
    Fetch all documents from an index.
    """
    logger.debug("Azure Search SEARCH ALL | index=%s", index_name)
    client = SearchClient(
        endpoint=config.SEARCH_SERVICE_ENDPOINT,
        credential=config.AZURE_CREDENTIAL,
        index_name=index_name,
    )
    results = client.search(search_text="*")
    logger.debug("Azure Search SEARCH ALL | index=%s | results iterator returned", index_name)
    return results
