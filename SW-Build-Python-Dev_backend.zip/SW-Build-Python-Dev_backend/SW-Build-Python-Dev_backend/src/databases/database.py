from functools import lru_cache
import logging

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

import src.utils.log_setup  # noqa: F401 — ensures file handler is attached
from src.configurations import config

logger = logging.getLogger(__name__)

# read_timeout was 5s with 8 retries: a full-table scan page on DynamoDB Local regularly
# needs longer than 5s, so every scan-backed endpoint burned 5s x retries and then 500'd
# (seen on dev: ReadTimeoutError on localhost:8000, pages dead for 30s+). A slow read
# must be allowed to FINISH; retrying a timeout that will time out again only multiplies it.
_BOTO_CONFIG = Config(
    connect_timeout=3,
    read_timeout=60,
    max_pool_connections=300,
    retries={"max_attempts": 3, "mode": "adaptive"},
)


@lru_cache(maxsize=1)
def get_dynamodb_resource(region: str = "", endpoint: str = ""):
    """
    Returns a boto3 DynamoDB resource.
    When endpoint is non-empty (DynamoDB Local) dummy credentials are supplied.
    The region/endpoint parameters are used as cache-key discriminators only;
    values are always read from config at module-import time.
    """
    mode = "local" if config.DYNAMODB_ENDPOINT else "cloud"
    logger.debug(
        "DynamoDB resource init | region=%s | endpoint=%s | mode=%s",
        config.DYNAMODB_REGION,
        config.DYNAMODB_ENDPOINT or "<AWS cloud>",
        mode,
    )
    kwargs = {
        "region_name": config.DYNAMODB_REGION,
        "config": _BOTO_CONFIG,
    }
    if config.DYNAMODB_ENDPOINT:
        kwargs["endpoint_url"] = config.DYNAMODB_ENDPOINT
        kwargs["aws_access_key_id"] = "dummy"
        kwargs["aws_secret_access_key"] = "dummy"
    resource = boto3.resource("dynamodb", **kwargs)
    logger.debug(
        "DynamoDB resource created successfully | region=%s | mode=%s",
        config.DYNAMODB_REGION,
        mode,
    )
    return resource


def _get_resource():
    """Internal helper that calls get_dynamodb_resource with cache-key values."""
    logger.debug(
        "DynamoDB _get_resource | region=%s | endpoint=%s",
        config.DYNAMODB_REGION,
        config.DYNAMODB_ENDPOINT or "<AWS cloud>",
    )
    return get_dynamodb_resource(
        region=config.DYNAMODB_REGION,
        endpoint=config.DYNAMODB_ENDPOINT,
    )


def get_table():
    table_name = "ai_assisted_data" + config.DYNAMODB_TABLE_SUFFIX
    logger.debug("DynamoDB get_table | table_name=%s", table_name)
    dynamodb = _get_resource()
    return dynamodb.Table(table_name)


def get_dynamodb():
    """
    Backward-compatible entrypoint used across the codebase.
    """
    logger.debug("DynamoDB get_dynamodb called")
    return _get_resource()


def test_connection():
    try:
        table = get_table()
        status = table.table_status
        logger.info("DynamoDB connection OK | table=%s | status=%s", table.name, status)
    except ClientError as e:
        logger.error("DynamoDB connection error | %s", e)


def scan_sample(limit=5):
    try:
        table = get_table()
        logger.debug("DynamoDB scan sample | table=%s | limit=%d", table.name, limit)
        response = table.scan(Limit=limit)
        items = response.get("Items", [])
        logger.debug("DynamoDB scan sample | table=%s | items_returned=%d", table.name, len(items))
        for item in items:
            logger.debug("DynamoDB sample item | %s", item)
    except ClientError as e:
        logger.error("DynamoDB scan error | %s", e)


# AI-Assist-Dev

# def get_dynamodb():
#     return boto3.resource(
#         "dynamodb",
#         region_name=AWS_REGION,
#         endpoint_url=DYNAMODB_ENDPOINT,
#         aws_access_key_id="AI-Assist-Dev",
#         aws_secret_access_key="AI-Assist-Dev"
#     )
