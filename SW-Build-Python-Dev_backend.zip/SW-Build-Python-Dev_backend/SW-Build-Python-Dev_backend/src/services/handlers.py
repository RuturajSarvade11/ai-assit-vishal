﻿import json
import uuid
import time
import traceback
import hashlib
import contextvars
from typing import Dict, List, Optional, Any
import os
import base64
import html as html_lib
from src.utils.oai_client import (
    create_embedding,
    chunk_text_by_tokens,
    embedding_token_budget,
    analyze_errors_and_solutions,
    summarize_artifact_content_for_embedding,
    analyze_errors_and_solutions_with_combined_context,
    analyze_with_unified_evidence,
    analyze_and_select_solution_with_unified_evidence,
)
from pdfminer.high_level import extract_text
from openai import RateLimitError, APITimeoutError, APIConnectionError
from src.utils import s3_dedup
from src.utils.payload_archive import get_s3_client, S3_BUCKET, AWS_REGION
from io import BytesIO
from zipfile import ZipFile
from pathlib import Path
from datetime import datetime, timedelta, UTC
from botocore.exceptions import ClientError
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from threading import Lock
import logging
import src.utils.log_setup  # noqa: F401
from werkzeug.utils import secure_filename
import re
from urllib import request as urllib_request

from src.utils.recommended import get_files_by_batch_id, search_similar_errors

from src.utils.project_details import (
    get_all_projects,
    get_total_task,
    get_total_error,
    get_project_solutions,
    get_daily_activity_solutions,
    get_week_sise_count,
    get_graph_projects_data,
    get_solution_id,
    get_diff_files,
    save_final_build_payload,
    touch_final_build_payload,
    save_archived_payload_reference,
    get_archived_payload_references,
    get_archive_references_from_db,
    save_vector_reference,
    get_error_vector_index,
    save_error_vector_index,
    save_error_solution_reference,
    save_fix_instance,
    get_fix_instances,
    touch_error_signature_summary,
    get_error_signature_summary,
    get_error_solution_references_summary_first,
    create_vectorization_status,
    update_vectorization_status,
    get_vectorization_status,
    get_vector_references,
    get_final_build_payload,
    delete_final_build_payload,
    list_request_scoped_items,
    list_request_reference_items,
    list_vector_reference_items_by_vector_id,
    delete_ai_assisted_items,
    delete_binary_metadata_by_batch_id,
    delete_solutions_by_batch_id,
    delete_error_logs,
    list_final_build_payloads_by_project,
    list_project_scoped_items,
    delete_project_row,
    append_final_build_recommendation_hit,
    save_recommendation_outcome,
    save_active_recommendation_context,
    get_recommendation_outcome_summary,
    list_recommendation_outcomes,
    list_recommendation_feedback,
    compact_recommendation_outcomes,
    compact_request_metadata,
    get_storage_health_summary,
    save_maintenance_run_result,
    get_latest_maintenance_run_result,
    ensure_final_build_payload,
    update_project_type_in_final_build,
    update_final_build_resolution_description,
    save_binary_metadata,
    get_artifacts_by_batch_id,
    save_artifact_reference,
    get_artifact_references,
    touch_copilot_session,
    touch_copilot_error_session,
    get_active_copilot_error_session,
    get_active_copilot_error_context,
    get_last_copilot_error_session_for_actor,
    get_copilot_error_archive_index,
    save_copilot_error_archive_index,
    get_active_predict_session,
    touch_predict_session,
    save_predict_result,
    save_prediction_history_report,
    list_prediction_history_reports,
    get_prediction_history_report,
)

from src.utils.recommended import (
    error_embed_budget,
    save_errors_on_vector_db_batch,
    search_similar_errors,
    search_similar_errors_fused,
    search_errors_by_signatures,
    delete_error_vectors,
)
from src.utils.payload_archive import (
    upload_payload_zips,
    download_payload_zip,
    upload_copilot_error_payload_zip,
    list_copilot_error_payload_archives,
    upload_binary_artifact_zip,
    upload_task_runtime_artifact_zip,
    upload_prediction_feature_json,
    list_prediction_feature_archives,
    download_prediction_feature_json,
)
from src.utils.payload_archive import list_payload_archives_for_request
from src.utils.oai_client import (
    create_embedding,
    analyze_errors_and_solutions,
    summarize_artifact_content_for_embedding,
    analyze_errors_and_solutions_with_combined_context,
    analyze_with_unified_evidence,
    analyze_and_select_solution_with_unified_evidence,
)

from src.azure_search.ai_search_index_client_with_embedding import (
    create_example_index_with_embedding
)
from src.configurations import config

logger = logging.getLogger(__name__)

_VECTORIZE_WORKERS = max(1, int(os.getenv("VECTORIZE_WORKERS", "4")))
_vector_executor = ThreadPoolExecutor(
    max_workers=_VECTORIZE_WORKERS,
    thread_name_prefix="vectorize",
)

# Dedicated pool for the FOREGROUND recommendation LLM analysis/selection (each request blocks on
# its future). Kept SEPARATE from background vectorization so that, under many concurrent users,
# recommendations never queue behind background jobs (which would make the LLM budget time out
# while merely waiting for a free worker). The work is I/O-bound (waiting on Azure OpenAI), so a
# generous thread count is cheap. Size it to expected concurrent recommendations.
_RECO_LLM_WORKERS = max(4, int(os.getenv("RECO_LLM_WORKERS", "48")))
_reco_llm_executor = ThreadPoolExecutor(
    max_workers=_RECO_LLM_WORKERS,
    thread_name_prefix="reco-llm",
)
_vector_jobs: Dict[str, object] = {}
_vector_jobs_lock = Lock()
_copilot_archive_workers = max(1, int(os.getenv("COPILOT_ARCHIVE_WORKERS", "2")))
_copilot_archive_executor = ThreadPoolExecutor(
    max_workers=_copilot_archive_workers,
    thread_name_prefix="copilot-archive",
)
_copilot_archive_jobs: Dict[str, object] = {}
_copilot_archive_lock = Lock()
_copilot_report_snapshots: Dict[str, Dict] = {}
_copilot_report_lock = Lock()
_copilot_report_last_by_actor: Dict[str, Dict] = {}
_PHASE2_PATCH_EMBEDDING_MAX = max(0, int(os.getenv("PHASE2_PATCH_EMBEDDING_MAX", "200")))
_PREDICT_SCOPE_MAX_FEATURES = max(20, int(os.getenv("PREDICT_SCOPE_MAX_FEATURES", "200")))
_PREDICT_SCOPE_MAX_FILES = max(10, int(os.getenv("PREDICT_SCOPE_MAX_FILES", "80")))
_PHASE2_FEATURE_VERSION = int(os.getenv("PHASE2_FEATURE_VERSION", "2"))
_PREDICT_STAGE3_THRESHOLD = max(0.0, min(1.0, float(os.getenv("PREDICT_STAGE3_THRESHOLD", "0.80"))))
_PHASE2_SCOPE_MAX_FEATURE_AGE_DAYS = max(0, int(os.getenv("PHASE2_SCOPE_MAX_FEATURE_AGE_DAYS", "730")))
_PHASE2_SCOPE_MIN_PATTERN_LENGTH = max(6, int(os.getenv("PHASE2_SCOPE_MIN_PATTERN_LENGTH", "12")))
_UNIFIED_CONTEXT_DOC_TOP_K = max(1, min(10, int(os.getenv("UNIFIED_CONTEXT_DOC_TOP_K", "3"))))
_UNIFIED_CONTEXT_ARTIFACT_TOP_K = max(1, min(10, int(os.getenv("UNIFIED_CONTEXT_ARTIFACT_TOP_K", "3"))))
_SOLUTION_RELEVANCE_THRESHOLD = max(0.1, min(1.0, float(os.getenv("SOLUTION_RELEVANCE_THRESHOLD", "0.50"))))


def _unique_strings(values: List[str]) -> List[str]:
    out: List[str] = []
    seen = set()
    for value in values or []:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        out.append(text)
    return out



def _delete_s3_keys(keys: List[str]) -> int:
    unique_keys = _unique_strings(keys)
    if not unique_keys:
        return 0
    logger.debug("S3 DELETE objects | bucket=%s | unique_keys_count=%d", S3_BUCKET, len(unique_keys))
    client = get_s3_client()
    deleted = 0
    for index in range(0, len(unique_keys), 1000):
        batch = unique_keys[index:index + 1000]
        client.delete_objects(
            Bucket=S3_BUCKET,
            Delete={"Objects": [{"Key": key} for key in batch], "Quiet": True},
        )
        deleted += len(batch)
    logger.debug("S3 DELETE objects done | bucket=%s | deleted=%d", S3_BUCKET, deleted)
    return deleted


def _delete_request_payload_files(request_id: str) -> List[str]:
    archive_rows = list_payload_archives_for_request(request_id)
    return [str(row.get("s3_key") or "").strip() for row in archive_rows if str(row.get("s3_key") or "").strip()]


def _write_request_tombstone(request_id: str) -> None:
    """Deletion marker, added because a deleted entry kept resurfacing in recommendations.
    A deleted request's VECTOR can survive legitimately (shared signature with other requests),
    and the hydrate backfill used to recreate the deleted row from vector metadata - a zombie.
    The tombstone tells every reader: this request was deliberately deleted, never rebuild it."""
    try:
        from src.utils.project_details import ai_assisted_data_table
        ai_assisted_data_table.put_item(Item={
            "PK": str(request_id), "SK": "TOMBSTONE",
            "deleted_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "expires_at": int(time.time()) + 180 * 24 * 3600,
        })
    except Exception:
        logger.exception("tombstone write failed for request_id=%s", request_id)


def _is_request_tombstoned(request_id: str) -> bool:
    try:
        from src.utils.project_details import ai_assisted_data_table
        return bool(ai_assisted_data_table.get_item(
            Key={"PK": str(request_id or ""), "SK": "TOMBSTONE"}).get("Item"))
    except Exception:
        return False


def _delete_request_data(request_id: str) -> Dict:
    request_id = str(request_id or "").strip()
    if not request_id:
        return {"request_id": request_id, "status": "invalid", "error": "request_id is required"}

    scoped_items = list_request_scoped_items(request_id)
    reference_items = list_request_reference_items(request_id)
    logger.debug("Delete request data | request_id=%s | scoped_items=%d | reference_items=%d", request_id, len(scoped_items), len(reference_items))
    all_items: List[Dict] = []
    seen_item_keys = set()
    for row in scoped_items + reference_items:
        pk = str(row.get("PK") or "")
        sk = str(row.get("SK") or "")
        marker = (pk, sk)
        if pk and sk and marker in seen_item_keys:
            continue
        if pk and sk:
            seen_item_keys.add(marker)
        all_items.append(row)

    payload_keys = _delete_request_payload_files(request_id)
    ai_s3_keys = []
    feature_s3_keys = []
    vector_ids = []
    for row in all_items:
        s3_key = str(row.get("s3_key") or "").strip()
        if s3_key:
            ai_s3_keys.append(s3_key)
        feature_s3_key = str(row.get("feature_s3_key") or "").strip()
        if feature_s3_key:
            feature_s3_keys.append(feature_s3_key)
        vector_id = str(row.get("vector_id") or "").strip()
        if vector_id:
            vector_ids.append(vector_id)

    s3_keys = _unique_strings(payload_keys + ai_s3_keys + feature_s3_keys)
    vector_ids = _unique_strings(vector_ids)
    deletable_vector_ids = []
    for vector_id in vector_ids:
        refs = list_vector_reference_items_by_vector_id(vector_id)
        other_refs = [
            row for row in refs
            if str(row.get("request_id") or "").strip() != request_id
        ]
        if not other_refs:
            deletable_vector_ids.append(vector_id)

    deleted_vectors = 0
    vector_error = ""
    if deletable_vector_ids:
        try:
            deleted_vectors = delete_error_vectors(deletable_vector_ids)
        except Exception as exc:
            vector_error = str(exc)
            logger.exception("Failed deleting vectors for request_id=%s", request_id)

    s3_deleted = 0
    s3_error = ""
    if s3_keys:
        try:
            # Dedup-aware delete: deduplicated objects can be SHARED by several requests, so each
            # key releases its reference first — the object is physically deleted only when this
            # was the last reference. Untracked (pre-dedup) objects delete exactly as before.
            deletable_keys = []
            shared_kept = 0
            for key in s3_keys:
                verdict = s3_dedup.release_key(key)
                if verdict == "keep":
                    shared_kept += 1
                else:
                    deletable_keys.append(key)
            if shared_kept:
                logger.info(
                    "Delete request data | request_id=%s | %d shared S3 object(s) kept (still referenced elsewhere)",
                    request_id, shared_kept,
                )
            s3_deleted = _delete_s3_keys(deletable_keys) if deletable_keys else 0
        except Exception as exc:
            s3_error = str(exc)
            logger.exception("Failed deleting S3 objects for request_id=%s", request_id)

    binary_deleted = 0
    binary_error = ""
    try:
        binary_deleted = delete_binary_metadata_by_batch_id(request_id)
    except Exception as exc:
        binary_error = str(exc)
        logger.exception("Failed deleting binary metadata for request_id=%s", request_id)

    solution_info = {"solutions_deleted": 0, "solution_files_deleted": 0, "solution_ids": []}
    solution_error = ""
    try:
        solution_info = delete_solutions_by_batch_id(request_id)
    except Exception as exc:
        solution_error = str(exc)
        logger.exception("Failed deleting solution rows for request_id=%s", request_id)

    error_logs_deleted = 0
    error_log_error = ""
    try:
        error_logs_deleted = delete_error_logs(
            vector_ids=vector_ids,
            solution_ids=solution_info.get("solution_ids", []),
        )
    except Exception as exc:
        error_log_error = str(exc)
        logger.exception("Failed deleting error logs for request_id=%s", request_id)

    ai_deleted = 0
    ai_error = ""
    try:
        ai_deleted = delete_ai_assisted_items(all_items)
    except Exception as exc:
        ai_error = str(exc)
        logger.exception("Failed deleting ai_assisted_data rows for request_id=%s", request_id)

    final_deleted = False
    final_error = ""
    try:
        final_deleted = delete_final_build_payload(request_id)
    except Exception as exc:
        final_error = str(exc)
        logger.exception("Failed deleting final_build_payload row for request_id=%s", request_id)

    errors = [msg for msg in [vector_error, s3_error, binary_error, solution_error, error_log_error, ai_error, final_error] if msg]
    had_data = bool(all_items or s3_keys or vector_ids or solution_info.get("solution_ids") or final_deleted or binary_deleted)
    if errors and had_data:
        status = "partial_failure"
    elif errors:
        status = "error"
    elif had_data:
        status = "deleted"
    else:
        status = "not_found"

    return {
        "request_id": request_id,
        "status": status,
        "final_build_deleted": bool(final_deleted),
        "ai_assisted_deleted": int(ai_deleted),
        "s3_deleted": int(s3_deleted),
        "vector_deleted": int(deleted_vectors),
        "binary_metadata_deleted": int(binary_deleted),
        "solutions_deleted": int(solution_info.get("solutions_deleted", 0) or 0),
        "solution_files_deleted": int(solution_info.get("solution_files_deleted", 0) or 0),
        "error_logs_deleted": int(error_logs_deleted),
        "s3_keys": len(s3_keys),
        "vector_ids": len(vector_ids),
        "exclusive_vector_ids": len(deletable_vector_ids),
        "errors": errors,
    }


def _copilot_snapshot_key(project_name: str, actor_id: str, client_id: str, workspace_id: str = "") -> str:
    safe_workspace = str(workspace_id or "").strip()
    if safe_workspace:
        return f"{project_name}::{actor_id}::{client_id}::{safe_workspace}"
    return f"{project_name}::{actor_id}::{client_id}"


def _copilot_client_snapshot_key(project_name: str, client_id: str, workspace_id: str = "") -> str:
    safe_workspace = str(workspace_id or "").strip()
    if safe_workspace:
        return f"{project_name}::client::{client_id}::{safe_workspace}"
    return f"{project_name}::client::{client_id}"


def _lookup_live_snapshot_meta(project_name: str, actor_id: str, client_id: str, workspace_id: str = "") -> Dict:
    safe_workspace = str(workspace_id or "").strip()
    with _copilot_report_lock:
        snap = _copilot_report_snapshots.get(_copilot_client_snapshot_key(project_name, client_id, safe_workspace)) or {}
        if not snap:
            snap = _copilot_report_snapshots.get(_copilot_snapshot_key(project_name, actor_id, client_id, safe_workspace)) or {}
        if not snap and safe_workspace:
            snap = _copilot_report_snapshots.get(_copilot_client_snapshot_key(project_name, client_id)) or {}
        if not snap and safe_workspace:
            snap = _copilot_report_snapshots.get(_copilot_snapshot_key(project_name, actor_id, client_id)) or {}
    return snap or {}


def _actor_candidates(actor_id: str) -> List[str]:
    primary = str(actor_id or "global").strip() or "global"
    if primary == "global":
        return ["global"]
    return [primary, "global"]


def _primary_error_from_report_bytes(report_bytes: bytes) -> str:
    try:
        html = (report_bytes or b"").decode("utf-8", errors="ignore")
        errors = extract_errors_from_report_html(html)
        query_candidates = _build_recommendation_query_candidates(errors)
        if query_candidates:
            return str(query_candidates[0]).strip()
        if errors:
            first = errors[0] if isinstance(errors[0], dict) else {}
            return str(first.get("message") or "").strip()
    except Exception:
        return ""
    return ""


def _enqueue_copilot_archive(
    idempotency_key: str,
    project_name: str,
    request_id: str,
    error_message: str,
    actor_id: str,
    client_id: str,
    ttl_hours: int,
):
    if not idempotency_key:
        return

    with _copilot_archive_lock:
        existing = _copilot_archive_jobs.get(idempotency_key)
        if existing is not None and not existing.done():
            return

        def _job():
            try:
                archive_payload = {
                    "uuid": request_id,
                    "project_name": project_name,
                    "error_message": error_message,
                    "source": "vscode-extension",
                    "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
                }
                archive_info = upload_copilot_error_payload_zip(
                    project_name=project_name,
                    request_id=request_id,
                    error_message=error_message,
                    payload=archive_payload,
                )
                try:
                    save_copilot_error_archive_index(
                        project_name=project_name,
                        error_signature=_signature_hash_from_text(error_message),
                        s3_key=archive_info.get("s3_key", ""),
                        canonical_request_id=request_id,
                        ttl_days=180,
                    )
                except Exception:
                    logger.exception(
                        "Failed to save copilot archive dedup index for project=%s request_id=%s",
                        project_name,
                        request_id,
                    )
                touch_copilot_error_session(
                    project_name=project_name,
                    request_id=request_id,
                    error_message=error_message,
                    error_signature=_signature_hash_from_text(error_message),
                    s3_key=archive_info.get("s3_key", ""),
                    actor_id=actor_id,
                    client_id=client_id,
                    ttl_hours=ttl_hours,
                )
            except Exception:
                logger.exception(
                    "Async copilot archive failed for project=%s request_id=%s",
                    project_name,
                    request_id,
                )
            finally:
                with _copilot_archive_lock:
                    _copilot_archive_jobs.pop(idempotency_key, None)

        _copilot_archive_jobs[idempotency_key] = _copilot_archive_executor.submit(_job)

def _invalidate_dashboard_read_cache() -> None:
    """A new/refreshed upload changes what the dashboard lists — drop the short-TTL read
    caches so the new row shows immediately instead of after the TTL. Never fails a write."""
    try:
        from src.utils import ttl_cache
        ttl_cache.invalidate_prefix("solutions")
        ttl_cache.invalidate_prefix("recent")
        ttl_cache.invalidate_prefix("art-summaries")
        ttl_cache.invalidate_prefix("projects_all")
        ttl_cache.invalidate_prefix("graphproj")
        ttl_cache.invalidate_prefix("finalrows")
    except Exception:
        logger.exception("dashboard read-cache invalidation failed (harmless - TTL expiry covers it)")


def _cached_all_projects() -> list:
    """get_all_projects() behind the dashboard TTL cache. The dashboard page calls it from
    several endpoints (project list, groups bar, every group card) and each call was a FULL
    table scan - the page took 30s+. One scan per TTL window now; uploads invalidate."""
    from src.utils import ttl_cache
    return ttl_cache.get_or_compute(
        ("projects_all",), lambda: [p for p in (get_all_projects() or []) if isinstance(p, dict)])


def _cached_graph_projects_data(s_date, c_date):
    """get_graph_projects_data() behind the dashboard TTL cache, keyed by date range - it runs
    TWO full scans per call and the dashboard calls it once per group card plus the graph."""
    from src.utils import ttl_cache
    return ttl_cache.get_or_compute(
        ("graphproj", str(s_date or ""), str(c_date or "")),
        lambda: get_graph_projects_data(s_date, c_date))


def handle_final_build(data: Dict) -> Dict:
    project_name = data.get("projectName")
    task_name = data.get("taskName")
    solution = data.get("solution", [])

    if not project_name:
        raise ValueError("projectName is required")
    if not task_name:
        raise ValueError("taskName is required")
    if not isinstance(solution, list):
        raise ValueError("solution must be an array")

    # NOTE (timestamps in error text): error text is cleaned at READ time
    # (_clean_error_text_for_view on the dashboard endpoints), NOT at storage time — storage-side
    # cleaning would shift the duplicate signatures of new uploads away from every pre-change
    # entry (the signature normalizer tokenizes timestamps; display cleaning deletes them).
    # Read-time cleaning covers OLD rows too, which storage cleaning never could.

    normalized_project_name = str(project_name).strip().lower()
    existing_request_id = _existing_exact_request_id_for_payload(
        payload=data,
        project_name=normalized_project_name,
        env=str(config.APP_ENV or "test").strip().lower() or "test",
    )
    if existing_request_id and (_is_request_tombstoned(existing_request_id)
                                or not get_final_build_payload(existing_request_id)):
        # The matched twin was DELETED (or half-deleted) - treating the upload as a
        # duplicate would resurrect the dead entry via touch. Store it as a fresh request.
        logger.info("handle_final_build | exact match %s is deleted/tombstoned - storing as new",
                    existing_request_id)
        existing_request_id = ""

    if existing_request_id:
        # Refresh the date AND the task: the duplicate just failed on the
        # CURRENT task — the row must say so, or the dashboard and the same-task
        # recommendation boost keep pointing at the task from the original upload.
        touch_final_build_payload(existing_request_id, task_name=str(task_name or ""))
        _invalidate_dashboard_read_cache()
        logger.info(
            "handle_final_build | duplicate request_id=%s | created_date + task refreshed (task=%s)",
            existing_request_id, task_name,
        )
        # The task went green again with the same fix — pending shadow reports of this task can
        # still be judged against it (idempotent: already-judged reports are skipped).
        _enqueue_shadow_judging(normalized_project_name, str(task_name), solution, existing_request_id)
        _enqueue_recommendation_accuracy(normalized_project_name, str(task_name), solution, existing_request_id)
        return {
            "message": "Final build payload already exists",
            "request_id": existing_request_id,
            "status": True,
            "prediction_features_count": 0,
            "prediction_feature_keys": [],
        }

    request_id = str(uuid.uuid4())
    save_final_build_payload(request_id=request_id, payload=data)
    _invalidate_dashboard_read_cache()
    prediction_features = _store_patch_prediction_features(
        payload=data,
        project_name=normalized_project_name,
        request_id=request_id,
    )

    # Shadow judging (roadmap step B): this upload IS the task's fix — compare it against the
    # silent shadow predictions captured at failure time for the same task.
    _enqueue_shadow_judging(normalized_project_name, str(task_name), solution, request_id)
    # Ground truth for the recommendation: was this fix what we recommended for this task?
    _enqueue_recommendation_accuracy(normalized_project_name, str(task_name), solution, request_id)

    return {
        "message": "Final build payload stored successfully",
        "request_id": request_id,
        "status": True,
        "prediction_features_count": len(prediction_features),
        "prediction_feature_keys": [x.get("s3_key") for x in prediction_features],
    }


def _enqueue_recommendation_accuracy(project_name: str, task_name: str, solution, request_id: str) -> None:
    """Fire-and-forget: rank this uploaded fix inside the latest recommendation for the same
    task (Hit@1/Hit@3 ground truth). Never blocks or fails the upload path."""
    try:
        from src.services import recommendation_accuracy
        recommendation_accuracy.enqueue_evaluation(project_name, task_name, solution, request_id)
    except Exception:
        logger.exception("recommendation accuracy enqueue failed | project=%s", project_name)


def _enqueue_shadow_judging(project_name: str, task_name: str, solution, request_id: str) -> None:
    """Fire-and-forget shadow judging (step B): compare pending shadow reports of this task with
    the uploaded fix on a background thread. Never blocks or fails the upload path."""
    def _run():
        try:
            from src.services import shadow_judge
            shadow_judge.judge_for_upload(project_name, task_name, solution, request_id)
        except Exception:
            logger.exception("shadow judging failed | project=%s | task=%s", project_name, task_name)
    import threading
    threading.Thread(target=_run, name="shadow-judge", daemon=True).start()


def handle_upload_precheck(data: Dict) -> Dict:
    """Duplicate pre-check the extension calls BEFORE opening the confirm webview
    (storage proposal §7). The extension sends the same shape as /final-build plus
    optional artifactFingerprints (cleaned-content fingerprints of the collected
    artifacts). The decision stays fully on the server:

      - skip_upload=True only when the error+solution combination is already stored
        AND every supplied artifact fingerprint is already known for that request.
      - Any doubt (no fingerprints supplied, legacy rows without fingerprints, any
        error) answers skip_upload=False, so the popup opens as today — fail-open,
        a pre-check problem can never cause data loss.
    """
    try:
        if not isinstance(data, dict):
            return {"status": True, "duplicate": False, "skip_upload": False}

        project_name = str(data.get("projectName") or "").strip().lower()
        if not project_name:
            return {"status": True, "duplicate": False, "skip_upload": False}

        existing_request_id = _existing_exact_request_id_for_payload(
            payload=data,
            project_name=project_name,
            env=str(config.APP_ENV or "test").strip().lower() or "test",
        )
        if not existing_request_id:
            return {"status": True, "duplicate": False, "skip_upload": False}

        supplied = data.get("artifactFingerprints")
        if supplied is None:
            supplied = data.get("artifact_fingerprints")
        if not isinstance(supplied, list):
            # Field absent: artifacts cannot be verified — popup must open.
            return {
                "status": True,
                "duplicate": True,
                "request_id": existing_request_id,
                "artifacts_all_known": False,
                "skip_upload": False,
            }

        known_fps = set()
        for row in (
            get_archive_references_from_db(existing_request_id)
            + get_artifact_references(existing_request_id, "binary")
            + get_artifact_references(existing_request_id, "runtime")
        ):
            fp = str((row or {}).get("content_fingerprint") or "").strip()
            if fp:
                known_fps.add(fp)

        supplied_fps = [str(x or "").strip() for x in supplied if str(x or "").strip()]
        artifacts_all_known = all(fp in known_fps for fp in supplied_fps)

        return {
            "status": True,
            "duplicate": True,
            "request_id": existing_request_id,
            "artifacts_all_known": artifacts_all_known,
            "skip_upload": artifacts_all_known,
        }
    except Exception as exc:
        logger.warning("handle_upload_precheck failed — answering fail-open | %s", exc)
        return {"status": True, "duplicate": False, "skip_upload": False, "reason": "precheck_error"}


def handle_update_final_build_resolution_description(request_id: str, description: str | None) -> Dict:
    updated = update_final_build_resolution_description(
        request_id=request_id,
        description=(str(description).strip() if isinstance(description, str) and str(description).strip() else None),
    )
    if not updated:
        return {
            "status": False,
            "message": "Final build payload not found",
            "request_id": request_id,
        }
    return {
        "status": True,
        "message": "Resolution description updated successfully",
        "request_id": request_id,
        "resolutionDescription": (str(description).strip() if isinstance(description, str) and str(description).strip() else None),
    }


def _extract_error_messages(payload: Dict, include_context: bool = False) -> List[str]:
    messages: List[str] = []

    def _walk(node):
        if isinstance(node, dict):
            for key, value in node.items():
                if key == "errorDetails" and isinstance(value, list):
                    file_context = (
                        node.get("filePath")
                        or node.get("path")
                        or node.get("fileName")
                        or node.get("file_name")
                        or ""
                    )
                    task_context = (
                        node.get("taskName")
                        or node.get("requestedTasks")
                        or ""
                    )
                    for err in value:
                        if isinstance(err, dict):
                            msg = err.get("message")
                            if msg:
                                msg_text = str(msg)
                                messages.append(msg_text)
                                if include_context:
                                    if file_context:
                                        messages.append(f"{file_context} | {msg_text}")
                                    if task_context:
                                        messages.append(f"{task_context} | {msg_text}")
                        elif isinstance(err, str):
                            messages.append(err)
                            if include_context:
                                if file_context:
                                    messages.append(f"{file_context} | {err}")
                                if task_context:
                                    messages.append(f"{task_context} | {err}")
                else:
                    _walk(value)
        elif isinstance(node, list):
            for item in node:
                _walk(item)

    _walk(payload)
    return messages


def _normalize_error_message(msg: str) -> str:
    return " ".join((msg or "").split()).strip().lower()


def _safe_doc_text(value) -> str:
    """Convert a ChromaDB document field to a clean string.
    Guards against Python None and the string 'None' produced by str(None)
    in older code paths where documents= was not passed to collection.add().
    """
    if value is None:
        return ""
    text = str(value).strip()
    return "" if text == "None" else text


def _normalize_signature_text(value: str) -> str:
    text = (value or "").replace("\r", "")
    text = text.lower()
    text = re.sub(r"\b[0-9a-f]{8}-[0-9a-f-]{27,}\b", "<uuid>", text)
    text = re.sub(
        r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\s+\d{1,2},\s+\d{4}\s+\d{1,2}:\d{2}:\d{2}\s+(?:am|pm)\b",
        "<datetime>",
        text,
    )
    text = re.sub(
        r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\s+\d{1,2},\s+\d{4}\b",
        "<date>",
        text,
    )
    # Fix: allow optional Z or +HH:MM timezone suffix so ISO timestamps like
    # 15:00:46Z or 15:00:46+05:30 are fully consumed (old \b failed on these).
    text = re.sub(r"\b\d{1,2}:\d{2}:\d{2}(?:\.\d+)?(?:z|[+-]\d{2}:\d{2})?", "<time>", text)
    text = re.sub(r"\b(?:am|pm)\b", "", text)
    text = re.sub(r"\b\d{4}-\d{2}-\d{2}\b", "<date>", text)
    # Durations, bracketed "[4] ms" (GBE snapshot lines) and bare "248 ms": without this the
    # SAME error hashed differently between a [4] ms and a [7] ms run, so the
    # exact-identity stage never fired on re-collected errors.
    text = re.sub(r"\[\s*\d+(?:[.,]\d+)?\s*\]\s*(?:ms|msec|millis|milliseconds|secs?|seconds|mins?|minutes|hrs?|hours|[smh])\b", "<dur>", text)
    text = re.sub(r"\b\d+(?:\.\d+)?\s?(?:ms|msec|millis|milliseconds|secs?|seconds|mins?|minutes|hrs?|hours|[smh])\b", "<dur>", text)
    # Normalize Java/Kotlin/Groovy stack trace line numbers e.g. AramisInfo.java:46
    text = re.sub(r"\b(\w+\.(?:java|kt|scala|groovy)):\d+", r"\1:<line>", text)
    text = re.sub(r"[a-z]:[\\/][^\s\"']+", "<path>", text)
    text = re.sub(r"/[^\s\"']+", "<path>", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _signature_hash_from_text(value: str) -> str:
    normalized = _normalize_signature_text(value)
    if not normalized:
        return ""
    return hashlib.sha1(normalized.encode("utf-8")).hexdigest()


def _solution_signature_hash_from_payload(payload: Dict) -> str:
    """Solution identity for the STORAGE decision (approved storage doc, Section 6 / Table 5):
    a solution counts as 'already stored' ONLY when it is 100% identical — a plain checksum
    over the exact content, no cleaning. Even a whitespace-only difference is a different
    solution and is stored as its own version; the cleaned checksum applies to ERROR and
    ARTIFACT identity only. sort_keys is JSON serialization stability (dict key ORDER is not
    content) — the values are hashed untouched. sha256 (64 hex) also distinguishes these
    hashes from the legacy normalized sha1 (40 hex) stored on old reference rows, which are
    recomputed exactly at comparison time in _existing_exact_solution_request_id."""
    if not isinstance(payload, dict):
        return ""
    solution = payload.get("solution", [])
    if not isinstance(solution, list) or not solution:
        return ""
    # Hash the solution in its STORED canonical form. The persisted
    # payload strips derived context (per-changeObject `patch`, per-file snapshotBefore/After
    # - archived to S3, recomputable), so hashing the incoming payload WITH those fields made
    # incoming-hash != stored-hash for the very same solution and the duplicate check never
    # fired (every re-upload minted a new row). Content lines/files remain hashed untouched -
    # a whitespace difference in the fix itself is still a different solution.
    def _canon_item(item):
        if not isinstance(item, dict):
            return item
        out = {k: v for k, v in item.items() if k not in ("snapshotBefore", "snapshotAfter")}
        objs = out.get("changeObjects")
        if isinstance(objs, list):
            out["changeObjects"] = [
                ({k: v for k, v in o.items() if k != "patch"} if isinstance(o, dict) else o)
                for o in objs
            ]
        return out

    canonical_solution = [_canon_item(i) for i in solution]
    try:
        canonical = json.dumps(canonical_solution, sort_keys=True, ensure_ascii=False,
                               separators=(",", ":"), default=str)
    except Exception:
        canonical = str(canonical_solution)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _existing_exact_solution_request_id(
    project_name: str,
    env: str,
    error_hash: str,
    solution_signature_hash: str,
    current_request_id: str = "",
) -> str:
    if not error_hash or not solution_signature_hash:
        return ""

    refs = get_error_solution_references_summary_first(project_name, env, error_hash) or []
    for row in refs:
        req_id = str(row.get("request_id") or "").strip()
        if not req_id or req_id == current_request_id:
            continue

        existing_signature = str(row.get("solution_signature_hash") or "").strip()
        if len(existing_signature) != 64:
            # Empty, or a legacy normalized sha1 (40 hex) from before the exact-checksum
            # rule: recompute the exact hash from the stored payload so old rows keep
            # deduplicating byte-identical re-uploads instead of silently never matching.
            existing_payload_row = get_final_build_payload(req_id) or {}
            existing_payload = existing_payload_row.get("payload_json") if isinstance(existing_payload_row, dict) else {}
            if not isinstance(existing_payload, dict):
                existing_payload = existing_payload_row if isinstance(existing_payload_row, dict) else {}
            existing_signature = _solution_signature_hash_from_payload(existing_payload)

        if existing_signature == solution_signature_hash:
            return req_id

    return ""


def _existing_exact_request_id_for_payload(
    payload: Dict,
    project_name: str,
    env: str,
) -> str:
    if not isinstance(payload, dict):
        return ""

    solution_signature_hash = _solution_signature_hash_from_payload(payload)
    if not solution_signature_hash:
        return ""

    incoming_candidates = _extract_error_messages(payload, include_context=False)
    incoming_hashes = set(_signature_hashes_from_candidates(incoming_candidates))
    if not incoming_hashes:
        return ""

    for row in list_final_build_payloads_by_project(project_name):
        existing_payload = row.get("payload_json") if isinstance(row, dict) else {}
        if not isinstance(existing_payload, dict):
            continue

        existing_request_id = str(row.get("request_id") or "").strip()
        existing_solution_hash = _solution_signature_hash_from_payload(existing_payload)
        if existing_solution_hash != solution_signature_hash:
            continue

        existing_candidates = _extract_error_messages(existing_payload, include_context=False)
        if not existing_candidates and existing_request_id:
            for archive_row in get_archived_payload_references(existing_request_id):
                s3_key = str(archive_row.get("s3_key") or "").strip()
                if not s3_key:
                    continue
                try:
                    archive_payload = download_payload_zip(
                        s3_key=s3_key,
                        expected_sha256=archive_row.get("sha256"),
                    )
                except Exception:
                    continue
                existing_candidates.extend(_extract_error_messages(archive_payload, include_context=False))

        existing_hashes = set(_signature_hashes_from_candidates(existing_candidates))
        if existing_hashes and existing_hashes == incoming_hashes:
            return existing_request_id
    return ""





def _is_duplicate_exact_archive_payload(
    payload: Dict,
    request_id: str | None,
    project_name: str,
    env: str,
) -> bool:
    """No longer used by handle_archive_payload: the signature-only comparison discarded
    freshly collected content (stale-artifact bug). Archive dedup is now per-file by
    cleaned-content fingerprint inside upload_payload_zips. Kept for the pre-check API."""
    req_id = str(request_id or "").strip()
    if not req_id or not isinstance(payload, dict):
        return False

    current_payload_row = get_final_build_payload(req_id) or {}
    current_payload = current_payload_row.get("payload_json") if isinstance(current_payload_row, dict) else {}
    if not isinstance(current_payload, dict):
        current_payload = current_payload_row if isinstance(current_payload_row, dict) else {}

    solution_signature_hash = _solution_signature_hash_from_payload(current_payload)
    if not solution_signature_hash:
        return False

    raw_messages = _extract_error_messages(payload, include_context=True)
    messages = _prepare_messages_for_vectorization(raw_messages)
    if not messages:
        return False

    found_exact_duplicate = False
    for msg in messages:
        error_hash = _signature_hash_from_text(msg)
        if not error_hash:
            return False
        duplicate_request_id = _existing_exact_solution_request_id(
            project_name=project_name,
            env=env,
            error_hash=error_hash,
            solution_signature_hash=solution_signature_hash,
            current_request_id=req_id,
        )
        if not duplicate_request_id:
            return False
        found_exact_duplicate = True

    return found_exact_duplicate


def _candidate_message_for_signature(candidate: str) -> str:
    value = (candidate or "").strip()
    if not value:
        return ""

    if " | " in value:
        left, right = value.split(" | ", 1)
        left_low = left.lower()
        if (
            "\\" in left
            or "/" in left
            or left_low.startswith(":targets:")
            or left_low.endswith(".kts")
            or left_low.endswith(".gradle")
        ):
            return right.strip()
    return value


def _signature_hashes_from_candidates(candidates: List[str], max_hashes: int = 10) -> List[str]:
    hashes: List[str] = []
    seen = set()
    for candidate in candidates:
        base = _candidate_message_for_signature(candidate)
        digest = _signature_hash_from_text(base)
        if not digest or digest in seen:
            continue
        seen.add(digest)
        hashes.append(digest)
        if len(hashes) >= max_hashes:
            break
    return hashes


# --- Strong error collection (block mode) ------------------------------------
# When VECTOR_BLOCK_MODE is enabled, one focused failure block is kept as a single
# embedding unit (no per-line fragmentation) and split only when it exceeds the
# embedding model's real capacity. Non-failure blocks (timing/status noise such as
# "dummy1 finished in 80 ms") are rejected before they can become signatures.
# Default off => the existing per-line path below is used unchanged.

_FAILURE_SIGNAL_TOKENS = (
    "error", "fail", "exception", "cannot", "could not", "couldn't", "unable",
    "no such", "not found", "missing", "denied", "fatal", "what went wrong",
    "caused by", "severe", "traceback", "undefined", "unresolved", "invalid",
    "refused", "timeout", "timed out", "aborted", "exec returned",
)

_NOISE_LINE_RE = re.compile(
    r"^(?:"
    r".*\bfinished in\b.*"            # "dummy1 finished in 80 ms"
    r"|build successful.*"
    r"|build succeeded.*"
    r"|build up-to-date.*"
    r"|\d+\s+actionable tasks?.*"
    r"|> task\b.*"                    # gradle task progress lines
    r"|[\d\s:.,msh]+"                 # pure numbers / durations
    r")$",
    re.IGNORECASE,
)


def _vector_block_mode_enabled() -> bool:
    return os.getenv("VECTOR_BLOCK_MODE", "0").strip().lower() in ("1", "true", "yes", "on")


def _reco_global_fallback_enabled() -> bool:
    """Whether recommendation evidence (errors, documents, artifacts) may fall back to a
    cross-project query when the project-scoped search is empty. Default off => strictly
    project-name-wise recommendations. Set ERROR_RECO_GLOBAL_FALLBACK=1 to restore the
    old cross-project behavior."""
    return os.getenv("ERROR_RECO_GLOBAL_FALLBACK", "0").strip().lower() in ("1", "true", "yes", "on")


def _is_real_failure_text(text: str) -> bool:
    """True if the text looks like a genuine failure, False for timing/status noise.

    Conservative by design: a block is rejected only when every non-empty line is
    recognizable noise, so real errors are never dropped.
    """
    s = (text or "").strip()
    if not s:
        return False
    if any(tok in s.lower() for tok in _FAILURE_SIGNAL_TOKENS):
        return True
    for raw_line in s.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if not _NOISE_LINE_RE.match(line):
            return True  # at least one non-noise line -> keep
    return False


def _chunk_block_on_line_boundaries(text: str, budget_tokens: int) -> List[str]:
    """Split an oversized block into chunks at line boundaries that each fit the embedding
    model's TOKEN budget, every line kept in order. One chunk = one vector, so the whole error
    is embedded and stored however long it is; nothing is cut to fit."""
    return chunk_text_by_tokens(text, budget_tokens)


def _prepare_message_blocks_for_vectorization(messages: List[str], max_messages: int) -> List[str]:
    """Block mode: one focused failure block -> one embedding unit + one signature.

    Step 1: no per-line fragmentation. Step 2: chunk only when over the embedding
    budget. Step 3: reject non-failure blocks before they become signatures.
    """
    # The model's token budget, the same one the embedder is given (error_embed_budget), so a
    # chunk made here is embedded whole there.
    budget = error_embed_budget()[2] or embedding_token_budget()
    out: List[str] = []
    seen = set()
    for msg in messages:
        if not msg:
            continue
        focused = _maybe_focus(str(msg)).strip()
        if not focused or not _is_real_failure_text(focused):
            continue
        for chunk in _chunk_block_on_line_boundaries(focused, budget):
            norm = _normalize_error_message(chunk)
            if not norm or norm in seen:
                continue
            seen.add(norm)
            out.append(chunk)
            if len(out) >= max_messages:
                return out
    return out


def _prepare_messages_for_vectorization(messages: List[str]) -> List[str]:
    """
    Reduce noisy/repetitive build logs to root-cause oriented messages for embeddings.
    Keeps high-signal lines and collapses repeated AccessDenied copy failures.
    """
    max_messages = max(1, int(os.getenv("VECTOR_MAX_MESSAGES", "25")))
    if _vector_block_mode_enabled():
        return _prepare_message_blocks_for_vectorization(messages, max_messages)
    lines: List[str] = []
    for msg in messages:
        if not msg:
            continue
        focused = _maybe_focus(str(msg))
        for raw_line in focused.splitlines():
            s = raw_line.strip()
            if s:
                lines.append(s)

    if not lines:
        return []

    copy_denied_re = re.compile(
        r"\[copy\]\s*Failed to copy\s+(?P<src>\S+)\s+to\s+(?P<dst>\S+)\s+due to\s+java\.nio\.file\.AccessDeniedException\s+(?P<denied>\S+)",
        re.IGNORECASE,
    )
    in_root_re = re.compile(r"^(?P<prefix>.*?/tmp/pda/[^/]+/in)(?:/.*)?$", re.IGNORECASE)

    copy_clusters: Dict[str, int] = {}
    root_examples: Dict[str, str] = {}
    signal_lines: List[str] = []
    seen_signal = set()
    for line in lines:
        m = copy_denied_re.search(line)
        if m:
            dst = (m.group("dst") or "").replace("\\", "/")
            denied = (m.group("denied") or "").replace("\\", "/")
            root_key = denied
            in_match = in_root_re.match(dst)
            if in_match:
                root_key = in_match.group("prefix")
            copy_clusters[root_key] = copy_clusters.get(root_key, 0) + 1
            root_examples.setdefault(root_key, dst)
            continue

        lower = line.lower()
        # ONE definition of "this line reports a failure", shared with the ranking tiers through
        # _line_has_failure_marker. There were two, and they disagreed: this path tested four
        # Gradle phrasings ("build failed", "exec returned:", "accessdeniedexception", "an error
        # has occurred") while the artifact comparison used a much broader set that already
        # included "not recognized", "no such", "denied", "errno" and the rest.
        #
        # A toolchain failing any other way matched none of the four, and the fallback below then
        # kept the WHOLE log. A recorded case: "'ech' is not recognized as an internal or external
        # command" fell through, so twenty lines of build progress were embedded with it, and
        # three unrelated failures came back at an identical 0.67 similarity. Of the 2,138
        # characters compared, 2,129 were the same for every build of that task.
        #
        # The shared check also cleans volatile text first, so a project folder called
        # "Build type error" cannot make every line read as a failure.
        if _line_has_failure_marker(line) or lower.endswith(".log.") or lower.endswith(".log"):
            norm = _normalize_error_message(line)
            if norm not in seen_signal:
                seen_signal.add(norm)
                signal_lines.append(line)

    compact: List[str] = []
    for root, count in sorted(copy_clusters.items(), key=lambda x: x[1], reverse=True):
        compact.append(
            f"[copy] AccessDeniedException while copying files to `{root}` (occurrences: {count})"
        )
        if len(compact) >= max_messages:
            break

    for line in signal_lines:
        if len(compact) >= max_messages:
            break
        compact.append(line)

    if compact:
        return compact

    # Fallback: keep unique normalized lines in order.
    out: List[str] = []
    seen = set()
    for line in lines:
        norm = _normalize_error_message(line)
        if norm in seen:
            continue
        seen.add(norm)
        out.append(line)
        if len(out) >= max_messages:
            break
    return out


def _extract_task_paths(payload: Dict) -> List[str]:
    task_paths: List[str] = []

    def _walk(node):
        if isinstance(node, dict):
            direct_task_path = str(node.get("taskPath") or "").strip()
            if direct_task_path:
                task_paths.append(direct_task_path)

            locations = node.get("locations")
            if isinstance(locations, list):
                for loc in locations:
                    if not isinstance(loc, dict):
                        continue
                    loc_task_path = str(loc.get("taskPath") or "").strip()
                    if loc_task_path:
                        task_paths.append(loc_task_path)

            fallback_task = str(node.get("taskName") or node.get("requestedTasks") or "").strip()
            if fallback_task:
                task_paths.append(fallback_task)

            for value in node.values():
                _walk(value)
        elif isinstance(node, list):
            for item in node:
                _walk(item)

    _walk(payload)

    out: List[str] = []
    seen = set()
    for value in task_paths:
        key = value.lower()
        if not value or key in seen:
            continue
        seen.add(key)
        out.append(value)
    return out


def _normalize_token(value: str) -> str:
    return re.sub(r"[^a-z0-9_]+", "", str(value or "").strip().lower())


# A command name inside quotes, however short. Toolchains name the thing that failed this way -
# 'ech' is not recognized, 'cp' not found - and the quoted word is the ONE part of such a line that
# is not shared by every other error of the same shape. Taken first, so a 16-token budget spent on
# the surrounding boilerplate cannot crowd it out.
_QUOTED_TOKEN_RE = re.compile(r"['\"`]([A-Za-z][A-Za-z0-9_.+-]{0,15})['\"`]")


def _extract_config_tokens(*values: str, limit: int = 16) -> List[str]:
    """Tokens that identify a failure, rarest-carrying first.

    The general pattern asks for four characters or more. That threshold dropped exactly the words
    that identify a failing command - ech, cp, ls, gcc - while keeping every generic word around
    them: "recognized", "internal", "external", "command" appear in every Windows not-recognized
    error, so what survived could not tell two such failures apart. A recorded case had the one
    distinguishing word, ech, discarded for being three letters.

    So: three characters or more generally, and a quoted word of any length, which is how a
    toolchain names the thing that failed. Common words still get through; they cost nothing,
    because the artifact comparison weights a token by how rare it is and a word in every record
    is worth almost zero.
    """
    tokens: List[str] = []
    seen = set()
    pattern = re.compile(r"[A-Z_]{3,}|[a-zA-Z][a-zA-Z0-9_.-]{2,}")
    for value in values:
        text = str(value or "")
        for raw in _QUOTED_TOKEN_RE.findall(text) + pattern.findall(text):
            token = _normalize_token(raw)
            if not token or token in seen:
                continue
            seen.add(token)
            tokens.append(token)
            if len(tokens) >= limit:
                return tokens
    return tokens


def _change_fingerprint(file_name: str, task_path: str, tokens: List[str]) -> str:
    base = "|".join(
        [
            _normalize_token(file_name),
            _normalize_token(task_path),
            ",".join(sorted(tokens[:12])),
        ]
    )
    return hashlib.sha1(base.encode("utf-8")).hexdigest()


def _finalize_request_vectors(request_id: str) -> Dict:
    archived = get_archived_payload_references(request_id)
    if not archived:
        return {"vectorized": False, "vectors": []}

    current_payload_row = get_final_build_payload(request_id) or {}
    current_payload = current_payload_row.get("payload_json") if isinstance(current_payload_row, dict) else {}
    if not isinstance(current_payload, dict):
        current_payload = current_payload_row if isinstance(current_payload_row, dict) else {}
    current_solution_signature_hash = _solution_signature_hash_from_payload(current_payload)

    vector_items: List[Dict] = []
    output_vectors: List[Dict] = []
    write_items: List[Dict] = []
    vector_index_cache: Dict[tuple, Dict] = {}
    duplicate_solution_cache: Dict[tuple, str] = {}
    summary_cache: Dict[tuple, Dict] = {}
    signature_env_cache: Dict[tuple, str] = {}

    for row in archived:
        payload = download_payload_zip(
            s3_key=row["s3_key"],
            expected_sha256=row.get("sha256"),
        )

        project_name = row.get("project_name") or "unknown-project"
        env = row.get("env") or "test"
        s3_key = row.get("s3_key")
        file_name = row.get("file_name") or "unknown-file"
        raw_messages = _extract_error_messages(payload, include_context=True)
        messages = _prepare_messages_for_vectorization(raw_messages)
        # Diagnostic: confirm whether block mode was actually effective for this store.
        # If block_mode=False here, the env var is not reaching the vectorization process.
        logger.info(
            "[STORE-DEBUG] vectorization | request_id=%s | VECTOR_BLOCK_MODE_env=%r | block_mode=%s | "
            "raw_messages=%d | prepared_messages=%d | first_prepared=%.160s",
            request_id,
            os.getenv("VECTOR_BLOCK_MODE"),
            _vector_block_mode_enabled(),
            len(raw_messages),
            len(messages),
            (str(messages[0]) if messages else "").replace("\n", " "),
        )
        task_paths = _extract_task_paths(payload)
        primary_task_path = task_paths[0] if task_paths else ""

        for idx, msg in enumerate(messages):
            normalized = _normalize_error_message(msg)
            if not normalized:
                continue

            error_signature_hash = _signature_hash_from_text(msg)
            # Env drift guard: keep every signature in the env family where
            # its rows already live, so an APP_ENV change never splits the store.
            signature_env = env
            if error_signature_hash:
                env_key = (project_name, env, error_signature_hash)
                if env_key not in signature_env_cache:
                    signature_env_cache[env_key] = _resolve_signature_env(project_name, env, error_signature_hash)
                signature_env = signature_env_cache[env_key]
            existing_vector_id = ""
            if error_signature_hash:
                cache_key = (project_name, signature_env, error_signature_hash)
                if cache_key not in vector_index_cache:
                    vector_index_cache[cache_key] = get_error_vector_index(project_name, signature_env, error_signature_hash) or {}
                existing_vector_id = str((vector_index_cache.get(cache_key) or {}).get("vector_id") or "").strip()

            duplicate_solution_request_id = ""
            if error_signature_hash and current_solution_signature_hash:
                dup_key = (project_name, signature_env, error_signature_hash, current_solution_signature_hash)
                if dup_key not in duplicate_solution_cache:
                    duplicate_solution_cache[dup_key] = _existing_exact_solution_request_id(
                        project_name=project_name,
                        env=signature_env,
                        error_hash=error_signature_hash,
                        solution_signature_hash=current_solution_signature_hash,
                        current_request_id=request_id,
                    )
                duplicate_solution_request_id = duplicate_solution_cache.get(dup_key) or ""

            vector_id = existing_vector_id or ("err-" + hashlib.sha1(
                f"{request_id}|{s3_key}|{idx}|{normalized}".encode("utf-8")
            ).hexdigest()[:40])
            logger.info("[dup-debug] WRITE sig=%s index_hit=%s vector_id=%s project=%s env=%s req=%s",
                        (error_signature_hash or "")[:16], bool(existing_vector_id),
                        vector_id, project_name, env, request_id)

            if not existing_vector_id:
                vector_items.append({
                    "vector_id": vector_id,
                    "project_name": project_name,
                    "error_message": msg,
                    "error_signature_hash": error_signature_hash,
                    "all_solution": json.dumps(
                        {
                            "request_id": request_id,
                            "s3_key": s3_key,
                            "file_name": file_name,
                        },
                        separators=(",", ":"),
                    ),
                    "batch_id": request_id,
                    "request_id": request_id,
                    "s3_key": s3_key,
                    "file_name": file_name,
                    "task_path": primary_task_path,
                })

                output_vectors.append({
                    "vector_id": vector_id,
                    "s3_key": s3_key,
                    "file_name": file_name,
                    "error_message": msg,
                    "project_name": project_name,
                    "env": signature_env,
                    "error_signature_hash": error_signature_hash,
                    "task_path": primary_task_path,
                })

            write_items.append({
                "vector_id": vector_id,
                "s3_key": s3_key,
                "file_name": file_name,
                "error_message": msg,
                "project_name": project_name,
                "env": signature_env,
                "error_signature_hash": error_signature_hash,
                "task_path": primary_task_path,
                "solution_signature_hash": current_solution_signature_hash,
                "skip_embedding_write": bool(existing_vector_id),
                "duplicate_solution_request_id": duplicate_solution_request_id,
            })

    if vector_items:
        save_errors_on_vector_db_batch(vector_items)

    for item in write_items:
        try:
            if not item.get("skip_embedding_write"):
                save_vector_reference(
                    request_id=request_id,
                    vector_id=item["vector_id"],
                    project_name=item["project_name"],
                    env=item["env"],
                    s3_key=item["s3_key"],
                    file_name=item["file_name"],
                    error_signature_hash=str(item.get("error_signature_hash") or ""),
                )

            error_hash = str(item.get("error_signature_hash") or "").strip()
            if not error_hash:
                continue

            if not item.get("skip_embedding_write"):
                try:
                    save_error_vector_index(
                        project_name=item["project_name"],
                        env=item["env"],
                        error_hash=error_hash,
                        error_message=item["error_message"],
                        vector_id=item["vector_id"],
                    )
                except ClientError as err:
                    if err.response.get("Error", {}).get("Code", "") != "ConditionalCheckFailedException":
                        raise

            if item.get("duplicate_solution_request_id"):
                identity = (item["project_name"], item["env"], error_hash)
                if identity not in summary_cache:
                    summary_cache[identity] = get_error_signature_summary(item["project_name"], item["env"], error_hash) or {}
                summary = summary_cache.get(identity) or {}
                touch_error_signature_summary(
                    project_name=item["project_name"],
                    env=item["env"],
                    error_hash=error_hash,
                    task_path=str(summary.get("latest_task_path") or item.get("task_path") or ""),
                    request_id=str(summary.get("latest_request_id") or item.get("duplicate_solution_request_id") or ""),
                    file_name=str(summary.get("latest_file_name") or item.get("file_name") or ""),
                    new_solution_reference=False,
                )
                continue

            inserted = save_error_solution_reference(
                project_name=item["project_name"],
                env=item["env"],
                error_hash=error_hash,
                request_id=request_id,
                s3_key=item["s3_key"],
                file_name=item["file_name"],
                task_path=item.get("task_path", ""),
                solution_signature_hash=str(item.get("solution_signature_hash") or ""),
            )
            touch_error_signature_summary(
                project_name=item["project_name"],
                env=item["env"],
                error_hash=error_hash,
                task_path=item.get("task_path", ""),
                request_id=request_id,
                file_name=item["file_name"],
                new_solution_reference=bool(inserted),
            )
        except ClientError as err:
            if err.response.get("Error", {}).get("Code", "") != "ConditionalCheckFailedException":
                raise

    return {
        "vectorized": bool(vector_items),
        "vectors": output_vectors,
    }

_KNOWN_SIGNATURE_ENVS = ("test", "dev", "prod")


def _resolve_signature_env(project_name: str, current_env: str, error_hash: str) -> str:
    """Env family an error signature's index/summary rows ALREADY live under.

    The signature tables are keyed by (project, env) where env was config.APP_ENV at
    upload time. When APP_ENV changes on a running install (for example rows stored
    under ('testgbe','test') while the service now runs 'dev'), a plain
    current-env lookup misses the existing family and the same error would be stored
    AGAIN under the new env - duplicate vectors, split history/feedback. Resolve to
    the family that already has rows; brand-new signatures stay on the current env.
    """
    if not error_hash:
        return current_env
    try:
        if get_error_vector_index(project_name, current_env, error_hash) or \
           get_error_signature_summary(project_name, current_env, error_hash):
            return current_env
        for legacy in _KNOWN_SIGNATURE_ENVS:
            if legacy == current_env:
                continue
            if get_error_vector_index(project_name, legacy, error_hash) or \
               get_error_signature_summary(project_name, legacy, error_hash):
                logger.info(
                    "[ENV-RESOLVE] signature %s lives under env=%s (service env=%s) - keeping its family",
                    error_hash[:16], legacy, current_env,
                )
                return legacy
    except Exception:
        logger.exception("resolve signature env failed - using current env")
    return current_env


def _run_vectorization_job(request_id: str):
    try:
        update_vectorization_status(
            request_id=request_id,
            status="in_progress",
            vector_count=0,
            last_error="",
        )
        result = _finalize_request_vectors(request_id)
        update_vectorization_status(
            request_id=request_id,
            status="completed",
            vector_count=len(result.get("vectors", [])),
            last_error="",
        )
    except Exception as exc:
        logger.exception("Vectorization failed for request_id=%s", request_id)
        try:
            update_vectorization_status(
                request_id=request_id,
                status="failed",
                vector_count=0,
                last_error=str(exc),
            )
        except Exception:
            logger.exception("Failed to persist vectorization error status for request_id=%s", request_id)
    finally:
        with _vector_jobs_lock:
            _vector_jobs.pop(request_id, None)


def _enqueue_vectorization(request_id: str, force: bool = False) -> str:
    current_status = get_vectorization_status(request_id)
    state = (current_status or {}).get("status")

    if state in {"queued", "in_progress"}:
        return state
    if state == "completed" and not force:
        return state
    if state == "failed" and not force:
        return state

    if current_status is None:
        created = create_vectorization_status(request_id=request_id, status="queued")
        if not created:
            latest = get_vectorization_status(request_id)
            if latest and latest.get("status"):
                state = latest.get("status")
                if state in {"queued", "in_progress", "completed"} and not force:
                    return state
    else:
        update_vectorization_status(
            request_id=request_id,
            status="queued",
            vector_count=0,
            last_error="",
        )

    with _vector_jobs_lock:
        fut = _vector_jobs.get(request_id)
        if fut is not None and not fut.done():
            return "in_progress"
        _vector_jobs[request_id] = _vector_executor.submit(_run_vectorization_job, request_id)

    return "queued"


def _run_prediction_features_job(payload: Dict, project_name: str, request_id: str) -> None:
    """Background worker for patch prediction-feature embedding. Best-effort: it must never
    affect the archive-store result. Runs the embedding work off the request path so a slow
    or unauthenticated LLM endpoint cannot block or fail a storage upload."""
    try:
        features = _store_patch_prediction_features(
            payload=payload,
            project_name=project_name,
            request_id=request_id,
        )
        logger.info(
            "prediction-features job done | request_id=%s | features=%d",
            request_id, len(features),
        )
    except Exception:
        logger.exception(
            "prediction-features job failed (best-effort; upload already stored) | request_id=%s",
            request_id,
        )


def _enqueue_prediction_features(payload: Dict, project_name: str, request_id: str) -> None:
    """Submit prediction-feature embedding to the background pool so /archive-payload returns
    as soon as S3 + DynamoDB are done. Storage (must-succeed) is decoupled from embeddings
    (best-effort, deferred)."""
    try:
        _vector_executor.submit(_run_prediction_features_job, payload, project_name, request_id)
    except Exception:
        logger.exception("Failed to enqueue prediction-features job | request_id=%s", request_id)


def handle_archive_payload(
    data: Dict,
    request_id: str | None = None,
    is_last: bool = False,
    sync_finalize: bool = False,
    force_finalize: bool = False,
    developer_id: str = "",
) -> Dict:
    if not isinstance(data, dict):
        raise ValueError("Invalid JSON body")

    project_name = data.get("projectName")
    if not isinstance(project_name, str) or not project_name.strip():
        project_name = "unknown-project"
    else:
        project_name = project_name.strip().lower()
    data["projectName"] = project_name

    project_type = data.get("projectType")
    if not isinstance(project_type, str) or not project_type.strip():
        project_type = ""
    else:
        project_type = project_type.strip().lower()

    storage_env = str(config.APP_ENV or "test").strip().lower() or "test"
    existing = get_archive_references_from_db(request_id) if request_id else []

    # Storage rule: duplicates are decided per FILE by cleaned-content
    # fingerprint, not by the error+solution signature. Only files whose content is
    # already stored for this request are skipped; new content under a known file name
    # is ADDED as a new version (the old signature-based skip threw fresh content away —
    # the stale-artifact bug). skip_archive_save keeps its meaning: nothing new stored.
    archive_info = upload_payload_zips(
        payload=data,
        project_name=project_name,
        request_id=request_id,
        existing_refs=existing if request_id else None,
    )
    skip_archive_save = (
        bool(request_id)
        and not archive_info["items"]
        and bool(archive_info.get("skipped_files"))
    )

    saved_files = []
    if skip_archive_save:
        logger.info(
            "Duplicate archive payload — all %d file(s) already stored for request_id=%s project=%s",
            len(archive_info.get("skipped_files") or []),
            archive_info["request_id"],
            project_name,
        )
    if archive_info["items"]:
        # Ensure request_id -> solution payload exists in final_build_payload, even if /final-build was skipped.
        if isinstance(data.get("solution"), list):
            ensure_final_build_payload(request_id=archive_info["request_id"], payload=data)
            # This path can CREATE the final-build row when /final-build
            # was skipped - the dashboards must see it immediately, same as the direct path.
            _invalidate_dashboard_read_cache()

        for item in archive_info["items"]:
            try:
                save_archived_payload_reference(
                    request_id=item["request_id"],
                    project_name=item["project_name"],
                    env=item["env"],
                    file_name=item["file_name"],
                    file_key_name=item["file_key_name"],
                    s3_bucket=item["s3_bucket"],
                    s3_key=item["s3_key"],
                    sha256=item["sha256"],
                    etag=item["etag"],
                    compressed_size=item["compressed_size"],
                    created_date=item["created_date"],
                    project_type=project_type,
                    developer_id=developer_id,
                    content_fingerprint=item.get("content_fingerprint", ""),
                )
            except ClientError as err:
                code = err.response.get("Error", {}).get("Code", "")
                if code != "ConditionalCheckFailedException":
                    raise
            saved_files.append({
                "file_name": item["file_name"],
                "s3_key": item["s3_key"],
            })

    all_files_map = {
        (f.get("file_name"), f.get("s3_key")): {
            "file_name": f.get("file_name"),
            "s3_key": f.get("s3_key"),
        }
        for f in existing
    }
    for f in saved_files:
        all_files_map[(f["file_name"], f["s3_key"])] = f
    all_files = list(all_files_map.values())

    # Stamp projectType on final_build_payload so /get-all-projects can surface it.
    if project_type and archive_info.get("request_id"):
        try:
            update_project_type_in_final_build(archive_info["request_id"], project_type)
        except Exception:
            pass

    # Phase-2 feature archival (best-effort, no impact on the storage path). Runs even for
    # duplicate archive payloads so we can backfill missing prediction-features.
    # ENTERPRISE DECOUPLING: this is embedding work (LLM-dependent). It is offloaded to a
    # background thread so the archive store (S3 + DynamoDB) returns immediately and is never
    # blocked or failed by slow / rate-limited / unauthenticated embeddings. The payload is a
    # plain parsed dict (not request-bound), so it is safe to use after this handler returns.
    _enqueue_prediction_features(
        payload=data,
        project_name=project_name,
        request_id=archive_info["request_id"],
    )

    finalize_result = {
        "vectorized": False,
        "vectors": [],
        "vectorization_status": "not_requested",
    }

    # When is_last=True and the payload is a duplicate (skip_archive_save), we still
    # need to (re-)trigger vectorization if the previous run produced vector_count=0
    # or ended in a failed state — this handles repeated POST /archive-payload/{id}/1
    # calls where the first run raced ahead before runtime artifacts were ready.
    if is_last and skip_archive_save:
        req_id = archive_info["request_id"]
        status_row = get_vectorization_status(req_id) or {}
        prior_status = status_row.get("status")
        prior_count = int(status_row.get("vector_count") or 0)
        if prior_status in {None, "failed"} or (prior_status == "completed" and prior_count == 0):
            logger.info(
                "handle_archive_payload | duplicate payload but vectorization needs retry | "
                "request_id=%s | prior_status=%s | prior_vector_count=%d",
                req_id, prior_status, prior_count,
            )
            state = _enqueue_vectorization(req_id, force=True)
            status_row = get_vectorization_status(req_id) or {}
            vectors = get_vector_references(req_id) if state == "completed" else []
            finalize_result = {
                "vectorized": state == "completed",
                "vectors": vectors,
                "vectorization_status": status_row.get("status", state),
                "vector_count": status_row.get("vector_count", len(vectors)),
                "vectorization_error": status_row.get("last_error", ""),
            }

    if is_last and not skip_archive_save:
        req_id = archive_info["request_id"]

        if sync_finalize:
            try:
                if not create_vectorization_status(request_id=req_id, status="in_progress"):
                    update_vectorization_status(
                        request_id=req_id,
                        status="in_progress",
                        vector_count=0,
                        last_error="",
                    )
                finalize_result = _finalize_request_vectors(req_id)
                finalize_result["vectorization_status"] = "completed"
                update_vectorization_status(
                    request_id=req_id,
                    status="completed",
                    vector_count=len(finalize_result.get("vectors", [])),
                    last_error="",
                )
            except Exception as exc:
                # Archive path must remain successful even if downstream vectorization fails.
                finalize_result = {
                    "vectorized": False,
                    "vectors": [],
                    "vectorization_status": "failed",
                    "vectorization_error": str(exc),
                }
                try:
                    update_vectorization_status(
                        request_id=req_id,
                        status="failed",
                        vector_count=0,
                        last_error=str(exc),
                    )
                except Exception:
                    logger.exception("Failed to persist sync vectorization status for request_id=%s", req_id)
        else:
            state = _enqueue_vectorization(req_id, force=force_finalize)
            status_row = get_vectorization_status(req_id) or {}
            vectors = get_vector_references(req_id) if state == "completed" else []
            finalize_result = {
                "vectorized": state == "completed",
                "vectors": vectors,
                "vectorization_status": status_row.get("status", state),
                "vector_count": status_row.get("vector_count", len(vectors)),
                "vectorization_error": status_row.get("last_error", ""),
            }

    return {
        "status": True,
        "message": "Payload compressed and stored successfully",
        "request_id": archive_info["request_id"],
        "projectName": archive_info["project_name"],
        "projectType": project_type,
        "env": archive_info["env"],
        "files": all_files,
        "prediction_features_count": 0,
        "prediction_feature_keys": [],
        "prediction_features_status": "queued",
        **finalize_result,
    }


def handle_upload_health_check() -> Dict:
    import time
    try:
        client = get_s3_client()
        t0 = time.monotonic()
        client.head_bucket(Bucket=S3_BUCKET)
        latency_ms = int((time.monotonic() - t0) * 1000)
        return {"s3_ok": True, "bucket": S3_BUCKET, "latency_ms": latency_ms}
    except Exception as exc:
        return {"s3_ok": False, "bucket": S3_BUCKET, "error": str(exc)}


def handle_retry_archive_payload(
    data: Dict,
    request_id: str,
    developer_id: str = "",
) -> Dict:
    if not isinstance(data, dict):
        raise ValueError("Invalid JSON body")
    if not str(request_id or "").strip():
        raise ValueError("request_id is required for retry")

    project_name = data.get("projectName")
    if not isinstance(project_name, str) or not project_name.strip():
        project_name = "unknown-project"
    else:
        project_name = project_name.strip().lower()
    data["projectName"] = project_name

    project_type = data.get("projectType") or ""
    if isinstance(project_type, str):
        project_type = project_type.strip().lower()

    logger.info(
        "handle_retry_archive_payload | request_id=%s | project=%s",
        request_id, project_name,
    )

    # Same content-fingerprint dedup as the normal archive path: a retry never
    # overwrites stored zips and never re-stores content that is already there.
    archive_info = upload_payload_zips(
        payload=data,
        project_name=project_name,
        request_id=request_id,
        existing_refs=get_archive_references_from_db(request_id),
    )

    saved_files = []
    for item in archive_info["items"]:
        try:
            save_archived_payload_reference(
                request_id=item["request_id"],
                project_name=item["project_name"],
                env=item["env"],
                file_name=item["file_name"],
                file_key_name=item["file_key_name"],
                s3_bucket=item["s3_bucket"],
                s3_key=item["s3_key"],
                sha256=item["sha256"],
                etag=item["etag"],
                compressed_size=item["compressed_size"],
                created_date=item["created_date"],
                project_type=project_type,
                developer_id=developer_id,
                content_fingerprint=item.get("content_fingerprint", ""),
            )
        except ClientError as err:
            code = err.response.get("Error", {}).get("Code", "")
            if code != "ConditionalCheckFailedException":
                raise
        saved_files.append({"file_name": item["file_name"], "s3_key": item["s3_key"]})

    return {
        "status": True,
        "message": "Retry upload completed",
        "request_id": archive_info["request_id"],
        "files_uploaded": len(saved_files),
        "files": saved_files,
    }


def _store_patch_prediction_features(payload: Dict, project_name: str, request_id: str) -> List[Dict]:
    out: List[Dict] = []
    if _PHASE2_PATCH_EMBEDDING_MAX <= 0:
        return out
    # Context radius from the dashboard config (admin-set) so NEW patches use the SAME window size as
    # the live scan in the extension. Falls back to 10; already-stored patches are unchanged.
    try:
        from src.services import prediction_config as _pc
        _ctx_radius = int(_pc.get_config().get("contextWindow", 10))
        if not (5 <= _ctx_radius <= 100):
            _ctx_radius = 10
    except Exception:
        _ctx_radius = 10
    try:
        solution = payload.get("solution")
        if not isinstance(solution, list):
            return out
        task_paths = _extract_task_paths(payload)
        primary_task_path = task_paths[0] if task_paths else str(payload.get("taskName") or payload.get("requestedTasks") or "").strip()

        processed = 0
        for file_item in solution:
            if processed >= _PHASE2_PATCH_EMBEDDING_MAX:
                break
            if not isinstance(file_item, dict):
                continue
            file_name = str(file_item.get("fileName") or file_item.get("filePath") or "N/A").strip() or "N/A"
            file_path = str(file_item.get("filePath") or file_name).strip() or file_name
            # A file marked "deleted" here is a FIX-SIDE deletion (action="deleted"/DELETED_ prefix) —
            # deleting a file is NOT the failure cause. The failure-causing "deletion" is the file the
            # fix RE-ADDS (its absence broke the build), and that is captured by the normal "add" path
            # below. So skip fix-side deletions: don't embed their removed content as failure features
            # (saves Azure calls + storage, and avoids wrong-side noise).
            _del = str(file_item.get("action") or file_item.get("fileStatus")
                       or file_item.get("changeType") or "").strip().lower()
            if file_name.startswith("DELETED_") or file_path.startswith("DELETED_") or "delet" in _del:
                logger.info("prediction-features: skipping fix-side deleted file=%s (not the failure cause)", file_name)
                continue
            change_objects = file_item.get("changeObjects")
            if not isinstance(change_objects, list):
                continue

            # Change A: build snapshot line array for 21-line context window embeddings.
            # Prefer the per-file snapshot; fall back to the top-level payload snapshot
            # when its path matches this file (covers the common single-file payload case).
            snapshot_lines: List[str] = []
            per_file_snap = file_item.get("snapshotBefore")
            if isinstance(per_file_snap, dict) and per_file_snap.get("content"):
                snap_content = str(per_file_snap["content"])
                snapshot_lines = snap_content.replace("\r\n", "\n").split("\n")
            else:
                top_snap = payload.get("snapshotBefore")
                if isinstance(top_snap, dict) and top_snap.get("content"):
                    snap_path = str(top_snap.get("path") or "").strip().lower().replace("\\", "/")
                    item_path = file_path.strip().lower().replace("\\", "/")
                    if not snap_path or snap_path == item_path:
                        snap_content = str(top_snap["content"])
                        snapshot_lines = snap_content.replace("\r\n", "\n").split("\n")

            # Change B: build a lookup of clean fixed-line text from MOD_AFTER change
            # objects in this file so it can be embedded into before-records at write time.
            after_patch_lookup: Dict[tuple, str] = {}
            for _co in change_objects:
                if not isinstance(_co, dict):
                    continue
                if str(_co.get("riskSide") or "").strip().lower() != "after":
                    continue
                if _phase2_change_kind(str(_co.get("change") or "")) != "modify_after":
                    continue
                _co_line = int(_co.get("line") or 0)
                _co_hunk = int(_co.get("hunk") or 0)
                _clean = _phase2_normalize_pattern_text(str(_co.get("change") or ""))
                _clean = re.sub(r"^\s*\[MOD_AFTER\]\s*", "", _clean).strip()
                if _clean and _co_line > 0:
                    after_patch_lookup[(_co_line, _co_hunk)] = _clean

            for change_obj in change_objects:
                if processed >= _PHASE2_PATCH_EMBEDDING_MAX:
                    break
                if not isinstance(change_obj, dict):
                    continue

                change_id = str(change_obj.get("id") or "").strip()
                line = int(change_obj.get("line") or 0)
                hunk = int(change_obj.get("hunk") or 0)
                change_text = str(change_obj.get("change") or "").strip()
                patch_text = str(change_obj.get("patch") or "").strip()
                risk_side = str(change_obj.get("riskSide") or "").strip().lower()
                if not change_id:
                    fallback_raw = f"{file_path}|{line}|{hunk}|{change_text}|{risk_side or 'unknown'}"
                    change_id = hashlib.sha1(fallback_raw.encode("utf-8")).hexdigest()

                normalized_risk_side = risk_side if risk_side in {"before", "after"} else _phase2_default_risk_side(change_text)

                if not patch_text:
                    patch_text = _phase2_normalize_pattern_text(change_text)

                # Change C: strip [MOD_AFTER] prefix from after-records so the stored
                # patch field is clean and consistent with the before-record format.
                if normalized_risk_side == "after":
                    patch_text = re.sub(r"^\s*\[MOD_AFTER\]\s*", "", patch_text).strip()

                # Change A: context window = the admin-configured radius (lines before & after the
                # changed line) so the vector geometry matches what Stage 3 builds in the extension.
                if snapshot_lines and line > 0:
                    _ctx_start = max(0, line - 1 - _ctx_radius)
                    _ctx_end = min(len(snapshot_lines), line + _ctx_radius)
                    embedding_input = "\n".join(snapshot_lines[_ctx_start:_ctx_end])
                else:
                    embedding_input = patch_text
                embedding: List[float] = []
                if embedding_input:
                    try:
                        embedding = create_embedding(embedding_input, request_id=request_id)
                        logger.info(
                            "Patch embedding generated request_id=%s change_id=%s risk_side=%s dim=%s",
                            request_id,
                            change_id,
                            normalized_risk_side,
                            len(embedding) if isinstance(embedding, list) else 0,
                        )
                    except Exception:
                        logger.exception(
                            "Failed patch embedding for request_id=%s change_id=%s risk_side=%s; storing feature without embedding",
                            request_id,
                            change_id,
                            normalized_risk_side,
                        )

                feature_payload = {
                    "request_id": request_id,
                    "project_name": project_name,
                    "file_name": file_name,
                    "file_path": file_path,
                    "change_id": change_id,
                    "line": line,
                    "hunk": hunk,
                    "change": change_text,
                    "patch": patch_text,
                    "risk_side": normalized_risk_side,
                    "context_window": embedding_input,
                    "patch_embedding": embedding,
                    "model_name": str(config.EMBEDDING_MODEL or ""),
                    "feature_version": _PHASE2_FEATURE_VERSION,
                    "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    # Change B: store the expected fixed line text directly in the
                    # before-record so Stage 3 can use it without a runtime JOIN.
                    "after_patch": after_patch_lookup.get((line, hunk), "") if normalized_risk_side == "before" else "",
                }
                try:
                    stored = upload_prediction_feature_json(
                        project_name=project_name,
                        request_id=request_id,
                        change_id=change_id,
                        payload=feature_payload,
                    )
                    out.append(stored)
                    logger.info(
                        "Patch embedding stored request_id=%s change_id=%s risk_side=%s s3_key=%s",
                        request_id,
                        change_id,
                        normalized_risk_side,
                        stored.get("s3_key"),
                    )
                    config_tokens = _extract_config_tokens(file_name, file_path, primary_task_path, change_text, patch_text)
                    try:
                        save_fix_instance(
                            request_id=request_id,
                            change_id=change_id,
                            project_name=project_name,
                            env=str(stored.get("env") or ""),
                            risk_side=normalized_risk_side,
                            task_path=primary_task_path,
                            file_name=file_name,
                            file_path=file_path,
                            feature_s3_key=str(stored.get("s3_key") or ""),
                            patch_hash=hashlib.sha1(patch_text.encode("utf-8")).hexdigest(),
                            change_fingerprint=_change_fingerprint(file_name, primary_task_path, config_tokens),
                            config_tokens=config_tokens,
                            created_date=str(stored.get("created_date") or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")),
                        )
                    except ClientError as err:
                        if err.response.get("Error", {}).get("Code", "") != "ConditionalCheckFailedException":
                            raise
                    processed += 1
                except Exception:
                    logger.exception(
                        "Failed storing patch feature to S3 request_id=%s change_id=%s",
                        request_id,
                        change_id,
                    )
                    continue
    except Exception:
        logger.exception("Patch prediction feature extraction failed request_id=%s", request_id)
    return out


def handle_get_archived_payload(request_id: str) -> Dict:
    records = get_archived_payload_references(request_id)
    if not records:
        return {
            "status": True,
            "request_id": request_id,
            "files": [],
            "message": "No detailed payload available for this request"
        }

    files = []
    for record in records:
        payload = download_payload_zip(
            s3_key=record["s3_key"],
            expected_sha256=record.get("sha256"),
        )
        files.append({
            "file_name": record.get("file_name"),
            "s3_key": record.get("s3_key"),
            "payload": payload,
        })

    return {
        "status": True,
        "request_id": request_id,
        "projectName": records[0].get("project_name"),
        "env": records[0].get("env"),
        "files": files,
    }


def handle_get_vectorization_status(request_id: str) -> Dict:
    status_row = get_vectorization_status(request_id)
    if not status_row:
        return {
            "status": False,
            "error": "request_id not found",
        }

    state = status_row.get("status", "unknown")
    vectors = get_vector_references(request_id) if state == "completed" else []
    return {
        "status": True,
        "request_id": request_id,
        "vectorization_status": state,
        "vector_count": status_row.get("vector_count", len(vectors)),
        "vectorization_error": status_row.get("last_error", ""),
        "vectors": vectors,
    }


# UPLOAD_DIR = "./uploads"
# os.makedirs(UPLOAD_DIR, exist_ok=True)
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # src/routes
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, "..", ".."))
UPLOAD_DIR = os.path.join(PROJECT_ROOT, "uploads")

os.makedirs(UPLOAD_DIR, exist_ok=True)
REPORT_DIR = os.path.join(UPLOAD_DIR, "recommendation_reports")
os.makedirs(REPORT_DIR, exist_ok=True)
MCP_REPORT_DIR = os.path.join(UPLOAD_DIR, "mcp_reports")
os.makedirs(MCP_REPORT_DIR, exist_ok=True)
_mcp_upload_lock = Lock()
_mcp_upload_state: Dict[str, Dict] = {}
_MCP_UPLOAD_TTL_SEC = 24 * 60 * 60


def handle_binary_store(data: dict) -> dict:
    """
    MCP SAFE VERSION (JSON only)

    Expected:
    {
        "uuid": "...",
        "metadata": [...],
        "files": [
            {"filename": "...", "content": "<base64>"}
        ]
    }
    """

    batch_id = data.get("uuid")
    request_id = str(data.get("request_id") or "").strip()
    metadata_list = data.get("metadata", [])
    files = data.get("files", [])

    if not batch_id:
        return {"error": "uuid required"}

    logger.debug("handle_binary_store | batch_id=%s | files_count=%d", batch_id, len(files))
    metadata_map = {}
    for m in metadata_list:
        if not isinstance(m, dict):
            continue
        key = str(m.get("fileName") or "").strip()
        if key:
            metadata_map[key] = m

    stored_files = []
    project_name = str(data.get("project_name") or "").strip().lower()

    for f in files:
        filename = secure_filename(f["filename"])
        content = base64.b64decode(f["content"])
        meta = metadata_map.get(filename, {})
        if not meta and filename.startswith("DELETED_"):
            meta = metadata_map.get(filename[len("DELETED_"):], {})
        action = str(meta.get("action") or "modified")
        archive = upload_binary_artifact_zip(
            batch_id=batch_id,
            file_name=str(meta.get("originalFileName") or filename),
            file_bytes=content,
            action=action,
            project_name=project_name,
        )
        stored_files.append(archive.get("s3_key"))
        if request_id and archive.get("s3_key"):
            save_artifact_reference(
                request_id=request_id,
                file_name=archive.get("file_name") or filename,
                s3_key=archive.get("s3_key"),
                s3_bucket=config.S3_BUCKET,
                artifact_type="binary",
                evidence_eligible=not _artifact_claimed_by_another_solution(
                    project_name, request_id, content, filename),
            )
        try:
            save_binary_metadata(
                batch_id=batch_id,
                file_name=archive.get("file_name") or filename,
                file_path=str(meta.get("filePath") or filename),
                action=action,
                stored_path=archive.get("s3_key", ""),
                s3_key=archive.get("s3_key"),
                payload_sha256=archive.get("payload_sha256"),
                zip_sha256=archive.get("zip_sha256"),
                payload_size=archive.get("payload_size"),
                compressed_size=archive.get("compressed_size"),
                project_name=project_name,
            )
        except Exception:
            pass

    return {
        "message": "Files stored successfully",
        "batch_id": batch_id,
        "stored_files": stored_files
    }


def handle_task_runtime_artifacts(data: dict) -> dict:
    batch_id = data.get("uuid")
    request_id = str(data.get("request_id") or "").strip()
    metadata_list = data.get("metadata", [])
    files = data.get("files", [])

    if not batch_id:
        return {"error": "uuid required"}

    logger.debug("handle_task_runtime_artifacts | batch_id=%s | files_count=%d", batch_id, len(files))
    metadata_map = {}
    for m in metadata_list:
        if not isinstance(m, dict):
            continue
        key = str(m.get("fileName") or "").strip()
        if key:
            metadata_map[key] = m

    stored_files = []
    project_name = str(data.get("project_name") or "").strip().lower()

    for f in files:
        filename = secure_filename(f["filename"])
        content = base64.b64decode(f["content"])
        meta = metadata_map.get(filename, {})
        if not meta and filename.startswith("DELETED_"):
            meta = metadata_map.get(filename[len("DELETED_"):], {})
        action = str(meta.get("action") or "modified")
        archive = upload_task_runtime_artifact_zip(
            batch_id=batch_id,
            file_name=str(meta.get("originalFileName") or filename),
            file_bytes=content,
            action=action,
            project_name=project_name,
            source_folder=str(meta.get("sourceFolder") or ""),
            task_path=str(meta.get("taskPath") or ""),
        )
        stored_files.append(archive.get("s3_key"))
        if request_id and archive.get("s3_key"):
            save_artifact_reference(
                request_id=request_id,
                file_name=archive.get("file_name") or filename,
                s3_key=archive.get("s3_key"),
                s3_bucket=config.S3_BUCKET,
                artifact_type="runtime",
                evidence_eligible=not _artifact_claimed_by_another_solution(
                    project_name, request_id, content, filename),
            )
        try:
            save_binary_metadata(
                batch_id=batch_id,
                file_name=archive.get("file_name") or filename,
                file_path=str(meta.get("filePath") or filename),
                action=action,
                stored_path=archive.get("s3_key", ""),
                s3_key=archive.get("s3_key"),
                payload_sha256=archive.get("payload_sha256"),
                zip_sha256=archive.get("zip_sha256"),
                payload_size=archive.get("payload_size"),
                compressed_size=archive.get("compressed_size"),
                source_folder=str(meta.get("sourceFolder") or ""),
                task_path=str(meta.get("taskPath") or ""),
                project_name=project_name,
            )
        except Exception:
            pass

    if request_id and stored_files:
        try:
            _enqueue_vectorization(request_id, force=True)
            logger.debug(
                "handle_task_runtime_artifacts | re-enqueued vectorization | request_id=%s | files=%d",
                request_id, len(stored_files),
            )
        except Exception:
            logger.exception(
                "handle_task_runtime_artifacts | failed to re-enqueue vectorization | request_id=%s", request_id
            )

    return {
        "message": "Runtime artifacts stored successfully",
        "batch_id": batch_id,
        "stored_files": stored_files,
    }



def handle_get_projects() -> Dict:
    # All-projects list with each project's resolved groupType joined in (dashboard spec point #3:
    # existing fields unchanged, one new property "groupType"). _pg_dashboard_projects is defined below.
    return {
        "projects": _pg_dashboard_projects(),
        "success": True
    }


# ======================= Dashboard grouped view (SEPARATE from the admin panel) =======================
# Read-only endpoints that power the home dashboard's grouped project cards. They reflect the SAME
# groups the admin configures (dynamic model) and include "Other". Kept separate from the admin CRUD
# APIs below. Response uses `groupType` = the group's name.

def _sort_projects_recent(projects: List[dict]) -> List[dict]:
    return sorted(projects, key=lambda p: _parse_created_date(p.get("last_analysis")), reverse=True)


def _pg_dashboard_projects() -> List[dict]:
    """get_all_projects() with each project's resolved group attached as `groupType` (dynamic model)."""
    from src.services import project_groups as _pg
    projects = _cached_all_projects()
    gmap = _pg.build_group_map([p.get("project_name") for p in projects if p.get("project_name")])
    for p in projects:
        p["groupType"] = gmap.get(p.get("project_name"), _pg.DEFAULT_GROUP)
    return projects


def _pg_group_order(projects: List[dict]) -> List[str]:
    """Groups ordered by MOST-RECENT activity first (group with the newest last_analysis on top),
    with 'Other' always pinned last. Inactive/empty defined groups sort after active ones (by name)."""
    from src.services import project_groups as _pg
    recent: Dict[str, str] = {}
    for p in projects:
        g = p.get("groupType")
        if not g or g == _pg.DEFAULT_GROUP:
            continue
        la = str(p.get("last_analysis") or "")
        if g not in recent or la > recent[g]:
            recent[g] = la
    groups = {d["group_name"] for d in _pg.list_group_defs() if d["group_name"] != _pg.DEFAULT_GROUP}
    groups.update(recent.keys())
    ordered = sorted(groups, key=lambda g: g.lower())                    # name asc (tie-breaker)
    ordered = sorted(ordered, key=lambda g: recent.get(g, ""), reverse=True)  # then recent desc (stable)
    ordered.append(_pg.DEFAULT_GROUP)                                    # 'Other' always last
    return ordered


def handle_project_group_summary() -> Dict:
    """GET /project-groups/summary — every group (defined + Other) with its project count."""
    projects = _pg_dashboard_projects()
    counts: Dict[str, int] = {}
    for p in projects:
        g = p.get("groupType")
        counts[g] = counts.get(g, 0) + 1
    data = [{"groupType": g, "count": counts.get(g, 0)} for g in _pg_group_order(projects)]
    return {"success": True, "data": data, "message": "Success"}


def handle_projects_by_group(group_type: str, limit: int = 0, search: str = "") -> Dict:
    """GET /project-groups/projects — projects in a group, newest first. limit<=0 = all (View All).
    search = case-insensitive substring on project name, applied BEFORE limit (so a limited call
    returns the first matches, not matches within the first N). With search given and groupType
    empty, matches across ALL groups (dashboard-wide search); without search the existing
    group-scoped behavior is unchanged."""
    target = str(group_type or "").strip()
    needle = str(search or "").strip().lower()
    rows = _pg_dashboard_projects()
    if target or not needle:
        rows = [p for p in rows if p.get("groupType") == target]
    if needle:
        rows = [p for p in rows if needle in str(p.get("project_name") or "").lower()]
    rows = _sort_projects_recent(rows)
    if limit and limit > 0:
        rows = rows[:limit]
    return {"success": True, "data": rows, "message": "Success"}


def handle_grouped_dashboard(limit: int = 4) -> Dict:
    """GET /project-groups/dashboard — every group (+ Other) with its project COUNT only (no projects).
    Per the dashboard flow: this is the single group-summary call; the UI then fetches each group's 4
    cards via /project-groups/projects?groupType=<g>&limit=4 (and no limit for View All)."""
    projects = _pg_dashboard_projects()
    counts: Dict[str, int] = {}
    for p in projects:
        g = p.get("groupType")
        counts[g] = counts.get(g, 0) + 1
    data = [{"groupType": g, "count": counts.get(g, 0)} for g in _pg_group_order(projects)]
    return {"success": True, "data": data, "message": "Success"}


def handle_graph_data(from_date=None, to_date=None, group_name=None, project_name=None,
                      page_number=None, page_size=None, group_by=None) -> Dict:
    """Dashboard graph: per-project error/recommended counts for a date range, optionally filtered to a
    group. Date filter is always applied (defaults to last 7 days). groupName omitted or "ALL" => all
    projects; otherwise only projects resolved to that group. projectName narrows further to that ONE
    project (filtering the chart to a single project is not possible with groups alone).
    Includes a summary + optional pagination."""
    if not from_date or not to_date:
        to_date = datetime.now().strftime("%Y-%m-%d")
        from_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")

    # get_graph_projects_data returns {date_range, summary, projects:[...]} (the /graph/projects
    # shape) — the per-project rows live under "projects". Iterating the dict directly yields its
    # KEYS (strings), which made this endpoint return [] for every request.
    raw = _cached_graph_projects_data(from_date, to_date) or []
    if isinstance(raw, dict):
        raw = raw.get("projects") or []
    rows = [r for r in raw if isinstance(r, dict)]

    gname = str(group_name or "").strip()
    if gname and gname.upper() != "ALL":
        from src.services import project_groups as _pg
        gmap = _pg.build_group_map([str(r.get("project_name") or "") for r in rows])
        rows = [r for r in rows if gmap.get(str(r.get("project_name") or "")) == gname]

    pname = str(project_name or "").strip().lower()
    if pname and pname != "all":
        rows = [r for r in rows if str(r.get("project_name") or "").strip().lower() == pname]

    data = [{
        "projectName": str(r.get("project_name") or ""),
        "errorCount": int(r.get("error_count") or 0),
        "recommendedCount": int(r.get("recommended_count") or 0),
    } for r in rows]
    project_count = len(data)

    # The dashboard chart can read at GROUP level instead of listing each and every project.
    # Aggregated HERE rather than in the browser because the frontend does not
    # hold a complete project -> group map: the dashboard loads only the first few projects of each
    # group for its cards, so a client-side rollup would quietly file every project beyond that
    # into "Other". build_group_map is the same resolver the group cards and the recommendation
    # scope use, so all three agree by construction.
    rollup = str(group_by or "").strip().lower() in ("group", "projectgroup", "project_group")
    if rollup:
        from src.services import project_groups as _pg
        data = _pg.rollup_by_group(data)

    summary = {
        "totalErrors": sum(d["errorCount"] for d in data),
        # Stays the number of PROJECTS in both modes - it labels projects, and flipping it to a
        # group count in group mode would silently change what the existing tile means.
        "totalProjects": project_count,
        "totalGroups": len(data) if rollup else 0,
        "totalRecommended": sum(d["recommendedCount"] for d in data),
    }
    page, pagination = _paginate_or_all(data, page_number, page_size)
    return {
        "success": True,
        "data": page,
        "summary": summary,
        "pagination": pagination,
        "message": "Graph data fetched successfully.",
    }


# ======================= Project Group Configuration (admin) =======================
# Dynamic groups (name + pattern) + manual assignment + "Other" default. Projects are derived, so
# PROJECT NAME is the identity (no numeric projectId). See src/services/project_groups.py.

def _pg_paginate(items: List, page_number, page_size):
    try:
        page_number = max(1, int(page_number or 1))
    except (TypeError, ValueError):
        page_number = 1
    try:
        page_size = max(1, int(page_size or 10))
    except (TypeError, ValueError):
        page_size = 10
    total = len(items)
    total_pages = (total + page_size - 1) // page_size if page_size else 1
    start = (page_number - 1) * page_size
    return items[start:start + page_size], {
        "pageNumber": page_number, "pageSize": page_size,
        "totalRecords": total, "totalPages": total_pages,
    }


def _pg_projects_indexed(from_date=None, to_date=None) -> List[dict]:
    """All derived projects -> [{projectName, groupName, errorsThisWeek, lastAnalysisDate}].
    errorsThisWeek is scoped to [from_date, to_date] (default: last 7 days)."""
    from src.services import project_groups as _pg
    projects = _cached_all_projects()
    names = [p.get("project_name") for p in projects if isinstance(p, dict) and p.get("project_name")]
    gmap = _pg.build_group_map(names)

    if not from_date or not to_date:
        to_date = datetime.now().strftime("%Y-%m-%d")
        from_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    week_errors: Dict[str, int] = {}
    try:
        # Same shape note as handle_graph_data: the per-project rows are under "projects".
        raw = _cached_graph_projects_data(from_date, to_date) or []
        if isinstance(raw, dict):
            raw = raw.get("projects") or []
        for row in raw:
            if isinstance(row, dict):
                week_errors[str(row.get("project_name") or "")] = int(row.get("error_count") or 0)
    except Exception:
        logger.exception("group projects: date-scoped error counts failed")

    out = []
    for p in projects:
        if not isinstance(p, dict):
            continue
        name = str(p.get("project_name") or "")
        out.append({
            "projectName": name,
            "groupName": gmap.get(name, _pg.DEFAULT_GROUP),
            "errorsThisWeek": week_errors.get(name, 0),
            "lastAnalysisDate": p.get("last_analysis") or "",
        })
    return out


def handle_all_group_data(page_number=1, page_size=10, search_text="", from_date=None, to_date=None) -> Dict:
    """1. GET /allGroupData — dashboard table: each defined group + its pattern + project count."""
    from src.services import project_groups as _pg
    projects = _cached_all_projects()
    names = [p.get("project_name") for p in projects if isinstance(p, dict) and p.get("project_name")]
    gmap = _pg.build_group_map(names)
    counts: Dict[str, int] = {}
    for g in gmap.values():
        counts[g] = counts.get(g, 0) + 1
    rows = [{"groupName": d["group_name"], "projectPattern": d["project_pattern"],
             "projectCount": counts.get(d["group_name"], 0)} for d in _pg.list_group_defs()]
    st = str(search_text or "").strip().lower()
    if st:
        rows = [r for r in rows if st in r["groupName"].lower() or st in r["projectPattern"].lower()]
    page, pagination = _pg_paginate(rows, page_number, page_size)
    return {"success": True, "data": page, "pagination": pagination,
            "message": "Project groups fetched successfully."}


def handle_group_projects_data(group_name, page_number=1, page_size=10, search_text="",
                               from_date=None, to_date=None) -> Dict:
    """2. GET /groupProjectsData — projects assigned to one group (paginated/search/date)."""
    target = str(group_name or "").strip()
    rows = [r for r in _pg_projects_indexed(from_date, to_date) if r["groupName"] == target]
    st = str(search_text or "").strip().lower()
    if st:
        rows = [r for r in rows if st in r["projectName"].lower()]
    rows.sort(key=lambda r: r["projectName"].lower())
    page, pagination = _pg_paginate(rows, page_number, page_size)
    data = [{"projectId": r["projectName"], "projectName": r["projectName"],
             "errorsThisWeek": r["errorsThisWeek"], "lastAnalysisDate": r["lastAnalysisDate"]} for r in page]
    return {"success": True, "data": data, "pagination": pagination,
            "message": "Projects fetched successfully."}


def handle_other_projects_data(page_number=1, page_size=10, search_text="") -> Dict:
    """3. GET /otherProjectsData — projects in the default 'Other' group (available to add)."""
    from src.services import project_groups as _pg
    projects = _cached_all_projects()
    names = [p.get("project_name") for p in projects if isinstance(p, dict) and p.get("project_name")]
    gmap = _pg.build_group_map(names)
    rows = [{"projectId": n, "projectName": n} for n in names
            if gmap.get(n, _pg.DEFAULT_GROUP) == _pg.DEFAULT_GROUP]
    st = str(search_text or "").strip().lower()
    if st:
        rows = [r for r in rows if st in r["projectName"].lower()]
    rows.sort(key=lambda r: r["projectName"].lower())
    page, pagination = _pg_paginate(rows, page_number, page_size)
    return {"success": True, "data": page, "pagination": pagination,
            "message": "Available projects fetched successfully."}


def handle_add_group(group_name, project_pattern) -> Dict:
    """4. POST /addGroup"""
    from src.services import project_groups as _pg
    _pg.create_group(group_name, project_pattern)
    return {"success": True, "message": "Project group created successfully."}


def handle_update_group(old_group_name, group_name, project_pattern) -> Dict:
    """5. PUT /updateGroup — rename (via oldGroupName) and/or change pattern."""
    from src.services import project_groups as _pg
    _pg.update_group(old_group_name, group_name, project_pattern)
    return {"success": True, "message": "Project group updated successfully."}


def handle_add_projects_in_group(group_name, project_names) -> Dict:
    """6. POST /addProjectInGroup — manually assign projects (by name) to a group."""
    from src.services import project_groups as _pg
    g = str(group_name or "").strip()
    if not g:
        raise ValueError("groupName is required")
    names = [str(n).strip() for n in (project_names or []) if str(n).strip()]
    if not names:
        raise ValueError("projectNames must be a non-empty list")
    for n in names:
        _pg.assign_project(n, g)
    return {"success": True, "message": "Projects added successfully."}


def handle_delete_project_from_group(group_name, project_name) -> Dict:
    """7. POST /deleteProjectFromGroup — remove a project from a group -> moves it to Other."""
    from src.services import project_groups as _pg
    if not str(project_name or "").strip():
        raise ValueError("projectName is required")
    _pg.move_project_to_other(project_name)
    return {"success": True, "message": "Project removed from group and moved to Other group successfully."}


def handle_delete_group(group_name) -> Dict:
    """8. DELETE /deleteGroup — delete a group; its projects fall back to Other."""
    from src.services import project_groups as _pg
    if not str(group_name or "").strip():
        raise ValueError("groupName is required")
    _pg.delete_group(group_name)
    return {"success": True, "message": "Project group deleted successfully. Projects moved to Other group."}


def handle_delete_project(project_name, actor: str = "admin") -> Dict:
    """DELETE /delete-project — remove ONE project outright (admin only).

    A project has no row of its own: it is every request filed under that name (get_all_projects
    derives the list from final_build_payload). Deleting it therefore means the per-request sweep
    for each of those requests - data rows, vectors, S3 objects, solutions, final payload,
    tombstone - exactly as /delete-requests does it, followed by the rows that belong to the
    project itself and carry no request id: session / prediction-history / signature-index rows
    keyed by project name, vectors still tagged with the project, its group pin, adapter overrides
    and the `project` table row. Every stage is reported on its own and a failure in one never
    skips the rest. Idempotent: a second run on a gone project answers not_found, all counts 0.

    This is NOT /deleteProjectFromGroup, which only moves a project to the Other group."""
    name = str(project_name or "").strip()
    if not name:
        raise ValueError("projectName is required")
    project_norm = name.lower()

    # 1. every request filed under the project. A fresh scan on purpose: the cached dashboard
    #    rows may be up to a TTL old, and a request missed here would keep the project alive.
    rows = list_final_build_payloads_by_project(project_norm)
    request_ids = _unique_strings([str(r.get("request_id") or "") for r in rows])
    request_results = [_delete_request_data(rid) for rid in request_ids]
    for rid in request_ids:
        _write_request_tombstone(rid)

    stages: Dict[str, Dict] = {}

    def _stage(label: str, fn) -> None:
        try:
            stages[label] = {"ok": True, "count": int(fn() or 0)}
        except Exception as exc:
            logger.exception("delete project | stage=%s failed | project=%s", label, project_norm)
            stages[label] = {"ok": False, "count": 0, "error": str(exc)}

    # 2. rows keyed by the project rather than by a request
    def _project_rows() -> int:
        items = list_project_scoped_items(project_norm)
        return delete_ai_assisted_items(items) if items else 0
    _stage("project_rows", _project_rows)

    # 3. vectors still tagged with the project - survivors of an earlier partial delete whose
    #    reference rows are gone, so the per-request sweep could not see them (base + learned space)
    def _vectors() -> int:
        from src.utils import recommended as _rec
        handles = [getattr(_rec, "collection", None)]
        try:
            handles.append(_rec._get_learned_collection())
        except Exception:
            logger.exception("learned space handle unavailable - base collection only")
        removed = 0
        for col in handles:
            if col is None:
                continue
            for _ in range(50):  # Azure get() pages at 1000; Chroma returns everything at once
                found = col.get(where={"project_name": project_norm}, include=["metadatas"]) or {}
                ids = [str(i) for i in (found.get("ids") or []) if str(i or "").strip()]
                if not ids:
                    break
                col.delete(ids=ids)
                removed += len(ids)
        return removed
    _stage("vectors", _vectors)

    # 4. the project's own configuration
    def _group_pin() -> int:
        from src.services import project_groups as _pg
        return _pg.remove_project_override(name)
    _stage("group_override", _group_pin)

    def _adapter_overrides() -> int:
        from src.services import adapter_settings as _as
        cleared = 0
        for domain in ("error", "artifact"):
            overrides = dict((_as.get_settings(force=True, domain=domain) or {}).get("project_overrides") or {})
            if project_norm in overrides:
                _as.clear_project(project_norm, by=actor, domain=domain)
                cleared += 1
        return cleared
    _stage("adapter_overrides", _adapter_overrides)

    _stage("project_row", lambda: delete_project_row(name))

    # The project must vanish from the dashboard now, not when the TTL expires.
    _invalidate_dashboard_read_cache()

    deleted = sum(1 for r in request_results if r.get("status") == "deleted")
    partial = sum(1 for r in request_results if r.get("status") == "partial_failure")
    failed = sum(1 for r in request_results if r.get("status") in {"error", "invalid"})
    stage_failed = [label for label, st in stages.items() if not st["ok"]]
    found_anything = bool(request_ids) or any(st["count"] for st in stages.values())
    success = partial == 0 and failed == 0 and not stage_failed
    if not found_anything and success:
        status, message = "not_found", f"No data found for project '{project_norm}'."
    elif success:
        status, message = "deleted", f"Project '{project_norm}' deleted."
    else:
        status, message = "partial_failure", f"Project '{project_norm}' only partially deleted - see requests and stages."
    return {
        "success": success,
        "status": status,
        "message": message,
        "project_name": project_norm,
        "request_count": len(request_ids),
        "deleted_count": deleted,
        "partial_failure_count": partial,
        "failed_count": failed,
        "failed_stages": stage_failed,
        "requests": request_results,
        "stages": stages,
    }


def _feedback_votes_for_rids(rids) -> dict:
    """Votes for exactly these request ids - PARALLEL per-id queries (indexed reads).
    History: originally one serial query per table row (3xN per Home load, slow);
    then one full scan of the data table (0f2c4678) - but that table is large and a
    scan on the strained dev DynamoDB Local takes minutes. Targeted queries for just
    the rows being shown are cheap on ANY backend. Cached per rid-set; a new vote
    invalidates immediately. Read-only downstream."""
    rid_key = tuple(sorted({str(r or "").strip() for r in (rids or []) if str(r or "").strip()}))
    if not rid_key:
        return {}
    from src.utils import ttl_cache

    def _build():
        from concurrent.futures import ThreadPoolExecutor

        def _one(rid):
            try:
                return rid, [{
                    "is_helpful": v.get("is_helpful"),
                    "Date": str(v.get("created_date") or v.get("Date") or v.get("updated_date") or ""),
                }
                             for v in list_recommendation_feedback(rid)]
            except Exception:
                return rid, []

        grouped = {}
        with ThreadPoolExecutor(max_workers=min(8, len(rid_key))) as pool:
            for rid, votes in pool.map(_one, rid_key):
                grouped[rid] = votes
        return grouped

    import hashlib as _hl
    digest = _hl.sha256("|".join(rid_key).encode("utf-8")).hexdigest()[:16]
    return ttl_cache.get_or_compute(("fbv", digest), _build, deep_copy=False)


def handle_get_tasks(project_name: str, s_date: Optional[str] = None, c_date: Optional[str] = None) -> Dict:
    if not s_date or not c_date:
        c_date = datetime.now().strftime("%d-%m-%Y")
        s_date = (datetime.now() - timedelta(days=7)).strftime("%d-%m-%Y")
    
    # Get token usage statistics for the project
    token_usage = {}
    try:
        from src.utils import project_details
        # Convert DD-MM-YYYY to ISO format for token usage query
        start_iso = None
        end_iso = None
        if s_date and c_date:
            try:
                start_dt = datetime.strptime(s_date, "%d-%m-%Y")
                end_dt = datetime.strptime(c_date, "%d-%m-%Y")
                start_iso = start_dt.strftime("%Y-%m-%dT00:00:00Z")
                end_iso = end_dt.strftime("%Y-%m-%dT23:59:59Z")
            except Exception:
                pass
        
        token_result = project_details.get_token_usage_by_project(
            project_name=project_name,
            start_date=start_iso,
            end_date=end_iso,
            operation_type="recommendation",
        )
        
        if token_result.get("success") and project_name.lower() in token_result.get("projects", {}):
            raw_usage = token_result["projects"][project_name.lower()]
            # Simplify response - remove redundant by_operation_type breakdown
            token_usage = {
                "request_count": raw_usage.get("request_count", 0),
                "total_prompt_tokens": raw_usage.get("total_prompt_tokens", 0),
                "total_output_tokens": raw_usage.get("total_output_tokens", 0),
                "total_tokens": raw_usage.get("total_tokens", 0),
                "average_tokens_per_request": raw_usage.get("average_tokens_per_request", 0),
            }
    except Exception as e:
        logger.warning("Failed to get token usage for project=%s: %s", project_name, str(e))
    
    tasks = get_total_task(project_name, s_date, c_date)

    # Dashboard consistency (the tiles used to say 48 errors while the overview table
    # showed 25 entries): the tiles counted every upload ROW — duplicates included — while
    # the table dedupes (same error + same fix = one logical entry). The tiles now count the
    # SAME unique entries through the SAME pipeline the table uses (enrich=False = dedup
    # only). The raw upload count stays available additively as occurrenceCount per task —
    # duplicates still count as occurrences, they just don't masquerade as distinct errors
    # (same behavior as the get-total-errors fix).
    unique_rows: List[dict] = []
    try:
        from src.utils import ttl_cache
        solutions = ttl_cache.get_or_compute(
            ("solutions", str(project_name or "").strip().lower(), s_date, c_date),
            lambda: get_project_solutions(project_name, s_date, c_date))
        unique_rows = _dedupe_and_enrich_solutions(solutions, project_name, enrich=False)
        unique_per_task: Dict[str, int] = {}
        for srow in unique_rows:
            t = str(srow.get("task_name") or "unknown-task").strip() or "unknown-task"
            unique_per_task[t] = unique_per_task.get(t, 0) + 1
        for trow in tasks:
            t = str(trow.get("task") or "").strip()
            trow["occurrenceCount"] = int(trow.get("errorDetected") or 0)
            trow["errorDetected"] = int(unique_per_task.get(t, 0))
        known = {str(tr.get("task") or "").strip() for tr in tasks}
        for t, n in unique_per_task.items():
            if t not in known:
                tasks.append({"task": t, "errorDetected": n, "recommendedSolution": 0, "occurrenceCount": 0})
    except Exception:
        logger.exception("get-tasks unique-count alignment failed — raw counts returned unchanged")

    # Project-level helpful/not-helpful feedback totals for the same date window — same shape as
    # get-total-errors' feedback_summary, over the same deduped rows used for the tiles above.
    feedback_helpful_total = 0
    feedback_not_helpful_total = 0
    try:
        _votes_by_rid = _feedback_votes_for_rids(
            [str(r.get("request_id") or "") for r in unique_rows if isinstance(r, dict)])
        for srow in unique_rows:
            rid = str(srow.get("request_id") or "").strip()
            if not rid:
                continue
            for vote in _votes_by_rid.get(rid, []):
                if vote.get("is_helpful") is True:
                    feedback_helpful_total += 1
                elif vote.get("is_helpful") is False:
                    feedback_not_helpful_total += 1
    except Exception:
        logger.exception("get-tasks feedback aggregation failed — feedback_summary returned as zeros")

    return {
        "tasks": tasks,
        "token_usage": token_usage,
        "feedback_summary": {
            "helpful": feedback_helpful_total,
            "not_helpful": feedback_not_helpful_total,
            "total": feedback_helpful_total + feedback_not_helpful_total,
        },
        "success": True
    }


# def handle_get_total_errors(project_name: str, s_date: Optional[str] = None, c_date: Optional[str] = None) -> Dict:
#     if not s_date or not c_date:
#         c_date = datetime.now().strftime("%d-%m-%Y")
#         s_date = (datetime.now() - timedelta(days=7)).strftime("%d-%m-%Y")
    
#     errors = get_total_error(project_name, s_date, c_date)
#     solutions = get_project_solutions(project_name, s_date, c_date)
#     total_count = len(solutions)
#     return {
#         "success": True,
#         "messgae": "Project solution retrived successfully",
#         "data": {
#             "count": total_count,
#             "projects": errors,
#             "solutions": solutions,
#         }
#     }
from datetime import datetime, timedelta
from typing import Dict, Optional

def _parse_created_date(value):
    if not value:
        return datetime.min

    if isinstance(value, datetime):
        return value

    for fmt in (
        "%d-%m-%Y",
        "%Y-%m-%d",
        "%d-%m-%Y %H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
    ):
        try:
            return datetime.strptime(str(value), fmt)
        except ValueError:
            continue

    try:
        text = str(value).strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        parsed = datetime.fromisoformat(text)
        if parsed.tzinfo is not None:
            return parsed.replace(tzinfo=None)
        return parsed
    except Exception:
        pass

    return datetime.min


def _dedupe_and_enrich_solutions(solutions: List[dict], project_name: str = "",
                                 enrich: bool = True) -> List[dict]:
    """Shared dashboard post-processing for solution lists — used by BOTH get-total-errors and
    daily-activity so their bodies match exactly:
      1. latest record first
      2. drop blank/incomplete rows (a record with no recommended solution to display)
      3. de-dup the SAME error (task) resolved with the SAME fix -> one logical entry (the latest)
      4. attach each artifact's AI summary + per-artifact token_usage + raw_url + diff_link
    project_name="" => cross-project: each row's own project_name is used for its artifact summaries.
    enrich=False skips step 4 so a paginated caller can attach summaries to the RETURNED PAGE
    only (via _attach_artifact_summaries) instead of paying one vector-store read per project
    for rows that are never returned.
    """
    # latest record first
    solutions = sorted(
        solutions,
        key=lambda x: _parse_created_date(x.get("created_date")),
        reverse=True,
    )

    # Drop blank/incomplete rows. Same error with a DIFFERENT solution is NOT blank -> it stays.
    solutions = [s for s in solutions if s.get("solution")]

    # The SAME error resolved with the SAME fix across builds is one logical entry -> show once.
    # Mapping fix (a recommended request id used to show "no activity found" on the
    # dashboard): the absorbed duplicates' request ids now ride on the SURVIVING row, so
    # searching/filtering by ANY member id - e.g. the id a recommendation cited - finds the
    # canonical entry instead of nothing.
    _seen_sol = {}
    _deduped_solutions = []
    for _sol in solutions:
        _key = (str(_sol.get("task_name") or "").strip(), _solution_fingerprint(_sol.get("solution")))
        if _key in _seen_sol:
            _survivor = _seen_sol[_key]
            _dup_id = str(_sol.get("request_id") or "").strip()
            if _dup_id:
                _survivor.setdefault("duplicate_request_ids", []).append(_dup_id)
            # The survivor used to show recommended_count 0 while the
            # absorbed member carried the real activity - the family's counts now ride on
            # the shown row, so a merged entry never looks dead.
            try:
                _surv_rc = _survivor.get("recommended_count")
                _dup_rc = _sol.get("recommended_count")
                if isinstance(_surv_rc, (int, float)) and isinstance(_dup_rc, (int, float)):
                    _survivor["recommended_count"] = int(_surv_rc) + int(_dup_rc)
            except Exception:
                pass
            continue
        _seen_sol[_key] = _sol
        _deduped_solutions.append(_sol)
    solutions = _deduped_solutions

    if enrich:
        _attach_artifact_summaries(solutions, project_name)

    return solutions


def _attach_artifact_summaries(solutions: List[dict], project_name: str = "") -> None:
    """Attach each artifact's AI summary (Error Signals / Missing or Failing Components / Root Cause
    Clues / Key Evidence, made once at upload, stored in the vector store) + per-artifact token
    audit + raw/diff links, IN PLACE. Summaries are per-project, so cache one vector-store read per
    project (a single project for get-total-errors; several for cross-project daily-activity —
    which is why paginated callers should pass only the returned page here)."""
    _summary_caches: Dict[str, dict] = {}

    def _summaries_for(proj: str) -> dict:
        proj = str(proj or "").strip()
        if not proj:
            return {}
        if proj not in _summary_caches:
            # One vector-store read per project — also TTL-cached across requests (UAT
            # perf): the summary map is read-only downstream, so it is shared, not copied.
            from src.utils import ttl_cache
            _summary_caches[proj] = ttl_cache.get_or_compute(
                ("art-summaries", proj.lower()),
                lambda: _artifact_summaries_for_project(proj),
                deep_copy=False)
        return _summary_caches[proj]

    for sol in solutions:
        proj = project_name or sol.get("project_name") or ""
        summary_by_s3 = _summaries_for(proj)
        if not summary_by_s3:
            continue
        binary_obj = sol.get("binary") if isinstance(sol.get("binary"), dict) else {}
        for art in (binary_obj.get("artifacts") or []):
            key = str(art.get("s3_key") or "").strip()
            # Exact key first; fall back to the content hash so DUPLICATE copies of the same file
            # (other builds' keys) resolve to the single stored record.
            entry = summary_by_s3.get(key) or summary_by_s3.get(f"sha:{_sha12_from_s3_key(key)}") or {}
            art["summary"] = entry.get("summary", "")
            art["token_usage"] = entry.get("token_usage", {})
            art["raw_url"] = _artifact_raw_url(key)
            art["diff_link"] = _artifact_diff_link(key, proj)


def _paginate_or_all(items: List, page_number, page_size):
    """Backward-compatible pagination: no pageSize -> return ALL items (existing callers unaffected);
    pageSize given -> return that page. Always returns the standard pagination block."""
    total = len(items)
    _all = (items, {"pageNumber": 1, "pageSize": total, "totalRecords": total, "totalPages": 1 if total else 0})
    if page_size in (None, "", 0, "0"):
        return _all
    try:
        ps = max(1, int(page_size))
        pn = max(1, int(page_number or 1))
    except (TypeError, ValueError):
        return _all
    total_pages = (total + ps - 1) // ps if total else 0
    start = (pn - 1) * ps
    return items[start:start + ps], {
        "pageNumber": pn, "pageSize": ps, "totalRecords": total, "totalPages": total_pages,
    }


def _string_values_of(value, depth: int = 0) -> List[str]:
    """All string VALUES nested inside dicts/lists (keys excluded, so searching 'error' doesn't
    match every row via the 'errorMessage' key name)."""
    if depth > 6:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [s for v in value for s in _string_values_of(v, depth + 1)]
    if isinstance(value, dict):
        return [s for v in value.values() for s in _string_values_of(v, depth + 1)]
    return []


def _solution_matches_search(sol: dict, needle: str) -> bool:
    """Case-insensitive substring match for the dashboard solution-list search box: task name,
    request id, developer/username, artifact file names, and every text value inside the
    solution entries (error messages, fix lines, file paths...)."""
    parts = [
        str(sol.get("task_name") or ""),
        str(sol.get("request_id") or ""),
        str(sol.get("username") or ""),
        str(sol.get("developer_id") or ""),
    ]
    # Absorbed duplicates' ids (see _dedupe_and_enrich_solutions) - a recommendation may cite
    # any member of the family; all of them must find the canonical row.
    parts.extend(str(r) for r in (sol.get("duplicate_request_ids") or []))
    binary_obj = sol.get("binary") if isinstance(sol.get("binary"), dict) else {}
    parts.extend(str(a.get("file_name") or "") for a in (binary_obj.get("artifacts") or [])
                 if isinstance(a, dict))
    parts.extend(_string_values_of(sol.get("solution")))
    return any(needle in p.lower() for p in parts if p)


def handle_get_total_errors(project_name: str, s_date: Optional[str] = None, c_date: Optional[str] = None,
                            username: str = "", page_number=None, page_size=None, search: str = "",
                            task: str = "") -> Dict:
    if not s_date or not c_date:
        c_date = datetime.now().strftime("%d-%m-%Y")
        s_date = (datetime.now() - timedelta(days=7)).strftime("%d-%m-%Y")

    errors = get_total_error(project_name, s_date, c_date)
    # UAT perf (30-60s per page click before this): the full date-range fetch is the
    # per-click cost — cache it for a short window so pagination/sort/search clicks on the
    # same range answer instantly. Deep-copied per request; new uploads invalidate.
    from src.utils import ttl_cache
    solutions = ttl_cache.get_or_compute(
        ("solutions", str(project_name or "").strip().lower(), s_date, c_date),
        lambda: get_project_solutions(project_name, s_date, c_date))
    solutions = _dedupe_and_enrich_solutions(solutions, project_name)

    # Dashboard consistency (the tile used to say "18 errors" while the table showed
    # "11 of 11"): the tile's error_count now carries the same UNIQUE count the table paginates.
    # The raw number of uploads stays available as occurrence_count — duplicates still count
    # occurrences, they just don't masquerade as distinct errors.
    if errors and isinstance(errors[0], dict):
        errors[0]["occurrence_count"] = int(errors[0].get("error_count") or 0)
        errors[0]["error_count"] = len(solutions)

    # Task FILTER (search highlights, a FILTER narrows the view to one task, e.g. only
    # task 4): exact task filter applied BEFORE count/pagination, so tiles, count and
    # pages all reflect the filtered view consistently.
    task_needle = str(task or "").strip().lower()
    if task_needle:
        solutions = [s for s in solutions
                     if str(s.get("task_name") or "").strip().lower() == task_needle]

    # Search filters BEFORE count/pagination so both reflect what the user actually sees.
    needle = str(search or "").strip().lower()
    if needle:
        solutions = [s for s in solutions if _solution_matches_search(s, needle)]

    total_count = len(solutions)
    created_date = solutions[0].get("created_date") if solutions else None
    page, pagination = _paginate_or_all(solutions, page_number, page_size)

    # Per-row recommendation LLM token usage (UI shows it alongside each recommendation, the same
    # way each artifact shows its summary token_usage). One query per call, joined on request_id;
    # rows with no stored usage get explicit zeros so the UI never needs a missing-key fallback.
    from src.utils import project_details as _pd
    _EMPTY_USAGE = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0, "llm_calls": 0}
    token_map = _pd.get_token_usage_map_for_project(project_name)
    for sol in page:
        rid = str(sol.get("request_id") or "").strip()
        sol["recommendation_token_usage"] = token_map.get(rid) or dict(_EMPTY_USAGE)
    # Combined per-request total across BOTH LLM calls the flow makes: (1) artifact summary
    # creation — each artifact's token_usage.tags "Total" entry, already attached above by
    # _dedupe_and_enrich_solutions/_attach_artifact_summaries — and (2) the recommendation LLM
    # call, just joined above. Gives one number per request for "how many tokens did this request use".
    def _artifact_tokens_for_row(sol: Dict) -> int:
        binary_obj = sol.get("binary") if isinstance(sol.get("binary"), dict) else {}
        total = 0
        for art in (binary_obj.get("artifacts") or []):
            if not isinstance(art, dict):
                continue
            for tag in ((art.get("token_usage") or {}).get("tags") or []):
                if str(tag.get("key")) == "Total":
                    try:
                        total += int(tag.get("value") or 0)
                    except (TypeError, ValueError):
                        pass
        return total

    for sol in page:
        artifact_tokens = _artifact_tokens_for_row(sol)
        recommendation_tokens = int((sol.get("recommendation_token_usage") or {}).get("total_tokens") or 0)
        sol["total_token_usage"] = artifact_tokens + recommendation_tokens

    # Project-wide artifact-summary token total across EVERY matching row (not just the returned
    # page) — solutions already carry their artifact token_usage from the enrichment step above,
    # before pagination sliced it down to `page`, so this reflects the same filtered set that
    # `count` does.
    total_artifact_summary_tokens = sum(_artifact_tokens_for_row(sol) for sol in solutions)

    # Evaluation metric: thumbs feedback as SIMPLE count key-values — per row
    # "helpful X / not helpful Y / total Z" for the click-through on Recommended Count, plus the
    # project-level roll-up so the dashboard can say how the project is trending. Counts only;
    # the UI owns the presentation. Same date-window rows as `count`.
    feedback_helpful_total = 0
    feedback_not_helpful_total = 0
    _votes_by_rid = _feedback_votes_for_rids(
        [str(sol.get("request_id") or "") for sol in solutions]
        + [str(d) for sol in solutions for d in (sol.get("duplicate_request_ids") or [])])
    for sol in solutions:
        rid = str(sol.get("request_id") or "").strip()
        # Family-wide votes: developers voted on the ABSORBED member ids too -
        # the shown row carries the whole family's helpful/not-helpful counts.
        _family_ids = [rid] + [str(d).strip() for d in (sol.get("duplicate_request_ids") or [])]
        helpful = not_helpful = 0
        if rid:
            try:
                for _frid in _family_ids:
                    if not _frid:
                        continue
                    for vote in _votes_by_rid.get(_frid, []):
                        if vote.get("is_helpful") is True:
                            helpful += 1
                        elif vote.get("is_helpful") is False:
                            not_helpful += 1
            except Exception:
                pass
        sol["helpful_count"] = helpful
        sol["not_helpful_count"] = not_helpful
        sol["feedback_total"] = helpful + not_helpful
        feedback_helpful_total += helpful
        feedback_not_helpful_total += not_helpful

    # Project-level totals for the SAME date range (matches get-tasks' token_usage block shape).
    recommendation_token_summary = {
        "request_count": 0, "total_prompt_tokens": 0, "total_output_tokens": 0,
        "total_tokens": 0, "average_tokens_per_request": 0,
    }
    try:
        start_iso = datetime.strptime(s_date, "%d-%m-%Y").strftime("%Y-%m-%dT00:00:00Z")
        end_iso = datetime.strptime(c_date, "%d-%m-%Y").strftime("%Y-%m-%dT23:59:59Z")
        token_result = _pd.get_token_usage_by_project(
            project_name=project_name, start_date=start_iso, end_date=end_iso,
            operation_type="recommendation",
        )
        proj_key = str(project_name or "").strip().lower()
        if token_result.get("success") and proj_key in token_result.get("projects", {}):
            raw = token_result["projects"][proj_key]
            recommendation_token_summary = {k: raw.get(k, 0) for k in recommendation_token_summary}
    except Exception as e:
        logger.warning("Failed to get recommendation token summary | project=%s | %s", project_name, str(e))

    # Tile reconciliation: the tiles must equal the SUM of the table's rows
    # (across every page), so a user adding the column up always lands on the tile number.
    # Computed over the same filtered, deduped set that `count` paginates. ADDITIVE fields —
    # the existing period-wide summaries stay for anyone who needs the old semantics.
    def _rec_count_of(sol: Dict) -> int:
        v = sol.get("recommended_count")
        if isinstance(v, list):
            return len(v)
        try:
            return int(v or 0)
        except (TypeError, ValueError):
            return 0

    rows_recommended_count_total = sum(_rec_count_of(sol) for sol in solutions)
    rows_recommendation_tokens_total = 0
    for sol in solutions:
        rid = str(sol.get("request_id") or "").strip()
        rows_recommendation_tokens_total += int((token_map.get(rid) or {}).get("total_tokens") or 0)
    rows_token_usage_total = total_artifact_summary_tokens + rows_recommendation_tokens_total

    return {
        "success": True,
        "messgae": "Project solution retrived successfully",
        "data": {
            "count": total_count,
            "created_date": created_date,
            "projects": errors,
            "solutions": page,
            "recommendation_token_summary": recommendation_token_summary,
            "total_artifact_summary_tokens": total_artifact_summary_tokens,
            # Row-sum totals for the tiles: recommended-count column sum, recommendation-token
            # column sum, and the combined token column (artifact summaries + recommendation).
            "rows_recommended_count_total": rows_recommended_count_total,
            "rows_recommendation_tokens_total": rows_recommendation_tokens_total,
            "rows_token_usage_total": rows_token_usage_total,
            "feedback_summary": {
                "helpful": feedback_helpful_total,
                "not_helpful": feedback_not_helpful_total,
                "total": feedback_helpful_total + feedback_not_helpful_total,
            },
        },
        "pagination": pagination,
    }


def handle_export_daily_activity(s_date=None, c_date=None, group_name=None, search_text=None):
    """Recent Activity export: the SAME rows the screen shows, under the SAME filters, with no
    pagination and no artifact enrichment.

    Skipping enrichment is the whole speed story: an export must not take time.
    handle_get_daily_activity attaches AI artifact summaries to the returned PAGE - one
    vector-store read per project on that page. An export spans every page, so doing the same
    would multiply those reads by the whole date range to produce columns the spreadsheet does
    not even contain. The underlying fetch is the same ttl-cached read the screen already warmed,
    so an export straight after browsing costs almost nothing.
    """
    # The cache is an optimisation, not a requirement. ttl_cache landed on dev and was never
    # cherry-picked to uat, so importing it unconditionally made the export 500 there with an
    # ImportError. When it is present the export reuses the same warmed read the screen just
    # did; when it is not, it reads directly and is simply not cached.
    try:
        from src.utils import ttl_cache
        solutions = ttl_cache.get_or_compute(
            ("recent", s_date, c_date),
            lambda: get_daily_activity_solutions(s_date=s_date, c_date=c_date))
    except ImportError:
        solutions = get_daily_activity_solutions(s_date=s_date, c_date=c_date)
    solutions = _dedupe_and_enrich_solutions(solutions, enrich=False)

    # Same group tagging the screen uses, so the exported Group Name column matches it.
    from src.services import project_groups as _pg
    _names = {str(s.get("project_name") or "") for s in solutions}
    _names.discard("")
    _gmap = _pg.build_group_map(_names)
    for row in solutions:
        row["groupType"] = _gmap.get(str(row.get("project_name") or ""), _pg.DEFAULT_GROUP)

    if group_name:
        wanted = str(group_name).strip()
        solutions = [s for s in solutions if str(s.get("groupType") or "") == wanted]

    if search_text:
        needle = str(search_text).strip().lower()
        if needle:
            def _hit(row):
                for key in ("project_name", "request_id", "task_name", "resolutionDescription",
                            "description", "developer_id", "groupType"):
                    if needle in str(row.get(key) or "").lower():
                        return True
                return False
            solutions = [s for s in solutions if _hit(s)]

    return solutions


def handle_get_daily_activity(s_date=None, c_date=None, group_name=None, page_number=None, page_size=None) -> Dict:
    # Keep the RECENT logic (cross-project, date-range fetch) as-is, but return the SAME enriched body
    # as get-total-errors: sorted, blank-dropped, de-duped, and each artifact carrying its AI summary +
    # token_usage + raw_url + diff_link. Cross-project => per-row project drives the artifact summaries.
    # UAT perf: same short-window cache as get-total-errors — Recent
    # Activity's cross-project fetch is the heaviest read, and every pagination click
    # repaid it. First click warms the range; the rest answer from memory.
    from src.utils import ttl_cache
    solutions = ttl_cache.get_or_compute(
        ("recent", s_date, c_date),
        lambda: get_daily_activity_solutions(s_date=s_date, c_date=c_date))
    # Dedupe/sort WITHOUT enrichment first, paginate, then attach artifact summaries to the
    # RETURNED PAGE only — one vector-store read per project on the page (1-3 typically)
    # instead of one per project across the whole date range. Same rows, same content.
    solutions = _dedupe_and_enrich_solutions(solutions, enrich=False)
    
    # Cross-project "recent" feed: tag each row with its project's dashboard group
    # (groupType) so the UI can show the SAME group label the dashboard uses. "Other" if unassigned.
    from src.services import project_groups as _pg
    project_names = {str(s.get("project_name") or "") for s in solutions}
    project_names.discard("")  # Remove empty strings
    _gmap = _pg.build_group_map(project_names)
    for s in solutions:
        pname = str(s.get("project_name") or "")
        s["groupType"] = _gmap.get(pname, _pg.DEFAULT_GROUP)
    
    # Filter by group_name if provided
    if group_name:
        group_name_normalized = group_name.strip()
        solutions = [s for s in solutions if s.get("groupType", "") == group_name_normalized]
    
    total_count = len(solutions)
    created_date = solutions[0].get("created_date") if solutions else None
    page, pagination = _paginate_or_all(solutions, page_number, page_size)
    _attach_artifact_summaries(page)

    return {
        "success": True,
        "message": "Activity retrieved successfully",
        "data": {
            "count": total_count,
            "created_date": created_date,
            "projects": [],
            "solutions": page,
        },
        "pagination": pagination,
    }


def handle_get_solution_by_request_id(request_id: str, project_name: str = "") -> Dict:
    request_id = (request_id or "").strip()
    if not request_id:
        return {
            "success": False,
            "error": "request_id is required",
        }

    archive_rows = get_archived_payload_references(request_id)
    if not archive_rows:
        return {
            "success": True,
            "request_id": request_id,
            "count": 0,
            "solutions": [],
        }

    solutions = []
    for row in archive_rows:
        s3_key = row.get("s3_key")
        if not s3_key:
            continue

        payload = download_payload_zip(
            s3_key=s3_key,
            expected_sha256=row.get("sha256"),
        )
        solution = payload.get("solution")
        if not isinstance(solution, list):
            solution = []

        solutions.append(
            {
                "file_name": row.get("file_name"),
                "s3_key": s3_key,
                "solution_count": len(solution),
                "solution": solution,
            }
        )

    # Whole-recommendation LLM token usage for this request (dashboard recommendation view).
    # Token rows are stored per PROJECT, so the caller must pass ?projectName= to get real
    # numbers; without it the field is still present with zeros so the UI shape is stable.
    recommendation_token_usage = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0, "llm_calls": 0}
    if str(project_name or "").strip():
        try:
            from src.utils import project_details as _pd
            token_map = _pd.get_token_usage_map_for_project(project_name)
            recommendation_token_usage = token_map.get(request_id) or recommendation_token_usage
        except Exception as e:
            logger.warning("Failed to get token usage for request=%s | %s", request_id, str(e))

    return {
        "success": True,
        "request_id": request_id,
        "count": len(solutions),
        "solutions": solutions,
        "recommendation_token_usage": recommendation_token_usage,
    }


def handle_get_error_messages_by_request_id(request_id: str) -> Dict:
    request_id = (request_id or "").strip()
    if not request_id:
        return {
            "success": False,
            "message": "request_id is required",
            "data": {
                "count": 0,
                "request_id": request_id,
                "errors": [],
            },
        }

    archive_rows = get_archived_payload_references(request_id)
    if not archive_rows:
        return {
            "success": False,
            "message": "No archived payload found for request_id",
            "data": {
                "count": 0,
                "request_id": request_id,
                "errors": [],
            },
        }

    files = []
    all_messages: List[str] = []
    seen = set()

    for row in archive_rows:
        s3_key = row.get("s3_key")
        if not s3_key:
            continue

        payload = download_payload_zip(
            s3_key=s3_key,
            expected_sha256=row.get("sha256"),
        )
        messages = _extract_error_messages(payload)
        unique_messages = []
        for message in messages:
            normalized = _normalize_error_message(message)
            if not normalized:
                continue
            # Path-only variants are the SAME error (the "1/3" view used to show three copies of
            # one failure differing only in D:\AI_Build vs D:\UAT_PROJECTS workspace paths). The
            # dedup key neutralizes volatile parts (paths/timestamps) with the same cleaner the
            # duplicate signatures use, so one failure displays once regardless of where it ran.
            from src.utils.content_fingerprint import clean_volatile_text, clean_volatile_text_for_display
            volatile_free_key = clean_volatile_text(normalized) or normalized
            if volatile_free_key in seen:
                continue
            seen.add(volatile_free_key)
            # Review decision: error text shown on the dashboard is timestamp-free. Cleaning at
            # READ time keeps storage and duplicate signatures untouched and covers old rows too.
            shown = clean_volatile_text_for_display(message)
            unique_messages.append(shown)
            all_messages.append(shown)

        files.append(
            {
                "file_name": row.get("file_name"),
                "s3_key": s3_key,
                "error_count": len(unique_messages),
                "errors": unique_messages,
            }
        )

    return {
        "success": True,
        "message": "Error retrived successfully",
        "data": {
            "count": len(all_messages),
            "request_id": request_id,
            "errors": all_messages,
        },
    }


def handle_delete_requests(data: Dict | None) -> Dict:
    payload = data or {}
    raw_request_ids = payload.get("request_ids")
    if isinstance(raw_request_ids, str):
        request_ids = [raw_request_ids]
    elif isinstance(raw_request_ids, list):
        request_ids = raw_request_ids
    else:
        raise ValueError("request_ids must be a non-empty array")

    normalized_ids = _unique_strings([str(request_id or "").strip() for request_id in request_ids])
    if not normalized_ids:
        raise ValueError("request_ids must contain at least one request id")

    results = [_delete_request_data(request_id) for request_id in normalized_ids]
    for request_id in normalized_ids:
        _write_request_tombstone(request_id)
    # Deleted rows must vanish from the dashboards immediately, not after the cache TTL.
    _invalidate_dashboard_read_cache()
    deleted = sum(1 for row in results if row.get("status") == "deleted")
    partial = sum(1 for row in results if row.get("status") == "partial_failure")
    not_found = sum(1 for row in results if row.get("status") == "not_found")
    failed = sum(1 for row in results if row.get("status") in {"error", "invalid"})

    return {
        "success": partial == 0 and failed == 0,
        "message": "Request cleanup completed",
        "count": len(results),
        "deleted_count": deleted,
        "partial_failure_count": partial,
        "not_found_count": not_found,
        "failed_count": failed,
        "results": results,
    }


def handle_get_week_day_wise_count(project_name: str, s_date: Optional[str] = None, c_date: Optional[str] = None) -> Dict:
    if not s_date or not c_date:
        c_date = datetime.now().strftime("%d-%m-%Y")
        s_date = (datetime.now() - timedelta(days=7)).strftime("%d-%m-%Y")

    results = get_week_sise_count(project_name, s_date, c_date)

    # The error-vs-recommendation graph ALSO shows, per day, how
    # many helpful / not-helpful votes the recommendations received — same date buckets so the
    # feedback bars line up with the error and recommendation bars. Additive fields; fail-open —
    # a feedback problem never breaks the base graph.
    try:
        from src.utils import ttl_cache
        solutions = ttl_cache.get_or_compute(
            ("solutions", str(project_name or "").strip().lower(), s_date, c_date),
            lambda: get_project_solutions(project_name, s_date, c_date))
        helpful_by_day: Dict[str, int] = {}
        not_helpful_by_day: Dict[str, int] = {}

        def _vote_day_key(raw_value) -> str:
            parsed = _parse_created_date(raw_value)
            if parsed == datetime.min:
                return ""
            return parsed.strftime("%Y-%m-%d")

        _votes_by_rid = _feedback_votes_for_rids(
            [str(sol.get("request_id") or "") for sol in solutions]
            + [str(d) for sol in solutions for d in (sol.get("duplicate_request_ids") or [])])
        for sol in solutions:
            rid = str(sol.get("request_id") or "").strip()
            family_ids = [rid] + [str(d).strip() for d in (sol.get("duplicate_request_ids") or [])]
            family_ids = [frid for frid in family_ids if frid]
            if not family_ids:
                continue
            for family_rid in family_ids:
                for vote in _votes_by_rid.get(family_rid, []):
                    day = _vote_day_key(vote.get("Date"))
                    if not day:
                        continue
                    if vote.get("is_helpful") is True:
                        helpful_by_day[day] = helpful_by_day.get(day, 0) + 1
                    elif vote.get("is_helpful") is False:
                        not_helpful_by_day[day] = not_helpful_by_day.get(day, 0) + 1

        for row in results:
            d = str(row.get("day_date") or "")
            row["helpful_count"] = int(helpful_by_day.get(d, 0))
            row["not_helpful_count"] = int(not_helpful_by_day.get(d, 0))

        # A vote can land on a day with no upload row (feedback given later) — add that day
        # inside the selected window so the feedback stays visible on the graph.
        try:
            range_start = datetime.strptime(s_date, "%d-%m-%Y").strftime("%Y-%m-%d")
            range_end = datetime.strptime(c_date, "%d-%m-%Y").strftime("%Y-%m-%d")
        except ValueError:
            range_start, range_end = "", "9999-12-31"
        known_days = {str(r.get("day_date") or "") for r in results}
        for d in sorted(set(helpful_by_day) | set(not_helpful_by_day)):
            if d in known_days or not (range_start <= d <= range_end):
                continue
            results.append({
                "project_name": str(project_name or "").strip().lower(),
                "day_date": d, "error_count": 0, "recommended_count": 0,
                "helpful_count": helpful_by_day.get(d, 0),
                "not_helpful_count": not_helpful_by_day.get(d, 0),
            })
        results.sort(key=lambda r: str(r.get("day_date") or ""))
    except Exception:
        logger.exception("day-wise feedback counts failed — graph returns base counts unchanged")

    return {
        "success": True,
        "results": results
    }


def handle_graph_projects(s_date: Optional[str] = None, c_date: Optional[str] = None) -> Dict:
    if not s_date or not c_date:
        c_date = datetime.now().strftime("%d-%m-%Y")
        s_date = (datetime.now() - timedelta(days=7)).strftime("%d-%m-%Y")
    data = get_graph_projects_data(s_date, c_date)
    return {"success": True, **data}

def handle_recommendations(data: Dict) -> Dict:
    project_name = (data.get("projectName") or data.get("project_name") or "").strip().lower()
    if not project_name:
        return {
            "message": "Recommendations endpoint",
            "success": False,
            "error": "projectName is required",
        }

    error_message = str(data.get("error_message") or "").strip()
    if not error_message:
        return {
            "message": "Recommendations endpoint",
            "projectName": project_name,
            "matched_ids": [],
            "success": False,
            "error": "error_message is required",
        }

    location_values = []
    for key in ("filePath", "path", "taskPath", "taskName", "requestedTasks"):
        val = str(data.get(key) or "").strip()
        if val:
            location_values.append(val)

    # Direct-message callers (including Copilot/extension flows) may not send
    # structured diagnostics. Build backend candidates from message + optional hints.
    pseudo_errors: List[Dict[str, object]] = [
        {"severity": "ERROR", "message": error_message, "locations": location_values}
    ]
    query_candidates = _build_recommendation_query_candidates(pseudo_errors)[:10]
    if not query_candidates:
        query_candidates = [error_message]
    local_patch_contexts = _extract_local_patch_contexts(data)
    top_k = 2
    search_result = _search_recommendation_matches(project_name=project_name, query_candidates=query_candidates, top_k=top_k)
    # Same deterministic task-ledger recall as the report flow: API parity.
    _ledger = _task_ledger_candidates(
        project_name, str(data.get("taskPath") or data.get("taskName") or ""),
        search_result.get("query_signature_hashes"), search_result["vector_matches"])
    for _lm in _ledger:
        search_result["vector_matches"].append(_lm)
        search_result["ids"].append(_lm["vector_id"])
        search_result["metadatas"].append(_lm["meta"])
    results = {
        "ids": [search_result["ids"]],
        "metadatas": [search_result["metadatas"]],
        "query_candidates": query_candidates,
        "query_signature_hashes": search_result["query_signature_hashes"],
        "exact_match_count": search_result["exact_match_count"],
    }

    recommendations = _hydrate_recommendations(
        vector_matches=search_result["vector_matches"],
        project_name=project_name,
        top_k=top_k,
        recommendation_context=_extract_recommendation_context(pseudo_errors),
        local_patch_contexts=local_patch_contexts,
        current_query_signatures=search_result.get("query_signature_hashes"),
        query_task_path=str(data.get("taskPath") or data.get("taskName") or ""),
        query_error_text=str(query_candidates[0] if query_candidates else ""),
    )
    # Consistency: the deterministic relevance layer (downvoted sink,
    # same-task first, distinctive tokens, file identity - the locked rules) ran only in
    # the report-error flow, so this endpoint could rank a DOWNVOTED candidate first while
    # the extension UI would not. Apply the same layer here - API tests now show exactly
    # what developers see.
    recommendations = _rerank_recommendations_for_relevance(
        recommendations,
        query_text=error_message,
        query_task_path=str(data.get("taskPath") or data.get("taskName") or ""),
        query_artifact_text="",
        query_file_names=location_values,
    )
    recommendations = _dedupe_recommendations_by_fix(
        recommendations,
        query_task_path=str(data.get("taskPath") or data.get("taskName") or ""))
    for _i, _rec in enumerate(recommendations):
        _rec["rank"] = _i + 1

    gated = _gate_recommendation_results(
        recommendations,
        top_k=top_k,
        track_hits=True,
        project_name=project_name,
        query_signature_hashes=search_result["query_signature_hashes"],
        trace_context={"endpoint": "recommendations", "query_error": error_message,
                       "task_path": str(data.get("taskPath") or data.get("taskName") or ""),
                       "changed_files": [],
                       "query_context": _extract_recommendation_context(pseudo_errors)},
    )

    return {
        "message": "Recommendations endpoint",
        "projectName": project_name,
        "matched_ids": search_result["ids"],
        "recommendations": gated["recommendations"],
        "weak_recommendations": gated["weak_recommendations"],
        "match_status": gated["match_status"],
        "confidence_score": gated["confidence_score"],
        "source": gated["source"],
        "trace_id": str(gated.get("trace_id") or ""),
        "success": True,
        "results": results
    }

def _extract_json_block_between_markers(html: str) -> str:
    """
    Robustly extract JSON content between begin/end markers from large HTML.
    Uses index + brace-balancing instead of a single regex over the whole file.
    """
    text = html or ""
    lower = text.lower()

    start_marker = "// begin-report-data"
    end_marker = "// end-report-data"

    start_idx = lower.find(start_marker)
    if start_idx == -1:
        raise ValueError("No embedded report data found")

    end_idx = lower.find(end_marker, start_idx + len(start_marker))
    if end_idx == -1:
        # Real Gradle reports only have begin marker — no end marker.
        # Let brace-balancing below find the JSON boundary instead.
        block = text[start_idx + len(start_marker):]
    else:
        block = text[start_idx + len(start_marker):end_idx]
    brace_start = block.find("{")
    if brace_start == -1:
        raise ValueError("No embedded report data found")

    # Balance braces to handle large payloads with nested objects reliably.
    depth = 0
    in_string = False
    escaped = False
    json_start = brace_start
    json_end = -1

    for idx in range(brace_start, len(block)):
        ch = block[idx]

        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue

        if ch == '"':
            in_string = True
            continue

        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                json_end = idx + 1
                break

    if json_end == -1:
        raise ValueError("No embedded report data found")

    return block[json_start:json_end]


def _extract_errors_from_jenkins_messages(html: str) -> List[Dict[str, object]]:
    """
    Fallback extractor for reports that don't embed begin/end JSON markers.
    Parses Jenkins-style HtmlReportJenkinsMessage blocks and SEVERE log lines.
    """
    text = html or ""
    errors: List[Dict[str, object]] = []
    seen = set()

    # 1) Structured HTML-like Jenkins message blocks.
    msg_pattern = re.compile(
        r"<HtmlReportJenkinsMessage>.*?<Description>(.*?)</Description>.*?</HtmlReportJenkinsMessage>",
        re.DOTALL | re.IGNORECASE,
    )
    for match in msg_pattern.finditer(text):
        desc = html_lib.unescape(match.group(1) or "").strip()
        if not desc:
            continue
        norm = " ".join(desc.split())
        if norm in seen:
            continue
        seen.add(norm)
        errors.append({"severity": "ERROR", "message": desc, "locations": []})

    # 2) Generic severe lines, if structured blocks are missing.
    if not errors:
        severe_pattern = re.compile(
            r"SEVERE\s*-\s*.*?(?:\r?\n|$)",
            re.IGNORECASE,
        )
        for match in severe_pattern.finditer(text):
            line = html_lib.unescape((match.group(0) or "").strip())
            if not line:
                continue
            norm = " ".join(line.split())
            if norm in seen:
                continue
            seen.add(norm)
            errors.append({"severity": "ERROR", "message": line, "locations": []})

    return errors


def _extract_diag_locations(diag: Dict) -> List[str]:
    locations = []
    for loc in diag.get("locations", []) or []:
        if not isinstance(loc, dict):
            continue
        path = (loc.get("path") or "").strip()
        task_path = (loc.get("taskPath") or "").strip()
        if path:
            locations.append(path.replace("\\", "/"))
        if task_path:
            locations.append(task_path)
    # keep order, remove duplicates
    out = []
    seen = set()
    for value in locations:
        key = value.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(value)
    return out


def _extract_signal_slices_from_message(message: str, max_slices: int = 4) -> List[str]:
    """
    Break a giant error detail message into smaller, high-signal snippets.
    This keeps recommendation queries robust when one ERROR block contains huge logs.
    """
    text = _maybe_focus(message)
    if not text.strip():
        return []

    lines = [ln.strip() for ln in text.split("\n") if ln and ln.strip()]
    if not lines:
        return []

    signal_patterns = (
        "error",
        "exception",
        "failed",
        "severe",
        "accessdeniedexception",
        "build failed",
        "not found",
        "invalid",
        "cvc-",
    )

    slices: List[str] = []
    for line in lines:
        low = line.lower()
        if any(token in low for token in signal_patterns):
            slices.append(line)
            if len(slices) >= max_slices:
                break

    if not slices:
        # fallback: beginning + middle + end windows from huge message
        n = len(lines)
        probe_indexes = [0, n // 2, n - 1]
        for idx in probe_indexes:
            if 0 <= idx < n:
                slices.append(lines[idx])

    # unique, ordered
    out = []
    seen = set()
    for s in slices:
        k = " ".join(s.split()).lower()
        if not k or k in seen:
            continue
        seen.add(k)
        out.append(s)
    return out[:max_slices]


def _error_raw_mode() -> bool:
    """RAW end-to-end: the same verbatim error text flows through
    collection, embedding and recommendation. The focus window was a guess about where the
    failure 'is' — a character slice that cut mid-word (an anchor began 'ied input
    files', chars 0-36 lost) and could merge one error's identity into a neighbour's.
    The engine judges the WHOLE text; size is handled by line-boundary chunking against
    the embedding budget, never by guessing. Default ON; ERROR_TEXT_RAW_MODE=0 restores
    the legacy focused-slice behavior."""
    return str(os.getenv("ERROR_TEXT_RAW_MODE", "1")).strip().lower() not in ("0", "false", "no", "off")


def _maybe_focus(message: str) -> str:
    """Raw mode: verbatim text (only CR normalization — no content change). Legacy: the
    focused slice."""
    if _error_raw_mode():
        return str(message or "").replace("\r", "")
    return _focus_failure_section(message)


def _focus_failure_section(message: str, window_chars: int | None = None) -> str:
    """
    Huge report error blocks often include long INFO/echo logs.
    Focus on failure-heavy section to avoid noisy embeddings and timeouts.

    The window is the cost/signal limiter for error embeddings. It is tunable per
    deployment via ERROR_FOCUS_WINDOW_CHARS (default 12000) so different toolchains
    (Gradle stacktraces vs. TD5 logs) can size their failure region without a code
    change. If raised above the block-mode embedding budget, the line-boundary
    chunker takes over instead of silently trimming.
    """
    if window_chars is None:
        window_chars = max(2000, int(os.getenv("ERROR_FOCUS_WINDOW_CHARS", "12000")))
    text = (message or "").replace("\r", "")
    if not text:
        return ""

    lower = text.lower()
    markers = [
        "execution failed for task",
        "what went wrong",
        "build failed",
        "severe",
        "exception",
        "failed to",
        "error:",
    ]

    # Prefer the latest marker because root cause often appears near the end.
    marker_pos = -1
    for token in markers:
        pos = lower.rfind(token)
        if pos > marker_pos:
            marker_pos = pos

    if marker_pos == -1:
        # Fallback: keep tail where ant/gradle failure summaries usually end.
        return text[-window_chars:]

    start = max(0, marker_pos - (window_chars // 3))
    end = min(len(text), marker_pos + (2 * window_chars // 3))
    focused = text[start:end]
    return focused if focused.strip() else text[-window_chars:]


def _build_recommendation_query_candidates(errors: List[Dict[str, object]]) -> List[str]:
    candidates: List[str] = []
    seen = set()
    max_candidates = max(2, int(os.getenv("RECOMMENDATION_QUERY_CANDIDATES", "10")))

    for err in errors:
        if not isinstance(err, dict):
            continue

        message = _maybe_focus(str(err.get("message") or "").strip())
        if not message:
            continue

        locations = err.get("locations")
        if not isinstance(locations, list):
            locations = []
        locations = [str(x).strip() for x in locations if str(x).strip()]

        # Use the same cleanup strategy as vectorization first.
        compact_lines = _prepare_messages_for_vectorization([message])
        if not compact_lines:
            compact_lines = _extract_signal_slices_from_message(message)
        if not compact_lines:
            compact_lines = [message]

        for line in compact_lines:
            # plain candidate
            norm = " ".join(line.split()).lower()
            if norm and norm not in seen:
                seen.add(norm)
                candidates.append(line)
                if len(candidates) >= max_candidates:
                    return candidates

            # location-aware candidates
            for loc in locations[:3]:
                combined = f"{loc} | {line}"
                key = " ".join(combined.split()).lower()
                if key in seen:
                    continue
                seen.add(key)
                candidates.append(combined)
                if len(candidates) >= max_candidates:
                    return candidates

    return candidates[:max_candidates]


def _extract_diag_task_and_file_path(diag: Dict) -> tuple:
    """Return (task_path, file_path) from the first populated location in diag."""
    task_path = ""
    file_path = ""
    for loc in diag.get("locations", []) or []:
        if not isinstance(loc, dict):
            continue
        if not task_path:
            tp = (loc.get("taskPath") or "").strip()
            if tp:
                task_path = tp
        if not file_path:
            fp = (loc.get("path") or "").strip()
            if fp:
                file_path = fp.replace("\\", "/")
        if task_path and file_path:
            break
    return task_path, file_path


def _read_text_parts(value) -> str:
    """Read a Gradle report text field in EVERY shape it ships in, losing nothing:
      - Gradle 8.x:  problemDetails / error.parts = LIST of {"text": "..."} dicts
      - Gradle 9.x:  problemDetails               = a single multi-line STRING (the real
                                                    [ERROR] line lives inside it)
      - also tolerated: a LIST of plain strings, or a single {"text": "..."} dict.
    Python port of the extension's readTextParts() so collection + backend agree byte-for-byte."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts: List[str] = []
        for item in value:
            if isinstance(item, str):
                t = item.strip()
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                t = item["text"].strip()
            else:
                t = ""
            if t:
                parts.append(t)
        return "\n".join(parts).strip()
    if isinstance(value, dict) and isinstance(value.get("text"), str):
        return value["text"].strip()
    return ""


def _extract_diagnostic_message(diag: Dict) -> str:
    """Combine ALL text sources for one diagnostic (mirrors the extension's extractDiagnosticMessage):
    problemDetails (the GBE description/log — on Gradle 9.x this carries the real [ERROR] line),
    error.parts (the raw exception/compiler lines), message, and problem (8.x title). No data dropped."""
    if not isinstance(diag, dict):
        return ""
    err = diag.get("error")
    err_parts = err.get("parts") if isinstance(err, dict) else None
    sources = [
        _read_text_parts(diag.get("problemDetails")),
        _read_text_parts(err_parts),
        _read_text_parts(diag.get("message")),
        _read_text_parts(diag.get("problem")),
    ]
    return "\n".join(s for s in sources if s).strip()


def _extract_error_problems_recursive(node) -> List[Dict[str, object]]:
    """Find ERROR problems ANYWHERE in the report JSON. Some report variants nest the problems
    outside the top-level 'diagnostics' array, so the main path sees none. Walks dicts + lists and
    pulls any object with severity==ERROR, reading its text via the shape-robust extractor."""
    out: List[Dict[str, object]] = []
    if isinstance(node, dict):
        sev = str(node.get("severity", "")).upper()
        if sev == "ERROR" and (node.get("problemDetails") is not None or node.get("error") is not None):
            message = _extract_diagnostic_message(node)
            if message:
                task_path, file_path = _extract_diag_task_and_file_path(node)
                locations = _extract_diag_locations(node)
                out.append({
                    "severity": "ERROR",
                    "message": message,
                    "task_path": task_path,
                    "file_path": file_path,
                    "locations": locations,
                })
        for value in node.values():
            out.extend(_extract_error_problems_recursive(value))
    elif isinstance(node, list):
        for item in node:
            out.extend(_extract_error_problems_recursive(item))
    return out


def extract_errors_from_report_html(html: str) -> List[Dict[str, object]]:
    errors: List[Dict[str, object]] = []
    try:
        json_text = _extract_json_block_between_markers(html)
        report_json = json.loads(json_text)
        diagnostics = report_json.get("diagnostics", [])

        for diag in diagnostics:
            if not isinstance(diag, dict):
                continue
            severity = str(diag.get("severity", "UNKNOWN")).upper()
            if severity != "ERROR":
                continue
            locations = _extract_diag_locations(diag)
            task_path, file_path = _extract_diag_task_and_file_path(diag)
            # Shape-robust: handles Gradle 8.x list-of-{text} AND Gradle 9.x string problemDetails,
            # and folds in error.parts/message/problem so we keep the full error context.
            message = _extract_diagnostic_message(diag)
            if message:
                errors.append({
                    "severity": "ERROR",
                    "message": message,
                    "task_path": task_path,
                    "file_path": file_path,
                    "locations": locations,
                })

        # Fallback for report variants that nest the problems outside top-level 'diagnostics'.
        # If the main path found nothing, recursively pull ERROR problems from anywhere.
        if not errors:
            seen = set()
            for e in _extract_error_problems_recursive(report_json):
                if e["message"] not in seen:
                    seen.add(e["message"])
                    errors.append(e)
    except ValueError:
        # Marker block not found: use robust fallback for Jenkins-like report variants.
        errors = _extract_errors_from_jenkins_messages(html)

    if not errors:
        raise ValueError("No errors found in report")

    return errors


def _requested_task_from_report_html(html: str) -> str:
    """The task the USER actually ran (problemsReport.requestedTasks). This
    identity is NEVER stored; it is read live from the report at recommendation time only,
    to confirm same-task and prefer candidates from the very task the user executed.
    Fail-open ''."""
    try:
        report_json = json.loads(_extract_json_block_between_markers(html))
        return str(((report_json or {}).get("problemsReport") or {}).get("requestedTasks") or "").strip()
    except Exception:
        return ""


def extract_errors_from_td5_log(log_text: str) -> List[Dict[str, object]]:
    """TD5 counterpart of extract_errors_from_report_html (GBE parity): TD5 has no
    report.html — the failing build's own <Target>_<BuildType>.log is the error source. The log
    marks failures with [ERR!] lines and names the running build process in
    '++++ Executing [X] build process ++++' banners. Consecutive [ERR!] lines form ONE error
    (a multi-line failure reads as one message, matching the extension's own TD5 parser), and
    the surrounding process name becomes task_path so same-task ranking works unchanged.
    Errors that belong to a build process are ordered FIRST: the pre-process tool-init [ERR!]
    noise must never become the recommendation anchor."""
    errors: List[Dict[str, object]] = []
    current_process = ""
    block: List[str] = []

    def _flush() -> None:
        nonlocal block
        message = "\n".join(block).strip()
        block = []
        if message:
            errors.append({
                "severity": "ERROR",
                "message": message,
                "task_path": current_process,
                "file_path": "",
                "locations": [current_process] if current_process else [],
            })

    for raw_line in str(log_text or "").splitlines():
        line = raw_line.strip()
        banner = re.search(r"\+\+\+\+\s*Executing\s*\[([^\]]+)\]\s*build process", line, re.IGNORECASE)
        if banner:
            _flush()
            current_process = banner.group(1).strip()
            continue
        err = re.match(r"^.*?\[ERR!\]\s*(.*)$", line)
        if err:
            text = err.group(1).strip()
            if text:
                block.append(text)
            continue
        if block:
            _flush()
    _flush()

    # Stable: process-scoped failures lead, tool-init noise (no process context) trails.
    errors.sort(key=lambda e: 0 if e.get("task_path") else 1)

    if not errors:
        raise ValueError("No errors found in report")

    return errors



from urllib.parse import quote

def _write_recommendation_report_html(
    project_name: str,
    query_error: str,
    recommendations: List[Dict],
) -> str:
    report_id = str(uuid.uuid4())
    filename = f"recommendation-{report_id}.html"
    path = os.path.join(REPORT_DIR, filename)

    rows = []
    for rec in recommendations:
        rows.append(
            "<tr>"
            f"<td>{rec.get('rank')}</td>"
            f"<td>{rec.get('vector_id','')}</td>"
            f"<td>{rec.get('request_id','')}</td>"
            f"<td>{rec.get('file_name','')}</td>"
            f"<td><code>{rec.get('s3_key','')}</code></td>"
            f"<td><a href=\"/archive-payload/{rec.get('request_id','')}\">Open Solution</a></td>"
            "</tr>"
        )

    html = (
        "<!doctype html><html><head><meta charset=\"utf-8\">"
        "<title>Recommendation Report</title>"
        "<style>body{font-family:Segoe UI,Arial,sans-serif;padding:20px;}table{border-collapse:collapse;width:100%;}"
        "th,td{border:1px solid #ddd;padding:8px;font-size:13px;}th{background:#f5f5f5;text-align:left;}code{font-size:12px;}"
        "</style></head><body>"
        f"<h2>Recommendation Report</h2><p><b>Project:</b> {project_name}</p>"
        f"<p><b>Query Error:</b> {query_error[:1000]}</p>"
        "<table><thead><tr><th>Rank</th><th>Vector ID</th><th>Request ID</th><th>File Name</th><th>S3 Key</th><th>Solution Link</th></tr>"
        "</thead><tbody>"
        + "".join(rows)
        + "</tbody></table></body></html>"
    )

    with open(path, "w", encoding="utf-8") as fp:
        fp.write(html)
    return filename


def _recommendation_top_k() -> int:
    raw = os.getenv("RECOMMENDATION_TOP_K", os.getenv("RECOMMEND_TOP_K", "5"))
    try:
        value = int(raw)
    except Exception:
        value = 5
    return max(1, min(value, 20))



def _sort_match_priority(match_type: str) -> int:
    mt = (match_type or "").strip().lower()
    if mt == "exact":
        return 0
    # Task-ledger candidates (a simulation showed a candidate scoring 54.3 yet falling into the
    # unknown-type tier, sorted below EVERY semantic row, and the same-solution dedup then
    # collapsed the master twins into the dev instance): same tier as semantic — the final
    # score decides within the tier.
    if mt in ("semantic", "task"):
        return 1
    return 2



def _solution_fingerprint(solution: object) -> str:
    normalized_solution = _normalize_solution_payload(solution)
    if not isinstance(normalized_solution, list):
        return ""
    chunks: List[str] = []
    for item in normalized_solution:
        if not isinstance(item, dict):
            continue
        file_name = str(item.get("fileName") or item.get("filePath") or "").strip().lower()
        changes = item.get("changes")
        if not isinstance(changes, list):
            changes = []
        norm_changes = [" ".join(str(c).split()).lower() for c in changes if str(c).strip()]
        chunks.append(file_name + "|" + "|".join(norm_changes))
    return "||".join(chunks)


def _normalize_solution_payload(solution: object) -> List[Dict]:
    out: List[Dict] = []
    if not isinstance(solution, list):
        return out

    for item in solution:
        if not isinstance(item, dict):
            continue

        file_name = str(item.get("fileName") or item.get("filePath") or "N/A").strip() or "N/A"
        file_path = str(item.get("filePath") or item.get("fileName") or file_name).strip() or file_name

        normalized_changes: List[str] = []
        seen = set()
        has_direct_changes = False

        direct_changes = item.get("changes")
        if isinstance(direct_changes, list):
            for change in direct_changes:
                text = str(change or "").strip()
                if not text or text in seen:
                    continue
                seen.add(text)
                normalized_changes.append(text)
                has_direct_changes = True

        change_objects = item.get("changeObjects")
        if not has_direct_changes and isinstance(change_objects, list):
            for change_obj in change_objects:
                if not isinstance(change_obj, dict):
                    continue
                risk_side = str(change_obj.get("riskSide") or "").strip().lower()
                if risk_side and risk_side != "after":
                    continue
                text = str(change_obj.get("change") or "").strip()
                if not text or text in seen:
                    continue
                seen.add(text)
                normalized_changes.append(text)

        out.append(
            {
                "fileName": file_name,
                "filePath": file_path,
                "changes": normalized_changes,
            }
        )
    return out


def _extract_solution_lines(solution: object) -> List[Dict]:
    lines: List[Dict] = []
    for item in _normalize_solution_payload(solution):
        if not isinstance(item, dict):
            continue
        file_name = str(item.get("fileName") or item.get("filePath") or "N/A").strip() or "N/A"
        changes = item.get("changes")
        if not isinstance(changes, list):
            continue
        for change in changes:
            text = str(change or "").strip()
            if not text:
                continue
            lines.append({"file_name": file_name, "change": text})
    return lines


def _sanitize_change_for_display(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    # Remove metadata markers added for Phase-2 storage/indexing.
    text = re.sub(r"\s*\[\[line:\d+\]\]\s*", " ", text)
    text = re.sub(r"\s*\[\[hunk:\d+\]\]\s*", " ", text)
    text = re.sub(r"^\s*\[\[\d+\]\]\s*", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _sanitize_solution_for_display(solution: object) -> List[Dict]:
    sanitized: List[Dict] = []
    for item in _normalize_solution_payload(solution):
        if not isinstance(item, dict):
            continue
        file_name = str(item.get("fileName") or item.get("filePath") or "N/A").strip() or "N/A"
        file_path = str(item.get("filePath") or item.get("fileName") or file_name).strip() or file_name
        changes = item.get("changes")
        if not isinstance(changes, list):
            changes = []
        normalized_changes = []
        seen = set()
        for change in changes:
            cleaned = _sanitize_change_for_display(str(change or ""))
            if not cleaned or cleaned in seen:
                continue
            seen.add(cleaned)
            normalized_changes.append(cleaned)
        sanitized.append(
            {
                "fileName": file_name,
                "filePath": file_path,
                "changes": normalized_changes,
            }
        )
    return sanitized


def _build_compare_diff_link(request_id: str | None, vector_id: str | None) -> str | None:
    base_url = str(config.BACKEND_PUBLIC_BASE_URL or "").rstrip("/")
    if request_id:
        path = f"/diff_view/request/{request_id}"
        return f"{base_url}{path}" if base_url else path
    if vector_id:
        path = f"/diff_view/{vector_id}"
        return f"{base_url}{path}" if base_url else path
    return None


def _format_report_errors_rows(rows: object, query_error: str = "", llm_analysis: str = "") -> str:
    logger.debug(
        "_format_report_errors_rows | start | rows_count=%d | llm_analysis_present=%s | query_error_preview=%.80s",
        len(rows) if isinstance(rows, list) else 0,
        bool(llm_analysis),
        (query_error or "")[:80],
    )
    if not isinstance(rows, list) or not rows:
        logger.debug("_format_report_errors_rows | no rows | returning empty placeholder")
        no_sol = "No solutions found for current active session."
        if llm_analysis:
            no_sol += f"\n\n---\n\n## LLM Analysis\n\n{llm_analysis}"
        return no_sol

    blocks: List[str] = []
    blocks.append(f"Active Recommendations Found: {len(rows)}")

    for idx, rec in enumerate(rows, start=1):
        if not isinstance(rec, dict):
            continue
        req_id = str(rec.get("request_id") or "").strip()
        compare_link = rec.get("compare_diff_link")
        if req_id:
            compare_link = _build_compare_diff_link(req_id, None)

        lines = [f"Solution {idx}"]

        solution_items = _sanitize_solution_for_display(rec.get("solution") or [])
        has_any_change = False
        if isinstance(solution_items, list) and solution_items:
            for item in solution_items:
                if not isinstance(item, dict):
                    continue
                file_path = item.get("filePath") or item.get("fileName") or "N/A"
                changes = item.get("changes") or []
                if not isinstance(changes, list):
                    changes = []
                for change in changes:
                    change_text = str(change or "").strip() or "No explicit change line"
                    lines.append(f"File name: `{file_path}`")
                    lines.append(f"Exact change line(s): `{change_text}`")
                    has_any_change = True
        else:
            lines.append("File name: `N/A`")
            lines.append("Exact change line(s): `N/A`")

        if not has_any_change and len(lines) == 1:
            lines.append("File name: `N/A`")
            lines.append("Exact change line(s): `N/A`")
        lines.append(f"Request ID: `{req_id or 'N/A'}`")
        lines.append(f"View Diff link: {compare_link or 'N/A'}")

        blocks.append("\n".join(lines))
        logger.debug(
            "_format_report_errors_rows | formatted solution block | idx=%d | request_id=%s | has_change=%s",
            idx, req_id or "N/A", has_any_change,
        )

    result = "\n\n".join(blocks) if blocks else "No solutions found for current active session."
    if llm_analysis:
        result += f"\n\n---\n\n## LLM Analysis\n\n{llm_analysis}"
        logger.debug(
            "_format_report_errors_rows | LLM analysis section appended | llm_analysis_chars=%d | total_chars=%d",
            len(llm_analysis), len(result),
        )
    logger.debug(
        "_format_report_errors_rows | done | blocks=%d | total_chars=%d",
        len(blocks), len(result),
    )
    return result


def _exact_query_signature_hashes(query_candidates: List[str], whole_signature_hashes: List[str]) -> tuple[List[str], List[str]]:
    """Return exact-lookup signatures for both the full query and stored block form."""
    block_signatures: List[str] = []
    try:
        blocks = _prepare_messages_for_vectorization(list(query_candidates or []))
        block_signatures = _signature_hashes_from_candidates(
            [str(block) for block in (blocks or [])], max_hashes=10)
    except Exception:
        logger.warning("[sig-debug] could not compute block-prepared query signatures")
    return list(dict.fromkeys(list(whole_signature_hashes or []) + block_signatures)), block_signatures


def _is_build_script_name(name: str) -> bool:
    """A Gradle build script (*.gradle, *.gradle.kts): where a task is DEFINED, which a report's
    error location names for every failure of that task."""
    base = Path(str(name or "").strip().replace("\\", "/")).name.lower()
    return base.endswith(".gradle") or base.endswith(".gradle.kts")


def _match_request_id(match: Dict) -> str:
    meta = match.get("meta") if isinstance(match, dict) else None
    meta = meta if isinstance(meta, dict) else {}
    return str(meta.get("request_id") or meta.get("batch_id") or "").strip()


def _expand_semantic_hits_to_signature_siblings(
    vector_matches: List[Dict],
    ids: List[str],
    metadatas: List[Dict],
    resolve_requests,
    limit: int = 20,
    per_hit: int = 5,
    max_hits: int = 15,
) -> int:
    """Add every live request stored under a semantic hit's error signature to the pool.

    A stored error vector names only the FIRST request that uploaded that error, so without this
    a semantic hit could never surface a newer fix for the same error. ``resolve_requests(meta,
    fallback_hashes)`` is the same resolver the exact path uses (latest request first, then the
    signature's solution references). Siblings inherit the hit's similarity - their stored error
    IS the same normalised text - and are capped (``per_hit`` per hit, ``limit`` overall, only
    the ``max_hits`` closest hits are expanded) so the lookups stay bounded. Fail-open: a
    resolver error skips that hit. Returns the number of matches added."""
    present = {rid for rid in (_match_request_id(m) for m in vector_matches) if rid}
    semantic = [m for m in vector_matches
                if isinstance(m, dict) and str(m.get("match_type") or "") == "semantic"]
    semantic.sort(key=lambda m: float(m.get("similarity") or 0.0), reverse=True)
    added = 0
    for match in semantic[:max(0, int(max_hits))]:
        if added >= limit:
            break
        meta = match.get("meta") if isinstance(match.get("meta"), dict) else {}
        if not str(meta.get("error_signature_hash") or "").strip():
            continue
        try:
            request_ids = resolve_requests(meta, []) or []
        except Exception:
            logger.exception("signature sibling lookup failed | vector_id=%s", match.get("vector_id"))
            continue
        origin = _match_request_id(match)
        taken = 0
        for rid in request_ids:
            rid = str(rid or "").strip()
            if not rid or rid in present:
                continue
            present.add(rid)
            sibling_meta = dict(meta)
            sibling_meta["request_id"] = rid
            sibling_meta["batch_id"] = rid
            vid = f"{match.get('vector_id')}::req::{rid}"
            sibling = dict(match)
            sibling.update({"vector_id": vid, "meta": sibling_meta, "signature_sibling_of": origin})
            vector_matches.append(sibling)
            ids.append(vid)
            metadatas.append(sibling_meta)
            added += 1
            taken += 1
            if taken >= per_hit or added >= limit:
                break
    return added


def _best_match_per_request(vector_matches: List[Dict]) -> List[Dict]:
    """One match per request, and it is the request's BEST one.

    Hydration keeps the first match it meets for each request, and matches arrive in query
    order - so a fix found at 0.80 by query 0 and at 0.97 by query 3 was scored at 0.80, which
    alone could cost it the top rank. The best match is an exact signature first, then the
    highest similarity; the slot keeps the position of the request's first appearance.
    Matches without a request id pass through untouched."""
    def _strength(match: Dict) -> tuple:
        exact = 1 if str(match.get("match_type") or "").strip().lower() == "exact" else 0
        sim = match.get("similarity")
        return (exact, float(sim) if isinstance(sim, (int, float)) else -1.0)

    out: List[Dict] = []
    position: Dict[str, int] = {}
    for match in vector_matches or []:
        if not isinstance(match, dict):
            continue
        rid = _match_request_id(match)
        if not rid:
            out.append(match)
            continue
        if rid not in position:
            position[rid] = len(out)
            out.append(match)
        elif _strength(match) > _strength(out[position[rid]]):
            out[position[rid]] = match
    return out


def _search_recommendation_matches(project_name: str, query_candidates: List[str], top_k: int, task_path: str = None) -> Dict:
    """
    Search for recommendation matches using exact and semantic search.
    
    Args:
        project_name: Project name for scoping
        query_candidates: List of error message candidates to search
        top_k: Number of top results desired
        task_path: Optional task path for hierarchical filtering (e.g., ":TARGETS:HIP26:aramis")
    
    Returns:
        Dict with vector_matches list containing matched recommendations
    """
    ids: List[str] = []
    metadatas: List[Dict] = []
    seen_vector_ids = set()
    seen_exact_request_ids = set()
    vector_matches: List[Dict] = []
    search_limit = max(top_k * 4, 20)  # Increased minimum from 10 to 20
    summary_cache: Dict[tuple[str, str, str], Dict | None] = {}
    solution_refs_cache: Dict[tuple[str, str, str], List[Dict]] = {}

    def _exact_identity(meta_val: Dict, fallback_hashes: List[str]) -> tuple[str, str] | None:
        error_hash = str(meta_val.get("error_signature_hash") or "").strip().lower()
        env = str(meta_val.get("env") or "prod").strip() or "prod"
        if not error_hash:
            if len(fallback_hashes) == 1:
                error_hash = str(fallback_hashes[0] or "").strip().lower()
            else:
                return None
        return (env, error_hash)

    def _exact_request_candidates(meta: Dict, fallback_hashes: List[str]) -> List[str]:
        meta_val = dict(meta) if isinstance(meta, dict) else {}
        identity = _exact_identity(meta_val, fallback_hashes)
        if identity is None:
            request_id = str(meta_val.get("request_id") or meta_val.get("batch_id") or "").strip()
            return [request_id] if request_id else []
        env, error_hash = identity
        # Group scope: a sibling's vector carries the SIBLING's project name, and its
        # ERROR# summary and SOL# references live under that project - looked up under the query
        # project they were never found. Under project scope owner == project_name, unchanged.
        owner = str(meta_val.get("project_name") or project_name or "").strip().lower() or project_name
        cache_key = (owner, env, error_hash)
        if cache_key not in summary_cache:
            # Env-family resolution on the READ side too (probe evidence: rows live under
            # ('testgbe','test') while vector meta resolves 'prod'/'dev' — the summary was
            # never found, so latest_request_id (the entry the dashboard shows, e.g.
            # d204cbdb) could never surface and the stage fell back to the vector's own id).
            resolved_env = _resolve_signature_env(owner, env, error_hash)
            summary_cache[cache_key] = get_error_signature_summary(owner, resolved_env, error_hash)
            solution_refs_cache[cache_key] = get_error_solution_references_summary_first(owner, resolved_env, error_hash)
        if cache_key not in solution_refs_cache:
            solution_refs_cache[cache_key] = []

        out: List[str] = []
        latest_request_id = str((summary_cache.get(cache_key) or {}).get("latest_request_id") or "").strip()
        if latest_request_id:
            out.append(latest_request_id)
        for row in solution_refs_cache.get(cache_key) or []:
            req_id = str(row.get("request_id") or "").strip()
            if req_id and req_id not in out:
                out.append(req_id)
        if not out:
            request_id = str(meta_val.get("request_id") or meta_val.get("batch_id") or "").strip()
            if request_id:
                out.append(request_id)
        return out

    query_signature_hashes = _signature_hashes_from_candidates(query_candidates, max_hashes=10)
    # Storage signs the prepared failure block in block mode. Search the same representation as
    # well as the full query, otherwise identical stored errors miss exact lookup when the report
    # contains additional wrapper/context text.
    exact_signature_hashes, block_signature_hashes = _exact_query_signature_hashes(
        query_candidates, query_signature_hashes)
    logger.info("[sig-debug] query signatures whole-text=%s | block-prepared=%s",
                [h[:16] for h in (query_signature_hashes or [])[:3]],
                [h[:16] for h in (block_signature_hashes or [])[:3]])
    exact = search_errors_by_signatures(
        project_name=project_name,
        signature_hashes=exact_signature_hashes,
        top_k=search_limit,
    )
    exact_ids = (exact.get("ids") or [[]])[0] or []
    exact_metas = (exact.get("metadatas") or [[]])[0] or []
    exact_docs = (exact.get("documents") or [[]])[0] or []
    for idx, vector_id in enumerate(exact_ids):
        if not vector_id:
            continue
        meta = exact_metas[idx] if idx < len(exact_metas) else {}
        meta_val = meta if isinstance(meta, dict) else {}
        doc_text = _safe_doc_text(exact_docs[idx] if idx < len(exact_docs) else None) or _safe_doc_text(meta_val.get("error_message"))
        request_candidates = _exact_request_candidates(meta_val, exact_signature_hashes)
        if not request_candidates:
            request_candidates = [str(meta_val.get("request_id") or meta_val.get("batch_id") or "").strip()]
        for req_id in request_candidates:
            req_id = str(req_id or "").strip()
            if not req_id or req_id in seen_exact_request_ids:
                continue
            seen_exact_request_ids.add(req_id)
            synthetic_vector_id = f"{vector_id}::req::{req_id}"
            exact_meta = dict(meta_val)
            exact_meta["request_id"] = req_id
            exact_meta["batch_id"] = req_id
            ids.append(synthetic_vector_id)
            metadatas.append(exact_meta)
            vector_matches.append(
                {
                    "vector_id": synthetic_vector_id,
                    "meta": exact_meta,
                    "match_type": "exact",
                    "document": doc_text,
                    "distance": 0.0,
                    "similarity": 1.0,
                }
            )
            if len(vector_matches) >= search_limit:
                break
        seen_vector_ids.add(vector_id)
        if len(vector_matches) >= search_limit:
            break

    # FAIR QUERY BUDGET. The loop used to stop as soon as the pool held search_limit matches -
    # counting the exact matches too - so query[0] alone (often a "location | text" variant or a
    # noisy first line) could fill the pool and the remaining prepared queries never ran. Each
    # query now gets its own share of NEW candidates, the exact matches no longer consume the
    # semantic budget, and RECOMMENDATION_SEMANTIC_QUERY_LIMIT bounds the number of searches.
    try:
        _sem_query_limit = max(1, int(os.getenv("RECOMMENDATION_SEMANTIC_QUERY_LIMIT", "10")))
    except (TypeError, ValueError):
        _sem_query_limit = 10
    _sem_queries = list(query_candidates or [])[:_sem_query_limit]
    _per_query_cap = max(5, -(-search_limit // max(1, len(_sem_queries))))
    _semantic_cap = search_limit * 2
    _semantic_added = 0
    # vector_id -> index in vector_matches, so a vector found again by a CLOSER query keeps
    # the better similarity instead of whichever query happened to run first.
    _semantic_index: Dict[str, int] = {}
    _sem_queries_run = 0
    for _cand_idx, candidate in enumerate(_sem_queries):
        if _semantic_added >= _semantic_cap:
            break
        _sem_queries_run += 1
        _added_this_query = 0
        results = search_similar_errors_fused(
            candidate,
            project_name=project_name,
            top_k=search_limit,
            task_path=task_path,
            # Error->solution recommendations must stay project-scoped: a cross-project
            # fix references paths that don't exist here.
            allow_global_fallback=_reco_global_fallback_enabled(),
        )
        candidate_ids = (results.get("ids") or [[]])[0] or []
        candidate_metas = (results.get("metadatas") or [[]])[0] or []
        candidate_docs = (results.get("documents") or [[]])[0] or []
        candidate_dists = (results.get("distances") or [[]])[0] or []

        for idx, vector_id in enumerate(candidate_ids):
            if not vector_id:
                continue
            if vector_id in _semantic_index:
                # Seen through an earlier query: keep the BEST similarity this vector reaches.
                try:
                    _d = float(candidate_dists[idx]) if idx < len(candidate_dists) else None
                except (TypeError, ValueError):
                    _d = None
                if _d is not None:
                    _s = max(0.0, min(1.0, 1.0 - _d / 2.0))
                    _prev = vector_matches[_semantic_index[vector_id]]
                    if _s > float(_prev.get("similarity") or 0.0):
                        _prev["similarity"] = _s
                        _prev["distance"] = _d
                        _prev["query_candidate_index"] = _cand_idx
                continue
            if vector_id in seen_vector_ids:
                continue
            if _added_this_query >= _per_query_cap or _semantic_added >= _semantic_cap:
                break
            seen_vector_ids.add(vector_id)
            ids.append(vector_id)
            meta = candidate_metas[idx] if idx < len(candidate_metas) else {}
            meta_val = meta if isinstance(meta, dict) else {}
            doc_text = _safe_doc_text(candidate_docs[idx] if idx < len(candidate_docs) else None) or _safe_doc_text(meta_val.get("error_message"))
            metadatas.append(meta_val)
            # Root cause of flat scores: the search RETURNS the distance but ranking never used
            # it - a barely-related nearest neighbor scored like a near-identical one. Capture the
            # raw distance + a clamped similarity on every match: always traced, and applied
            # to scoring only behind the admin flag (similarityWeightedScoring).
            raw_dist = None
            if idx < len(candidate_dists):
                try:
                    raw_dist = float(candidate_dists[idx])
                except (TypeError, ValueError):
                    raw_dist = None
            similarity = None
            if raw_dist is not None:
                # The store returns squared-L2 distance = 2*(1-cosine),
                # range [0,2] - similarity is 1 - d/2 THROUGHOUT. The previous two-branch
                # mapping was non-monotonic at d=1 (a cos-0.55 candidate scored 0.10 while a
                # cos-0.49 one scored 0.49), corrupting the floor and the similarity weighting.
                similarity = max(0.0, min(1.0, 1.0 - raw_dist / 2.0))
            _ab = meta_val.get("adapter_rank_base")
            _al = meta_val.get("adapter_rank_learned")
            _adapter_influence = None
            if _ab is not None or _al is not None:
                # The adapter must be shown as what it does to the
                # SIMILARITY, not only to the rank. Both distances survive the fusion now, so
                # each is mapped through the same 1 - d/2 the base similarity uses - comparing
                # two numbers produced by different formulas would be worse than showing none.
                def _sim(dist):
                    if dist is None:
                        return None
                    try:
                        return max(0.0, min(1.0, 1.0 - float(dist) / 2.0))
                    except (TypeError, ValueError):
                        return None

                _sim_base = _sim(meta_val.get("adapter_distance_base"))
                _sim_learned = _sim(meta_val.get("adapter_distance_learned"))
                _adapter_influence = {
                    "base_rank": _ab, "learned_rank": _al,
                    "source": "both" if (_ab and _al) else ("learned" if _al else "base"),
                    # Which space produced this pool - "learned" when the adapter is on
                    # for the project (its similarity is the one scored), "base" otherwise.
                    "space": meta_val.get("adapter_space") or "base",
                    "similarity_base": _sim_base,
                    "similarity_with_adapter": _sim_learned,
                    # Only meaningful when the candidate surfaced in BOTH spaces. When it did
                    # not, the honest answer is "not retrieved there", which the None above says.
                    "similarity_delta": (round(_sim_learned - _sim_base, 4)
                                         if (_sim_base is not None and _sim_learned is not None)
                                         else None),
                }
            vector_matches.append(
                {
                    "vector_id": vector_id,
                    "meta": meta_val,
                    # WHICH prepared query line found this match - the
                    # budget is shared across candidates, so without this nobody can tell
                    # whether candidates beyond [0] ever contribute.
                    "query_candidate_index": _cand_idx,
                    "match_type": "semantic",
                    "document": doc_text,
                    "distance": raw_dist,
                    "similarity": similarity,
                    "adapter_influence": _adapter_influence,
                }
            )
            _semantic_index[vector_id] = len(vector_matches) - 1
            _added_this_query += 1
            _semantic_added += 1

    # NEWER FIXES OF THE SAME ERROR. A stored error vector is shared by every request with that
    # signature and its metadata names the FIRST uploader, so a semantic hit only ever surfaced
    # the oldest fix - the newer (often the right) one was reachable only through an exact
    # signature match. Semantic hits are now expanded exactly like exact hits: every live
    # request stored under the hit's signature joins the pool with the hit's similarity.
    _sibling_added = _expand_semantic_hits_to_signature_siblings(
        vector_matches, ids, metadatas, _exact_request_candidates, limit=search_limit)

    logger.info("[FLOW-DEBUG] semantic queries run: %d of %d prepared candidate(s) | matches=%d "
                "| per-query cap=%d | same-signature siblings added=%d",
                _sem_queries_run, len(query_candidates or []), len(vector_matches),
                _per_query_cap, _sibling_added)
    return {
        "ids": ids,
        "metadatas": metadatas,
        "vector_matches": vector_matches,
        "query_signature_hashes": query_signature_hashes,
        "exact_match_count": len(exact_ids),
    }


def _task_ledger_candidates(project_name: str, task_path: str,
                            query_signature_hashes: List[str] | None,
                            existing_matches: List[Dict], limit: int = 5) -> List[Dict]:
    """Deterministic recall by TASK IDENTITY (in a live case a master-task
    solution whose vectors were never built was unfindable by the semantic engine, so the
    user was shown a dev-task twin). The failing task in the user's LIVE system is a hard
    key: every stored solution of this project+task deserves scoring, vectors or no vectors.
    ADDITIVE only — the vector results are never removed or reordered; scoring judges what
    this adds. A stored error whose signature equals the query's enters as EXACT (it IS the
    same failure); otherwise as match_type 'task' with the semantic base score. Self-heals:
    a surfaced request with no vectors is re-enqueued for vectorization so the semantic
    engine recovers it on future requests. Fail-open: never breaks the vector results."""
    try:
        query_task = _canonical_task_token(task_path)
        if not query_task:
            return []
        proj = str(project_name or "").strip().lower()
        from src.utils import ttl_cache
        from src.utils.project_details import list_final_build_payloads_by_project
        # Group scope: the ledger reads the payload rows of EVERY project in scope, so a
        # sibling's fix stored under the same task is a candidate too. Project scope = [proj].
        try:
            _scope, _smode = _reco_scope_members(proj)
        except Exception:
            _scope, _smode = [proj], "project"
        rows: List[Dict] = []
        for _member in (_scope or [proj]):
            rows.extend(ttl_cache.get_or_compute(
                ("task-ledger-payloads", _member),
                lambda _m=_member: list_final_build_payloads_by_project(_m),
                deep_copy=False,
            ) or [])
        existing_ids = set()
        for m in existing_matches or []:
            meta = (m or {}).get("meta") or {}
            rid = str(meta.get("request_id") or meta.get("batch_id") or "").strip()
            if rid:
                existing_ids.add(rid)
        q_sigs = {str(h).strip().lower() for h in (query_signature_hashes or []) if str(h).strip()}
        same_task = [r for r in rows
                     if _canonical_task_token(str((r or {}).get("task_name") or "")) == query_task
                     and str((r or {}).get("request_id") or "").strip()
                     and str((r or {}).get("request_id") or "").strip() not in existing_ids]
        same_task = [
            row for row in same_task
            if _normalize_solution_payload(
                (row.get("payload_json") if isinstance(row.get("payload_json"), dict) else {}).get("solution")
            )
        ]
        same_task.sort(key=lambda r: str(r.get("created_date") or ""), reverse=True)
        out: List[Dict] = []
        for row in same_task[:max(1, int(limit))]:
            rid = str(row.get("request_id") or "").strip()
            payload = row.get("payload_json") if isinstance(row.get("payload_json"), dict) else {}
            error_texts = _extract_error_messages(payload) or []
            if not error_texts:
                # The final-build row's payload_json is TRIMMED (no errorDetails) — the errors
                # live in the ARCHIVED payload, exactly where vectorization reads them (sim log
                # 19:49: ledger doc empty -> distinct=0 and no exact-signature chance, while
                # the same request's vectorization found raw_messages=2 from the archive).
                # One S3 download per candidate, cached for an hour.
                def _archived_errors(rid=rid):
                    try:
                        rows_a = get_archived_payload_references(rid)
                        if rows_a:
                            arch = download_payload_zip(
                                s3_key=rows_a[0]["s3_key"],
                                expected_sha256=rows_a[0].get("sha256"))
                            return _extract_error_messages(arch) or []
                    except Exception:
                        logger.warning("[task-ledger] archived-error fetch failed | request_id=%s", rid)
                    return []
                error_texts = ttl_cache.get_or_compute(
                    ("ledger-errtext", rid), _archived_errors,
                    deep_copy=False, ttl_override=3600) or []
            error_text = str(error_texts[0] if error_texts else "").strip()
            # The SAME text the store embedded. A ledger row's cosine is measured against the
            # block-prepared form of its error (what save_errors_on_vector_db_batch vectorised),
            # not the raw first message - otherwise its similarity sits on a different basis
            # from every semantic row's and the column cannot be compared across rows.
            try:
                _prepared = _prepare_messages_for_vectorization([error_text]) if error_text else []
            except Exception:
                _prepared = []
            embed_text = str(_prepared[0]).strip() if _prepared else error_text
            sig_hit = False
            if error_texts and q_sigs:
                cand_sigs = {str(h).strip().lower()
                             for h in _signature_hashes_from_candidates(error_texts[:3], max_hashes=5)}
                sig_hit = bool(cand_sigs & q_sigs)
            out.append({
                "vector_id": f"ledger:{rid}",
                "meta": {
                    "request_id": rid,
                    "project_name": str(row.get("project_name") or proj).strip().lower(),
                    "task_path": str(row.get("task_name") or ""),
                    "error_message": error_text[:1000],
                    "recall_source": "task_ledger",
                },
                "match_type": "exact" if sig_hit else "task",
                "document": embed_text,
                "distance": 0.0 if sig_hit else None,
                "similarity": 1.0 if sig_hit else None,
            })
            # Self-heal: without vectors the semantic engine can never find this row on its
            # own — force the build so the NEXT request retrieves it normally. NOTE the
            # shared-vector design (one vector per unique signature, owned by the FIRST
            # request; siblings resolve at hydrate time): a sibling-served request has no
            # vector rows of its own, so this check re-fires for it forever. The writes are
            # idempotent (signature-index upserts), so the heal is rate-limited per request
            # instead of made design-aware — once per hour is plenty.
            try:
                def _heal(rid=rid):
                    from src.utils.recommended import collection as _err_coll
                    if not (_err_coll.get(where={"request_id": rid}, limit=1) or {}).get("ids"):
                        logger.info("[task-ledger] %s has no OWN error vectors — re-enqueueing "
                                    "vectorization (shared-vector siblings are healed by the "
                                    "signature index upsert)", rid)
                        _enqueue_vectorization(rid, force=True)
                    return 1
                # get_or_compute runs _heal only on a cache miss — at most once per hour per
                # request, no matter how often the ledger surfaces it.
                ttl_cache.get_or_compute(("ledger-heal", rid), _heal,
                                         deep_copy=False, ttl_override=3600)
            except Exception:
                logger.warning("[task-ledger] vector self-heal check failed | request_id=%s", rid)
        if out:
            logger.info(
                "[task-ledger] added %d stored solution(s) of task '%s' missed by vector search: %s",
                len(out), query_task,
                [(str(o["meta"]["request_id"])[:8], o["match_type"]) for o in out],
            )
        return out
    except Exception:
        logger.exception("task-ledger recall failed (vector results unaffected)")
        return []


def _extract_recommendation_context(errors: List[Dict[str, object]]) -> Dict[str, List[str]]:
    task_paths: List[str] = []
    file_names: List[str] = []
    tokens: List[str] = []
    seen_tasks = set()
    seen_files = set()
    seen_tokens = set()

    for err in errors:
        if not isinstance(err, dict):
            continue

        # Use dedicated task_path field extracted from HTML (preferred).
        tp = str(err.get("task_path") or "").strip()
        if tp:
            key = tp.lower()
            if key not in seen_tasks:
                seen_tasks.add(key)
                task_paths.append(tp)

        # Use dedicated file_path field extracted from HTML (preferred).
        fp = str(err.get("file_path") or "").strip()
        if fp:
            file_name = Path(fp.replace("\\", "/")).name
            key = file_name.lower()
            if file_name and key not in seen_files:
                seen_files.add(key)
                file_names.append(file_name)

        # Fall back to flat locations list for backward compatibility.
        if not tp or not fp:
            for loc in err.get("locations") or []:
                value = str(loc or "").strip()
                if not value:
                    continue
                if value.startswith(":"):
                    key = value.lower()
                    if key not in seen_tasks:
                        seen_tasks.add(key)
                        task_paths.append(value)
                else:
                    file_name = Path(value.replace("\\", "/")).name
                    key = file_name.lower()
                    if file_name and key not in seen_files:
                        seen_files.add(key)
                        file_names.append(file_name)

        # Signal-first tokens (the wording-tier philosophy, extended after a
        # live mis-rank): a GBE report message BEGINS with install/progress chatter, so the
        # 16-token cap filled up with 'created/inputs/snapshot/copied...' before ever reaching
        # the failure lines at the bottom — the actual discriminator ('...but got 6.2r1p456')
        # never became a context token, and every same-environment candidate matched the
        # chatter. Failure-signal lines feed the tokens FIRST; the full message only fills
        # whatever room is left (texts with no signal lines behave exactly as before).
        msg = str(err.get("message") or "")
        # Bare path arguments (a command line echoed into the report) can carry marker words
        # INSIDE the path ("D:\Build type error\...") and would flood the signal tokens with
        # folder names. A line that IS a path has no failure phrasing of its own — drop it
        # from the signal text; the full message still fills the remaining token room.
        signal_text = "\n".join(
            ln for ln in _failure_signal_lines(msg)
            if not re.match(r"^\s*(?:[A-Za-z]:[\\/]|[\\/]{2})", ln))
        for token in _extract_config_tokens(signal_text, msg):
            if token in seen_tokens:
                continue
            seen_tokens.add(token)
            tokens.append(token)
            if len(tokens) >= 16:
                break

    return {
        "task_paths": task_paths,
        "file_names": file_names,
        "tokens": tokens,
    }


def _recommended_hit_count(final_payload: Dict | None) -> int:
    if not isinstance(final_payload, dict):
        return 0
    history = final_payload.get("recommended_count", [])
    if not isinstance(history, list):
        return 0
    return len(history)


def _parse_iso_utc(value: str) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        if text.endswith("Z"):
            return datetime.fromisoformat(text.replace("Z", "+00:00"))
        return datetime.fromisoformat(text)
    except Exception:
        return None


def _days_since(value: str, now: datetime | None = None) -> float:
    dt = _parse_iso_utc(value)
    if not dt:
        return 9999.0
    now_dt = now or datetime.now(UTC)
    try:
        delta = now_dt - dt
        return max(0.0, delta.total_seconds() / 86400.0)
    except Exception:
        return 9999.0


def _recommendation_success_score(
    request_id: str,
    summary_cache: Dict[str, Dict | None],
    outcomes_cache: Dict[str, List[Dict]],
) -> float:
    req_id = str(request_id or "").strip()
    if not req_id:
        return 0.0

    if req_id not in summary_cache:
        summary_cache[req_id] = get_recommendation_outcome_summary(req_id)
    if req_id not in outcomes_cache:
        outcomes_cache[req_id] = list_recommendation_outcomes(req_id)

    summary = summary_cache.get(req_id) or {}
    outcomes = outcomes_cache.get(req_id) or []
    now = datetime.now(UTC)

    hit_count = int(summary.get("hit_count") or 0)
    # View-derived history (hit_count and "shown" outcomes) is scaled by shownHistoryWeight
    # (default 0): being displayed is not success. Confirmed successes count in full.
    _shown_w = _rc_value("shownHistoryWeight", 0.0, 1.0)
    base = min(3.0, float(hit_count) * 0.25) * _shown_w

    success_score = 0.0
    success_events = 0
    shown_events = 0
    for item in outcomes:
        outcome_type = str(item.get("outcome_type") or "").strip().lower()
        age_days = _days_since(str(item.get("created_date") or ""), now=now)
        decay = 1.0 / (1.0 + (age_days / 30.0))
        if outcome_type == "success_correlated":
            success_events += 1
            success_score += 3.0 * decay
        elif outcome_type == "shown":
            shown_events += 1
            success_score += 0.15 * decay * _shown_w

    ratio_bonus = 0.0
    if success_events > 0:
        ratio = success_events / max(1, shown_events)
        ratio_bonus = min(3.0, ratio * 3.0)

    return min(10.0, base + success_score + ratio_bonus)


def _build_successful_after_fix_frequency_map(
    recommendations: List[Dict],
    fix_instance_cache: Dict[str, List[Dict]],
    outcomes_cache: Dict[str, List[Dict]],
) -> Dict[str, float]:
    freq: Dict[str, float] = {}
    now = datetime.now(UTC)
    for rec in recommendations:
        request_id = str(rec.get("request_id") or "").strip()
        if not request_id:
            continue
        outcomes = outcomes_cache.get(request_id) or []
        success_weight = 0.0
        for item in outcomes:
            if str(item.get("outcome_type") or "").strip().lower() != "success_correlated":
                continue
            age_days = _days_since(str(item.get("created_date") or ""), now=now)
            success_weight += 1.0 / (1.0 + (age_days / 30.0))
        if success_weight <= 0:
            continue
        for fix in fix_instance_cache.get(request_id, []):
            if str(fix.get("risk_side") or "").strip().lower() != "after":
                continue
            fp = str(fix.get("change_fingerprint") or "").strip()
            if not fp:
                continue
            freq[fp] = float(freq.get(fp) or 0.0) + success_weight
    return freq


_MIN_CHANGE_CHARS = 12


def _norm_change(value: str) -> str:
    """Whitespace collapsed and case dropped, so indentation does not hide a real match."""
    return re.sub(r"\s+", " ", str(value or "")).strip().lower()


def _file_content_agreement(final_payload: Dict | None, matched_files: List[str],
                            file_contents: List[str]) -> List[str]:
    """Which of this fix's changed lines are actually present in the developer's current file.

    Only lines belonging to a file whose NAME already matched are considered - a line found in some
    unrelated file says nothing about this one.

    Cheap on purpose: the changed lines are already on the payload and the current file already
    arrived with the request, so this is a string comparison over text held in memory.
    """
    if not matched_files or not file_contents:
        return []

    haystack = " ".join(_norm_change(t) for t in file_contents if t)
    if not haystack.strip():
        return []

    wanted = {str(f).strip().lower() for f in matched_files if f}
    hits: List[str] = []
    for line in _extract_solution_lines((final_payload or {}).get("solution", [])):
        raw_name = str(line.get("file_name") or "").replace("\\", "/")
        if Path(raw_name).name.strip().lower() not in wanted:
            continue
        needle = _norm_change(str(line.get("change") or ""))
        # A brace, a closing tag, a blank line - these match everything and prove nothing.
        if len(needle) < _MIN_CHANGE_CHARS:
            continue
        if needle in haystack and needle not in hits:
            hits.append(needle)
            if len(hits) >= 5:
                break
    return hits


def _fix_context_score(
    *,
    fix_instances: List[Dict],
    final_payload: Dict | None,
    context: Dict[str, List[str]],
    details: Dict | None = None,
) -> float:
    # details (WHAT context matched, not just the number): when a dict is
    # passed, it is filled with the named matches behind every point - recorded in the trace.
    score = 0.0
    task_paths = {str(x).strip().lower() for x in context.get("task_paths", []) if str(x).strip()}
    file_names = {Path(str(x).strip().replace("\\", "/")).name.lower()
                  for x in context.get("file_names", []) if str(x).strip()}
    file_names.discard("")
    tokens = {str(x).strip().lower() for x in context.get("tokens", []) if str(x).strip()}

    # IDENTITY COUNTS ONCE. The observed defect: a different task name made the scores far too
    # low, while a candidate whose artifact did not match at all but whose task name was the
    # same scored high.
    # The old tier awarded task/file/token points PER FIX INSTANCE, so the SAME identity fact
    # was paid once per confirmation: the live case gave a wrong-root-cause candidate
    # 8 + 10x2 = 28 task points (base 33) against the right candidate's 5, a 28-point head
    # start that no artifact evidence could overcome. "This solution belongs to the failing
    # task" is ONE fact worth ONE bounded amount; how OFTEN it was confirmed already has its
    # own honest channels (usage hits, success score, after-fix pattern). Weights are
    # admin-tunable (baseTaskWeight/baseFileWeight/baseTokenWeight) so balancing needs no
    # release, and every component is reported in details for the trace breakdown.
    try:
        _cfg = _rc_get_config_cached() or {}
        _w_task = _rc_value("baseTaskWeight")
        _w_file = _rc_value("baseFileWeight")
        _w_token = _rc_value("baseTokenWeight")
        # Extra points when the fix's own changed lines are actually present in the
        # file the developer is looking at. Default 0 - nothing changes until it is switched on.
        _w_content = max(0.0, float(_cfg.get("fileContentMatchWeight", 0.0)))
    except Exception:
        _w_task = _rc_value("baseTaskWeight")
        _w_file = _rc_value("baseFileWeight")
        _w_token = _rc_value("baseTokenWeight")
        _w_content = 0.0

    request_task = str((final_payload or {}).get("task_name") or "").strip().lower()
    matched_fix_tasks = []
    matched_files = []
    best_token_overlap = []
    task_hit = bool(request_task and request_task in task_paths)
    if task_hit and isinstance(details, dict):
        details["candidate_task_in_query_tasks"] = request_task

    for fix in fix_instances:
        fix_task = str(fix.get("task_path") or "").strip().lower()
        # Basename on both sides: a fix stored with a full path must still match "config.xml".
        fix_file = Path(str(fix.get("file_name") or "").strip().replace("\\", "/")).name.lower()
        if fix_task and fix_task in task_paths:
            task_hit = True
            if fix_task not in matched_fix_tasks:
                matched_fix_tasks.append(fix_task)
        if fix_file and fix_file in file_names and fix_file not in matched_files:
            matched_files.append(fix_file)

        fix_tokens = {str(x).strip().lower() for x in (fix.get("config_tokens") or []) if str(x).strip()}
        if fix_tokens and tokens:
            overlap_set = fix_tokens & tokens
            if len(overlap_set) > len(best_token_overlap):
                best_token_overlap = sorted(overlap_set)

    task_points = _w_task if task_hit else 0.0
    file_points = _w_file if matched_files else 0.0
    token_points = min(_w_token, float(len(best_token_overlap)))

    # The name matching is kept as it is. This is added on top, and only when the fix's own changed
    # lines are found in the file the developer currently has - which is the difference between
    # "a file of this name exists" and "this fix belongs to this file".
    content_hits: List[str] = []
    content_points = 0.0
    if _w_content > 0 and matched_files:
        content_hits = _file_content_agreement(
            final_payload, matched_files,
            [str(x) for x in (context.get("file_contents") or []) if str(x).strip()])
        if content_hits:
            content_points = _w_content

    score += task_points + file_points + token_points + content_points

    # Times this fix was SHOWN before. A view is not evidence the fix is right for THIS failure,
    # and counting it made the ranking feed itself (shown -> more points -> shown again), so a
    # newer, closer fix could not overtake. Scaled by usageHitsWeight (default 0 = off).
    hits = min(3.0, float(_recommended_hit_count(final_payload))) * _rc_value("usageHitsWeight", 0.0, 1.0)
    score += hits
    if isinstance(details, dict):
        # The exact arithmetic behind the base number, for the trace, so a reader can go
        # inside the context score and see how the number came about.
        details["points"] = {"task": round(task_points, 2), "file": round(file_points, 2),
                             "tokens": round(token_points, 2), "hits": round(hits, 2),
                             "file_content": round(content_points, 2)}
        if content_hits:
            details["matched_file_lines"] = content_hits[:5]
    if isinstance(details, dict):
        if matched_fix_tasks:
            details["matched_fix_tasks"] = matched_fix_tasks[:5]
        if matched_files:
            details["matched_files"] = matched_files[:5]
        if best_token_overlap:
            details["matched_tokens"] = best_token_overlap[:8]
        if hits:
            details["usage_hits_points"] = hits
    return score


def _extract_local_patch_contexts(data: Dict | None) -> List[str]:
    if not isinstance(data, dict):
        return []

    candidates: List[str] = []
    multi = data.get("local_patch_contexts")
    if isinstance(multi, list):
        for item in multi:
            text = str(item or "").strip()
            if text:
                candidates.append(text)

    for key in ("local_patch_context", "current_patch_context", "current_file_context", "patch_context"):
        text = str(data.get(key) or "").strip()
        if text:
            candidates.append(text)

    out: List[str] = []
    seen = set()
    for text in candidates:
        key = hashlib.sha1(text.encode("utf-8")).hexdigest()
        if key in seen:
            continue
        seen.add(key)
        out.append(text)
    return out[:5]


def _cosine_similarity(vec_a: List[float], vec_b: List[float]) -> float:
    if not isinstance(vec_a, list) or not isinstance(vec_b, list):
        return 0.0
    if not vec_a or not vec_b or len(vec_a) != len(vec_b):
        return 0.0
    dot = 0.0
    norm_a = 0.0
    norm_b = 0.0
    for a, b in zip(vec_a, vec_b):
        fa = float(a)
        fb = float(b)
        dot += fa * fb
        norm_a += fa * fa
        norm_b += fb * fb
    if norm_a <= 0.0 or norm_b <= 0.0:
        return 0.0
    return dot / ((norm_a ** 0.5) * (norm_b ** 0.5))


def _task_recall_similarity(query_text: str, candidate_text: str,
                            embedding_cache: Dict[str, List[float]]) -> float | None:
    """The similarity a task-recall candidate was never given.

    The task ledger surfaces a candidate by task identity alone and leaves its similarity at
    None, and nothing downstream filled it in - so the base of 12 was never scaled. A candidate
    that was never compared to the failure earned MORE match points than one compared and
    scored 0.71 (live, 07-Oct: two task-recall rows at a flat 12.00 above a 0.71 row at 8.55).

    Measured the same way the vector store measures it - cosine of the two embeddings - so the
    figure sits on the same scale as every other row's (the store's distance is 2(1-cos) and the
    search maps it back with 1 - d/2, which IS the cosine). Both texts go through the same
    create_embedding, so the same first-lines window applies to both sides.

    None when either text is empty or an embedding could not be produced: the caller keeps the
    unscaled base in that case, exactly as before, and the trace still reads 'task recall'.
    """
    q = str(query_text or "").strip()
    c = str(candidate_text or "").strip()
    if not q or not c:
        return None
    # The SAME budget the stored vectors and the semantic query are built with
    # (error_embed_budget): the embedder's defaults kept the first 40 lines, so this cosine was
    # measured on the preamble while every semantic row's was measured on the whole block.
    _chars, _lines, _tokens = error_embed_budget()
    for text in (q, c):
        if text not in embedding_cache:
            try:
                embedding_cache[text] = create_embedding(text, max_chars=_chars, max_lines=_lines,
                                                         max_tokens=_tokens)
            except Exception:
                logger.exception("task-recall similarity: embedding failed - base left unscaled")
                embedding_cache[text] = []
    qv, cv = embedding_cache.get(q) or [], embedding_cache.get(c) or []
    if not qv or not cv:
        return None
    return max(0.0, min(1.0, float(_cosine_similarity(qv, cv))))


def _local_patch_embedding_score(
    *,
    fix_instances: List[Dict],
    local_patch_contexts: List[str],
    local_embedding_cache: Dict[str, List[float]],
    feature_embedding_cache: Dict[str, List[float]],
) -> float:
    if not fix_instances or not local_patch_contexts:
        return 0.0

    before_fix_instances = [fix for fix in fix_instances if str(fix.get("risk_side") or "").strip().lower() == "before"]
    if not before_fix_instances:
        return 0.0

    for text in local_patch_contexts:
        if text not in local_embedding_cache:
            try:
                local_embedding_cache[text] = create_embedding(text)
            except Exception:
                logger.exception("Failed local patch embedding generation for recommendation rerank")
                local_embedding_cache[text] = []

    best = 0.0
    for fix in before_fix_instances:
        feature_s3_key = str(fix.get("feature_s3_key") or "").strip()
        if not feature_s3_key:
            continue
        if feature_s3_key not in feature_embedding_cache:
            try:
                feature_payload = download_prediction_feature_json(feature_s3_key)
                embedding = feature_payload.get("patch_embedding")
                feature_embedding_cache[feature_s3_key] = embedding if isinstance(embedding, list) else []
            except Exception:
                logger.exception("Failed loading historical patch embedding for s3_key=%s", feature_s3_key)
                feature_embedding_cache[feature_s3_key] = []

        hist_embedding = feature_embedding_cache.get(feature_s3_key) or []
        if not hist_embedding:
            continue
        for text in local_patch_contexts:
            score = _cosine_similarity(local_embedding_cache.get(text) or [], hist_embedding)
            if score > best:
                best = score
    return best * 12.0


def _build_after_fix_frequency_map(recommendations: List[Dict], fix_instance_cache: Dict[str, List[Dict]]) -> Dict[str, int]:
    freq: Dict[str, int] = {}
    for rec in recommendations:
        request_id = str(rec.get("request_id") or "").strip()
        if not request_id:
            continue
        for fix in fix_instance_cache.get(request_id, []):
            if str(fix.get("risk_side") or "").strip().lower() != "after":
                continue
            fp = str(fix.get("change_fingerprint") or "").strip()
            if not fp:
                continue
            freq[fp] = freq.get(fp, 0) + 1
    return freq


def _after_fix_pattern_score(
    fix_instances: List[Dict],
    after_fix_frequency: Dict[str, int],
    successful_after_fix_frequency: Dict[str, float] | None = None,
) -> float:
    best = 0
    best_success = 0.0
    for fix in fix_instances:
        if str(fix.get("risk_side") or "").strip().lower() != "after":
            continue
        fp = str(fix.get("change_fingerprint") or "").strip()
        if not fp:
            continue
        best = max(best, int(after_fix_frequency.get(fp) or 0))
        if successful_after_fix_frequency:
            best_success = max(best_success, float(successful_after_fix_frequency.get(fp) or 0.0))
    freq_score = 0.0 if best <= 1 else min(8.0, float(best - 1) * 2.0)
    success_score = min(6.0, best_success * 2.0) if best_success > 0 else 0.0
    return freq_score + success_score


def _artifact_display_name(s3_key: str) -> str:
    """Human name for a stored artifact: basename of the s3 key with the content-hash suffix
    and .zip wrapper stripped (log/debug.log-e65ded8d3e36.zip -> debug.log)."""
    name = os.path.basename(str(s3_key or "").replace("\\", "/")).strip()
    if name.lower().endswith(".zip"):
        name = name[:-4]
    return re.sub(r"-[0-9a-f]{8,}$", "", name, flags=re.IGNORECASE) or name


_PROJECT_FIX_TOKENS_CACHE: Dict[str, tuple] = {}
_ARTIFACT_OWNERSHIP_COMMON_TOKENS = {
    "error", "errors", "fail", "failed", "failure", "file", "files",
    "input", "output", "log", "logs", "line", "lines", "message",
}


def _project_fix_tokens(project_name: str, must_include: str = "") -> Dict[str, set]:
    """{request_id: distinctive tokens of that solution's change lines} for one project.

    Cached 5 min - the ingest gate runs per uploaded artifact and must not re-scan the whole
    project every time. Fail-safe: any error returns {} so the gate simply does nothing.
    """
    proj = str(project_name or "").strip().lower()
    if not proj:
        return {}
    now = time.time()
    hit = _PROJECT_FIX_TOKENS_CACHE.get(proj)
    rid_needed = str(must_include or "").strip()
    if hit and (now - hit[0]) < 300:
        # A warm cache predating the fix that is uploading RIGHT NOW would disable the gate for
        # exactly the back-to-back case it exists for: the payload is saved before its artifacts
        # arrive, so it exists in the store but not in this snapshot. Rebuild once for such an
        # id; an id that stays absent after a rebuild (solution yields no tokens) is remembered
        # so it cannot force a scan on every artifact of the same upload.
        if not rid_needed or rid_needed in hit[1] or rid_needed in hit[2]:
            return hit[1]
    out: Dict[str, set] = {}
    try:
        from src.utils.project_details import list_final_build_payloads_by_project
        for row in list_final_build_payloads_by_project(proj) or []:
            rid = str(row.get("request_id") or "").strip()
            payload = row.get("payload_json") if isinstance(row.get("payload_json"), dict) else {}
            if not rid or not payload:
                continue
            changes = [
                change
                for item in _normalize_solution_payload(payload.get("solution"))
                for change in (item.get("changes") or [])
                if str(change or "").strip()
            ]
            toks = _distinctive_token_set("\n".join(changes)) - _ARTIFACT_OWNERSHIP_COMMON_TOKENS
            if toks:
                out[rid] = toks
    except Exception:
        logger.exception("project fix-token scan failed (ingest gate disabled for this upload)")
        return {}
    _attempted = (hit[2] if hit else set()) | ({rid_needed} if rid_needed else set())
    _PROJECT_FIX_TOKENS_CACHE[proj] = (now, out, _attempted)
    return out


def _artifact_claimed_by_another_solution(project_name: str, request_id: str,
                                          file_bytes: bytes, file_name: str = "") -> str:
    """INGEST GATE. Returns the request_id of the solution this log is REALLY about,
    or "" to keep it as evidence for the record uploading it.

    The gate never asks "is this the right file for this fix" - that question cannot be answered
    for most logs and answering it wrongly would discard real evidence. It asks the far safer
    opposite: "can I PROVE this file is about something else?" Proof means another stored fix in
    this project names what this log's failure names, and this fix does not. Everything else -
    a generic build.log naming nothing, an unparsable solution, a project with no other
    solutions, any error at all - returns "" and the artifact is kept.

    Why this exists: two ctc_aurix fixes were storing python debug.logs, so a python failure was
    answered with a ctc fix. The extension fix (2.3.5) stops new ones being created, but only for
    users who update; this runs server-side and therefore protects every client version.
    """
    try:
        text = (file_bytes or b"").decode("utf-8", errors="replace")
        if not text.strip():
            return ""
        lines = _failure_signal_lines(text)
        if not lines:
            return ""          # names no failure at all - boilerplate, never flagged
        art_tokens = _distinctive_token_set(chr(10).join(lines)) - _ARTIFACT_OWNERSHIP_COMMON_TOKENS
        if not art_tokens:
            return ""          # names nothing specific - keep
        fix_tokens = _project_fix_tokens(project_name, str(request_id or "").strip())
        mine = fix_tokens.get(str(request_id or "").strip())
        if mine is None:
            return ""          # this fix's own text is unknown - cannot prove anything
        if len(art_tokens & mine) >= 2:
            return ""          # the log names what this fix changes - it IS about this fix
        for other_rid, other_tokens in fix_tokens.items():
            if (other_rid != str(request_id or "").strip()
                    and len(art_tokens & other_tokens) >= 2):
                logger.info("[ingest-gate] '%s' uploaded for %s is about %s (shared: %s) - stored, "
                            "but not evidence for %s",
                            file_name or "artifact", str(request_id)[:12], str(other_rid)[:12],
                            ",".join(sorted(art_tokens & other_tokens)[:4]), str(request_id)[:12])
                return other_rid
        return ""              # nobody claims it - keep, absence of proof is not proof
    except Exception:
        logger.exception("artifact ingest gate failed (artifact kept as evidence)")
        return ""


# What THIS request asked for, if anything. The 30-Sep review put the choice of scope in the
# developer's hands rather than an administrator's, and the scope is read in four places spread
# across the pipeline - a contextvar carries the choice without threading a parameter through
# functions that have no other interest in it. It is set once at the entry point and always reset,
# so one request can never inherit another's scope.
#
# This is an ambient VALUE for the duration of a request, not a control-flow switch: it records
# what the developer chose and nothing reads it to decide which branch to take.
_requested_scope_var: contextvars.ContextVar = contextvars.ContextVar(
    "aiasb_requested_scope", default=None)


def _reco_scope_members(project_name: str):
    """(members, mode) for THIS request's retrieval scope.

    The scope the developer asked for wins; the stored recommendationScope is only the starting
    point when the request named none. Any failure answers project scope - a scope resolver that
    fails open would widen the search, which is the opposite of safe.

    "project"  the one-project filter, byte-identical to a caller that is not widening
    "customer" one pass over the project's customer (or its defined group of more than one)
    "global"   no project filter at all
    """
    from src.services.project_groups import (
        resolve_scope_projects, normalize_scope, SCOPE_PROJECT, SCOPE_GLOBAL)
    proj = str(project_name or "").strip().lower()
    if not proj:
        return [], SCOPE_PROJECT
    try:
        requested = _requested_scope_var.get()
        if requested:
            wanted = normalize_scope(requested, default=SCOPE_PROJECT)
        else:
            wanted = normalize_scope(
                (_rc_get_config_cached() or {}).get("recommendationScope"), default=SCOPE_PROJECT)
        if wanted == SCOPE_PROJECT:
            return [proj], SCOPE_PROJECT
        if wanted == SCOPE_GLOBAL:
            return [], SCOPE_GLOBAL
        return resolve_scope_projects(proj, requested_scope=wanted)
    except Exception:
        logger.exception("scope resolution failed - using project scope")
        return [proj], SCOPE_PROJECT


# The artifact probe is embedded WHOLE, the same way VECTOR_BLOCK_MODE embeds a whole failure
# block on the error path (EMBEDDING_ERROR_MAX_CHARS / EMBEDDING_ERROR_MAX_LINES). The default
# char budget matches the probe's own 8000-char cap, so the artifact is not cut at either step and
# a root cause at the END of a long log still reaches the vector. Nothing is selected or filtered -
# the log goes in as the developer's machine produced it.
_ARTIFACT_EMBED_CHARS = max(200, int(os.getenv("EMBEDDING_ARTIFACT_MAX_CHARS", "28000")))
_ARTIFACT_EMBED_LINES = max(5, int(os.getenv("EMBEDDING_ARTIFACT_MAX_LINES", "400")))


def _artifact_reference_evidence_eligible(project_name: str, request_id: str, ref: Dict) -> bool:
    if not isinstance(ref, dict) or ref.get("evidence_eligible") is not False:
        return True
    s3_key = str(ref.get("s3_key") or "").strip()
    if not s3_key:
        return False

    from src.utils import ttl_cache

    def _revalidate() -> bool:
        try:
            from src.utils.payload_archive import download_s3_zip_bytes
            zip_bytes, _ = download_s3_zip_bytes(s3_key)
            with ZipFile(BytesIO(zip_bytes), "r") as archive:
                names = archive.namelist()
                content = archive.read(names[0]) if names else b""
            claimant = _artifact_claimed_by_another_solution(
                project_name, request_id, content, str(ref.get("file_name") or ""))
            return not bool(claimant)
        except Exception:
            logger.exception("legacy artifact eligibility recheck failed | request_id=%s", request_id)
            return False

    return bool(ttl_cache.get_or_compute(
        ("artifact-evidence-eligibility-v2", str(project_name or "").lower(), request_id, s3_key),
        _revalidate,
        deep_copy=False,
        ttl_override=3600,
    ))


def _artifact_match_scores(project_name: str, query_error_text: str,
                           candidate_request_ids: list,
                           query_artifact_text: str = "",
                           solution_texts: dict | None = None,
                           artifact_items: list | None = None) -> dict:
    """Artifact-match source: two failures can carry IDENTICAL report
    error text while the real difference lives in the ARTIFACTS - task match and artifact match
    are the sources that connect to the exact solution; more sources = more exact. Compares the
    current failure against each candidate's STORED artifact summaries (already embedded in the
    artifact collection at upload time) via TWO probes: the error text, and - when the
    extension sent artifact excerpts - the CURRENT build's artifact content on its own, so
    artifact-vs-artifact evidence still discriminates when the error texts are identical (the
    error-dominated combined query could not). One indexed reference lookup per candidate maps
    the best neighbour back. Returns {request_id: {similarity, s3_key, file_name, via}};
    fail-open {} - never breaks a recommendation."""
    try:
        rids = [str(r or "").strip() for r in (candidate_request_ids or []) if str(r or "").strip()]
        probes = []
        if str(query_error_text or "").strip():
            probes.append(("error_text", str(query_error_text).strip()))
        # ONE PROBE PER LIVE ARTIFACT: two solutions can share an error text and hold
        # DIFFERENT artifacts - one a debug.log, another a build.log. Embedding all of the
        # user's artifacts as a single blob dilutes each of them, so a solution holding only the
        # one that matches scores lower than it should. Each live artifact is now its own probe
        # and every candidate is scored on its best PAIR - live artifact against stored
        # artifact - regardless of file name, because only content is compared. Falls back to
        # the combined text when the client sent no per-file excerpts (older extensions).
        _items = [i for i in (artifact_items or []) if isinstance(i, dict) and str(i.get("text") or "").strip()]
        if _items:
            for _i, _it in enumerate(_items[:5]):
                _nm = str(_it.get("name") or f"artifact{_i + 1}").strip()
                probes.append((f"artifact:{_nm}",
                               str(_it.get("text") or "").strip()[-_ARTIFACT_EMBED_CHARS:]))  # TAIL: logs end with the failure
        elif str(query_artifact_text or "").strip():
            probes.append(("artifact_content",
                           str(query_artifact_text).strip()[-_ARTIFACT_EMBED_CHARS:]))  # TAIL: logs end with the failure
        if not probes or not rids:
            return {}
        # HYBRID fusion: embeddings see MEANING, so two
        # version-mismatch failures differing by one literal token ("but got '6.2r1p456'" vs
        # "but got '6.2r1p5'") score near-identical by vector alone — yet they are different
        # failures with different exact fixes. A second, LEXICAL leg scores exact-token overlap
        # between the probe text and each neighbour's stored summary, with each token weighted
        # by RARITY across the returned neighbours (1/df): boilerplate shared by every summary
        # weighs ~nothing, the one discriminating token weighs everything. No hardcoded
        # patterns — rarity decides, same philosophy as the extension's excerpt scorer.
        # fused = (1-alpha)*vector + alpha*token; alpha=0 restores pure-vector behavior.
        try:
            fusion_alpha = min(1.0, max(0.0, float(os.getenv("ARTIFACT_TOKEN_FUSION_ALPHA", "0.4"))))
        except (TypeError, ValueError):
            fusion_alpha = 0.4
        proj = str(project_name or "").strip().lower()
        _scope_members, _scope_mode = _reco_scope_members(proj)
        if _scope_mode == "customer":
            logger.info("[artifact-match] scope=customer over %d project(s): %s",
                        len(_scope_members), ",".join(_scope_members[:8]))
        elif _scope_mode == "global":
            logger.info("[artifact-match] scope=global - no project filter")
        sim_by_key = {}
        via_by_key = {}
        parts_by_key = {}
        per_probe: dict = {}
        parts_by_probe: dict = {}
        documents_by_probe: dict = {}
        about_by_key: dict = {}
        # Which probe decided a key's "about" tokens. When live artifacts were sent, the artifact
        # probe decides: the error-text probe runs first and ranks token rarity on a different
        # query, which once made a fix's OWN log read as "about another fix" and excluded it
        # (offline 10-case test, 300-line log).
        about_from_artifact: set = set()
        # Hoisted above the probe loop: it was reset per probe, so the
        # boilerplate-skip log reported only the LAST probe's count.
        _skipped_no_signal = 0
        for via, text in probes:
            # EMBED THE FAILURE, NOT THE PREAMBLE. _prepare_text_for_embedding keeps the
            # FIRST 40 lines capped at 1500 chars - head truncation. Measured on a 122-line log:
            # only 19 lines survive, and a root cause sitting at the end is simply absent from the
            # vector. Logs put the failure LAST, so the vector leg was matching on the progress
            # chatter every log shares while the failure line never reached it.
            #
            # The two sides were also asymmetric, which is what made it invisible. The stored side
            # is a summary that LEADS with its error signals, so its failure survives; the token
            # leg already reduces to signal lines via _evidence_tokens, so its failure survives;
            # only the query's vector leg was fed raw head-truncated text. Reducing it here makes
            # all three agree on what is being compared.
            #
            # EMBED THE WHOLE ARTIFACT, THE SAME WAY THE ERROR PATH EMBEDS A WHOLE FAILURE BLOCK.
            #
            # create_embedding defaults to the FIRST 40 lines capped at 1500 chars - head
            # truncation - and logs put the failure LAST. Measured on a 122-line debug.log, only 19
            # lines survived and the root-cause token never reached the vector at all: the leg was
            # matching on the progress chatter every log shares. It stayed invisible because the
            # other legs were fine (the stored side is a summary LEADING with its error signals,
            # the token leg scans the whole probe), so a small artifact matched perfectly and only
            # a real one degraded.
            #
            # The answer is the one the error path already uses - VECTOR_BLOCK_MODE raises its
            # budget to EMBEDDING_ERROR_MAX_CHARS/LINES so a failure block is embedded whole. No
            # selecting, no filtering, no reordering, no marker list deciding what counts: the
            # artifact goes in as it is, exactly as the developer's machine produced it. The
            # default covers the probe's own 8000-char cap, so nothing is cut at either step.
            # (Since 09-Oct the embedder also keeps the END of a text that is over budget, so
            # the head-truncation described above cannot recur even for an oversized artifact.)
            query_kwargs = {
                "query_embeddings": [create_embedding(
                    text,
                    max_chars=_ARTIFACT_EMBED_CHARS,
                    max_lines=_ARTIFACT_EMBED_LINES,
                )],
                "n_results": 200,
                "include": ["metadatas", "distances", "documents"],
            }
            if proj:
                # SCOPE: the evidence layer widens WITH retrieval, never behind it.
                # Widening retrieval alone pulls in sibling
                # candidates whose logs cannot be scored - they arrive unscoreable and compete on
                # error text and helpers only, which is the familiarity-wins failure mode the
                # whole ranking model exists to prevent. Project scope emits the identical dict.
                from src.services.project_groups import scope_where as _scope_where
                query_kwargs["where"] = _scope_where(proj, members=_scope_members)
            res = get_artifact_chroma_collection().query(**query_kwargs)
            metas = (res.get("metadatas") or [[]])[0] or []
            dists = (res.get("distances") or [[]])[0] or []
            docs = (res.get("documents") or [[]])[0] or []
            # Lexical leg: rarity weights from THIS probe's neighbour set.
            # FAILURE LINES vs FAILURE LINES (measured on a recorded request):
            # the token leg compared the whole stored SUMMARY against the query, so the one word
            # that identifies the failure ('ctc_aurix' vs 'python') was a single token among
            # fifty of shared vocabulary - and the leg scored the WRONG candidate higher
            # (0.272 vs 0.209) while the vector leg had it right (0.553 vs 0.545), dragging the
            # fused score the wrong way. Both sides are now reduced to their failure-signal
            # lines before tokenising, so the comparison is what failed here against what failed
            # there. Rarity weighting then does its job: shared scaffolding is common and cheap,
            # the failing tool and its values are rare and decisive. Falls back to the full text
            # when a side has no signal line, so nothing is lost.
            def _evidence_tokens(_t: str) -> set:
                _sig = chr(10).join(_failure_signal_lines(str(_t or "")))
                return _distinctive_token_set(_sig or str(_t or ""))

            query_tokens = _evidence_tokens(text) if fusion_alpha > 0 else set()
            doc_tokens: list = []
            df: dict = {}
            if query_tokens:
                for i in range(len(metas)):
                    toks = _evidence_tokens(str(docs[i] or "")) if i < len(docs) else set()
                    doc_tokens.append(toks)
                    for t in (toks & query_tokens):
                        df[t] = df.get(t, 0) + 1
            weight_total = sum(1.0 / df[t] for t in query_tokens if t in df)
            for i, meta in enumerate(metas):
                if not isinstance(meta, dict) or i >= len(dists):
                    continue
                # EVIDENCE MUST NAME A FAILURE (found by comparing stored logs against
                # the live one): a stored artifact whose text carries NO failure-signal line is
                # boilerplate - the preamble every debug.log shares (script started, reading
                # config, validation started). It therefore matches EVERY live log moderately
                # well and can outrank real, specific evidence: a truncated capture with no
                # failure line scored 0.609 against a python failure while the python fix's own
                # log scored 0.549, so the wrong fix owned the evidence. The query side has
                # already required a failure signal; stored artifacts now must clear the
                # same bar to count as evidence. Content-agnostic: any failure phrasing
                # qualifies, and nothing is deleted - such artifacts stay downloadable and keep
                # their summaries, they simply cannot decide a ranking.
                if not _failure_signal_lines(str(docs[i] or "") if i < len(docs) else ""):
                    _skipped_no_signal += 1
                    continue
                try:
                    dist = float(dists[i])
                except (TypeError, ValueError):
                    continue
                vec_sim = max(0.0, min(1.0, 1.0 - dist / 2.0))
                token_sim = 0.0
                if query_tokens and weight_total > 0 and i < len(doc_tokens):
                    hit = sum(1.0 / df[t] for t in (doc_tokens[i] & query_tokens) if t in df)
                    token_sim = max(0.0, min(1.0, hit / weight_total))
                sim = ((1.0 - fusion_alpha) * vec_sim + fusion_alpha * token_sim
                       if query_tokens and weight_total > 0 else vec_sim)
                s3 = str(meta.get("s3_key") or "").strip()
                sha = str(meta.get("content_sha12") or "").strip().lower()
                _dtoks = doc_tokens[i] if i < len(doc_tokens) else set()
                for key in ([s3] if s3 else []) + (["sha:" + sha] if sha else []):
                    if sim > per_probe.setdefault(via, {}).get(key, 0.0):
                        per_probe[via][key] = sim
                        parts_by_probe.setdefault(via, {})[key] = (round(vec_sim, 3), round(token_sim, 3))
                        documents_by_probe.setdefault(via, {})[key] = str(docs[i] or "") if i < len(docs) else ""
                    # What this artifact is ABOUT: its failure tokens, rarest first (rarity is
                    # the same 1/df used for scoring, so the top entries are the failing tool
                    # and its values rather than shared scaffolding).
                    if _dtoks and (key not in about_by_key
                                   or (via.startswith("artifact") and key not in about_from_artifact)):
                        about_by_key[key] = sorted(_dtoks, key=lambda t: (df.get(t, 999), t))[:6]
                        if via.startswith("artifact"):
                            about_from_artifact.add(key)
        # THE LIVE ARTIFACT DECIDES (the main error can be identical while the artifact
        # carries a completely different error). Taking the MAX across both probes let
        # a contradicted candidate win through the ERROR-TEXT probe, which in a GBE report is
        # saturated with tool-install chatter present in every report regardless of what failed -
        # live case: a python failure scored ctc 51.45 vs python 50.43, a 1-point gap where the
        # evidence should be decisive. When the request carries artifact evidence, that probe
        # alone scores the candidates: a stored artifact that does not match this failure earns
        # no lift, which is the honest answer. The error text keeps its own jobs - retrieval,
        # signature identity and match points - and remains the only probe when no artifacts
        # were sent (older clients, artifact-less cycles), so nothing regresses there.
        if _skipped_no_signal:
            logger.info("[artifact-match] %d stored artifact(s) ignored as evidence - no failure "
                        "signal in their content (boilerplate matches every log)", _skipped_no_signal)
        # Best PAIR wins: across every live artifact probe, the highest score each stored
        # artifact reached. The error-text probe is used only when no artifacts were sent.
        _art_probes = [k for k in per_probe if k.startswith("artifact")]
        sim_by_key, parts_by_key, via_by_key, documents_by_key = {}, {}, {}, {}
        if _art_probes:
            for _pk in _art_probes:
                for _key, _val in (per_probe.get(_pk) or {}).items():
                    if _val > sim_by_key.get(_key, 0.0):
                        sim_by_key[_key] = _val
                        parts_by_key[_key] = (parts_by_probe.get(_pk) or {}).get(_key, (0.0, 0.0))
                        via_by_key[_key] = _pk
                        documents_by_key[_key] = (documents_by_probe.get(_pk) or {}).get(_key, "")
        else:
            sim_by_key = dict(per_probe.get("error_text") or {})
            parts_by_key = dict(parts_by_probe.get("error_text") or {})
            documents_by_key = dict(documents_by_probe.get("error_text") or {})
            via_by_key = {k: "error_text" for k in sim_by_key}
        logger.info("[artifact-match] scored on %d live artifact probe(s): %s",
                    len(_art_probes), ",".join(_art_probes) or "none (error text only)")
        if not sim_by_key:
            logger.info("[artifact-match] no artifact neighbours returned for project=%s", proj)
            return {}
        # A SOLUTION'S EVIDENCE MUST BE ABOUT THAT SOLUTION (production shape: many
        # users, many solutions for one error text, each solution carrying SEVERAL artifacts).
        # A record accumulates artifacts from every cycle that re-confirmed it, so a fix can end
        # up holding a log of a DIFFERENT failure - and "my best-matching artifact" then lets it
        # win on evidence that was never about it (live: a ctc fix and the python fix scored an
        # identical 0.786 on a python failure). An artifact counts for a candidate only when what
        # it is ABOUT - its rarest failure tokens - appears in that fix's OWN change lines. Fully
        # content-agnostic: the fix names what it corrects, the log names what failed, and they
        # must agree. Fail-open: unknown solution text accepts everything, exactly as before.
        _sol_tokens = {}
        for _rid, _txt in (solution_texts or {}).items():
            _tk = _distinctive_token_set(str(_txt or ""))
            if _tk:
                _sol_tokens[str(_rid)] = _tk

        def _is_about(rid_key: str, art_key: str) -> bool:
            _want = _sol_tokens.get(str(rid_key))
            _about = about_by_key.get(art_key) or []
            if not _want or not _about:
                return True
            return any(t in _want for t in _about[:3])

        def _belongs_to_another_fix(rid_key: str, art_key: str) -> bool:
            """This log is demonstrably about a DIFFERENT candidate's fix (seen in the
            data: two ctc_aurix fixes hold python debug.logs, and one of them holds NOTHING else -
            so 'prefer the log that is about me' still handed it the python log and let it win
            python failures). Preference is not enough when a record has no evidence of its own:
            an artifact whose failure subject matches ANOTHER candidate's fix is excluded here
            outright. A log that matches nobody's fix - a generic build.log naming no component -
            is still allowed, so evidence is never discarded on a guess."""
            _about = about_by_key.get(art_key) or []
            if not _about:
                return False
            _mine = _sol_tokens.get(str(rid_key))
            if not _mine:
                # Fail-open, matching _is_about: a candidate whose own change lines could not be
                # parsed knows nothing about what it corrects, so it cannot be shown that this
                # log belongs elsewhere. Excluding on that silence would strip real evidence.
                return False
            if any(t in _mine for t in _about[:3]):
                return False
            for _other, _tokens in _sol_tokens.items():
                if str(_other) != str(rid_key) and any(t in _tokens for t in _about[:3]):
                    return True
            return False

        out = {}
        _preferred = 0
        _foreign = 0
        for rid in rids:
            _state = None          # why this candidate has no evidence, for the trace
            _had_refs = False
            _saw_scored_key = False
            _excluded_here = 0
            # Two buckets: artifacts that are ABOUT this fix, and the rest. The best "about"
            # artifact wins whenever one exists; otherwise the best of the rest is used, so a
            # generic build.log that names nothing the fix mentions is still evidence rather
            # than being thrown away. Preference, not rejection.
            best_about = (0.0, "", "", "")
            best_any = (0.0, "", "", "")
            for artifact_type in ("runtime", "binary"):
                for ref in get_artifact_references(rid, artifact_type) or []:
                    s3 = str((ref or {}).get("s3_key") or "").strip()
                    if not s3:
                        continue
                    _had_refs = True
                    # Ingest gate said this log is about a different fix. The file stays stored
                    # and downloadable; it simply never counts as evidence for this record.
                    if not _artifact_reference_evidence_eligible(proj, rid, ref):
                        _foreign += 1
                        _excluded_here += 1
                        continue
                    here = sim_by_key.get(s3, 0.0)
                    here_via = via_by_key.get(s3, "")
                    here_key = s3
                    sha = _sha12_from_s3_key(s3)
                    if sha and sim_by_key.get("sha:" + sha, 0.0) > here:
                        here = sim_by_key["sha:" + sha]
                        here_via = via_by_key.get("sha:" + sha, "")
                        here_key = "sha:" + sha

                    if here > 0:
                        _saw_scored_key = True
                    if here > 0 and _belongs_to_another_fix(rid, here_key):
                        _foreign += 1
                        _excluded_here += 1
                        continue
                    if here > best_any[0]:
                        best_any = (here, s3, here_via, here_key)
                    if here > best_about[0] and _is_about(rid, here_key):
                        best_about = (here, s3, here_via, here_key)
            if best_about[0] > 0:
                if best_about[1] != best_any[1]:
                    _preferred += 1
                best, best_s3, best_via, best_key = best_about
            else:
                best, best_s3, best_via, best_key = best_any
            if best > 0:
                # Not just HOW similar - WHICH stored artifact matched,
                # kept linkable so the file itself can be opened and confirmed, via WHICH
                # probe, and the fusion breakdown (meaning vs exact tokens) behind the score.
                vec_sim, token_sim = parts_by_key.get(best_key, (0.0, 0.0))
                out[rid] = {"similarity": best, "s3_key": best_s3,
                            "file_name": _artifact_display_name(best_s3),
                            "via": best_via,
                            "evidence_text": documents_by_key.get(best_key, ""),
                            "vector_similarity": vec_sim,
                            "token_overlap": token_sim,
                            "evidence_state": "scored"}
            else:
                # WHY there is no evidence: four distinct states were
                # indistinguishable on the trace - and downstream they all read as
                # 'contradicted'. State only, similarity untouched: consumers treat these
                # entries exactly like a missing one (similarity 0), so ranking is unchanged.
                if not _had_refs:
                    _state = "no_artifacts"
                elif _excluded_here and not _saw_scored_key:
                    _state = "excluded"
                elif _saw_scored_key:
                    _state = "compared_no_match"
                else:
                    _state = "not_retrieved"
                out[rid] = {"evidence_state": _state}
        if _preferred:
            logger.info("[artifact-match] %d candidate(s) scored on the artifact that is ABOUT "
                        "their own fix instead of a better-matching log of another failure", _preferred)
        if _foreign:
            logger.info("[artifact-match] %d artifact(s) ignored - they are about ANOTHER "
                        "candidate's fix, not the one holding them", _foreign)
        _scored_n = sum(1 for v in out.values() if float((v or {}).get("similarity") or 0.0) > 0)
        logger.info("[artifact-match] %d of %d candidate(s) have artifact evidence | states: %s",
                    _scored_n, len(rids),
                    {st: sum(1 for v in out.values() if (v or {}).get("evidence_state") == st)
                     for st in ("scored", "no_artifacts", "excluded", "compared_no_match", "not_retrieved")})
        return out
    except Exception:
        logger.exception("artifact match scoring failed (recommendation unaffected)")
        return {}


def _rc_value(key: str, lo: float = 0.0, hi: float = 30.0) -> float:
    """One admin-tunable scoring number, clamped to its range. The fallback when the config is
    unreadable is the SAME default get_config() would have filled in (SCORING_DEFAULTS) - never
    a second literal written here that could disagree with it."""
    from src.services.recommendation_config import SCORING_DEFAULTS
    default = float(SCORING_DEFAULTS[key])
    try:
        raw = (_rc_get_config_cached() or {}).get(key)
        value = default if raw is None else float(raw)
    except Exception:
        value = default
    return max(lo, min(hi, value))


def _match_type_score(match_type: str) -> float:
    """The match BASE: what a candidate earns at similarity 1.0.
      exact     exactMatchBase    (the same normalised error - the signature hashes equal)
      semantic  semanticMatchBase (scaled by the similarity afterwards)
      task      semanticMatchBase (task-ledger recall enters on the same base as semantic: match
                points mean "how well does this candidate match THIS failure", and both are
                scaled by the evidence before they are awarded)
    Both bases are admin-tunable; raising the semantic base strengthens the error and the artifact
    together, because it is multiplied by the evidence-combined similarity."""
    normalized = str(match_type or "").strip().lower()
    if normalized == "exact":
        return _rc_value("exactMatchBase")
    if normalized in ("semantic", "task"):
        return _rc_value("semanticMatchBase")
    return 0.0


def _recommendation_source_label(match_type: str, context_score: float) -> str:
    normalized = str(match_type or "").strip().lower()
    if normalized == "exact" and context_score > 0:
        return "hybrid"
    if normalized == "exact":
        return "signature"
    if context_score > 0:
        return "contextual"
    return "top_k"


def _recommendation_min_final() -> float:
    """Env-only FINAL-SCORE floor (RECOMMENDATION_MIN_FINAL_SCORE), 0 = off. Kept for
    deployments that calibrated a score floor by env. The dashboard's minSimilarityPercent no
    longer maps onto the final score: it gates the CONFIDENCE, which is a similarity and so means
    the same thing whatever the score ceiling is (see _recommendation_confidence)."""
    try:
        return max(0.0, float(getattr(config, "RECOMMENDATION_MIN_FINAL_SCORE", 0.0) or 0.0))
    except (TypeError, ValueError):
        return 0.0


def _recommendation_min_confidence() -> float:
    """minSimilarityPercent / 100: the confidence a shown candidate must reach. 0 = gate off."""
    try:
        pct = float((_rc_get_config_cached() or {}).get("minSimilarityPercent") or 0)
    except Exception:
        pct = 0.0
    return max(0.0, min(1.0, pct / 100.0))


def _recommendation_confidence(rec: Dict) -> tuple:
    """(confidence, source): how close this candidate's error is to the one in hand, 0..1.

    The FINAL SCORE orders candidates; it is not a confidence. Under the additive model support
    can never exceed evidence, so the old final/30 capped a semantic candidate at 0.80 whatever
    its cosine and at 0.40 x cosine without support: a 70% threshold hid every semantic match
    below cosine 0.875, and the number on the screen was a share of an arbitrary ceiling rather
    than a similarity. Confidence is now the similarity that EARNED the match points:

      exact_signature        1.0   the same normalised error IS the same error
      evidence_similarity    the error+artifact blend, when the artifact lift blended it
      error_similarity       the cosine of the error text
      unavailable            None  nothing was compared (embedding unavailable) - no confidence
                                   can honestly be stated, so a threshold refuses it
    """
    if str(rec.get("match_type") or "").strip().lower() == "exact":
        return 1.0, "exact_signature"
    for key in ("evidence_similarity", "similarity"):
        value = rec.get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return max(0.0, min(1.0, float(value))), key if key != "similarity" else "error_similarity"
    return None, (str(rec.get("similarity_source") or "") or "unavailable")


def _evaluate_recommendation_strength(recommendation: Dict | None) -> Dict[str, object]:
    rec = recommendation if isinstance(recommendation, dict) else {}
    match_type = str(rec.get("match_type") or "").strip().lower()
    context_score = float(rec.get("context_score") or 0.0)
    match_score = float(rec.get("match_score") or 0.0)
    final_score = float(rec.get("final_score") or 0.0)
    has_solution = bool(rec.get("solution"))
    source = _recommendation_source_label(match_type, context_score)

    if not has_solution:
        return {
            "match_status": "none",
            "confidence_score": 0.0,
            "confidence_source": "no_solution",
            "source": source,
        }

    confidence, confidence_source = _recommendation_confidence(rec)
    result = {
        "confidence_score": round(confidence, 3) if confidence is not None else 0.0,
        "confidence_source": confidence_source,
        "source": source,
        "match_score": round(match_score, 3),
        "context_score": round(context_score, 3),
        "final_score": round(final_score, 3),
    }

    # The error-text cosine FLOOR (minSemanticSimilarity, 0..1): a semantic candidate whose
    # error text is below it is never shown, whatever the artifact blend or the context say.
    try:
        _sim_floor = float((_rc_get_config_cached() or {}).get("minSemanticSimilarity") or 0)
    except Exception:
        _sim_floor = 0.0
    if _sim_floor > 0.0 and match_type == "semantic":
        _sim = rec.get("similarity")
        if isinstance(_sim, (int, float)) and float(_sim) < _sim_floor:
            return {"match_status": "below_threshold", **result}

    # The CONFIDENCE threshold (minSimilarityPercent): a candidate must be at least this similar.
    # A candidate with no confidence at all cannot clear a threshold that is switched on.
    min_conf = _recommendation_min_confidence()
    if min_conf > 0.0 and (confidence is None or confidence < min_conf):
        return {"match_status": "below_threshold", **result}

    # The env-only final-score floor, for deployments that calibrated one.
    min_final = _recommendation_min_final()
    if min_final > 0.0 and final_score < min_final:
        return {"match_status": "below_threshold", **result}

    return {"match_status": "strong", **result}


def _track_recommendation_hits(
    recommendations: List[Dict],
    project_name: str = "",
    query_signature_hashes: List[str] | None = None,
) -> None:
    for rec in recommendations:
        req_id = rec.get("request_id")
        if not req_id:
            continue
        hit_date = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        try:
            append_final_build_recommendation_hit(
                request_id=req_id,
                recommended=True,
                hit_date=hit_date,
            )
        except Exception:  # telemetry failure must degrade, never 500 the request
            logger.exception("Failed to append recommendation hit for request_id=%s", req_id)
        try:
            save_recommendation_outcome(
                request_id=str(req_id).strip(),
                project_name=str(project_name or rec.get("project_name") or "").strip().lower(),
                recommended=True,
                source=str(rec.get("source") or rec.get("match_type") or "").strip(),
                match_status=str(rec.get("match_status") or "").strip(),
                confidence_score=float(rec.get("confidence_score") or 0.0),
                query_signature_hashes=query_signature_hashes or [],
                hit_date=hit_date,
                adapter_enabled=_adapter_state_for(str(project_name or rec.get("project_name") or "")),
            )
        except Exception:  # telemetry failure must degrade, never 500 the request
            logger.exception("Failed to save recommendation outcome for request_id=%s", req_id)


def _extract_recommendation_request_ids(recommendations: List[Dict]) -> List[str]:
    out: List[str] = []
    seen = set()
    for rec in recommendations or []:
        req_id = str(rec.get("request_id") or "").strip()
        if not req_id or req_id in seen:
            continue
        seen.add(req_id)
        out.append(req_id)
    return out


def _gate_recommendation_results(
    recommendations: List[Dict],
    top_k: int,
    track_hits: bool = False,
    project_name: str = "",
    query_signature_hashes: List[str] | None = None,
    trace_context: Dict | None = None,
) -> Dict[str, object]:
    ordered = list(recommendations or [])
    top = ordered[0] if ordered else None
    visible: List[Dict] = []
    weak_visible: List[Dict] = []

    # The bar applies to EVERY shown slot - a place in the top 3 is earned by
    # crossing the score, never by merely being whatever ranked third. Scan the
    # WHOLE ordered list for the first top_k candidates that cross, instead of only the first
    # top_k positions - the display order is tier-based (same-task/file/tokens), not score
    # order, so a below-threshold candidate at #2 must free its slot for a strong one at #4,
    # and a below-threshold candidate at #1 must not blank the response when strong
    # candidates exist further down.
    for rec in ordered:
        if len(visible) >= max(1, int(top_k)):
            break
        rec_eval = _evaluate_recommendation_strength(rec)
        if rec_eval.get("match_status") != "strong":
            continue
        rec["match_status"] = rec_eval["match_status"]
        rec["confidence_score"] = rec_eval["confidence_score"]
        rec["source"] = rec_eval["source"]
        visible.append(rec)

    for rec in ordered:
        if len(visible) + len(weak_visible) >= max(1, int(top_k)):
            break
        if rec in visible:
            continue
        rec_eval = _evaluate_recommendation_strength(rec)
        if rec_eval.get("match_status") != "below_threshold":
            continue
        rec["match_status"] = rec_eval["match_status"]
        rec["confidence_score"] = rec_eval["confidence_score"]
        rec["source"] = rec_eval["source"]
        rec["is_weak_match"] = True
        weak_visible.append(rec)

    # Reported status reflects what is actually shown; falls back to the ranked top's
    # evaluation when nothing crossed (below_threshold / none for the caller's verdict).
    top_eval = _evaluate_recommendation_strength(visible[0] if visible else top)

    if visible and track_hits:
        _track_recommendation_hits(
            visible,
            project_name=project_name,
            query_signature_hashes=query_signature_hashes,
        )

    logger.info(
        "Recommendation gate top_status=%s top_confidence=%.3f source=%s returned=%s total_candidates=%s",
        str(top_eval.get("match_status") or "none"),
        float(top_eval.get("confidence_score") or 0.0),
        str(top_eval.get("source") or "unknown"),
        len(visible) + len(weak_visible),
        len(ordered),
    )
    if top:
        logger.info(
            "Recommendation gate top_candidate request_id=%s match_type=%s match_score=%.3f context_score=%.3f final_score=%.3f",
            top.get("request_id"),
            top.get("match_type"),
            float(top.get("match_score") or 0.0),
            float(top.get("context_score") or 0.0),
            float(top.get("final_score") or 0.0),
        )

    # Store the DECISION CHAIN for every recommendation request -
    # what the user's error was, every candidate with its real scores, the threshold and
    # adapter state in force, and what was finally shown. Fail-open: tracing never breaks
    # the recommendation itself.
    try:
        from src.utils import recommendation_trace
        ctx = trace_context or {}
        shown_for_trace = visible + weak_visible
        # ONE order for both screens: the trace lists the candidates exactly as the webview
        # receives them - what is shown, in its order, then the rest in the ranking order.
        # Before, the trace listed the raw ranking while the webview skipped below-threshold
        # and solution-less rows, so the two screens disagreed on who was #2.
        _shown_ids = {str(r.get("request_id") or "") for r in shown_for_trace}
        _trace_order = shown_for_trace + [r for r in ordered
                                          if str(r.get("request_id") or "") not in _shown_ids]
        candidates_snapshot = []
        for rec in _trace_order[:10]:
            snap = dict(rec)
            snap["match_status"] = str(_evaluate_recommendation_strength(rec).get("match_status") or "")
            if str(rec.get("request_id") or "") in {
                    str(shown.get("request_id") or "") for shown in shown_for_trace}:
                snap["shown"] = True
            candidates_snapshot.append(snap)
        # The trace records the knobs that were ACTUALLY live for this
        # request, plus which config row served them. Settles service-vs-scripts divergence in
        # one read: prediction_config vs prediction_config_dev is an ops fact the trace now
        # states instead of anyone assuming.
        _eff_cfg = {}
        try:
            _c_eff = _rc_get_config_cached() or {}
            for _k_eff in ("artifactMatchWeight", "similarityWeightedScoring",
                           "evidenceSimilarityWeight", "semanticMatchBase", "exactMatchBase",
                           "minSimilarityPercent", "baseTaskWeight",
                           "baseFileWeight", "baseTokenWeight", "historyWeightCeiling",
                           "taskMatchWeight", "afterPatternWeight", "llmPromoteEnabled",
                           "minSemanticSimilarity"):
                if _k_eff in _c_eff:
                    _eff_cfg[_k_eff] = str(_c_eff.get(_k_eff))
            from src.services import recommendation_config as _rc_mod
            _eff_cfg["config_table"] = str(getattr(_rc_mod, "CONFIG_TABLE", ""))
            # WHICH SCOPE decided this request. Without it a cross-project pick is
            # unexplainable: the reader cannot tell whether a fix from another project was
            # eligible by design or leaked in.
            _sm, _smode = _reco_scope_members(project_name)
            _eff_cfg["scope_mode"] = _smode
            # Which scope was used AND where it came from. Without the source, a trace showing
            # customer scope cannot be told apart from an administrator having changed the
            # default - and the developer's own choice is the thing worth being able to see.
            _eff_cfg["scope_source"] = "request" if _requested_scope_var.get() else "config"
            if _smode == "customer":
                _eff_cfg["scope_projects"] = ",".join(_sm)
        except Exception:
            pass
        _trace_id = recommendation_trace.save_trace(
            scoring_config=_eff_cfg,
            project_name=project_name,
            endpoint=str(ctx.get("endpoint") or ""),
            query_error=str(ctx.get("query_error") or ""),
            query_signature_hashes=query_signature_hashes or [],
            task_path=str(ctx.get("task_path") or ""),
            changed_files=ctx.get("changed_files") or [],
            query_context=ctx.get("query_context"),
            query_artifacts=ctx.get("query_artifacts"),
            candidates=candidates_snapshot,
            shown_request_ids=[str(r.get("request_id") or "") for r in shown_for_trace],
            threshold_min_final=_recommendation_min_final(),
            threshold_min_confidence=_recommendation_min_confidence(),
            adapter_error_on=_adapter_state_for(project_name),
            adapter_artifact_on=None,
            adapter_state=_adapter_runtime_state(project_name),
            gate_status=str(top_eval.get("match_status") or "none"),
        )
    except Exception:
        logger.exception("recommendation trace failed (recommendation unaffected)")
        _trace_id = ""

    return {
        # The request's own identity - shown in the webview so it can
        # be copied and pasted straight into the dashboard trace page.
        "trace_id": _trace_id if isinstance(_trace_id, str) else "",
        "recommendations": visible,
        "weak_recommendations": weak_visible,
        "match_status": str(top_eval.get("match_status") or "none"),
        "confidence_score": float(top_eval.get("confidence_score") or 0.0),
        "source": str(top_eval.get("source") or "unknown"),
    }


def _rc_get_config_cached():
    from src.services import recommendation_config as _rc
    return _rc.get_config()


def _blend_evidence(error_similarity, error_usable: bool, artifact_similarity,
                    contrast_share, contrast_on: bool, weight) -> tuple:
    """The similarity that earns match points once artifact evidence exists: (combined, rule).

    Artifact similarity is NOT on the error cosine's scale. Two logs of one toolchain share their
    boilerplate, so an unrelated stored log still scores about 0.5-0.6 - and blending that
    absolute figure into the cosine meant a candidate that was merely COMPARED read lower than a
    rival that could not be compared at all (no stored artifacts): presence was punished and
    absence rewarded. The lift already measures evidence RELATIVE to the rivals (the contrast
    share); the blend now uses the same measure, so one artifact figure means one thing:

      contrast on    the best-matching log raises the confidence toward 1, a contradicted log
                     lowers it toward 0, the rest sit in between - all relative to the pool
      contrast off   the candidates' logs agree too closely (or only one was compared) to say
                     anything FOR or AGAINST any of them: the error cosine stands, and the
                     artifact still earns the lift
      no error text  the artifact is the only evidence (task recall): its share when contrast
                     is on, its absolute similarity otherwise

    A candidate with no artifacts is never blended - absence is not contradiction - and a
    candidate WITH artifacts is now never worse off than it for having been compared on
    evidence that agrees with everyone else's.
    """
    w = max(0.0, min(1.0, float(weight or 0.0)))
    art = float(contrast_share) if (contrast_on and contrast_share is not None) else float(artifact_similarity or 0.0)
    art = max(0.0, min(1.0, art))
    if not error_usable:
        return art, ("artifact alone, share among rivals" if contrast_on else "artifact alone, absolute")
    err = max(0.0, min(1.0, float(error_similarity)))
    if not contrast_on:
        return err, "error cosine (the artifacts agree too closely to decide for or against)"
    return (1.0 - w) * err + w * art, f"{round(1 - w, 2)} x error + {round(w, 2)} x artifact share"


def _hydrate_recommendations(
    vector_matches: List[Dict],
    project_name: str,
    top_k: int,
    recommendation_context: Dict[str, List[str]] | None = None,
    local_patch_contexts: List[str] | None = None,
    current_query_signatures: List[str] | None = None,
    query_task_path: str = "",
    query_error_text: str = "",
    query_artifact_text: str = "",
    query_artifact_items: List[Dict] | None = None,
) -> List[Dict]:
    # The LAST segment of the task path identifies the task itself (:TARGETS:master:task4
    # -> task4) - candidates are compared on that.
    query_task_name = str(query_task_path or "").strip().strip(":").split(":")[-1].strip().lower()
    recommendations: List[Dict] = []
    seen_request_ids: set = set()
    final_payload_cache: Dict[str, Dict | None] = {}
    fix_instance_cache: Dict[str, List[Dict]] = {}
    outcome_summary_cache: Dict[str, Dict | None] = {}
    outcomes_cache: Dict[str, List[Dict]] = {}
    feedback_cache: Dict[str, List[Dict]] = {}
    local_embedding_cache: Dict[str, List[float]] = {}
    feature_embedding_cache: Dict[str, List[float]] = {}
    # Signatures of the error being recommended for - used to scope the live feedback link
    # ("this solution was marked Helpful for THIS error") to the current error.
    query_sig_set = {str(s).strip().lower() for s in (current_query_signatures or []) if str(s).strip()}

    # Each request is scored on its BEST match, not on whichever query found it first.
    vector_matches = _best_match_per_request(vector_matches)
    for match in vector_matches:
        meta = match.get("meta")
        if not isinstance(meta, dict):
            continue

        vector_id = match.get("vector_id") or meta.get("vector_id")
        request_id = meta.get("request_id") or meta.get("batch_id")
        # One historical request = one recommendation. include_context stores the same
        # request under multiple signature variants (bare/path/task-prefixed, multiple
        # file names), so a single fix can match several vectors. Keep the first
        # (best-ranked) match and skip the rest to avoid duplicate solutions.
        if request_id and request_id in seen_request_ids:
            continue
        s3_key = meta.get("s3_key")
        file_name = meta.get("file_name")
        match_type = str(match.get("match_type") or "semantic")
        recommendation_similarity = match.get("similarity")
        recommendation_distance = match.get("distance")
        if match_type == "task" and recommendation_similarity is None:
            # Task recall arrives without a similarity: give it the same cosine every semantic
            # row carries - measured on the same prepared text, with the same budget - so its
            # base is scaled like theirs below. The similarity column then shows a cosine and
            # nothing else: a computed one carries NO source label, exactly like a vector-search
            # row, because it IS the same measure. Only the abnormal cases are named
            # (similarity_source), on the row and in the trace:
            #   no_error_text          the stored row carries NO error text: nothing to compare,
            #                          similarity left blank (not a fake 0), no match points. A
            #                          bare row of the same task took the full 12 and rank 2
            #                          with an empty solution column (live, 08-Oct). Its context
            #                          (same task, same file, history) still counts, and
            #                          artifact evidence, if any, still earns match points below.
            #   no_query_text          the request carried no error text - nothing to compare
            #                          against, and no semantic row competes either; base kept
            #   embedding_unavailable  the embedding call failed - base kept, as before, so a
            #                          transient outage does not blank the ledger
            _doc = str(match.get("document") or "").strip()
            if not _doc:
                match["similarity_source"] = "no_error_text"
            elif not str(query_error_text or "").strip():
                match["similarity_source"] = "no_query_text"
            else:
                _tr_sim = _task_recall_similarity(query_error_text, _doc, local_embedding_cache)
                if _tr_sim is None:
                    match["similarity_source"] = "embedding_unavailable"
                else:
                    recommendation_similarity = _tr_sim
                    recommendation_distance = round(2.0 * (1.0 - _tr_sim), 6)
                    match["similarity"] = recommendation_similarity
                    match["distance"] = recommendation_distance

        final_payload = None
        if request_id:
            if request_id not in final_payload_cache:
                final_payload_cache[request_id] = get_final_build_payload(request_id)
            final_payload = final_payload_cache.get(request_id)

            if not final_payload:
                # LIVE-UPDATE fix (a DELETED entry kept showing while the newer
                # correct entry stayed hidden). The vector is SHARED across same-signature
                # requests and its metadata names the FIRST uploader - when that request is
                # gone, resolve the signature's references to the newest LIVE sibling and
                # recommend THAT instead.
                _sig = str(meta.get("error_signature_hash") or "").strip().lower()
                if _sig:
                    try:
                        _seen_envs: set = set()
                        for _env in (str(meta.get("env") or "").strip().lower(),
                                     str(config.APP_ENV or "test").strip().lower() or "test",
                                     "test"):
                            if not _env or _env in _seen_envs:
                                continue
                            _seen_envs.add(_env)
                            for _ref in get_error_solution_references_summary_first(
                                    project_name, _env, _sig) or []:
                                _sib = str(_ref.get("request_id") or "").strip()
                                if not _sib or _sib == request_id or _sib in seen_request_ids:
                                    continue
                                if _sib not in final_payload_cache:
                                    final_payload_cache[_sib] = get_final_build_payload(_sib)
                                if final_payload_cache.get(_sib):
                                    request_id = _sib
                                    final_payload = final_payload_cache[_sib]
                                    logger.info(
                                        "hydrate: resolved shared vector %s to live sibling request_id=%s",
                                        vector_id, _sib)
                                    break
                            if final_payload:
                                break
                    except Exception:
                        logger.exception("sibling resolution failed for vector_id=%s", vector_id)

            if not final_payload and _is_request_tombstoned(request_id):
                # Deliberately deleted and no live sibling: NEVER rebuild it from vector
                # metadata - skip the candidate entirely.
                logger.info("hydrate: skipping tombstoned request_id=%s (deleted entry)", request_id)
                continue

            if not final_payload:
                meta_solution = meta.get("solution")
                parsed_solution = []
                if isinstance(meta_solution, list):
                    parsed_solution = meta_solution
                elif isinstance(meta_solution, str):
                    try:
                        parsed = json.loads(meta_solution)
                        if isinstance(parsed, list):
                            parsed_solution = parsed
                    except Exception:
                        parsed_solution = []

                if parsed_solution:
                    # This is a WRITE on the read path - a throttling
                    # error here must skip this one candidate's backfill, not kill the
                    # whole recommendation request.
                    try:
                        ensure_final_build_payload(
                            request_id=request_id,
                            payload={
                                "solution": parsed_solution,
                                "projectName": meta.get("project_name") or project_name,
                                "taskName": None,
                            },
                        )
                        final_payload = get_final_build_payload(request_id)
                    except Exception:
                        logger.exception("final-build backfill failed for request_id=%s (candidate degraded)", request_id)
                        final_payload = None
                    final_payload_cache[request_id] = final_payload

        recommendation = {
            "rank": 0,
            "vector_id": vector_id,
            "request_id": request_id,
            "file_name": file_name,
            "s3_key": s3_key,
            "solutionUrl": f"/archive-payload/{request_id}" if request_id else None,
            "solution": _normalize_solution_payload((final_payload or {}).get("solution", [])),
            "task_name": (final_payload or {}).get("task_name"),
            "project_name": (final_payload or {}).get("project_name") or project_name,
            "created_date": (final_payload or {}).get("created_date") or meta.get("created_date"),
            "uploaded_at": (final_payload or {}).get("first_seen_date")
                           or (final_payload or {}).get("created_date")
                           or meta.get("created_date"),
            "match_type": match_type,
            "compare_diff_link": _build_compare_diff_link(request_id, vector_id),
            "solution_lines": _extract_solution_lines((final_payload or {}).get("solution", [])),
            "context_score": 0.0,
            "document": str(match.get("document") or "").strip(),
            # Developer-authored description of how this fix solved the failure (entered in the
            # upload preview, stored on the final-build payload). Surfaced in the recommendation.
            # resolutionDescription (camelCase) is what the save path writes - see
            # project_details.update_final_build_resolution_description, which sets
            # payload["resolutionDescription"]. Reading only the snake_case spelling meant a
            # description a developer had entered never reached the recommendation panel: it was
            # written, stored and then looked up under a name nothing uses. Reported from
            # production (07-Oct) as a recommendation whose description did not display.
            # The export path already read both; this one did not. Snake_case stays as the
            # fallback for rows written before that save path existed.
            "resolution_description": str((final_payload or {}).get("resolutionDescription")
                                          or (final_payload or {}).get("resolution_description")
                                          or "").strip(),
        }
        if request_id:
            if request_id not in fix_instance_cache:
                fix_instance_cache[request_id] = get_fix_instances(request_id)
            base_match_details: Dict = {}
            # The developer's current file travels with the context, so the content check has
            # something to compare against. Everything else in the context is unchanged.
            _ctx = dict(recommendation_context or
                        {"task_paths": [], "file_names": [], "tokens": []})
            _ctx["file_contents"] = local_patch_contexts or []
            base_context_score = _fix_context_score(
                fix_instances=fix_instance_cache.get(request_id, []),
                final_payload=final_payload,
                context=_ctx,
                details=base_match_details,
            )
            recommendation["base_matches"] = base_match_details
            patch_context_score = _local_patch_embedding_score(
                fix_instances=fix_instance_cache.get(request_id, []),
                local_patch_contexts=local_patch_contexts or [],
                local_embedding_cache=local_embedding_cache,
                feature_embedding_cache=feature_embedding_cache,
            )
            success_context_score = _recommendation_success_score(
                request_id=request_id,
                summary_cache=outcome_summary_cache,
                outcomes_cache=outcomes_cache,
            )
            match_score = _match_type_score(match_type)
            recommendation["similarity"] = recommendation_similarity
            recommendation["distance"] = recommendation_distance
            recommendation["similarity_source"] = str(match.get("similarity_source") or "")
            recommendation["adapter_influence"] = match.get("adapter_influence")
            # ALWAYS weighted by the actual similarity. This was behind an admin flag that
            # shipped OFF, so a barely-related nearest neighbour scored exactly like a
            # near-identical error: every semantic candidate carried the full base and the Match
            # column read a flat 12.00 whatever the similarity beside it said. The similarity was
            # computed, displayed, and then ignored, which left the ranking to be decided by
            # circumstantial signals - and made a trace tooltip divide the match by the similarity
            # to recover a "base", printing 14.5 and 26 for a number that is only ever 18 or 12.
            # There is no sensible configuration in which the match ignores how well it matched.
            # Task recall is scaled the same way. It carries the same cosine now (computed at
            # the top of this loop by _task_recall_similarity - the ledger itself never set
            # one), so leaving it out of the scaling handed it the full base for having been
            # compared to nothing: two task-recall rows read a flat 12.00 above a 0.71 row at
            # 8.55 (live, 07-Oct). A recall row still without a similarity (embedding
            # unavailable) keeps the unscaled base, exactly as before.
            if match_type in ("semantic", "task") and isinstance(recommendation_similarity, (int, float)):
                match_score = match_score * max(0.0, min(1.0, float(recommendation_similarity)))
            elif str(match.get("similarity_source") or "") == "no_error_text":
                # Nothing was compared: no match points. The base must not survive on a blank.
                match_score = 0.0
            recommendation["context_score"] = base_context_score + patch_context_score + success_context_score
            # Full decomposition (how each number is calculated, and with what
            # data) - recorded on the candidate so the trace shows every component.
            recommendation["context_components"] = {
                "base": round(float(base_context_score), 2),
                "patch": round(float(patch_context_score), 2),
                "success": round(float(success_context_score), 2),
                "after_pattern": 0.0,
                "artifact": 0.0,
                "task_weight": 0.0,
            }
            # Task-match weight (the task name considered with a configurable weight):
            # a candidate whose stored fix belongs to the SAME task as the current failure gets
            # an admin-configurable additive lift. Default 0 = OFF - shipped ranking unchanged
            # until the admin sets the weight. Additive only: a different task never demotes.
            try:
                _task_weight = float((_rc_get_config_cached() or {}).get("taskMatchWeight") or 0)
            except Exception:
                _task_weight = 0.0
            if _task_weight > 0 and query_task_name:
                cand_task = str((final_payload or {}).get("task_name") or "").strip().lower()
                if cand_task and cand_task.strip(":").split(":")[-1] == query_task_name:
                    recommendation["context_score"] = float(recommendation["context_score"] or 0.0) + _task_weight
                    recommendation["task_match_weight_applied"] = _task_weight
                    recommendation["context_components"]["task_weight"] = round(float(_task_weight), 2)
            recommendation["match_score"] = match_score
            recommendation["final_score"] = match_score + float(recommendation["context_score"] or 0.0)
            logger.info(
                "Recommendation rerank candidate request_id=%s match_type=%s task=%s file=%s fix_instances=%s local_patch_contexts=%s match_score=%.3f base_score=%.3f patch_score=%.3f success_score=%.3f total_score=%.3f",
                request_id,
                match_type,
                (final_payload or {}).get("task_name") or "",
                file_name or "",
                len(fix_instance_cache.get(request_id, [])),
                len(local_patch_contexts or []),
                float(match_score),
                float(base_context_score),
                float(patch_context_score),
                float(success_context_score),
                float(recommendation["final_score"]),
            )
        if request_id:
            # Votes are stored under SK 'FEEDBACK#...' (separate from the 'RECOMMEND#' outcomes),
            # so they must be read with list_recommendation_feedback, not outcomes_cache.
            if request_id not in feedback_cache:
                feedback_cache[request_id] = list_recommendation_feedback(request_id)
            fb_outcomes = feedback_cache[request_id]
            thumbs_up = sum(1 for oc in fb_outcomes if oc.get("is_helpful") is True)
            thumbs_down = sum(1 for oc in fb_outcomes if oc.get("is_helpful") is False)
            if thumbs_up or thumbs_down:
                recommendation["thumbs_up"] = thumbs_up
                recommendation["thumbs_down"] = thumbs_down
            # Error-scoped, human-validated link (live, online - no scripts): did developers
            # who faced THIS error mark this solution Helpful? Used to surface it next time.
            if config.FEEDBACK_LINK_BOOST_ENABLED and query_sig_set:
                fb_helped = fb_not = 0
                for oc in fb_outcomes:
                    oc_sigs = {str(s).strip().lower() for s in (oc.get("query_signature_hashes") or []) if str(s).strip()}
                    if not (oc_sigs & query_sig_set):
                        continue
                    if oc.get("is_helpful") is True:
                        fb_helped += 1
                    elif oc.get("is_helpful") is False:
                        fb_not += 1
                if fb_helped or fb_not:
                    recommendation["fb_link_helped"] = fb_helped
                    recommendation["fb_link_not_helped"] = fb_not
                    recommendation["fb_link_net"] = fb_helped - fb_not
        recommendations.append(recommendation)
        if request_id:
            seen_request_ids.add(request_id)

    # Artifact-match lift (admin knob artifactMatchWeight, ON by default - see
    # SCORING_DEFAULTS): additive context points proportional to how similar the candidate's
    # stored artifacts are to the CURRENT failure - the disambiguator when report error texts
    # are identical. Whenever artifacts are present they are used: the live artifact excerpts
    # probe the stored artifacts directly, and the error text is the probe when the client sent
    # none. 0 switches the path off deliberately.
    _evidence_rel: Dict[str, float] = {}
    _artifact_weight = _rc_value("artifactMatchWeight", hi=60.0)
    if _artifact_weight > 0 and (str(query_error_text or "").strip()
                                 or str(query_artifact_text or "").strip()):
        # The artifact source is an ENRICHMENT: any failure inside it must cost the lift, never
        # the recommendation (one stored payload shape raised while ARGUMENTS were being
        # built - outside the matcher's own guard - and returned 500 for the whole request).
        try:
            _sol_texts = {}
            for r in recommendations:
                try:
                    _sol_texts[str(r.get("request_id") or "")] = (
                        json.dumps(r.get("solution") or [], default=str)
                        + " " + str(r.get("file_name") or ""))
                except Exception:
                    continue
            _art_scores = _artifact_match_scores(
                project_name, query_error_text,
                [str(r.get("request_id") or "") for r in recommendations],
                query_artifact_text=query_artifact_text,
                artifact_items=query_artifact_items,
                solution_texts=_sol_texts)
        except Exception:
            logger.exception("artifact-match source failed - recommendation continues without "
                             "the artifact lift")
            _art_scores = {}
        # CONTRAST normalization (live mis-rank, master/dev task4): two stored debug.logs
        # share every boilerplate line, so even the CONTRADICTING candidate (python-version log
        # vs the query's ctc_aurix log) kept a high absolute similarity and the weight lifted
        # both — the differential stayed too small to beat task-location points. When the
        # candidates' artifact evidence genuinely DISAGREES (spread >= 0.15), points follow the
        # contrast: best evidence takes the full weight, contradicted evidence takes none.
        # Near-identical evidence (spread < 0.15) keeps the absolute-similarity lift unchanged —
        # a noise-level difference must not decide anything.
        _scored_sims = [float((v or {}).get("similarity") or 0.0) for v in _art_scores.values()
                        if float((v or {}).get("similarity") or 0.0) > 0]
        _smin = min(_scored_sims) if _scored_sims else 0.0
        _smax = max(_scored_sims) if _scored_sims else 0.0
        _spread = (_smax - _smin) if _scored_sims else 0.0
        # The spread below which the candidates' evidence counts as "agreeing" - admin-tunable
        # (evidenceContrastMinSpread): two summaries of one toolchain share their format, so the
        # vector leg alone moves by hundredths; the token leg is what opens the spread.
        _contrast_on = len(_scored_sims) >= 2 and _spread >= _rc_value("evidenceContrastMinSpread", hi=1.0)
        # POOL COMPOSITION IS NOT EVIDENCE (prerequisite for widening the scope from
        # project to group and later to global). Contrast measures a candidate against the
        # SPREAD between the best and worst candidate in the pool, so adding one candidate from
        # a sibling project moves everybody else's points without a single piece of their own
        # evidence changing - measured on the live pair, adding a weaker sibling (0.40) lifted
        # the python fix 21.15 -> 30.00 and the ctc fix 17.85 -> 19.18. That is a rescale, and
        # rescales reorder near-ties. 'best' mode measures each candidate against the STRONGEST
        # evidence present instead: a weaker sibling changes nothing at all, while a sibling
        # with genuinely better evidence still demotes the others - which is the whole point of
        # sharing evidence across projects. Default 'spread' keeps today's proven behaviour
        # exactly; the flip is an admin decision, proven both directions first.
        try:
            _contrast_mode = str((_rc_get_config_cached() or {}).get("evidenceContrastMode")
                                 or "spread").strip().lower()
        except Exception:
            _contrast_mode = "spread"
        _any_evidence = bool(_scored_sims)
        for rec in recommendations:
            _info = _art_scores.get(str(rec.get("request_id") or "")) or {}
            _sim = float(_info.get("similarity") or 0.0)
            rec["evidence_state"] = str(_info.get("evidence_state") or "not_retrieved")
            if _sim <= 0:
                # A TASK-recalled candidate was surfaced by task identity and never matched
                # against the failure at all, yet it kept the FULL flat match base while every
                # semantic candidate had its base scaled down by similarity - a 2.4-point head
                # start for the candidate with less proof (in a recorded request a ctc
                # fix led a PYTHON failure 49.80 to 49.68 on exactly that gap, having lost the
                # context comparison 43.80 to 46.07). When the request carries artifact
                # evidence and this candidate matched none of it, its match points go with it.
                # Its task identity still stands - that is what the base context points are.
                # ABSENCE IS NOT CONTRADICTION: solutions with no artifacts rely purely on
                # error text and other supporting facts.
                # Zeroing fired for every no-evidence state alike, so a solution stored
                # before artifact capture existed - 11 of 21 on the TD5 project - lost its whole
                # match base the moment any rival carried evidence. Now only a candidate whose
                # OWN stored evidence was compared against this failure and supported a different
                # one (compared_no_match / excluded) forfeits the base; no_artifacts and
                # not_retrieved keep it and compete on error text plus supporting facts.
                _ev_state = str(rec.get("evidence_state") or "")
                if (_any_evidence
                        and str(rec.get("match_type") or "").strip().lower() == "task"
                        and _ev_state in ("compared_no_match", "excluded")):
                    rec["match_score"] = 0.0
                    rec["evidence_similarity"] = 0.0
                    rec["final_score"] = float(rec.get("context_score") or 0.0)
                continue
            if not _contrast_on:
                _rel = _sim
            elif _contrast_mode == "best":
                _rel = (_sim / _smax) if _smax > 0 else 0.0
            else:
                _rel = (_sim - _smin) / _spread
            # NO LIVE LOG -> WEAK EVIDENCE. Without artifact excerpts the matcher probes the
            # stored logs with the ERROR TEXT. That is the same error text again, compared against
            # logs: a fix whose log happens to mention the same file can then earn the full lift
            # and beat an EXACT error match (offline 10-case test: "malformed JSON in config.json"
            # lost to the duplicate-target fix, whose log names config.json too). Such evidence
            # earns errorTextArtifactWeight (default 0.25) of the lift, does not replace the error
            # similarity in the match score, and does not gate history.
            _via_error_text = str(_info.get("via") or "") == "error_text"
            if _contrast_on and not _via_error_text:
                _evidence_rel[str(rec.get("request_id") or "")] = _rel
            _lift = _artifact_weight * _rel
            if _via_error_text:
                _lift *= _rc_value("errorTextArtifactWeight", 0.0, 1.0)
            rec["context_score"] = float(rec.get("context_score") or 0.0) + _lift
            rec["artifact_match_similarity"] = round(_sim, 3)
            # Where the log evidence came from: the live log, or only the error text probing the
            # stored logs. The tie check must not treat the latter as real evidence.
            rec["artifact_evidence_via"] = "error_text" if _via_error_text else "live_artifact"
            # EVIDENCE-COMBINED SIMILARITY: match points were weighted by the ERROR-TEXT
            # similarity alone, so between two candidates whose report text is word-for-word
            # identical the difference was noise - and it handed the wrong candidate more points
            # (live: ctc 0.75 vs python 0.71 on a python failure). The artifact says what the
            # error text cannot, so the similarity that earns match points now blends both:
            # (1-w) x error-text + w x artifact evidence, w = evidenceSimilarityWeight (default
            # 0.5, admin-tunable). Only candidates WITH artifact evidence are re-weighted, and
            # only when similarity weighting is on - error-text-only requests are unchanged.
            try:
                _cfg_es = _rc_get_config_cached() or {}
                _ev_w = max(0.0, min(1.0, float(_cfg_es.get("evidenceSimilarityWeight", 0.5))))
            except Exception:
                _ev_w = 0.5
            _err_sim = rec.get("similarity")
            _mt = str(rec.get("match_type") or "").strip().lower()
            if _ev_w > 0 and _mt in ("semantic", "task") and not _via_error_text:
                # A usable error similarity: a number, and not the 0.0 that marks a task-recall
                # row with no stored error text (that 0.0 says "nothing to compare", not "compared
                # and found unrelated" - blending it would halve the artifact's evidence). Task
                # recall carries a real cosine now (task_recall_cosine), so it blends exactly
                # like a semantic row; a recall row still without one (embedding unavailable,
                # no request text) keeps the artifact as its only evidence, as before.
                _err_usable = (isinstance(_err_sim, (int, float))
                               and str(rec.get("similarity_source") or "") != "no_error_text")
                _combined, _blend_rule = _blend_evidence(
                    _err_sim, _err_usable, _sim, _rel if _contrast_on else None, _contrast_on, _ev_w)
                _base_match = _match_type_score(_mt)
                rec["match_score"] = round(_base_match * max(0.0, min(1.0, _combined)), 3)
                rec["evidence_similarity"] = round(_combined, 3)
                # WHERE THE NUMBER CAME FROM, in the trace, because one figure explains nothing.
                # Asked for directly (07-Oct): "here we have no idea what is this 0.69 and where
                # it came from", and separately "how do you normalize the score for artifact" -
                # a candidate carrying twenty artifacts must not beat one carrying two simply by
                # having more. Both are answered by storing the arithmetic rather than the result.
                try:
                    _fuse_a = min(1.0, max(0.0, float(os.getenv("ARTIFACT_TOKEN_FUSION_ALPHA", "0.4"))))
                except Exception:
                    _fuse_a = 0.4
                _n_art = len([i for i in (query_artifact_items or [])
                              if isinstance(i, dict) and str(i.get("text") or "").strip()])
                _vec = float(_info.get("vector_similarity") or 0.0)
                _tok = float(_info.get("token_overlap") or 0.0)
                rec["similarity_components"] = {
                    # THE REAL BASE, stored - never recovered by dividing the match by the
                    # similarity. A trace tooltip did exactly that and showed bases of 14.5, 15.9,
                    # 18.3 and 26 for a value that is only ever 18 or 12: with similarity weighting
                    # off every match was a flat 12, so 12 / 0.83 read as 14.5 and 12 / 0.46 as 26.
                    # Reported as "where this 14.5 came from" (07-Oct) - arithmetic run backwards.
                    "match_base": round(_base_match, 1),
                    "match_base_rule": (f"{round(_match_type_score('exact'), 1)} = exact signature "
                                        "(exactMatchBase); otherwise semanticMatchBase "
                                        f"(currently {round(_match_type_score('semantic'), 1)})"),
                    "match_formula": (f"{round(_base_match, 1)} x {round(_combined, 3)}"
                                      f" = {round(_base_match * max(0.0, min(1.0, _combined)), 3)}"),
                    "error_similarity": round(float(_err_sim), 3)
                                        if isinstance(_err_sim, (int, float)) else "",
                    "artifact_similarity": round(_sim, 3),
                    "artifact_weight": round(_ev_w, 2),
                    "combined": round(_combined, 3),
                    "blend": (f"{_blend_rule}: error "
                              f"{round(float(_err_sim), 3) if _err_usable else '-'}, artifact "
                              f"{round(_sim, 3)}"
                              f"{', share ' + str(round(_rel, 3)) if _contrast_on else ''}"
                              f" = {round(_combined, 3)}"),
                    # Inside the artifact figure: meaning plus rare-token overlap.
                    "artifact_vector": round(_vec, 3),
                    "artifact_token_overlap": round(_tok, 3),
                    "artifact_fusion": (f"{round(1 - _fuse_a, 2)} x vector {round(_vec, 3)}"
                                        f" + {_fuse_a} x rare-token {round(_tok, 3)}"
                                        f" = {round(_sim, 3)}"),
                    # The answer to "does more files mean a higher score": no.
                    "artifacts_compared": _n_art,
                    "artifact_rule": (f"best single pair of {_n_art} live artifact(s) against this "
                                      f"candidate's stored artifacts - the highest pair wins, "
                                      f"scores are never summed, so more files cannot raise it"),
                    "artifact_file": str(_info.get("file_name") or ""),
                    "contrast_share": round(_rel, 3) if _contrast_on else "",
                    "contrast_rule": ("relative to the other candidates in this request"
                                      if _contrast_on else
                                      "absolute - the candidates' artifacts agreed too closely "
                                      "(spread < 0.15) for a relative score to mean anything"),
                }
            rec["final_score"] = float(rec.get("match_score") or 0.0) + float(rec.get("context_score") or 0.0)
            _s3 = str(_info.get("s3_key") or "").strip()
            if _s3:
                # The trace links the matched artifact via the same
                # download-artifact URL the Download Files popup uses.
                from src.utils.project_details import _artifact_download_url
                rec["artifact_matched"] = {
                    "file_name": str(_info.get("file_name") or ""),
                    "s3_key": _s3,
                    "url": _artifact_download_url(_s3),
                    "evidence_text": str(_info.get("evidence_text") or "")[:4000],
                    # Which probe found it: the user's own artifact content (the strong,
                    # artifact-vs-artifact signal) or the error text.
                    "via": str(_info.get("via") or ""),
                    # Hybrid fusion breakdown behind the similarity: meaning (vector) and
                    # exact rare-token overlap — shown on the trace tooltip so a decided
                    # match is explainable ("the '6.2r1p456' token picked this one").
                    "vector_similarity": str(_info.get("vector_similarity") or 0),
                    "token_overlap": str(_info.get("token_overlap") or 0),
                    # Contrast share of the admin weight this candidate's evidence earned
                    # (1 = clearly best among rivals, 0 = contradicted; empty = contrast off).
                    "contrast": str(round(_rel, 3)) if _contrast_on else "",
                }
            if isinstance(rec.get("context_components"), dict):
                rec["context_components"]["artifact"] = round(_lift, 2)

    after_fix_frequency = _build_after_fix_frequency_map(recommendations, fix_instance_cache)
    successful_after_fix_frequency = _build_successful_after_fix_frequency_map(
        recommendations,
        fix_instance_cache,
        outcomes_cache,
    )
    for rec in recommendations:
        request_id = str(rec.get("request_id") or "").strip()
        if not request_id:
            continue
        after_pattern_score = _after_fix_pattern_score(
            fix_instances=fix_instance_cache.get(request_id, []),
            after_fix_frequency=after_fix_frequency,
            successful_after_fix_frequency=successful_after_fix_frequency,
        )
        # REPEATED-FIX PATTERN IS OFF BY DEFAULT: the W adapter already captures the
        # repeated fix, and an admin can re-enable this term. It measured which change
        # developers typically make next, which is precisely what the feedback adapter learns
        # from votes and outcomes - counting it here paid the same signal twice, and it paid it
        # to whichever fix was most POPULAR rather than the one this failure points at.
        # afterPatternWeight (default 0) re-enables it without a release.
        try:
            _ap_w = max(0.0, min(1.0, float((_rc_get_config_cached() or {}).get("afterPatternWeight", 0.0))))
        except Exception:
            _ap_w = 0.0
        after_pattern_score = float(after_pattern_score) * _ap_w
        if after_pattern_score > 0:
            rec["context_score"] = float(rec.get("context_score") or 0.0) + after_pattern_score
            rec["final_score"] = float(rec.get("match_score") or 0.0) + float(rec.get("context_score") or 0.0)
            if isinstance(rec.get("context_components"), dict):
                rec["context_components"]["after_pattern"] = round(float(after_pattern_score), 2)
            logger.info(
                "Recommendation fix-pattern bonus request_id=%s after_pattern_score=%.3f total_score=%.3f",
                request_id,
                float(after_pattern_score),
                float(rec.get("final_score") or 0.0),
            )

    # HISTORY IS A HELPER, NOT A DECIDER: success (up to ~12) plus after-fix pattern
    # (up to 8) could total 20 points - and together with identity (19) the helper signals
    # reached 39 against artifact evidence's 30, so a candidate with a long record could
    # outweigh the log of the failure actually being fixed. In a recorded request, on a
    # CTC failure the python fix carried 18 points of history against the ctc fix's 13.7 and
    # led the ranking. The two history components are now capped as ONE budget
    # (historyWeightCeiling, default 8, admin-tunable) so a proven fix keeps a real advantage
    # over an unproven one without ever rivalling the evidence. Recorded as history_cap.
    _hist_cap = _rc_value("historyWeightCeiling")
    for rec in recommendations:
        comp = rec.get("context_components") if isinstance(rec.get("context_components"), dict) else None
        if not comp:
            continue
        _hist = float(comp.get("success") or 0.0) + float(comp.get("after_pattern") or 0.0)
        # The gate below must discount the CAPPED history, not the raw figure, so the capped
        # total is carried on the record. It used to be achieved by scaling comp["success"] and
        # comp["after_pattern"] down in place - which double-counted the trim on the trace: the
        # parts were already reduced AND history_cap subtracted the same excess again, so the
        # components summed 6 points below the stored context score. The parts stay raw, the cap
        # line carries the whole subtraction once, and the components add up.
        rec["capped_history"] = round(min(_hist, _hist_cap), 4)
        if _hist > _hist_cap:
            _excess = _hist - _hist_cap
            rec["context_score"] = float(rec.get("context_score") or 0.0) - _excess
            rec["final_score"] = float(rec.get("match_score") or 0.0) + float(rec.get("context_score") or 0.0)
            comp["history_cap"] = -round(_excess, 2)
            logger.info("Recommendation history cap request_id=%s history=%.2f -> %.2f total_score=%.3f",
                        str(rec.get("request_id") or "")[:12], _hist, _hist_cap,
                        float(rec.get("final_score") or 0.0))

    # EVIDENCE GATES HISTORY (the live 2.17-point residue): success and after-fix
    # points are earned fixing a candidate's OWN root cause. When the candidates' artifact
    # evidence genuinely disagrees (contrast active), a candidate whose stored evidence is
    # CONTRADICTED by the live failure is carrying history of a DIFFERENT problem — its
    # history counts in proportion to how well its evidence matches THIS failure (gate =
    # contrast share). Candidates with NO artifact evidence are untouched (absence is not
    # contradiction). Fully dynamic — flips with every failure's evidence; lives entirely
    # behind the artifactMatchWeight gate, so weight 0 switches it off with the lift.
    if _evidence_rel:
        for rec in recommendations:
            _rel = _evidence_rel.get(str(rec.get("request_id") or ""))
            if _rel is None or _rel >= 1.0:
                continue
            comp = rec.get("context_components") if isinstance(rec.get("context_components"), dict) else {}
            # The CAPPED history, carried from the cap above. Reading the raw parts here would
            # discount history the cap has already removed.
            _history = rec.get("capped_history")
            if _history is None:
                _history = float(comp.get("success") or 0.0) + float(comp.get("after_pattern") or 0.0)
            _discount = (1.0 - max(0.0, min(1.0, _rel))) * float(_history)
            if _discount <= 0:
                continue
            rec["context_score"] = float(rec.get("context_score") or 0.0) - _discount
            rec["final_score"] = float(rec.get("match_score") or 0.0) + float(rec.get("context_score") or 0.0)
            comp["evidence_gate"] = -round(_discount, 2)
            # Votes transfer across root causes when error texts are IDENTICAL (live case:
            # 2 Helpful votes earned fixing the ctc mismatch pinned the ctc solution for a
            # PYTHON failure — same signature, different problem). The error-scoped vote link
            # is gated by evidence exactly like history: a contradicted candidate's votes
            # under this signature were earned on a different root cause.
            # TASK CONFIRMS EVIDENCE, IT DOES NOT REPLACE IT: everything matching is
            # strongest; error + artifact matching is still strong; the task is uncontrollable -
            # the same error, solution and artifacts legitimately live under different gradle
            # tasks. A flat task bonus cannot express that, because it pays the same whether
            # the candidate's evidence agrees or contradicts. Task identity now scales with the
            # candidate's own evidence share: full evidence keeps the full task confirmation
            # (everything matches = strongest), matching evidence under a different task keeps
            # its full evidence and simply earns no task bonus (still strong), and a
            # same-task candidate whose log points elsewhere earns almost none of it.
            _task_pts = float((((rec.get("base_matches") or {}).get("points")) or {}).get("task") or 0.0)
            if _task_pts > 0 and _rel < 1.0:
                _task_trim = _task_pts * (1.0 - max(0.0, min(1.0, _rel)))
                rec["context_score"] = float(rec.get("context_score") or 0.0) - _task_trim
                rec["final_score"] = float(rec.get("match_score") or 0.0) + float(rec.get("context_score") or 0.0)
                if isinstance(comp, dict):
                    comp["task_identity_scaled"] = -round(_task_trim, 2)
            _fb = int(rec.get("fb_link_net") or 0)
            if _fb > 0:
                rec["fb_link_net"] = int(round(_fb * max(0.0, min(1.0, _rel))))
            logger.info(
                "Recommendation evidence gate request_id=%s contrast=%.3f history=%.2f discount=%.2f "
                "fb_link %d->%s total_score=%.3f",
                str(rec.get("request_id") or "")[:12], _rel, _history, _discount,
                _fb, rec.get("fb_link_net") if _fb > 0 else "-",
                float(rec.get("final_score") or 0.0),
            )

    # SAME-ERROR FEEDBACK EARNS POINTS. The trace used to say "no change" on every row, which
    # is useless - the raw helpful/not-helpful counts are already shown elsewhere, and the
    # question is what they DID. Until then votes were only a tie-break and a downvote sink, so
    # "no change" was the honest answer almost always. This gives feedback a real, visible share.
    #
    # ONLY same-error votes count (fb_link_net): developers who hit THIS error and said this fix
    # worked. Global thumbs stay a tie-break and earn nothing - popularity is not evidence, and
    # a recorded request showed why: the LLM picked a candidate on a DIFFERENT task with no artifact
    # evidence and a score of 13.8 against 55.2, reasoning it had "the strongest helpful feedback
    # signals". That is exactly the mistake this must not encode.
    #
    # Saturating, so one enthusiastic developer cannot buy a rank: points = W*net/(net+2), i.e.
    # 1 vote earns a third of the weight, 2 earn half, and the ceiling is W however many arrive.
    # Positive only - a net-downvoted candidate is handled by the downvote sink, and subtracting
    # here too would penalise it twice.
    #
    # Added BEFORE the helper cap below, deliberately: feedback is a HELPER, so the existing
    # invariant already stops it outranking evidence. The rule holds unchanged - the error
    # and the artifact decide, feedback confirms.
    # Feedback was later rejected as an additive score term - it belongs in the
    # adapter, which moves the similarity itself. The weight now defaults to 0, so this block is
    # inert unless an admin deliberately turns it on; see recommendation_config for why the
    # mechanism was kept rather than deleted.
    try:
        _fb_weight = float((_rc_get_config_cached() or {}).get("feedbackSupportWeight") or 0.0)
    except (TypeError, ValueError):
        _fb_weight = 0.0
    if _fb_weight > 0:
        for rec in recommendations:
            _net = int(rec.get("fb_link_net") or 0)
            if _net <= 0:
                continue
            _pts = _fb_weight * (_net / (_net + 2.0))
            rec["context_score"] = float(rec.get("context_score") or 0.0) + _pts
            rec["final_score"] = float(rec.get("match_score") or 0.0) + float(rec.get("context_score") or 0.0)
            _c = rec.get("context_components")
            if isinstance(_c, dict):
                _c["feedback_support"] = round(_pts, 2)
            logger.info(
                "Recommendation feedback support request_id=%s same_error_net=%d points=%.2f "
                "total_score=%.3f",
                str(rec.get("request_id") or "")[:12], _net, _pts,
                float(rec.get("final_score") or 0.0),
            )

    # HELPERS NEVER OUTWEIGH EVIDENCE (context must not be weighted greater
    # than error message + artifact). Rather than re-tuning single numbers forever, this is an
    # invariant checked per candidate: identity (task/file/wording/usage) + history + admin task
    # lift may total at most what the EVIDENCE earned - the error match (which itself scales
    # with the error+artifact similarity) plus the artifact points plus patch similarity. Above
    # that the helpers are scaled down proportionally, so a candidate can never win on
    # familiarity while the failure's own log points elsewhere. Recorded as helper_cap.
    # helperEvidenceRatio (default 0.5) sets the share: at 1.0 a 0.85 match with full support
    # (2 x 10.2) beat a 0.95 match without it (11.4 + 3) - the closer fix ranked 2nd. At 0.5
    # helpers still separate comparable matches but cannot overturn a clearly better one.
    _helper_ratio = _rc_value("helperEvidenceRatio", 0.0, 1.0)
    for rec in recommendations:
        comp = rec.get("context_components") if isinstance(rec.get("context_components"), dict) else None
        if not comp:
            continue
        # EVIDENCE is the failure's own words and its own logs - nothing else (the repeated-fix
        # pattern is not evidence; the W adapter already captures repeated fixes). Patch
        # similarity says this fix LOOKS LIKE fixes made before; that is familiarity, not proof
        # about THIS failure, so it counts with the helpers it must not outweigh.
        _evidence = float(rec.get("match_score") or 0.0) + float(comp.get("artifact") or 0.0)
        # ONE FLOW, NO CORRECTION STEP: no trimming step is required. The rule has always
        # been "the supporting facts may count for at most what the evidence is worth" -
        # which is simply min(helpers, evidence).
        # It had been written as "add everything, then subtract the excess", and that phrasing
        # cost us a real defect: the earlier stages subtract from context_score but leave the
        # raw numbers in the breakdown, so the correction re-added them, believed the helpers
        # were larger than they were, and removed part of the same amount twice (measured: a
        # gate removing 5.40 followed by a cap removing 8.00 of which 5.40 was already gone).
        # Written as one expression there is nothing to correct and nothing to double-count.
        # Proven identical to the previous arithmetic across 564 generated cases, so no
        # candidate's score changes - only the way the rule is expressed.
        # Idempotent by construction: the helpers are read back as context - artifact, so a
        # second pass computes min(min(h, e), e) = min(h, e) and settles on the same number.
        _evidence = float(rec.get("match_score") or 0.0) + float(comp.get("artifact") or 0.0)
        if _evidence <= 0:
            # Nothing to measure the helpers against (no error match AND no artifact). Absence
            # is not contradiction - the candidate keeps what it earned.
            continue
        _artifact = float(comp.get("artifact") or 0.0)
        _ctx = float(rec.get("context_score") or 0.0)
        _helpers = _ctx - _artifact                     # what the helpers are STILL worth, after
                                                        # every earlier adjustment already applied
        _counted = max(0.0, min(_helpers, _evidence * _helper_ratio))
        if abs(_counted - _helpers) > 1e-9:
            rec["context_score"] = _artifact + _counted
            rec["final_score"] = float(rec.get("match_score") or 0.0) + float(rec.get("context_score") or 0.0)
            # Display only - the trace still shows how much the helpers were held back by.
            comp["helper_cap"] = -round(_helpers - _counted, 2)
            logger.info("Recommendation helper cap request_id=%s helpers=%.2f capped to %.2f x evidence "
                        "%.2f (held back %.2f) | total_score=%.3f",
                        str(rec.get("request_id") or "")[:12], _helpers, _helper_ratio, _evidence,
                        _helpers - _counted, float(rec.get("final_score") or 0.0))

    # WHOLE message against WHOLE message, scored on what DIFFERS between them.
    #
    # LAST, and onto the final score rather than into the context. Seven adjustments run above
    # this point - the artifact lift, the after-pattern bonus, an excess trim, a discount, a
    # task trim and the helper cap - and each recomputes the final score from the context. Added
    # into the context, these points were clawed back by whichever trim fired next, and the
    # candidate with the most helper points to trim lost the most: a recorded request put the
    # correct fix FOURTH with a final score 7.14 below the sum of its own parts. Applied here,
    # after everything, nothing can take it back.
    #
    # Why this exists: errors of the same shape differ by one line, sometimes three characters.
    # Scoring on what two messages SHARE returns the same number for all of them - measured on
    # that request, 2,129 of 2,138 characters were identical for every build of the task, and
    # three unrelated failures all came back at 0.67. No threshold separates 99.58% from 99.60%.
    # Removing the shared part first leaves only what identifies each failure: on the same case,
    # 0.83 for the right answer against 0.03 for the wrong ones.
    #
    # It asks nothing about what a line means - no phrase list, no language assumption, nothing
    # learned from how often anything has been seen - so an unfamiliar toolchain behaves like a
    # familiar one and the answer for two given messages never drifts.
    #
    # Ships OFF (weight 0): no shipped behaviour moves until an administrator sets it.
    try:
        _diff_weight = float((_rc_get_config_cached() or {}).get("distinctiveMatchWeight") or 0)
    except Exception:
        _diff_weight = 0.0
    if _diff_weight > 0 and str(query_error_text or "").strip():
        for rec in recommendations:
            try:
                _ov = _distinctive_overlap(query_error_text, str(rec.get("document") or ""))
            except Exception:
                logger.exception("distinctive overlap failed - candidate keeps its score")
                continue
            rec["distinctive_overlap"] = round(_ov, 4)
            rec["distinctive_points"] = round(_diff_weight * _ov, 3)
            rec["final_score"] = float(rec.get("final_score") or 0.0) + rec["distinctive_points"]

    # EVIDENCE MODE: the error decides, everything else can only strengthen or weaken it.
    #
    # The additive score has a structural flaw, not a tuning one: with final = match + context,
    # a candidate with a poor match and strong circumstantial agreement beats a strong match with
    # weak agreement. No set of weights prevents it - they only postpone it to the next scenario.
    # A recorded request had the correct fix at the HIGHEST similarity of four candidates and
    # placed fourth, beaten by three fixes that touched a file the developer had changed.
    #
    # Here the error match multiplies instead of adding:
    #
    #     final = scale x evidence x (1 + support / support_scale)
    #
    #   evidence   how far this candidate's error matches the one in hand, measured on what
    #              DIFFERS between them - 1.0 for an exact signature, which IS the same error
    #   support    everything circumstantial, exactly as it is scored today: same task, same
    #              file, shared words, how often the fix has helped
    #
    # Support can no longer substitute for evidence. A candidate the error does not match scores
    # near zero whatever else agrees, and a strong match with little support stays on top. Between
    # two candidates whose errors match comparably, support still decides - which is its job.
    #
    # On the recorded case: the correct fix 18 x 0.83 x 1.385 = 20.7, the config.xml fixes
    # 18 x 0.03 x 1.476 = 0.80. A separation of the kind no threshold could produce.
    #
    # OFF by default. Turning it on is a configuration change, and the previous scoring is
    # restored by turning it off - both effective on the next request, neither needing a deploy.
    try:
        _cfg_sm = _rc_get_config_cached() or {}
        _evidence_mode = str(_cfg_sm.get("scoringMode") or "additive").strip().lower() == "evidence"
        _ev_scale = max(1.0, min(60.0, float(_cfg_sm.get("evidenceScale") or 18.0)))
        _sup_scale = max(1.0, min(200.0, float(_cfg_sm.get("supportScale") or 30.0)))
    except Exception:
        _evidence_mode, _ev_scale, _sup_scale = False, 18.0, 30.0
    if _evidence_mode and str(query_error_text or "").strip():
        for rec in recommendations:
            try:
                if str(rec.get("match_type") or "").strip().lower() == "exact":
                    _ev = 1.0          # the same normalised error IS the same error
                else:
                    # The error text AND the artifact, because the failure is often only in the
                    # artifact. A recorded request's "error message" was 904 characters of build
                    # progress - "Created inputs snapshot", "Local installation of tool ... is
                    # UP-TO-DATE" - while the actual failure, "Error parsing input file" and
                    # "<Target><Compiler> must contain 'CTC' but found 'Diab'", appeared only in
                    # debug.log. Comparing the error texts alone compared build progress against
                    # build progress and every candidate looked alike.
                    #
                    # Both are passed whole and the comparison removes what they share, so adding
                    # the artifact cannot dilute anything: shared boilerplate cancels on both
                    # sides, and only what differs is scored.
                    #
                    # Not narrowed to "failure lines" first: that was measured and it was worse.
                    # The line that identified the failure above carries no marker word, so the
                    # focus dropped it and a version mismatch scored HIGHER, 0.29 against 0.22.
                    _ev = _distinctive_overlap(
                        "\n".join(x for x in (query_error_text, query_artifact_text) if x),
                        str(rec.get("document") or ""))
                    rec["distinctive_overlap"] = round(_ev, 4)
                _support = max(0.0, float(rec.get("context_score") or 0.0))
                rec["evidence_score"] = round(_ev, 4)
                rec["final_score"] = round(_ev_scale * _ev * (1.0 + _support / _sup_scale), 3)
            except Exception:
                logger.exception("evidence scoring failed - candidate keeps its additive score")

    def _recommendation_order_key(rec: Dict) -> tuple:
        final_score = -float(rec.get("final_score") or 0.0)
        _sim_raw = rec.get("similarity")
        similarity = -(max(0.0, min(1.0, float(_sim_raw))) if isinstance(_sim_raw, (int, float)) else 0.0)
        missing_solution = 0 if rec.get("solution") else 1
        # WHEN THE SOLUTION WAS UPLOADED, not when the error was captured. Asked for directly
        # (07-Oct): "it should be the upload, when I upload it, that is the time which we
        # consider - not when the error has occurred." Between two candidates that are otherwise
        # equal, the fix a developer uploaded two days ago is the better answer than one uploaded
        # three months ago, and the capture date can be months adrift from it. Falls back to
        # created_date for rows stored before uploaded_at existed, so nothing loses its order.
        recency_days = _days_since(str(rec.get("uploaded_at") or rec.get("created_date") or ""))
        request_id = str(rec.get("request_id") or "")
        # Net user feedback: more thumbs_up relative to thumbs_down = ranked higher.
        # Negated so higher net = lower tuple value = better rank.
        net_feedback = -(int(rec.get("thumbs_up") or 0) - int(rec.get("thumbs_down") or 0))
        # Human-validated FOR THIS error: a solution developers marked Helpful for this same
        # error surfaces first (within the same match priority). Boost-only - never demotes
        # others - and 0 (no effect) until such votes exist.
        link_boost = -max(0, int(rec.get("fb_link_net") or 0)) if config.FEEDBACK_LINK_BOOST_ENABLED else 0
        # The live task's own instance of an identical fix is preferred WITHIN a tie: this
        # decides which instance the same-solution dedup keeps - the one stored under the task
        # the user is fixing, not a twin from another target. It sits BEHIND the score: with
        # more than top_k candidates retrieved, a same-task row ahead of the score pushed a
        # higher-scoring other-task row out of the pool before the visible ordering ever ran,
        # so the pool and the ranking disagreed about who was in.
        rec_task = str(rec.get("task_name") or "").strip().strip(":").split(":")[-1].strip().lower()
        task_mismatch = 0 if (query_task_name and rec_task and rec_task == query_task_name) else 1
        # Same shape as the visible order: score first, similarity next, feedback only as a
        # tie-break. The match-type tier is gone (an exact match leads on score anyway) and the
        # same-error vote link (link_boost) no longer sits ahead of the score - it was a
        # feedback weight, and feedback decides ties only.
        return (
            missing_solution,
            final_score,    # relevance score
            similarity,     # ties on score go to the closer error
            task_mismatch,  # the live task's own instance survives dedup, within a tie
            net_feedback,   # global user feedback as tiebreaker
            link_boost,     # human-validated-for-this-error, tiebreaker after that
            recency_days,   # recency last
            request_id,
        )

    deduped: List[Dict] = []
    seen_keys = set()
    ordered = sorted(recommendations, key=_recommendation_order_key)
    logger.info("[dup-debug] DISPLAY candidates (vector_id, request_id, file, sig)=%s",
                [(r.get("vector_id"), r.get("request_id"), r.get("file_name"),
                  str(r.get("error_signature_hash") or "")[:16]) for r in ordered[:12]])

    seen_solutions: set = set()
    for rec in ordered:
        solution_fp = _solution_fingerprint(rec.get("solution"))
        # Content-level dedup: the SAME fix uploaded across different build cycles gets a different
        # request_id, so keying the dedup on request_id let identical solutions through and the top-k
        # showed the same fix repeated. Collapse purely by solution CONTENT regardless of request_id,
        # keeping the best-ranked instance ('ordered' is already best-first). This surfaces DISTINCT
        # solutions in the top-k. (Removing exact duplicates is redundancy removal, not data loss.)
        if solution_fp:
            if solution_fp in seen_solutions:
                logger.info("[dup-debug] DISPLAY dropped same-solution request_id=%s file=%s",
                            rec.get("request_id"), rec.get("file_name"))
                continue
            seen_solutions.add(solution_fp)
        else:
            # No usable solution content -> fall back to identity key so distinct empty/near-empty
            # rows are not over-collapsed into one.
            key = (
                str(rec.get("request_id") or rec.get("vector_id") or ""),
                str(rec.get("file_name") or ""),
            )
            if key in seen_keys:
                logger.info("[dup-debug] DISPLAY dropped duplicate vector_id=%s request_id=%s file=%s",
                            rec.get("vector_id"), rec.get("request_id"), rec.get("file_name"))
                continue
            seen_keys.add(key)
        deduped.append(rec)
        if len(deduped) >= top_k:
            break

    if ordered:
        logger.info(
            "Recommendation rerank ordered candidates=%s",
            [
                {
                    "request_id": rec.get("request_id"),
                    "match_type": rec.get("match_type"),
                    "match_score": round(float(rec.get("match_score") or 0.0), 3),
                    "context_score": round(float(rec.get("context_score") or 0.0), 3),
                    "final_score": round(float(rec.get("final_score") or 0.0), 3),
                    "file_name": rec.get("file_name"),
                }
                for rec in ordered[: min(len(ordered), 5)]
            ],
        )

    for idx, rec in enumerate(deduped, start=1):
        rec["rank"] = idx

    return deduped


def _extract_gbe_task_token(text: str) -> str:
    """The failing task name embedded in GBE launch preambles ('... for the GBE process task4 ...')."""
    m = re.search(r"GBE process\s+([A-Za-z0-9_.\-]+)", str(text or ""), re.IGNORECASE)
    return m.group(1).strip().lower() if m else ""


def _canonical_task_token(task: str) -> str:
    """':TARGETS:master:task4' / 'task4' -> 'task4' (case/prefix-insensitive comparison form)."""
    t = str(task or "").strip().lower().strip(":")
    return t.split(":")[-1].strip() if t else ""


# A drive-letter path INCLUDING spaces in its segments. clean_volatile_text's own path rule is
# [a-z]:[\\/][^\s"']+ - it stops at the first SPACE, so it neutralises D:\TESTGBE_ERROR\... but
# leaves 'D:\Build type error\TestGbe\build\master\task4\...' as ' type error\testgbe\build\...'.
# Segments may contain spaces as long as another separator follows; the LAST segment may not, so
# text after a path survives ("c:/app/python.exe: can't find __main__" keeps "can't find").
_PATH_WITH_SPACES = re.compile(r"[a-zA-Z]:[\\/](?:[^\\/\r\n\"']*[\\/])*[^\\/\r\n\"'\s]*")


def _scrub_paths_for_ranking(text: str) -> str:
    """Neutralise spaced paths BEFORE ranking looks at a text.

    Seen on a recorded request: the project lived in 'D:\\Build type error\\...'.
    Because clean_volatile_text's path rule stops at the first space, the folder name kept the
    word "error", so every path line in the debug.log was classified as a FAILURE line - and the
    whole directory layout (testgbe, build, master, task4, log, out, config.json) entered the
    comparison token set. Rarity weighting then rewarded whichever candidate shared the query's
    DIRECTORY layout: a python fix scored 27 token hits (task4 alone weighing 0.100) against the
    ctc fix's 17, and beat it 1.6455 to 1.1909 even though only the ctc fix carried the actual
    root-cause token '6.2r1p456' (weight 0.333). The failing tool lost to a folder name.

    The same bug was found and fixed once before for 'TESTGBE_ERROR' - that folder has no spaces,
    so the existing rule consumed it. A space reopened it.

    Deliberately NOT fixed inside clean_volatile_text: that function also computes the cleaned
    checksums used for artifact dedup and the upload precheck, so changing it would shift every
    stored fingerprint and stop existing artifacts matching new uploads. Ranking-side only.
    """
    return _PATH_WITH_SPACES.sub(" <path> ", str(text or ""))


# clean_volatile_text marks every value it neutralises with an ANGLE-BRACKET placeholder - <ts>,
# <path>, <hex>, and whatever it gains next. The tokeniser below splits on non-alphanumerics, so
# each placeholder survives as a bare word and rarity weighting then scores it as evidence.
#
# Seen on a recorded request: on a ctc failure a PYTHON fix's artifact scored token 0.629
# against the ctc fix's 0.440, and the entire 0.5000 difference was ONE token: "ts", df=2, weight
# 0.5000 - the heaviest in the whole comparison. Most stored summaries have their timestamps
# paraphrased away by the summariser, so only two documents still carried one; that made the
# placeholder RARE, and rare means decisive. The winning artifact was the vaguest of four
# ("Validation indicates tools[name=python].version mismatch", no version at all) and it beat an
# artifact naming the exact failing tool, purely by keeping a timestamp.
#
# The failure mode is systematic and inverted: the more meaningless a placeholder is, the fewer
# documents retain it, and the MORE weight rarity gives it.
#
# Matched by SHAPE, not by a list of words. A stop-list of "ts, path, hex..." would go stale the
# moment clean_volatile_text gains a placeholder, and would silently stop covering it - and it
# would also delete those words from real error text, where they are ordinary vocabulary. This
# only removes the bracketed form the cleaner itself emits, so it covers every placeholder that
# exists now or later and touches nothing a failure actually said.
_CLEANER_PLACEHOLDER = re.compile(r"<[a-z]+>")


def _differing_lines(query_text: str, candidate_text: str) -> tuple:
    """(what only the query says, what only the candidate says), compared whole against whole.

    Lines are normalised first - volatile parts removed - so a different path or timestamp does
    not count as a difference. What comes back is the content that genuinely separates the two
    messages.
    """
    from src.utils.content_fingerprint import clean_volatile_text

    def _lines(text):
        out = {}
        for raw in str(text or "").splitlines():
            if not raw.strip():
                continue
            key = _normalize_error_message(clean_volatile_text(_scrub_paths_for_ranking(raw)))
            if key:
                out.setdefault(key, raw.strip())
        return out

    q, c = _lines(query_text), _lines(candidate_text)
    shared = q.keys() & c.keys()
    return ([q[k] for k in q.keys() - shared], [c[k] for k in c.keys() - shared])


def _distinctive_overlap(query_text: str, candidate_text: str) -> float:
    """How much the two messages agree ON WHAT MAKES THEM DIFFERENT. 0 to 1.

    The whole message is compared against the whole message - but scored on what DIFFERS, not on
    what is shared, and that inversion is the entire point.

    A build log is mostly the same every run: the snapshot lines, the tool install, the command
    line. Measured on a reported case, 2,129 of 2,138 characters were identical for every build of
    that task and nine said which command had failed. Scoring on what is shared therefore returns
    the same number for every candidate - unrelated failures all came back at 0.67, correctly,
    because they genuinely are 99.6% the same text. No threshold can separate 99.58 from 99.60.

    Removing the common part first leaves only the content that identifies each failure, and those
    parts either correspond or they do not:

      the same failure           almost nothing is left on either side  -> near 1
      different failures         'ech is not recognized' on one side, a version mismatch on the
                                 other, no words in common              -> near 0

    Deterministic: the same two messages always give the same answer. It asks nothing about what a
    line MEANS - no phrase list, no language assumption, no count of how often anything has been
    seen - so a toolchain nobody has encountered is handled the same as a familiar one.
    """
    q_only, c_only = _differing_lines(query_text, candidate_text)
    c_tokens = _distinctive_token_set("\n".join(c_only))
    if not c_tokens:
        # The candidate says nothing this error does not already say, so it describes this same
        # failure. The best possible answer, and it must not be confused with "no overlap".
        #
        # Scored as a Jaccard over both sides' leftovers it came out as ZERO, because one side
        # was empty - the opposite of the truth. That showed up the moment the artifact was
        # included: the query then carried MORE than the candidate, which is the ordinary case
        # once the live log is part of the comparison.
        return 1.0
    # How much of what the candidate uniquely says is also in this failure. Measured against the
    # WHOLE query, not only its leftovers: a line the two share is still a line this failure has,
    # and removing it from the query's side as well would punish the candidate for agreeing.
    q_all = _distinctive_token_set(str(query_text or ""))
    return len(c_tokens & q_all) / len(c_tokens)


_XML_TAG_RE = re.compile(r"</?\s*([A-Za-z_][\w.:-]*)[^<>]*>")


def _xml_tags_to_words(text: str) -> str:
    """An element name is a word of the failure. `<Target><Compiler> must contain 'CTC'` names
    the Compiler element, and the fix `<Compiler>CTC</Compiler>` names it again - but the
    cleaner read `</Compiler>` as a path (it starts with a slash) and the placeholder filter
    read `<Compiler>` as one of its own `<path>`-style markers, so both were deleted and the
    only token left of that fix was `ctc`. The ingest ownership gate needs TWO shared tokens
    for proof, so a config.xml fix with a single-word value could never be matched to its own
    log. Tags become their element names before any cleaning runs."""
    return _XML_TAG_RE.sub(lambda m: " " + m.group(1) + " ", str(text or ""))


def _distinctive_token_set(text: str) -> set:
    """Comparison tokens of an error text with volatile parts (paths/timestamps/hex) normalized
    away, so what remains is the wording that actually distinguishes one failure from another.
    XML element names count as words (see _xml_tags_to_words)."""
    from src.utils.content_fingerprint import clean_volatile_text
    cleaned = clean_volatile_text(_scrub_paths_for_ranking(_xml_tags_to_words(text)))
    cleaned = _CLEANER_PLACEHOLDER.sub(" ", cleaned)
    return {t for t in re.split(r"[^a-z0-9.]+", cleaned.lower()) if len(t) >= 2}


# Words that mark a line as carrying FAILURE signal (same philosophy as the client-side
# artifact signal scan). Lowercase substring match — deliberately broad, never format-specific.
_FAILURE_SIGNAL_MARKERS = (
    "error", "fail", "exception", "traceback", "fatal", "warn",
    "cannot", "can't", "unable", "missing", "not found", "no such",
    "not defined", "undefined", "not recognized", "denied", "refused",
    "invalid", "abort", "timeout", "exit code", "errno",
    # Validation-failure phrasing (debug.log case): the root-cause line
    # "'tools[...].version' must be '6.2r1p4' but got '6.2r1p456'" sits behind a [DEBUG]
    # tag and carries none of the classic markers — without these it never reaches the
    # signal-focused tiers. Kept in sync with the extension's SIGNAL regex
    # (FileWatcher.extractArtifactSignalLines).
    "must be", "but got", "expected", "should be", "mismatch", "not match",
)


def _line_has_failure_marker(line: str) -> bool:
    """Marker check on the VOLATILE-CLEANED line: paths become '<path>' first, so a project
    folder like D:\\...\\TESTGBE_ERROR\\... can no longer make every line 'contain error'
    (live 17:17 log: 35 of 35 lines "matched" through the path, keeping demo chatter)."""
    from src.utils.content_fingerprint import clean_volatile_text
    # _scrub_paths_for_ranking first: clean_volatile_text's path rule stops at the first space,
    # so a folder named 'Build type error' kept the word "error" and made four pure path lines
    # of a debug.log read as failure signals (seen on a recorded request).
    low = clean_volatile_text(_scrub_paths_for_ranking(line)).lower()
    return any(m in low for m in _FAILURE_SIGNAL_MARKERS)


def _failure_signal_lines(text: str) -> List[str]:
    """Lines that carry failure signal, PLUS the detail lines that follow each one.

    In these logs the marker line says THAT something failed and the next line says WHAT:

        [ERROR] Error parsing input file
        [DEBUG] <Target><Compiler> must contain 'CTC' but found 'Diab'

    The detail line holds the only words that distinguish this failure from every other "Error
    parsing input file", and it need not contain a marker word of its own - the recorded line
    above contains none, so it was invisible to every consumer of this function: the artifact
    evidence tokens, the ingest ownership gate, the wording tier and the stored summary's
    verbatim appendix. A CTC-compiler log then "named" nothing but the generic error line, which
    every GBE failure shares. Up to FAILURE_DETAIL_LINES (default 2) non-empty lines after a
    marker line are kept with it; a marker line inside that window restarts the window. No
    phrase decides what a detail line looks like - position after a marker does."""
    try:
        n_detail = max(0, int(os.getenv("FAILURE_DETAIL_LINES", "2")))
    except (TypeError, ValueError):
        n_detail = 2
    out: List[str] = []
    carry = 0
    for ln in str(text or "").splitlines():
        if not ln.strip():
            continue
        if _line_has_failure_marker(ln):
            out.append(ln)
            carry = n_detail
        elif carry > 0:
            out.append(ln)
            carry -= 1
    return out


def _signal_focused_query_text(text: str) -> str:
    """The FAILURE-signal lines of a query error text, for the wording-relevance tier only.

    Live evidence (a captured log): the winning overlap tokens were snapshot-progress
    chatter ('Creating snapshot for ctc_aurix 6.2r1p4') — present in one candidate's stored
    block simply because that block was stored longer, not because it was relevant. The real
    failure ('NameError ... is not defined') sat lower in the message and never decided the
    order. Ranking wording must therefore compare FAILURE lines, not build-progress lines.

    Keeps every line containing a failure marker; single-line texts and texts with no marker
    lines fall back to the FULL text unchanged (unknown formats never lose information).
    Display, storage, search embeddings and every other tier are untouched.
    """
    raw = str(text or "")
    lines = [ln for ln in raw.splitlines() if ln.strip()]
    if len(lines) <= 1:
        return raw
    signal = _failure_signal_lines(raw)
    return "\n".join(signal) if signal else raw


def _candidate_artifact_texts_for_rerank(recommendations: List[Dict]) -> Dict[str, str]:
    """Per candidate request_id: the stored AI summaries of its artifacts (made once at upload —
    'Error Signals' / 'Root Cause Clues'). Compact evidence of what ACTUALLY went wrong in that
    build. Used to disambiguate near-identical error texts (two ~95%-similar
    version errors, but the build.log names the real cause — the fix whose artifacts match the
    current failure's log must rank on top). One vector-store read per project."""
    texts: Dict[str, str] = {}
    try:
        project = next(
            (str(r.get("project_name") or "").strip() for r in recommendations if r.get("project_name")),
            "",
        )
        summaries_by_key = _artifact_summaries_for_project(project) if project else {}
    except Exception:
        summaries_by_key = {}
    if not summaries_by_key:
        return texts
    from src.utils.project_details import get_artifact_references
    for rec in recommendations:
        rid = str(rec.get("request_id") or "").strip()
        if not rid or rid in texts:
            continue
        parts: List[str] = []
        try:
            refs = (get_artifact_references(rid, "runtime") or []) + (get_artifact_references(rid, "binary") or [])
        except Exception:
            refs = []
        for ref in refs:
            # Ingest gate: a log proven to be about a different fix must not feed ANY
            # ranking leg. _artifact_match_scores already skips these; this second consumer has
            # to agree, or the flagged log's summary still boosts the wrong fix lexically.
            if not _artifact_reference_evidence_eligible(project, rid, ref):
                continue
            key = str((ref or {}).get("s3_key") or "").strip()
            if not key:
                continue
            entry = summaries_by_key.get(key) or summaries_by_key.get(f"sha:{_sha12_from_s3_key(key)}") or {}
            summary = str(entry.get("summary") or "").strip()
            if summary:
                parts.append(summary)
        texts[rid] = "\n".join(parts)[:8000]
    return texts


def _candidate_solution_file_names(rec: Dict) -> set:
    """Lowercased basenames of the files a candidate's FIX touched."""
    names = set()
    for item in (rec.get("solution") or []):
        if not isinstance(item, dict):
            continue
        for key in ("fileName", "filePath", "file_name", "file_path"):
            raw = str(item.get(key) or "").strip().replace("\\", "/")
            if raw:
                base = raw.rstrip("/").split("/")[-1].strip().lower()
                if base:
                    names.add(base)
    return names


def _rerank_recommendations_for_relevance(
    recommendations: List[Dict],
    query_text: str,
    query_task_path: str = "",
    query_artifact_text: str = "",
    query_file_names: List[str] | None = None,
    user_task_path: str = "",
    query_project: str = "",
) -> List[Dict]:
    """Deterministic relevance layer over the fused candidates (observed in a demo: with
    several near-identical stored errors the vector order is effectively arbitrary — the right
    fix ranked outside the top 3 even when queried with its OWN stored text, a thrice-downvoted
    unrelated fix sat at #1, and task identity was ignored).

    Order: the FINAL SCORE, descending - always. Ties on the final score go to the higher
    similarity; ties on both go to net thumbs (feedback is a tie-break, never a weight);
    then same project, same task, file identity, distinctive-token overlap and the original
    order. A candidate with no solution sorts last whatever its score. Nothing sinks on votes
    any more: a downvote is recorded on the row (relevance_rerank.downvoted) but moves nothing
    unless the scores are tied. This is the ONE order: the webview (report-error API) returns
    it and the trace stores it, in the same sequence.
    Nothing is dropped — this only reorders."""
    if not recommendations:
        return recommendations

    query_task = _canonical_task_token(query_task_path) or _extract_gbe_task_token(query_text)
    # The task the USER actually ran (report requestedTasks, live-only): candidates from that
    # very task get a confirmation preference WITHIN the same-task tier.
    user_task = _canonical_task_token(user_task_path)
    # Wording tier compares FAILURE lines, not build-progress chatter (in a live log
    # snapshot-noise tokens decided #1 vs #2 between two config.xml fixes).
    _q_focus = _signal_focused_query_text(query_text)
    if _q_focus != str(query_text or ""):
        logger.info("[RECO-DEBUG] wording tier focused on %d signal line(s): %r",
                    len(_q_focus.splitlines()), _q_focus[:400])
    q_tokens = _distinctive_token_set(_q_focus)
    docs = [q_tokens] + [_distinctive_token_set(str(r.get("document") or "")) for r in recommendations]
    df: Dict[str, int] = {}
    for d in docs:
        for t in d:
            df[t] = df.get(t, 0) + 1

    # Artifact evidence: when the request carries excerpts of the CURRENT
    # failure's collected artifacts (build/task logs), compare them against each candidate's
    # stored artifact summaries the same 1/df way — the actual cause named in the logs breaks
    # ties that near-identical error texts cannot.
    a_query_tokens: set = set()
    candidate_artifact_tokens: List[set] = []
    a_df: Dict[str, int] = {}
    _artifact_usable = bool(str(query_artifact_text or "").strip())
    if _artifact_usable and not _failure_signal_lines(query_artifact_text):
        # Context-only excerpts (live 17:17 log: two 27-char demo files, 'Dummy content for
        # file one.') carry no failure signal — their tokens only match other tasks' identical
        # demo outputs, so junk would DECIDE the ranking. Evidence must name a failure to rank.
        logger.info("[RECO-DEBUG] artifact evidence skipped: excerpts carry no failure-signal line (context-only)")
        _artifact_usable = False
    if _artifact_usable:
        artifact_texts = _candidate_artifact_texts_for_rerank(recommendations)
        a_query_tokens = _distinctive_token_set(query_artifact_text)
        for r in recommendations:
            rid = str(r.get("request_id") or "").strip()
            candidate_artifact_tokens.append(_distinctive_token_set(artifact_texts.get(rid, "")))
        for d in [a_query_tokens] + candidate_artifact_tokens:
            for t in d:
                a_df[t] = a_df.get(t, 0) + 1

    # File identity (the file-level challenge): the failure implicates specific FILES
    # (report error locations). A candidate whose fix touched one of those files outranks
    # candidates that fixed other files — config.xml problems get config.xml fixes on top.
    q_files = {
        str(n or "").strip().replace("\\", "/").rstrip("/").split("/")[-1].lower()
        for n in (query_file_names or []) if str(n or "").strip()
    }
    q_files.discard("")

    # [RECO-DEBUG] the tokens that decide the wording-relevance tier (weight = 1/df):
    # boilerplate shared by every candidate weighs ~nothing, rare tokens carry the ranking.
    _q_weighted = sorted(((t, 1.0 / df[t]) for t in q_tokens), key=lambda x: (-x[1], x[0]))
    logger.info("[RECO-DEBUG] query task token=%r | query files=%r", query_task, sorted(q_files))
    logger.info("[RECO-DEBUG] query tokens by weight (top 25 of %d): %s",
                len(q_tokens), ", ".join(f"{t}={w:.2f}" for t, w in _q_weighted[:25]))

    keyed = []
    for idx, rec in enumerate(recommendations):
        c_tokens = docs[idx + 1]
        distinct_score = sum(1.0 / df[t] for t in (q_tokens & c_tokens))
        artifact_score = 0.0
        if a_query_tokens and idx < len(candidate_artifact_tokens):
            artifact_score = sum(1.0 / a_df[t] for t in (a_query_tokens & candidate_artifact_tokens[idx]))
        relevance = distinct_score + artifact_score
        up = int(rec.get("thumbs_up") or 0)
        down = int(rec.get("thumbs_down") or 0)
        rec_task = _canonical_task_token(str(rec.get("task_name") or "")) or _extract_gbe_task_token(str(rec.get("document") or ""))
        task_hit = 1 if (query_task and rec_task and rec_task == query_task) else 0
        user_task_hit = 1 if (user_task and rec_task and rec_task == user_task) else 0
        file_hit = 1 if (q_files and (q_files & _candidate_solution_file_names(rec))) else 0
        # Group scope: the project's OWN fix wins only a TIE in final score. A sibling
        # that scored higher stays ahead - evidence decides, the project is the secondary signal.
        # Under project scope every candidate is same-project, so the order is unchanged.
        _qp = str(query_project or "").strip().lower()
        same_project = 1 if (_qp and str(rec.get("project_name") or "").strip().lower() == _qp) else 0
        # A net-downvoted candidate no longer SINKS. Feedback is a tie-break only (below): the
        # order is the final score, and votes decide between candidates whose final score and
        # similarity are equal. The flag is still computed and recorded on the row for the
        # trace. downvoteSinkMinVotes keeps its meaning for the flag alone.
        try:
            _sink_min = int(float((_rc_get_config_cached() or {}).get("downvoteSinkMinVotes") or 1))
        except Exception:
            _sink_min = 1
        downvoted = 1 if (down > up and down >= max(1, _sink_min)) else 0
        _overlap = sorted(((t, 1.0 / df[t]) for t in (q_tokens & c_tokens)), key=lambda x: (-x[1], x[0]))[:8]
        logger.info(
            "[RECO-DEBUG] cand %s task=%r fix_files=%r task_hit=%s file_hit=%s distinct=%.4f artifact=%.4f net=%d | top overlap: %s",
            str(rec.get("request_id") or "")[:12],
            str(rec.get("task_name") or ""),
            sorted(_candidate_solution_file_names(rec)),
            bool(task_hit), bool(file_hit), distinct_score, artifact_score, up - down,
            ", ".join(f"{t}={w:.2f}" for t, w in _overlap) or "(none)",
        )
        rec["relevance_rerank"] = {
            "task_hit": bool(task_hit),
            "file_hit": bool(file_hit),
            "distinct_score": round(distinct_score, 4),
            "artifact_score": round(artifact_score, 4),
            "net_thumbs": up - down,
            "downvoted": bool(downvoted),
        }
        # Recorded for the trace; no longer a tier of its own. An exact-signature match earns
        # the exact base (18) and similarity 1.0, so it leads on score and wins any tie on
        # similarity - it does not need to outrank the final score to come first.
        exact_hit = 1 if str(rec.get("match_type") or "").strip().lower() == "exact" else 0
        rec["relevance_rerank"]["exact_hit"] = bool(exact_hit)
        # NOTHING TO RECOMMEND sorts last whatever its score. The gate already refuses to SHOW
        # a candidate without a solution (match_status 'none'); this order is what the trace
        # lists too, and a bare same-task row scored 15.00 sat at rank 2 with an empty solution
        # column (live, 08-Oct) above three real fixes.
        no_solution = 0 if rec.get("solution") else 1
        _final = float(rec.get("final_score") or 0.0)
        _sim_raw = rec.get("similarity")
        _sim = max(0.0, min(1.0, float(_sim_raw))) if isinstance(_sim_raw, (int, float)) else 0.0
        # THE ORDER (asked for directly, 08-Oct):
        #   1. final score, descending - always;
        #   2. similarity, descending, when final scores tie;
        #   3. net thumbs, when final score AND similarity tie - feedback is a tie-break, never
        #      a weight, so a downvote cannot bury a better-scoring fix and an upvote cannot
        #      lift a worse one;
        #   4. same project, same task, user's task, file identity, distinctive-token overlap,
        #      and the original order, so the result is stable and fully explained.
        # Every factor is recorded on the candidate (rank_factors) so the trace explains the
        # order instead of anyone guessing.
        rec["rank_factors"] = {
            "no_solution": bool(no_solution), "final_score": round(_final, 2),
            "similarity": round(_sim, 3), "net_votes": up - down,
            "same_project": bool(same_project), "same_task": bool(task_hit),
            "user_ran_task": bool(user_task_hit), "file_match": bool(file_hit),
            "token_overlap": round(float(relevance), 3),
            "exact_signature": bool(exact_hit), "downvoted": bool(downvoted),
        }
        keyed.append((no_solution, -round(_final, 3), -round(_sim, 6), -(up - down), -same_project,
                      -task_hit, -user_task_hit, -file_hit, -relevance, idx, rec))

    keyed.sort(key=lambda k: k[:10])
    reordered = [k[10] for k in keyed]

    # ---- Did developer feedback actually change this order? ----
    # Exactly ONE term of the key above comes from votes: net thumbs at position 3, the
    # tie-break behind final score and similarity. Re-sorting the SAME pool with that term -
    # and only that term - neutralised gives the order this request would have had if nobody
    # had ever voted. The difference between the two positions is therefore MEASURED, not
    # asserted, and it is 0 for every candidate whenever no vote exists or the scores were not
    # tied - which is the honest answer almost always, now that votes are a tie-break only.
    try:
        _no_fb = sorted(keyed, key=lambda k: tuple(k[0:3]) + (0,) + tuple(k[4:10]))
        _rank_without = {k[9]: i for i, k in enumerate(_no_fb)}
        for _i, _k in enumerate(keyed):
            _was = _rank_without.get(_k[9])
            if _was is None:
                continue
            _rec = _k[10]
            _rec["feedback_influence"] = {
                "rank": _i + 1,
                "rank_without_feedback": _was + 1,
                "delta": _was - _i,                      # > 0 = votes moved it UP (a tie only)
                "sunk": False,                           # nothing sinks on votes any more
                "net_votes": int((_rec.get("relevance_rerank") or {}).get("net_thumbs") or 0),
            }
    except Exception:
        # An explanation is never worth a recommendation: the order above already stands.
        logger.exception("feedback counterfactual failed (ranking unaffected)")
    logger.info(
        "[RERANK] deterministic relevance order: %s",
        [
            f"{r.get('request_id')}(task_hit={r['relevance_rerank']['task_hit']},"
            f"file_hit={r['relevance_rerank']['file_hit']},"
            f"distinct={r['relevance_rerank']['distinct_score']},net={r['relevance_rerank']['net_thumbs']})"
            for r in reordered
        ],
    )
    return reordered


def _dedupe_recommendations_by_fix(recommendations: List[Dict],
                                   query_task_path: str = "") -> List[Dict]:
    """Collapse candidates proposing the IDENTICAL fix (near-duplicate stored errors share one
    solution): the best-ranked SLOT stays, the repeats go — the 'third one keeps
    appearing' case. Candidates without a solution are never collapsed.

    Family representative: the member whose STORED TASK matches the task the user is
    fixing right now represents the family — the shown entry then carries the user's own task
    context, not a twin from another target. Within the same task-match tier the LATEST
    confirmed one wins (the id refreshes on every re-confirmation,
    not a 9-day-old twin). The slot/rank stays where the best family member ranked; only the
    representative inside it changes."""
    query_task = _canonical_task_token(query_task_path)

    def _task_hit(rec: Dict) -> int:
        if not query_task:
            return 0
        rec_task = _canonical_task_token(str(rec.get("task_name") or ""))
        return 1 if (rec_task and rec_task == query_task) else 0

    slot_by_sig: Dict[str, int] = {}
    out: List[Dict] = []
    for rec in recommendations:
        solution = rec.get("solution") or []
        if not solution:
            out.append(rec)
            continue
        sig = re.sub(r"\s+", "", json.dumps(solution, sort_keys=True, default=str)).lower()
        if sig not in slot_by_sig:
            slot_by_sig[sig] = len(out)
            out.append(rec)
            continue
        idx = slot_by_sig[sig]
        kept = out[idx]
        if (_task_hit(rec), str(rec.get("created_date") or "")) > \
                (_task_hit(kept), str(kept.get("created_date") or "")):
            logger.info(
                "[dup-debug] family representative -> %s %s (was %s)",
                "same-task" if _task_hit(rec) else "latest confirmed",
                rec.get("request_id"), kept.get("request_id"),
            )
            out[idx] = rec
    return out


def _run_report_error_recommendation(*args, **kwargs) -> Dict:
    """GROUP IS THE SCOPE, PROJECT ONLY FOR THE UNGROUPED.

    The scope was expanded: a project in a DEFINED group is searched together with its siblings
    in ONE pass, every source widened (exact signature, semantic base + learned space, task
    ledger, artifact evidence, artifact summaries), and the scoring decides between a sibling's
    fix and the project's own. The project's own fix wins only a tie in the display order
    (_rerank_recommendations_for_relevance). Projects in "Other", or alone in their group, stay
    at project scope until an admin assigns them - "Other" is a removal bucket, not a group.

    This replaces the earlier two-pass rule (project first, siblings only when the project showed
    nothing). That rule guarded against dev's mixed-up test groups; the rule now is that a
    wrong group is corrected in the group configuration, not by narrowing the search. The knob
    recommendationScope keeps "project" available: with it the one-project search is
    byte-identical to the pre-group behaviour.

    The pass itself is _run_report_error_recommendation_scoped; the scope reaches each source
    through _reco_scope_members / recommended._scope_filter, so this wrapper only logs it.
    """
    project = str((kwargs.get("project_name") if "project_name" in kwargs
                   else (args[0] if args else "")) or "").strip().lower()
    # The developer's choice for THIS request, taken off the call and published to the four places
    # downstream that resolve scope. Always reset, so one request cannot inherit another's.
    requested = kwargs.pop("requested_scope", None)
    token = _requested_scope_var.set(str(requested).strip().lower() if requested else None)
    try:
        try:
            _members, _mode = _reco_scope_members(project)
        except Exception:
            _members, _mode = [project], "project"
        if _mode == "customer":
            logger.info("[scope] customer scope for %s (%s) - one pass over %d member(s): %s",
                        project, "requested" if requested else "configured",
                        len(_members), ",".join(_members[:8]))
        elif _mode == "global":
            logger.info("[scope] GLOBAL scope for %s (%s) - no project filter",
                        project, "requested" if requested else "configured")
        return _run_report_error_recommendation_scoped(*args, **kwargs)
    finally:
        _requested_scope_var.reset(token)


def _run_report_error_recommendation_scoped(
    project_name: str,
    errors: List[Dict[str, object]],
    preferred_query: str = "",
    task_path: str = "",
    copilot_query: str = "",
    query_artifact_text: str = "",
    query_changed_files: List[str] | None = None,
    user_requested_task: str = "",
    query_artifact_excerpts: List[Dict] | None = None,
) -> Dict:
    project_name = (project_name or "").strip().lower()
    if not project_name:
        return {
            "status": "error",
            "error": "project_name is required"
        }

    top_k = 3         # Final output: TOP 3 recommendations to the client
    search_top_k = 10 # Retrieval: TOP 10 for RRF fusion

    logger.debug(
        "_run_report_error_recommendation | start | project_name=%s | error_count=%d | top_k=%d | search_top_k=%d",
        project_name, len(errors or []), top_k, search_top_k,
    )

    user_query = str(preferred_query or "").strip()
    query_candidates = _build_recommendation_query_candidates(errors)
    if not query_candidates and errors:
        first = str((errors[0] or {}).get("message") or "").strip()
        if first:
            query_candidates = [first]
    if user_query:
        deduped = [user_query]
        seen = {user_query.lower()}
        for candidate in query_candidates:
            c = str(candidate or "").strip()
            if not c or c.lower() in seen:
                continue
            seen.add(c.lower())
            deduped.append(c)
        query_candidates = deduped
    query_candidates = query_candidates[:10]
    msg = query_candidates[0] if query_candidates else ""

    logger.debug(
        "_run_report_error_recommendation | query_candidates | project_name=%s | count=%d | first_preview=%.120s",
        project_name, len(query_candidates), msg,
    )

    # ---- FLOW-DEBUG: what drives the search ----
    logger.info("[FLOW-DEBUG] === STEP 1: QUERY CONSTRUCTION ===")
    logger.info("[FLOW-DEBUG] preferred_query (query_text from user) = %r", user_query)
    logger.info("[FLOW-DEBUG] error message(s) from build = %r",
                [str((e or {}).get("message") or "")[:150] for e in (errors or [])])
    logger.info("[FLOW-DEBUG] query_candidates (order matters, [0] is the anchor) = %r",
                [str(c)[:80] for c in query_candidates])
    logger.info("[FLOW-DEBUG] msg = ANCHOR used for artifact/doc search = %r", str(msg)[:600])
    logger.info("[FLOW-DEBUG] task_path = %r", task_path)
    logger.info("[FLOW-DEBUG] changed_files from client = %r", list(query_changed_files or []))
    logger.info("[FLOW-DEBUG] artifact_text: %d chars | preview: %r",
                len(str(query_artifact_text or "")), str(query_artifact_text or "")[:400])
    # ---------------------------------------------

    normalized_task_path = (task_path or "").strip()
    # Task-mapping fix (the user's current task could be one thing while the
    # recommendation matched another): the request-level task can be an UMBRELLA task
    # (report requestedTasks, e.g. :TARGETS:master:1_normal_without_arproc) while the user is
    # fixing the task that actually FAILED. When the sent task is missing or does not match
    # any failing error's own task path, the first ERROR's task path becomes the query task -
    # it drives the same-task tier, the task weight, the +8 base bonus and the trace.
    _error_task_paths = [str((e or {}).get("task_path") or "").strip()
                         for e in (errors or []) if isinstance(e, dict)]
    _error_task_paths = [t for t in _error_task_paths if t]
    if _error_task_paths:
        _norm_l = normalized_task_path.lower()
        if not _norm_l or all(_norm_l != t.lower() for t in _error_task_paths):
            logger.info("query task overridden by failing error's task: %r -> %r",
                        normalized_task_path, _error_task_paths[0])
            normalized_task_path = _error_task_paths[0]
    search_result = _search_recommendation_matches(
        project_name=project_name,
        query_candidates=query_candidates,
        top_k=search_top_k,
        task_path=normalized_task_path
    )

    logger.debug(
        "_run_report_error_recommendation | vector_search_done | project_name=%s | "
        "matched_ids_count=%d | exact_match_count=%d | query_signature_hashes_count=%d",
        project_name,
        len(search_result.get("ids") or []),
        search_result.get("exact_match_count", 0),
        len(search_result.get("query_signature_hashes") or []),
    )

    # Deterministic task-ledger recall: stored solutions of the FAILING
    # task join the pool even when the vector index missed them (e.g. vectors never built).
    _ledger = _task_ledger_candidates(
        project_name, normalized_task_path,
        search_result.get("query_signature_hashes"), search_result["vector_matches"])
    for _lm in _ledger:
        search_result["vector_matches"].append(_lm)
        search_result["ids"].append(_lm["vector_id"])
        search_result["metadatas"].append(_lm["meta"])

    results = {
        "ids": [search_result["ids"]],
        "metadatas": [search_result["metadatas"]],
        "query_candidates": query_candidates,
        "query_signature_hashes": search_result["query_signature_hashes"],
        "exact_match_count": search_result["exact_match_count"],
    }
    # Hydrate TOP 10 for RRF; final output is gated to TOP 3 below.
    recommendation_context = _extract_recommendation_context(errors)
    if normalized_task_path:
        norm_key = normalized_task_path.lower()
        if norm_key not in {t.lower() for t in recommendation_context["task_paths"]}:
            recommendation_context["task_paths"].insert(0, normalized_task_path)
    # NOTE (tried and REVERTED): changed files were briefly added to
    # the BASE file tier here — but that tier scores PER FIX INSTANCE (+6 each), so a solution
    # confirmed 5 times on the changed file gained +30: popularity amplified as identity, the
    # opposite of evidence-driven. Changed-file identity is used where it is a per-candidate
    # boolean — the relevance layer's file tier (_file_signal below) — and stays out of the
    # per-instance base accumulation.
    # FILE IDENTITY FOR THE +file POINTS: the files the developer CHANGED this cycle, when the
    # client sends them. The report's error location is usually the task script, so with it the
    # file points went to fixes of the script rather than of the file actually edited. Awarded
    # once per candidate (not per fix instance), so popularity is not amplified. The error
    # locations remain the fallback for clients that send no changed files.
    _changed_names = [Path(str(f).strip().replace("\\", "/")).name
                      for f in (query_changed_files or []) if str(f or "").strip()]
    hydrate_context = dict(recommendation_context or {})
    if _changed_names:
        hydrate_context["file_names"] = _changed_names
    else:
        # No changed files: the error LOCATION is the fallback, and for a Gradle task failure
        # that location is the task's own build script (task4.processes.gradle.kts). A fix that
        # once edited that script then earned the file points on EVERY failure of the task,
        # whatever the cause - offline test: one such fix "won clearly" all 10 same-error queries.
        # Build scripts say where the task is defined, not what broke; real source files in the
        # error location (Foo.java from a compile error) still count.
        hydrate_context["file_names"] = [
            n for n in (hydrate_context.get("file_names") or []) if not _is_build_script_name(n)]
    recommendations = _hydrate_recommendations(
        vector_matches=search_result["vector_matches"],
        project_name=project_name,
        top_k=search_top_k,
        recommendation_context=hydrate_context,
        current_query_signatures=search_result.get("query_signature_hashes"),
        query_task_path=str(normalized_task_path or ""),
        # Artifact source query = the error PLUS the failure-signal lines of the CURRENT
        # build's artifact excerpts (the extension already sends them) - artifact-vs-artifact
        # comparison, the disambiguator when report error texts are identical.
        # The LAST failure lines: a log ends with its failure, while its head is progress
        # chatter ("... 3 warnings") that also passes the marker check.
        query_error_text=(str(query_candidates[0] if query_candidates else "")
                          + ("\n" + "\n".join(_failure_signal_lines(query_artifact_text)[-12:])
                             if str(query_artifact_text or "").strip() else "")),
        # The artifact content ALSO probes the artifact index on its own -
        # error-identical failures are then separated by their artifacts, the exact reason
        # the artifacts are collected.
        query_artifact_text=str(query_artifact_text or ""),
        query_artifact_items=list(query_artifact_excerpts or []),
    )

    logger.info(
        "_run_report_error_recommendation | hydrated_recommendations | project_name=%s | count=%d",
        project_name, len(recommendations),
    )

    # Deterministic relevance layer: same-task first, distinctive wording decides
    # between near-duplicate errors, downvoted fixes sink, identical fixes collapse to one row.
    # Artifact evidence joins the relevance score when the client sent excerpts.
    # File identity precedence: the CHANGED FILES of the current cycle are the true
    # signal — the report's error location is usually the task script (task4.processes.gradle
    # .kts), which would boost fixes to OTHER tasks' scripts instead of the file the developer
    # actually touched (config.xml). Error-location files are only the fallback when the
    # client sent no changed files (older clients / by-message flows).
    _file_signal = list(query_changed_files or []) or [
        n for n in ((recommendation_context or {}).get("file_names") or []) if not _is_build_script_name(n)]
    logger.info(
        "[FLOW-DEBUG] file signal = %r (source=%s)",
        _file_signal[:20],
        "changed_files" if query_changed_files else "error-locations-fallback",
    )
    recommendations = _rerank_recommendations_for_relevance(
        recommendations,
        query_text=msg,
        query_task_path=normalized_task_path,
        query_artifact_text=query_artifact_text,
        query_file_names=_file_signal,
        user_task_path=user_requested_task,
        query_project=project_name,
    )
    # Family representative follows the LIVE task first: prefer the member stored
    # under the task the user is fixing right now; the user-run task is the fallback signal.
    recommendations = _dedupe_recommendations_by_fix(
        recommendations,
        query_task_path=str(normalized_task_path or user_requested_task or ""))

    for i, rec in enumerate(recommendations):
        rec["rank"] = i + 1

    try:
        report_file = _write_recommendation_report_html(
            project_name=project_name,
            query_error=msg,
            recommendations=recommendations,
        )
    except Exception:
        # A full/read-only report dir must never lose a computed
        # recommendation - the report file is a debugging convenience.
        logger.exception("recommendation report write failed (response unaffected)")
        report_file = ""

    gated = _gate_recommendation_results(
        recommendations,
        top_k=top_k,
        track_hits=True,
        project_name=project_name,
        query_signature_hashes=search_result["query_signature_hashes"],
        trace_context={"endpoint": "report-error", "query_error": msg,
                       "task_path": str(normalized_task_path or ""),
                       "changed_files": list(_file_signal or [])[:10],
                       "query_context": {**(recommendation_context or {}),
                                         "requested_task": str(user_requested_task or "")},
                       # The artifact content the QUERY carried must be visible
                       # on the trace, otherwise the two sides cannot be compared.
                       "query_artifacts": [
                           {"name": str((p or {}).get("name") or ""),
                            "text": str((p or {}).get("text") or "")}
                           for p in (query_artifact_excerpts or []) if isinstance(p, dict)
                       ][:5]},
    )

    logger.info(
        "_run_report_error_recommendation | gated_results | project_name=%s | "
        "recommendations_count=%d | weak_count=%d | match_status=%s | confidence_score=%s",
        project_name,
        len(gated.get("recommendations") or []),
        len(gated.get("weak_recommendations") or []),
        gated.get("match_status"),
        gated.get("confidence_score"),
    )

    llm_analysis = ""
    llm_selection: Dict = {}
    llm_token_usage: dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    llm_analysis_status = "ok"
    llm_analysis_message = ""
    document_context: Dict = {
        "success": False,
        "message": "document query is empty",
        "query": msg,
        "project_name": project_name,
        "count": 0,
        "results": [],
        "artifact_context": {"success": False, "count": 0, "results": []},
    }
    context_enrichment: Dict = {
        "enabled": bool(getattr(config, "LLM_ANALYSIS_ENABLED", True)),
        "query": msg,
        "semantic_results_used": 0,
        "artifact_results_used": 0,
        "combined_context": {"semantic_results": [], "artifact_results": []},
        "token_usage": {
            "final_analysis": {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0},
            "total": {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0},
        },
    }

    try:
        # Pass raw metadatas for error_message extraction
        raw_metadatas = (results.get("metadatas") or [[]])[0] if results.get("metadatas") else []
        unified = _build_unified_context_enrichment(
            query_text=msg,
            project_name=project_name,
            errors=errors,
            recommendations=recommendations,  # Full TOP 10 for RRF
            task_path=normalized_task_path,
            copilot_query=copilot_query or preferred_query,
            raw_metadatas=raw_metadatas,
            # The live failure's own artifact content drives the ARTIFACT evidence source,
            # so the LLM selection ranks evidence of THIS root cause.
            query_artifact_text=str(query_artifact_text or ""),
        )
        document_context = unified.get("document_context") or document_context
        context_enrichment = unified.get("context_enrichment") or context_enrichment
        llm_analysis = str(unified.get("llm_analysis") or "")
        llm_selection = unified.get("llm_selection") or {}
        llm_token_usage = unified.get("llm_token_usage") or llm_token_usage
        llm_analysis_status = str(unified.get("llm_analysis_status") or "ok")
        llm_analysis_message = str(unified.get("llm_analysis_message") or "")
    except Exception:
        llm_analysis_status = "error"
        llm_analysis_message = (
            "AI analysis is temporarily unavailable — preparing the analysis failed on the server. "
            "The matched fix and evidence below are still valid."
        )
        logger.exception("_run_report_error_recommendation | unified context enrichment failed for project=%s", project_name)

    # B3 (rely-on-data) — if NO strong match passed the gate, still surface the closest WEAK
    # matches (flagged) instead of showing nothing. We have no ground truth for the fix, so the
    # developer should see the best available data, clearly marked as a low-relevance "possible
    # match" rather than a confident recommendation. Runs BEFORE promotion so the LLM pick can
    # still be promoted among the surfaced weak matches.
    if not (gated.get("recommendations") or []) and (gated.get("weak_recommendations") or []):
        # Weak candidates STAY in weak_recommendations. Promoting them
        # into `recommendations` returned the very candidates the relevance floor / threshold
        # had just rejected - the admin knob had zero effect on what the developer saw, and one
        # rejected candidate even got badged is_closest_match. The extension shows its clear
        # "no sufficiently similar past error" view for this case (match_status below_threshold).
        _weak = gated.get("weak_recommendations") or []
        for _w in _weak:
            if isinstance(_w, dict):
                _w["is_weak_match"] = True
        logger.info("[RECO] no strong match — %d weak candidate(s) kept in weak_recommendations (not shown)", len(_weak))

    # Promote-but-keep-others: whenever the LLM selected a historical fix, move it to rank 1 and
    # badge it so the developer always sees the LLM-chosen correct solution as Candidate 1 — even
    # at low confidence (the badge conveys the certainty). The other matches stay below as fallback,
    # which is exactly what's needed for the "same error, different version/value" case: the picked
    # resolution is on top, the alternative targets remain visible underneath.
    chosen_request_id = str((llm_selection or {}).get("chosen_request_id") or "").strip()
    selection_confidence = str((llm_selection or {}).get("confidence") or "").strip().lower() or "low"
    # LLM re-ranking is switched off by default: it might be useful when everything is
    # almost a close match, but that is a later step, and while it is on ranking defects cannot
    # be isolated. Our own scoring must produce the right order on its own; a re-rank that
    # rescues a wrong ranking hides the defect instead of fixing it. The pick is still COMPUTED
    # and STAMPED on the trace (promoted=false), so agreement between the algorithm and the LLM
    # stays measurable for the close-scores case later. Admin knob llmPromoteEnabled turns
    # promotion back on without a release.
    try:
        _promote_on = bool((_rc_get_config_cached() or {}).get("llmPromoteEnabled"))
    except Exception:
        _promote_on = False
    if chosen_request_id and not _promote_on:
        logger.info(
            "[LLM] pick request_id=%s (confidence=%s) recorded but NOT promoted - "
            "llmPromoteEnabled is off, the algorithm's own order stands",
            chosen_request_id, selection_confidence,
        )
        try:
            from src.utils import recommendation_trace
            recommendation_trace.mark_llm_pick(
                str(gated.get("trace_id") or ""), chosen_request_id,
                confidence=selection_confidence, promoted=False,
                note="recorded only - LLM promotion disabled (algorithm order stands)")
        except Exception:
            logger.exception("llm-pick trace stamp failed (recommendation unaffected)")
        chosen_request_id = ""
    if chosen_request_id:
        recs = gated.get("recommendations") or []
        chosen_idx = next(
            (i for i, r in enumerate(recs)
             if str((r or {}).get("request_id") or "").strip() == chosen_request_id),
            -1,
        )
        if chosen_idx >= 0:
            # Developer verdict outranks the LLM pick (a fix downvoted three
            # times still carried the RECOMMENDED badge at #1): a net-downvoted candidate is
            # never promoted or badged — the deterministic order stands.
            _chosen = recs[chosen_idx]
            _c_up = int(_chosen.get("thumbs_up") or 0)
            _c_down = int(_chosen.get("thumbs_down") or 0)
            if _c_down > _c_up:
                logger.info(
                    "[LLM] pick request_id=%s is net-downvoted by developers (%d up / %d down) — "
                    "promotion and badge withheld", chosen_request_id, _c_up, _c_down,
                )
                _pick_promoted, _pick_note = False, "promotion withheld: net-downvoted by developers"
            else:
                # BADGED IN PLACE, never moved. The order is the final score, descending, and
                # it is the same order the trace stored; moving the pick to Candidate 1 put a
                # lower score above a higher one and made the webview contradict the trace.
                _chosen["is_recommended"] = True
                _chosen["selection_confidence"] = selection_confidence
                _chosen["why_this_fix"] = str((llm_selection or {}).get("why_this_fix") or "").strip()
                logger.info(
                    "[LLM] pick badged at rank %d (order unchanged) | request_id=%s | confidence=%s",
                    chosen_idx + 1, chosen_request_id, selection_confidence,
                )
                _pick_promoted = False
                _pick_note = f"badged at rank {chosen_idx + 1} - order stands (final score, descending)"
            # The trace snapshot was taken BEFORE this promotion — stamp the pick on it so the
            # trace page explains the webview's Candidate 1 instead of contradicting it.
            try:
                from src.utils import recommendation_trace
                recommendation_trace.mark_llm_pick(
                    str(gated.get("trace_id") or ""), chosen_request_id,
                    confidence=selection_confidence, promoted=_pick_promoted, note=_pick_note)
            except Exception:
                logger.exception("llm-pick trace stamp failed (recommendation unaffected)")
        else:
            logger.info(
                "[LLM] pick request_id=%s not in gated candidates — cannot promote (it may have been "
                "below the match threshold)", chosen_request_id,
            )

    # A1 — Guarantee a meaningful top: if no LLM pick was promoted, mark the closest-ranked
    # candidate so Candidate 1 is always clearly the best available match (badged honestly as
    # the closest match, not as an LLM-selected fix).
    _top_recs = gated.get("recommendations") or []
    if _top_recs and isinstance(_top_recs[0], dict) and not _top_recs[0].get("is_recommended"):
        _top_recs[0]["is_closest_match"] = True

    logger.debug(
        "_run_report_error_recommendation | unified context ready | project_name=%s | doc_count=%d | artifact_count=%d | llm_analysis_present=%s",
        project_name,
        len(document_context.get("results") or []) if isinstance(document_context, dict) else 0,
        len(((document_context.get("artifact_context") or {}).get("results") or [])) if isinstance(document_context, dict) else 0,
        bool(llm_analysis),
    )

    logger.debug(
        "_run_report_error_recommendation | returning | project_name=%s | match_status=%s | llm_analysis_present=%s",
        project_name, gated.get("match_status"), bool(llm_analysis),
    )

    # Same-task confirmation from the build report's requestedTasks:
    # ADDITIVE marker only — matching/scoping behavior is unchanged. The normalization here
    # (leading ':' + case) is used purely for this informational comparison, so the UI can show
    # "exact same task — confirmed from the build report" vs "same project, different task".
    def _norm_req_task(value) -> str:
        return str(value or "").strip().lstrip(":").lower()

    _recs = gated.get("recommendations") or []
    _top_rec = _recs[0] if _recs and isinstance(_recs[0], dict) else {}
    _matched_task = str(
        _top_rec.get("task_path") or _top_rec.get("task_name") or _top_rec.get("taskName") or ""
    ).strip()
    # This marker used to claim the report's requestedTasks but compared the
    # FAILING task - the user-run identity was never wired. Now: requested_tasks = what the
    # user actually ran (live from the report, never stored), failing_task = what broke,
    # and the confirmation is genuine - canonical user-run task vs the top candidate's task.
    _user_task_token = _canonical_task_token(user_requested_task)
    _matched_token = _canonical_task_token(_matched_task)
    task_match = {
        "requested_tasks": str(user_requested_task or "") or normalized_task_path,
        "failing_task": normalized_task_path,
        "matched_task": _matched_task,
        "exact_task_confirmed": bool(_user_task_token) and bool(_matched_token)
                                and _user_task_token == _matched_token,
    }

    # The tie check runs over the WHOLE ranked pool, not only the 3 shown: with one generic error
    # message and many stored causes, the right fix can be tied at rank 5 and never be shown.
    decision = _decision_confidence(recommendations or gated.get("recommendations") or [],
                                    _rc_value("ambiguityMargin", 0.0, 0.5))
    if decision.get("ambiguous"):
        try:
            _by_id = {str(r.get("request_id") or ""): r for r in (recommendations or [])}
            _tied = [_by_id[t] for t in decision.get("tied_request_ids") or [] if t in _by_id]
            decision["how_to_choose"] = _disambiguation_clues(_tied)
        except Exception:
            logger.exception("disambiguation clues failed (response unaffected)")
            decision["how_to_choose"] = []
        # The shipped extension renders llm_analysis but not the "decision" field, so the tie and
        # HOW TO CHOOSE are stated at the top of the analysis text - no client release needed.
        llm_analysis = _ambiguity_notice_text(decision) + ("\n\n" + llm_analysis if llm_analysis else "")

    return {
        "status": "success",
        "query_error": msg,
        "matched_ids": search_result["ids"],
        "recommendations": gated["recommendations"],
        "weak_recommendations": gated["weak_recommendations"],
        "match_status": gated["match_status"],
        "confidence_score": gated["confidence_score"],
        "source": gated["source"],
        # The request's trace id - the extension webview shows it so the team can
        # copy it straight into the dashboard Recommendation Trace page.
        "trace_id": str(gated.get("trace_id") or ""),
        "recommendation_report_url": f"/recommendation-report/{quote(report_file)}",
        "errors": results,
        "query_signature_hashes": search_result["query_signature_hashes"],
        "feedback_token": str(uuid.uuid4()),
        "task_match": task_match,
        "llm_analysis": llm_analysis,
        "llm_analysis_status": llm_analysis_status,
        "llm_analysis_message": llm_analysis_message,
        "llm_selection": llm_selection,
        "llm_token_usage": llm_token_usage,
        "document_context": document_context,
        "context_enrichment": context_enrichment,
        # Is rank 1 clearly the answer, or are several different fixes equally supported?
        "decision": decision,
    }


def _decision_confidence(recommendations: List[Dict], margin_threshold: float = 0.05) -> Dict:
    """How decisively rank 1 beats the rest - so a coin-flip is never presented as an answer.

    Two different fixes can be supported by exactly the same evidence: identical error text and
    logs that differ only in what the pipeline treats as noise (a date, a hex address) or not at
    all. The order between them is then a tie-break, not a finding. Every shown candidate whose
    final score is within ``margin_threshold`` (relative) of the top one is "tied" with it; more
    than one tied fix = ambiguous, and the developer is told to compare them.

    status: clear     (rank 1 leads by >= 15%)
            likely    (rank 1 leads, but by less than 15%)
            ambiguous (two or more different fixes within the margin)
            none      (nothing shown)
    Identical fixes were already collapsed by the dedupe, so a tie is always between DIFFERENT
    fixes."""
    shown = [r for r in (recommendations or []) if isinstance(r, dict) and r.get("solution")]
    if not shown:
        return {"status": "none", "ambiguous": False, "margin": None, "tied_request_ids": []}
    top = float(shown[0].get("final_score") or 0.0)
    if len(shown) == 1 or top <= 0:
        return {"status": "clear", "ambiguous": False, "margin": None,
                "tied_request_ids": [str(shown[0].get("request_id") or "")]}
    second = float(shown[1].get("final_score") or 0.0)
    margin = round(max(0.0, (top - second) / top), 4)

    def _evidence(rec: Dict) -> tuple:
        sim = rec.get("similarity")
        art = rec.get("artifact_match_similarity")
        return (float(sim) if isinstance(sim, (int, float)) else None,
                float(art) if isinstance(art, (int, float)) else None)

    def _same_evidence(a: Dict, b: Dict, eps: float = 0.02) -> bool:
        # The final score is dominated by bases every candidate shares (an exact match earns 18
        # flat), so a small score gap can still be a real evidence gap. Tied means the EVIDENCE
        # is equal: the error similarity and the log similarity both within eps.
        (ea, aa), (eb, ab) = _evidence(a), _evidence(b)
        # A log similarity measured only by probing stored logs with the error TEXT (no live log
        # sent) is not evidence about this failure - it must not break a tie.
        if (str(a.get("artifact_evidence_via") or "") != "live_artifact"
                and str(b.get("artifact_evidence_via") or "") != "live_artifact"):
            aa = ab = None
        if (ea is None) != (eb is None) or (aa is None) != (ab is None):
            return False
        if ea is not None and abs(ea - eb) > eps:
            return False
        if aa is not None and abs(aa - ab) > eps:
            return False
        return True

    def _tie_score(rec: Dict) -> float:
        # Points earned from the error text probing stored logs (no live log) are left out: they
        # differ per candidate by chance and would hide a real tie behind a few-percent gap.
        score = float(rec.get("final_score") or 0.0)
        if str(rec.get("artifact_evidence_via") or "") == "error_text":
            score -= float((rec.get("context_components") or {}).get("artifact") or 0.0)
        return score

    anchor = shown[0]
    anchor_score = max(_tie_score(anchor), 1e-9)
    tied = [str(r.get("request_id") or "") for r in shown
            if r is anchor or (abs(anchor_score - _tie_score(r)) / anchor_score <= margin_threshold
                               and _same_evidence(anchor, r))][:10]  # = the scored pool size
    if len(tied) > 1:
        status = "ambiguous"
        reason = (f"{len(tied)} different fixes match this failure almost equally (within "
                  f"{int(round(margin_threshold * 100))}%). Compare them before applying one.")
    elif margin >= 0.15:
        status, reason = "clear", "The first fix leads clearly."
    else:
        status = "likely"
        reason = f"The first fix leads, but only by {int(round(margin * 100))}%."
    return {"status": status, "ambiguous": status == "ambiguous", "margin": margin,
            "tied_request_ids": tied if status == "ambiguous" else tied[:1], "reason": reason}


def _disambiguation_clues(tied: List[Dict]) -> List[Dict]:
    """For fixes tied on the error text: the line of each fix's STORED log that only it has.

    When report.html carries the same generic message for several stored failures ("Error
    parsing input file") and no live log is sent, the server cannot know which failure this is -
    but it knows what each stored failure's log said. That line is what the developer looks for
    in their own log to pick the right fix. Per fix: the failure-signal line whose tokens are the
    most unique to it among the tied fixes (shared scaffolding scores nothing). Source: the fix's
    stored artifact summaries, else its stored error text. A fix with no unique line gets no
    clue (its log does not differ - the fixes are then truly interchangeable)."""
    try:
        texts = _candidate_artifact_texts_for_rerank(tied)
    except Exception:
        texts = {}
    lines_by_id: Dict[str, List[str]] = {}
    for rec in tied:
        rid = str(rec.get("request_id") or "")
        text = str(texts.get(rid) or "") + "\n" + str(rec.get("document") or rec.get("error_message") or "")
        lines = _failure_signal_lines(text) or [ln for ln in text.splitlines() if ln.strip()]
        lines_by_id[rid] = lines
    tokens_by_id = {rid: set().union(*[_distinctive_token_set(ln) for ln in lines]) if lines else set()
                    for rid, lines in lines_by_id.items()}
    try:
        from src.utils.content_fingerprint import clean_volatile_text_for_display
    except Exception:
        clean_volatile_text_for_display = lambda s: s  # noqa: E731
    base = str(getattr(config, "BACKEND_PUBLIC_BASE_URL", "") or "").rstrip("/")
    clues: List[Dict] = []
    for pos, rec in enumerate(tied, start=1):
        rid = str(rec.get("request_id") or "")
        others = set().union(*[t for r, t in tokens_by_id.items() if r != rid]) if len(tokens_by_id) > 1 else set()
        best, best_score = "", 0
        for ln in lines_by_id.get(rid) or []:
            unique = _distinctive_token_set(ln) - others
            if len(unique) > best_score:
                best, best_score = ln, len(unique)
        clue = re.sub(r"\s+", " ", clean_volatile_text_for_display(best)).strip()[:220] if best else ""
        clues.append({
            "rank": pos,
            "request_id": rid,
            "clue": clue,
            "compare_diff_link": f"{base}/diff_view/request/{rid}" if (base and rid) else "",
        })
    return clues


def _ambiguity_notice_text(decision: Dict) -> str:
    """The tie + how to choose, as plain text for the analysis section the extension renders."""
    clues = [c for c in (decision.get("how_to_choose") or []) if c.get("clue")]
    head = f"⚖️ {decision.get('reason') or 'Several fixes match equally well.'}"
    if not clues:
        return head
    out = [head, "", "The error message is the same for all of them - the difference is in the build "
           "log. Find which of these lines your log contains:"]
    for c in clues:
        out.append(f"  {c['rank']}. \"{c['clue']}\" -> fix {c['request_id'][:8]}"
                   + (f" ({c['compare_diff_link']})" if c.get("compare_diff_link") else ""))
    return "\n".join(out)


def _dominant_task_path(errors: List[Dict]) -> str:
    """Return the most frequent non-empty task_path across all errors."""
    from collections import Counter
    counts: Counter = Counter(
        str(err.get("task_path") or "").strip()
        for err in errors
        if isinstance(err, dict) and str(err.get("task_path") or "").strip()
    )
    return counts.most_common(1)[0][0] if counts else ""


def handle_report_errors(html: str, project_name: str, query_text: str = "", task_path: str = "", copilot_query: str = "", artifact_text: str = "", report_format: str = "", changed_files: List[str] | None = None, user_task: str = "", artifact_excerpts: List[Dict] | None = None, requested_scope: str = "") -> Dict:
    try:
        # TD5 GBE-parity: the uploaded "report" may be a TD5 build log instead of a
        # Gradle report.html — explicit report_format wins; auto-detect covers older clients
        # ([ERR!] markers and no HTML shell = a TD5 log). Everything downstream is identical.
        content = str(html or "")
        fmt = str(report_format or "").strip().lower()
        if fmt == "td5-log" or (not fmt and "[ERR!]" in content and "<html" not in content[:2000].lower()):
            errors = extract_errors_from_td5_log(content)
        else:
            errors = extract_errors_from_report_html(content)
        # Auto-extract task_path from errors when not supplied by the caller.
        if not task_path:
            task_path = _dominant_task_path(errors)
        # The user-run task - live-only identity, never stored. The extension's own
        # session value (what the user's VS Code actually ran) wins; the report's
        # requestedTasks is the fallback for older extensions and API callers.
        user_requested_task = str(user_task or "").strip() or _requested_task_from_report_html(html)
        # [RECO-DEBUG] Every extracted error, verbatim head — the anchor is built from these,
        # so a noise anchor (progress lines instead of the failure) is visible RIGHT here.
        # Locations are strings on GBE reports and dicts on TD5 — handle both, and NEVER let
        # debug logging fail the request (first live run 500'd on loc.get — logging bug).
        try:
            logger.info("[RECO-DEBUG] extracted %d error(s) from the report | dominant_task_path=%r",
                        len(errors or []), task_path)
            for _i, _e in enumerate(errors or []):
                _locs = []
                for _loc in ((_e or {}).get("locations") or [])[:5]:
                    if isinstance(_loc, dict):
                        _locs.append(str(_loc.get("file_path") or _loc.get("filePath") or _loc.get("path") or ""))
                    else:
                        _locs.append(str(_loc or ""))
                logger.info(
                    "[RECO-DEBUG] error[%d] severity=%s task_path=%r locations=%r message(%d chars): %r",
                    _i,
                    (_e or {}).get("severity"),
                    (_e or {}).get("task_path"),
                    _locs,
                    len(str((_e or {}).get("message") or "")),
                    str((_e or {}).get("message") or "")[:500],
                )
        except Exception:
            logger.exception("[RECO-DEBUG] error trace logging failed (request unaffected)")
        result = _run_report_error_recommendation(
            project_name=project_name,
            errors=errors,
            requested_scope=requested_scope,
            preferred_query=query_text,
            task_path=task_path,
            copilot_query=copilot_query,
            query_artifact_text=artifact_text,
            user_requested_task=user_requested_task,
            query_artifact_excerpts=artifact_excerpts,
            query_changed_files=list(changed_files or []),
        )
        
        # Store token usage for tracking
        if result.get("status") == "success":
            token_usage = result.get("llm_token_usage") or {}
            if token_usage.get("total_tokens", 0) > 0:
                try:
                    from src.utils import project_details
                    recommendations = result.get("recommendations") or result.get("weak_recommendations") or []
                    related_request_ids = _extract_recommendation_request_ids(recommendations)
                    request_id = related_request_ids[0] if related_request_ids else ""
                    if result.get("trace_id"):
                        related_request_ids.append(str(result["trace_id"]))
                    
                    project_details.save_token_usage(
                        project_name=project_name,
                        request_id=request_id,
                        related_request_ids=related_request_ids,
                        prompt_tokens=int(token_usage.get("prompt_tokens", 0) or 0),
                        output_tokens=int(token_usage.get("output_tokens", 0) or 0),
                        total_tokens=int(token_usage.get("total_tokens", 0) or 0),
                        operation_type="recommendation",
                    )
                except Exception as e:
                    logger.warning("Failed to save token usage for project=%s: %s", project_name, str(e))
        
        return result

    except Exception as e:
        traceback.print_exc()
        return {
            "status": "error",
            "error": str(e)
        }


def handle_report_errors_by_message(project_name: str, error_message: str, context_payload: Dict | None = None) -> Dict:
    try:
        message = str(error_message or "").strip()
        if not message:
            return {"status": "error", "error": "error_message is required"}

        pseudo_errors: List[Dict[str, object]] = [
            {
                "severity": "ERROR",
                "message": message,
                "locations": [],
            }
        ]
        preferred_query = ""
        task_path = ""
        copilot_query = ""
        requested_scope = ""
        if isinstance(context_payload, dict):
            preferred_query = str(context_payload.get("query_text") or "").strip()
            requested_scope = str(context_payload.get("scope")
                                  or context_payload.get("requested_scope") or "").strip()
            task_path = str(context_payload.get("task_path") or "").strip()
            copilot_query = str(context_payload.get("copilot_query") or "").strip()
        if not preferred_query:
            preferred_query = message
        result = _run_report_error_recommendation(
            project_name=project_name,
            errors=pseudo_errors,
            requested_scope=requested_scope,
            preferred_query=preferred_query,
            task_path=task_path,
            copilot_query=copilot_query,
        )
        
        # Store token usage for tracking
        if result.get("status") == "success":
            token_usage = result.get("llm_token_usage") or {}
            if token_usage.get("total_tokens", 0) > 0:
                try:
                    from src.utils import project_details
                    recommendations = result.get("recommendations") or result.get("weak_recommendations") or []
                    related_request_ids = _extract_recommendation_request_ids(recommendations)
                    request_id = related_request_ids[0] if related_request_ids else ""
                    if result.get("trace_id"):
                        related_request_ids.append(str(result["trace_id"]))
                    
                    project_details.save_token_usage(
                        project_name=project_name,
                        request_id=request_id,
                        related_request_ids=related_request_ids,
                        prompt_tokens=int(token_usage.get("prompt_tokens", 0) or 0),
                        output_tokens=int(token_usage.get("output_tokens", 0) or 0),
                        total_tokens=int(token_usage.get("total_tokens", 0) or 0),
                        operation_type="recommendation",
                    )
                except Exception as e:
                    logger.warning("Failed to save token usage for project=%s: %s", project_name, str(e))
        
        return result
    except Exception as e:
        traceback.print_exc()
        return {"status": "error", "error": str(e)}

def handle_get_files_by_batch(batch_id: str) -> dict:
    files = get_files_by_batch_id(batch_id)

    if not files:
        return {"error": "No files found"}

    return {
        "batch_id": batch_id,
        "files": [f.replace(f"{batch_id}-", "", 1) for f in files]
    }



def handle_create_index() -> dict:
    index_response = create_example_index_with_embedding(
        index_name=config.INDEX_NAME
    )
    return {
        "message": "Index created successfully",
        "index_response": index_response
    }


def _normalize_diff_text(value) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        if all(isinstance(v, str) for v in value):
            return "\n".join(value)
        return json.dumps(value, ensure_ascii=False, indent=2)
    if isinstance(value, dict):
        content = value.get("content")
        if isinstance(content, str):
            return content
        return json.dumps(value, ensure_ascii=False, indent=2)
    return str(value)


def _extract_diff_files_from_payload(payload: Dict, fallback_file_name: str = "payload.json") -> List[Dict]:
    diff_files: List[Dict] = []
    seen = set()

    def _add(file_name: str, file_path: str, before_text: str, after_text: str):
        key = (file_name or "", file_path or "", before_text or "", after_text or "")
        if key in seen:
            return
        seen.add(key)
        diff_files.append(
            {
                "file_name": file_name or fallback_file_name,
                "file_path": file_path or "",
                "before_file_text": before_text or "",
                "after_file_text": after_text or "",
            }
        )

    def _walk(node, inherited_name: str = "", inherited_path: str = ""):
        if isinstance(node, dict):
            file_name = node.get("fileName") or node.get("file_name") or inherited_name or fallback_file_name
            file_path = node.get("filePath") or node.get("path") or inherited_path or ""

            has_snapshot = "snapshotBefore" in node or "snapshotAfter" in node
            has_before_after = (
                "before" in node
                or "after" in node
                or "beforeText" in node
                or "afterText" in node
            )
            has_changes = "changes" in node
            is_leaf = False
            if has_snapshot or has_before_after or has_changes:
                before_source = node.get("snapshotBefore")
                if before_source is None:
                    before_source = node.get("before")
                if before_source is None:
                    before_source = node.get("beforeText")
                before_text = _normalize_diff_text(before_source)

                after_source = node.get("snapshotAfter")
                if after_source is None:
                    after_source = node.get("after")
                if after_source is None:
                    after_source = node.get("afterText")
                if after_source is None and has_changes:
                    after_source = node.get("changes")
                after_text = _normalize_diff_text(after_source)
                if before_text or after_text:
                    _add(file_name, file_path, before_text, after_text)
                    # Node has real snapshot content — treat it as a leaf and skip
                    # recursing into solution/all_changes/files. Those are change-metadata
                    # sub-arrays, not separate diffable files, and recursing into them
                    # produces a duplicate sidebar entry from the nested "changes" key.
                    is_leaf = has_snapshot or has_before_after

            if not is_leaf:
                for key in ("solution", "all_changes", "files"):
                    value = node.get(key)
                    if isinstance(value, list):
                        for item in value:
                            _walk(item, file_name, file_path)

        elif isinstance(node, list):
            for item in node:
                _walk(item, inherited_name, inherited_path)

    _walk(payload, fallback_file_name, "")

    if not diff_files:
        _add(fallback_file_name, "", "", _normalize_diff_text(payload))

    return diff_files


def handle_show_diff_page_by_request(request_id: str) -> Dict:
    archived_refs = list_payload_archives_for_request(request_id)
    if not archived_refs:
        return {
            "message": "Show diff page",
            "request_id": request_id,
            "file_count": 0,
            "diff_files": [],
        }

    # Keep only archive rows that actually point to S3 objects.
    archive_rows = [
        row for row in archived_refs
        if isinstance(row, dict) and row.get("s3_key")
    ]

    if not archive_rows:
        return {
            "message": "Show diff page",
            "request_id": request_id,
            "file_count": 0,
            "diff_files": [],
        }

    sorted_refs = sorted(
        archive_rows,
        key=lambda item: (
            item.get("created_date") or "",
            item.get("file_name") or "",
            item.get("s3_key") or "",
        ),
    )

    # De-duplicate by object key while preserving order.
    ordered_refs = []
    seen_keys = set()
    for ref in sorted_refs:
        s3_key = ref.get("s3_key")
        if s3_key in seen_keys:
            continue
        seen_keys.add(s3_key)
        ordered_refs.append(ref)

    diff_files: List[Dict] = []
    for ref in ordered_refs:
        fallback_name = (
            ref.get("file_name")
            or ref.get("file_key_name")
            or "payload.json"
        )

        try:
            payload = download_payload_zip(
                s3_key=ref["s3_key"],
                expected_sha256=ref.get("sha256"),
            )
        except Exception as exc:
            diff_files.append(
                {
                    "file_name": fallback_name,
                    "file_path": "",
                    "before_file_text": "",
                    "after_file_text": (
                        f"Unable to load archived payload from S3 key '{ref.get('s3_key')}': {exc}"
                    ),
                    "event_type": None,
                }
            )
            continue

        event_type: str | None = None
        if isinstance(payload, dict):
            event_type = payload.get("eventType") or payload.get("event_type") or None

        for diff_file in _extract_diff_files_from_payload(
            payload=payload,
            fallback_file_name=fallback_name,
        ):
            diff_file["event_type"] = event_type
            diff_files.append(diff_file)

    # Storage keeps every content-version of a file per request (version-add, storage proposal
    # 2026-07), so one request can hold several archives whose VISIBLE diff is identical (the
    # re-stored payload differed only in metadata: attached errors, solution subset) — or several
    # real successive saves of the same file. The extractor's dedup is per archive only; without
    # a cross-archive pass the sidebar shows identical-looking duplicate rows. Collapse identical
    # visible diffs, then number the remaining real versions chronologically (archive order).
    # The FILE PATH is deliberately NOT part of either key: the same change
    # uploaded from different workspaces (D:\AI_Build vs D:\UAT_PROJECTS) is one change, not
    # "(change 2)/(change 3)" rows — content decides identity, not where the file lived.
    unique_rows: List[Dict] = []
    seen_visible = set()
    for row in diff_files:
        visible_key = (
            row.get("file_name") or "",
            row.get("before_file_text") or "",
            row.get("after_file_text") or "",
        )
        if visible_key in seen_visible:
            continue
        seen_visible.add(visible_key)
        unique_rows.append(row)

    version_counter: Dict = {}
    for row in unique_rows:
        file_key = row.get("file_name") or ""
        version_counter[file_key] = version_counter.get(file_key, 0) + 1
        row["version"] = version_counter[file_key]
    for row in unique_rows:
        row["versions_total"] = version_counter[row.get("file_name") or ""]
    diff_files = unique_rows

    return {
        "message": "Show diff page",
        "request_id": request_id,
        "file_count": len(diff_files),
        "diff_files": diff_files,
    }


# UI dev spec (Diff Viewer module): event_type must be one of added / modified / deleted / renamed.
_DIFF_EVENT_TYPES = {
    "add": "added", "added": "added", "create": "added", "created": "added", "new": "added",
    "change": "modified", "changed": "modified", "modify": "modified", "modified": "modified",
    "update": "modified", "updated": "modified",
    "unlink": "deleted", "delete": "deleted", "deleted": "deleted", "remove": "deleted",
    "removed": "deleted",
    "rename": "renamed", "renamed": "renamed", "move": "renamed", "moved": "renamed",
}


def _normalize_diff_event_type(value, before_text: str, after_text: str) -> str:
    """Map stored eventType onto the 4 supported values; infer from content when missing."""
    mapped = _DIFF_EVENT_TYPES.get(str(value or "").strip().lower())
    if mapped:
        return mapped
    if before_text and not after_text:
        return "deleted"
    if after_text and not before_text:
        return "added"
    return "modified"


def handle_difference_viewer(request_id: str) -> Dict | None:
    """Dashboard Diff Viewer module: GET /difference-viewer/<request_id>.

    Thin JSON view over handle_show_diff_page_by_request (the same data the /diff_view HTML page
    renders) — before/after text verbatim (line breaks / tabs / indentation preserved), event_type
    normalized to added|modified|deleted|renamed. Returns None when the request has no archived
    diff data (route answers 404). Frontend computes the line-by-line diff itself."""
    base = handle_show_diff_page_by_request(request_id)
    raw_files = base.get("diff_files") if isinstance(base, dict) else []
    if not raw_files:
        return None

    normalized_rows = []
    for row in raw_files:
        if not isinstance(row, dict):
            continue
        before_text = str(row.get("before_file_text") or "")
        after_text = str(row.get("after_file_text") or "")
        normalized_rows.append(
            {
                "file_name": str(row.get("file_name") or ""),
                "file_path": str(row.get("file_path") or ""),
                "event_type": _normalize_diff_event_type(row.get("event_type"), before_text, after_text),
                "before_file_text": before_text,
                "after_file_text": after_text,
                "version": int(row.get("version") or 1),
                "versions_total": int(row.get("versions_total") or 1),
            }
        )

    # The compare shows ONE
    # row per file — the LATEST change, i.e. the current state against its IMMEDIATE previous
    # state. Earlier break→fix cycles of the same file are not separate sidebar rows; they ride
    # along additively in previous_versions (oldest first) so the UI can offer a history view
    # without another API change. Nothing is lost — only the presentation collapses.
    grouped: Dict[str, List[Dict]] = {}
    order: List[str] = []
    for row in normalized_rows:
        name = row["file_name"]
        if name not in grouped:
            grouped[name] = []
            order.append(name)
        grouped[name].append(row)

    diff_files = []
    for name in order:
        versions = sorted(grouped[name], key=lambda r: r["version"])
        latest = versions[-1]
        latest["previous_versions"] = [
            {
                "version": v["version"],
                "event_type": v["event_type"],
                "before_file_text": v["before_file_text"],
                "after_file_text": v["after_file_text"],
            }
            for v in versions[:-1]
        ]
        diff_files.append(latest)

    return {
        "request_id": str(request_id or ""),
        "file_count": len(diff_files),
        "diff_files": diff_files,
    }


def handle_show_diff_page(vector_id: str) -> Dict:
    solution_id = get_solution_id(vector_id)
    if not solution_id:
        return {
            "message": "Show diff page",
            "solution_id": None,
            "diff_files": [],
        }

    diff_files = get_diff_files(solution_id)

    return {
        "message": "Show diff page",
        "solution_id": solution_id,
        "diff_files": diff_files,
    }


def _locate_report_html() -> tuple[str, str, str]:
    """
    Find report.html under repository build directory.
    Returns (repo_root, repo_name_lower, report_file_path).
    """
    cwd = Path.cwd()
    repo_root = cwd
    current = cwd
    while current != current.parent:
        if (current / ".git").exists():
            repo_root = current
            break
        current = current.parent

    build_dir = repo_root / "build"
    if not build_dir.exists():
        raise FileNotFoundError("Build folder not found in repository root.")

    report_file = next(build_dir.rglob("report.html"), None)
    if not report_file:
        raise FileNotFoundError("report.html not found under build directory.")

    repo_name_lower = repo_root.name.lower().strip()
    if not repo_name_lower:
        raise ValueError("Unable to resolve repository name.")

    return str(repo_root), repo_name_lower, str(report_file)


def _parse_change_for_find_replace(change: str) -> tuple[str, str]:
    """
    Deterministic parsing only from API-provided change strings.
    """
    text = str(change or "").strip()
    if text.startswith("[+] "):
        return "<not present>", text[4:].strip()
    if text.startswith("[-] "):
        return text[4:].strip(), "<removed>"
    if text.startswith("[MOD] "):
        value = text[6:].strip()
        return value, value
    return text, text


def _format_copilot_output(api_result: Dict) -> str:
    match_status = str(api_result.get("match_status") or "").strip().lower()
    recommendations = api_result.get("recommendations") or []
    llm_analysis_in = str(api_result.get("llm_analysis") or "").strip()
    logger.debug(
        "_format_copilot_output | start | match_status=%s | recommendations_count=%d | llm_analysis_present=%s | llm_analysis_chars=%d",
        match_status,
        len(recommendations) if isinstance(recommendations, list) else 0,
        bool(llm_analysis_in),
        len(llm_analysis_in),
    )
    # below_threshold belongs here: _evaluate_recommendation_strength returns only "strong",
    # "below_threshold" or "none", and nothing anywhere assigns "weak". Without it, a gate decision
    # of below_threshold - candidates existed but none scored high enough - fell through and handed
    # Copilot the ordinary "Solution 1" text, presenting a weak match as a real answer. The panel
    # was never affected; it reads is_weak_match rather than this comparison. "weak" is kept so an
    # older caller passing it keeps working.
    if match_status in {"weak", "below_threshold", "none"}:
        logger.debug("_format_copilot_output | match_status=%s | returning no-match template", match_status)
        return (
            "## Solution 1\n"
            "- Match: No strong historical recommendation found\n"
            "- Compare changes: N/A\n"
            "- Required changes:\n"
            "1. File: `N/A`\n"
            "2. Find: `N/A`\n"
            "3. Replace: `N/A`\n"
            "- Validation:\n"
            "1. Re-check current error context\n"
            "2. Re-run build or refresh report.html\n"
            "3. Retry recommendation after exact error is available\n"
        )

    if not isinstance(recommendations, list) or not recommendations:
        logger.debug("_format_copilot_output | no recommendations | returning not-found template")
        return (
            "## Solution 1\n"
            "- Match: Not found\n"
            "- Compare changes: N/A\n"
            "- Required changes:\n"
            "1. File: `N/A`\n"
            "2. Find: `N/A`\n"
            "3. Replace: `N/A`\n"
            "- Validation:\n"
            "1. Re-run build\n"
            "2. Confirm report.html has no ERROR\n"
        )

    binary_groups = (
        api_result.get("recommendedFiles")
        or api_result.get("recommended_files")
        or []
    )
    binaries_by_batch = {}
    if isinstance(binary_groups, list):
        for item in binary_groups:
            if not isinstance(item, dict):
                continue
            b = item.get("batch_id")
            if not b:
                continue
            binaries_by_batch.setdefault(str(b), []).append(item)

    blocks: List[str] = []
    for idx, rec in enumerate(recommendations, start=1):
        if not isinstance(rec, dict):
            continue

        compare_link = rec.get("compare_diff_link")
        if not compare_link and rec.get("request_id"):
            compare_link = _build_compare_diff_link(rec.get("request_id"), None)
        if not compare_link and rec.get("vector_id"):
            compare_link = _build_compare_diff_link(None, rec.get("vector_id"))

        match_type = str(rec.get("match_type") or "semantic").strip().lower()
        match_label = "Exact signature match" if match_type == "exact" else "Semantic match"
        lines = [f"## Solution {idx}", f"- Match: {match_label}"]
        if compare_link:
            lines.append(f"- [Compare diff link]({compare_link})")
        else:
            lines.append("- Compare changes: N/A")
        lines.append("- Required changes:")

        solution_items = rec.get("solution") or []
        step = 1
        if isinstance(solution_items, list) and solution_items:
            for item in solution_items:
                if not isinstance(item, dict):
                    continue
                file_path = item.get("filePath") or item.get("fileName") or "N/A"
                changes = item.get("changes") or []
                if not isinstance(changes, list) or not changes:
                    changes = ["[MOD] No explicit change lines provided by API"]
                for change in changes:
                    find_v, replace_v = _parse_change_for_find_replace(str(change))
                    lines.extend(
                        [
                            f"{step}. File: `{file_path}`",
                            f"{step}. Find: `{find_v}`",
                            f"{step}. Replace: `{replace_v}`",
                        ]
                    )
                    step += 1
        else:
            lines.extend(
                [
                    "1. File: `N/A`",
                    "1. Find: `N/A`",
                    "1. Replace: `N/A`",
                ]
            )

        batch_id = rec.get("batch_id") or rec.get("request_id")
        binaries = binaries_by_batch.get(str(batch_id), []) if batch_id else []
        if binaries:
            lines.append("- Binary changes:")
            for bidx, b in enumerate(binaries, start=step):
                file_name = b.get("file_name") or b.get("name") or "unknown.bin"
                if str(file_name).startswith("DELETED_"):
                    lines.append(f"{bidx}. Remove binary: `{file_name}`")
                else:
                    lines.append(f"{bidx}. Add binary: `{file_name}`")
                    lines.append(
                        f"{bidx}. Download: {config.BACKEND_PUBLIC_BASE_URL}/download-files/{batch_id}?file={file_name}"
                    )

        lines.extend(
            [
                "- Validation:",
                "1. Re-run build",
                "2. Confirm report.html clean",
                "3. Confirm build success",
            ]
        )

        blocks.append("\n".join(lines))
        logger.debug(
            "_format_copilot_output | formatted solution block | idx=%d | match_type=%s | compare_link_present=%s",
            idx, str(rec.get("match_type") or "semantic"), bool(compare_link),
        )

    output = "\n\n".join(blocks)
    llm_analysis = str(api_result.get("llm_analysis") or "").strip()
    if llm_analysis:
        output += f"\n\n---\n\n## LLM Analysis\n\n{llm_analysis}"
        logger.debug(
            "_format_copilot_output | LLM analysis section appended | llm_analysis_chars=%d | total_output_chars=%d",
            len(llm_analysis), len(output),
        )
    logger.debug(
        "_format_copilot_output | done | blocks_count=%d | total_chars=%d",
        len(blocks), len(output),
    )
    return output


def _safe_project_name(value: str) -> str:
    return re.sub(r"[^a-z0-9._-]+", "-", (value or "").strip().lower()).strip("-")


def handle_copilot_session_start(data: Dict) -> Dict:
    payload = data or {}
    project_name = _safe_project_name(str(payload.get("project_name") or ""))
    error_message = str(payload.get("error_message") or "").strip()
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    client_id = str(payload.get("client_id") or "global").strip() or "global"
    ttl_hours = int(payload.get("ttl_hours") or 24)
    file_path = str(payload.get("filePath") or payload.get("path") or "").strip()
    task_path = str(payload.get("taskPath") or payload.get("taskName") or payload.get("requestedTasks") or "").strip()
    local_patch_contexts = _extract_local_patch_contexts(payload)
    workspace_id = str(payload.get("workspace_id") or "").strip()
    build_context_id = str(payload.get("build_context_id") or "").strip()
    report_version = int(payload.get("report_version") or 0)
    error_signature = _signature_hash_from_text(error_message)

    if not project_name:
        raise ValueError("project_name is required")
    if not error_message:
        raise ValueError("error_message is required")

    current = get_active_copilot_error_session(
        project_name=project_name,
        actor_id=actor_id,
        client_id=client_id,
    )
    current_signature = str((current or {}).get("error_signature") or "").strip()
    request_id = str(payload.get("uuid") or payload.get("request_id") or "").strip()
    if not request_id:
        current_request_id = str((current or {}).get("request_id") or "").strip()
        if current and current_request_id and current_signature == error_signature:
            request_id = current_request_id
        else:
            request_id = str(uuid.uuid4())

    s3_key = ""
    if current_signature and current_signature == error_signature:
        s3_key = str((current or {}).get("s3_key") or "").strip()
    if not s3_key and error_signature:
        archive_idx = get_copilot_error_archive_index(
            project_name=project_name,
            error_signature=error_signature,
        )
        s3_key = str((archive_idx or {}).get("s3_key") or "").strip()
    session = touch_copilot_error_session(
        project_name=project_name,
        request_id=request_id,
        error_message=error_message,
        error_signature=error_signature,
        s3_key=s3_key,
        actor_id=actor_id,
        client_id=client_id,
        file_path=file_path,
        task_path=task_path,
        local_patch_contexts=local_patch_contexts,
        workspace_id=workspace_id,
        build_context_id=build_context_id,
        report_version=report_version,
        ttl_hours=ttl_hours,
        # The task the USER ran when this failed, kept for the success check
        # below. Read straight from the client's requestedTasks - taskPath/taskName are the
        # FAILING task, which is a different thing and would make the comparison meaningless.
        requested_task=str(payload.get("requestedTasks") or payload.get("requested_task") or "").strip(),
    )

    idempotency_key = f"{project_name}|{client_id}|{error_signature}|{request_id}"
    if not s3_key:
        _enqueue_copilot_archive(
            idempotency_key=idempotency_key,
            project_name=project_name,
            request_id=request_id,
            error_message=error_message,
            actor_id=actor_id,
            client_id=client_id,
            ttl_hours=ttl_hours,
        )

    archive_info = {
        "status": "reused" if s3_key else "queued",
        "request_id": request_id,
        "project_name": project_name,
        "s3_key": s3_key or None,
        "idempotency_key": idempotency_key,
    }
    return {
        "status": True,
        "project_name": project_name,
        "uuid": request_id,
        "request_id": request_id,
        "archive": archive_info,
        "session": session,
    }


def handle_get_active_copilot_session(data: Dict) -> Dict:
    payload = data or {}
    project_name = _safe_project_name(str(payload.get("project_name") or ""))
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    client_id = str(payload.get("client_id") or "global").strip() or "global"
    workspace_id = str(payload.get("workspace_id") or "").strip()
    if not project_name:
        raise ValueError("project_name is required")

    session = None
    if workspace_id:
        session = get_active_copilot_error_context(
            project_name=project_name,
            actor_id=actor_id,
            client_id=client_id,
            workspace_id=workspace_id,
        )
    if not session:
        session = get_active_copilot_error_session(
            project_name=project_name,
            actor_id=actor_id,
            client_id=client_id,
        )
    return {
        "status": bool(session),
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "workspace_id": workspace_id or (session or {}).get("workspace_id"),
        "session": session,
    }


def _active_session_from_snapshot(
    project_name: str,
    actor_id: str,
    client_id: str,
    workspace_id: str,
    snap_meta: Dict | None,
) -> Dict | None:
    snapshot_path = str((snap_meta or {}).get("path") or "")
    if not snapshot_path or not os.path.exists(snapshot_path):
        return None
    try:
        report_bytes = Path(snapshot_path).read_bytes()
        snapshot_error = _primary_error_from_report_bytes(report_bytes)
    except Exception:
        logger.exception(
            "Failed reading active report snapshot for project=%s actor=%s client=%s",
            project_name,
            actor_id,
            client_id,
        )
        return None
    if not snapshot_error:
        return None

    snapshot_signature = _signature_hash_from_text(snapshot_error)
    current = handle_get_active_copilot_session(
        {
            "project_name": project_name,
            "actor_id": actor_id,
            "client_id": client_id,
            "workspace_id": workspace_id,
        }
    )
    current_session = (current or {}).get("session") or {}
    current_signature = str(current_session.get("error_signature") or "").strip()
    current_request_id = str(current_session.get("request_id") or "").strip()

    refreshed = touch_copilot_error_session(
        project_name=project_name,
        request_id=current_request_id if current_signature and current_signature == snapshot_signature and current_request_id else str(uuid.uuid4()),
        error_message=snapshot_error,
        error_signature=snapshot_signature,
        s3_key="",
        actor_id=actor_id,
        client_id=client_id,
        file_path=str(current_session.get("file_path") or ""),
        task_path=str(current_session.get("task_path") or ""),
        local_patch_contexts=[],
        workspace_id=workspace_id,
        build_context_id=str((snap_meta or {}).get("build_context_id") or current_session.get("build_context_id") or ""),
        report_version=int((snap_meta or {}).get("report_version") or current_session.get("report_version") or 0),
        ttl_hours=24,
    )
    return {
        "status": True,
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "workspace_id": workspace_id or str((refreshed or {}).get("workspace_id") or ""),
        "session": refreshed,
    }


def handle_get_active_copilot_session_auto(data: Dict) -> Dict:
    payload = data or {}
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    project_name = _safe_project_name(str(payload.get("project_name") or ""))
    client_id = str(payload.get("client_id") or "").strip()
    workspace_id = str(payload.get("workspace_id") or "").strip()
    if project_name and client_id and workspace_id:
        snap_meta = _lookup_live_snapshot_meta(project_name, actor_id, client_id, workspace_id)
        from_snapshot = _active_session_from_snapshot(
            project_name=project_name,
            actor_id=actor_id,
            client_id=client_id,
            workspace_id=workspace_id,
            snap_meta=snap_meta,
        )
        if from_snapshot:
            return from_snapshot

    return {
        "status": False,
        "actor_id": actor_id,
        "client_id": client_id or None,
        "workspace_id": workspace_id or None,
        "project_name": project_name or None,
        "session": None,
    }


def handle_copilot_recommend_by_session(data: Dict) -> Dict:
    payload = data or {}
    active = handle_get_active_copilot_session(payload)
    if not active.get("status"):
        return {
            "status": "error",
            "error": "active copilot session not found",
            "recommendations": [],
        }

    session = active.get("session") or {}
    recommendation_payload = {
        "projectName": active.get("project_name"),
        "error_message": session.get("error_message") or "",
        "filePath": session.get("file_path") or "",
        "taskPath": session.get("task_path") or "",
        "local_patch_contexts": session.get("local_patch_contexts") or [],
    }
    rec = handle_recommendations(recommendation_payload)
    visible_recommendations = list((rec or {}).get("recommendations") or [])
    if visible_recommendations:
        try:
            request_ids = _extract_recommendation_request_ids(visible_recommendations)
            save_active_recommendation_context(
                project_name=str(active.get("project_name") or ""),
                actor_id=str(active.get("actor_id") or session.get("actor_id") or "global"),
                client_id=str(active.get("client_id") or session.get("client_id") or "global"),
                workspace_id=str(active.get("workspace_id") or session.get("workspace_id") or ""),
                request_ids=request_ids,
                primary_request_id=request_ids[0] if request_ids else "",
            )
        except Exception:
            logger.exception("Failed to persist active recommendation context for session flow")
    return {
        "status": "success" if rec.get("success") else "error",
        "request_id": session.get("request_id"),
        "s3_key": session.get("s3_key"),
        "result": rec,
        "formatted_output": rec.get("formatted_output") or _format_copilot_output(rec),
    }


def handle_copilot_recommend_by_active_auto(data: Dict) -> Dict:
    payload = data or {}
    active = handle_get_active_copilot_session_auto(payload)
    if not active.get("status"):
        return {
            "status": "error",
            "error": "active copilot session not found",
            "result": [],
        }

    session = active.get("session") or {}
    project_name = _safe_project_name(str(active.get("project_name") or session.get("project_name") or ""))
    request_id = str(session.get("request_id") or "").strip()
    s3_key = str(session.get("s3_key") or "").strip()
    error_message = str(session.get("error_message") or "").strip()
    resolved_s3_key = s3_key

    if not project_name:
        return {
            "status": "error",
            "error": "project_name is missing in active session",
            "result": [],
        }

    if not error_message:
        return {
            "status": "error",
            "error": "error_message missing in active session/archive payload",
            "request_id": request_id,
            "s3_key": resolved_s3_key,
            "result": [],
        }

    rec_result: Dict = {}
    actor_for_snapshot = str(active.get("actor_id") or session.get("actor_id") or "global")
    client_for_snapshot = str(active.get("client_id") or session.get("client_id") or "global")
    workspace_for_snapshot = str(active.get("workspace_id") or session.get("workspace_id") or "").strip()
    snapshot_path = ""
    snapshot_error = ""
    snap = _lookup_live_snapshot_meta(project_name, actor_for_snapshot, client_for_snapshot, workspace_for_snapshot)
    snapshot_path = str(snap.get("path") or "")

    # Prefer full report.html parsing path (same as Phase-1 recommendation behavior)
    # because it produces better query candidates than plain error-message-only matching.
    if snapshot_path and os.path.exists(snapshot_path):
        try:
            with open(snapshot_path, "rb") as fp:
                report_bytes = fp.read()
                html_text = report_bytes.decode("utf-8", errors="ignore")
            snapshot_error = _primary_error_from_report_bytes(report_bytes)
            if snapshot_error:
                error_message = snapshot_error
                snapshot_signature = _signature_hash_from_text(snapshot_error)
                session_signature = str(session.get("error_signature") or "").strip()
                if snapshot_signature and snapshot_signature != session_signature:
                    try:
                        refreshed_session = touch_copilot_error_session(
                            project_name=project_name,
                            request_id=str(uuid.uuid4()),
                            error_message=snapshot_error,
                            error_signature=snapshot_signature,
                            s3_key="",
                            actor_id=actor_for_snapshot,
                            client_id=client_for_snapshot,
                            file_path=str(session.get("file_path") or ""),
                            task_path=str(session.get("task_path") or ""),
                            local_patch_contexts=[],
                            workspace_id=workspace_for_snapshot,
                            build_context_id=str(snap.get("build_context_id") or session.get("build_context_id") or ""),
                            report_version=int(snap.get("report_version") or session.get("report_version") or 0),
                            ttl_hours=24,
                        )
                        session = refreshed_session or session
                        request_id = str((refreshed_session or {}).get("request_id") or request_id).strip()
                    except Exception:
                        logger.exception(
                            "Failed to refresh active session from latest report snapshot for project=%s actor=%s client=%s",
                            project_name,
                            actor_for_snapshot,
                            client_for_snapshot,
                        )
            rec_result = handle_report_errors(html_text, project_name)
        except Exception:
            logger.exception(
                "Failed to evaluate recommendations from report snapshot for project=%s actor=%s client=%s",
                project_name,
                actor_for_snapshot,
                client_for_snapshot,
            )

    # Strict live-context behavior:
    # current active recommendation must come from the latest report snapshot.
    # If the snapshot is missing or invalid, do not reuse saved session context
    # or old error-message-only matching for active recommendation flow.
    if not snapshot_path or not os.path.exists(snapshot_path):
        return {
            "status": "error",
            "error": "current report snapshot not available for active recommendation",
            "request_id": request_id,
            "s3_key": resolved_s3_key,
            "result": [],
        }
    if not rec_result or rec_result.get("status") != "success":
        return {
            "status": "error",
            "error": rec_result.get("error") or "failed to evaluate recommendation from current report snapshot",
            "request_id": request_id,
            "s3_key": resolved_s3_key,
            "result": [],
        }
    if rec_result.get("status") != "success":
        return {
            "status": "error",
            "error": rec_result.get("error") or "recommendation failed",
            "request_id": request_id,
            "s3_key": resolved_s3_key,
            "result": [],
        }

    recommendations = rec_result.get("recommendations")
    if not isinstance(recommendations, list):
        recommendations = []
    match_status = str(rec_result.get("match_status") or "").strip().lower()

    # Same three values as the formatter above - see the note there for why below_threshold must
    # be in this set.
    if match_status in {"weak", "below_threshold", "none"}:
        return {
            "status": "success",
            "request_id": request_id,
            "s3_key": resolved_s3_key,
            "result": [],
            "match_status": match_status or "none",
            "formatted_output": _format_copilot_output(rec_result),
        }

    compact_rows = []
    for rec in recommendations:
        if not isinstance(rec, dict):
            continue
        req_id = rec.get("request_id") or rec.get("batch_id")
        compact_rows.append(
            {
                "compare_diff_link": _build_compare_diff_link(req_id, None),
                "request_id": req_id,
                "solution": rec.get("solution", []),
            }
        )

    if compact_rows:
        try:
            request_ids = [str(row.get("request_id") or "").strip() for row in compact_rows if str(row.get("request_id") or "").strip()]
            save_active_recommendation_context(
                project_name=project_name,
                actor_id=actor_for_snapshot,
                client_id=client_for_snapshot,
                workspace_id=workspace_for_snapshot,
                request_ids=request_ids,
                primary_request_id=request_ids[0] if request_ids else "",
            )
        except Exception:
            logger.exception("Failed to persist active recommendation context for active-auto flow")

    matched_request_id = ""
    if compact_rows:
        matched_request_id = str((compact_rows[0] or {}).get("request_id") or "").strip()

    _llm_analysis = rec_result.get("llm_analysis") or ""
    query_text = str(payload.get("query_text") or "").strip()
    doc_top_k_raw = payload.get("doc_top_k")
    try:
        doc_top_k = int(doc_top_k_raw) if doc_top_k_raw is not None else 5
    except (TypeError, ValueError):
        doc_top_k = 5
    doc_top_k = max(1, min(doc_top_k, 20))
    document_query = query_text or str(rec_result.get("query_error") or error_message or "").strip()
    document_context = rec_result.get("document_context")
    if not isinstance(document_context, dict):
        document_context = {
            "success": False,
            "query": document_query,
            "project_name": project_name,
            "count": 0,
            "results": [],
            "message": "document query is empty",
        }
        if document_query:
            document_context = build_document_context(
                query_text=document_query,
                project_name=project_name,
                top_k=doc_top_k,
            )

    context_enrichment = rec_result.get("context_enrichment")
    if not isinstance(context_enrichment, dict):
        context_enrichment = {
            "enabled": False,
            "query": document_query,
            "semantic_results_used": 0,
            "artifact_results_used": 0,
            "combined_context": {"semantic_results": [], "artifact_results": []},
            "token_usage": {
                "final_analysis": {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0},
                "total": {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0},
            },
        }

    logger.debug(
        "handle_copilot_recommend_by_active_auto | building final response | "
        "project_name=%s | compact_rows_count=%d | match_status=%s | llm_analysis_present=%s | llm_analysis_chars=%d | document_query_present=%s | document_result_count=%d",
        project_name,
        len(compact_rows),
        match_status,
        bool(_llm_analysis),
        len(_llm_analysis),
        bool(document_query),
        len(document_context.get("results") or []) if isinstance(document_context, dict) else 0,
    )

    return {
        "status": "success",
        "request_id": request_id,
        "active_request_id": request_id,
        "matched_request_id": matched_request_id or None,
        "s3_key": resolved_s3_key,
        "result": compact_rows,
        "query_error": error_message,
        "llm_analysis": _llm_analysis,
        "document_context": document_context,
        "context_enrichment": context_enrichment,
        "formatted_output": _format_report_errors_rows(
            compact_rows,
            query_error=rec_result.get("query_error") or "",
            llm_analysis=_llm_analysis,
        ),
    }


def handle_copilot_recommend_by_uuid(data: Dict) -> Dict:
    payload = data or {}
    project_name = _safe_project_name(str(payload.get("project_name") or payload.get("projectName") or ""))
    request_id = str(payload.get("uuid") or payload.get("request_id") or "").strip()
    error_message = str(payload.get("error_message") or "").strip()

    if not project_name:
        raise ValueError("project_name is required")
    if not request_id:
        raise ValueError("uuid is required")
    if not error_message:
        raise ValueError("error_message is required")

    rec = handle_recommendations(
        {
            "projectName": project_name,
            "error_message": error_message,
        }
    )
    return {
        "status": "success" if rec.get("success") else "error",
        "request_id": request_id,
        "result": rec,
        "formatted_output": rec.get("formatted_output") or _format_copilot_output(rec),
    }


def handle_copilot_build_success(data: Dict) -> Dict:
    payload = data or {}
    project_name = _safe_project_name(str(payload.get("project_name") or payload.get("projectName") or ""))
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    client_id = str(payload.get("client_id") or "global").strip() or "global"
    workspace_id = str(payload.get("workspace_id") or "").strip()
    build_context_id = str(payload.get("build_context_id") or "").strip()

    active = None
    if project_name:
      active = handle_get_active_copilot_session(
          {
              "project_name": project_name,
              "actor_id": actor_id,
              "client_id": client_id,
              "workspace_id": workspace_id,
          }
      )
    else:
      active = handle_get_active_copilot_session_auto(
          {
              "actor_id": actor_id,
              "client_id": client_id,
              "workspace_id": workspace_id,
          }
      )

    if not active or not active.get("status"):
        return {
            "status": False,
            "message": "no active copilot session found for build success correlation",
            "saved_outcomes": 0,
        }

    session = active.get("session") or {}
    session_build_context_id = str(session.get("build_context_id") or "").strip()
    if build_context_id and session_build_context_id and build_context_id != session_build_context_id:
        return {
            "status": False,
            "message": "active session build context does not match success event",
            "saved_outcomes": 0,
        }

    # SAME BUILD TYPE, or it is not the same failure resolved.
    #
    # Otherwise a build that fails in one build type and passes in another would be treated as
    # that error resolved, which is wrong. Example: RMS fails
    # under one requested task; the developer changes something and runs a DIFFERENT task that
    # also executes RMS. That green build says nothing about the original failure, so the
    # original must stay open rather than be recorded as fixed.
    #
    # For Gradle the build type IS the requested task (a lifecycle task), already present
    # in the report's problemsReport.requestedTasks - so nothing new is read or stored, this is
    # only an extra condition on the pairing.
    #
    # FAIL-OPEN by design: TD5 has no report.html, and extensions older than this change send no
    # requestedTasks. When either side is unknown the pairing behaves exactly as it did before -
    # a check that silently stopped recording fixes wherever the signal is absent would be a far
    # worse regression than the mismatch it prevents.
    success_requested_task = str(payload.get("requestedTasks")
                                 or payload.get("requested_task") or "").strip()
    session_requested_task = str(session.get("requested_task") or "").strip()
    if success_requested_task and session_requested_task:
        if _canonical_task_token(success_requested_task) != _canonical_task_token(session_requested_task):
            logger.info(
                "[build-type] success ignored - different build type | failure_task=%s | success_task=%s | project=%s",
                session_requested_task, success_requested_task, project_name,
            )
            return {
                "status": False,
                "message": ("build succeeded under a different build type "
                            f"(failed on '{session_requested_task}', passed on "
                            f"'{success_requested_task}') - the original failure stays open"),
                "saved_outcomes": 0,
                "build_type_mismatch": True,
                "failure_requested_task": session_requested_task,
                "success_requested_task": success_requested_task,
            }

    request_ids = [
        str(x).strip()
        for x in (session.get("last_recommended_request_ids") or [])
        if str(x).strip()
    ]
    if not request_ids:
        primary = str(session.get("last_recommended_request_id") or "").strip()
        if primary:
            request_ids = [primary]

    if not request_ids:
        return {
            "status": True,
            "message": "build success recorded with no prior recommendation context",
            "saved_outcomes": 0,
        }

    query_signature_hashes = []
    error_signature = str(session.get("error_signature") or "").strip()
    if error_signature:
        query_signature_hashes = [error_signature]

    hit_date = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    saved = 0
    for req_id in request_ids:
        try:
            save_recommendation_outcome(
                request_id=req_id,
                project_name=str(active.get("project_name") or session.get("project_name") or project_name or "").strip().lower(),
                recommended=True,
                outcome_type="success_correlated",
                source="build_success_correlation",
                match_status="success_correlated",
                confidence_score=1.0,
                query_signature_hashes=query_signature_hashes,
                hit_date=hit_date,
                adapter_enabled=_adapter_state_for(str(active.get("project_name") or session.get("project_name") or project_name or "")),
            )
            saved += 1
        except ClientError:
            logger.exception("Failed to save success-correlated recommendation outcome for request_id=%s", req_id)

    return {
        "status": True,
        "message": "build success correlation recorded",
        "saved_outcomes": saved,
        "request_ids": request_ids,
        "project_name": active.get("project_name") or session.get("project_name") or project_name,
    }


def _adapter_runtime_state(project_name: str) -> Dict:
    """WHY the Adapter column shows what it shows: a bare '-' cannot
    tell apart four different truths — the admin toggle is OFF, the toggle is ON but no adapter
    has been TRAINED yet, the adapter ran but this candidate came from a non-semantic stage
    (exact signature / task ledger, which the fusion never touches), or the adapter genuinely
    did not surface this candidate. The trace records the state so the page states the fact."""
    enabled = trained = None
    try:
        from src.services.adapter_settings import adapter_enabled_for
        enabled = bool(adapter_enabled_for(str(project_name or "")))
    except Exception:
        logger.warning("adapter enabled-state read failed (trace records unknown)")
    try:
        from src.utils import feedback_adapter
        trained = bool(feedback_adapter.is_active("error"))
    except Exception:
        logger.warning("adapter trained-state read failed (trace records unknown)")
    # A FOURTH truth, added after the column read "- -> -" on every row while the state
    # said "active": W can be trained and the switch on while the parallel index the second
    # search reads is empty or missing. Training produces W; filling that index is a separate
    # step. Without this the page confidently reported "active" for a search that never ran.
    learned_ready = None
    try:
        from src.utils.recommended import _get_learned_collection
        collection = _get_learned_collection()
        learned_ready = bool(collection is not None and collection.count())
    except Exception:
        logger.warning("learned-space check failed (trace records unknown)")

    if enabled is False:
        reason = "off"                 # admin switch is off for this project
    elif trained is False:
        reason = "not_trained"         # switch on, but no W has been trained yet
    elif learned_ready is False:
        reason = "no_learned_space"    # W trained and switched on, but its index is empty
    elif enabled and trained:
        reason = "active"              # fusion applies; per-candidate ranks show the influence
    else:
        reason = "unknown"
    return {"enabled": enabled, "trained": trained,
            "learned_space": learned_ready, "reason": reason}


def _adapter_state_for(project_name: str):
    """Whether the W adapter is active for this project right now - recorded on recommendation
    events and feedback votes so the impact of the feedback loop is measurable.
    None on any error: recording state must never break the flows."""
    try:
        from src.services.adapter_settings import adapter_enabled_for
        return bool(adapter_enabled_for(str(project_name or "")))
    except Exception:
        return None


def handle_recommendation_feedback(data: dict) -> dict:
    if not isinstance(data, dict):
        return {"status": "error", "error": "request body must be JSON"}

    request_id = str(data.get("request_id") or "").strip()
    project_name = str(data.get("project_name") or "").strip().lower()
    is_helpful = data.get("is_helpful")
    feedback_token = str(data.get("feedback_token") or "").strip()
    raw_hashes = data.get("query_signature_hashes") or []
    query_signature_hashes = [str(h).strip().lower() for h in raw_hashes if str(h).strip()]

    if not request_id:
        return {"status": "error", "error": "request_id is required"}
    if not isinstance(is_helpful, bool):
        return {"status": "error", "error": "is_helpful must be true or false"}

    hit_date = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        save_recommendation_outcome(
            request_id=request_id,
            project_name=project_name,
            outcome_type="user_feedback",
            source="user_feedback",
            query_signature_hashes=query_signature_hashes,
            hit_date=hit_date,
            is_helpful=is_helpful,
            feedback_token=feedback_token,
            adapter_enabled=_adapter_state_for(project_name),
        )
    except Exception:
        logger.exception("Failed to save user feedback for request_id=%s", request_id)
        return {"status": "error", "error": "failed to save feedback"}

    # New vote must show in the dashboards immediately, not after the cache TTL.
    try:
        from src.utils import ttl_cache
        ttl_cache.invalidate_prefix("fbv")
    except Exception:
        pass

    if is_helpful is False:
        # The decision chains behind not-helpful recommendations are
        # kept long-term for analysis and future training - flag them now.
        try:
            from src.utils import recommendation_trace
            recommendation_trace.flag_not_helpful(request_id)
        except Exception:
            logger.exception("trace flagging failed for request_id=%s", request_id)

    logger.info(
        "handle_recommendation_feedback | saved | request_id=%s | is_helpful=%s",
        request_id, is_helpful,
    )
    return {
        "status": True,
        "request_id": request_id,
        "is_helpful": is_helpful,
    }


def _predict_display(result_payload: Dict) -> str:
    if not isinstance(result_payload, dict):
        return "Prediction not available."
    matches = result_payload.get("matches") or []
    if not isinstance(matches, list):
        matches = []
    has_history_match = len(matches) > 0

    lines = [
        "Build Failure Historical Match Check",
        (
            "Result: Historical failure pattern(s) found in current project files."
            if has_history_match
            else "Result: No historical failure pattern found in current project files."
        ),
        "Note: This is a historical risk indicator, not a 100% failure guarantee.",
    ]

    lines.append("Historical Evidence:")
    reasons = result_payload.get("top_reasons") or []
    if isinstance(reasons, list) and reasons:
        for idx, reason in enumerate(reasons[:5], start=1):
            lines.append(f"{idx}. {reason}")
    else:
        lines.append("1. No matching historical failing pattern was found.")

    top_files = result_payload.get("top_risk_files") or []
    if isinstance(top_files, list) and top_files:
        lines.append("Matched Files From History:")
        for row in top_files[:5]:
            if not isinstance(row, dict):
                continue
            lines.append(
                f"- {row.get('file_path','N/A')} | matched_hits={int(row.get('hit_count',0))}"
            )

    refs = result_payload.get("most_similar_references") or []
    if isinstance(refs, list) and refs:
        lines.append("Historical Reference IDs:")
        for ref in refs[:5]:
            if not isinstance(ref, dict):
                continue
            rid = str(ref.get("request_id") or "").strip()
            if not rid:
                continue
            lines.append(f"- request_id={rid}")

    if has_history_match:
        lines.append("Lines Found In Current Project:")
        for m in matches[:5]:
            if not isinstance(m, dict):
                continue
            line_found = int(m.get("line_found") or 0)
            line_text = str(m.get("line_text_found") or "").strip()
            line_part = f" | line={line_found}" if line_found > 0 else ""
            text_part = f" | found=\"{line_text[:140]}\"" if line_text else ""
            lines.append(
                f"- {m.get('file_path','N/A')}{line_part}{text_part} | request_id={m.get('request_id','')}"
            )
    return "\n".join(lines)


def _normalize_predict_scope_path(value: str, project_name: str) -> str:
    raw = str(value or "").strip().replace("\\", "/").lower()
    if not raw:
        return ""
    project = str(project_name or "").strip().lower()
    marker = f"/{project}/"
    idx = raw.find(marker)
    if idx >= 0:
        return raw[idx + len(marker):].strip("/")
    return raw.strip("/")


def _predict_scope_path_keys(value: str, project_name: str) -> set[str]:
    normalized = _normalize_predict_scope_path(value, project_name)
    if not normalized:
        return set()
    keys = {normalized}
    keys.add(os.path.basename(normalized))
    parts = normalized.split("/")
    if len(parts) >= 2:
        keys.add("/".join(parts[-2:]))
    return {k for k in keys if k}


def _phase2_normalize_pattern_text(value: str) -> str:
    text = str(value or "").strip()
    text = re.sub(r"^\s*\[\[\d+\]\]\s*", "", text)
    text = re.sub(r"^\s*\[(?:MOD|\+|-)\]\s*", "", text)
    text = re.sub(r"\[\[line:\d+\]\]\s*", "", text)
    text = re.sub(r"\[\[hunk:\d+\]\]\s*", "", text)
    return text.strip()


def _phase2_change_kind(change_text: str) -> str:
    text = str(change_text or "").strip()
    text = re.sub(r"^\s*\[\[\d+\]\]\s*", "", text)
    match = re.match(r"^\s*\[(MOD_AFTER|MOD|\+|-)\]", text)
    if not match:
        return ""
    token = match.group(1)
    if token == "+":
        return "add"
    if token == "-":
        return "delete"
    if token == "MOD":
        return "modify"
    if token == "MOD_AFTER":
        return "modify_after"
    return ""


def _phase2_default_risk_side(change_text: str) -> str:
    kind = _phase2_change_kind(change_text)
    if kind in {"delete", "modify"}:
        return "before"
    if kind in {"add", "modify_after"}:
        return "after"
    return "before"


def _phase2_is_weak_feature(change_text: str) -> bool:
    text = _phase2_normalize_pattern_text(change_text)
    if not text or len(text) < _PHASE2_SCOPE_MIN_PATTERN_LENGTH:
        return True
    if re.match(r"^\s*//", text):
        return True
    if re.match(r"^\s*#", text) and not re.match(r"^\s*#\s*include\b", text, re.IGNORECASE):
        return True
    return False


def _scorecard_reliability_map(project_name: str) -> dict:
    """Per-pattern right/near/wrong from the judged shadow reports (step B metrics), keyed the
    same way shadow_judge keys its patterns. TTL-cached - judging is upload-time, 5 minutes of
    staleness is fine. Fail-open {} so a metrics problem never touches predictions."""
    from src.utils import ttl_cache

    def _build():
        try:
            from src.services import shadow_judge
            metrics = shadow_judge.shadow_metrics(str(project_name or ""), limit=200) or {}
            out = {}
            for row in metrics.get("patterns") or []:
                key = re.sub(r"\s+", " ", str(row.get("pattern") or "")).strip().lower()[:200]
                if key:
                    out[key] = {"right": int(row.get("right") or 0),
                                "near": int(row.get("near") or 0),
                                "wrong": int(row.get("wrong") or 0)}
            return out
        except Exception:
            logger.exception("scorecard map build failed")
            return {}

    return ttl_cache.get_or_compute(("scorecard", str(project_name or "").strip().lower()),
                                    _build, deep_copy=False, ttl_override=300)


def _predict_match_reason(issue: Dict) -> str:
    stage1_score = float(issue.get("stage1_score") or 0.0)
    stage2_score = float(issue.get("stage2_score") or 0.0)
    stage3_score = float(issue.get("stage3_score") or 0.0)
    stage4_score = float(issue.get("stage4_score") or 0.0)
    absence_found = bool(issue.get("absence_found") or False)
    if absence_found and stage4_score >= max(stage1_score, stage2_score, stage3_score):
        return "This file is missing a line that a past fix added — historically this absence caused a build failure."
    if stage1_score > 0 and stage2_score > 0:
        return "Exact line position and nearby patch both matched the historical failure."
    if stage1_score > 0:
        return "Exact line matched at the same historical position."
    if stage2_score > 0:
        return "Nearby patch matched the historical failure around the risky line."
    if stage3_score > 0:
        return "Nearby code context was similar to the historical failure."
    return "Historical comparison matched this file."


def _build_prediction_scope(project_name: str, selected_files: List[str] | None = None) -> Dict:
    refs = list_prediction_feature_archives(project_name=project_name, limit=_PREDICT_SCOPE_MAX_FEATURES)
    selected_keys: set[str] = set()
    for item in (selected_files or []):
        selected_keys.update(_predict_scope_path_keys(str(item or ""), project_name))
    all_rule_file_paths: set[str] = set()
    by_file: Dict[str, List[Dict]] = {}
    rules_skipped_old = 0
    rules_skipped_weak = 0
    after_patch_by_key: Dict[tuple, str] = {}
    now = datetime.now(UTC)
    for ref in refs:
        s3_key = str(ref.get("s3_key") or "")
        if not s3_key:
            continue
        try:
            feature = download_prediction_feature_json(s3_key)
        except Exception:
            logger.exception("Failed loading prediction feature s3_key=%s", s3_key)
            continue
        if not isinstance(feature, dict):
            continue
        feature_version = int(feature.get("feature_version") or 1)
        if feature_version < _PHASE2_FEATURE_VERSION:
            continue
        change_text = str(feature.get("change") or "")
        change_kind = _phase2_change_kind(change_text)
        risk_side = str(feature.get("risk_side") or "").strip().lower()
        # Collect the fixed line text from MOD_AFTER features so that before-rules
        # can be enriched with it — the extension uses this to skip rules where
        # the code has already been corrected to the fixed value.
        if risk_side == "after" and change_kind == "modify_after":
            req_id_af = str(feature.get("request_id") or "").strip()
            feat_line_af = int(feature.get("line") or 0)
            patch_raw_af = str(feature.get("patch") or "")
            patch_clean_af = re.sub(r"^\s*\[MOD_AFTER\]\s*", "", patch_raw_af).strip()
            if req_id_af and feat_line_af > 0 and patch_clean_af:
                after_patch_by_key[(req_id_af, feat_line_af)] = patch_clean_af
        include_in_scope = risk_side == "before" or change_kind == "add"
        if not include_in_scope:
            continue
        created_date = str(ref.get("created_date") or feature.get("created_date") or "")
        created_dt = _parse_iso_utc(created_date)
        if _PHASE2_SCOPE_MAX_FEATURE_AGE_DAYS > 0 and created_dt:
            age_days = max(0.0, (now - created_dt).total_seconds() / 86400.0)
            if age_days > _PHASE2_SCOPE_MAX_FEATURE_AGE_DAYS:
                rules_skipped_old += 1
                continue
        file_path = str(feature.get("file_path") or "").strip()
        if not file_path:
            continue
        all_rule_file_paths.add(file_path)
        if selected_keys:
            feature_keys = _predict_scope_path_keys(file_path, project_name)
            if not feature_keys or selected_keys.isdisjoint(feature_keys):
                continue
        if _phase2_is_weak_feature(change_text):
            rules_skipped_weak += 1
            continue
        row = {
            "change_id": str(feature.get("change_id") or ""),
            "line": int(feature.get("line") or 0),
            "hunk": int(feature.get("hunk") or 0),
            "change": change_text,
            "patch": str(feature.get("patch") or ""),
            "patch_embedding": feature.get("patch_embedding") if isinstance(feature.get("patch_embedding"), list) else [],
            "request_id": str(feature.get("request_id") or ""),
            "created_date": created_date,
        }
        by_file.setdefault(file_path, []).append(row)

    # Enrich before-rules with the corresponding fixed line text so the extension
    # can suppress rules where the current file already has the fix applied.
    for _file_rules in by_file.values():
        for _row in _file_rules:
            _row["after_patch"] = after_patch_by_key.get((_row["request_id"], _row["line"]), "")

    ranked = sorted(by_file.items(), key=lambda kv: len(kv[1]), reverse=True)[:_PREDICT_SCOPE_MAX_FILES]
    target_files = [k for k, _ in ranked]
    rules_by_file = {k: v[:20] for k, v in ranked}
    total_rule_files_available = len(all_rule_file_paths)
    scope_reduction_percent = 0.0
    if total_rule_files_available > 0:
        scope_reduction_percent = max(
            0.0,
            round((1.0 - (len(target_files) / total_rule_files_available)) * 100.0, 2),
        )
    return {
        "target_files": target_files,
        "rules_by_file": rules_by_file,
        "max_files": _PREDICT_SCOPE_MAX_FILES,
        "stage3_threshold": _PREDICT_STAGE3_THRESHOLD,
        "selected_files_count": len(selected_files or []),
        "total_rule_files_available": total_rule_files_available,
        "matched_rule_files_count": len(target_files),
        "rules_returned_count": sum(len(v) for v in rules_by_file.values()),
        "scope_reduction_percent": scope_reduction_percent,
        "rules_skipped_old": rules_skipped_old,
        "rules_skipped_weak": rules_skipped_weak,
    }


def _resolve_predict_project(payload: Dict, actor_id: str) -> str:
    project_name = _safe_project_name(str(payload.get("project_name") or ""))
    if project_name:
        return project_name
    last = get_last_copilot_error_session_for_actor(actor_id=actor_id) or {}
    return _safe_project_name(str(last.get("project_name") or ""))


def handle_predict_scope(data: Dict) -> Dict:
    payload = data or {}
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    client_id = str(payload.get("client_id") or "global").strip() or "global"
    project_name = _resolve_predict_project(payload, actor_id)
    if not project_name:
        raise ValueError("project_name is required")

    scope = _build_prediction_scope(project_name)
    prediction_session_id = str(uuid.uuid4())
    session = touch_predict_session(
        project_name=project_name,
        prediction_session_id=prediction_session_id,
        scope_payload=scope,
        actor_id=actor_id,
        client_id=client_id,
        ttl_hours=int(payload.get("ttl_hours") or 24),
    )
    return {
        "status": True,
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "prediction_session_id": prediction_session_id,
        "scope": scope,
        "session": session,
    }


def handle_get_predict_pending_scope(data: Dict) -> Dict:
    payload = data or {}
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    client_id = str(payload.get("client_id") or "global").strip() or "global"
    project_name = _resolve_predict_project(payload, actor_id)
    if not project_name:
        return {"status": False, "error": "project_name is required"}
    session = get_active_predict_session(project_name, actor_id, client_id)
    if not session:
        return {"status": False, "project_name": project_name, "actor_id": actor_id, "client_id": client_id}
    scope_raw = session.get("scope_json") or ""
    scope = {}
    if isinstance(scope_raw, str) and scope_raw.strip():
        try:
            scope = json.loads(scope_raw)
        except Exception:
            scope = {}
    result_raw = session.get("result_json") or ""
    has_result = bool(result_raw)
    return {
        "status": True,
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "prediction_session_id": session.get("prediction_session_id"),
        "session_status": session.get("status"),
        "scope": scope,
        "has_result": has_result,
    }


def _compute_prediction_risk(matches: List[Dict]) -> Dict:
    def _clamp(val: float, lo: float, hi: float) -> float:
        return max(lo, min(hi, val))

    def _safe_float(val: object, default: float = 0.0) -> float:
        try:
            return float(val)
        except Exception:
            return default

    def _parse_iso_date(value: object) -> Optional[datetime]:
        txt = str(value or "").strip()
        if not txt:
            return None
        try:
            if txt.endswith("Z"):
                txt = txt[:-1] + "+00:00"
            dt = datetime.fromisoformat(txt)
            if dt.tzinfo is None:
                return dt.replace(tzinfo=UTC)
            return dt.astimezone(UTC)
        except Exception:
            return None

    def _risk_level(score_100: float) -> str:
        if score_100 >= 80.0:
            return "critical"
        if score_100 >= 60.0:
            return "high"
        if score_100 >= 30.0:
            return "medium"
        return "low"

    if not matches:
        return {
            "risk_score": 0.0,
            "risk_score_percent": 0.0,
            "risk_level": "low",
            "risk_band": "low",
            "top_reasons": ["No historical risky pattern matched in current local scan."],
            "score_breakdown": {
                "formula": "RiskScore = S1 + S2 + S3 + S4 - ConfidencePenalty",
                "s1_exact": 0.0,
                "s2_patch": 0.0,
                "s3_frequency": 0.0,
                "s4_recency": 0.0,
                "confidence_penalty": 0.0,
            },
            "top_risk_files": [],
            "most_similar_references": [],
        }

    max_score = 0.0
    stage_counts = {1: 0, 2: 0, 3: 0}
    stage_best = {1: 0.0, 2: 0.0, 3: 0.0}
    request_ids = set()
    file_stats: Dict[str, Dict] = {}
    most_similar: List[Dict] = []
    recency_points = 0.0
    missing_signal_count = 0
    weak_signal_count = 0
    now = datetime.now(UTC)

    for m in matches:
        if not isinstance(m, dict):
            continue
        score = _clamp(_safe_float(m.get("score"), 0.0), 0.0, 1.0)
        max_score = max(max_score, score)
        stage = int(m.get("stage") or 3)
        stage_counts[stage] = stage_counts.get(stage, 0) + 1
        stage_best[stage] = max(stage_best.get(stage, 0.0), score)

        rid = str(m.get("request_id") or "").strip()
        if rid:
            request_ids.add(rid)
        file_path = str(m.get("file_path") or "N/A").strip() or "N/A"
        if file_path not in file_stats:
            file_stats[file_path] = {
                "file_path": file_path,
                "max_score": 0.0,
                "hit_count": 0,
                "request_ids": set(),
                "stages": set(),
            }
        file_stats[file_path]["max_score"] = max(file_stats[file_path]["max_score"], score)
        file_stats[file_path]["hit_count"] += 1
        file_stats[file_path]["stages"].add(stage)
        if rid:
            file_stats[file_path]["request_ids"].add(rid)

        most_similar.append({"request_id": rid, "score": score, "stage": stage, "file_path": file_path})

        # Optional feature created date from extension/local matching payload.
        dt = _parse_iso_date(m.get("feature_created_date") or m.get("created_date"))
        if dt:
            age_days = max(0.0, (now - dt).total_seconds() / 86400.0)
            if age_days <= 7:
                recency_points = max(recency_points, 10.0)
            elif age_days <= 30:
                recency_points = max(recency_points, 7.0)
            elif age_days <= 90:
                recency_points = max(recency_points, 4.0)
            else:
                recency_points = max(recency_points, 1.0)

        if not m.get("file_path") or not rid:
            missing_signal_count += 1
        if score < 0.55:
            weak_signal_count += 1

    # S1 (0..40): exact anchored confidence (stage-1 strongest, stage-2 partial fallback).
    s1_exact = _clamp((stage_best.get(1, 0.0) * 40.0) + (stage_best.get(2, 0.0) * 10.0), 0.0, 40.0)
    # S2 (0..30): patch-context similarity (stage-3 similarity driven).
    s2_patch = _clamp(stage_best.get(3, 0.0) * 30.0, 0.0, 30.0)
    # S3 (0..20): historical density/frequency impact.
    s3_frequency = _clamp((len(matches) / 12.0) * 20.0, 0.0, 20.0)
    # S4 (0..10): recency impact; if no timestamps available, keep neutral-low at 2.
    s4_recency = recency_points if recency_points > 0 else 2.0

    confidence_penalty = _clamp(
        (2.0 * weak_signal_count) + (1.5 * missing_signal_count) + (3.0 if stage_counts.get(1, 0) == 0 else 0.0),
        0.0,
        10.0,
    )

    score_100 = _clamp(s1_exact + s2_patch + s3_frequency + s4_recency - confidence_penalty, 0.0, 100.0)
    risk_score = round(score_100 / 100.0, 4)
    level = _risk_level(score_100)

    top_files = []
    for _, row in sorted(file_stats.items(), key=lambda kv: (kv[1]["max_score"], kv[1]["hit_count"]), reverse=True):
        top_files.append(
            {
                "file_path": row["file_path"],
                "max_score": round(float(row["max_score"]), 4),
                "hit_count": int(row["hit_count"]),
                "stages": sorted(int(x) for x in row["stages"]),
                "request_ids": sorted(str(x) for x in row["request_ids"])[:5],
            }
        )

    similar_sorted = sorted(most_similar, key=lambda x: float(x.get("score") or 0.0), reverse=True)
    refs_out: List[Dict] = []
    seen_ref = set()
    for row in similar_sorted:
        rid = str(row.get("request_id") or "").strip()
        if not rid or rid in seen_ref:
            continue
        seen_ref.add(rid)
        refs_out.append({"request_id": rid, "score": round(float(row.get("score") or 0.0), 4)})
        if len(refs_out) >= 5:
            break

    reasons = [
        f"Matched {len(matches)} historical risky signal(s) across {len(file_stats)} file(s).",
        f"Exact anchored hits (Stage-1): {stage_counts.get(1,0)}; approximate in-file hits (Stage-2): {stage_counts.get(2,0)}.",
        f"Patch-context similarity hits (Stage-3): {stage_counts.get(3,0)}; strongest similarity={stage_best.get(3,0.0):.3f}.",
        f"Historical reference set size for this scan: {len(request_ids)} unique request_id(s).",
    ]
    risky_line_examples: List[str] = []
    seen_line = set()
    for m in matches:
        if not isinstance(m, dict):
            continue
        txt = str(m.get("line_text_found") or "").strip()
        if not txt:
            continue
        key = txt.lower()
        if key in seen_line:
            continue
        seen_line.add(key)
        risky_line_examples.append(txt)
        if len(risky_line_examples) >= 2:
            break
    if risky_line_examples:
        reasons.append(
            "Risky line(s) found in current project: "
            + " | ".join([f'"{x[:100]}"' for x in risky_line_examples])
        )
    if confidence_penalty > 0:
        reasons.append(
            f"Confidence penalty applied ({confidence_penalty:.1f}) due to weak/partial signals."
        )
    return {
        "risk_score": risk_score,
        "risk_score_percent": round(score_100, 2),
        "risk_level": level,
        "risk_band": level,
        "top_reasons": reasons,
        "score_breakdown": {
            "formula": "RiskScore = S1 + S2 + S3 + S4 - ConfidencePenalty",
            "s1_exact": round(s1_exact, 2),
            "s2_patch": round(s2_patch, 2),
            "s3_frequency": round(s3_frequency, 2),
            "s4_recency": round(s4_recency, 2),
            "confidence_penalty": round(confidence_penalty, 2),
        },
        "top_risk_files": top_files[:5],
        "most_similar_references": refs_out,
    }


def handle_predict_result(data: Dict) -> Dict:
    payload = data or {}
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    client_id = str(payload.get("client_id") or "global").strip() or "global"
    project_name = _resolve_predict_project(payload, actor_id)
    if not project_name:
        raise ValueError("project_name is required")
    prediction_session_id = str(payload.get("prediction_session_id") or "").strip()
    if not prediction_session_id:
        raise ValueError("prediction_session_id is required")
    matches = payload.get("matches") or []
    if not isinstance(matches, list):
        matches = []
    summary = payload.get("summary") or {}
    if not isinstance(summary, dict):
        summary = {}
    risk = _compute_prediction_risk(matches)
    result_payload = {
        "prediction_session_id": prediction_session_id,
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "matches": matches,
        "summary": summary,
        **risk,
        "updated_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    save_predict_result(
        project_name=project_name,
        actor_id=actor_id,
        client_id=client_id,
        prediction_session_id=prediction_session_id,
        result_payload=result_payload,
        ttl_hours=int(payload.get("ttl_hours") or 24),
    )
    return {"status": True, "result": result_payload, "formatted_output": _predict_display(result_payload)}


def handle_get_predict_result_current(data: Dict) -> Dict:
    payload = data or {}
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    client_id = str(payload.get("client_id") or "global").strip() or "global"
    project_name = _resolve_predict_project(payload, actor_id)
    if not project_name:
        return {"status": False, "error": "project_name is required"}
    session = get_active_predict_session(project_name, actor_id, client_id)
    if not session:
        return {"status": False, "error": "prediction session not found", "project_name": project_name}
    result_raw = session.get("result_json") or ""
    scope_raw = session.get("scope_json") or ""
    result = {}
    scope = {}
    if isinstance(result_raw, str) and result_raw.strip():
        try:
            result = json.loads(result_raw)
        except Exception:
            result = {}
    if isinstance(scope_raw, str) and scope_raw.strip():
        try:
            scope = json.loads(scope_raw)
        except Exception:
            scope = {}
    if result:
        current_session_id = str(session.get("prediction_session_id") or "").strip()
        result_session_id = str(result.get("prediction_session_id") or "").strip()
        if result_session_id and current_session_id and result_session_id != current_session_id:
            return {
                "status": True,
                "project_name": project_name,
                "actor_id": actor_id,
                "client_id": client_id,
                "prediction_session_id": current_session_id,
                "result": None,
                "scope": scope,
                "formatted_output": "Prediction session is ready. Waiting for local extension analysis result.",
            }
        return {
            "status": True,
            "project_name": project_name,
            "actor_id": actor_id,
            "client_id": client_id,
            "prediction_session_id": session.get("prediction_session_id"),
            "result": result,
            "formatted_output": _predict_display(result),
        }
    return {
        "status": True,
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "prediction_session_id": session.get("prediction_session_id"),
        "result": None,
        "scope": scope,
        "formatted_output": "Prediction session is ready. Waiting for local extension analysis result.",
    }


def handle_predict_report_scope(data: Dict) -> Dict:
    payload = data or {}
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    project_name = _resolve_predict_project(payload, actor_id)
    if not project_name:
        raise ValueError("project_name is required")
    selected_files = payload.get("selected_files") or []
    if not isinstance(selected_files, list):
        selected_files = []
    scope = _build_prediction_scope(project_name, selected_files=[str(x or "") for x in selected_files])
    return {
        "status": True,
        "project_name": project_name,
        "generated_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "scope": scope,
    }


def _build_predict_history_report(project_name: str, matches: List[Dict], summary: Dict) -> Dict:
    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    grouped: Dict[tuple, Dict] = {}
    for m in matches:
        if not isinstance(m, dict):
            continue
        file_path = str(m.get("file_path") or "").strip() or "N/A"
        file_name = os.path.basename(file_path) if file_path and file_path != "N/A" else "N/A"
        request_id = str(m.get("request_id") or "").strip()
        line_found = int(m.get("line_found") or 0)
        line_text = str(m.get("line_text_found") or "").strip()
        pattern = str(m.get("historical_pattern") or "").strip()
        stage = int(m.get("stage") or 0)
        dominant_stage = int(m.get("dominant_stage") or stage or 0)
        risk_score = float(m.get("risk_score") or 0.0)
        stage1_score = float(m.get("stage1_score") or 0.0)
        stage2_score = float(m.get("stage2_score") or 0.0)
        stage3_score = float(m.get("stage3_score") or 0.0)
        stage4_score = float(m.get("stage4_score") or 0.0)
        absence_found = bool(m.get("absence_found") or m.get("stage4_found") or False)
        key = (file_path, line_found, line_text, pattern)
        row = grouped.get(key)
        if not row:
            row = {
                "icon": "cross",
                "file_name": file_name,
                "file_path": file_path,
                "line_found": line_found,
                "line_text_found": line_text,
                "historical_pattern": pattern,
                "request_ids": [],
                "historical_hits": 0,
                "stage": stage,
                "dominant_stage": dominant_stage,
                "risk_score": risk_score,
                "stage1_score": stage1_score,
                "stage2_score": stage2_score,
                "stage3_score": stage3_score,
                "stage4_score": stage4_score,
                "absence_found": absence_found,
                "why_matched": "",
            }
            grouped[key] = row
        row["historical_hits"] = int(row.get("historical_hits") or 0) + 1
        row["stage"] = min(int(row.get("stage") or 99), stage if stage > 0 else 99)
        row["dominant_stage"] = dominant_stage if dominant_stage > 0 else int(row.get("dominant_stage") or 0)
        row["risk_score"] = max(float(row.get("risk_score") or 0.0), risk_score)
        row["stage1_score"] = max(float(row.get("stage1_score") or 0.0), stage1_score)
        row["stage2_score"] = max(float(row.get("stage2_score") or 0.0), stage2_score)
        row["stage3_score"] = max(float(row.get("stage3_score") or 0.0), stage3_score)
        row["stage4_score"] = max(float(row.get("stage4_score") or 0.0), stage4_score)
        row["absence_found"] = bool(row.get("absence_found") or absence_found)
        if request_id and request_id not in row["request_ids"]:
            row["request_ids"].append(request_id)

    issues: List[Dict] = []
    for row in grouped.values():
        req_ids = list(row.get("request_ids") or [])
        primary_req = req_ids[0] if req_ids else ""
        issues.append(
            {
                **row,
                "why_matched": _predict_match_reason(row),
                "request_id": primary_req or None,
                "view_diff_link": _build_compare_diff_link(primary_req or None, None),
            }
        )
    # Rollout step C (Prediction Feedback Enhancement doc, admin switch, default OFF):
    # reliability scorecards from the judged shadow reports adjust ranking. Q5 answered as
    # proposed: a pattern needs at least 5 judged results before it may influence ranking.
    # Every adjustment is ATTACHED to the issue (issue["scorecard"]) so warnings stay
    # explainable - "ranked lower because this pattern was wrong 4 of 5 times".
    try:
        from src.services import prediction_config as _pcfg
        _sc_on = bool(int((_pcfg.get_config() or {}).get("scorecardWeightingEnabled") or 0))
    except Exception:
        _sc_on = False
    if _sc_on and issues:
        try:
            _rel_map = _scorecard_reliability_map(project_name)
            for _iss in issues:
                _key = re.sub(r"\s+", " ", str(_iss.get("historical_pattern") or "")).strip().lower()[:200]
                _st = _rel_map.get(_key)
                if not _st:
                    continue
                _n = int(_st.get("right") or 0) + int(_st.get("near") or 0) + int(_st.get("wrong") or 0)
                if _n < 5:
                    continue
                _reliability = (float(_st.get("right") or 0) + 0.5 * float(_st.get("near") or 0) + 1.0) / (_n + 2.0)
                _factor = round(0.6 + 0.8 * _reliability, 3)   # 0.6 (always wrong) .. 1.4 (always right)
                _iss["risk_score"] = round(float(_iss.get("risk_score") or 0.0) * _factor, 2)
                _iss["scorecard"] = {"right": int(_st.get("right") or 0), "near": int(_st.get("near") or 0),
                                     "wrong": int(_st.get("wrong") or 0), "factor": _factor}
        except Exception:
            logger.exception("scorecard weighting failed (predictions unadjusted)")

    issues.sort(key=lambda x: (-float(x.get("risk_score") or 0.0), x.get("file_name") or "", int(x.get("line_found") or 0), int(x.get("stage") or 99)))

    has_matches = len(issues) > 0
    return {
        "project_name": project_name,
        "scan_time": now_iso,
        "result": "Historical failure patterns found" if has_matches else "No historical failure patterns found",
        "note": "This report indicates historical failure matches, not guaranteed failure. Risk score is based on weighted Stage 1, Stage 2, and Stage 3 evidence.",
        "has_matches": has_matches,
        "files_scanned": int(summary.get("total_files_scanned") or 0),
        "matches_found": len(issues),
        "average_risk_score": float(summary.get("average_risk_score") or 0.0),
        "selected_files_count": int(summary.get("selected_files_count") or 0),
        "total_rule_files_available": int(summary.get("total_rule_files_available") or 0),
        "matched_rule_files_count": int(summary.get("matched_rule_files_count") or 0),
        "rules_returned_count": int(summary.get("rules_returned_count") or 0),
        "scope_reduction_percent": float(summary.get("scope_reduction_percent") or 0.0),
        "rules_skipped_old": int(summary.get("rules_skipped_old") or 0),
        "rules_skipped_weak": int(summary.get("rules_skipped_weak") or 0),
        "selected_relative_files": summary.get("selected_relative_files") or [],
        "issues": issues,
    }


def handle_predict_report(data: Dict) -> Dict:
    payload = data or {}
    actor_id = str(payload.get("actor_id") or "global").strip() or "global"
    client_id = str(payload.get("client_id") or "global").strip() or "global"
    project_name = _resolve_predict_project(payload, actor_id)
    if not project_name:
        raise ValueError("project_name is required")

    matches = payload.get("matches") or []
    summary = payload.get("summary") or {}
    if not isinstance(matches, list):
        matches = []
    if not isinstance(summary, dict):
        summary = {}

    # Shadow-mode capture (prediction-feedback enhancement, step A): the extension ran the
    # prediction SILENTLY at build-failure time and reports it here with shadow=true plus the
    # failure-cycle context (requested/failing tasks, error signature) so the report can later
    # be judged against the actual fix when the SAME task goes green. Shadow reports are stored
    # with report_kind="shadow" and never appear on the client-facing report pages.
    is_shadow = bool(payload.get("shadow"))
    if is_shadow and not getattr(config, "SHADOW_PREDICTION_CAPTURE_ENABLED", True):
        logger.info("shadow prediction capture disabled — report acknowledged, not stored | project=%s", project_name)
        return {"status": True, "stored": False, "reason": "shadow capture disabled"}

    report = _build_predict_history_report(project_name, matches, summary)
    if is_shadow:
        shadow_context = payload.get("shadow_context")
        report["report_kind"] = "shadow"
        report["shadow_context"] = shadow_context if isinstance(shadow_context, dict) else {}
        # Stored error snippet follows the same rule as all stored error text: timestamp-free.
        if isinstance(report["shadow_context"].get("primary_error_message"), str):
            from src.utils.content_fingerprint import clean_volatile_text_for_display
            report["shadow_context"]["primary_error_message"] = clean_volatile_text_for_display(
                report["shadow_context"]["primary_error_message"])
    try:
        save_prediction_history_report(
            prediction_report_id=str(uuid.uuid4()),
            project_name=project_name,
            actor_id=actor_id,
            client_id=client_id,
            developer_id=str(payload.get("developer_id") or actor_id).strip(),
            request_id=str(payload.get("request_id") or "").strip(),
            report_payload=report,
            created_date=str(payload.get("scan_time") or "").strip() or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            report_kind="shadow" if is_shadow else "",
        )
    except Exception:
        logger.exception("Failed to persist prediction history for project=%s actor=%s", project_name, actor_id)
    return {"status": True, "report": report}


def handle_get_prediction_history(project_name: str, limit: int = 100, kind: str = "standard") -> Dict:
    project = str(project_name or "").strip().lower()
    if not project:
        raise ValueError("project_name is required")
    # kind: "standard" (default, shadow hidden) | "shadow" (silent failure-time captures) | "all"
    items = list_prediction_history_reports(project, limit=limit, kind=kind)
    return {
        "status": True,
        "project_name": project,
        "count": len(items),
        "reports": items,
        "kind": str(kind or "standard").strip().lower(),
    }


def handle_get_prediction_history_report(prediction_report_id: str) -> Dict:
    report_id = str(prediction_report_id or "").strip()
    if not report_id:
        raise ValueError("prediction_report_id is required")
    item = get_prediction_history_report(report_id)
    if not item:
        return {
            "status": False,
            "prediction_report_id": report_id,
            "report": None,
        }
    return {
        "status": True,
        **item,
    }


def handle_predict_embed_texts(data: Dict) -> Dict:
    payload = data or {}
    texts = payload.get("texts") or []
    request_id = str(payload.get("request_id") or str(uuid.uuid4())).strip()
    if not isinstance(texts, list):
        raise ValueError("texts must be an array")
    if len(texts) > 50:
        raise ValueError("texts max size is 50")

    out: List[List[float]] = []
    for raw in texts:
        txt = str(raw or "")
        if not txt.strip():
            out.append([])
            continue
        emb = create_embedding(txt, request_id=request_id)
        out.append(emb if isinstance(emb, list) else [])

    return {
        "status": True,
        "request_id": request_id,
        "model_name": str(config.EMBEDDING_MODEL or ""),
        "embeddings": out,
    }


def handle_compact_recommendation_outcomes(data: Dict | None = None) -> Dict:
    payload = data or {}
    shown_days = int(payload.get("shown_retention_days") or 180)
    success_days = int(payload.get("success_retention_days") or 730)
    result = compact_recommendation_outcomes(
        max_age_days_shown=shown_days,
        max_age_days_success=success_days,
    )
    return {
        "status": True,
        "shown_retention_days": shown_days,
        "success_retention_days": success_days,
        **result,
    }


def handle_compact_request_metadata(data: Dict | None = None) -> Dict:
    payload = data or {}
    fix_days = int(payload.get("fix_retention_days") or 1095)
    vector_days = int(payload.get("vector_retention_days") or 1095)
    warm_after_days = int(payload.get("warm_after_days") or 365)
    result = compact_request_metadata(
        fix_retention_days=fix_days,
        vector_retention_days=vector_days,
        warm_after_days=warm_after_days,
    )
    return {
        "status": True,
        "fix_retention_days": fix_days,
        "vector_retention_days": vector_days,
        "warm_after_days": warm_after_days,
        **result,
    }


def handle_storage_health_summary() -> Dict:
    result = get_storage_health_summary()
    return {
        "status": True,
        **result,
    }


def handle_run_maintenance(data: Dict | None = None) -> Dict:
    payload = data or {}
    name = str(payload.get("name") or "default").strip().lower() or "default"

    recommendation = handle_compact_recommendation_outcomes(payload)
    request_metadata = handle_compact_request_metadata(payload)
    storage_health = handle_storage_health_summary()

    result = {
        "status": True,
        "name": name,
        "recommendation_outcomes": recommendation,
        "request_metadata": request_metadata,
        "storage_health": storage_health,
    }
    save_maintenance_run_result(name=name, payload=result)
    return result


def handle_get_latest_maintenance_run(data: Dict | None = None) -> Dict:
    payload = data or {}
    name = str(payload.get("name") or "default").strip().lower() or "default"
    latest = get_latest_maintenance_run_result(name)
    if not latest:
        return {
            "status": False,
            "name": name,
            "result": None,
        }
    return {
        "status": True,
        **latest,
    }


def _maintenance_alerts_from_health(health: Dict, thresholds: Dict[str, int]) -> List[Dict[str, object]]:
    alerts: List[Dict[str, object]] = []
    tiers = (health or {}).get("tiers") or {}
    for key in ("hot", "warm", "archive-only", "expired"):
        value = int(tiers.get(key) or 0)
        limit = int(thresholds.get(key) or 0)
        if limit > 0 and value > limit:
            alerts.append(
                {
                    "severity": "warning" if key != "expired" else "critical",
                    "metric": key,
                    "value": value,
                    "threshold": limit,
                    "message": f"{key} rows exceeded threshold ({value} > {limit})",
                }
            )
    return alerts


def handle_maintenance_admin_summary(data: Dict | None = None) -> Dict:
    payload = data or {}
    name = str(payload.get("name") or "default").strip().lower() or "default"
    latest = get_latest_maintenance_run_result(name)
    health = get_storage_health_summary()
    thresholds = {
        "hot": int(payload.get("hot_threshold") or os.getenv("MAINT_HOT_THRESHOLD", "50000")),
        "warm": int(payload.get("warm_threshold") or os.getenv("MAINT_WARM_THRESHOLD", "150000")),
        "archive-only": int(payload.get("archive_only_threshold") or os.getenv("MAINT_ARCHIVE_ONLY_THRESHOLD", "250000")),
        "expired": int(payload.get("expired_threshold") or os.getenv("MAINT_EXPIRED_THRESHOLD", "1000")),
    }
    alerts = _maintenance_alerts_from_health(health, thresholds)
    overall = "healthy" if not alerts else "warning"
    if any(str(a.get("severity") or "") == "critical" for a in alerts):
        overall = "critical"
    return {
        "status": True,
        "name": name,
        "overall_status": overall,
        "thresholds": thresholds,
        "alerts": alerts,
        "latest_run": latest,
        "storage_health": health,
    }


def handle_copilot_report_snapshot(
    project_name: str,
    report_bytes: bytes,
    actor_id: str = "global",
    client_id: str = "global",
    workspace_id: str = "",
    build_context_id: str = "",
    report_version: int = 0,
) -> Dict:
    project_name = _safe_project_name(project_name)
    if not project_name:
        raise ValueError("project_name is required")
    if not report_bytes:
        raise ValueError("report content is required")

    report_dir = os.path.join(MCP_REPORT_DIR, "live")
    os.makedirs(report_dir, exist_ok=True)
    safe_workspace_id = str(workspace_id or "").strip()
    file_name = f"{project_name}__{actor_id}__{client_id}"
    if safe_workspace_id:
        file_name += f"__{safe_workspace_id}"
    file_name += ".report.html"
    path = os.path.join(report_dir, secure_filename(file_name))
    with open(path, "wb") as fp:
        fp.write(report_bytes)

    snapshot_key = _copilot_snapshot_key(project_name, actor_id, client_id, safe_workspace_id)
    with _copilot_report_lock:
        _copilot_report_snapshots[snapshot_key] = {
            "path": path,
            "updated_ts": datetime.now(UTC).timestamp(),
            "size": len(report_bytes),
            "workspace_id": safe_workspace_id,
            "build_context_id": str(build_context_id or "").strip(),
            "report_version": int(report_version or 0),
        }
        _copilot_report_snapshots[_copilot_client_snapshot_key(project_name, client_id, safe_workspace_id)] = {
            "path": path,
            "updated_ts": datetime.now(UTC).timestamp(),
            "size": len(report_bytes),
            "workspace_id": safe_workspace_id,
            "build_context_id": str(build_context_id or "").strip(),
            "report_version": int(report_version or 0),
        }
        if safe_workspace_id:
            _copilot_report_snapshots[_copilot_snapshot_key(project_name, actor_id, client_id)] = {
                "path": path,
                "updated_ts": datetime.now(UTC).timestamp(),
                "size": len(report_bytes),
                "workspace_id": safe_workspace_id,
                "build_context_id": str(build_context_id or "").strip(),
                "report_version": int(report_version or 0),
            }
            _copilot_report_snapshots[_copilot_client_snapshot_key(project_name, client_id)] = {
                "path": path,
                "updated_ts": datetime.now(UTC).timestamp(),
                "size": len(report_bytes),
                "workspace_id": safe_workspace_id,
                "build_context_id": str(build_context_id or "").strip(),
                "report_version": int(report_version or 0),
            }
        _copilot_report_last_by_actor[actor_id] = {
            "project_name": project_name,
            "client_id": client_id,
            "updated_ts": datetime.now(UTC).timestamp(),
            "workspace_id": safe_workspace_id,
            "build_context_id": str(build_context_id or "").strip(),
            "report_version": int(report_version or 0),
        }

    return {
        "status": True,
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "workspace_id": safe_workspace_id,
        "build_context_id": str(build_context_id or "").strip(),
        "report_version": int(report_version or 0),
        "size": len(report_bytes),
    }


def handle_copilot_start() -> Dict:
    """
    Production MCP entrypoint for strict Copilot automation.
    - Locates report.html under build/
    - Uses backend report-error logic as source of truth
    - Returns deterministic formatted output
    """
    repo_root, project_name, report_path = _locate_report_html()

    report_bytes = Path(report_path).read_bytes()
    api_result = _call_report_errors_api(report_bytes, project_name)
    if api_result.get("status") != "success":
        return {
            "status": "error",
            "repo_root": repo_root,
            "project_name": project_name,
            "report_file": report_path,
            "api_result": api_result,
            "formatted_output": "Solution 1\nCompare changes\nPatch Plan\nBrief explanation of failure\nWhat value/config caused issue\nWhat this solution corrects\nRequired Changes\nStep 1 â€” API returned error\nFile: `N/A`\nFind: `N/A`\nReplace: `N/A`\nValidation\nRe-run build\nConfirm report.html clean\nConfirm build success",
        }

    return {
        "status": "success",
        "repo_root": repo_root,
        "project_name": project_name,
        "report_file": report_path,
        "api_result": api_result,
        "formatted_output": _format_copilot_output(api_result),
    }


def handle_copilot_from_report_html(html: str, project_name: str) -> Dict:
    """
    Copilot/MCP path:
    - report.html is discovered by Copilot in local workspace
    - html + project_name are sent to backend through MCP
    - backend computes recommendations and returns deterministic output
    """
    project_name = (project_name or "").strip().lower()
    session_info = touch_copilot_session(
        project_name=project_name,
        actor_id="global",
        ttl_hours=24,
    )
    report_bytes = (html or "").encode("utf-8", errors="ignore")
    api_result = _call_report_errors_api(report_bytes, project_name)
    return {
        "status": api_result.get("status", "error"),
        "session": session_info,
        "api_result": api_result,
        "formatted_output": _format_copilot_output(api_result),
    }


def _call_report_errors_api(report_bytes: bytes, project_name: str) -> Dict:
    boundary = f"----codex-boundary-{uuid.uuid4().hex}"
    project_bytes = (project_name or "").encode("utf-8")
    body = (
        f"--{boundary}\r\n"
        "Content-Disposition: form-data; name=\"file\"; filename=\"report.html\"\r\n"
        "Content-Type: text/html\r\n\r\n"
    ).encode("utf-8") + (report_bytes or b"") + (
        f"\r\n--{boundary}\r\n"
        "Content-Disposition: form-data; name=\"project_name\"\r\n\r\n"
    ).encode("utf-8") + project_bytes + (
        f"\r\n--{boundary}--\r\n"
    ).encode("utf-8")

    req = urllib_request.Request(
        config.REPORT_ERRORS_API_URL,
        data=body,
        method="POST",
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Accept": "application/json",
        },
    )
    with urllib_request.urlopen(req, timeout=config.REPORT_ERRORS_TIMEOUT_SEC) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _cleanup_expired_mcp_uploads():
    now = datetime.now(UTC).timestamp()
    expired = []
    with _mcp_upload_lock:
        for upload_id, meta in _mcp_upload_state.items():
            if now - meta.get("updated_ts", now) > _MCP_UPLOAD_TTL_SEC:
                expired.append(upload_id)
        for upload_id in expired:
            meta = _mcp_upload_state.pop(upload_id, {})
            path = meta.get("path")
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except OSError:
                    pass


def handle_copilot_report_upload_start(project_name: str) -> Dict:
    _cleanup_expired_mcp_uploads()
    upload_id = str(uuid.uuid4())
    path = os.path.join(MCP_REPORT_DIR, f"{upload_id}.part")
    with open(path, "wb"):
        pass

    with _mcp_upload_lock:
        _mcp_upload_state[upload_id] = {
            "project_name": (project_name or "").strip().lower(),
            "path": path,
            "created_ts": datetime.now(UTC).timestamp(),
            "updated_ts": datetime.now(UTC).timestamp(),
            "size": 0,
        }

    return {
        "status": "ok",
        "upload_id": upload_id,
        "chunk_encoding": "base64",
        "ttl_seconds": _MCP_UPLOAD_TTL_SEC,
    }


def handle_copilot_report_upload_append(upload_id: str, chunk_b64: str, is_last: bool = False) -> Dict:
    _cleanup_expired_mcp_uploads()
    if not upload_id:
        raise ValueError("upload_id is required")
    if chunk_b64 is None:
        raise ValueError("chunk_b64 is required")

    with _mcp_upload_lock:
        meta = _mcp_upload_state.get(upload_id)

    if not meta:
        raise ValueError("upload_id not found or expired")

    chunk = base64.b64decode(chunk_b64.encode("utf-8"))
    with open(meta["path"], "ab") as fp:
        fp.write(chunk)

    with _mcp_upload_lock:
        meta["updated_ts"] = datetime.now(UTC).timestamp()
        meta["size"] = int(meta.get("size", 0)) + len(chunk)
        _mcp_upload_state[upload_id] = meta

    if not is_last:
        return {
            "status": "ok",
            "upload_id": upload_id,
            "received_bytes": meta["size"],
            "finalized": False,
        }

    with open(meta["path"], "rb") as fp:
        report_bytes = fp.read()

    try:
        api_result = _call_report_errors_api(report_bytes, meta["project_name"])
        formatted_output = _format_copilot_output(api_result)
        return {
            "status": api_result.get("status", "error"),
            "upload_id": upload_id,
            "received_bytes": meta["size"],
            "finalized": True,
            "formatted_output": formatted_output,
            "api_result": api_result,
        }
    finally:
        with _mcp_upload_lock:
            _mcp_upload_state.pop(upload_id, None)
        try:
            os.remove(meta["path"])
        except OSError:
            pass
###login
def handle_login(payload: Dict) -> Dict:
    """
    Simple credential check using env-configured username/password.
    """
    if not isinstance(payload, dict):
        return {"success": False, "error": "Invalid JSON body"}

    username = str(payload.get("username") or "").strip()
    password = str(payload.get("password") or "").strip()
    if not username or not password:
        return {"success": False, "error": "username and password are required"}

    expected_user = (config.LOGIN_USERNAME or "").strip()
    expected_pass = (config.LOGIN_PASSWORD or "").strip()
    if not expected_user or not expected_pass:
        return {"success": False, "error": "login is not configured on the server"}

    if username == expected_user and password == expected_pass:
        return {"success": True, "token": str(uuid.uuid4()), "message": "login ok"}

    return {"success": False, "error": "invalid credentials"}
####
def handle_get_project_names() -> Dict:
    """
    Return unique sorted project name list (names only).
    """
    projects = _cached_all_projects()
    names = sorted({(p.get("project_name") or "").strip() for p in projects if p.get("project_name")})
    return {"success": True, "projects": names}


def handle_get_all_project_names() -> Dict:
    """
    Return all unique project names as a numbered list for the /get-all-project-name endpoint.
    """
    try:
        projects = get_all_projects() or []
        names = sorted({(p.get("project_name") or "").strip() for p in projects if p.get("project_name")})
        data = [{"id": i + 1, "name": name} for i, name in enumerate(names)]
        return {
            "success": True,
            "data": data,
            "message": "Projects retrieved successfully",
        }
    except Exception as exc:
        logger.exception("handle_get_all_project_names failed")
        return {
            "success": False,
            "data": [],
            "message": str(exc),
        }


###injection

logger = logging.getLogger(__name__)

MAX_DOC_CHUNK_LEN = 1200
MIN_DOC_CHUNK_LEN = 160
MERGE_TARGET_LEN = 900


def _document_signature_hash_from_text(text: str) -> str:
    import hashlib
    normalized = re.sub(r"\s+", " ", (text or "").strip().lower())
    return hashlib.sha1(normalized.encode("utf-8")).hexdigest()


def _normalize_document_text(text: str) -> str:
    if not text:
        return ""

    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _extract_text_from_uploaded_file(file_bytes: bytes, file_name: str) -> str:
    lower_name = (file_name or "").lower()
    if lower_name.endswith(".pdf"):
        return extract_text(BytesIO(file_bytes))
    return file_bytes.decode("utf-8", errors="replace")


def _line_alpha_count(line: str) -> int:
    return sum(1 for ch in line if ch.isalpha())


def _is_probable_heading(line: str) -> bool:
    s = (line or "").strip()
    if not s:
        return False

    if len(s) > 120:
        return False

    alpha_count = _line_alpha_count(s)
    if alpha_count == 0:
        return False

    if s.endswith(".") and len(s) > 40:
        return False

    words = s.split()
    if len(words) > 14:
        return False

    upper_ratio = sum(1 for c in s if c.isupper()) / max(1, alpha_count)
    title_case_ratio = sum(1 for w in words if w[:1].isupper()) / max(1, len(words))

    numbered_heading = bool(re.match(r"^\d+(\.\d+)*[\)\.]?\s+\S+", s))
    roman_heading = bool(re.match(r"^(?:[IVXLC]+)[\)\.]?\s+\S+", s))
    short_label_heading = bool(re.match(r"^[A-Za-z][A-Za-z0-9 _/\-&]{1,60}:?$", s))

    if numbered_heading or roman_heading:
        return True

    if len(words) <= 8 and (upper_ratio > 0.65 or title_case_ratio > 0.7):
        return True

    if short_label_heading and len(words) <= 10 and not s.endswith(","):
        return True

    return False


def _is_bullet_line(line: str) -> bool:
    return bool(re.match(r"^\s*([•\-\*\u2022]|\d+[.)]|[a-zA-Z][.)])\s+", line or ""))


def _split_into_structural_blocks(text: str) -> List[str]:
    text = _normalize_document_text(text)
    if not text:
        return []

    lines = text.split("\n")
    blocks: List[str] = []
    current: List[str] = []

    for line in lines:
        raw = line.rstrip()
        stripped = raw.strip()

        if not stripped:
            if current and current[-1] != "":
                current.append("")
            continue

        if _is_probable_heading(stripped) and current:
            block_text = "\n".join(current).strip()
            if block_text:
                blocks.append(block_text)
            current = [stripped]
            continue

        current.append(raw)

    if current:
        block_text = "\n".join(current).strip()
        if block_text:
            blocks.append(block_text)

    return blocks


def _extract_block_title(block_text: str, default_title: str) -> str:
    lines = [ln.strip() for ln in block_text.splitlines() if ln.strip()]
    if not lines:
        return default_title

    first = lines[0]
    if _is_probable_heading(first):
        return first

    for line in lines[:3]:
        if 3 <= len(line) <= 80:
            return line

    return default_title


def _merge_related_blocks(
    blocks: List[str],
    max_len: int = MAX_DOC_CHUNK_LEN,
    merge_target_len: int = MERGE_TARGET_LEN,
) -> List[Dict]:
    merged: List[Dict] = []
    buffer_parts: List[str] = []
    chunk_index = 1

    def flush():
        nonlocal buffer_parts, chunk_index
        if not buffer_parts:
            return

        combined = "\n\n".join(buffer_parts).strip()
        if combined:
            merged.append({
                "chunk_no": chunk_index,
                "title": _extract_block_title(combined, f"Chunk {chunk_index}"),
                "text": combined,
            })
            chunk_index += 1
        buffer_parts = []

    for block in blocks:
        if not buffer_parts:
            buffer_parts.append(block)
            continue

        candidate = "\n\n".join(buffer_parts + [block]).strip()

        if len(candidate) <= merge_target_len:
            buffer_parts.append(block)
        elif len(candidate) <= max_len:
            buffer_parts.append(block)
            flush()
        else:
            flush()
            buffer_parts.append(block)

    flush()
    return merged


def _split_paragraphs(text: str) -> List[str]:
    return [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]


def _split_bullet_group(paragraph: str) -> List[str]:
    lines = [ln.rstrip() for ln in paragraph.splitlines() if ln.strip()]
    if not lines:
        return []

    bullet_count = sum(1 for line in lines if _is_bullet_line(line))
    if bullet_count < 2:
        return [paragraph.strip()]

    groups: List[str] = []
    current: List[str] = []

    for line in lines:
        if _is_bullet_line(line):
            if current:
                groups.append("\n".join(current).strip())
            current = [line]
        else:
            current.append(line)

    if current:
        groups.append("\n".join(current).strip())

    return [g for g in groups if g]


def _safe_fixed_split(text: str, max_len: int = MAX_DOC_CHUNK_LEN) -> List[str]:
    text = text.strip()
    if not text:
        return []

    if len(text) <= max_len:
        return [text]

    chunks: List[str] = []
    start = 0

    while start < len(text):
        end = min(start + max_len, len(text))

        if end < len(text):
            split_pos = text.rfind("\n", start, end)
            if split_pos == -1:
                split_pos = text.rfind(". ", start, end)
            if split_pos == -1:
                split_pos = text.rfind(" ", start, end)
            if split_pos == -1 or split_pos <= start:
                split_pos = end
            else:
                if text[split_pos:split_pos + 2] == ". ":
                    split_pos += 1
        else:
            split_pos = end

        part = text[start:split_pos].strip()
        if part:
            chunks.append(part)

        start = split_pos

    return chunks


def _split_chunk_further(chunk: Dict, max_len: int = MAX_DOC_CHUNK_LEN) -> List[Dict]:
    text = str(chunk.get("text") or "").strip()
    if not text:
        return []

    if len(text) <= max_len:
        return [chunk]

    paragraphs = _split_paragraphs(text)
    pieces: List[str] = []

    for p in paragraphs:
        pieces.extend(_split_bullet_group(p))

    results: List[str] = []
    buffer = ""

    for piece in pieces:
        piece = piece.strip()
        if not piece:
            continue

        if not buffer:
            if len(piece) <= max_len:
                buffer = piece
            else:
                results.extend(_safe_fixed_split(piece, max_len=max_len))
            continue

        candidate = f"{buffer}\n\n{piece}".strip()
        if len(candidate) <= max_len:
            buffer = candidate
        else:
            results.append(buffer)
            if len(piece) <= max_len:
                buffer = piece
            else:
                split_parts = _safe_fixed_split(piece, max_len=max_len)
                if split_parts:
                    results.extend(split_parts[:-1])
                    buffer = split_parts[-1]
                else:
                    buffer = ""

    if buffer.strip():
        results.append(buffer.strip())

    return [
        {
            "chunk_no": idx,
            "title": chunk.get("title") or f"Chunk {idx}",
            "text": part,
        }
        for idx, part in enumerate(results, start=1)
        if part.strip()
    ]


def build_document_chunks(text: str, max_len: int = MAX_DOC_CHUNK_LEN) -> List[Dict]:
    text = _normalize_document_text(text)
    if not text:
        return []

    blocks = _split_into_structural_blocks(text)
    if not blocks:
        return []

    merged = _merge_related_blocks(blocks, max_len=max_len)

    final_chunks: List[Dict] = []
    final_index = 1

    for item in merged:
        smaller_chunks = _split_chunk_further(item, max_len=max_len)
        for chunk in smaller_chunks:
            chunk_text = str(chunk.get("text") or "").strip()
            if not chunk_text:
                continue

            if final_chunks and len(chunk_text) < MIN_DOC_CHUNK_LEN:
                candidate = f"{final_chunks[-1]['text']}\n\n{chunk_text}".strip()
                if len(candidate) <= max_len:
                    final_chunks[-1]["text"] = candidate
                    continue

            final_chunks.append({
                "chunk_no": final_index,
                "title": chunk.get("title") or f"Chunk {final_index}",
                "text": chunk_text,
            })
            final_index += 1

    return final_chunks


def _new_chroma_collection(name):
    """Lazily open a local Chroma collection. Imports chromadb only when a local store is actually
    needed (never in AZURE_ONLY), so the chromadb package can be uninstalled when running on Azure."""
    import chromadb
    return chromadb.PersistentClient(path=config.CHROMA_VECTOR_STORE_PATH).get_or_create_collection(name=name)


def get_document_chroma_collection():
    from src.azure_search.azure_collection import open_collection  # T3: Azure read / dual-write / azure-only
    return open_collection(
        config.CHROMA_COLLECTION_DOCS,
        lambda: _new_chroma_collection(config.CHROMA_COLLECTION_DOCS))


def get_artifact_chroma_collection():
    from src.azure_search.azure_collection import open_collection  # T3: Azure read / dual-write / azure-only
    return open_collection(
        config.CHROMA_COLLECTION_ARTIFACTS,
        lambda: _new_chroma_collection(config.CHROMA_COLLECTION_ARTIFACTS))

from src.utils.oai_client import (
    create_embedding,
    analyze_errors_and_solutions,
    summarize_artifact_content_for_embedding,
    analyze_errors_and_solutions_with_combined_context,
    analyze_with_unified_evidence,
    analyze_and_select_solution_with_unified_evidence,
)

def _save_text_chunks_on_vector_db_batch(vector_items: List[Dict], collection_name: str):
    from src.azure_search.azure_collection import open_collection  # T3: Azure read / dual-write / azure-only
    collection = open_collection(
        collection_name,
        lambda: _new_chroma_collection(collection_name))
    logger.debug("ChromaDB ADD | collection=%s | items_count=%d", collection.name, len(vector_items))

    ids = []
    documents = []
    embeddings = []
    metadatas = []

    for item in vector_items:
        chunk_text = item["error_message"]

        ids.append(item["vector_id"])
        documents.append(chunk_text)
        # The SAME budget the live artifact probe is embedded with (_artifact_match_scores):
        # the stored side used the embedder's defaults - the first 40 lines - while the probe
        # was embedded whole, the asymmetry already fixed on the error path.
        embeddings.append(create_embedding(chunk_text, max_chars=_ARTIFACT_EMBED_CHARS,
                                           max_lines=_ARTIFACT_EMBED_LINES))
        metadatas.append({
            # ChromaDB only accepts str | int | float | bool — never None.
            # The document-injection path does not set the artifact-only fields
            # (artifact_type, source_folder, task_path, action), so every string
            # field gets an "" fallback to keep a consistent, None-free schema.
            "project_name": item.get("project_name") or "",
            "request_id": item.get("request_id") or "",
            "batch_id": item.get("batch_id") or "",
            "file_name": item.get("file_name") or "",
            "s3_key": item.get("s3_key") or "",
            "error_signature_hash": item.get("error_signature_hash") or "",
            "artifact_type": item.get("artifact_type") or "",
            "source_folder": item.get("source_folder") or "",
            "task_path": item.get("task_path") or "",
            "developer_id": item.get("developer_id") or "",
            "action": item.get("action") or "",
            "is_artifact_summary": bool(item.get("is_artifact_summary", False)),
            "summary_model": item.get("summary_model") or "",
            "content_sha12": item.get("content_sha12") or "",
            "content_sha256": item.get("content_sha256") or "",
            "token_audit_json": item.get("token_audit_json") or "",
            "summary_total_tokens": int(item.get("summary_total_tokens") or 0),
        })

    collection.upsert(
        ids=ids,
        documents=documents,
        embeddings=embeddings,
        metadatas=metadatas,
    )
    logger.debug("ChromaDB UPSERT success | collection=%s | items_upserted=%d", collection.name, len(ids))


def save_document_chunks_on_vector_db_batch(vector_items: List[Dict]):
    _save_text_chunks_on_vector_db_batch(vector_items, config.CHROMA_COLLECTION_DOCS)


def _is_semantic_artifact_file(file_name: str) -> bool:
    lower_name = (file_name or "").strip().lower()
    return lower_name.endswith(".log") or lower_name.endswith(".txt")


def _extract_text_from_artifact_bytes(file_bytes: bytes, file_name: str) -> str:
    if not file_bytes:
        return ""
    lower_name = (file_name or "").strip().lower()
    if lower_name.endswith((".log", ".txt")):
        return file_bytes.decode("utf-8", errors="replace")
    return ""


def _persist_artifact_chunks_to_vector_db(
    *,
    project_name: str,
    file_name: str,
    s3_key: str,
    batch_id: str,
    request_id: str = "",
    artifact_type: str = "binary",
    action: str = "uploaded",
    source_folder: str = "",
    task_path: str = "",
    developer_id: str = "",
    is_artifact_summary: bool = True,
    summary_model: str = "",
    content_sha12: str = "",
    content_sha256: str = "",
    token_audit_json: str = "",
    summary_total_tokens: int = 0,
    chunks: List[Dict],
) -> Dict:
    project = (project_name or "").strip().lower()
    if not project:
        return {"success": False, "error": "project_name is required"}

    vector_items: List[Dict] = []
    for chunk in chunks:
        chunk_text = str(chunk.get("text") or "").strip()
        if not chunk_text:
            continue

        chunk_no = int(chunk.get("chunk_no") or 0)
        title = str(chunk.get("title") or "").strip()
        vector_id = str(uuid.uuid4())
        artifact_signature_hash = _document_signature_hash_from_text(chunk_text)
        vector_request_id = request_id or f"{batch_id}-{chunk_no}"

        vector_items.append({
            "vector_id": vector_id,
            "project_name": project,
            "error_message": chunk_text,
            "error_signature_hash": artifact_signature_hash,
            "batch_id": batch_id,
            "request_id": vector_request_id,
            "s3_key": s3_key,
            "file_name": file_name,
            "artifact_type": artifact_type,
            "action": action,
            "source_folder": source_folder,
            "task_path": task_path,
            "developer_id": str(developer_id or "").strip().lower(),
            "title": title,
            "is_artifact_summary": bool(is_artifact_summary),
            "summary_model": str(summary_model or "").strip(),
            "content_sha12": str(content_sha12 or "").strip(),
            "content_sha256": str(content_sha256 or "").strip(),
            "token_audit_json": str(token_audit_json or "").strip(),
            "summary_total_tokens": int(summary_total_tokens or 0),
        })

    if not vector_items:
        return {"success": False, "error": "no valid text chunks created from artifact"}

    _save_text_chunks_on_vector_db_batch(vector_items, config.CHROMA_COLLECTION_ARTIFACTS)

    for item in vector_items:
        try:
            save_vector_reference(
                request_id=item["request_id"],
                vector_id=item["vector_id"],
                project_name=item["project_name"],
                env="manual",
                s3_key=item.get("s3_key") or "",
                file_name=item.get("file_name") or "",
                error_signature_hash=item.get("error_signature_hash") or "",
            )
        except ClientError:
            logger.exception(
                "Failed to persist artifact vector metadata for request_id=%s",
                item.get("request_id"),
            )

    return {
        "success": True,
        "project_name": project,
        "file_name": file_name,
        "s3_key": s3_key,
        "batch_id": batch_id,
        "count": len(vector_items),
        "collection_name": config.CHROMA_COLLECTION_ARTIFACTS,
        "artifact_type": artifact_type,
    }


_S3_SHA12_RE = re.compile(r"-([0-9a-fA-F]{12})\.zip$")


def _sha12_from_s3_key(s3_key: str) -> str:
    """The artifact S3 key embeds the file's content sha256[:12] suffix — the duplicate-content
    fingerprint shared by every copy of the same file across builds."""
    m = _S3_SHA12_RE.search(str(s3_key or "").strip())
    return m.group(1).lower() if m else ""


def _parse_token_audit(raw) -> Dict:
    """Parse the token_audit_json metadata back into the per-artifact audit object. Returns {} when
    absent or malformed (older artifacts summarised before the audit was captured carry none)."""
    s = str(raw or "").strip()
    if not s:
        return {}
    try:
        val = json.loads(s)
        return val if isinstance(val, dict) else {}
    except Exception:
        return {}


def _stage_value(s: Dict) -> int:
    """The single number shown for a stage tag: prefer the stage total, else input, else output
    (recomputed large files only know per-part input, so that is shown)."""
    for k in ("total", "input", "output"):
        v = (s or {}).get(k)
        if v is not None:
            return int(v)
    return 0


def _token_usage_view(tu: Dict) -> Dict:
    """Build the dashboard presentation (flat key/value `tags`) FROM the stored raw token data, at
    API time. Because it reads input_chars/steps/totals (which every audited record already has,
    including older ones), the UI shape can change with NO re-store / backfill. Returns {} when there
    is no token data. Records already stored in the flat `tags` form are passed through."""
    if not isinstance(tu, dict) or not tu:
        return {}
    if tu.get("tags"):  # already presentation form (forward-compatible)
        view = {"mode": tu.get("mode", ""), "source": tu.get("source", ""), "tags": tu["tags"]}
        if tu.get("token_basis"):
            view["token_basis"] = tu["token_basis"]
        if tu.get("note"):
            view["note"] = tu["note"]
        return view

    ic = tu.get("input_chars") or {}
    steps = tu.get("steps") or []
    totals = tu.get("totals") or {}
    mode = tu.get("mode") or ("map-reduce" if len(steps) > 1 else "single-call")
    view = {"mode": mode, "source": tu.get("source", "")}
    if tu.get("token_basis"):
        view["token_basis"] = tu["token_basis"]
    if tu.get("note"):
        view["note"] = tu["note"]

    tags: List[Dict] = []
    oc = int(ic.get("original") or 0)
    rc = int(ic.get("after_reduction") or 0)
    pct = int(ic.get("reduced_pct") or 0)
    if oc:
        tags.append({"key": "Input", "value": f"{oc:,} -> {rc:,} chars ({pct}% reduced)"})
    if mode == "single-call":
        tags.append({"key": "Tokens in", "value": int(totals.get("input") or 0)})
        tags.append({"key": "Tokens out", "value": int(totals.get("output") or 0)})
        tags.append({"key": "Total", "value": int(totals.get("total") or 0)})
    else:
        stage = 0
        for s in steps:
            nm = str(s.get("step") or "").lower()
            if "combine" in nm or "reduce" in nm:
                key = "Combine"
            else:
                stage += 1
                key = f"Stage {stage}"
            tags.append({"key": key, "value": _stage_value(s)})
        tags.append({"key": "Total", "value": int(totals.get("total") or 0)})
    view["tags"] = tags
    return view


def _find_previous_artifact_text(project_name: str, task_path: str, file_name: str,
                                 current_sha256: str, current_s3_key: str,
                                 developer_id: str = "") -> str:
    """Best-effort lookup of the PREVIOUS run's text for the SAME file (same project + task +
    file_name, different content), for the opt-in diff-vs-previous-run summary. Reuses the existing
    ChromaDB artifact collection to locate prior versions and S3 for the bytes — no new index, no
    schema change. Returns "" when there is no usable previous version.

    When developer_id is given, PREFER the same developer's prior versions (the user's own
    fail->success cycle) so concurrent users on the same file are never mixed; falls back to any
    prior version when none of the same user's are found (e.g. old records with no developer_id)."""
    proj = str(project_name or "").strip().lower()
    fname = str(file_name or "").strip()
    if not proj or not fname:
        return ""
    try:
        conds = [{"project_name": proj}, {"file_name": fname}, {"is_artifact_summary": True}]
        tp = str(task_path or "").strip()
        if tp:
            conds.append({"task_path": tp})
        res = get_artifact_chroma_collection().get(where={"$and": conds}, include=["metadatas"], limit=50)
    except Exception:
        return ""
    cur_key = str(current_s3_key or "").strip().rstrip('"').rstrip("%22")
    cur_sha = str(current_sha256 or "").strip()
    cur_dev = str(developer_id or "").strip().lower()
    candidates = []  # (s3_key, developer_id) for each distinct prior version
    for m in (res.get("metadatas") or []):
        if not isinstance(m, dict):
            continue
        k = str(m.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
        sha = str(m.get("content_sha256") or "").strip()
        if k and k != cur_key and (not sha or sha != cur_sha):
            candidates.append((k, str(m.get("developer_id") or "").strip().lower()))
    if not candidates:
        return ""
    # Prefer the SAME developer's prior versions (their own fail->success cycle); only if we know the
    # developer AND at least one prior version carries it. Otherwise use all (cross-user fallback).
    if cur_dev:
        same_user = [c for c in candidates if c[1] and c[1] == cur_dev]
        if same_user:
            candidates = same_user
    candidate_keys = {k for (k, _d) in candidates}
    cli = get_s3_client()
    # Most recent prior version (by S3 LastModified) is the "previous run".
    best_key, best_lm = "", None
    for k in candidate_keys:
        try:
            lm = cli.head_object(Bucket=S3_BUCKET, Key=k).get("LastModified")
        except Exception:
            lm = None
        if not best_key or (lm is not None and (best_lm is None or lm > best_lm)):
            best_key, best_lm = k, lm
    try:
        body = cli.get_object(Bucket=S3_BUCKET, Key=best_key)["Body"].read()
        with ZipFile(BytesIO(body), "r") as zf:
            names = zf.namelist()
            raw = zf.read(names[0]) if names else b""
        return raw.decode("utf-8", errors="replace")
    except Exception:
        logger.warning("previous-run S3 fetch failed | key=%s", best_key)
        return ""


def _artifact_diff_link(s3_key: str, project_name: str = "") -> str:
    key = str(s3_key or "").strip()
    if not key:
        return ""
    return (f"{config.BACKEND_PUBLIC_BASE_URL}/artifact-diff"
            f"?s3_key={quote(key, safe='')}&project={quote(str(project_name or ''), safe='')}")


def handle_artifact_diff(s3_key: str, project_name: str = "") -> Dict | None:
    """Read-only: return the ORIGINAL artifact text and the KEPT text (basic noise strip +
    changed-content vs previous run), so the dashboard can show a side-by-side diff of what is cut
    vs what actually changed. The original is read from S3 (zip), 'kept' is recomputed - nothing is
    stored or changed."""
    from src.utils.oai_client import artifact_reduced_text_for_view
    key = str(s3_key or "").strip().rstrip('"').rstrip("%22")
    if not key:
        return None
    meta: Dict = {}
    try:
        r = get_artifact_chroma_collection().get(where={"s3_key": key}, include=["metadatas"], limit=1)
        ms = r.get("metadatas") or []
        meta = ms[0] if ms and isinstance(ms[0], dict) else {}
    except Exception:
        logger.warning("artifact-diff meta lookup failed | key=%s", key)
    proj = str(project_name or meta.get("project_name") or "").strip().lower()
    file_name = str(meta.get("file_name") or os.path.basename(key))
    task_path = str(meta.get("task_path") or "")
    developer_id = str(meta.get("developer_id") or "")  # internal scoping only — never shown on the UI
    sha = str(meta.get("content_sha256") or "")
    original = ""
    try:
        body = get_s3_client().get_object(Bucket=S3_BUCKET, Key=key)["Body"].read()
        with ZipFile(BytesIO(body), "r") as zf:
            names = zf.namelist()
            original = zf.read(names[0]).decode("utf-8", errors="replace") if names else ""
    except Exception as ex:
        logger.warning("artifact-diff original fetch failed | key=%s | %s", key, ex)
    previous = _find_previous_artifact_text(proj, task_path, file_name, sha, key, developer_id) if proj else ""
    kept = artifact_reduced_text_for_view(file_name, original, previous)
    return {"file_name": file_name, "original": original, "kept": kept, "previous": previous,
            "original_chars": len(original), "kept_chars": len(kept),
            "previous_chars": len(previous), "had_previous": bool(previous)}


_ARTIFACT_SUMMARY_CACHE: Dict[str, tuple] = {}   # project -> (expires_epoch, lookup)


def _artifact_summaries_for_project(project_name: str, limit: int = 2000) -> Dict[str, dict]:
    """Build a lookup {s3_key -> entry} AND {'sha:'+content_sha12 -> entry} for a project's
    artifacts, read from the ChromaDB artifact collection. Each entry is
    {"summary": <document text>, "token_usage": <parsed token audit or {}>}. Duplicate file copies
    (same content, different builds/keys) share ONE stored record; the sha keys let every copy
    resolve to it. get(where=...) reads storage, not the vector index.

    Successful results are cached in-process for ARTIFACT_SUMMARY_CACHE_TTL_SEC (default 120s,
    0 = off) — summaries only change on upload, and this read is on the dashboard hot path.
    Failures are NOT cached, so a transient vector-store error never hides summaries for the TTL."""
    proj = str(project_name or "").strip().lower()
    if not proj:
        return {}
    # SCOPE: under group scope this must read the whole group, or a sibling candidate is
    # retrievable but has no summary to score. The CACHE KEY carries the scope, otherwise a
    # project-scoped entry and a group-scoped one overwrite each other and the answer depends on
    # whoever asked first.
    _members, _mode = _reco_scope_members(proj)
    cache_key = proj if _mode != "group" else "group:" + ",".join(_members)
    ttl = max(0, int(os.getenv("ARTIFACT_SUMMARY_CACHE_TTL_SEC", "120")))
    if ttl:
        hit = _ARTIFACT_SUMMARY_CACHE.get(cache_key)
        if hit and hit[0] > time.time():
            return hit[1]
    try:
        col = get_artifact_chroma_collection()
        from src.services.project_groups import scope_where as _scope_where
        res = col.get(where=_scope_where(proj, members=_members),
                      include=["documents", "metadatas"], limit=max(1, int(limit)))
    except Exception:
        logger.exception("artifact summaries fetch failed | project=%s", proj)
        return {}
    docs = res.get("documents") or []
    metas = res.get("metadatas") or []
    out: Dict[str, dict] = {}
    for i, meta in enumerate(metas):
        if not isinstance(meta, dict):
            continue
        doc = str(docs[i] if i < len(docs) else "")
        entry = {"summary": doc,
                 "token_usage": _token_usage_view(_parse_token_audit(meta.get("token_audit_json")))}
        s3 = str(meta.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
        if s3 and s3 not in out:
            out[s3] = entry
        sha = str(meta.get("content_sha12") or "").strip().lower() or _sha12_from_s3_key(s3)
        if sha and f"sha:{sha}" not in out:
            out[f"sha:{sha}"] = entry
    if ttl:
        _ARTIFACT_SUMMARY_CACHE[cache_key] = (time.time() + ttl, out)
    return out


def _is_noise_artifact_file(file_name: str) -> bool:
    """Noise/metadata artifacts (e.g. process-id.txt) carry no failure signal. Exclude them at
    INGESTION so they are never embedded and RRF can never pick them as evidence. Configurable via
    ARTIFACT_NOISE_FILES (comma-separated basenames, case-insensitive; default 'process-id.txt')."""
    name = os.path.basename(str(file_name or "").replace("\\", "/")).strip().lower()
    if not name:
        return False
    raw = os.getenv("ARTIFACT_NOISE_FILES", "process-id.txt")
    excluded = {p.strip().lower() for p in raw.split(",") if p.strip()}
    return name in excluded


def handle_artifact_text_embedding(
    *,
    project_name: str,
    file_name: str,
    file_bytes: bytes,
    s3_key: str,
    batch_id: str,
    request_id: str = "",
    artifact_type: str = "binary",
    action: str = "uploaded",
    source_folder: str = "",
    task_path: str = "",
    developer_id: str = "",
) -> Dict:
    if not _is_semantic_artifact_file(file_name):
        return {
            "success": False,
            "skipped": True,
            "reason": "artifact is not a .log or .txt file",
        }

    # Noise exclusion at the START (per client): drop junk/metadata files (e.g. process-id.txt)
    # before embedding, so RRF only ever has real evidence to pick from.
    if _is_noise_artifact_file(file_name):
        logger.info("Artifact '%s' excluded as noise — not embedded (ARTIFACT_NOISE_FILES)", file_name)
        return {
            "success": False,
            "skipped": True,
            "reason": f"artifact '{file_name}' excluded as noise",
        }

    try:
        text = _extract_text_from_artifact_bytes(file_bytes=file_bytes, file_name=file_name)
    except Exception as exc:
        logger.exception("Artifact text extraction failed for file=%s", file_name)
        return {"success": False, "error": f"artifact text extraction failed: {exc}"}

    if not text or not text.strip():
        return {"success": False, "error": "artifact text is empty"}

    # Content dedup: the SAME file content uploaded across many builds must produce ONE summary,
    # not one per copy (unique summaries, no repeats). The content hash matches the sha12 suffix in
    # the S3 key. If a summary for this exact content already exists in the artifact collection,
    # skip the LLM call and the duplicate vector; the dashboard resolves duplicates by this hash.
    # ARTIFACT_SUMMARY_DEDUP=0 bypasses the skip — used to force a full live-cycle validation run
    # (capture -> compress -> summarise -> store) even for already-known content.
    summary_dedup_on = str(os.getenv("ARTIFACT_SUMMARY_DEDUP", "1")).strip().lower() not in ("0", "false", "no", "off")
    # The FULL sha256 is the collision-safe dedup identity. content_sha12 (first 12 hex) is retained
    # only as the short suffix in the S3 key and for dashboard grouping — it must NOT be the skip
    # decision: 48 bits can collide for two DIFFERENT files and would then wrongly skip the second
    # file's summary (silent data loss). Matches the full-sha256 identity used by s3_dedup.
    content_sha256 = hashlib.sha256(file_bytes or b"").hexdigest()
    content_sha12 = content_sha256[:12]
    if summary_dedup_on:
        try:
            coll = get_artifact_chroma_collection()
            existing = coll.get(where={"content_sha256": content_sha256}, limit=1)
            if not (existing.get("ids") or []):
                # Legacy fallback: records written before content_sha256 existed carry only
                # content_sha12. Match those by sha12, but REJECT a same-sha12 record that carries a
                # DIFFERENT full hash (that is a 48-bit collision, not a real duplicate).
                legacy = coll.get(where={"content_sha12": content_sha12},
                                  include=["metadatas"], limit=5)
                metas = legacy.get("metadatas") or []
                if (legacy.get("ids") or []) and any(
                    str((m or {}).get("content_sha256") or "") in ("", content_sha256) for m in metas):
                    existing = legacy
            if (existing.get("ids") or []):
                logger.info(
                    "Artifact '%s' content already summarised (sha256=%s) — skipping duplicate summary",
                    file_name, content_sha256,
                )
                return {"success": True, "skipped": True, "deduplicated": True,
                        "reason": f"duplicate content (sha256 {content_sha256}) — summary already exists"}
        except Exception:
            # Dedup check is best-effort; on failure proceed as a normal upload.
            logger.warning("artifact content-dedup check failed | file=%s | sha256=%s", file_name, content_sha256)
    else:
        logger.info("Artifact summary dedup BYPASSED (ARTIFACT_SUMMARY_DEDUP=0) | file=%s | sha256=%s",
                    file_name, content_sha256)

    # Diff-vs-previous-run (opt-in, default OFF; large files only). Fetch the previous run's text so
    # the summariser can describe just what changed. Reuses the artifact collection + S3 — no new
    # index. Any failure leaves previous_text="" -> existing full-summary behaviour, unchanged.
    previous_text = ""
    diff_on = str(os.getenv("ARTIFACT_DIFF_SUMMARY", "0")).strip().lower() in ("1", "true", "yes", "on")
    if diff_on and len(text or "") > int(os.getenv("ARTIFACT_CHUNK_CHARS", "50000")):
        try:
            previous_text = _find_previous_artifact_text(
                project_name, task_path, file_name, content_sha256, s3_key, developer_id)
        except Exception:
            logger.warning("previous-run lookup failed | file=%s", file_name)
            previous_text = ""

    summarized_text = ""
    summary_usage: Dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    if getattr(config, "LLM_ANALYSIS_ENABLED", True):
        try:
            summarized_text, summary_usage = summarize_artifact_content_for_embedding(
                file_name=file_name,
                artifact_text=text,
                request_id=request_id or batch_id,
                previous_text=previous_text,
            )
        except (RateLimitError, APITimeoutError, APIConnectionError) as exc:
            # TRANSIENT failure (429 exhausted, connect/read timeout, connection error): return a
            # RETRYABLE failure. Do NOT fall through to the raw-text fallback — that would chunk-embed
            # the raw content as the "summary" and the content-dedup would then permanently block a
            # proper summary for this file. The raw file is safe in S3; the backfill script picks it
            # up on the next run.
            logger.error("Artifact '%s' NOT embedded — transient LLM failure (%s); retry later via backfill",
                         file_name, type(exc).__name__)
            return {"success": False, "rate_limited": True, "transient": True,
                    "error": f"transient LLM failure ({type(exc).__name__}) — summary not generated; retry later"}
    if not summarized_text:
        # Fail-open fallback: keep pipeline operational if summary LLM is unavailable.
        summarized_text = text[:max(2000, int(os.getenv("ARTIFACT_SUMMARY_INPUT_CHARS", "600000")))]
    else:
        # Verbatim-token guarantee (hybrid fusion): an LLM summary may paraphrase the
        # discriminating literal ("wrong ctc_aurix version" instead of quoting '6.2r1p456'),
        # and then neither the lexical leg nor the embedding can grip the exact token. Append
        # the RAW failure-signal lines of the original capture to the stored document, capped,
        # only when the summary does not already quote them.
        raw_signal = _failure_signal_lines(text)[:80]
        appendix = "\n".join(raw_signal)[:6000].strip()
        if appendix and appendix not in summarized_text:
            summarized_text += "\n\nRAW FAILURE LINES (verbatim):\n" + appendix

    chunks = build_document_chunks(text=summarized_text, max_len=MAX_DOC_CHUNK_LEN)
    if not chunks:
        return {"success": False, "error": "no chunks created from artifact"}

    # Per-artifact token audit (input size before/after reduction + per-step usage + totals). Stored
    # on the ChromaDB record so the dashboard can show it next to the summary. ChromaDB metadata is
    # scalar-only, so the per-step breakdown is serialised to a JSON string; the grand total is also
    # stored as a plain number for quick reads/sorting.
    try:
        token_audit_json = json.dumps(summary_usage or {}, ensure_ascii=False, separators=(",", ":"))
    except Exception:
        token_audit_json = ""
    summary_total_tokens = 0
    if isinstance(summary_usage, dict):
        summary_total_tokens = int((summary_usage.get("totals") or {}).get("total", 0) or 0)

    persisted = _persist_artifact_chunks_to_vector_db(
        project_name=project_name,
        file_name=file_name,
        s3_key=s3_key,
        batch_id=batch_id,
        request_id=request_id,
        artifact_type=artifact_type,
        action=action,
        source_folder=source_folder,
        task_path=task_path,
        developer_id=developer_id,
        is_artifact_summary=True,
        summary_model=str(config.DEFAULT_MODEL or ""),
        content_sha12=content_sha12,
        content_sha256=content_sha256,
        token_audit_json=token_audit_json,
        summary_total_tokens=summary_total_tokens,
        chunks=chunks,
    )
    if isinstance(persisted, dict):
        persisted["summary_token_usage"] = summary_usage
        persisted["summarized_for_embedding"] = True
    return persisted

def _persist_file_chunks_to_vector_db(
    project_name: str,
    file_name: str,
    s3_key: str,
    batch_id: str,
    chunks: List[Dict],
) -> Dict:
    project = (project_name or "").strip().lower()
    if not project:
        return {"success": False, "error": "project_name is required"}

    vector_items: List[Dict] = []
    inserted: List[Dict] = []

    for chunk in chunks:
        chunk_text = str(chunk.get("text") or "").strip()
        if not chunk_text:
            continue

        chunk_no = int(chunk.get("chunk_no") or 0)
        title = str(chunk.get("title") or "").strip()
        request_id = f"{batch_id}-{chunk_no}"
        error_signature_hash = _document_signature_hash_from_text(chunk_text)
        # Deterministic ID: same content in same project always maps to the same vector,
        # so upsert below overwrites instead of creating a duplicate on re-upload.
        vector_id = f"doc-{project}-{error_signature_hash}"

        solution_payload = {
            "source": "file",
            "original_name": file_name,
            "s3_key": s3_key,
            "batch_id": batch_id,
            "chunk_no": chunk_no,
            "title": title,
            "collection_name": config.CHROMA_COLLECTION_DOCS,
            "chunking_strategy": [
                "dynamic_structure_detection",
                "paragraph_or_bullet_group_split",
                "safe_fallback_split",
            ],
        }

        vector_items.append({
            "vector_id": vector_id,
            "project_name": project,
            "error_message": chunk_text,
            "error_signature_hash": error_signature_hash,
            "all_solution": json.dumps(solution_payload, separators=(",", ":"), ensure_ascii=False),
            "batch_id": batch_id,
            "request_id": request_id,
            "s3_key": s3_key,
            "file_name": file_name,
        })

        inserted.append({
            "vector_id": vector_id,
            "request_id": request_id,
            "chunk_no": chunk_no,
            "title": title,
            "file_name": file_name,
            "s3_key": s3_key,
            "error_signature_hash": error_signature_hash,
            "preview": chunk_text[:180],
        })

    if not vector_items:
        return {"success": False, "error": "no valid text chunks created from file"}

    save_document_chunks_on_vector_db_batch(vector_items)

    for item in vector_items:
        try:
            save_vector_reference(
                request_id=item["request_id"],
                vector_id=item["vector_id"],
                project_name=item["project_name"],
                env="manual",
                s3_key=item.get("s3_key") or "",
                file_name=item.get("file_name") or "",
                error_signature_hash=item.get("error_signature_hash") or "",
            )

            error_hash = str(item.get("error_signature_hash") or "").strip()
            if error_hash:
                save_error_vector_index(
                    project_name=item["project_name"],
                    env="manual",
                    error_hash=error_hash,
                    error_message=item["error_message"],
                    vector_id=item["vector_id"],
                )

                is_new_solution_ref = save_error_solution_reference(
                    project_name=item["project_name"],
                    env="manual",
                    error_hash=error_hash,
                    request_id=item["request_id"],
                    s3_key=item.get("s3_key") or "",
                    file_name=item.get("file_name") or "",
                    task_path="",
                )

                touch_error_signature_summary(
                    project_name=item["project_name"],
                    env="manual",
                    error_hash=error_hash,
                    task_path="",
                    request_id=item["request_id"],
                    file_name=item.get("file_name") or "",
                    new_solution_reference=bool(is_new_solution_ref),
                )

        except ClientError:
            logger.exception(
                "Failed to persist vector metadata for request_id=%s",
                item.get("request_id"),
            )

    return {
        "success": True,
        "project_name": project,
        "file_name": file_name,
        "s3_key": s3_key,
        "batch_id": batch_id,
        "count": len(vector_items),
        "collection_name": config.CHROMA_COLLECTION_DOCS,
        # "vectors": inserted,
    }


def handle_file_data_injection(project_name: str, file_name: str, file_bytes: bytes) -> Dict:
    """
    Required form-data:
      - project_name
      - file
    """
    import threading

    project = (project_name or "").strip().lower()
    if not project:
        return {"success": False, "error": "project_name is required"}

    if not file_bytes:
        return {"success": False, "error": "file is empty"}

    clean_name = secure_filename(file_name or "upload.bin")
    batch_id = str(uuid.uuid4())

    def _process():
        try:
            # Upload to S3 first so the file always appears in "Recent Uploads" regardless
            # of whether text extraction succeeds. Previously this happened after extraction,
            # so files with no extractable text (scanned PDFs, etc.) were silently dropped.
            archive = upload_binary_artifact_zip(
                batch_id=batch_id,
                file_name=clean_name,
                file_bytes=file_bytes,
                action="uploaded",
                project_name=project,
            )
            s3_key = archive.get("s3_key", "")
            deduplicated = archive.get("deduplicated", False)

            # If S3 dedup hit but the file was renamed, force a new S3 key under the new name
            # so the renamed file appears separately in "Recent Uploads". Embeddings are skipped
            # since the content is identical (same chunk hashes → same vector IDs via upsert).
            if deduplicated and s3_key:
                existing_segment = re.sub(r"-[0-9a-f]{12}\.zip$", "", s3_key.split("/")[-1])
                new_segment = re.sub(r"[^a-z0-9._-]+", "-", clean_name.lower()).strip("-")
                if existing_segment.lower() != new_segment.lower():
                    logger.info(
                        "data-injection | dedup hit but name changed (%s → %s) — uploading new S3 key",
                        existing_segment, new_segment,
                    )
                    renamed_archive = upload_binary_artifact_zip(
                        batch_id=batch_id,
                        file_name=clean_name,
                        file_bytes=file_bytes,
                        action="uploaded",
                        project_name=project,
                        force_upload=True,
                    )
                    s3_key = renamed_archive.get("s3_key", s3_key)
                    logger.info(
                        "data-injection | renamed file stored | file=%s | s3_key=%s",
                        clean_name, s3_key,
                    )
                    return  # content already embedded under the same chunk hashes

            text = _extract_text_from_uploaded_file(file_bytes=file_bytes, file_name=clean_name)
            if not text or not text.strip():
                logger.warning(
                    "data-injection | no text extracted — file stored in S3 but not embedded"
                    " | file=%s | batch_id=%s | s3_key=%s",
                    clean_name, batch_id, s3_key,
                )
                return

            chunks = build_document_chunks(text=text, max_len=MAX_DOC_CHUNK_LEN)
            if not chunks:
                logger.warning(
                    "data-injection | no chunks produced — file stored in S3 but not embedded"
                    " | file=%s | batch_id=%s",
                    clean_name, batch_id,
                )
                return

            _persist_file_chunks_to_vector_db(
                project_name=project,
                file_name=clean_name,
                s3_key=s3_key,
                batch_id=batch_id,
                chunks=chunks,
            )
            logger.info(
                "data-injection | complete | file=%s | batch_id=%s | chunks=%d",
                clean_name, batch_id, len(chunks),
            )
        except Exception:
            logger.exception(
                "data-injection | background processing failed | file=%s | batch_id=%s",
                clean_name, batch_id,
            )

    threading.Thread(target=_process, daemon=True).start()

    return {
        "success": True,
        "status": "processing",
        "project_name": project,
        "file_name": clean_name,
        "batch_id": batch_id,
        "collection_name": config.CHROMA_COLLECTION_DOCS,
        "message": "File accepted and is being indexed in the background.",
    }



###get-data-injection###

def get_document_chroma_collection():
    from src.azure_search.azure_collection import open_collection  # T3: Azure read / dual-write / azure-only
    return open_collection(
        config.CHROMA_COLLECTION_DOCS,
        lambda: _new_chroma_collection(config.CHROMA_COLLECTION_DOCS))



def search_document_data_injection(query: str, project_name: str = "", top_k: int = 5, allow_global_fallback: bool = True) -> Dict:
    logger.debug("ChromaDB SEARCH | collection=%s | project=%s | top_k=%d | query=%.80s", config.CHROMA_COLLECTION_DOCS, project_name, top_k, query)
    collection = get_document_chroma_collection()
    query_embedding = create_embedding(query or "")
    normalized_project = (project_name or "").strip().lower()
    # T13: documents are global knowledge (FAQ / Confluence / shared docs) - search across ALL
    # projects. Flag-gated (config.DATA_INJECTION_GLOBAL); set 0 for project-scoped documents.
    if getattr(config, "DATA_INJECTION_GLOBAL", False):
        normalized_project = ""
    # Over-fetch candidates so post-filtering can remove duplicates while still returning top_k unique items.
    candidate_limit = max(top_k, min(max(top_k * 4, 20), 100))

    if normalized_project:
        results = collection.query(
            query_embeddings=[query_embedding],
            where={"project_name": normalized_project},
            n_results=candidate_limit,
            include=["documents", "metadatas", "distances"],
        )
        ids = (results.get("ids") or [[]])[0]
        if ids:
            logger.debug("ChromaDB SEARCH (project-scoped) | collection=%s | results=%d", config.CHROMA_COLLECTION_DOCS, len(ids))
            return results
        if not allow_global_fallback:
            logger.debug("ChromaDB SEARCH | collection=%s | project-scoped empty and global fallback disabled -> empty", config.CHROMA_COLLECTION_DOCS)
            return {"ids": [[]], "documents": [[]], "metadatas": [[]], "distances": [[]]}
        logger.warning("ChromaDB SEARCH (project-scoped) | collection=%s | NO RESULTS, falling back to global search", config.CHROMA_COLLECTION_DOCS)

    global_results = collection.query(
        query_embeddings=[query_embedding],
        n_results=candidate_limit,
        include=["documents", "metadatas", "distances"],
    )
    global_ids = (global_results.get("ids") or [[]])[0]
    if not global_ids:
        logger.warning("ChromaDB SEARCH (global) | collection=%s | NO RESULTS", config.CHROMA_COLLECTION_DOCS)
    else:
        logger.debug("ChromaDB SEARCH (global) | collection=%s | results=%d", config.CHROMA_COLLECTION_DOCS, len(global_ids))
    return global_results


def search_artifact_data_injection(query: str, project_name: str = "", top_k: int = 10, task_path: str = None, allow_global_fallback: bool = True) -> Dict:
    """
    Search artifact embeddings with optional task-based filtering.
    
    Args:
        query: Search query text
        project_name: Project name for scoping
        top_k: Number of results to return (default: 10, increased from 3)
        task_path: Optional task path for hierarchical filtering (e.g., ":TARGETS:HIP26:aramis")
    
    Returns:
        ChromaDB query results with ids, documents, metadatas, distances
    """
    normalized_task = (task_path or "").strip()
    logger.debug(
        "ChromaDB SEARCH (artifact) | collection=%s | project=%s | task=%s | top_k=%d | query=%.80s",
        config.CHROMA_COLLECTION_ARTIFACTS,
        project_name,
        normalized_task or "<none>",
        top_k,
        query,
    )
    collection = get_artifact_chroma_collection()
    query_embedding = create_embedding(query or "")
    normalized_project = (project_name or "").strip().lower()
    # T13: GLOBAL (cross-project) artifact evidence - drop the project/task filter so evidence can
    # come from ANY project. Flag-gated (config.DATA_INJECTION_GLOBAL); set 0 for project-scoped.
    if getattr(config, "DATA_INJECTION_GLOBAL", False):
        normalized_project = ""
        normalized_task = ""
        allow_global_fallback = True
    candidate_limit = max(top_k, min(max(top_k * 4, 20), 100))

    # Hierarchical task-based filtering strategy (same as historical errors)
    # 1. Exact task + project match (task_path extracted from report.html)
    # 2. Project-only match
    # 3. Global fallback
    
    if normalized_project and normalized_task:
        # Level 1: Exact task + project match
        exact_task_results = collection.query(
            query_embeddings=[query_embedding],
            where={
                "$and": [
                    {"project_name": normalized_project},
                    {"task_path": normalized_task}
                ]
            },
            n_results=candidate_limit,
            include=["documents", "metadatas", "distances"],
        )
        exact_task_ids = (exact_task_results.get("ids") or [[]])[0]
        if exact_task_ids:
            logger.debug(
                "ChromaDB SEARCH (artifact exact_task) | collection=%s | match_level=exact | results=%d",
                config.CHROMA_COLLECTION_ARTIFACTS,
                len(exact_task_ids),
            )
            # Add match level to metadata
            metadatas = (exact_task_results.get("metadatas") or [[]])[0] or []
            for meta in metadatas:
                if isinstance(meta, dict):
                    meta["task_match_level"] = "exact"
            return exact_task_results
        
        
        logger.debug(
            "ChromaDB SEARCH (artifact task-filtered) | collection=%s | NO RESULTS, falling back to project-only",
            config.CHROMA_COLLECTION_ARTIFACTS,
        )

    # Level 3: Project-only match
    if normalized_project:
        results = collection.query(
            query_embeddings=[query_embedding],
            where={"project_name": normalized_project},
            n_results=candidate_limit,
            include=["documents", "metadatas", "distances"],
        )
        ids = (results.get("ids") or [[]])[0]
        if ids:
            logger.debug(
                "ChromaDB SEARCH (artifact project-scoped) | collection=%s | match_level=project | results=%d",
                config.CHROMA_COLLECTION_ARTIFACTS,
                len(ids),
            )
            metadatas = (results.get("metadatas") or [[]])[0] or []
            for meta in metadatas:
                if isinstance(meta, dict):
                    meta["task_match_level"] = "project"
            return results
        if not allow_global_fallback:
            logger.debug(
                "ChromaDB SEARCH (artifact) | collection=%s | project-scoped empty and global fallback disabled -> empty",
                config.CHROMA_COLLECTION_ARTIFACTS,
            )
            return {"ids": [[]], "documents": [[]], "metadatas": [[]], "distances": [[]]}
        logger.warning(
            "ChromaDB SEARCH (artifact project-scoped) | collection=%s | NO RESULTS, falling back to global search",
            config.CHROMA_COLLECTION_ARTIFACTS,
        )

    # Level 4: Global fallback
    global_results = collection.query(
        query_embeddings=[query_embedding],
        n_results=candidate_limit,
        include=["documents", "metadatas", "distances"],
    )
    global_ids = (global_results.get("ids") or [[]])[0]
    if not global_ids:
        logger.warning("ChromaDB SEARCH (artifact global) | collection=%s | NO RESULTS", config.CHROMA_COLLECTION_ARTIFACTS)
    else:
        logger.debug(
            "ChromaDB SEARCH (artifact global) | collection=%s | match_level=global | results=%d",
            config.CHROMA_COLLECTION_ARTIFACTS,
            len(global_ids),
        )
        metadatas = (global_results.get("metadatas") or [[]])[0] or []
        for meta in metadatas:
            if isinstance(meta, dict):
                meta["task_match_level"] = "global"
    return global_results


# =====================================================================================
# W_artifact — the ARTIFACT-domain feedback adapter (prediction-feedback enhancement:
# one adapter per embedding domain). Mirrors the error-side learned-space fusion in
# src/utils/recommended.py: adapter ON -> the learned-space ranking is the result, OFF or
# untrained -> the base artifact result; no rank fusion. Any failure falls back to base.
# =====================================================================================
_artifact_learned_collection_cache = None


def get_artifact_learned_collection():
    global _artifact_learned_collection_cache
    if _artifact_learned_collection_cache is None:
        from src.azure_search.azure_collection import open_collection
        name = config.FEEDBACK_ADAPTER_ARTIFACT_LEARNED_COLLECTION
        _artifact_learned_collection_cache = open_collection(
            name, lambda: _new_chroma_collection(name))
    return _artifact_learned_collection_cache


def _search_artifact_learned_space(query: str, project_name: str = "", top_k: int = 10,
                                   task_path: str = None, allow_global_fallback: bool = True) -> Dict:
    """Same task/project/global scoping as search_artifact_data_injection, but in the
    ARTIFACT learned space: the query embedding is passed through W_artifact and
    unit-normalised (stored learned vectors are normalised) before matching."""
    import numpy as np
    from src.utils import feedback_adapter

    empty = {"ids": [[]], "documents": [[]], "metadatas": [[]], "distances": [[]]}
    lc = get_artifact_learned_collection()
    if lc is None:
        return empty
    base_emb = create_embedding(query or "")
    z = np.asarray(feedback_adapter.transform(base_emb, domain="artifact"), dtype=np.float64)
    zq = (z / (float(np.linalg.norm(z)) or 1e-9)).tolist()
    normalized_project = (project_name or "").strip().lower()
    normalized_task = (task_path or "").strip()
    if getattr(config, "DATA_INJECTION_GLOBAL", False):
        normalized_project = ""
        normalized_task = ""
        allow_global_fallback = True
    inc = ["documents", "metadatas", "distances"]

    def _q(**kw):
        try:
            return lc.query(query_embeddings=[zq], n_results=top_k, include=inc, **kw)
        except Exception as exc:
            logger.debug("artifact learned-space query failed | %s", exc)
            return empty

    if normalized_project and normalized_task:
        r = _q(where={"$and": [{"project_name": normalized_project}, {"task_path": normalized_task}]})
        if (r.get("ids") or [[]])[0]:
            return r
    if normalized_project:
        r = _q(where={"project_name": normalized_project})
        if (r.get("ids") or [[]])[0]:
            return r
    if not allow_global_fallback:
        return empty
    return _q()


def search_artifact_data_injection_fused(query: str, project_name: str = "", top_k: int = 10,
                                         task_path: str = None, allow_global_fallback: bool = True) -> Dict:
    """Drop-in for search_artifact_data_injection: the W_artifact learned-space ranking when
    the artifact adapter is ON for the project, exactly the base behaviour while it is OFF or
    untrained. Same rule as the error side - one space decides, no rank fusion."""
    base = search_artifact_data_injection(
        query=query, project_name=project_name, top_k=top_k,
        task_path=task_path, allow_global_fallback=allow_global_fallback,
    )
    try:
        from src.utils import feedback_adapter
        try:
            from src.services.adapter_settings import adapter_enabled_for
            runtime_on = adapter_enabled_for(project_name, domain="artifact")
        except Exception:
            runtime_on = True
        if not runtime_on or not feedback_adapter.is_active(domain="artifact"):
            return base
        learned = _search_artifact_learned_space(
            query=query, project_name=project_name, top_k=top_k,
            task_path=task_path, allow_global_fallback=allow_global_fallback,
        )
        if not ((learned.get("ids") or [[]])[0]):
            return base
        from src.utils.recommended import _pool_from
        pool = _pool_from(learned, base, "learned", top_k)
        logger.debug(
            "artifact adapter | space=learned base=%d learned=%d pool=%d",
            len((base.get("ids") or [[]])[0]), len((learned.get("ids") or [[]])[0]),
            len((pool.get("ids") or [[]])[0]),
        )
        return pool
    except Exception as exc:
        logger.warning("artifact learned-space search failed - using base ranking | %s", exc)
        return base


def get_data_injection_by_query(query: str, project_name: str = "", top_k: int = 5, allow_global_fallback: bool = True) -> Dict:
    query = (query or "").strip()
    if not query:
        return {"success": False, "error": "query is required"}

    try:
        results = search_document_data_injection(
            query=query,
            project_name=project_name,
            top_k=top_k,
            allow_global_fallback=allow_global_fallback,
        )
    except Exception as exc:
        logger.exception("Failed document search for query=%s", query)
        return {
            "success": False,
            "error": f"failed to search inserted data: {exc}",
        }

    ids = (results.get("ids") or [[]])[0] or []
    documents = (results.get("documents") or [[]])[0] or []
    metadatas = (results.get("metadatas") or [[]])[0] or []
    distances = (results.get("distances") or [[]])[0] or []

    if not ids:
        return {
            "success": False,
            "message": "No matching inserted data found",
            "query": query,
            "project_name": (project_name or "").strip().lower(),
            "count": 0,
            "results": [],
        }

    output = []
    seen_keys = set()
    for i, vector_id in enumerate(ids):
        metadata = metadatas[i] if i < len(metadatas) and isinstance(metadatas[i], dict) else {}
        document = documents[i] if i < len(documents) else ""
        distance = distances[i] if i < len(distances) else None

        doc_norm = " ".join(str(document or "").split()).strip().lower()
        hash_norm = str(metadata.get("error_signature_hash") or "").strip().lower()
        # Prefer signature hash for stable dedupe. Fallback to normalized text when hash is missing.
        unique_key = hash_norm or doc_norm
        if unique_key in seen_keys:
            continue
        seen_keys.add(unique_key)

        output.append({
            "vector_id": vector_id,
            "document": document,
            "preview": (document or "")[:250],
            "distance": distance,
            "project_name": metadata.get("project_name"),
            "request_id": metadata.get("request_id"),
            "batch_id": metadata.get("batch_id"),
            "file_name": metadata.get("file_name"),
            "s3_key": metadata.get("s3_key"),
            "error_signature_hash": metadata.get("error_signature_hash"),
        })
        if len(output) >= top_k:
            break

    return {
        "success": True,
        "message": "Inserted data fetched successfully",
        "query": query,
        "project_name": (project_name or "").strip().lower(),
        "count": len(output),
        "collection_name": config.CHROMA_COLLECTION_DOCS,
        "results": output,
    }


def get_artifact_context_by_query(query: str, project_name: str = "", top_k: int = 3, allow_global_fallback: bool = True) -> Dict:
    query = (query or "").strip()
    if not query:
        return {"success": False, "error": "query is required"}

    try:
        results = search_artifact_data_injection_fused(
            query=query,
            project_name=project_name,
            top_k=top_k,
            allow_global_fallback=allow_global_fallback,
        )
    except Exception as exc:
        logger.exception("Failed artifact search for query=%s", query)
        return {
            "success": False,
            "error": f"failed to search artifact embeddings: {exc}",
        }

    ids = (results.get("ids") or [[]])[0] or []
    documents = (results.get("documents") or [[]])[0] or []
    metadatas = (results.get("metadatas") or [[]])[0] or []
    distances = (results.get("distances") or [[]])[0] or []

    if not ids:
        return {
            "success": False,
            "message": "No matching artifact context found",
            "query": query,
            "project_name": (project_name or "").strip().lower(),
            "count": 0,
            "results": [],
        }

    output = []
    seen_keys = set()
    for i, vector_id in enumerate(ids):
        metadata = metadatas[i] if i < len(metadatas) and isinstance(metadatas[i], dict) else {}
        document = documents[i] if i < len(documents) else ""
        distance = distances[i] if i < len(distances) else None

        doc_norm = " ".join(str(document or "").split()).strip().lower()
        hash_norm = str(metadata.get("error_signature_hash") or "").strip().lower()
        unique_key = hash_norm or doc_norm
        if unique_key in seen_keys:
            continue
        seen_keys.add(unique_key)

        output.append({
            "vector_id": vector_id,
            "document": document,
            "preview": (document or "")[:250],
            "distance": distance,
            "project_name": metadata.get("project_name"),
            "request_id": metadata.get("request_id"),
            "batch_id": metadata.get("batch_id"),
            "file_name": metadata.get("file_name"),
            "s3_key": metadata.get("s3_key"),
            "error_signature_hash": metadata.get("error_signature_hash"),
            "artifact_type": metadata.get("artifact_type"),
            "source_folder": metadata.get("source_folder"),
            "task_path": metadata.get("task_path"),
            "action": metadata.get("action"),
        })
        if len(output) >= top_k:
            break

    return {
        "success": True,
        "message": "Artifact context fetched successfully",
        "query": query,
        "project_name": (project_name or "").strip().lower(),
        "count": len(output),
        "collection_name": config.CHROMA_COLLECTION_ARTIFACTS,
        "results": output,
    }


def build_document_context(
    *,
    query_text: str,
    project_name: str,
    top_k: int = 5,
) -> Dict:
    query = str(query_text or "").strip()
    normalized_project = (project_name or "").strip().lower()
    try:
        k = int(top_k)
    except (TypeError, ValueError):
        k = 5
    k = max(1, min(k, 20))

    if not query:
        return {
            "success": False,
            "message": "document query is empty",
            "query": "",
            "project_name": normalized_project,
            "count": 0,
            "results": [],
        }

    _allow_global = _reco_global_fallback_enabled()
    document_context = get_data_injection_by_query(
        query=query,
        project_name=normalized_project,
        top_k=k,
        allow_global_fallback=_allow_global,
    )
    artifact_context = get_artifact_context_by_query(
        query=query,
        project_name=normalized_project,
        top_k=min(3, k),
        allow_global_fallback=_allow_global,
    )

    merged_success = bool(document_context.get("success") or artifact_context.get("success"))
    return {
        "success": merged_success,
        "message": document_context.get("message") or "Document context fetched",
        "query": query,
        "project_name": normalized_project,
        "count": int(document_context.get("count") or 0),
        "collection_name": document_context.get("collection_name") or config.CHROMA_COLLECTION_DOCS,
        "results": document_context.get("results") or [],
        "artifact_context": artifact_context,
    }


def _artifact_raw_url(s3_key) -> str:
    """Public URL to view the RAW artifact .txt/.log (served from S3 by /view-artifact). Empty when
    there is no s3_key. Lets the client open the literal source file behind an evidence item."""
    key = str(s3_key or "").strip()
    if not key:
        return ""
    from urllib.parse import quote
    base = str(getattr(config, "BACKEND_PUBLIC_BASE_URL", "") or "").rstrip("/")
    return f"{base}/view-artifact?s3_key={quote(key, safe='')}"


def _build_unified_context_enrichment(
    *,
    query_text: str,
    project_name: str,
    errors: List[Dict[str, object]],
    recommendations: List[Dict],
    task_path: str = None,
    copilot_query: str = None,
    raw_metadatas: List[Dict] = None,
    query_artifact_text: str = "",
) -> Dict:
    """
    Build unified context enrichment with triple-source RRF fusion.
    
    Args:
        query_text: Primary error query text
        project_name: Project name for scoping
        errors: List of error dicts
        recommendations: List of recommendation dicts (historical errors with solutions)
        task_path: Optional task path for hierarchical filtering
        copilot_query: Optional copilot query to enhance document search
    
    Returns:
        Dict with document_context, context_enrichment, unified_evidence, rrf_metadata, llm_analysis
    """
    query = str(query_text or "").strip()
    normalized_project = (project_name or "").strip().lower()
    normalized_task = (task_path or "").strip()
    normalized_copilot_query = (copilot_query or "").strip()
    
    # Enhance document query with copilot_query if provided. Avoid doubling the text
    # when copilot_query is identical to the error query (common: both are the focused
    # failure line), which would otherwise embed the same sentence twice.
    doc_query = query
    if normalized_copilot_query and normalized_copilot_query.lower() != query.lower():
        doc_query = f"{normalized_copilot_query} {query}".strip()
    elif normalized_copilot_query and not query:
        doc_query = normalized_copilot_query

    # ---- FLOW-DEBUG: what query each source actually searches with ----
    logger.info("[FLOW-DEBUG] === STEP 2: SEARCH QUERIES ===")
    logger.info("[FLOW-DEBUG] enrichment query_text (=msg anchor) = %r", str(query)[:200])
    logger.info("[FLOW-DEBUG] copilot_query = %r", str(normalized_copilot_query)[:200])
    # The ARTIFACT source searches with the LIVE FAILURE'S OWN ARTIFACT CONTENT when the
    # client sent it (root cause of "python fails, ctc is Candidate 1" even with a
    # clean single debug.log): a GBE report's error text carries tool-install chatter naming
    # ctc_aurix in EVERY report regardless of which tool failed ("Creating snapshot for
    # [...ctc_aurix\6.2r1p4]", "Local installation of tool ctc_aurix:6.2r1p4 is UP-TO-DATE"),
    # so an error-text artifact query is saturated with ctc tokens and retrieved ctc summaries
    # first (live FLOW-DEBUG: hits 0-3 ctc at dist 0.78-0.85, python at 1.02+). That evidence
    # is what the LLM selection ranks and picks from - it never saw the real root cause. The
    # scoring path has its own artifact-content probe; this evidence path is the other
    # half. Failure-signal lines only (the cause, not the scaffolding); error text remains the
    # query whenever no artifact evidence was sent, so older clients are unaffected.
    _artifact_signal = "\n".join(_failure_signal_lines(str(query_artifact_text or "")))[:6000].strip()
    artifact_query = _artifact_signal or query
    logger.info("[FLOW-DEBUG] ARTIFACT search query (%s) = %r",
                "live artifact evidence" if _artifact_signal else "error text (no artifacts sent)",
                str(artifact_query)[:200])
    logger.info("[FLOW-DEBUG] DOCUMENT search query = %r", str(doc_query)[:200])
    # -------------------------------------------------------------------

    # Retrieve from all three sources with task filtering
    # Note: recommendations are already retrieved, but we need artifacts and documents
    document_context = build_document_context(
        query_text=doc_query,
        project_name=normalized_project,
        top_k=3,  # Top 3 documents; project-scoped unless ERROR_RECO_GLOBAL_FALLBACK=1
    )

    # Search artifacts with task filtering (Top 10) — fused with the W_artifact learned
    # space when the artifact adapter is trained + toggled on (base-only otherwise).
    artifact_search_results = search_artifact_data_injection_fused(
        query=artifact_query,
        project_name=normalized_project,
        top_k=10,
        task_path=normalized_task,
        allow_global_fallback=_reco_global_fallback_enabled(),
    )
    
    # Extract artifact hits from search results
    artifact_ids = (artifact_search_results.get("ids") or [[]])[0] or []
    artifact_distances = (artifact_search_results.get("distances") or [[]])[0] or []
    artifact_metas = (artifact_search_results.get("metadatas") or [[]])[0] or []
    artifact_docs = (artifact_search_results.get("documents") or [[]])[0] or []
    
    # NOTE: we intentionally do NOT filter older 'in'/'tmp' artifacts out of retrieval. New
    # captures are already restricted to out/log (RuntimeArtifactCollector), but artifacts
    # already embedded from earlier captures are kept and still used for analysis so previously
    # collected data is not lost. Going forward the store naturally contains only out/log.
    artifact_hits = []
    _no_signal_hits = 0
    for idx, art_id in enumerate(artifact_ids):
        # Same bar as the scoring side: an artifact whose text names no failure is
        # boilerplate, not evidence - it must not occupy one of the few evidence slots the LLM
        # selection reads, where it would describe "what happened" without any failure in it.
        if not _failure_signal_lines(str(artifact_docs[idx] if idx < len(artifact_docs) else "")):
            _no_signal_hits += 1
            continue
        artifact_hits.append({
            "id": art_id,
            "distance": artifact_distances[idx] if idx < len(artifact_distances) else 0.0,
            "metadata": artifact_metas[idx] if idx < len(artifact_metas) else {},
            "document": artifact_docs[idx] if idx < len(artifact_docs) else "",
            "file_name": (artifact_metas[idx] if idx < len(artifact_metas) else {}).get("file_name", ""),
            "artifact_type": (artifact_metas[idx] if idx < len(artifact_metas) else {}).get("artifact_type", ""),
            "task_match_level": (artifact_metas[idx] if idx < len(artifact_metas) else {}).get("task_match_level", "unknown"),
            "s3_key": (artifact_metas[idx] if idx < len(artifact_metas) else {}).get("s3_key", ""),
        })
    
    if _no_signal_hits:
        logger.info("[FLOW-DEBUG] %d artifact hit(s) dropped from evidence - no failure signal", _no_signal_hits)

    # OTHER-TASK LOGS FOUND BY ERROR TEXT ARE NOT EVIDENCE. Without a live log the artifact
    # search runs on the error text and, when the failing task has no stored logs, widens to the
    # whole project - live: a task3 read_xml_config failure was "explained" to the LLM with three
    # task4 ctc_aurix debug.logs. A live log matched against another task's log IS evidence (the
    # same failure can occur in several tasks), so this applies only to the error-text probe.
    _query_task_token = _canonical_task_token(normalized_task) if normalized_task else ""
    if not _artifact_signal and _query_task_token and artifact_hits:
        _kept = []
        for _h in artifact_hits:
            _h_task = _canonical_task_token(str((_h.get("metadata") or {}).get("task_path") or ""))
            if _h_task and _h_task != _query_task_token:
                continue
            _kept.append(_h)
        if len(_kept) != len(artifact_hits):
            logger.info("[FLOW-DEBUG] %d artifact hit(s) from other tasks dropped from evidence "
                        "(no live log; error-text probe)", len(artifact_hits) - len(_kept))
        artifact_hits = _kept

    # Extract document hits
    artifact_context = document_context.get("artifact_context") or {}
    semantic_hits = list(document_context.get("results") or [])[:3]

    # ---- FLOW-DEBUG: what each source returned, with distances ----
    logger.info("[FLOW-DEBUG] === STEP 3: SEARCH RESULTS (lower distance = better match) ===")
    logger.info("[FLOW-DEBUG] ARTIFACT hits: %d", len(artifact_hits))
    for i, h in enumerate(artifact_hits):
        logger.info("[FLOW-DEBUG]   artifact[%d] dist=%.4f match=%s file=%s preview=%.100s",
                    i, float(h.get("distance") or 0.0), h.get("task_match_level"),
                    h.get("file_name"), str(h.get("document") or "").replace("\n", " "))
    logger.info("[FLOW-DEBUG] DOCUMENT hits: %d", len(semantic_hits))
    for i, h in enumerate(semantic_hits):
        logger.info("[FLOW-DEBUG]   document[%d] dist=%.4f file=%s preview=%.100s",
                    i, float(h.get("distance") or 0.0), h.get("file_name"),
                    str(h.get("document") or "").replace("\n", " "))
    # ----------------------------------------------------------------

    # Prepare historical error results from recommendations (Top 10 already retrieved).
    # error_message priority: ChromaDB document text > metadata field > empty.
    historical_error_hits = []
    safe_raw_metadatas = raw_metadatas if raw_metadatas else []
    # Pair each recommendation with ITS OWN search metadata, by request id. The two lists are in
    # different orders (search order vs ranked/deduped order), and pairing them by position gave
    # the LLM one fix's error next to another fix's metadata - seen live: a task3 'AURIX1' error
    # carrying a task4 python-version fix's error_message, request_id and solution.
    _meta_by_request: Dict[str, Dict] = {}
    for _m in safe_raw_metadatas:
        if isinstance(_m, dict):
            _rid = str(_m.get("request_id") or _m.get("batch_id") or "").strip()
            if _rid and _rid not in _meta_by_request:
                _meta_by_request[_rid] = _m
    for idx, rec in enumerate(recommendations[:10]):
        error_msg = ""
        task_match_level = "unknown"
        meta: Dict = _meta_by_request.get(
            str(rec.get("request_id") or rec.get("batch_id") or "").strip()) or {}
        task_match_level = str(meta.get("task_match_level", "unknown")).strip()

        # Prefer the document text (original embedded error), fall back to stored metadata field.
        doc_text = _safe_doc_text(rec.get("document"))
        meta_msg = _safe_doc_text(meta.get("error_message"))
        error_msg = doc_text or meta_msg

        historical_error_hits.append({
            "id": rec.get("vector_id", f"hist_{idx}"),
            "distance": rec.get("distance", 0.0),
            "metadata": meta,
            "request_id": rec.get("request_id", ""),
            "error_message": error_msg,
            "task_match_level": task_match_level,
        })

    # Query-time evidence gate: drop historical errors whose stored message is not a
    # real failure (timing/status noise such as "dummy1 finished in 80 ms"). This keeps
    # pre-existing garbage rows from surfacing as RRF evidence without backfilling them.
    if _vector_block_mode_enabled() and historical_error_hits:
        _pre_gate = len(historical_error_hits)
        historical_error_hits = [
            h for h in historical_error_hits
            if _is_real_failure_text(str(h.get("error_message") or ""))
        ]
        if len(historical_error_hits) != _pre_gate:
            logger.info(
                "[FLOW-DEBUG] historical evidence gated: %d -> %d (dropped non-failure messages)",
                _pre_gate, len(historical_error_hits),
            )

    # ---- FLOW-DEBUG: historical error candidates ----
    logger.info("[FLOW-DEBUG] HISTORICAL ERROR hits: %d", len(historical_error_hits))
    for i, h in enumerate(historical_error_hits):
        logger.info("[FLOW-DEBUG]   historical[%d] dist=%.4f match=%s request_id=%s error=%.120s",
                    i, float(h.get("distance") or 0.0), h.get("task_match_level"),
                    h.get("request_id"), str(h.get("error_message") or "").replace("\n", " "))
    # --------------------------------------------------

    # Apply triple-source RRF fusion
    rrf_enabled = getattr(config, "RRF_ENABLED", True)
    unified_evidence = []
    rrf_metadata = {}
    
    if rrf_enabled and (historical_error_hits or artifact_hits or semantic_hits):
        rrf_result = _apply_triple_source_rrf_fusion(
            historical_errors=historical_error_hits,
            artifact_results=artifact_hits,
            document_results=semantic_hits,
            top_k=3,
            rrf_k=getattr(config, "RRF_CONSTANT_K", 60)
        )
        unified_evidence = rrf_result.get("unified_evidence", [])
        rrf_metadata = rrf_result.get("rrf_metadata", {})
        
        logger.debug(
            "RRF FUSION applied | historical=%d | artifacts=%d | documents=%d | unified_top_3=%d | avg_score=%.6f",
            len(historical_error_hits),
            len(artifact_hits),
            len(semantic_hits),
            len(unified_evidence),
            rrf_metadata.get("avg_rrf_score", 0.0)
        )
        # ---- FLOW-DEBUG: what RRF picked as top-3 evidence ----
        logger.info("[FLOW-DEBUG] === STEP 4: RRF FUSION OUTPUT (top-3 evidence to LLM) ===")
        logger.info("[FLOW-DEBUG] rrf_metadata = %r", rrf_metadata)
        for i, ev in enumerate(unified_evidence):
            logger.info("[FLOW-DEBUG]   evidence[%d] source=%s rrf_score=%.6f orig_dist=%s file=%s req=%s preview=%.100s",
                        i, ev.get("source"), float(ev.get("rrf_score") or 0.0),
                        ev.get("original_distance"), ev.get("file_name") or "",
                        ev.get("request_id") or "",
                        str(ev.get("document") or ev.get("error_message") or ev.get("preview") or "").replace("\n", " "))
        # -------------------------------------------------------
    else:
        logger.debug("RRF FUSION skipped | enabled=%s | sources_available=%d", rrf_enabled, len([x for x in [historical_error_hits, artifact_hits, semantic_hits] if x]))
        logger.info("[FLOW-DEBUG] === STEP 4: RRF SKIPPED (enabled=%s) ===", rrf_enabled)
    
    # LLM Root Cause Analysis — TIME-BOUNDED only to protect against a genuinely HUNG LLM
    # (dead network / broken auth), NOT against normal latency. The budget is set generously
    # (default 120s, comfortably under the extension's 180s client timeout) so that whenever the
    # LLM is reachable the analysis AND selection always complete — they are only ever omitted if
    # the call truly hangs past the budget. In that case the recommendation still returns with the
    # matched fix + RRF evidence (best-effort). Configurable via RECOMMENDATION_LLM_TIMEOUT_SEC.
    final_llm_analysis = ""
    final_llm_selection: Dict = {}
    final_llm_usage: Dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    # Status the client uses to explain a missing analysis so it never looks like a bug:
    #   ok | timeout | error | disabled
    llm_analysis_status = "ok" if getattr(config, "LLM_ANALYSIS_ENABLED", True) else "disabled"
    if getattr(config, "LLM_ANALYSIS_ENABLED", True):
        def _run_llm_analysis() -> tuple:
            analysis = ""
            selection: Dict = {}
            usage: Dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}
            logger.info("[FLOW-DEBUG] === STEP 5: LLM PATH ===")
            logger.info("[FLOW-DEBUG] errors sent to LLM = %r",
                        [str((e or {}).get("message") or "")[:150] for e in (errors or [])])
            # Selection path: let the LLM pick the exact historical fix (by request_id)
            # and explain it. Falls through to descriptive analysis if it yields nothing.
            if getattr(config, "LLM_SELECTION_ENABLED", False) and (unified_evidence or recommendations):
                logger.info("[FLOW-DEBUG] LLM path = analyze_and_select_solution_with_unified_evidence")
                analysis, selection, usage = analyze_and_select_solution_with_unified_evidence(
                    errors=errors,
                    unified_evidence=unified_evidence,
                    candidate_solutions=recommendations[:5],
                    query_text=query,
                )
                logger.info(
                    "[FLOW-DEBUG] selection = chosen_request_id=%s confidence=%s",
                    selection.get("chosen_request_id"), selection.get("confidence"),
                )
            if analysis:
                return analysis, selection, usage
            if unified_evidence:
                logger.info("[FLOW-DEBUG] LLM path = analyze_with_unified_evidence (RRF evidence)")
                # Primary path: use Top-3 RRF unified evidence directly.
                analysis, usage = analyze_with_unified_evidence(
                    errors=errors,
                    unified_evidence=unified_evidence,
                    query_text=query,
                )
            else:
                # Fallback when RRF produced no evidence: use raw combined context.
                # Filter solutions by relevance threshold before sending to LLM.
                relevant_solutions = [
                    s for s in recommendations[:3]
                    if float(s.get("distance") or 1.0) < _SOLUTION_RELEVANCE_THRESHOLD
                ]
                analysis, usage = analyze_errors_and_solutions_with_combined_context(
                    errors=errors,
                    solutions=relevant_solutions,
                    semantic_results=semantic_hits,
                    artifact_results=artifact_hits[:_UNIFIED_CONTEXT_ARTIFACT_TOP_K],
                    query_text=query,
                )

            # Last-resort fallback: errors-only analysis.
            if not analysis:
                logger.info("[FLOW-DEBUG] LLM path = analyze_errors_and_solutions (last-resort, errors-only)")
                relevant_solutions = [
                    s for s in recommendations[:3]
                    if float(s.get("distance") or 1.0) < _SOLUTION_RELEVANCE_THRESHOLD
                ]
                analysis, usage = analyze_errors_and_solutions(
                    errors=errors,
                    solutions=relevant_solutions,
                )
            return analysis, selection, usage

        try:
            _llm_budget_sec = max(5, int(os.getenv("RECOMMENDATION_LLM_TIMEOUT_SEC", "120")))
        except (TypeError, ValueError):
            _llm_budget_sec = 120
        # A2 — up to 2 attempts: retry ONCE on a transient EMPTY/ERROR (fast failures). Do NOT
        # retry a TIMEOUT — the budget was already spent, so a second wait would only delay the
        # response without helping.
        for _attempt in (1, 2):
            try:
                logger.info(
                    "[LLM] analysis+pick START (attempt %d) | selection_enabled=%s | budget=%ds | "
                    "unified_evidence=%d | recommendations=%d | query=%.80s",
                    _attempt, bool(getattr(config, "LLM_SELECTION_ENABLED", False)), _llm_budget_sec,
                    len(unified_evidence or []), len(recommendations or []), str(query or "")[:80],
                )
                _llm_future = _reco_llm_executor.submit(_run_llm_analysis)
                final_llm_analysis, final_llm_selection, final_llm_usage = _llm_future.result(timeout=_llm_budget_sec)
                if final_llm_analysis:
                    llm_analysis_status = "ok"
                    logger.info(
                        "[LLM] analysis+pick OK | analysis_chars=%d | pick_request_id=%s | pick_confidence=%s | tokens=%s",
                        len(final_llm_analysis),
                        (final_llm_selection or {}).get("chosen_request_id") or "<none>",
                        (final_llm_selection or {}).get("confidence") or "<none>",
                        (final_llm_usage or {}).get("total_tokens", 0),
                    )
                    break
                # Empty (reached the model, got nothing) — retry once, then give up.
                if _attempt == 1:
                    logger.info("[LLM] empty result on attempt 1 — retrying once")
                    continue
                llm_analysis_status = "empty"
                logger.warning(
                    "[LLM] analysis+pick EMPTY — model reached but produced NO analysis after retry. "
                    "unified_evidence=%d | recommendations=%d | pick_request_id=%s | query=%.80s",
                    len(unified_evidence or []), len(recommendations or []),
                    (final_llm_selection or {}).get("chosen_request_id") or "<none>",
                    str(query or "")[:80],
                )
            except FuturesTimeoutError:
                llm_analysis_status = "timeout"
                logger.warning(
                    "[LLM] analysis+pick TIMEOUT — exceeded %ds budget; returning fix + evidence WITHOUT analysis "
                    "(LLM unreachable / slow / rate-limited / auth hung) | query=%.80s",
                    _llm_budget_sec, str(query or "")[:80],
                )
                break  # budget already spent — do not retry
            except Exception as _llm_err:
                if _attempt == 1:
                    logger.warning("[LLM] error on attempt 1 (%s) — retrying once", type(_llm_err).__name__)
                    continue
                llm_analysis_status = "error"
                logger.exception(
                    "[LLM] analysis+pick ERROR — %s: %s | returning fix + evidence without analysis | query=%.80s",
                    type(_llm_err).__name__, str(_llm_err)[:200], str(query or "")[:80],
                )

    # ---- FLOW-DEBUG: final summary + the recommendation it should match ----
    logger.info("[FLOW-DEBUG] === STEP 6: FINAL SUMMARY ===")
    logger.info("[FLOW-DEBUG] llm_analysis = %s", str(final_llm_analysis or "").replace("\n", " "))
    logger.info("[FLOW-DEBUG] top recommendation request_id = %s",
                str((recommendations[0] or {}).get("request_id") if recommendations else "") )
    logger.info("[FLOW-DEBUG] ================================")
    # ------------------------------------------------------------------------

    return {
        "document_context": document_context,
        "context_enrichment": {
            "enabled": bool(getattr(config, "LLM_ANALYSIS_ENABLED", True)),
            "query": query,
            "copilot_query": normalized_copilot_query,
            "task_path": normalized_task,
            "semantic_results_used": len(semantic_hits),
            "artifact_results_used": len(artifact_hits),
            "historical_errors_used": len(historical_error_hits),
            "rrf_enabled": rrf_enabled,
            "llm_evidence_used": [
                {
                    "rank": i + 1,
                    "source": item.get("source"),
                    "rrf_score": item.get("rrf_score"),
                    "error_message": str(item.get("error_message") or "")[:300],
                    "file_name": str(item.get("file_name") or ""),
                    "request_id": str(item.get("request_id") or ""),
                    "task_match_level": str(item.get("task_match_level") or ""),
                    "preview": str(item.get("document") or item.get("preview") or "")[:300],
                }
                for i, item in enumerate(unified_evidence[:3])
            ],
            "combined_context": {
                "semantic_results": semantic_hits,
                "artifact_results": artifact_hits[:_UNIFIED_CONTEXT_ARTIFACT_TOP_K],
                "historical_errors": historical_error_hits[:10],
            },
            "token_usage": {
                "final_analysis": final_llm_usage,
                "total": {
                    "prompt_tokens": int(final_llm_usage.get("prompt_tokens", 0) or 0),
                    "output_tokens": int(final_llm_usage.get("output_tokens", 0) or 0),
                    "total_tokens": int(final_llm_usage.get("total_tokens", 0) or 0),
                },
            },
        },
        "unified_evidence": unified_evidence,
        "rrf_metadata": rrf_metadata,
        "llm_analysis": final_llm_analysis,
        "llm_selection": final_llm_selection,
        "llm_token_usage": final_llm_usage,
        # Tells the client WHY analysis may be missing so it never looks like a bug.
        "llm_analysis_status": llm_analysis_status,
        "llm_analysis_message": {
            "timeout": "AI analysis is temporarily unavailable — the language model did not respond in time "
                       "(it may be busy or rate-limited, or the network/auth to the AI service is slow). "
                       "The matched fix and evidence below are still valid — try again in a moment.",
            "error": "AI analysis is temporarily unavailable — the language-model request failed "
                     "(please check the AI service network and credentials). "
                     "The matched fix and evidence below are still valid.",
            "disabled": "AI analysis is turned off in this environment. The matched fix and evidence below "
                        "are based on historical matches.",
            "empty": "AI analysis produced no summary for this failure this time. The matched fix and "
                     "evidence below are still valid — try again in a moment.",
        }.get(llm_analysis_status, ""),
    }

def list_all_injected_documents_by_project_handler() -> Dict:
    """
    Return uploaded documents grouped by project from binary-artifacts/ (action=uploaded only).
    """
    from src.utils.payload_archive import BINARY_ARTIFACTS_PREFIX

    s3_client = get_s3_client()
    paginator = s3_client.get_paginator("list_objects_v2")

    def _clean_name(raw: str) -> str:
        return re.sub(r"-[0-9a-f]{12}\.zip$", "", raw)

    # project_segment -> { clean_file_name -> (s3_key, last_modified) }
    projects: Dict[str, Dict[str, tuple]] = {}

    try:
        pages = paginator.paginate(Bucket=S3_BUCKET, Prefix=BINARY_ARTIFACTS_PREFIX)
        for page in pages:
            for item in page.get("Contents", []) or []:
                key = str(item.get("Key") or "").strip()
                if not key or key.endswith("/"):
                    continue
                parts = key.split("/")
                # key layout: binary-artifacts/{project}/{env}/{batch}/{action}/{file}
                if len(parts) < 6:
                    continue
                key_action = parts[-2].lower()
                if key_action != "uploaded":
                    continue
                project_segment = parts[1]
                clean = _clean_name(parts[-1])
                last_modified = item.get("LastModified")
                size = int(item.get("Size") or 0)

                if project_segment not in projects:
                    projects[project_segment] = {}
                current = projects[project_segment].get(clean)
                if current is None or (
                    last_modified is not None and
                    (current[1] is None or last_modified > current[1])
                ):
                    projects[project_segment][clean] = (key, last_modified, size)

        result = []
        for project_name in sorted(projects):
            docs = sorted(
                [
                    {
                        "file_name": fname,
                        "s3_key": entry[0],
                        "file_size": entry[2],
                        "last_modified": entry[1].strftime("%Y-%m-%dT%H:%M:%SZ") if entry[1] else None,
                    }
                    for fname, entry in projects[project_name].items()
                ],
                key=lambda x: x["last_modified"] or "",
                reverse=True,
            )
            result.append({
                "project_name": project_name,
                "document_count": len(docs),
                "documents": docs,
            })

        return {
            "success": True,
            "total_projects": len(result),
            "projects": result,
        }

    except Exception as exc:
        logger.exception("list_all_injected_documents_by_project_handler failed")
        return {"success": False, "error": str(exc)}


def list_injected_files_handler(project_name: str = "") -> Dict:
    """GET /files — flat file list for the Data Injection page (UI contract).

    project_name (optional) narrows to ONE project, compared case-insensitively against the
    S3 project segment. Omitted/empty => all projects' files in one flat list. Unknown project
    => success with an empty list (the UI shows 'no files' instead of an error)."""
    base = list_all_injected_documents_by_project_handler()
    if not base.get("success"):
        return {
            "success": False,
            "message": str(base.get("error") or "Failed to fetch files"),
            "data": {"files_count": 0, "documents": []},
        }

    target = str(project_name or "").strip().lower()
    documents: List[dict] = []
    for proj in base.get("projects", []) or []:
        if target and str(proj.get("project_name") or "").strip().lower() != target:
            continue
        # UI contract: file_name + file_size (stored size in bytes) + last_modified — no s3_key.
        for doc in proj.get("documents", []) or []:
            documents.append({
                "file_name": doc.get("file_name"),
                "file_size": int(doc.get("file_size") or 0),
                "last_modified": doc.get("last_modified"),
            })
    documents.sort(key=lambda d: str(d.get("last_modified") or ""), reverse=True)

    return {
        "success": True,
        "message": "Files fetched successfully",
        "data": {
            "project_name": str(project_name or "").strip(),
            "files_count": len(documents),
            "documents": documents,
        },
    }


####
def list_s3_documents_handler(prefix: str | None = None, unique_names: bool = False,
                              action: str | None = None, project_name: str | None = None) -> Dict:
    """
    If prefix is empty, list all files in the S3 bucket.
    If prefix is provided, list files only under that prefix.

    `action` (optional) filters by the artifact action segment of the key. Binary artifacts are stored
    as  binary-artifacts/{project}/{env}/{batch}/{action}/{file}.zip  — so user-injected DOCUMENTS use
    action="uploaded" while build artifacts use modified/created/added/... Passing action="uploaded"
    returns ONLY the manually uploaded documents (no build-artifact noise). "" / "all" = no filter.

    `project_name` (optional) narrows the S3 prefix to a specific project so only that project's
    files are returned (e.g. prefix=binary-artifacts + project_name=1g_hio_000u0_uat).
    """
    prefix = str(prefix or "").strip()
    action_filter = str(action or "").strip().lower()
    if action_filter in {"all", "*", "any"}:
        action_filter = ""

    # Narrow S3 prefix to the specific project when provided so we only page through
    # that project's keys instead of the entire bucket prefix.
    project_filter = str(project_name or "").strip().lower()
    if project_filter and prefix:
        project_segment = re.sub(r"[^a-z0-9._-]+", "-", project_filter).strip("-")
        scoped_prefix = f"{prefix.rstrip('/')}/{project_segment}/"
    else:
        scoped_prefix = prefix

    logger.debug("S3 LIST documents | bucket=%s | prefix=%s | project=%s | action=%s",
                 S3_BUCKET, scoped_prefix or "<ALL>", project_filter or "<ALL>", action_filter or "<ALL>")

    s3_client = get_s3_client()
    paginator = s3_client.get_paginator("list_objects_v2")

    keys: List[str] = []

    try:
        paginate_kwargs = {"Bucket": S3_BUCKET}
        if scoped_prefix:
            paginate_kwargs["Prefix"] = scoped_prefix

        pages = paginator.paginate(**paginate_kwargs)

        records: List[tuple] = []  # (key, last_modified)
        for page in pages:
            contents = page.get("Contents", []) or []
            for item in contents:
                key = str(item.get("Key") or "").strip()
                if not key or key.endswith("/"):
                    continue
                if action_filter:
                    # action is the parent "folder" of the file in the key layout above.
                    parts = key.split("/")
                    key_action = parts[-2].lower() if len(parts) >= 2 else ""
                    if key_action != action_filter:
                        continue
                records.append((key, item.get("LastModified")))

        def _clean_name(raw: str) -> str:
            # S3 key last segment is "{filename}-{sha12}.zip" — strip the hash suffix
            # to recover the original file name (e.g. "guidelines.pdf-abc123.zip" → "guidelines.pdf").
            import re
            return re.sub(r"-[0-9a-f]{12}\.zip$", "", raw)

        if unique_names:
            # Collapse duplicates by (PROJECT, clean file name): the same document re-uploaded to the
            # SAME project produces one key per upload -> show it once (latest version).
            best: Dict[tuple, tuple] = {}  # (project, clean_name) -> (key, last_modified)
            for key, last_modified in records:
                parts = key.split("/")
                name = _clean_name(parts[-1])
                # key layout: {prefix}/{project}/{env}/{batch}/{action}/{file}
                project = parts[1] if len(parts) >= 2 else ""
                dedup_key = (project, name)
                current = best.get(dedup_key)
                if current is None or (
                    last_modified is not None and (current[1] is None or last_modified > current[1])
                ):
                    best[dedup_key] = (key, last_modified)
            ordered = sorted(best.keys())  # sort by (project, name)
            keys = [best[dk][0] for dk in ordered]
            names = [dk[1] for dk in ordered]
        else:
            keys = [key for key, _ in records]
            names = [_clean_name(key.split("/")[-1]) for key in keys]

        # Build per-project grouping: key layout is {prefix}/{project}/{env}/{batch}/{action}/{file}
        by_project: Dict[str, list] = {}
        for key in keys:
            parts = key.split("/")
            project_segment = parts[1] if len(parts) >= 2 else "unknown"
            clean = _clean_name(parts[-1])
            if project_segment not in by_project:
                by_project[project_segment] = []
            by_project[project_segment].append({"file_name": clean, "s3_key": key})

        projects_list = [
            {"project_name": p, "document_count": len(docs), "documents": docs}
            for p, docs in sorted(by_project.items())
        ]

        logger.debug("S3 LIST documents | bucket=%s | prefix=%s | action=%s | document_count=%d",
                     S3_BUCKET, prefix or "<ALL>", action_filter or "<ALL>", len(names))
        return {
            "success": True,
            "bucket": S3_BUCKET,
            "region": AWS_REGION,
            "prefix": prefix,
            "action": action_filter or "all",
            "document_count": len(names),
            "document_names": names,
            "document_keys": keys,
            "by_project": projects_list,
        }
    except Exception as exc:
        logger.exception("Failed listing S3 documents for prefix=%s", prefix or "<ALL>")
        return {
            "success": False,
            "error": str(exc),
            "bucket": S3_BUCKET,
            "region": AWS_REGION,
            "prefix": prefix,
        }


# ============================================================================
# RRF (Reciprocal Rank Fusion) Functions
# ============================================================================


def reciprocal_rank_fusion(
    ranked_lists: List[List[Dict]],
    rank_key: str = "rank",
    id_key: str = "unique_id",
    k: int = 60,
) -> List[Dict]:
    """
    Apply Reciprocal Rank Fusion (RRF) to combine multiple ranked lists.
    
    RRF Formula: RRF_score(item) = Σ(1 / (k + rank_i))
    where k is a constant (default 60) and rank_i is the rank in list i.
    
    Args:
        ranked_lists: List of ranked lists, each containing dicts with items
        rank_key: Key name for rank in the item dicts (default: "rank")
        id_key: Key name for unique identifier (default: "unique_id")
        k: RRF constant, typically 60 (default: 60)
    
    Returns:
        Unified ranked list sorted by RRF score (highest first)
    """
    if not ranked_lists:
        return []
    
    rrf_scores: Dict[str, float] = {}
    item_map: Dict[str, Dict] = {}
    
    # Calculate RRF scores across all lists
    for list_idx, ranked_list in enumerate(ranked_lists):
        for item in ranked_list or []:
            if not isinstance(item, dict):
                continue
            
            item_id = str(item.get(id_key) or "").strip()
            if not item_id:
                continue
            
            # Get rank (1-indexed) from item or use position
            rank = item.get(rank_key, 0)
            if not rank or rank <= 0:
                # If no rank, use position in list (1-indexed)
                rank = ranked_list.index(item) + 1
            
            # Calculate RRF contribution: 1 / (k + rank)
            rrf_contribution = 1.0 / (k + rank)
            rrf_scores[item_id] = rrf_scores.get(item_id, 0.0) + rrf_contribution
            
            # Store item for later retrieval (keep first occurrence)
            if item_id not in item_map:
                item_map[item_id] = item.copy()
    
    # Sort items by RRF score (descending)
    sorted_ids = sorted(rrf_scores.keys(), key=lambda x: rrf_scores[x], reverse=True)
    
    # Build final ranked list with RRF scores
    fused_results = []
    for final_rank, item_id in enumerate(sorted_ids, start=1):
        item = item_map[item_id].copy()
        item["rrf_score"] = round(rrf_scores[item_id], 6)
        item["rrf_rank"] = final_rank
        fused_results.append(item)
    
    return fused_results


def _prepare_ranked_list_for_rrf(
    items: List[Dict],
    source_type: str,
    distance_key: str = "distance",
    id_prefix: str = "",
) -> List[Dict]:
    """
    Prepare a ranked list for RRF fusion by normalizing format.
    
    Args:
        items: List of items to prepare
        source_type: Source type tag ("historical_error", "artifact", "document")
        distance_key: Key name for similarity distance (default: "distance")
        id_prefix: Prefix for unique ID generation (default: "")
    
    Returns:
        Normalized list with rank, unique_id, source fields
    """
    if not items:
        return []
    
    prepared = []
    for rank, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            continue
        
        normalized = item.copy()
        
        # Assign rank based on position (lower distance = better rank = lower number)
        normalized["rank"] = rank
        normalized["original_rank"] = rank
        
        # Create unique ID
        existing_id = str(item.get("vector_id") or item.get("id") or item.get("request_id") or "").strip()
        if existing_id:
            normalized["unique_id"] = f"{id_prefix}{existing_id}" if id_prefix else existing_id
        else:
            normalized["unique_id"] = f"{source_type}_{rank}"
        
        # Tag with source type
        normalized["source"] = source_type
        
        # Preserve original distance/score
        if distance_key in item:
            normalized["original_distance"] = item[distance_key]
        
        prepared.append(normalized)
    
    return prepared


def _apply_triple_source_rrf_fusion(
    historical_errors: List[Dict],
    artifact_results: List[Dict],
    document_results: List[Dict],
    top_k: int = 3,
    rrf_k: int = 60,
) -> Dict[str, Any]:
    """
    Apply RRF fusion across three sources: historical errors, artifacts, documents.
    
    Args:
        historical_errors: List of historical error matches
        artifact_results: List of artifact search results
        document_results: List of document search results
        top_k: Number of top results to return (default: 3)
        rrf_k: RRF constant (default: 60)
    
    Returns:
        Dict with unified_evidence (top_k items) and rrf_metadata
    """
    # Prepare ranked lists for each source
    historical_ranked = _prepare_ranked_list_for_rrf(
        historical_errors,
        source_type="historical_error",
        distance_key="distance",
        id_prefix="hist_"
    )
    
    artifact_ranked = _prepare_ranked_list_for_rrf(
        artifact_results,
        source_type="artifact",
        distance_key="distance",
        id_prefix="art_"
    )
    
    document_ranked = _prepare_ranked_list_for_rrf(
        document_results,
        source_type="document",
        distance_key="distance",
        id_prefix="doc_"
    )
    
    # Apply RRF fusion
    all_ranked_lists = []
    if historical_ranked:
        all_ranked_lists.append(historical_ranked)
    if artifact_ranked:
        all_ranked_lists.append(artifact_ranked)
    if document_ranked:
        all_ranked_lists.append(document_ranked)
    
    if not all_ranked_lists:
        return {
            "unified_evidence": [],
            "rrf_metadata": {
                "total_sources": 0,
                "total_items": 0,
                "fusion_applied": False,
                "top_k": top_k,
            }
        }
    
    fused_results = reciprocal_rank_fusion(
        all_ranked_lists,
        rank_key="rank",
        id_key="unique_id",
        k=rrf_k
    )
    
    # Select top K
    top_evidence = fused_results[:top_k]
    
    # Calculate source distribution
    source_counts = {}
    for item in top_evidence:
        source = item.get("source", "unknown")
        source_counts[source] = source_counts.get(source, 0) + 1
    
    # Build metadata
    metadata = {
        "total_sources": len(all_ranked_lists),
        "total_items": len(historical_ranked) + len(artifact_ranked) + len(document_ranked),
        "fusion_applied": True,
        "top_k": top_k,
        "rrf_constant_k": rrf_k,
        "source_distribution": source_counts,
        "input_counts": {
            "historical_errors": len(historical_ranked),
            "artifacts": len(artifact_ranked),
            "documents": len(document_ranked),
        },
        "avg_rrf_score": round(sum(item.get("rrf_score", 0) for item in top_evidence) / len(top_evidence), 6) if top_evidence else 0.0,
    }
    
    return {
        "unified_evidence": top_evidence,
        "rrf_metadata": metadata,
    }


def handle_adapter_impact(project_name: str = "") -> Dict:
    """A number that shows the impact of the feedback loop:
    the helpful-rate of recommendations while the W adapter was ON vs OFF, from the
    thumbs votes (each vote carries the adapter state at vote time). Votes recorded before the
    tracking began are reported as untracked - never guessed. Cached for a short window."""
    proj = str(project_name or "").strip().lower()
    from src.utils import ttl_cache
    from src.utils.project_details import list_all_recommendation_feedback

    votes = ttl_cache.get_or_compute(("adapter-impact-votes",), list_all_recommendation_feedback)

    buckets = {"with_adapter": {"helpful": 0, "not_helpful": 0},
               "without_adapter": {"helpful": 0, "not_helpful": 0},
               "untracked": {"helpful": 0, "not_helpful": 0}}
    for vote in votes:
        if proj and str(vote.get("project_name") or "").strip().lower() != proj:
            continue
        is_helpful = vote.get("is_helpful")
        if is_helpful is not True and is_helpful is not False:
            continue
        flag = vote.get("adapter_enabled")
        key = "with_adapter" if flag is True else ("without_adapter" if flag is False else "untracked")
        buckets[key]["helpful" if is_helpful else "not_helpful"] += 1

    def _rated(bucket: Dict) -> Dict:
        total = bucket["helpful"] + bucket["not_helpful"]
        rate = round(100.0 * bucket["helpful"] / total, 1) if total else None
        return {**bucket, "total": total, "helpful_rate_percent": rate}

    data = {key: _rated(bucket) for key, bucket in buckets.items()}
    with_rate = data["with_adapter"]["helpful_rate_percent"]
    without_rate = data["without_adapter"]["helpful_rate_percent"]
    impact = round(with_rate - without_rate, 1) if (with_rate is not None and without_rate is not None) else None
    return {
        "success": True,
        "data": {
            **data,
            "impact_percent_points": impact,
            "note": "Each vote carries the adapter state at vote time; votes from before this tracking appear as untracked.",
        },
    }


def handle_trace_explain(trace_id: str, request_id: str) -> Dict:
    """Take one candidate's context score apart, down to the values that produced it.

    This detail is not displayed on the dashboard by default, only where debugging needs it.
    The values are calculated at click time rather than kept pre-calculated, and the breakdown
    goes one level deeper, showing how each step and each number came about.

    So nothing here is read from a stored explanation. The context score is recomputed by calling
    _fix_context_score - the SAME function that produced the number in the first place, with the
    same stored inputs - and asked for its working. A second implementation that agreed most of
    the time would be worse than useless: it would disagree exactly when something was wrong,
    which is the only moment anyone opens this page.

    The recomputed total is compared with the one stored on the row. They can legitimately
    differ, because the weights are read live and an administrator may have changed one since;
    that is reported rather than hidden, because two numbers quietly disagreeing is the thing
    this page exists to prevent.
    """
    from src.utils import recommendation_trace

    trace_id = str(trace_id or "").strip()
    request_id = str(request_id or "").strip()
    traces = recommendation_trace.get_traces_for_request(trace_id)
    trace = next((t for t in traces if str(t.get("trace_id") or "") == trace_id), None) \
        or (traces[0] if traces else None)
    if not trace:
        return {"success": False, "error": "trace not found"}

    candidate = next((c for c in (trace.get("candidates") or [])
                      if str(c.get("request_id") or "") == request_id), None)
    if not candidate:
        return {"success": False, "error": "that candidate is not on this trace"}

    query_context = trace.get("query_context") or {}
    context = {
        "task_paths": [str(x) for x in (query_context.get("task_paths") or [])],
        "file_names": [str(x) for x in (query_context.get("file_names") or [])],
        "tokens": [str(x) for x in (query_context.get("tokens") or [])],
    }

    try:
        payload = get_final_build_payload(request_id) or {}
    except Exception:
        payload = {}
    try:
        instances = get_fix_instances(request_id) or []
    except Exception:
        instances = []

    details: Dict = {}
    recomputed = _fix_context_score(fix_instances=instances, final_payload=payload,
                                    context=context, details=details)
    points = (details.get("points") or {})

    cfg = _rc_get_config_cached() or {}
    def _w(name, fallback):
        try:
            return float(cfg.get(name, fallback))
        except (TypeError, ValueError):
            return float(fallback)

    candidate_task = str((payload or {}).get("task_name") or "")
    fix_files = sorted({str(i.get("file_name") or "") for i in instances if i.get("file_name")})
    fix_tokens = sorted({str(t) for i in instances for t in (i.get("config_tokens") or []) if t})

    # Level three: for each part, what was compared, the rule, and what it produced. The values
    # are the real ones - abstract descriptions cannot answer "how did this become 4.00".
    parts = [
        {
            "part": "Same task",
            "compared": {
                "the failing build ran": context["task_paths"],
                "this fix belongs to": candidate_task,
            },
            "rule": f"all or nothing, {_w('baseTaskWeight', 8.0):g} points",
            "matched": details.get("matched_fix_tasks") or (
                [candidate_task] if details.get("candidate_task_in_query_tasks") else []),
            "points": points.get("task", 0.0),
        },
        {
            "part": "Same file",
            "compared": {
                "files in this failure": context["file_names"],
                "files this fix changed": fix_files,
            },
            "rule": f"all or nothing, {_w('baseFileWeight', 6.0):g} points - one match is enough",
            "matched": details.get("matched_files") or [],
            "points": points.get("file", 0.0),
        },
        {
            "part": "Configuration tokens",
            "compared": {
                "values in this failure": context["tokens"],
                "values in this fix": fix_tokens,
            },
            "rule": f"1 point for each shared value, up to {_w('baseTokenWeight', 4.0):g}",
            "matched": details.get("matched_tokens") or [],
            "points": points.get("tokens", 0.0),
        },
        {
            "part": "Usage history",
            "compared": {"times this fix has been recommended and helped":
                         _recommended_hit_count(payload)},
            "rule": "1 point each, up to 3",
            "matched": [],
            "points": points.get("hits", 0.0),
        },
    ]

    # What was recorded at the time, for each part. The trace already keeps the named matches,
    # so the page can say when the live recomputation disagrees with them instead of
    # quietly showing today's answer as though it were the one that was used.
    then = candidate.get("base_matches") or {}
    for part, key in (("Same task", "matched_fix_tasks"), ("Same file", "matched_files"),
                      ("Configuration tokens", "matched_tokens")):
        entry = next(p for p in parts if p["part"] == part)
        was = then.get(key)
        entry["matched_when_recommended"] = was if isinstance(was, list) else (
            [was] if was else [])
        entry["same_as_when_recommended"] = (
            sorted(entry["matched"]) == sorted(entry["matched_when_recommended"]))

    stored_components = {k: _explain_float(v) for k, v in
                         (candidate.get("context_components") or {}).items()}
    stored_context = _explain_float(candidate.get("context_score"))
    base_now = round(float(recomputed), 2)
    base_then = round(stored_components.get("base", 0.0), 2)

    # Everything the row's expand panel used to show now comes from here instead. The deeper
    # detail does not belong on the dashboard at all - it is only needed for debugging, and it
    # is too large for an expand panel - so the panel is gone, the row carries a clickable
    # icon, and this separate page carries all of it.
    evidence = {
        "error_similarity": candidate.get("similarity"),
        "artifact_similarity": candidate.get("artifact_match_similarity"),
        "combined_evidence": candidate.get("evidence_similarity"),
        "match_type": candidate.get("match_type") or "",
        "match_points": candidate.get("match_score"),
        "evidence_state": candidate.get("evidence_state") or "",
    }

    influence = candidate.get("adapter_influence") or {}

    def _num(value):
        try:
            text = str(value).strip()
            return float(text) if text else None
        except (TypeError, ValueError):
            return None

    sim_base = _num(influence.get("similarity_base"))
    sim_with = _num(influence.get("similarity_with_adapter"))
    delta = _num(influence.get("similarity_delta"))
    adapter = {
        "available": sim_base is not None or sim_with is not None,
        "similarity_without": sim_base,
        "similarity_with": sim_with,
        "change": delta,
        "base_rank": influence.get("base_rank") or "",
        "learned_rank": influence.get("learned_rank") or "",
        "space": influence.get("space") or "base",
        "reason": _adapter_absent_reason(trace, candidate),
    }
    adapter["chain"] = _adapter_score_chain(candidate, sim_base, sim_with, stored_context)

    return {
        "success": True,
        "trace_id": trace_id,
        "request_id": request_id,
        "computed_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "evidence": evidence,
        "adapter": adapter,
        "votes": {
            "up": candidate.get("thumbs_up") or 0,
            "down": candidate.get("thumbs_down") or 0,
            "validated_for_error": candidate.get("validated_for_error") or 0,
        },
        "artifact": candidate.get("artifact_matched") or {},
        "query": {
            "error": trace.get("query_error") or "",
            "task": trace.get("task_path") or "",
            "changed_files": trace.get("changed_files") or [],
        },
        "candidate": {
            "task": candidate.get("task_name") or "",
            "file": candidate.get("file_name") or "",
            "match_type": candidate.get("match_type") or "",
            "similarity": candidate.get("similarity"),
            "artifact_similarity": candidate.get("artifact_match_similarity"),
            "evidence_similarity": candidate.get("evidence_similarity"),
            "match_score": candidate.get("match_score"),
            "context_score": candidate.get("context_score"),
            "final_score": candidate.get("final_score"),
            # The bonus that sits OUTSIDE match + context (applied last, onto the final score,
            # so the trims cannot claw it back). Without it the row does not add up: a live
            # table read match 12.00 + context 9.33 = final 23.60, and nobody could say why.
            "distinctive_points": candidate.get("distinctive_points"),
            "distinctive_overlap": candidate.get("distinctive_overlap"),
            "similarity_source": candidate.get("similarity_source"),
        },
        # Level two, straight off the row - these are the numbers the ranking actually used.
        "components": stored_components,
        "components_total": round(sum(stored_components.values()), 2),
        "context_score": stored_context,
        # Level three, worked out now.
        "parts": parts,
        "recomputed_base": base_now,
        "drift": {
            "base_when_recommended": base_then,
            "base_now": base_now,
            "differs": abs(base_now - base_then) > 0.02,
            "note": ("The same inputs now produce a different number than they did when this "
                     "recommendation was made - a weight has been changed since, or the stored "
                     "inputs were trimmed to fit the record. The row keeps what was actually "
                     "used at the time; this page shows what the code would do today."
                     if abs(base_now - base_then) > 0.02 else ""),
        },
    }


def _adapter_score_chain(candidate: Dict, sim_base, sim_with, context_score: float) -> Dict:
    """The adapter followed all the way to the final score.

    The influence is shown where it actually lands: on the similarity,
    then through match, then on the final score and the position in the list. Two columns of
    similarity on their own do not answer "so what" - the same 0.07 is worth nothing on a
    candidate whose context already decided the order, and worth a place on one where it did not.

    The chain is the product's own arithmetic, replayed once per space:

        combined evidence = (1 - w) x error similarity + w x artifact similarity
        match points      = base x combined evidence
        final             = match points + context

    Context is deliberately shown as the same figure in both columns. It is not an oversight:
    the adapter changes retrieval, not the context terms, so this is the one place the reader
    can see exactly how far its influence reaches.

    One of the two columns is what ranked the candidate and the other is a counterfactual;
    which is which depends on whether the adapter was on for the project (one space
    decides, no rank fusion). `adapter.space` on the response says so, and the page labels
    the columns from it.
    """
    match_type = str(candidate.get("match_type") or "").strip().lower()
    artifact_sim = None
    try:
        raw = str(candidate.get("artifact_match_similarity") or "").strip()
        artifact_sim = float(raw) if raw else None
    except (TypeError, ValueError):
        artifact_sim = None

    cfg = _rc_get_config_cached() or {}
    try:
        weight = max(0.0, min(1.0, float(cfg.get("evidenceSimilarityWeight", 0.5))))
    except (TypeError, ValueError):
        weight = 0.5

    base_points = _match_type_score(match_type)

    _sim_source = str(candidate.get("similarity_source") or "").strip().lower()
    # The SAME blend the live scoring applied (_blend_evidence), replayed from what the trace
    # stored: the contrast share sits in similarity_components ("" when contrast was off). A
    # second copy of the formula here is how this page drifted from the ranking once before.
    _comps = candidate.get("similarity_components") if isinstance(candidate.get("similarity_components"), dict) else {}
    _share_raw = str(_comps.get("contrast_share") or "").strip()
    try:
        _share = float(_share_raw) if _share_raw else None
    except (TypeError, ValueError):
        _share = None
    _contrast_on = _share is not None

    def _leg(error_sim):
        if error_sim is None:
            return None
        if artifact_sim is None:
            combined = error_sim
        else:
            combined, _ = _blend_evidence(error_sim, _sim_source != "no_error_text",
                                          artifact_sim, _share, _contrast_on, weight)
        combined = max(0.0, min(1.0, combined))
        match_points = round(base_points * combined, 2)
        return {
            "error_similarity": round(error_sim, 3),
            "combined_evidence": round(combined, 3),
            "match_points": match_points,
            "context": round(context_score, 2),
            "final": round(match_points + context_score, 2),
        }

    without = _leg(sim_base)
    with_adapter = _leg(sim_with)
    if not without or not with_adapter:
        return {"available": False}

    return {
        "available": True,
        "weight": weight,
        "match_base": base_points,
        "artifact_similarity": artifact_sim,
        # Always on now. The key stays so a page built against the earlier shape keeps working
        # rather than reading it as absent and claiming the weighting is off.
        "evidence_weighting_on": True,
        "without": without,
        "with": with_adapter,
        "final_change": round(with_adapter["final"] - without["final"], 2),
        "context_unchanged": True,
    }


def _adapter_absent_reason(trace: Dict, candidate: Dict) -> str:
    """Why this candidate has no adapter figures, in one line.

    It used to show five dashes, which reads as broken - and after somebody has marked a
    recommendation helpful several times, the natural next thought is that the votes should have
    filled them in. They cannot: the adapter learns from proven fixes, not from votes, and it
    produces no figures at all unless it is running. Saying which of those applies is worth more
    than five dashes.
    """
    match_type = str(candidate.get("match_type") or "").lower()
    if match_type in ("exact", "task"):
        found_by = "an exact error signature" if match_type == "exact" else "task identity"
        return (f"Not applicable: this candidate was found by {found_by}, which the adapter never "
                "sees. Only semantic matches carry an adapter effect.")

    reason = str(((trace.get("adapter_state") or {}).get("reason")) or "")
    if reason == "off":
        return "The adapter is switched off for this project."
    if reason == "not_trained":
        return "No adapter has been trained yet, so nothing ran."
    if reason == "no_learned_space":
        return ("The adapter is on and trained, but its search index is empty or the wrong size, "
                "so its search returned nothing. Rebuild the learned space.")
    return ("The adapter did not return this candidate, so there is no second similarity to "
            "compare. Votes do not affect this - the adapter learns from proven fixes, not votes.")


def _explain_float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0
