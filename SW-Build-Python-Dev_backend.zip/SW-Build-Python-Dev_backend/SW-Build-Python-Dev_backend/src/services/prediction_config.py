"""
src/services/prediction_config.py — Build-Failure-Prediction tunables, stored in DynamoDB.

One record in a DEDICATED table (`prediction_config{sfx}`) holds the engine knobs that the dashboard
edits and the extension reads at scan time:
    contextWindow        radius: N lines above + N below the matched line (window = 2N+1)
    cosineWeight/diceWeight   blend for the Stage-2 score (Risk = Cos*cw% + Dice*dw%)
    lowRiskUpperLimit/mediumRiskUpperLimit   3 risk bands: Low [0,low]  Medium (low,med]  High (med,100]

Defaults match the extension's current hardcoded values + the design doc. The table is schemaless, so
NEW fields can be added later with no migration: get_config() merges the stored item over DEFAULTS and
passes through any extra stored keys. An audit (updated_by / updated_at) is kept on every write.
"""
import time
import logging

from src.databases.database import get_dynamodb
from src.configurations import config

logger = logging.getLogger(__name__)

CONFIG_TABLE = f"prediction_config{config.DYNAMODB_TABLE_SUFFIX}"
CONFIG_KEY = "build_prediction"      # single global record (per-project can be added later)
_CACHE_TTL = 30

# Defaults = the extension's current constants (PredictionRiskAnalyzer.ts) + design doc.
DEFAULTS = {
    "contextWindow": 10,        # 10 above + line + 10 below = 21-line window
    "cosineWeight": 70,
    "diceWeight": 30,
    "lowRiskUpperLimit": 30,
    "mediumRiskUpperLimit": 70,
    # Rollout step C (Prediction Feedback Enhancement doc): reliability scorecards from the
    # judged shadow reports adjust prediction ranking. 0 = OFF (shipped behavior unchanged).
    "scorecardWeightingEnabled": 0,
}
_NUMERIC = set(DEFAULTS.keys())

_cache = {"data": None, "ts": 0.0}
_table_ready = False


def _table():
    return get_dynamodb().Table(CONFIG_TABLE)


def _ensure_table():
    global _table_ready
    if _table_ready:
        return
    try:
        ddb = get_dynamodb()
        if CONFIG_TABLE not in [t.name for t in ddb.tables.all()]:
            logger.info("creating prediction config table %s", CONFIG_TABLE)
            ddb.create_table(
                TableName=CONFIG_TABLE,
                KeySchema=[{"AttributeName": "config_key", "KeyType": "HASH"}],
                AttributeDefinitions=[{"AttributeName": "config_key", "AttributeType": "S"}],
                BillingMode="PAY_PER_REQUEST",
            ).wait_until_exists()
        _table_ready = True
    except Exception:
        logger.exception("ensure prediction config table failed")


def _read_raw() -> dict:
    try:
        _ensure_table()  # create on read too, avoids ResourceNotFound on a fresh env
        item = _table().get_item(Key={"config_key": CONFIG_KEY}).get("Item") or {}
    except Exception:
        logger.exception("read prediction config failed - using defaults")
        item = {}
    data = dict(DEFAULTS)
    for k, v in item.items():            # stored over defaults; unknown future keys pass through
        if k == "config_key":
            continue
        data[k] = v
    for k in _NUMERIC:                   # coerce the known knobs to int
        try:
            data[k] = int(data[k])
        except Exception:
            data[k] = DEFAULTS[k]
    return data


def get_config(force: bool = False) -> dict:
    now = time.time()
    if not force and _cache["data"] is not None and (now - _cache["ts"]) < _CACHE_TTL:
        return _cache["data"]
    data = _read_raw()
    _cache["data"], _cache["ts"] = data, now
    return data


def public_view(cfg: dict | None = None) -> dict:
    """Just the 5 tunables (what the GET API + extension consume)."""
    cfg = cfg or get_config()
    return {k: int(cfg.get(k, DEFAULTS[k])) for k in DEFAULTS}


def _write(updates: dict, by: str) -> dict:
    _ensure_table()
    data = dict(get_config(force=True))
    data.update(updates)
    item = {k: v for k, v in data.items()}
    item["config_key"] = CONFIG_KEY
    item["updated_by"] = by
    item["updated_at"] = int(time.time())
    _table().put_item(Item=item)
    _cache["data"], _cache["ts"] = data, time.time()
    return data


# ---- validated setters (raise ValueError on bad input) ----
def set_context_window(value, by: str = "dashboard") -> dict:
    v = int(value)
    if not (5 <= v <= 100):
        raise ValueError("contextWindow must be between 5 and 100")
    return _write({"contextWindow": v}, by)


def set_similarity_weights(cosine, dice, by: str = "dashboard") -> dict:
    c, d = int(cosine), int(dice)
    if c < 0 or d < 0 or (c + d) != 100:
        raise ValueError("cosineWeight + diceWeight must equal 100")
    return _write({"cosineWeight": c, "diceWeight": d}, by)


def set_risk_thresholds(low, medium, by: str = "dashboard") -> dict:
    lo, me = int(low), int(medium)
    # 3 bands, user-defined: Low [0,low]  Medium (low,med]  High (med,100]. Only need low < medium.
    if not (5 <= lo < me <= 100):
        raise ValueError("require 5 <= lowRiskUpperLimit < mediumRiskUpperLimit <= 100")
    return _write({"lowRiskUpperLimit": lo, "mediumRiskUpperLimit": me}, by)


def set_scorecard_weighting(enabled, by: str = "dashboard") -> dict:
    v = 1 if str(enabled).strip().lower() in ("1", "true", "yes", "on") else 0
    return _write({"scorecardWeightingEnabled": v}, by)


def reset_to_default(by: str = "dashboard") -> dict:
    """Restore all tunables to their defaults (the dashboard 'Reset to Default' button)."""
    return _write(dict(DEFAULTS), by)
