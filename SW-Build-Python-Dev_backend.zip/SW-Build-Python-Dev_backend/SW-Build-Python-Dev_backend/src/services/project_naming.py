"""
src/services/project_naming.py — derive CUSTOMER and PROJECT from a project name.

Why this exists. Grouping today is manual: an admin creates a group and gives it a glob
(HIP-26 / "1GHIO*"), and every new project in the estate needs someone to notice it and file it.
That is sustainable for a pilot and not for a worldwide rollout - the 29-Sep review called it out
as a daily maintenance overhead. The organisation already names projects to a convention, so the
customer and the project are ALREADY IN THE NAME; we can read them instead of re-declaring them.

The model that replaces the flat group: a two-level identity derived from the name.

    1GHIO_000U0_TD5   ->  customer "1G"   project "HIO"
    4P231_PTP4LITE    ->  customer "4P"   project "231"

    customer (parent)
      +- project (child)

  - PROJECT scope  = the exact (customer, project) pair.
  - GROUP scope    = every project sharing the CUSTOMER.

Manual groups are NOT deleted by this. Management asked to see friendly family names (HIP26,
PTP4Lite) rather than raw project ids, so the group definitions stay as the DISPLAY name; they
simply stop being what retrieval scope is built from.

Two deliberate choices:

  - The convention regex is CONFIGURATION, not code. Schaeffler owns the naming standard and said
    they would supply the authoritative expression; DEFAULT_REGEX below only reproduces the
    examples given on the call, so it must not be trusted as the standard.
  - `namingEnabled` defaults to 0. Derived identity changes which projects share evidence, which
    changes recommendations, so it ships OFF and is switched on per deployment after review. With
    it off, every caller behaves exactly as it does today.

Storage: one schemaless record in `project_naming{sfx}`, created on demand, mirroring
prediction_config so new keys need no migration.
"""
import re
import time
import logging

from src.databases.database import get_dynamodb
from src.configurations import config

logger = logging.getLogger(__name__)

CONFIG_TABLE = f"project_naming{config.DYNAMODB_TABLE_SUFFIX}"
CONFIG_KEY = "project_naming"
_CACHE_TTL = 30

# There is NO default convention, and that is deliberate.
#
# The first draft shipped the examples from the call as the default:
#     ^(?P<customer>[a-z0-9]{2})(?P<project>[a-z0-9]{3})
# which reads 1GHIO as 1g/hio correctly - and also reads testgbe as customer "te", project "stg".
# A prefix expression matches EVERY name, so an unconventional project is not merely mis-grouped:
# it is put in a customer alongside any other project that happens to share two leading
# characters, and those two projects then share evidence. That is the confidentiality failure the
# scope rules exist to prevent, arriving silently through a placeholder nobody chose.
#
# So the shipped default derives nothing. Schaeffler owns the naming standard and said they would
# supply the expression; until it is configured, every project keeps its manual group. The example
# below is kept for the preview endpoint and the documentation ONLY - it is never active. It adds
# the boundary the first draft lacked - (?:[_\-]|$) - which is what makes testgbe fail to match
# rather than be split; see _normalize for why the separator has to survive to be asserted.
DEFAULT_REGEX = ""
EXAMPLE_REGEX = r"^(?P<customer>[a-z0-9]{2})(?P<project>[a-z0-9]{3})(?:[_\-]|$)"

DEFAULTS = {
    "namingEnabled": 0,          # 0 = OFF: grouping stays manual, behaviour unchanged
    "namingRegex": DEFAULT_REGEX,
}
_NUMERIC = {"namingEnabled"}

_cache = {"data": None, "ts": 0.0}
_table_ready = False


def _table():
    return get_dynamodb().Table(CONFIG_TABLE)


def _ensure_table():
    global _table_ready
    if _table_ready:
        return
    try:
        ddb = get_dynamodb()
        if CONFIG_TABLE not in [t.name for t in ddb.tables.all()]:
            logger.info("creating project naming table %s", CONFIG_TABLE)
            ddb.create_table(
                TableName=CONFIG_TABLE,
                KeySchema=[{"AttributeName": "config_key", "KeyType": "HASH"}],
                AttributeDefinitions=[{"AttributeName": "config_key", "AttributeType": "S"}],
                BillingMode="PAY_PER_REQUEST",
            ).wait_until_exists()
        _table_ready = True
    except Exception:
        logger.exception("ensure project naming table failed")


def _read_raw() -> dict:
    try:
        _ensure_table()
        item = _table().get_item(Key={"config_key": CONFIG_KEY}).get("Item") or {}
    except Exception:
        logger.exception("read project naming config failed - using defaults")
        item = {}
    data = dict(DEFAULTS)
    for k, v in item.items():
        if k == "config_key":
            continue
        data[k] = v
    for k in _NUMERIC:
        try:
            data[k] = int(data[k])
        except (TypeError, ValueError):
            data[k] = DEFAULTS[k]
    return data


def get_config() -> dict:
    now = time.time()
    if _cache["data"] is not None and (now - _cache["ts"]) < _CACHE_TTL:
        return dict(_cache["data"])
    data = _read_raw()
    _cache["data"] = data
    _cache["ts"] = now
    return dict(data)


def set_config(*, enabled=None, regex=None, updated_by: str = "") -> dict:
    """Write the convention. A regex that does not compile, or that lacks the two named groups, is
    rejected here rather than at resolve time - a bad expression would otherwise silently return no
    customer for every project and collapse the whole estate to project scope."""
    cfg = get_config()
    if regex is not None:
        candidate = str(regex or "").strip()
        if not candidate:
            raise ValueError("namingRegex is required")
        try:
            compiled = re.compile(candidate)
        except re.error as exc:
            raise ValueError(f"namingRegex is not a valid regular expression: {exc}") from exc
        if "customer" not in compiled.groupindex or "project" not in compiled.groupindex:
            raise ValueError(
                "namingRegex must define the named groups (?P<customer>...) and (?P<project>...)"
            )
        cfg["namingRegex"] = candidate
    if enabled is not None:
        cfg["namingEnabled"] = 1 if str(enabled).strip().lower() in ("1", "true", "yes", "on") else 0
    item = {"config_key": CONFIG_KEY}
    item.update({k: v for k, v in cfg.items()})
    item["updated_at"] = int(time.time())
    if updated_by:
        item["updated_by"] = str(updated_by)
    try:
        _ensure_table()
        _table().put_item(Item=item)
    except Exception:
        logger.exception("write project naming config failed")
        raise
    _cache["data"] = None
    _cache["ts"] = 0.0
    _identity_cache.clear()
    # The convention decides who shares evidence, so the already-resolved scopes are now stale.
    try:
        from src.services import project_groups
        project_groups.invalidate_scope_cache()
    except Exception:
        logger.exception("could not invalidate the resolved scope cache after a naming change")
    return get_config()


def is_enabled() -> bool:
    try:
        return int(get_config().get("namingEnabled") or 0) == 1
    except (TypeError, ValueError):
        return False


def _normalize(value: str) -> str:
    """Lower-case and trim, and KEEP the separators.

    The glob matcher next door (project_groups._norm_for_match) strips _ and - so that 1g_hio and
    1GHIO compare equal, and copying that here was a mistake worth recording: the separator is the
    only boundary that tells the customer/project prefix apart from the rest of the name.

        1ghio_000u0_td5   -> prefix 1ghio  ends at the underscore
        4p231_ptp4lite    -> prefix 4p231  ends at the underscore
        testgbe           -> no 5-character prefix followed by a boundary, so nothing is derived

    With separators stripped, every name became one long token, a prefix expression matched all of
    them, and testgbe was read as customer "te". Keeping the separator lets the convention assert
    the boundary - e.g. (?:[_\\-]|$) after the project group - which is what makes an unconventional
    name fail to match instead of being silently split.
    """
    return str(value or "").strip().lower()


_identity_cache: dict = {}


def derive_identity(project_name: str) -> tuple:
    """(customer, project) read out of the project name, or ("", "") when it does not fit.

    A name that does not match the convention is NOT forced into a customer. It falls through to
    ("", ""), and every caller treats that as "no derived identity" and keeps today's behaviour.
    Guessing a customer from an unconventional name would put unrelated projects into one another's
    evidence pool, which is the confidentiality problem the group rules exist to prevent.
    """
    normalized = _normalize(project_name)
    if not normalized:
        return "", ""
    cached = _identity_cache.get(normalized)
    if cached is not None:
        return cached
    cfg = get_config()
    pattern = str(cfg.get("namingRegex") or "").strip()
    if not pattern:
        # No convention configured. Deriving from a guessed pattern is worse than not deriving.
        _identity_cache[normalized] = ("", "")
        return "", ""
    try:
        rx = re.compile(pattern)
    except re.error:
        logger.warning("stored namingRegex does not compile - no identity derived")
        _identity_cache[normalized] = ("", "")
        return "", ""
    match = rx.match(normalized)
    if not match:
        _identity_cache[normalized] = ("", "")
        return "", ""
    customer = str(match.groupdict().get("customer") or "").strip().lower()
    project = str(match.groupdict().get("project") or "").strip().lower()
    result = (customer, project) if customer else ("", "")
    if len(_identity_cache) > 2000:
        _identity_cache.clear()
    _identity_cache[normalized] = result
    return result


def derive_customer(project_name: str) -> str:
    return derive_identity(project_name)[0]


def public_view(cfg: dict = None) -> dict:
    data = dict(cfg or get_config())
    # exampleRegex is illustrative only. It is NOT applied when namingRegex is unset - see the note
    # on DEFAULT_REGEX for why a prefix expression must never be a default.
    data["exampleRegex"] = EXAMPLE_REGEX
    data["configured"] = bool(str(data.get("namingRegex") or "").strip())
    return data
