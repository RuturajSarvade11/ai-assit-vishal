"""
src/services/recommendation_config.py — Recommendation relevance threshold, ADMIN-configurable.

The minimum similarity for showing a recommendation is part of the configuration — an admin
edits it on the dashboard, no release needed to tune it.

Stored as a SECOND record (config_key = "recommendation") in the existing prediction_config
table (schemaless single-record pattern — no migration). One knob:

    minSimilarityPercent   0..100 — a candidate must reach this CONFIDENCE percent to occupy a
                           top-3 slot; below it, the response says clearly that nothing similar
                           enough was found. 0 = gate OFF. Confidence is the similarity that
                           earned the candidate's match points: 1.0 for an exact signature, the
                           error cosine (or the error+artifact blend) otherwise - so 70 means
                           "at least 70% similar", not a share of some score ceiling.

Reads are cached for 30s. The RECOMMENDATION_MIN_FINAL_SCORE env value stays as the fallback
when the store is unset/unreachable, so calibration-by-env keeps working on any environment.
"""
import logging
import time
from decimal import Decimal

from src.databases.database import get_dynamodb
from src.configurations import config
from src.services import prediction_config as _pc

logger = logging.getLogger(__name__)

CONFIG_TABLE = f"prediction_config{config.DYNAMODB_TABLE_SUFFIX}"
CONFIG_KEY = "recommendation"
_CACHE_TTL = 30

DEFAULTS = {"minSimilarityPercent": 0.0}

# ONE table of scoring defaults. Every number the scorer falls back to when the config table is
# unreadable comes from here, and get_config() fills the same values in - so there is no second
# copy of a default anywhere in handlers to drift away from this one.
SCORING_DEFAULTS = {
    "exactMatchBase": 18.0,       # match points of an exact-signature candidate
    "semanticMatchBase": 12.0,    # match points of a semantic/task candidate at similarity 1.0
    "baseTaskWeight": 3.0,
    "baseFileWeight": 6.0,
    "baseTokenWeight": 4.0,
    "historyWeightCeiling": 4.0,
    "evidenceSimilarityWeight": 0.5,
    # ARTIFACTS ARE USED WHENEVER THEY ARE PRESENT. This shipped at 0, which switched the whole
    # artifact-evidence path off: the artifacts the extension collects never changed a score,
    # and two candidates with identical error text were separated by task, file and history
    # alone. At the semantic base (12) the lift is worth exactly one full error match, so a
    # candidate whose stored log matches this failure gains as much as a perfect error match,
    # and the blend in the match score (evidenceSimilarityWeight) and the evidence gate on
    # history both come alive with it. A candidate with no artifacts loses nothing it earned
    # (absence is not contradiction); it simply cannot earn the lift.
    "artifactMatchWeight": 12.0,
    "afterPatternWeight": 0.0,
    "feedbackSupportWeight": 0.0,
    # Below this spread between the best and worst artifact evidence in a pool the candidates'
    # logs count as agreeing (absolute lift for all); at or above it the contrast decides.
    "evidenceContrastMinSpread": 0.15,
    # POPULARITY IS NOT EVIDENCE. Every time a fix was SHOWN it earned points three ways
    # (recommended_count +1 each up to 3, hit_count x 0.25 up to 3, 0.15 per "shown" outcome),
    # so whatever ranked first kept ranking first and a newer, closer fix started 6+ points
    # behind. These multipliers scale those view-derived points: 0 = views earn nothing
    # (default), 1 = the previous behaviour. Confirmed successes (success_correlated) are not
    # views and are untouched.
    "usageHitsWeight": 0.0,
    "shownHistoryWeight": 0.0,
    # Helpers (task, file, tokens, history, ...) may total at most this share of the EVIDENCE
    # (error match + artifact lift). 1.0 = the previous "helpers <= evidence", which let a
    # weaker match with more history outrank a clearly closer one; 0.5 keeps helpers a
    # tie-breaker between comparable matches.
    "helperEvidenceRatio": 0.5,
    # Share of the artifact lift a candidate earns when the request carried NO live log and the
    # stored logs were probed with the error text instead (weak, second-hand evidence).
    # 1.0 = previous behaviour (full lift), 0 = ignore stored logs when no live log was sent.
    "errorTextArtifactWeight": 0.25,
    # Shown fixes whose final score is within this share of rank 1 are reported as TIED
    # (response "decision": ambiguous) - the order between them is a tie-break, not a finding.
    "ambiguityMargin": 0.05,
}

_cache = {"data": None, "ts": 0.0}


def _table():
    return get_dynamodb().Table(CONFIG_TABLE)


def get_config(force: bool = False) -> dict:
    now = time.time()
    if not force and _cache["data"] is not None and (now - _cache["ts"]) < _CACHE_TTL:
        return dict(_cache["data"])

    data = dict(DEFAULTS)
    try:
        _pc._ensure_table()  # same table as prediction config; created on first touch
        item = _table().get_item(Key={"config_key": CONFIG_KEY}).get("Item") or {}
        for k, v in item.items():
            if k != "config_key":
                data[k] = v
    except Exception:
        logger.exception("read recommendation config failed — using defaults/env fallback")

    try:
        data["minSimilarityPercent"] = float(data.get("minSimilarityPercent") or 0)
    except (TypeError, ValueError):
        data["minSimilarityPercent"] = 0.0
    data["minSimilarityPercent"] = max(0.0, min(100.0, data["minSimilarityPercent"]))
    try:
        data["taskMatchWeight"] = max(0.0, min(30.0, float(data.get("taskMatchWeight") or 0)))
    except (TypeError, ValueError):
        data["taskMatchWeight"] = 0.0
    try:
        # Ceiling 60: the artifact IS the discriminator when two failures share one error
        # text, so evidence must be able to outweigh every helper signal COMBINED. The default
        # (SCORING_DEFAULTS) is ON; 0 switches the artifact path off deliberately.
        data["artifactMatchWeight"] = max(0.0, min(60.0, float(
            SCORING_DEFAULTS["artifactMatchWeight"] if data.get("artifactMatchWeight") is None
            else data.get("artifactMatchWeight"))))
    except (TypeError, ValueError):
        data["artifactMatchWeight"] = SCORING_DEFAULTS["artifactMatchWeight"]
    try:
        # "additive" (match + context, the shipped behaviour) or "evidence" (the error match
        # multiplies, support can only strengthen it). Anything unrecognised means additive, so a
        # typo can never silently change how every project is scored.
        _mode = str(data.get("scoringMode") or "additive").strip().lower()
        data["scoringMode"] = _mode if _mode in ("additive", "evidence") else "additive"
    except Exception:
        data["scoringMode"] = "additive"
    try:
        data["evidenceScale"] = max(1.0, min(60.0, float(data.get("evidenceScale") or 18.0)))
    except (TypeError, ValueError):
        data["evidenceScale"] = 18.0
    try:
        data["supportScale"] = max(1.0, min(200.0, float(data.get("supportScale") or 30.0)))
    except (TypeError, ValueError):
        data["supportScale"] = 30.0
    try:
        # Whole message against whole message, scored on what DIFFERS. Same range as the artifact
        # lift, and 0 by default so no shipped behaviour moves until an admin sets it.
        data["distinctiveMatchWeight"] = max(0.0, min(60.0, float(data.get("distinctiveMatchWeight") or 0)))
    except (TypeError, ValueError):
        data["distinctiveMatchWeight"] = 0.0
    try:
        data["minSemanticSimilarity"] = max(0.0, min(1.0, float(data.get("minSemanticSimilarity") or 0)))
    except (TypeError, ValueError):
        data["minSemanticSimilarity"] = 0.0
    try:
        data["downvoteSinkMinVotes"] = max(1, min(10, int(float(data.get("downvoteSinkMinVotes") or 1))))
    except (TypeError, ValueError):
        data["downvoteSinkMinVotes"] = 1
    # RETIRED. Similarity weighting is always applied - there is no sensible configuration in
    # which the match score ignores how well the candidate actually matched. Shipped OFF, which
    # left every semantic candidate on the full base: the Match column read a flat 12.00 whatever
    # the similarity beside it, and the ranking fell to circumstantial signals instead.
    # Reported as always-12, and as a tooltip dividing the match by the similarity to recover a
    # "base" of 14.5 or 26 for a number that is only ever 18 or 12.
    # Still READ and reported as True so a dashboard built against the old shape keeps working;
    # a PUT setting it is accepted and ignored rather than failing an older client.
    data["similarityWeightedScoring"] = True
    # Base IDENTITY weights (the weight given to task name, file name and tokens).
    # Each is ONE bounded signal per candidate - the
    # base tier used to award task/file/token points PER FIX INSTANCE, so a solution confirmed
    # N times scored N x the same identity fact and outranked candidates whose ARTIFACT
    # evidence actually matched the live failure. Tunable so balancing needs no release.
    for _k, _default, _cap in (("baseTaskWeight", SCORING_DEFAULTS["baseTaskWeight"], 30.0),
                               ("baseFileWeight", SCORING_DEFAULTS["baseFileWeight"], 30.0),
                               ("baseTokenWeight", SCORING_DEFAULTS["baseTokenWeight"], 30.0)):
        try:
            _v = data.get(_k)
            data[_k] = max(0.0, min(_cap, float(_default if _v is None else _v)))
        except (TypeError, ValueError):
            data[_k] = _default
    # LLM re-ranking is switched off by default - our own scoring must produce the
    # right order; the LLM pick is still RECORDED on the trace for comparison, it just does not
    # promote. False = algorithm order stands.
    data["llmPromoteEnabled"] = bool(data.get("llmPromoteEnabled"))
    # How much of the similarity that earns MATCH points comes from artifact evidence rather
    # than the report error text. 0 = error text only (previous behaviour),
    # 1 = artifacts only; 0.5 = both equally.
    # Repeated-fix pattern: 0 = off (the adapter already learns repeated fixes).
    # Semantic match base: how much the ERROR + artifact similarity can earn.
    # RETRIEVAL SCOPE: how wide the search for candidate fixes goes.
    #   group (DEFAULT)   - a project in a DEFINED group is searched together with
    #                       its siblings in one pass, every source widened; the project's own fix
    #                       wins only a tie. Projects in "Other" or alone in their group stay at
    #                       project scope until an admin assigns them ("Other" is a removal
    #                       bucket, not a group).
    #   project           - the one-project search, byte-identical to the pre-group behaviour.
    # Kept as a string rather than a boolean because the next step is "global", and a scope LEVEL
    # extends where a flag would have to be replaced.
    try:
        # 30-Sep review: three scopes, and the DEFAULT is project. The developer widens per
        # request; this stored value is only the starting point when a request names none.
        # "group" is still accepted as a spelling of "customer" so stored rows need no migration.
        from src.services.project_groups import normalize_scope, SCOPE_PROJECT
        data["recommendationScope"] = normalize_scope(
            data.get("recommendationScope"), default=SCOPE_PROJECT)
    except Exception:
        data["recommendationScope"] = "project"
    # How a candidate's artifact evidence is measured against its rivals (prerequisite
    # for widening the recommendation scope beyond one project):
    #   spread (default, today's proven behaviour) - against the gap between best and worst in
    #           the pool. Amplifies differences, but makes a candidate's points depend on WHO
    #           ELSE is in the pool, so adding a cross-project candidate rescales everyone.
    #   best  - against the strongest evidence present. Pool-composition stable: a weaker
    #           sibling changes nothing, a genuinely better one still demotes.
    try:
        _cm = str(data.get("evidenceContrastMode") or "spread").strip().lower()
        data["evidenceContrastMode"] = _cm if _cm in ("spread", "best") else "spread"
    except Exception:
        data["evidenceContrastMode"] = "spread"
    # Same-error feedback support. Initially shipped ON at 6 so the trace column had something
    # to show; the DEFAULT is now 0 because feedback as an additive score term was rejected:
    # feedback belongs in the ADAPTER, which changes the distance between an error and a fix
    # and therefore the similarity - not a number bolted onto the final score afterwards.
    #
    # The value was also not kept separate from the final score as intended: the points landed
    # on context_score and so on final_score. Defaulting to 0 makes the code true to the
    # intended model without deleting the mechanism - an admin can still set it, and the trace's
    # Feedback effect column is unaffected because it measures the vote-derived RANK terms (the
    # downvote sink and the net-vote tie-break) by counterfactual re-sort, which never used this
    # weight.
    for _k, _default, _cap in (("afterPatternWeight", SCORING_DEFAULTS["afterPatternWeight"], 1.0),
                               ("semanticMatchBase", SCORING_DEFAULTS["semanticMatchBase"], 30.0),
                               # The exact-signature base, configurable like the semantic one.
                               ("exactMatchBase", SCORING_DEFAULTS["exactMatchBase"], 30.0),
                               ("evidenceContrastMinSpread", SCORING_DEFAULTS["evidenceContrastMinSpread"], 1.0),
                               ("feedbackSupportWeight", SCORING_DEFAULTS["feedbackSupportWeight"], 18.0),
                               ("usageHitsWeight", SCORING_DEFAULTS["usageHitsWeight"], 1.0),
                               ("shownHistoryWeight", SCORING_DEFAULTS["shownHistoryWeight"], 1.0),
                               ("helperEvidenceRatio", SCORING_DEFAULTS["helperEvidenceRatio"], 1.0),
                               ("errorTextArtifactWeight", SCORING_DEFAULTS["errorTextArtifactWeight"], 1.0),
                               ("ambiguityMargin", SCORING_DEFAULTS["ambiguityMargin"], 0.5)):
        try:
            _v = data.get(_k)
            data[_k] = max(0.0, min(_cap, float(_default if _v is None else _v)))
        except (TypeError, ValueError):
            data[_k] = _default
    # Total budget for success + after-fix history, so a long record helps without rivalling
    # the evidence of the failure being fixed.
    try:
        data["historyWeightCeiling"] = max(0.0, min(30.0, float(
            SCORING_DEFAULTS["historyWeightCeiling"] if data.get("historyWeightCeiling") is None
            else data.get("historyWeightCeiling"))))
    except (TypeError, ValueError):
        data["historyWeightCeiling"] = SCORING_DEFAULTS["historyWeightCeiling"]
    try:
        data["evidenceSimilarityWeight"] = max(0.0, min(1.0, float(
            SCORING_DEFAULTS["evidenceSimilarityWeight"] if data.get("evidenceSimilarityWeight") is None
            else data.get("evidenceSimilarityWeight"))))
    except (TypeError, ValueError):
        data["evidenceSimilarityWeight"] = SCORING_DEFAULTS["evidenceSimilarityWeight"]

    _cache["data"] = dict(data)
    _cache["ts"] = now
    return data


def set_values(updates: dict, updated_by: str = "") -> dict:
    """Merge-update the recommendation config. Three knobs:
      minSimilarityPercent      0..100  relevance threshold (0 = off)
      taskMatchWeight           0..30   additive lift for same-task candidates (0 = off)
      similarityWeightedScoring bool    semantic score x actual similarity
    MERGES into the stored item - updating one knob never wipes the others."""
    _pc._ensure_table()
    current = _table().get_item(Key={"config_key": CONFIG_KEY}).get("Item") or {}
    item = dict(current)
    item["config_key"] = CONFIG_KEY
    applied = []
    if "minSimilarityPercent" in updates:
        pct = max(0.0, min(100.0, float(updates["minSimilarityPercent"])))
        item["minSimilarityPercent"] = Decimal(str(round(pct, 2)))
        applied.append("minSimilarityPercent")
    if "taskMatchWeight" in updates:
        weight = max(0.0, min(30.0, float(updates["taskMatchWeight"])))
        item["taskMatchWeight"] = Decimal(str(round(weight, 2)))
        applied.append("taskMatchWeight")
    if "scoringMode" in updates:
        _m = str(updates["scoringMode"] or "").strip().lower()
        if _m in ("additive", "evidence"):
            item["scoringMode"] = _m
            applied.append("scoringMode")
    for _k, _lo, _hi in (("evidenceScale", 1.0, 60.0), ("supportScale", 1.0, 200.0)):
        if _k in updates:
            _v = max(_lo, min(_hi, float(updates[_k])))
            item[_k] = Decimal(str(round(_v, 2)))
            applied.append(_k)
    if "distinctiveMatchWeight" in updates:
        weight = max(0.0, min(60.0, float(updates["distinctiveMatchWeight"])))
        item["distinctiveMatchWeight"] = Decimal(str(round(weight, 2)))
        applied.append("distinctiveMatchWeight")
    if "artifactMatchWeight" in updates:
        weight = max(0.0, min(60.0, float(updates["artifactMatchWeight"])))
        item["artifactMatchWeight"] = Decimal(str(round(weight, 2)))
        applied.append("artifactMatchWeight")
    if "minSemanticSimilarity" in updates:
        floor = max(0.0, min(1.0, float(updates["minSemanticSimilarity"])))
        item["minSemanticSimilarity"] = Decimal(str(round(floor, 3)))
        applied.append("minSemanticSimilarity")
    if "downvoteSinkMinVotes" in updates:
        votes = max(1, min(10, int(float(updates["downvoteSinkMinVotes"]))))
        item["downvoteSinkMinVotes"] = Decimal(str(votes))
        applied.append("downvoteSinkMinVotes")
    # Accepted and ignored - see the read path. Not stored, so it cannot switch anything back on.
    if "similarityWeightedScoring" in updates:
        applied.append("similarityWeightedScoring (retired - always on)")
    for _k in ("baseTaskWeight", "baseFileWeight", "baseTokenWeight"):
        if _k in updates:
            _w = max(0.0, min(30.0, float(updates[_k])))
            item[_k] = Decimal(str(round(_w, 2)))
            applied.append(_k)
    for _k, _cap in (("afterPatternWeight", 1.0), ("semanticMatchBase", 30.0),
                     ("exactMatchBase", 30.0), ("evidenceContrastMinSpread", 1.0),
                     ("feedbackSupportWeight", 18.0), ("usageHitsWeight", 1.0),
                     ("shownHistoryWeight", 1.0), ("helperEvidenceRatio", 1.0),
                     ("errorTextArtifactWeight", 1.0), ("ambiguityMargin", 0.5)):
        if _k in updates:
            _v = max(0.0, min(_cap, float(updates[_k])))
            item[_k] = Decimal(str(round(_v, 3)))
            applied.append(_k)
    if "recommendationScope" in updates:
        # An unrecognised value is REJECTED here rather than silently narrowed. Setting "global"
        # used to be accepted and then mapped back to group, so the caller was told it had worked
        # and got something else.
        from src.services.project_groups import VALID_SCOPES, _SCOPE_ALIASES
        _sc = str(updates["recommendationScope"] or "").strip().lower()
        _sc = _SCOPE_ALIASES.get(_sc, _sc)
        if _sc in VALID_SCOPES:
            item["recommendationScope"] = _sc
            applied.append("recommendationScope")
    if "evidenceContrastMode" in updates:
        _cm = str(updates["evidenceContrastMode"] or "").strip().lower()
        if _cm in ("spread", "best"):
            item["evidenceContrastMode"] = _cm
            applied.append("evidenceContrastMode")
    if "historyWeightCeiling" in updates:
        _h = max(0.0, min(30.0, float(updates["historyWeightCeiling"])))
        item["historyWeightCeiling"] = Decimal(str(round(_h, 2)))
        applied.append("historyWeightCeiling")
    if "evidenceSimilarityWeight" in updates:
        _w = max(0.0, min(1.0, float(updates["evidenceSimilarityWeight"])))
        item["evidenceSimilarityWeight"] = Decimal(str(round(_w, 3)))
        applied.append("evidenceSimilarityWeight")
    if "llmPromoteEnabled" in updates:
        item["llmPromoteEnabled"] = bool(updates["llmPromoteEnabled"])
        applied.append("llmPromoteEnabled")

    # Extra points when the fix's own changed line is found in the file the developer has open.
    # Same 0-30 range as the identity weights it sits beside.
    if "fileContentMatchWeight" in updates:
        _fc = max(0.0, min(30.0, float(updates["fileContentMatchWeight"])))
        item["fileContentMatchWeight"] = Decimal(str(round(_fc, 2)))
        applied.append("fileContentMatchWeight")

    if not applied:
        raise ValueError("no supported config key in update")
    # A key that arrives here and is not applied has been accepted by the route and then
    # dropped in silence - a 200 for a change that never happened. Fail, and name it.
    _ignored = [k for k in updates if k not in applied]
    if _ignored:
        raise ValueError("config key(s) accepted but not written: " + ", ".join(sorted(_ignored)))
    item["updated_by"] = str(updated_by or "")
    item["updated_at"] = int(time.time())
    _table().put_item(Item=item)
    _cache["data"] = None
    logger.info("recommendation config updated | keys=%s | by=%s", applied, updated_by)
    return get_config(force=True)


def set_min_similarity_percent(value, updated_by: str = "") -> dict:
    return set_values({"minSimilarityPercent": value}, updated_by=updated_by)
