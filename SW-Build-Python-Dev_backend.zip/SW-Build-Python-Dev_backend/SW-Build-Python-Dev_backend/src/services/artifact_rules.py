"""
src/services/artifact_rules.py — Artifact collection RULES (updated UI contract).

The dashboard's Artifact Configuration screen was redesigned from the folder+patterns model to a
FLAT RULE LIST. One record in a dedicated table (`artifact_rules{sfx}`) holds:

    rules: [ { id, ruleType INCLUDE|EXCLUDE, resourceType FOLDER|FOLDER_RECURSIVE|FILE,
               globPattern, description, enabled,
               createdAt, updatedAt, createdBy, updatedBy } ]

Contract points implemented here (UI contract):
  - every mutation returns the FULL payload (rules + summary) — no follow-up GET needed
  - backend-generated string ids ("rule_XXXXXXXXXX") are the only handles
  - duplicate = ruleType + resourceType + NORMALIZED globPattern (trimmed, '\\'->'/', lowercased)
  - update with no editable change is rejected ("No changes were detected.")
  - summary recalculated on every write; timestamps UTC ISO-8601; audit createdBy/updatedBy
  - glob engine (documented): Python fnmatch translated to regex — '*' any chars, '?' one char,
    '[...]' classes; path separators normalized to '/' before matching. Exclude beats include at
    match time. Disabled rules never participate.

Errors raise ArtifactRuleError carrying {code, http_status, message, fieldErrors} which the route
maps onto the contract's standard error response.

NOTE: the legacy folder-based /api/artifact-configurations GET remains alive — the shipped
extension reads it for collection. This module is the new source of truth for the DASHBOARD only;
the extension migrates to rules with its next release.

Same storage pattern as prediction_config.py / artifact_config.py: schemaless single record,
30s read cache, full-record writes.
"""
import re
import time
import uuid
import logging
from datetime import datetime, timezone
from fnmatch import translate as _fnmatch_translate

from src.databases.database import get_dynamodb
from src.configurations import config

logger = logging.getLogger(__name__)

RULES_TABLE = f"artifact_rules{config.DYNAMODB_TABLE_SUFFIX}"
CONFIG_KEY = "artifact_rules"        # single global record
_CACHE_TTL = 30

RULE_TYPES = {"INCLUDE", "EXCLUDE"}
RESOURCE_TYPES = {"FOLDER", "FOLDER_RECURSIVE", "FILE"}
_MAX_GLOB = 500
_MAX_DESCRIPTION = 500

# Defaults = the extension's CURRENT stock collection behavior translated to rules, so a fresh
# environment matches today's package until an admin edits the screen: collect everything under
# the task build dir's out/log/wrk (+ TD5 proc), minus the known noise files.
DEFAULT_RULES = [
    {"ruleType": "INCLUDE", "resourceType": "FOLDER_RECURSIVE", "globPattern": "out/**",
     "description": "Runtime output", "enabled": True},
    {"ruleType": "INCLUDE", "resourceType": "FOLDER_RECURSIVE", "globPattern": "log/**",
     "description": "Build logs", "enabled": True},
    {"ruleType": "INCLUDE", "resourceType": "FOLDER_RECURSIVE", "globPattern": "wrk/**",
     "description": "Task work files", "enabled": True},
    {"ruleType": "INCLUDE", "resourceType": "FOLDER_RECURSIVE", "globPattern": "proc/**",
     "description": "TD5 process outputs", "enabled": True},
    {"ruleType": "EXCLUDE", "resourceType": "FILE", "globPattern": "**/*lock*",
     "description": "Lock files (no failure signal)", "enabled": True},
    {"ruleType": "EXCLUDE", "resourceType": "FILE", "globPattern": "**/process-id.txt",
     "description": "Process metadata (no failure signal)", "enabled": True},
    {"ruleType": "EXCLUDE", "resourceType": "FILE", "globPattern": "**/*.gbe",
     "description": "GBE tooling files", "enabled": True},
]

_cache = {"data": None, "ts": 0.0}
_table_ready = False


class ArtifactRuleError(Exception):
    """Contract error: the route serializes code/message/fieldErrors at http_status."""

    def __init__(self, message: str, code: str = "ARTIFACT_RULE_VALIDATION_ERROR",
                 http_status: int = 400, field_errors: dict | None = None):
        super().__init__(message)
        self.message = message
        self.code = code
        self.http_status = http_status
        self.field_errors = field_errors or {}


def _table():
    return get_dynamodb().Table(RULES_TABLE)


def _ensure_table():
    global _table_ready
    if _table_ready:
        return
    try:
        ddb = get_dynamodb()
        if RULES_TABLE not in [t.name for t in ddb.tables.all()]:
            logger.info("creating artifact rules table %s", RULES_TABLE)
            ddb.create_table(
                TableName=RULES_TABLE,
                KeySchema=[{"AttributeName": "config_key", "KeyType": "HASH"}],
                AttributeDefinitions=[{"AttributeName": "config_key", "AttributeType": "S"}],
                BillingMode="PAY_PER_REQUEST",
            ).wait_until_exists()
        _table_ready = True
    except Exception:
        logger.exception("ensure artifact rules table failed")


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _new_rule_id() -> str:
    return f"rule_{uuid.uuid4().hex[:10].upper()}"


def _norm_glob(pattern: str) -> str:
    """Comparison form for duplicate detection: trimmed, separators unified, case-insensitive."""
    return str(pattern or "").strip().replace("\\", "/").lower()


def _default_record(by: str = "system") -> dict:
    now = _now_iso()
    return {
        "rules": [
            {
                "id": _new_rule_id(),
                "ruleType": r["ruleType"],
                "resourceType": r["resourceType"],
                "globPattern": r["globPattern"],
                "description": r["description"],
                "enabled": bool(r["enabled"]),
                "createdAt": now, "updatedAt": now,
                "createdBy": by, "updatedBy": by,
            }
            for r in DEFAULT_RULES
        ],
        "lastUpdatedAt": now,
        "lastUpdatedBy": by,
    }


def _read_raw() -> dict:
    try:
        _ensure_table()
        item = _table().get_item(Key={"config_key": CONFIG_KEY}).get("Item")
    except Exception:
        logger.exception("read artifact rules failed - serving defaults")
        item = None
    if not item or not isinstance(item.get("rules"), list):
        return _default_record()
    return {
        "rules": [r for r in item["rules"] if isinstance(r, dict)],
        "lastUpdatedAt": str(item.get("lastUpdatedAt") or ""),
        "lastUpdatedBy": str(item.get("lastUpdatedBy") or ""),
    }


def get_config(force: bool = False) -> dict:
    now = time.time()
    if not force and _cache["data"] is not None and (now - _cache["ts"]) < _CACHE_TTL:
        return _cache["data"]
    data = _read_raw()
    _cache["data"], _cache["ts"] = data, now
    return data


def _write(record: dict, by: str) -> dict:
    _ensure_table()
    record["lastUpdatedAt"] = _now_iso()
    record["lastUpdatedBy"] = by
    item = {"config_key": CONFIG_KEY, **record}
    _table().put_item(Item=item)
    _cache["data"], _cache["ts"] = record, time.time()
    return record


def _summary(record: dict) -> dict:
    rules = record.get("rules", [])
    include = sum(1 for r in rules if r.get("ruleType") == "INCLUDE")
    enabled = sum(1 for r in rules if bool(r.get("enabled")))
    return {
        "totalRules": len(rules),
        "includeRules": include,
        "excludeRules": len(rules) - include,
        "enabledRules": enabled,
        "disabledRules": len(rules) - enabled,
        "lastUpdatedAt": record.get("lastUpdatedAt") or "",
        "lastUpdatedBy": record.get("lastUpdatedBy") or "",
    }


def full_view(record: dict | None = None) -> dict:
    """The common success payload: complete rule collection + recalculated summary."""
    record = record or get_config()
    return {"rules": [dict(r) for r in record.get("rules", [])], "summary": _summary(record)}


# ---------------------------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------------------------
def _validate_body(body: dict) -> dict:
    """Normalize + validate one rule payload. Raises ArtifactRuleError with fieldErrors."""
    body = body if isinstance(body, dict) else {}
    field_errors: dict = {}

    rule_type = str(body.get("ruleType") or "").strip().upper()
    if rule_type not in RULE_TYPES:
        field_errors["ruleType"] = "Invalid rule type."

    resource_type = str(body.get("resourceType") or "").strip().upper()
    if resource_type not in RESOURCE_TYPES:
        field_errors["resourceType"] = "Invalid resource type."

    glob_pattern = str(body.get("globPattern") or "").strip().replace("\\", "/")
    if not glob_pattern:
        field_errors["globPattern"] = "Glob pattern is required."
    elif len(glob_pattern) > _MAX_GLOB:
        field_errors["globPattern"] = f"Glob pattern must not exceed {_MAX_GLOB} characters."

    description = body.get("description")
    if description is not None:
        description = str(description).strip()
        if len(description) > _MAX_DESCRIPTION:
            field_errors["description"] = f"Description must not exceed {_MAX_DESCRIPTION} characters."
        if description == "":
            description = None

    enabled = body.get("enabled")
    if not isinstance(enabled, bool):
        field_errors["enabled"] = "Enabled must be true or false."

    if field_errors:
        raise ArtifactRuleError("Validation failed.", field_errors=field_errors)

    # Glob semantics (422 per contract): compile through the documented engine.
    try:
        re.compile(_fnmatch_translate(glob_pattern))
    except re.error:
        raise ArtifactRuleError(
            "Validation failed.", code="ARTIFACT_RULE_INVALID_GLOB", http_status=422,
            field_errors={"globPattern": "Invalid glob pattern."})

    return {
        "ruleType": rule_type,
        "resourceType": resource_type,
        "globPattern": glob_pattern,
        "description": description,
        "enabled": enabled,
    }


def _assert_not_duplicate(record: dict, fields: dict, ignore_rule_id: str | None = None) -> None:
    key = (fields["ruleType"], fields["resourceType"], _norm_glob(fields["globPattern"]))
    for r in record.get("rules", []):
        if ignore_rule_id and r.get("id") == ignore_rule_id:
            continue
        if (r.get("ruleType"), r.get("resourceType"), _norm_glob(r.get("globPattern"))) == key:
            raise ArtifactRuleError(
                "An identical artifact rule already exists.",
                code="ARTIFACT_RULE_DUPLICATE", http_status=409)


def _find_rule(record: dict, rule_id: str) -> dict:
    for r in record.get("rules", []):
        if r.get("id") == str(rule_id or "").strip():
            return r
    raise ArtifactRuleError("Artifact rule not found.",
                            code="ARTIFACT_RULE_NOT_FOUND", http_status=404)


# ---------------------------------------------------------------------------------------------
# Mutations — each persists, then returns the fresh record for full_view()
# ---------------------------------------------------------------------------------------------
def create_rule(body: dict, by: str = "dashboard") -> dict:
    fields = _validate_body(body)
    record = dict(get_config(force=True))
    _assert_not_duplicate(record, fields)
    now = _now_iso()
    record["rules"] = list(record.get("rules", [])) + [{
        "id": _new_rule_id(), **fields,
        "createdAt": now, "updatedAt": now, "createdBy": by, "updatedBy": by,
    }]
    return _write(record, by)


def update_rule(rule_id: str, body: dict, by: str = "dashboard") -> dict:
    fields = _validate_body(body)
    record = dict(get_config(force=True))
    rule = _find_rule(record, rule_id)
    unchanged = all(rule.get(k) == v for k, v in fields.items())
    if unchanged:
        raise ArtifactRuleError("No changes were detected.",
                                code="ARTIFACT_RULE_NO_CHANGES", http_status=409)
    _assert_not_duplicate(record, fields, ignore_rule_id=rule.get("id"))
    rule.update(fields)
    rule["updatedAt"] = _now_iso()
    rule["updatedBy"] = by
    return _write(record, by)


def set_rule_status(rule_id: str, enabled, by: str = "dashboard") -> dict:
    if not isinstance(enabled, bool):
        raise ArtifactRuleError("Validation failed.",
                                field_errors={"enabled": "Enabled must be true or false."})
    record = dict(get_config(force=True))
    rule = _find_rule(record, rule_id)
    if bool(rule.get("enabled")) == enabled:
        raise ArtifactRuleError("No changes were detected.",
                                code="ARTIFACT_RULE_NO_CHANGES", http_status=409)
    rule["enabled"] = enabled
    rule["updatedAt"] = _now_iso()
    rule["updatedBy"] = by
    return _write(record, by)


def delete_rule(rule_id: str, by: str = "dashboard") -> dict:
    record = dict(get_config(force=True))
    rule = _find_rule(record, rule_id)   # 404 if unknown
    record["rules"] = [r for r in record.get("rules", []) if r.get("id") != rule.get("id")]
    return _write(record, by)


def reset_defaults(by: str = "dashboard") -> dict:
    record = _default_record(by)
    return _write(record, by)
