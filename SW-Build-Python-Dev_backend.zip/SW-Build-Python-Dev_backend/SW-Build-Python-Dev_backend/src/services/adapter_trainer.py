"""
src/services/adapter_trainer.py — SELF-RUNNING W training (no manual scripts).

W retrains itself in the backend as feedback accumulates: a background daemon checks periodically,
and when enough newly-resolved errors exist since the last train (and a minimum interval has passed)
it runs the SAME pipeline as train_feedback_adapter.py + build_learned_space.py IN-PROCESS, reusing
the backend's single Chroma client (one client => serialized => no concurrent-client corruption).
W is promoted only if held-out top-1 improves; the adapter auto-reloads (mtime). The learned-space
collection is rebuilt so the ON switch immediately uses the fresh W.

OFF by default (AUTO_TRAIN_ENABLED) so it cannot run until validated on dev. An owner can also
trigger a one-off train from the dashboard (admin_route: /admin/adapter-train) — a button, not a script.

Each cycle trains TWO domain adapters with the same pipeline and promotion gate (prediction-
feedback enhancement: one adapter per embedding domain): the original error W, then W_artifact
from ARTIFACT vectors (labels = the resolved fix of the artifact's request). Each promotes
independently; an artifact-side failure never affects the error adapter.
"""
import os
import time
import threading
import logging

import numpy as np

from src.configurations import config
from src.utils import feedback_adapter as fa
from src.utils import recommended

logger = logging.getLogger(__name__)

AUTO_TRAIN_ENABLED = os.getenv("AUTO_TRAIN_ENABLED", "0").strip().lower() in ("1", "true", "yes", "on")
CHECK_INTERVAL = int(os.getenv("AUTO_TRAIN_CHECK_SECONDS", "1800"))          # check every 30 min
MIN_INTERVAL = int(os.getenv("AUTO_TRAIN_MIN_INTERVAL_SECONDS", "3600"))     # at most once per hour
MIN_NEW_ERRORS = int(os.getenv("AUTO_TRAIN_MIN_NEW_ERRORS", "15"))           # need >= this many new
TRAIN_DIM = config.FEEDBACK_ADAPTER_DIM or 512                               # 512 = quick; 0 -> full 3072

_state = {"last_train": 0.0, "last_count": 0, "running": False, "last_result": None}
_lock = threading.Lock()


def _rebuild_learned_space(W) -> int:
    """Transform the base vectors with W and (re)write the learned-space collection. Works on BOTH
    backends: Chroma (uses the stored vectors via the backend's single client) and Azure (re-embeds
    the stored error text, then writes a learned Azure index sized to W's output dim)."""
    base = recommended.collection
    data = base.get(include=["embeddings", "documents", "metadatas"])
    ids = data.get("ids") or []
    embs = data.get("embeddings")
    embs = [] if embs is None else embs
    docs = data.get("documents") or []
    metas = data.get("metadatas") or []
    if not ids:
        return 0
    # Azure: vectors are not retrievable -> re-embed the stored error text (same as build_dataset).
    if len(embs) == 0 or embs[0] is None or len(embs[0]) == 0:
        if not docs:
            return 0
        from src.utils.embedding_cache import embed_documents
        embs = embed_documents(docs, label="error corpus (learned-space rebuild)")
    X = np.asarray(embs, dtype=np.float64)
    if X.size == 0 or X.shape[1] != W.shape[0]:
        logger.warning("[auto-train] learned-space dim mismatch base=%s W=%s", getattr(X, "shape", None), W.shape)
        return 0
    Z = fa.l2norm(X @ W).astype(np.float32)
    name = config.FEEDBACK_ADAPTER_LEARNED_COLLECTION
    client = recommended.client
    if client is not None:
        # Chroma path (single client => serialized => safe in-process).
        try:
            client.delete_collection(name)
        except Exception:
            pass
        learned = client.get_or_create_collection(name=name)
        B = 1000
        for i in range(0, len(ids), B):
            learned.add(ids=ids[i:i + B], embeddings=[z.tolist() for z in Z[i:i + B]],
                        metadatas=[{k: v for k, v in (m or {}).items() if v is not None} for m in metas[i:i + B]])
    else:
        # Azure path (AZURE_ONLY): recreate a learned index sized to the adapter output dim, then upload.
        from src.azure_search.azure_collection import AzureCollection, ensure_azure_index
        ensure_azure_index(name, int(Z.shape[1]), recreate=True)
        learned = AzureCollection(name)
        B = 500
        for i in range(0, len(ids), B):
            learned.upsert(ids=ids[i:i + B], embeddings=[z.tolist() for z in Z[i:i + B]],
                           metadatas=[{k: v for k, v in (m or {}).items() if v is not None} for m in metas[i:i + B]])
        logger.info("[auto-train] learned-space -> Azure index for '%s' (%d vectors, dim=%d)",
                    name, len(ids), int(Z.shape[1]))
    recommended._learned_collection_cache = None   # force re-open of the fresh collection
    return len(ids)


def build_artifact_dataset(col=None):
    """(artifact vector -> proven-fix label) pairs for W_artifact. The label is the resolved
    solution signature of the artifact's request — the artifacts collected for a failure share
    the fix that resolved it, the same label source the error adapter uses. The distinct-unit
    signature for cluster filtering is the artifact CONTENT hash, so a fix must be supported by
    >= MIN_CLUSTER different artifact contents to become a training signal."""
    from collections import defaultdict
    from src.utils.project_details import get_final_build_payload
    from train_feedback_adapter import _solution_signature

    if col is None:
        from src.services import handlers
        col = handlers.get_artifact_chroma_collection()
    data = col.get(include=["embeddings", "documents", "metadatas"])
    embs = data.get("embeddings")
    embs = [] if embs is None else embs
    docs = data.get("documents") or []
    metas = data.get("metadatas") or []
    # Azure: vectors are not retrievable -> re-embed the stored chunk text (same model, same space).
    if docs and (len(embs) == 0 or embs[0] is None or len(embs[0]) == 0):
        from src.utils.embedding_cache import embed_documents
        embs = embed_documents(docs, label="artifact corpus")

    payload_cache = {}
    vecs, labels, sigs = [], [], []
    skip = defaultdict(int)
    for i, m in enumerate(metas):
        m = m or {}
        emb = embs[i] if i < len(embs) else None
        if emb is None or len(emb) == 0:
            skip["no_embedding"] += 1
            continue
        req = str(m.get("request_id") or "").strip()
        if not req:
            skip["no_request_id"] += 1
            continue
        if req not in payload_cache:
            try:
                payload_cache[req] = get_final_build_payload(req) or {}
            except Exception:
                payload_cache[req] = {}
        sig = _solution_signature(payload_cache[req])
        if not sig:
            skip["no_solution"] += 1
            continue
        vecs.append(np.asarray(emb, dtype=np.float32))
        labels.append(sig)
        sigs.append(str(m.get("content_sha256") or m.get("content_sha12") or m.get("s3_key") or ""))
    X = np.vstack(vecs) if vecs else np.empty((0, 0))
    return X, labels, sigs, dict(skip)


def _rebuild_artifact_learned_space(W) -> int:
    """W_artifact counterpart of _rebuild_learned_space: transform the base ARTIFACT vectors and
    (re)write the artifact learned-space collection on either backend."""
    from src.services import handlers

    base = handlers.get_artifact_chroma_collection()
    data = base.get(include=["embeddings", "documents", "metadatas"])
    ids = data.get("ids") or []
    embs = data.get("embeddings")
    embs = [] if embs is None else embs
    docs = data.get("documents") or []
    metas = data.get("metadatas") or []
    if not ids:
        return 0
    if len(embs) == 0 or embs[0] is None or len(embs[0]) == 0:
        if not docs:
            return 0
        from src.utils.embedding_cache import embed_documents
        embs = embed_documents(docs, label="artifact corpus (learned-space rebuild)")
    X = np.asarray(embs, dtype=np.float64)
    if X.size == 0 or X.shape[1] != W.shape[0]:
        logger.warning("[auto-train] artifact learned-space dim mismatch base=%s W=%s", getattr(X, "shape", None), W.shape)
        return 0
    Z = fa.l2norm(X @ W).astype(np.float32)
    name = config.FEEDBACK_ADAPTER_ARTIFACT_LEARNED_COLLECTION
    client = recommended.client   # same Chroma store path as the artifact collections
    if client is not None:
        try:
            client.delete_collection(name)
        except Exception:
            pass
        learned = client.get_or_create_collection(name=name)
        B = 1000
        for i in range(0, len(ids), B):
            learned.add(ids=ids[i:i + B], embeddings=[z.tolist() for z in Z[i:i + B]],
                        metadatas=[{k: v for k, v in (m or {}).items() if v is not None} for m in metas[i:i + B]])
    else:
        from src.azure_search.azure_collection import AzureCollection, ensure_azure_index
        ensure_azure_index(name, int(Z.shape[1]), recreate=True)
        learned = AzureCollection(name)
        B = 500
        for i in range(0, len(ids), B):
            learned.upsert(ids=ids[i:i + B], embeddings=[z.tolist() for z in Z[i:i + B]],
                           metadatas=[{k: v for k, v in (m or {}).items() if v is not None} for m in metas[i:i + B]])
        logger.info("[auto-train] artifact learned-space -> Azure index '%s' (%d vectors, dim=%d)",
                    name, len(ids), int(Z.shape[1]))
    handlers._artifact_learned_collection_cache = None   # force re-open of the fresh collection
    return len(ids)


def _train_error_cycle(force: bool = False) -> dict:
    """Train/gate/promote the ERROR adapter (the original W). Unchanged behaviour."""
    try:
        from train_feedback_adapter import build_dataset, filter_clusters
        X, labels, sigs, skip = build_dataset(col=recommended.collection)
        if len(labels) < 20:
            return {"ok": False, "reason": f"too few (error, fix) pairs: {len(labels)}", "skip": skip}
        Xc, yc, _sizes = filter_clusters(X, labels, sigs, config.FEEDBACK_ADAPTER_MIN_CLUSTER)
        if len(yc) < 20:
            return {"ok": False, "reason": f"too few after cluster filter: {len(yc)}"}
        res, W = fa.evaluate_and_train(Xc, yc, dim_out=(TRAIN_DIM or None), verbose=False)
        if not res.get("ok"):
            return {"ok": False, "reason": res.get("reason")}
        b, l = res["baseline"], res["learned"]
        gate = config.FEEDBACK_ADAPTER_MIN_GAIN_PP
        passes = (l[1] > b[1]) and (res["gain_top1_pp"] >= gate)
        summary = {"top1_before": round(b[1] * 100, 1), "top1_after": round(l[1] * 100, 1),
                   "gain_pp": round(res["gain_top1_pp"], 1), "gate_pp": gate,
                   "fixes": res["n_fixes"], "trained_on": res["n_train"], "held_out": res["n_heldout"]}
        if not passes and not force:
            logger.info("[auto-train] not promoted | %s", summary)
            return {"ok": True, "promoted": False, "summary": summary}
        path = fa.save_adapter(W, {"metrics": res, "trained_at": time.strftime("%Y-%m-%dT%H:%M:%S"), "auto": True})
        n = _rebuild_learned_space(W)
        logger.info("[auto-train] PROMOTED W -> %s | learned-space rebuilt (%d) | %s", path, n, summary)
        return {"ok": True, "promoted": True, "learned_count": n, "summary": summary}
    except Exception as e:
        logger.exception("[auto-train] error-adapter cycle failed")
        return {"ok": False, "reason": str(e)}


def _train_artifact_cycle(force: bool = False) -> dict:
    """Train/gate/promote W_artifact from ARTIFACT vectors. Same pipeline and promotion gate as
    the error adapter; failures here never affect the error-adapter result."""
    try:
        from train_feedback_adapter import filter_clusters
        X, labels, sigs, skip = build_artifact_dataset()
        if len(labels) < 20:
            return {"ok": False, "reason": f"too few (artifact, fix) pairs: {len(labels)}", "skip": skip}
        Xc, yc, _sizes = filter_clusters(X, labels, sigs, config.FEEDBACK_ADAPTER_MIN_CLUSTER)
        if len(yc) < 20:
            return {"ok": False, "reason": f"too few after cluster filter: {len(yc)}"}
        res, W = fa.evaluate_and_train(Xc, yc, dim_out=(TRAIN_DIM or None), verbose=False)
        if not res.get("ok"):
            return {"ok": False, "reason": res.get("reason")}
        b, l = res["baseline"], res["learned"]
        gate = config.FEEDBACK_ADAPTER_MIN_GAIN_PP
        passes = (l[1] > b[1]) and (res["gain_top1_pp"] >= gate)
        summary = {"top1_before": round(b[1] * 100, 1), "top1_after": round(l[1] * 100, 1),
                   "gain_pp": round(res["gain_top1_pp"], 1), "gate_pp": gate,
                   "fixes": res["n_fixes"], "trained_on": res["n_train"], "held_out": res["n_heldout"]}
        if not passes and not force:
            logger.info("[auto-train] artifact W not promoted | %s", summary)
            return {"ok": True, "promoted": False, "summary": summary}
        path = fa.save_adapter(
            W,
            {"metrics": res, "trained_at": time.strftime("%Y-%m-%dT%H:%M:%S"), "auto": True, "domain": "artifact"},
            path=config.FEEDBACK_ADAPTER_ARTIFACT_PATH,
        )
        n = _rebuild_artifact_learned_space(W)
        logger.info("[auto-train] PROMOTED W_artifact -> %s | learned-space rebuilt (%d) | %s", path, n, summary)
        return {"ok": True, "promoted": True, "learned_count": n, "summary": summary}
    except Exception as e:
        logger.exception("[auto-train] artifact-adapter cycle failed")
        return {"ok": False, "reason": str(e)}


def run_training_cycle(force: bool = False) -> dict:
    """One in-process training pass: trains the ERROR adapter, then W_artifact (prediction-feedback
    enhancement: one adapter per domain, same trainer). Returns the error-adapter result dict with
    the artifact result attached under 'artifact'; sets _state['last_result']."""
    with _lock:
        if _state["running"]:
            return {"ok": False, "reason": "a training cycle is already running"}
        _state["running"] = True
    try:
        result = _train_error_cycle(force=force)
        result["artifact"] = _train_artifact_cycle(force=force)
        return result
    finally:
        with _lock:
            _state["running"] = False
            _state["last_train"] = time.time()


def trigger_async(force: bool = False) -> bool:
    """Kick a training cycle on a background thread (for the admin 'Train now' button). Returns
    False if one is already running."""
    if _state["running"]:
        return False

    def _run():
        _state["last_result"] = run_training_cycle(force=force)
    threading.Thread(target=_run, name="adapter-train-now", daemon=True).start()
    return True


def status() -> dict:
    return {"auto_train_enabled": AUTO_TRAIN_ENABLED, "running": _state["running"],
            "last_train": int(_state["last_train"]), "last_result": _state["last_result"],
            "min_new_errors": MIN_NEW_ERRORS, "check_interval_s": CHECK_INTERVAL, "train_dim": TRAIN_DIM}


def _resolved_count() -> int:
    try:
        return recommended.collection.count()
    except Exception:
        return 0


def _maybe_train():
    now = time.time()
    if now - _state["last_train"] < MIN_INTERVAL:
        return
    count = _resolved_count()
    if _state["last_count"] and (count - _state["last_count"]) < MIN_NEW_ERRORS:
        return
    logger.info("[auto-train] trigger | total_errors=%d (>= %d new since last)", count, MIN_NEW_ERRORS)
    _state["last_result"] = run_training_cycle()
    _state["last_count"] = count


def _loop():
    _state["last_count"] = _resolved_count()
    logger.info("[auto-train] started | check=%ss min_interval=%ss min_new=%s dim=%s",
                CHECK_INTERVAL, MIN_INTERVAL, MIN_NEW_ERRORS, TRAIN_DIM)
    while True:
        try:
            _maybe_train()
        except Exception:
            logger.exception("[auto-train] loop error")
        time.sleep(CHECK_INTERVAL)


def start_auto_trainer():
    if not AUTO_TRAIN_ENABLED:
        logger.info("[auto-train] disabled (set AUTO_TRAIN_ENABLED=1 to enable self-running W training)")
        return
    threading.Thread(target=_loop, name="adapter-auto-trainer", daemon=True).start()
