"""
src/services/shadow_judge.py — judging for shadow-mode prediction (roadmap step B).

Shadow capture (step A) stores a silent prediction report at build-FAILURE time, with the
failure cycle context (requested/failing tasks, error signature, capture time). This module
closes the loop: when the SAME task's fix is uploaded (the task went green — the 2.1.9 rule),
every still-unjudged shadow report of that task is compared against the fix's actual changed
lines, per the client-approved rules from the Prediction Feedback Enhancement document:

    - the fix touched a warned file+line          -> HIT        (the warning was right)
    - the fix touched the warned file, other line -> NEAR HIT   (right file, imprecise line)
    - the fix never touched the warned file       -> FALSE ALARM
    - fix files that carried no warning at all    -> MISS       (report-level metric)
    - the task never goes green                   -> never judged; reports older than the
      judging window simply stay unjudged (an abandoned task is NOT a false alarm)

Judging is cheap (no LLM, no embeddings — pure line/path comparison) and runs on a background
thread after the fix upload, so the upload path is never slowed or failed by it. Verdicts are
stored ON the shadow report rows (additive attributes), and per-pattern totals are aggregated
on demand — the seed data for the reliability scorecards (roadmap step C).
"""
import logging
import os
import re
from datetime import datetime, timezone

from src.utils.project_details import (
    list_prediction_history_reports_with_report,
    attach_shadow_judgement,
)

logger = logging.getLogger(__name__)

JUDGE_WINDOW_DAYS = max(1, int(os.getenv("SHADOW_JUDGE_WINDOW_DAYS", "7")))
LINE_TOLERANCE = max(0, int(os.getenv("SHADOW_JUDGE_LINE_TOLERANCE", "3")))


def _now():
    return datetime.now(timezone.utc)


def _parse_iso(value) -> datetime | None:
    s = str(value or "").strip()
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _norm_task(value) -> str:
    return str(value or "").strip().lstrip(":").lower()


def _norm_path(value) -> str:
    return str(value or "").strip().replace("\\", "/").lower().strip("/")


def _same_file(a: str, b: str) -> bool:
    """Boundary-safe suffix match (same rule as prediction path matching): paths refer to the
    same file when equal, or when one ends with '/'+the other and the shorter side keeps at
    least two segments (never bare-basename matching)."""
    a, b = _norm_path(a), _norm_path(b)
    if not a or not b:
        return False
    if a == b:
        return True
    longer, shorter = (a, b) if len(a) >= len(b) else (b, a)
    if shorter.count("/") < 1:
        return False
    return longer.endswith("/" + shorter)


def _task_matches(shadow_context: dict, task_name: str) -> bool:
    """The SAME-task rule: a shadow report is judged only by its own task's fix. failing_tasks
    is the per-task identity and takes precedence — a launch command (requested_tasks) can cover
    several failing tasks, and one task's fix must never judge a sibling task's warnings."""
    wanted = _norm_task(task_name)
    if not wanted:
        return False
    ctx = shadow_context or {}
    failing = ctx.get("failing_tasks")
    if isinstance(failing, list) and any(str(f or "").strip() for f in failing):
        return any(_norm_task(f) == wanted for f in failing if f)
    return _norm_task(ctx.get("requested_tasks")) == wanted


_LINE_MARK = re.compile(r"^\[\[(\d+)\]\]")


def _fix_change_map(solution) -> dict:
    """{normalized file path: {"raw": original path, "lines": set of FAILURE-side line numbers}}
    from the uploaded solution. Fix-side ('after') change objects are excluded — warnings point
    at the broken state, so they are judged against the broken state's line numbers."""
    out: dict = {}
    for item in solution or []:
        if not isinstance(item, dict):
            continue
        raw_path = str(item.get("filePath") or item.get("fileName") or "").strip()
        if not raw_path:
            continue
        key = _norm_path(raw_path)
        entry = out.setdefault(key, {"raw": raw_path, "lines": set()})
        for change in item.get("changeObjects") or []:
            if not isinstance(change, dict):
                continue
            if str(change.get("riskSide") or "").strip().lower() == "after":
                continue
            line = change.get("line")
            try:
                line_no = int(line)
            except (TypeError, ValueError):
                m = _LINE_MARK.match(str(change.get("change") or change.get("patch") or ""))
                line_no = int(m.group(1)) if m else 0
            if line_no > 0:
                entry["lines"].add(line_no)
    return out


def _judge_issues(issues, fix_map: dict, fix_request_id: str) -> dict:
    verdicts = []
    hits = near_hits = false_alarms = 0
    warned_files: set = set()
    for issue in issues or []:
        if not isinstance(issue, dict):
            continue
        file_path = str(issue.get("file_path") or issue.get("file_name") or "").strip()
        line_found = 0
        try:
            line_found = int(issue.get("line_found") or 0)
        except (TypeError, ValueError):
            pass
        matched = next((e for k, e in fix_map.items() if _same_file(k, file_path)), None)
        if matched is None:
            verdict = "false_alarm"
            false_alarms += 1
        else:
            warned_files.add(_norm_path(matched["raw"]))
            lines = matched["lines"]
            if line_found and lines and any(abs(line_found - ln) <= LINE_TOLERANCE for ln in lines):
                verdict = "hit"
                hits += 1
            elif not lines:
                # The fix touched the file but carried no failure-side line info — the file-level
                # signal was right; count it as a near hit rather than guessing the line.
                verdict = "near_hit"
                near_hits += 1
            else:
                verdict = "near_hit"
                near_hits += 1
        verdicts.append({
            "file_path": file_path,
            "line_found": line_found,
            "pattern": str(issue.get("historical_pattern") or "").strip()[:300],
            "verdict": verdict,
        })

    missed_fix_files = [
        e["raw"] for k, e in fix_map.items()
        if k not in warned_files and not any(_same_file(k, w) for w in warned_files)
    ]
    return {
        "judged_at": _now().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "fix_request_id": str(fix_request_id or ""),
        "warnings": len(verdicts),
        "hits": hits,
        "near_hits": near_hits,
        "false_alarms": false_alarms,
        "missed_fix_files": missed_fix_files[:20],
        "issues": verdicts[:100],
    }


def judge_for_upload(project_name: str, task_name: str, solution, request_id: str) -> dict:
    """Judge every still-unjudged shadow report of THIS task against THIS fix. Returns a small
    summary dict (also logged). Safe to call repeatedly — judged reports are skipped."""
    project = str(project_name or "").strip().lower()
    if not project or not str(task_name or "").strip():
        return {"judged": 0, "reason": "missing project/task"}

    fix_map = _fix_change_map(solution)
    if not fix_map or not any(e["lines"] for e in fix_map.values()):
        # Without failure-side line information the comparison would be guesswork - leave the
        # reports unjudged rather than mint unreliable verdicts.
        return {"judged": 0, "reason": "no failure-side changes in the fix payload"}

    rows = list_prediction_history_reports_with_report(project, limit=200, kind="shadow")
    now = _now()
    judged = 0
    for row in rows:
        if row.get("judgement") or row.get("judged_at"):
            continue
        rep = row.get("report") or {}
        if rep.get("judgement"):
            continue
        ctx = rep.get("shadow_context") or {}
        if not _task_matches(ctx, task_name):
            continue
        captured = _parse_iso(ctx.get("captured_at")) or _parse_iso(row.get("created_date"))
        if not captured or captured > now:
            continue
        if (now - captured).days > JUDGE_WINDOW_DAYS:
            continue  # abandoned cycle: expires UNJUDGED, never a false alarm
        judgement = _judge_issues(rep.get("issues") or [], fix_map, request_id)
        try:
            attach_shadow_judgement(
                project_name=project,
                prediction_report_id=str(row.get("prediction_report_id") or ""),
                created_date=str(row.get("created_date") or ""),
                judgement=judgement,
            )
            judged += 1
            logger.info(
                "shadow judged | project=%s | report=%s | warnings=%d hits=%d near=%d false=%d missed_files=%d",
                project, row.get("prediction_report_id"), judgement["warnings"], judgement["hits"],
                judgement["near_hits"], judgement["false_alarms"], len(judgement["missed_fix_files"]),
            )
        except Exception:
            logger.exception("failed to persist shadow judgement | report=%s", row.get("prediction_report_id"))
    return {"judged": judged}


def shadow_metrics(project_name: str, limit: int = 200) -> dict:
    """On-demand aggregation of judged shadow reports: per-project totals + per-pattern
    right/wrong counts — the raw material for the reliability scorecards (step C)."""
    project = str(project_name or "").strip().lower()
    rows = list_prediction_history_reports_with_report(project, limit=max(1, int(limit)), kind="shadow")
    totals = {"reports": len(rows), "judged": 0, "unjudged": 0,
              "warnings": 0, "hits": 0, "near_hits": 0, "false_alarms": 0, "missed_fix_files": 0}
    patterns: dict = {}
    for row in rows:
        judgement = row.get("judgement")
        if not isinstance(judgement, dict):
            rep = row.get("report") or {}
            judgement = rep.get("judgement") if isinstance(rep.get("judgement"), dict) else None
        if not judgement:
            totals["unjudged"] += 1
            continue
        totals["judged"] += 1
        totals["warnings"] += int(judgement.get("warnings") or 0)
        totals["hits"] += int(judgement.get("hits") or 0)
        totals["near_hits"] += int(judgement.get("near_hits") or 0)
        totals["false_alarms"] += int(judgement.get("false_alarms") or 0)
        totals["missed_fix_files"] += len(judgement.get("missed_fix_files") or [])
        for issue in judgement.get("issues") or []:
            key = re.sub(r"\s+", " ", str(issue.get("pattern") or "")).strip().lower()[:200]
            if not key:
                continue
            slot = patterns.setdefault(key, {"pattern": str(issue.get("pattern") or "")[:200],
                                             "right": 0, "near": 0, "wrong": 0})
            verdict = str(issue.get("verdict") or "")
            if verdict == "hit":
                slot["right"] += 1
            elif verdict == "near_hit":
                slot["near"] += 1
            elif verdict == "false_alarm":
                slot["wrong"] += 1
    decided = totals["hits"] + totals["false_alarms"]
    totals["precision_percent"] = round(100.0 * totals["hits"] / decided, 1) if decided else None
    pattern_rows = sorted(patterns.values(), key=lambda p: -(p["right"] + p["near"] + p["wrong"]))[:50]
    return {"status": True, "project_name": project, "totals": totals, "patterns": pattern_rows}
