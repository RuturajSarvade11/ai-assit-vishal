"""
src/services/project_groups.py — Project Group Configuration (admin) + dashboard grouping.

Model (per the UI-developer spec):
  - GROUPS are dynamic: admin creates/renames/deletes them. Each group = { group_name (unique id),
    project_pattern }  e.g.  HIP-26 / "1GHIO*",  Vehicle SW / "VSW_*".
  - A project belongs to a group by (a) an explicit MANUAL assignment, else (b) matching a group's
    pattern, else (c) the implicit default group "Other".
  - "Other" is not stored — it is the fallback for any project not assigned and not matching a pattern.

Projects are DERIVED (get_all_projects); there is no stored project id, so PROJECT NAME is the identity.

Storage (two schemaless DynamoDB tables, created on demand, mirrors prediction_config):
  - project_group_defs{sfx}   PK group_name   -> { group_name, project_pattern, created_at, updated_at }
  - project_groups{sfx}       PK project_name  -> { project_name, group_name }   (manual override; a
                                                   value of "Other" pins a project out of any pattern)
"""
import re
import time
import logging

from src.databases.database import get_dynamodb
from src.configurations import config

logger = logging.getLogger(__name__)

DEFS_TABLE = f"project_group_defs{config.DYNAMODB_TABLE_SUFFIX}"
OVERRIDES_TABLE = f"project_groups{config.DYNAMODB_TABLE_SUFFIX}"
DEFAULT_GROUP = "Other"

_ready = False


def _defs():
    return get_dynamodb().Table(DEFS_TABLE)


def _ovr():
    return get_dynamodb().Table(OVERRIDES_TABLE)


def _ensure_tables():
    global _ready
    if _ready:
        return
    try:
        ddb = get_dynamodb()
        existing = [t.name for t in ddb.tables.all()]
        if DEFS_TABLE not in existing:
            logger.info("creating group defs table %s", DEFS_TABLE)
            ddb.create_table(
                TableName=DEFS_TABLE,
                KeySchema=[{"AttributeName": "group_name", "KeyType": "HASH"}],
                AttributeDefinitions=[{"AttributeName": "group_name", "AttributeType": "S"}],
                BillingMode="PAY_PER_REQUEST",
            ).wait_until_exists()
        if OVERRIDES_TABLE not in existing:
            logger.info("creating group overrides table %s", OVERRIDES_TABLE)
            ddb.create_table(
                TableName=OVERRIDES_TABLE,
                KeySchema=[{"AttributeName": "project_name", "KeyType": "HASH"}],
                AttributeDefinitions=[{"AttributeName": "project_name", "AttributeType": "S"}],
                BillingMode="PAY_PER_REQUEST",
            ).wait_until_exists()
        _ready = True
    except Exception:
        logger.exception("ensure project group tables failed")


def _scan(table):
    items = []
    resp = table.scan()
    items.extend(resp.get("Items", []))
    while "LastEvaluatedKey" in resp:
        resp = table.scan(ExclusiveStartKey=resp["LastEvaluatedKey"])
        items.extend(resp.get("Items", []))
    return items


# ---------------------------------------------------------------- pattern matching
def _norm_for_match(value):
    """Strip separators (_, -, spaces) + lowercase so naming variants of the SAME project family
    compare equal: 1g_hio_000u0 == 1ghio_000u0 == 1GHIO000U0. Glob metachars * and ? are preserved
    (not separators), so a stored pattern like `1g_hio_000u0*` also catches `1ghio_000u0_td5_rnt`."""
    return re.sub(r"[\s_\-]+", "", str(value or "")).lower()


def pattern_to_regex(pattern):
    """Glob -> anchored regex, built on the separator-normalized pattern. '*' = any chars, '?' = one."""
    pat = _norm_for_match(pattern)
    if not pat:
        return None
    rx = re.escape(pat).replace(r"\*", ".*").replace(r"\?", ".")
    try:
        return re.compile("^" + rx + "$")   # case + separators already normalized on both sides
    except re.error:
        return None


def pattern_matches(project_name, pattern):
    rx = pattern_to_regex(pattern)
    return bool(rx and rx.match(_norm_for_match(project_name)))


# ---------------------------------------------------------------- group defs (CRUD)
def list_group_defs():
    """[{group_name, project_pattern}] sorted by group_name."""
    try:
        _ensure_tables()
        out = []
        for it in _scan(_defs()):
            name = str(it.get("group_name") or "").strip()
            if name:
                out.append({"group_name": name, "project_pattern": str(it.get("project_pattern") or "").strip()})
        return sorted(out, key=lambda g: g["group_name"].lower())
    except Exception:
        logger.exception("list_group_defs failed")
        return []


def get_group_def(group_name):
    _ensure_tables()
    item = _defs().get_item(Key={"group_name": str(group_name or "").strip()}).get("Item")
    return item or None


def create_group(group_name, project_pattern):
    name = str(group_name or "").strip()
    if not name:
        raise ValueError("groupName is required")
    if name.lower() == DEFAULT_GROUP.lower():
        raise ValueError('"Other" is a reserved group and cannot be created')
    _ensure_tables()
    if get_group_def(name):
        raise ValueError(f"group '{name}' already exists")
    now = int(time.time())
    _defs().put_item(Item={
        "group_name": name,
        "project_pattern": str(project_pattern or "").strip(),
        "created_at": now,
        "updated_at": now,
    })
    return {"group_name": name, "project_pattern": str(project_pattern or "").strip()}


def update_group(old_group_name, group_name, project_pattern):
    old = str(old_group_name or "").strip()
    new = str(group_name or old).strip()
    if not old:
        raise ValueError("oldGroupName is required")
    _ensure_tables()
    if not get_group_def(old):
        raise ValueError(f"group '{old}' not found")
    if new.lower() == DEFAULT_GROUP.lower():
        raise ValueError('"Other" is a reserved group name')
    renaming = new.lower() != old.lower()
    if renaming and get_group_def(new):
        raise ValueError(f"group '{new}' already exists")
    now = int(time.time())
    _defs().put_item(Item={
        "group_name": new,
        "project_pattern": str(project_pattern or "").strip(),
        "created_at": (get_group_def(old) or {}).get("created_at", now),
        "updated_at": now,
    })
    if renaming:
        _defs().delete_item(Key={"group_name": old})
        # repoint manual overrides that named the old group
        for it in _scan(_ovr()):
            if str(it.get("group_name") or "").strip() == old:
                _ovr().put_item(Item={"project_name": it["project_name"], "group_name": new})
    return {"group_name": new, "project_pattern": str(project_pattern or "").strip()}


def delete_group(group_name):
    """Remove the group definition and move its members to Other (drop overrides that named it; its
    pattern is gone, so pattern-matched projects fall back to Other automatically)."""
    name = str(group_name or "").strip()
    if not name:
        raise ValueError("groupName is required")
    _ensure_tables()
    _defs().delete_item(Key={"group_name": name})
    for it in _scan(_ovr()):
        if str(it.get("group_name") or "").strip() == name:
            _ovr().delete_item(Key={"project_name": it["project_name"]})
    return {"group_name": name}


# ---------------------------------------------------------------- manual assignments (overrides)
def get_overrides():
    """{project_name: group_name} explicit assignments (incl. 'Other' pins)."""
    try:
        _ensure_tables()
        out = {}
        for it in _scan(_ovr()):
            p = str(it.get("project_name") or "").strip()
            g = str(it.get("group_name") or "").strip()
            if p and g:
                out[p] = g
        return out
    except Exception:
        logger.exception("get_overrides failed")
        return {}


def assign_project(project_name, group_name):
    """Manually put a project into a group (from the Add Projects dropdown)."""
    p = str(project_name or "").strip()
    g = str(group_name or "").strip()
    if not p or not g:
        raise ValueError("projectName and groupName are required")
    _ensure_tables()
    _ovr().put_item(Item={"project_name": p, "group_name": g, "updated_at": int(time.time())})
    return {"project_name": p, "group_name": g}


def move_project_to_other(project_name):
    """Remove a project from its group -> pin it to Other (beats any pattern match)."""
    return assign_project(project_name, DEFAULT_GROUP)


def remove_project_override(project_name):
    """Forget a project's manual pin entirely (the project is being deleted). Both the raw and
    the lower-cased spelling are tried - pins were written as typed. Returns the pins removed."""
    raw = str(project_name or "").strip()
    if not raw:
        return 0
    _ensure_tables()
    removed = 0
    for name in dict.fromkeys([raw, raw.lower()]):
        res = _ovr().delete_item(Key={"project_name": name}, ReturnValues="ALL_OLD")
        if res.get("Attributes"):
            removed += 1
    return removed


# ---------------------------------------------------------------- resolution
def resolve_group(project_name, group_defs=None, overrides=None):
    """A project's DISPLAY group: explicit override first, else first matching pattern, else Other.

    This stays manual on purpose. Management reads the dashboard by family name (HIP26, PTP4Lite),
    not by the raw project id, so the admin-created groups remain the label. What changed on 29-Sep
    is that retrieval scope no longer comes from here - see resolve_scope_group.
    """
    p = str(project_name or "").strip()
    overrides = get_overrides() if overrides is None else overrides
    if p in overrides:
        return overrides[p]
    defs = list_group_defs() if group_defs is None else group_defs
    for gd in defs:
        if pattern_matches(p, gd.get("project_pattern")):
            return gd["group_name"]
    return DEFAULT_GROUP


def resolve_scope_group(project_name, group_defs=None, overrides=None):
    """The group that RETRIEVAL widens over, and whether it was derived from the name.

    Returns (group_name, source) where source is "derived" or "manual".

    When the naming convention is switched on and the project name fits it, the CUSTOMER read out
    of the name is the scope - no admin has to file the project first, which is the maintenance
    overhead this replaces. A name that does not fit the convention derives nothing and falls back
    to the manual group, so switching the convention on can never widen a project that the
    convention does not recognise.
    """
    try:
        from src.services import project_naming
        if project_naming.is_enabled():
            customer, _project = project_naming.derive_identity(project_name)
            if customer:
                return customer, "derived"
    except Exception:
        logger.exception("derived scope group failed - falling back to the manual group")
    return resolve_group(project_name, group_defs, overrides), "manual"


# ------------------------------------------------------------ retrieval scope
# Recommendations are project-scoped. Evidence is shared between projects
# that belong to the same GROUP, because projects sharing a toolchain legitimately share logs.
#
# THE RULE this function exists to enforce: ungrouped projects do
# NOT share. "Other" is what a project falls into when nothing matched - a removal bucket, not a
# group - so widening to it would make every unconfigured project in the estate share evidence
# with every other one. That is an accuracy problem and a confidentiality one.
#
# Widening therefore requires ALL of: a resolved group, that is not DEFAULT_GROUP, and that
# actually EXISTS in the group definitions. The last test also kills a phantom group, because
# assign_project() accepts any string without checking a definition exists - a typo'd group name
# would otherwise resolve to itself and pass the first two tests.
_SCOPE_TTL_SEC = 120
_scope_cache: dict = {}


def invalidate_scope_cache() -> None:
    """Drop the resolved scopes. Called when the naming convention is edited: the convention
    decides who shares evidence, so a change must take effect on the next request rather than
    up to _SCOPE_TTL_SEC later - a half-applied scope is the kind of drift that is impossible to
    reproduce from a trace afterwards."""
    _scope_cache.clear()


# The three scopes the 30-Sep review settled on, narrowest first. "group" is kept as an accepted
# spelling of "customer" because that is what the stored configuration and the existing trace rows
# already say; one level, two names, and nothing has to be migrated.
SCOPE_PROJECT = "project"
SCOPE_CUSTOMER = "customer"
SCOPE_GLOBAL = "global"
_SCOPE_ALIASES = {"group": SCOPE_CUSTOMER}
VALID_SCOPES = (SCOPE_PROJECT, SCOPE_CUSTOMER, SCOPE_GLOBAL)


def normalize_scope(value, default=SCOPE_PROJECT):
    """A requested scope -> one of VALID_SCOPES, or `default` when it is unrecognised.

    Unrecognised input narrows rather than widens. A typo in a request must never be the reason a
    project's evidence is searched estate-wide.
    """
    raw = str(value or "").strip().lower()
    if not raw:
        return default
    raw = _SCOPE_ALIASES.get(raw, raw)
    return raw if raw in VALID_SCOPES else default


def resolve_scope_projects(project_name, all_project_names=None, requested_scope=None):
    """(members, mode) for retrieval scope.

    ([project], "project")   - the default, and the answer to ANY doubt or failure.
    (members,   "customer")  - the project's customer, or its defined group of more than one.
    ([],        "global")    - no project filter at all; scope_where emits nothing.

    `requested_scope` is what the DEVELOPER asked for on this request. The 30-Sep review put the
    choice in their hands rather than an administrator's, so it overrides the stored default when
    it is given. It can only be honoured, never exceeded: asking for customer scope on a project
    that has no customer still resolves to project scope.

    Fails closed to project scope on every error. A scope resolver that fails open widens the
    search, which is the opposite of safe.
    """
    p = str(project_name or "").strip().lower()
    wanted = normalize_scope(requested_scope, default=None) if requested_scope else None
    if not p:
        return [], SCOPE_PROJECT

    # Global is not a widening of the project's group - it is the absence of a filter, so there is
    # nothing to resolve and nothing worth caching.
    if wanted == SCOPE_GLOBAL:
        return [], SCOPE_GLOBAL
    if wanted == SCOPE_PROJECT:
        return [p], SCOPE_PROJECT

    now = time.time()
    hit = _scope_cache.get(p)
    if hit and (now - hit[0]) < _SCOPE_TTL_SEC:
        return list(hit[1]), hit[2]
    try:
        defs = list_group_defs()
        defined = {str(d.get("group_name") or "").strip() for d in defs}
        overrides = get_overrides()
        group, source = resolve_scope_group(project_name, defs, overrides)
        # A DERIVED customer needs no group definition to exist - the naming convention IS the
        # definition, which is the whole point of deriving it. The "must be defined" test below
        # still guards the manual path, where a typo'd group name would otherwise resolve to
        # itself and pass as a real group.
        if source == "derived":
            if not group:
                _scope_cache[p] = (now, [p], SCOPE_PROJECT)
                return [p], SCOPE_PROJECT
        elif not group or group == DEFAULT_GROUP or group not in defined:
            _scope_cache[p] = (now, [p], SCOPE_PROJECT)
            return [p], SCOPE_PROJECT

        if all_project_names is None:
            from src.utils.project_details import get_all_projects
            all_project_names = [str((row or {}).get("project_name") or "")
                                 for row in (get_all_projects() or [])]
        members = sorted({
            str(name or "").strip().lower()
            for name in all_project_names
            if str(name or "").strip()
            and resolve_scope_group(name, defs, overrides) == (group, source)
        })
        if p not in members:
            members.append(p)
            members.sort()
        # A customer with one project in it is project scope by another name - say so, so callers
        # and the trace do not report a widening that did not happen.
        mode = SCOPE_CUSTOMER if len(members) > 1 else SCOPE_PROJECT
        result = (members if mode == SCOPE_CUSTOMER else [p])
        _scope_cache[p] = (now, result, mode)
        return list(result), mode
    except Exception:
        logger.exception("resolve_scope_projects failed - falling back to project scope")
        return [p], SCOPE_PROJECT


# GROUP IS THE SCOPE. A project in a defined group is searched together with its siblings
# in ONE pass (every source widened) and the scoring decides; the project's own fix wins only a
# tie. The earlier two-pass fallback (project first, siblings only when the project showed nothing)
# and its contextvar were removed - a wrong group is corrected in the group configuration, not by
# narrowing the search. "Other" and single-member groups still resolve to project scope above.


def scope_where(project_name, extra=None, members=None, mode=None):
    """The store filter for a scope. Identical to today's dict for project scope, so a caller
    that is not widening emits byte-identical queries.

    Never emits a 0- or 1-element $or: Chroma REJECTS a single-element $or, and that rejection is
    swallowed into an empty result - the fail-open path would silently return NO candidates
    instead of project-scoped ones.

    Global scope emits NO project filter, and it has to be asked for by `mode`. An empty members
    list on its own still narrows to the project: "nothing resolved" and "deliberately unfiltered"
    must not be the same signal, or a failed lookup would quietly search the whole estate.
    """
    if mode == SCOPE_GLOBAL:
        return extra if extra else None
    if members is None:
        members, _mode = resolve_scope_projects(project_name)
    names = sorted({str(m or "").strip().lower() for m in (members or []) if str(m or "").strip()})
    if len(names) <= 1:
        base = {"project_name": names[0] if names else str(project_name or "").strip().lower()}
    else:
        base = {"project_name": {"$in": names}}
    return {"$and": [base, extra]} if extra else base


def build_group_map(project_names):
    """{project_name: group_name} for many projects (loads defs + overrides once)."""
    defs = list_group_defs()
    overrides = get_overrides()
    return {p: resolve_group(p, defs, overrides) for p in project_names}


def rollup_by_group(rows, group_map=None):
    """Sum per-project dashboard rows into per-GROUP rows (the chart reads at group
    level instead of listing each and every project).

    rows: [{"projectName", "errorCount", "recommendedCount"}] -> the same shape, one entry per
    group, plus "groupName" and "projectCount". Ordered busiest-first with the name as tie-break,
    so the bars do not shuffle between two refreshes that happen to tie.

    Lives here, next to resolve_group, because this is the SAME grouping the dashboard cards and
    the recommendation scope use - a second rollup implemented elsewhere is how a chart starts
    disagreeing with the cards above it. Pass group_map to avoid a second resolve.
    """
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    if not rows:
        # Nothing to group - return before build_group_map, which would otherwise read the group
        # definitions and overrides out of DynamoDB to answer a question about zero projects.
        return []
    names = [str(r.get("projectName") or "") for r in rows]
    gmap = group_map if group_map is not None else build_group_map(names)

    totals = {}
    for row in rows:
        name = str(row.get("projectName") or "")
        key = gmap.get(name) or DEFAULT_GROUP
        bucket = totals.setdefault(key, {"errorCount": 0, "recommendedCount": 0, "projectCount": 0})
        bucket["errorCount"] += int(row.get("errorCount") or 0)
        bucket["recommendedCount"] += int(row.get("recommendedCount") or 0)
        bucket["projectCount"] += 1

    # projectName carries the label so the chart needs no model change; groupName says what the
    # row actually is.
    #
    # "Other" is pinned LAST, matching _pg_group_order in handlers and sortGroups in the frontend.
    # It is a removal bucket rather than a group, and because it absorbs every
    # unconfigured project it is usually the biggest bucket - sorting purely by count would put
    # the one non-group at the head of a chart about groups.
    return sorted(
        [{"projectName": name, "groupName": name, **vals} for name, vals in totals.items()],
        key=lambda d: (d["groupName"] == DEFAULT_GROUP, -d["errorCount"], d["projectName"].lower()),
    )
