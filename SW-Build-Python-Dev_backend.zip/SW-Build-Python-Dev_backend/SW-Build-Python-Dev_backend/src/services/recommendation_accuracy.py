"""
src/services/recommendation_accuracy.py — how often the recommendation was actually right.

Every scoring change so far was judged on a handful of hand-picked cases. The ground truth for a
recommendation arrives for free a little later: the developer fixes the failure and the extension
uploads the fix (/final-build). If that fix is one of the solutions we recommended for the same
project + task shortly before, we know at which rank the right answer sat.

Per upload, one row is stored:

  PK="RECACCURACY"  SK="<iso>#<trace_id>"
    shown_rank   1..3 when the uploaded fix was among the SHOWN recommendations, else 0
    pool_rank    1..10 rank in the scored candidate pool (shown or not), else 0
                 (shown_rank 0 + pool_rank > 0 = retrieved but ranked too low;
                  pool_rank 0 = retrieval never found it - a different problem)
    file_rank    first shown rank whose fix touched the same files, else 0 (a softer signal)

summary() turns the rows into Hit@1 / Hit@3 / in-pool rate / MRR, overall and per project, so a
weight change can be judged on real failures before and after.

A fix "matches" a candidate when the candidate IS the uploaded request (a duplicate upload
resolves to the stored request) or when both solutions have the same normalised content
fingerprint. Every function is fail-open: measuring must never break an upload.
"""
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_PK = "RECACCURACY"
_TRACE_PK = "RECTRACE"
_RETENTION_DAYS = 180
_RECO_ENDPOINTS = {"report-error", "recommendations"}


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _table():
    from src.utils.project_details import ai_assisted_data_table
    return ai_assisted_data_table


def _task_token(value: str) -> str:
    from src.services.handlers import _canonical_task_token
    return str(_canonical_task_token(str(value or "")) or "").strip().lower()


def _fingerprint(solution) -> str:
    from src.services.handlers import _solution_fingerprint
    return _solution_fingerprint(solution or [])


def _solution_files(solution) -> set:
    from src.services.handlers import _normalize_solution_payload
    out = set()
    for item in _normalize_solution_payload(solution or []):
        name = str(item.get("fileName") or item.get("filePath") or "").replace("\\", "/")
        name = name.rstrip("/").split("/")[-1].strip().lower()
        if name:
            out.add(name)
    return out


def _recent_traces(project_name: str, since: datetime, max_items: int = 1000) -> List[Dict]:
    """Recommendation traces of one project created after ``since``, newest first."""
    from boto3.dynamodb.conditions import Key
    items: List[Dict] = []
    kwargs = {
        "KeyConditionExpression": Key("PK").eq(_TRACE_PK) & Key("SK").gte(_iso(since)),
        "ScanIndexForward": False,
    }
    while len(items) < max_items:
        res = _table().query(**kwargs)
        for it in res.get("Items", []):
            if str(it.get("project_name") or "").strip().lower() == project_name:
                items.append(it)
        last = res.get("LastEvaluatedKey")
        if not last:
            break
        kwargs["ExclusiveStartKey"] = last
    return items


def rank_upload_in_trace(trace: Dict, uploaded_request_id: str, upload_fp: str,
                         upload_files: set, candidate_solution) -> Dict:
    """Where did the uploaded fix sit in this trace? Pure apart from ``candidate_solution``
    (request_id -> stored solution), so it is unit-testable.

    Returns {shown_rank, pool_rank, file_rank, shown_count, pool_count}."""
    candidates = sorted((trace.get("candidates") or []),
                        key=lambda c: int(c.get("rank") or 0) or 999)
    shown_ids = [str(r) for r in (trace.get("shown_request_ids") or [])]
    shown_rank = pool_rank = file_rank = 0
    fp_cache: Dict[str, str] = {}

    def _is_match(rid: str) -> bool:
        if not rid:
            return False
        if uploaded_request_id and rid == uploaded_request_id:
            return True
        if not upload_fp:
            return False
        if rid not in fp_cache:
            fp_cache[rid] = _fingerprint(candidate_solution(rid))
        return bool(fp_cache[rid]) and fp_cache[rid] == upload_fp

    for pos, cand in enumerate(candidates, start=1):
        if _is_match(str(cand.get("request_id") or "")):
            pool_rank = pos
            break
    for pos, rid in enumerate(shown_ids, start=1):
        if _is_match(rid):
            shown_rank = pos
            break
    if upload_files:
        for pos, rid in enumerate(shown_ids, start=1):
            if _solution_files(candidate_solution(rid)) & upload_files:
                file_rank = pos
                break
    return {"shown_rank": shown_rank, "pool_rank": pool_rank, "file_rank": file_rank,
            "shown_count": len(shown_ids), "pool_count": len(candidates)}


def evaluate_upload(project_name: str, task_name: str, solution, uploaded_request_id: str,
                    window_hours: Optional[float] = None) -> Optional[Dict]:
    """Score the latest recommendation for this project + task against the fix just uploaded.
    Stores and returns the accuracy row, or None when there was no recommendation to judge."""
    try:
        import os
        project = str(project_name or "").strip().lower()
        task = _task_token(task_name)
        if not project or not task:
            return None
        if window_hours is None:
            try:
                window_hours = float(os.getenv("RECO_ACCURACY_WINDOW_HOURS", "72"))
            except (TypeError, ValueError):
                window_hours = 72.0
        now = datetime.now(timezone.utc)
        traces = [t for t in _recent_traces(project, now - timedelta(hours=window_hours))
                  if str(t.get("endpoint") or "") in _RECO_ENDPOINTS
                  and _task_token(t.get("task_path") or "") == task]
        if not traces:
            return None
        trace = traces[0]  # newest: the recommendation the developer last saw for this task

        from src.utils.project_details import get_final_build_payload
        payload_cache: Dict[str, object] = {}

        def _candidate_solution(rid: str):
            if rid not in payload_cache:
                try:
                    payload_cache[rid] = (get_final_build_payload(rid) or {}).get("solution") or []
                except Exception:
                    payload_cache[rid] = []
            return payload_cache[rid]

        ranks = rank_upload_in_trace(trace, str(uploaded_request_id or ""),
                                     _fingerprint(solution), _solution_files(solution),
                                     _candidate_solution)
        row = {
            "PK": _PK,
            "SK": f"{_iso(now)}#{trace.get('trace_id') or ''}",
            "created_date": _iso(now),
            "project_name": project,
            "task": task,
            "trace_id": str(trace.get("trace_id") or ""),
            "trace_created": str(trace.get("created_date") or ""),
            "uploaded_request_id": str(uploaded_request_id or ""),
            "scoring_config": trace.get("scoring_config") or {},
            "expires_at": int(time.time()) + _RETENTION_DAYS * 86400,
            **ranks,
        }
        _table().put_item(Item=row)
        logger.info("[reco-accuracy] project=%s task=%s trace=%s shown_rank=%s pool_rank=%s file_rank=%s",
                    project, task, row["trace_id"], ranks["shown_rank"], ranks["pool_rank"],
                    ranks["file_rank"])
        return row
    except Exception:
        logger.exception("recommendation accuracy evaluation failed (upload unaffected)")
        return None


def enqueue_evaluation(project_name: str, task_name: str, solution, uploaded_request_id: str) -> None:
    """Fire-and-forget evaluate_upload on a background thread."""
    import threading
    threading.Thread(
        target=evaluate_upload,
        args=(project_name, task_name, solution, uploaded_request_id),
        name="reco-accuracy", daemon=True,
    ).start()


def summarize(rows: List[Dict]) -> Dict:
    """Hit@1 / Hit@3 / in-pool rate / MRR over accuracy rows. Pure - unit-testable."""
    def _block(rs: List[Dict]) -> Dict:
        n = len(rs)
        if not n:
            return {"evaluated": 0, "hit_at_1": None, "hit_at_3": None, "in_pool": None,
                    "retrieved_but_hidden": None, "file_hit_at_3": None, "mrr": None}
        shown = [int(r.get("shown_rank") or 0) for r in rs]
        pool = [int(r.get("pool_rank") or 0) for r in rs]
        files = [int(r.get("file_rank") or 0) for r in rs]
        return {
            "evaluated": n,
            "hit_at_1": round(sum(1 for s in shown if s == 1) / n, 4),
            "hit_at_3": round(sum(1 for s in shown if 1 <= s <= 3) / n, 4),
            "in_pool": round(sum(1 for p in pool if p > 0) / n, 4),
            # Found by retrieval but not shown in the top 3: a RANKING miss, not a recall miss.
            "retrieved_but_hidden": round(sum(1 for s, p in zip(shown, pool) if p > 0 and s == 0) / n, 4),
            "file_hit_at_3": round(sum(1 for f in files if 1 <= f <= 3) / n, 4),
            "mrr": round(sum((1.0 / s) for s in shown if s > 0) / n, 4),
        }

    by_project: Dict[str, List[Dict]] = {}
    for r in rows:
        by_project.setdefault(str(r.get("project_name") or ""), []).append(r)
    return {"overall": _block(rows),
            "by_project": {p: _block(rs) for p, rs in sorted(by_project.items())}}


def get_summary(project_name: str = "", days: int = 30) -> Dict:
    """Accuracy over the last ``days`` days, optionally for one project."""
    try:
        from boto3.dynamodb.conditions import Key
        since = datetime.now(timezone.utc) - timedelta(days=max(1, int(days or 30)))
        kwargs = {"KeyConditionExpression": Key("PK").eq(_PK) & Key("SK").gte(_iso(since)),
                  "ScanIndexForward": False}
        rows: List[Dict] = []
        while True:
            res = _table().query(**kwargs)
            rows.extend(res.get("Items", []))
            last = res.get("LastEvaluatedKey")
            if not last or len(rows) >= 20000:
                break
            kwargs["ExclusiveStartKey"] = last
        project = str(project_name or "").strip().lower()
        if project:
            rows = [r for r in rows if str(r.get("project_name") or "") == project]
        out = summarize(rows)
        out["days"] = int(days or 30)
        out["recent"] = [{k: r.get(k) for k in ("created_date", "project_name", "task", "trace_id",
                                                 "uploaded_request_id", "shown_rank", "pool_rank",
                                                 "file_rank")} for r in rows[:50]]
        return out
    except Exception:
        logger.exception("recommendation accuracy summary failed")
        return summarize([])
