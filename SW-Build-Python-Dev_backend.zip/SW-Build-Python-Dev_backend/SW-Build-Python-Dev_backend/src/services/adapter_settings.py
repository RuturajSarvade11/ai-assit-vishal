"""
src/services/adapter_settings.py — runtime ON/OFF for the W feedback adapter.

One DynamoDB item holds the GLOBAL default + PER-PROJECT overrides. The recommendation flow calls
adapter_enabled_for(project) at query time:  effective = project override if set, else global default.
Cached ~30s; the cache is refreshed on every toggle. The global default seeds from the
FEEDBACK_ADAPTER_ENABLED env flag until an admin changes it. Admin endpoints live in admin_route.py.
"""
import time
import logging

from src.databases.database import get_dynamodb
from src.configurations import config

logger = logging.getLogger(__name__)

SETTINGS_TABLE = f"app_settings{config.DYNAMODB_TABLE_SUFFIX}"
SETTING_KEY = "feedback_adapter"
_CACHE_TTL = 30

# One settings item per adapter DOMAIN: "error" = the original W toggle (unchanged key,
# unchanged behaviour), "artifact" = W_artifact for the artifact-evidence search.
_DOMAIN_KEYS = {
    "error": SETTING_KEY,
    "artifact": "feedback_adapter_artifact",
}
_ENV_DEFAULTS = {
    "error": str(getattr(config, "FEEDBACK_ADAPTER_ENABLED", False)).strip().lower() in ("1", "true", "yes", "on"),
    "artifact": str(getattr(config, "FEEDBACK_ADAPTER_ARTIFACT_ENABLED", False)).strip().lower() in ("1", "true", "yes", "on"),
}
_ENV_DEFAULT = _ENV_DEFAULTS["error"]

_cache = {domain: {"data": None, "ts": 0.0} for domain in _DOMAIN_KEYS}
_table_ready = False


def _domain(domain: str) -> str:
    d = str(domain or "error").strip().lower()
    return d if d in _DOMAIN_KEYS else "error"


def _table():
    return get_dynamodb().Table(SETTINGS_TABLE)


def _ensure_table():
    global _table_ready
    if _table_ready:
        return
    try:
        ddb = get_dynamodb()
        if SETTINGS_TABLE not in [t.name for t in ddb.tables.all()]:
            logger.info("creating settings table %s", SETTINGS_TABLE)
            ddb.create_table(
                TableName=SETTINGS_TABLE,
                KeySchema=[{"AttributeName": "setting_key", "KeyType": "HASH"}],
                AttributeDefinitions=[{"AttributeName": "setting_key", "AttributeType": "S"}],
                BillingMode="PAY_PER_REQUEST",
            ).wait_until_exists()
        _table_ready = True
    except Exception:
        logger.exception("ensure settings table failed")


def _defaults(domain: str = "error"):
    return {"global_enabled": _ENV_DEFAULTS[_domain(domain)], "project_overrides": {},
            "group_overrides": {}, "updated_by": "default", "updated_at": 0}


def _read_raw(domain: str = "error"):
    domain = _domain(domain)
    try:
        _ensure_table()  # create on first read too, not only on write — avoids ResourceNotFound spam
        item = _table().get_item(Key={"setting_key": _DOMAIN_KEYS[domain]}).get("Item")
        if not item:
            return _defaults(domain)
        return {
            "global_enabled": bool(item.get("global_enabled", _ENV_DEFAULTS[domain])),
            "project_overrides": {str(k): bool(v) for k, v in (item.get("project_overrides") or {}).items()},
            "group_overrides": {str(k): bool(v) for k, v in (item.get("group_overrides") or {}).items()},
            "updated_by": str(item.get("updated_by", "")),
            "updated_at": int(item.get("updated_at", 0) or 0),
        }
    except Exception:
        logger.exception("read adapter settings failed - using defaults | domain=%s", domain)
        return _defaults(domain)


def get_settings(force: bool = False, domain: str = "error") -> dict:
    domain = _domain(domain)
    now = time.time()
    slot = _cache[domain]
    if not force and slot["data"] is not None and (now - slot["ts"]) < _CACHE_TTL:
        return slot["data"]
    data = _read_raw(domain)
    slot["data"], slot["ts"] = data, now
    return data


def _write(data: dict, by: str, domain: str = "error") -> dict:
    domain = _domain(domain)
    _ensure_table()
    data["updated_by"] = by
    data["updated_at"] = int(time.time())
    _table().put_item(Item={
        "setting_key": _DOMAIN_KEYS[domain],
        "global_enabled": bool(data["global_enabled"]),
        "project_overrides": {str(k): bool(v) for k, v in (data["project_overrides"] or {}).items()},
        "group_overrides": {str(k): bool(v) for k, v in (data.get("group_overrides") or {}).items()},
        "updated_by": by, "updated_at": data["updated_at"],
    })
    _cache[domain]["data"], _cache[domain]["ts"] = data, time.time()
    return data


def set_global(enabled: bool, by: str, domain: str = "error") -> dict:
    data = dict(get_settings(force=True, domain=domain))
    data["global_enabled"] = bool(enabled)
    return _write(data, by, domain)


def set_project(project: str, enabled: bool, by: str, domain: str = "error") -> dict:
    data = dict(get_settings(force=True, domain=domain))
    overrides = dict(data["project_overrides"])
    overrides[str(project).strip().lower()] = bool(enabled)
    data["project_overrides"] = overrides
    return _write(data, by, domain)


def clear_project(project: str, by: str, domain: str = "error") -> dict:
    data = dict(get_settings(force=True, domain=domain))
    overrides = dict(data["project_overrides"])
    overrides.pop(str(project).strip().lower(), None)
    data["project_overrides"] = overrides
    return _write(data, by, domain)


def member_projects_of(group_name: str) -> list:
    """Every project that resolves into this group — short-TTL cached, fail-open to []."""
    group = str(group_name or "").strip()
    if not group:
        return []
    try:
        from src.utils import ttl_cache

        def _members():
            from src.services import project_groups as _pg
            from src.utils.project_details import get_all_projects
            names = {str(p.get("project_name") or "").strip()
                     for p in (get_all_projects() or []) if p.get("project_name")}
            gmap = _pg.build_group_map(names)
            return sorted((n for n, g in gmap.items() if str(g) == group), key=str.lower)

        return list(ttl_cache.get_or_compute(("adapter-group-members", group.lower()), _members))
    except Exception:
        logger.exception("group member listing failed | group=%s", group)
        return []


def _drop_member_pins(data: dict, group: str) -> None:
    """A group-wide switch means the whole family follows. Old PER-PROJECT pins (from the
    Home toggle before group support existed, or from misfired test clicks) would silently
    beat the group forever — so every member project's pin is removed when its group is
    switched or cleared. A project pin set AFTER the group action still wins, as designed."""
    members = {str(m).strip().lower() for m in member_projects_of(group)}
    if not members:
        return
    before = dict(data.get("project_overrides") or {})
    data["project_overrides"] = {k: v for k, v in before.items() if k not in members}
    removed = sorted(set(before) - set(data["project_overrides"]))
    if removed:
        logger.info("[adapter] group action swept stale project pins | group=%s | removed=%s",
                    group, removed)


def set_group(group: str, enabled: bool, by: str, domain: str = "error") -> dict:
    """The adapter is configured GROUP-wise — one switch for a project
    group applies to every project resolved into it."""
    data = dict(get_settings(force=True, domain=domain))
    overrides = dict(data.get("group_overrides") or {})
    overrides[str(group).strip().lower()] = bool(enabled)
    data["group_overrides"] = overrides
    _drop_member_pins(data, group)
    return _write(data, by, domain)


def clear_group(group: str, by: str, domain: str = "error") -> dict:
    data = dict(get_settings(force=True, domain=domain))
    overrides = dict(data.get("group_overrides") or {})
    overrides.pop(str(group).strip().lower(), None)
    data["group_overrides"] = overrides
    _drop_member_pins(data, group)
    return _write(data, by, domain)


def _group_of(project_name: str) -> str:
    """The dashboard group this project resolves to — short-TTL cached, fail-open to ''."""
    proj = str(project_name or "").strip()
    if not proj:
        return ""
    try:
        from src.utils import ttl_cache

        def _resolve():
            from src.services import project_groups as _pg
            return str(_pg.build_group_map({proj}).get(proj, "") or "")

        return str(ttl_cache.get_or_compute(("adapter-group", proj.lower()), _resolve,
                                            deep_copy=False) or "")
    except Exception:
        logger.exception("group resolution failed for adapter setting | project=%s", proj)
        return ""


def adapter_enabled_for(project_name: str, domain: str = "error") -> bool:
    """Effective switch: project override > group override > global default."""
    data = get_settings(domain=domain)
    proj = str(project_name or "").strip().lower()
    if proj in data["project_overrides"]:
        return bool(data["project_overrides"][proj])
    group = _group_of(project_name).lower()
    group_overrides = data.get("group_overrides") or {}
    if group and group in group_overrides:
        return bool(group_overrides[group])
    return bool(data["global_enabled"])
