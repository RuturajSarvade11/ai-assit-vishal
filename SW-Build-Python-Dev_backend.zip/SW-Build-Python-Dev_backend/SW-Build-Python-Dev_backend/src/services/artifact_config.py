"""
src/services/artifact_config.py — Artifact Collection configuration (dashboard "Artifact
Configuration" admin page, UI team spec; folder_name REMOVED per the updated contract
— folder_path is the only folder display/configuration value, folder_id the identifier;
folder_name is ignored if a client still sends it and never returned), stored in DynamoDB.

One record in a dedicated table (`artifact_config{sfx}`) holds the scan folders + include/exclude
patterns that decide WHICH files the extension collects as build artifacts when a build fails:

    folders: [ { folder_id, folder_path, is_enabled,
                 include_patterns: [{pattern_id, pattern, pattern_type:"include"}],
                 exclude_patterns: [{pattern_id, pattern, pattern_type:"exclude"}] } ]

Matching rules (mirrored by the extension): patterns match the file NAME only (not the path),
'*' wildcard, case-insensitive, EXCLUDE always beats include, disabled folders are skipped.

Same storage pattern as prediction_config.py: schemaless single record, defaults merged under the
stored item, 30s read cache, updated_by/updated_at audit on every write. IDs are numeric and
monotonic (next_folder_id / next_pattern_id counters persisted in the record) so the UI can use
them as stable handles.

Every mutation returns the FULL view (same structure as the GET API) per the UI spec, so the
frontend replaces its screen state with the response.
"""
import time
import logging
from fnmatch import fnmatchcase

from src.databases.database import get_dynamodb
from src.configurations import config

logger = logging.getLogger(__name__)

CONFIG_TABLE = f"artifact_config{config.DYNAMODB_TABLE_SUFFIX}"
CONFIG_KEY = "artifact_collection"   # single global record
_CACHE_TTL = 30

# Dropdown source for "Add Folder" (UI contract: folders are picked from a backend-fed
# dropdown instead of free text). These are the GBE task-build-dir subfolders the extension can
# collect from. 'in' (build inputs) and 'tmp' (scratch) are intentionally NOT offered — they carry
# no failure evidence, per client guidance.
FOLDER_OPTIONS = ["out", "log", "wrk", "proc"]


def folder_options(cfg: dict | None = None) -> list[dict]:
    """Selectable folders for the Add Folder dropdown, each flagged with whether it is already
    configured (duplicates are rejected on add, so the UI can disable those entries)."""
    cfg = cfg or get_config()
    configured = {_norm_path(f["folder_path"]) for f in cfg["folders"]}
    return [
        {"folder_path": p, "is_configured": _norm_path(p) in configured}
        for p in FOLDER_OPTIONS
    ]


# Static "Key Rules" block for the right-side panel (spec section 5.1).
RULES = {
    "wildcard_supported": True,
    "match_against": "file_name",
    "exclusion_priority": True,
    "duplicate_patterns_allowed": False,
    "empty_patterns_allowed": False,
}

# Defaults = the extension's CURRENT hardcoded collection behavior (RuntimeArtifactCollector.ts:
# out/log/wrk under the task build dir + TD5 proc; .txt/.log allow-list; lock/process-id/.gbe
# noise excluded), so a fresh environment behaves exactly like today until an admin edits the page.
_DEFAULT_INCLUDE = ["*.txt", "*.log"]
_DEFAULT_EXCLUDE = ["*lock*", "process-id.txt", "*.gbe"]
DEFAULT_FOLDERS = [
    {"folder_path": "out", "is_enabled": True,
     "include": list(_DEFAULT_INCLUDE), "exclude": list(_DEFAULT_EXCLUDE)},
    {"folder_path": "log", "is_enabled": True,
     "include": list(_DEFAULT_INCLUDE), "exclude": list(_DEFAULT_EXCLUDE)},
    {"folder_path": "wrk", "is_enabled": True,
     "include": list(_DEFAULT_INCLUDE), "exclude": list(_DEFAULT_EXCLUDE)},
    {"folder_path": "proc", "is_enabled": True,
     "include": list(_DEFAULT_INCLUDE), "exclude": list(_DEFAULT_EXCLUDE)},
]

_cache = {"data": None, "ts": 0.0}
_table_ready = False


class ArtifactConfigNotFound(LookupError):
    """Unknown folder_id / pattern_id — the route answers 404."""


def _table():
    return get_dynamodb().Table(CONFIG_TABLE)


def _ensure_table():
    global _table_ready
    if _table_ready:
        return
    try:
        ddb = get_dynamodb()
        if CONFIG_TABLE not in [t.name for t in ddb.tables.all()]:
            logger.info("creating artifact config table %s", CONFIG_TABLE)
            ddb.create_table(
                TableName=CONFIG_TABLE,
                KeySchema=[{"AttributeName": "config_key", "KeyType": "HASH"}],
                AttributeDefinitions=[{"AttributeName": "config_key", "AttributeType": "S"}],
                BillingMode="PAY_PER_REQUEST",
            ).wait_until_exists()
        _table_ready = True
    except Exception:
        logger.exception("ensure artifact config table failed")


def _default_record() -> dict:
    folders, pid, fid = [], 101, 1
    for spec in DEFAULT_FOLDERS:
        inc, exc = [], []
        for p in spec["include"]:
            inc.append({"pattern_id": pid, "pattern": p, "pattern_type": "include"})
            pid += 1
        for p in spec["exclude"]:
            exc.append({"pattern_id": pid, "pattern": p, "pattern_type": "exclude"})
            pid += 1
        folders.append({
            "folder_id": fid,
            "folder_path": spec["folder_path"],
            "is_enabled": bool(spec["is_enabled"]),
            "include_patterns": inc,
            "exclude_patterns": exc,
        })
        fid += 1
    return {"folders": folders, "next_folder_id": fid, "next_pattern_id": pid}


def _coerce(record: dict) -> dict:
    """Dynamo Decimals -> int, and defensive shaping so a hand-edited row can't crash the API."""
    folders = []
    for f in record.get("folders") or []:
        if not isinstance(f, dict):
            continue
        def _pats(key, ptype):
            out = []
            for p in f.get(key) or []:
                if isinstance(p, dict) and str(p.get("pattern") or "").strip():
                    out.append({
                        "pattern_id": int(p.get("pattern_id") or 0),
                        "pattern": str(p.get("pattern")),
                        "pattern_type": ptype,
                    })
            return out
        # folder_name intentionally NOT projected (updated contract): rows written
        # before the removal may still carry it — dropping it here scrubs every response, and the
        # next _write persists the record without it.
        folders.append({
            "folder_id": int(f.get("folder_id") or 0),
            "folder_path": str(f.get("folder_path") or ""),
            "is_enabled": bool(f.get("is_enabled")),
            "include_patterns": _pats("include_patterns", "include"),
            "exclude_patterns": _pats("exclude_patterns", "exclude"),
        })
    return {
        "folders": folders,
        "next_folder_id": int(record.get("next_folder_id") or 1),
        "next_pattern_id": int(record.get("next_pattern_id") or 101),
    }


def _read_raw() -> dict:
    try:
        _ensure_table()
        item = _table().get_item(Key={"config_key": CONFIG_KEY}).get("Item")
    except Exception:
        logger.exception("read artifact config failed - using defaults")
        item = None
    return _coerce(item) if item else _default_record()


def get_config(force: bool = False) -> dict:
    now = time.time()
    if not force and _cache["data"] is not None and (now - _cache["ts"]) < _CACHE_TTL:
        return _cache["data"]
    data = _read_raw()
    _cache["data"], _cache["ts"] = data, now
    return data


def _write(data: dict, by: str) -> dict:
    _ensure_table()
    item = dict(data)
    item["config_key"] = CONFIG_KEY
    item["updated_by"] = by
    item["updated_at"] = int(time.time())
    _table().put_item(Item=item)
    _cache["data"], _cache["ts"] = data, time.time()
    return data


# ---------------------------------------------------------------------------
# Matching (shared with pattern examples): file NAME only, '*' wildcard,
# case-insensitive, exclude beats include.
# ---------------------------------------------------------------------------
def _matches(file_name: str, pattern: str) -> bool:
    return fnmatchcase(str(file_name or "").lower(), str(pattern or "").strip().lower())


def classify_file(file_name: str, folder: dict):
    """-> (matched_pattern, matched_pattern_type): exclude first, then include, else (None, None)."""
    for p in folder.get("exclude_patterns") or []:
        if _matches(file_name, p["pattern"]):
            return p["pattern"], "exclude"
    for p in folder.get("include_patterns") or []:
        if _matches(file_name, p["pattern"]):
            return p["pattern"], "include"
    return None, None


def _example_name_for(pattern: str, stem: str = "error") -> str:
    """'*.log' -> 'error.log'; 'abc.txt' -> 'abc.txt'; 'temp*' -> 'temperror' -> keep simple."""
    pat = str(pattern or "").strip()
    return pat.replace("*", stem) if "*" in pat else pat


_NO_MATCH_CANDIDATES = ["data.xml", "readme.md", "image.png", "archive.zip", "video.mp4"]


def _pattern_examples(folders: list) -> list:
    """Bottom "Pattern Examples" table: per enabled folder one include-derived and one
    exclude-derived row, plus one no-match row for the first enabled folder. Backend sends only
    file + matched pattern facts; the UI derives the result/reason labels (spec section 6)."""
    examples, no_match_done = [], False
    for folder in folders:
        if not folder.get("is_enabled"):
            continue
        seen_names = set()

        def _add(name):
            if not name or name.lower() in seen_names:
                return
            seen_names.add(name.lower())
            pattern, ptype = classify_file(name, folder)
            examples.append({
                "example_file_name": name,
                "folder_path": folder.get("folder_path") or "",
                "matched_pattern": pattern,
                "matched_pattern_type": ptype,
            })

        if folder.get("include_patterns"):
            _add(_example_name_for(folder["include_patterns"][0]["pattern"]))
        if folder.get("exclude_patterns"):
            _add(_example_name_for(folder["exclude_patterns"][0]["pattern"]))
        if not no_match_done:
            for cand in _NO_MATCH_CANDIDATES:
                if classify_file(cand, folder) == (None, None):
                    _add(cand)
                    no_match_done = True
                    break
    return examples


# ---------------------------------------------------------------------------
# Views
# ---------------------------------------------------------------------------
def _folders_from_rules() -> list | None:
    """Legacy-shape folders DERIVED from the new artifact RULES store (compatibility bridge).

    The admin page now edits /api/artifact-rules, but fielded extensions (<= v2.1.7) still read
    THIS endpoint's folders. Deriving them from the rules makes the admin page the single source
    of truth for every installed extension - no package update needed. (Root cause of the
    "runtime artifacts not detected" report: this store's July test data had the log folder
    enabled with ZERO include patterns - which collects nothing - while the rules store said
    log/** include.) Returns None when the rules store is empty or unreadable; callers then fall
    back to the legacy stored record, so a fresh environment behaves exactly as before.
    """
    try:
        from src.services import artifact_rules
        record = artifact_rules.get_config()
        rules = [r for r in (record.get("rules") or []) if isinstance(r, dict) and r.get("enabled")]
    except Exception:
        logger.exception("artifact rules unavailable - serving the legacy artifact-config store")
        return None
    if not rules:
        return None

    folder_heads: list = []
    seen = set()
    file_excludes: list = []
    file_includes_by_head: dict = {}
    for r in rules:
        rtype = str(r.get("ruleType") or "").upper()
        res = str(r.get("resourceType") or "").upper()
        glob = str(r.get("globPattern") or "").strip().replace("\\", "/")
        if not glob:
            continue
        if res in ("FOLDER", "FOLDER_RECURSIVE") and rtype == "INCLUDE":
            head = glob.strip("/").split("/", 1)[0].replace("*", "").strip()
            key = head.lower()
            if head and key not in seen:
                seen.add(key)
                folder_heads.append(head)
        elif res == "FILE" and rtype == "EXCLUDE":
            base = glob.rstrip("/").split("/")[-1].strip()
            if base and base not in file_excludes:
                file_excludes.append(base)
        elif res == "FILE" and rtype == "INCLUDE":
            # FOLDER-SCOPED file INCLUDE rules ('proc/*.log') NARROW that folder to those name
            # patterns (570-file TD5 field report: a bare '*' include swept whole proc trees).
            # Folder-LESS file includes ('*.txt', '**/x.log') are ADDITIVE hints and must NEVER
            # shrink a folder's coverage — treating them as narrowing re-broke the
            # log/debug.log collection on testgbe the moment any global rule existed.
            parts = [p for p in glob.strip("/").split("/") if p]
            base = parts[-1].strip() if parts else ""
            if not base:
                continue
            head_key = parts[0].replace("*", "").strip().lower() if len(parts) > 1 else ""
            if head_key:
                bucket = file_includes_by_head.setdefault(head_key, [])
                if base not in bucket:
                    bucket.append(base)

    if not folder_heads:
        return None

    folders = []
    for i, head in enumerate(folder_heads):
        pid = 9100 + i * 100
        specific = list(file_includes_by_head.get(head.lower(), []))
        # A folder with NO folder-scoped file include collects everything in it;
        # file-level EXCLUDE rules still win (exclusion_priority).
        include_patterns = specific if specific else ["*"]
        folders.append({
            "folder_id": 9000 + i,
            "folder_path": head,
            "is_enabled": True,
            "include_patterns": [
                {"pattern_id": pid + j, "pattern": p, "pattern_type": "include"}
                for j, p in enumerate(include_patterns)
            ],
            "exclude_patterns": [
                {"pattern_id": pid + 50 + j, "pattern": p, "pattern_type": "exclude"}
                for j, p in enumerate(file_excludes)
            ],
        })
    return folders


def full_view(cfg: dict | None = None, selected_folder_id: int | None = None) -> dict:
    """The complete screen payload (GET response + every action response, spec section 4/5).
    The plain GET (cfg=None) serves folders derived from the artifact RULES store when rules
    exist (see _folders_from_rules); mutation responses keep showing the legacy store they
    just modified."""
    if cfg is None:
        derived = _folders_from_rules()
        cfg = {"folders": derived} if derived is not None else get_config()
    folders = cfg["folders"]
    include_total = sum(len(f["include_patterns"]) for f in folders)
    exclude_total = sum(len(f["exclude_patterns"]) for f in folders)
    enabled = [f for f in folders if f["is_enabled"]]
    if selected_folder_id is None or not any(f["folder_id"] == selected_folder_id for f in folders):
        selected_folder_id = folders[0]["folder_id"] if folders else None
    return {
        "selected_folder_id": selected_folder_id,
        "folders": folders,
        "summary": {
            "total_folders": len(folders),
            "enabled_folders": len(enabled),
            "total_include_patterns": include_total,
            "total_exclude_patterns": exclude_total,
            "included_folders": [f["folder_path"] for f in enabled],
        },
        "rules": dict(RULES),
        "pattern_examples": _pattern_examples(folders),
    }


# ---------------------------------------------------------------------------
# Validation helpers (raise ValueError -> 400; ArtifactConfigNotFound -> 404)
# ---------------------------------------------------------------------------
def _norm_path(path: str) -> str:
    return str(path or "").strip().replace("\\", "/").strip("/").lower()


def _require_folder(cfg: dict, folder_id) -> dict:
    try:
        fid = int(folder_id)
    except (TypeError, ValueError):
        raise ArtifactConfigNotFound(f"Folder {folder_id} not found")
    for f in cfg["folders"]:
        if f["folder_id"] == fid:
            return f
    raise ArtifactConfigNotFound(f"Folder {folder_id} not found")


def _validate_folder_path(cfg: dict, path: str, ignore_folder_id: int | None = None):
    if not str(path or "").strip():
        raise ValueError("Folder path is required")
    norm = _norm_path(path)
    for f in cfg["folders"]:
        if f["folder_id"] != ignore_folder_id and _norm_path(f["folder_path"]) == norm:
            raise ValueError(f"Folder path '{path}' already exists")


def _validate_pattern(folder: dict, ptype: str, pattern: str):
    if ptype not in ("include", "exclude"):
        raise ValueError("pattern_type must be 'include' or 'exclude'")
    value = str(pattern or "").strip()
    if not value:
        raise ValueError("Pattern value should not be empty")
    existing = folder["include_patterns"] if ptype == "include" else folder["exclude_patterns"]
    if any(p["pattern"].strip().lower() == value.lower() for p in existing):
        raise ValueError(f"Pattern '{value}' already exists in {ptype} patterns")
    return value


# ---------------------------------------------------------------------------
# Mutations — each persists and returns (config, selected_folder_id)
# ---------------------------------------------------------------------------
def add_folder(body: dict, by: str = "dashboard"):
    # folder_name in the body is IGNORED per the updated contract — folder_path only.
    cfg = dict(get_config(force=True))
    path = str(body.get("folder_path") or "").strip()
    _validate_folder_path(cfg, path)

    folder = {
        "folder_id": cfg["next_folder_id"],
        "folder_path": path,
        "is_enabled": bool(body.get("is_enabled", True)),
        "include_patterns": [],
        "exclude_patterns": [],
    }
    cfg["next_folder_id"] += 1

    # Initial patterns in the same request (spec 7.1); duplicates within the body are rejected too.
    for ptype, key in (("include", "include_patterns"), ("exclude", "exclude_patterns")):
        raw = body.get(key)
        if raw is None:
            continue
        if not isinstance(raw, list):
            raise ValueError(f"{key} must be an array of strings")
        for entry in raw:
            value = _validate_pattern(folder, ptype, entry)
            folder[key].append({"pattern_id": cfg["next_pattern_id"], "pattern": value,
                                "pattern_type": ptype})
            cfg["next_pattern_id"] += 1

    cfg["folders"] = cfg["folders"] + [folder]
    _write(cfg, by)
    return cfg, folder["folder_id"]


def update_folder(folder_id, body: dict, by: str = "dashboard"):
    # Updates folder_path ONLY (spec 8.2); folder_name in the body is ignored.
    cfg = dict(get_config(force=True))
    folder = _require_folder(cfg, folder_id)
    path = str(body.get("folder_path") or "").strip()
    _validate_folder_path(cfg, path, ignore_folder_id=folder["folder_id"])
    folder["folder_path"] = path
    folder.pop("folder_name", None)   # scrub legacy field from rows written before the removal
    _write(cfg, by)
    return cfg, folder["folder_id"]


def set_folder_status(folder_id, is_enabled, by: str = "dashboard"):
    cfg = dict(get_config(force=True))
    folder = _require_folder(cfg, folder_id)
    if not isinstance(is_enabled, bool):
        raise ValueError("is_enabled must be true or false")
    folder["is_enabled"] = is_enabled
    _write(cfg, by)
    return cfg, folder["folder_id"]


def delete_folder(folder_id, by: str = "dashboard"):
    cfg = dict(get_config(force=True))
    folder = _require_folder(cfg, folder_id)  # patterns live inside the folder -> cascade delete
    cfg["folders"] = [f for f in cfg["folders"] if f["folder_id"] != folder["folder_id"]]
    _write(cfg, by)
    return cfg, cfg["folders"][0]["folder_id"] if cfg["folders"] else None


def add_pattern(folder_id, body: dict, by: str = "dashboard"):
    cfg = dict(get_config(force=True))
    folder = _require_folder(cfg, folder_id)
    ptype = str(body.get("pattern_type") or "").strip().lower()
    value = _validate_pattern(folder, ptype, body.get("pattern"))
    key = "include_patterns" if ptype == "include" else "exclude_patterns"
    folder[key].append({"pattern_id": cfg["next_pattern_id"], "pattern": value,
                        "pattern_type": ptype})
    cfg["next_pattern_id"] += 1
    _write(cfg, by)
    return cfg, folder["folder_id"]


def delete_pattern(folder_id, pattern_id, by: str = "dashboard"):
    cfg = dict(get_config(force=True))
    folder = _require_folder(cfg, folder_id)
    try:
        pid = int(pattern_id)
    except (TypeError, ValueError):
        raise ArtifactConfigNotFound(f"Pattern {pattern_id} not found")
    for key in ("include_patterns", "exclude_patterns"):
        kept = [p for p in folder[key] if p["pattern_id"] != pid]
        if len(kept) != len(folder[key]):
            folder[key] = kept
            _write(cfg, by)
            return cfg, folder["folder_id"]
    raise ArtifactConfigNotFound(f"Pattern {pattern_id} not found in folder {folder_id}")


def reset_to_default(by: str = "dashboard"):
    """Dashboard 'Reset to Default' button — restores the extension's stock collection rules."""
    cfg = _default_record()
    _write(cfg, by)
    return cfg, cfg["folders"][0]["folder_id"] if cfg["folders"] else None
