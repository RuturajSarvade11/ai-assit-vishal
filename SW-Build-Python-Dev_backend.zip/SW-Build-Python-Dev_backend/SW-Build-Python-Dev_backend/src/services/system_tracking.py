"""
src/services/system_tracking.py — System Tracking Configuration (UI contract).

Admin-configurable FILE-CHANGE-TRACKING inclusion list (the "System Configuration"
feature): which project files/folders the extension monitors during build-failure
analysis. One record in `system_tracking{sfx}` holds:

    tracking_patterns: [ { id, status, resource, glob_pattern, description } ]

Contract points (deliberately DIFFERENT from artifact-rules — the UI team specified snake_case
here and a different error shape; do not "unify"):
  - field names: glob_pattern (never "pattern"), status (never "enabled")
  - resource enum: "Folder" | "Folder(Recursive)" | "File" (canonical display strings; input is
    matched case-insensitively and stored canonically — the API stores the FINAL resolved value,
    never the UI's auto-detect state)
  - every mutation returns the complete refreshed tracking_patterns list (no follow-up GET)
  - duplicate = resource + normalized glob_pattern -> DUPLICATE_TRACKING_PATTERN (field glob_pattern)
  - update with no change rejected; unknown id -> 404
  - error shape: {success:false, message, error:{code, field}}  (single field, NOT fieldErrors)

DEFAULTS = the extension's current hardcoded tracking list (work folder + gradle.properties +
settings.gradle.kts) so rollout changes nothing, plus gradle-wrapper.properties present but
DISABLED (design-draft Q1 recommendation: one admin click enables it — never a silent
day-one behavior change).

Glob engine: Python fnmatch (same documented engine as artifact rules); separators normalized
to '/'. Storage pattern identical to the other admin configs (single record, 30s cache).
"""
import re
import time
import uuid
import logging
from fnmatch import translate as _fnmatch_translate

from src.databases.database import get_dynamodb
from src.configurations import config

logger = logging.getLogger(__name__)

TRACKING_TABLE = f"system_tracking{config.DYNAMODB_TABLE_SUFFIX}"
CONFIG_KEY = "file_tracking"         # single global record; future System Config sections get their own keys
_CACHE_TTL = 30

# Canonical resource values per the contract (input matched case-insensitively).
_RESOURCES = {"folder": "Folder", "folder(recursive)": "Folder(Recursive)", "file": "File"}
_MAX_GLOB = 500
_MAX_DESCRIPTION = 500

# DEFAULTS = the extension's shipped inclusion list (FileUtils.isIncludedForTracking)
# expressed as patterns, so rollout alone changes NOTHING: the work/ tree,
# the gradle/ folder (which already contains gradle-wrapper.properties — it is tracked TODAY),
# and root-level gradle build/settings/properties files. The explicit wrapper entry exists so
# admins SEE it listed; it is enabled because gradle/** already tracks it anyway.
DEFAULT_PATTERNS = [
    {"status": True, "resource": "Folder(Recursive)", "glob_pattern": "work/**",
     "description": "Entire work directory"},
    {"status": True, "resource": "Folder(Recursive)", "glob_pattern": "gradle/**",
     "description": "Gradle directory (wrapper files)"},
    {"status": True, "resource": "File", "glob_pattern": "gradle.properties",
     "description": "Gradle properties file (root level)"},
    {"status": True, "resource": "File", "glob_pattern": "settings.gradle.kts",
     "description": "Settings file (root level)"},
    {"status": True, "resource": "File", "glob_pattern": "*.gradle.kts",
     "description": "Root-level Gradle Kotlin build files"},
    {"status": True, "resource": "File", "glob_pattern": "*.gradle",
     "description": "Root-level Gradle build files"},
    {"status": True, "resource": "File", "glob_pattern": "**/gradle-wrapper.properties",
     "description": "Gradle wrapper properties"},
]

_cache = {"data": None, "ts": 0.0}
_table_ready = False


class TrackingPatternError(Exception):
    """Contract error: route serializes {code, field} at http_status."""

    def __init__(self, message: str, code: str = "TRACKING_PATTERN_VALIDATION_ERROR",
                 http_status: int = 400, field: str | None = None):
        super().__init__(message)
        self.message = message
        self.code = code
        self.http_status = http_status
        self.field = field


def _table():
    return get_dynamodb().Table(TRACKING_TABLE)


def _ensure_table():
    global _table_ready
    if _table_ready:
        return
    try:
        ddb = get_dynamodb()
        if TRACKING_TABLE not in [t.name for t in ddb.tables.all()]:
            logger.info("creating system tracking table %s", TRACKING_TABLE)
            ddb.create_table(
                TableName=TRACKING_TABLE,
                KeySchema=[{"AttributeName": "config_key", "KeyType": "HASH"}],
                AttributeDefinitions=[{"AttributeName": "config_key", "AttributeType": "S"}],
                BillingMode="PAY_PER_REQUEST",
            ).wait_until_exists()
        _table_ready = True
    except Exception:
        logger.exception("ensure system tracking table failed")


def _new_id() -> str:
    return uuid.uuid4().hex[:8]      # contract example: "7af8c62d"


def _norm_glob(pattern: str) -> str:
    return str(pattern or "").strip().replace("\\", "/").lower()


def _default_record() -> dict:
    return {"tracking_patterns": [{"id": _new_id(), **p} for p in DEFAULT_PATTERNS]}


def _read_raw() -> dict:
    try:
        _ensure_table()
        item = _table().get_item(Key={"config_key": CONFIG_KEY}).get("Item")
    except Exception:
        logger.exception("read system tracking failed - serving defaults")
        item = None
    if not item or not isinstance(item.get("tracking_patterns"), list):
        return _default_record()
    return {"tracking_patterns": [p for p in item["tracking_patterns"] if isinstance(p, dict)]}


def get_config(force: bool = False) -> dict:
    now = time.time()
    if not force and _cache["data"] is not None and (now - _cache["ts"]) < _CACHE_TTL:
        return _cache["data"]
    data = _read_raw()
    _cache["data"], _cache["ts"] = data, now
    return data


def _write(record: dict) -> dict:
    _ensure_table()
    _table().put_item(Item={"config_key": CONFIG_KEY, **record})
    _cache["data"], _cache["ts"] = record, time.time()
    return record


def full_view(record: dict | None = None) -> dict:
    record = record or get_config()
    return {"tracking_patterns": [dict(p) for p in record.get("tracking_patterns", [])]}


def _validate_body(body: dict) -> dict:
    """Normalize + validate one pattern payload. Raises with the FIRST offending field (the
    contract's error shape carries a single field, not a map)."""
    body = body if isinstance(body, dict) else {}

    resource_raw = str(body.get("resource") or "").strip()
    resource = _RESOURCES.get(resource_raw.lower().replace(" ", ""))
    if not resource:
        raise TrackingPatternError(
            "Resource must be Folder, Folder(Recursive), or File.", field="resource")

    glob_pattern = str(body.get("glob_pattern") or "").strip().replace("\\", "/")
    if not glob_pattern:
        raise TrackingPatternError("Glob pattern is required.", field="glob_pattern")
    if len(glob_pattern) > _MAX_GLOB:
        raise TrackingPatternError(
            f"Glob pattern must not exceed {_MAX_GLOB} characters.", field="glob_pattern")
    try:
        re.compile(_fnmatch_translate(glob_pattern))
    except re.error:
        raise TrackingPatternError("Invalid glob pattern.",
                                   code="INVALID_GLOB_PATTERN", field="glob_pattern")

    status = body.get("status")
    if not isinstance(status, bool):
        raise TrackingPatternError("Status must be true or false.", field="status")

    description = body.get("description")
    if description is not None:
        description = str(description).strip()
        if len(description) > _MAX_DESCRIPTION:
            raise TrackingPatternError(
                f"Description must not exceed {_MAX_DESCRIPTION} characters.", field="description")
        if description == "":
            description = None

    return {"status": status, "resource": resource,
            "glob_pattern": glob_pattern, "description": description}


def _assert_not_duplicate(record: dict, fields: dict, ignore_id: str | None = None) -> None:
    key = (fields["resource"], _norm_glob(fields["glob_pattern"]))
    for p in record.get("tracking_patterns", []):
        if ignore_id and p.get("id") == ignore_id:
            continue
        if (p.get("resource"), _norm_glob(p.get("glob_pattern"))) == key:
            raise TrackingPatternError(
                "A tracking pattern with the same resource and glob pattern already exists.",
                code="DUPLICATE_TRACKING_PATTERN", http_status=409, field="glob_pattern")


def _find(record: dict, pattern_id: str) -> dict:
    for p in record.get("tracking_patterns", []):
        if p.get("id") == str(pattern_id or "").strip():
            return p
    raise TrackingPatternError("Tracking pattern not found.",
                               code="TRACKING_PATTERN_NOT_FOUND", http_status=404)


def add_pattern(body: dict) -> dict:
    fields = _validate_body(body)
    record = dict(get_config(force=True))
    _assert_not_duplicate(record, fields)
    record["tracking_patterns"] = list(record.get("tracking_patterns", [])) + [
        {"id": _new_id(), **fields}]
    return _write(record)


def update_pattern(pattern_id: str, body: dict) -> dict:
    fields = _validate_body(body)
    record = dict(get_config(force=True))
    pattern = _find(record, pattern_id)
    if all(pattern.get(k) == v for k, v in fields.items()):
        raise TrackingPatternError("No changes were detected.",
                                   code="TRACKING_PATTERN_NO_CHANGES", http_status=409)
    _assert_not_duplicate(record, fields, ignore_id=pattern.get("id"))
    pattern.update(fields)
    return _write(record)


def set_pattern_status(pattern_id: str, status) -> dict:
    if not isinstance(status, bool):
        raise TrackingPatternError("Status must be true or false.", field="status")
    record = dict(get_config(force=True))
    pattern = _find(record, pattern_id)
    if bool(pattern.get("status")) == status:
        raise TrackingPatternError("No changes were detected.",
                                   code="TRACKING_PATTERN_NO_CHANGES", http_status=409)
    pattern["status"] = status
    return _write(record)


def delete_pattern(pattern_id: str) -> dict:
    record = dict(get_config(force=True))
    pattern = _find(record, pattern_id)   # 404 if unknown
    record["tracking_patterns"] = [
        p for p in record.get("tracking_patterns", []) if p.get("id") != pattern.get("id")]
    return _write(record)


def reset_defaults() -> dict:
    return _write(_default_record())
