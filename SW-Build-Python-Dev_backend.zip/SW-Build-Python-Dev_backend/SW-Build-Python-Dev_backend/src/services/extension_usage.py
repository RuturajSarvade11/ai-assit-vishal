"""
src/services/extension_usage.py — extension adoption and usage KPIs.

How identity is handled, which replaced an earlier design: the developer login is never stored
or encrypted; only a key derived from it is used, and only to tell whether two records belong
to the same person. The ID is never displayed on the dashboard.

So there is no encrypted login here, no reveal, no masked form and no admin capture toggle. All
of those existed and have been removed. What remains is a key the EXTENSION derives on the
developer's own machine and sends in place of the login, which means the login is not stored,
not displayed, and never even received.

The key answers exactly one question - is this the same person as that record - so a developer
working on two machines is counted once rather than twice. It answers nothing else, by design.
There is no path from it back to a person for anyone, including us.

Everything the screen shows is a count:

  1. installations, builds, versions, project coverage  - keyed on the id VS Code creates per
     installation, which is not derived from any person
  2. whether the assistant is helping                   - from the recommendation records the
     system already writes; no new collection at all
  3. how many distinct PEOPLE are active                - the key, as counts only

Everything here is fail-open. A KPI is a nice-to-have; it must never break an upload.
"""
import logging
import os
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta, UTC

logger = logging.getLogger(__name__)

_KEY_PREFIX = "ext#"
DEFAULT_WINDOW_DAYS = 30


def _scan_budget_sec() -> float:
    """Wall-clock ceiling for the KPI scan. Well under the gateway timeout, so the endpoint
    always answers - a partial answer that fills the cache beats a 504 that never does.

    Raised from 20s after a live table of ~34,000 rows took 18.7s to read: the budget was cutting
    the scan short, and because usage rows are a tiny fraction of the table and a scan returns
    them in no particular order, whole categories went missing. The screen then reported "no
    installation has reported yet" about data that was sitting in the table."""
    try:
        return max(2.0, float(os.getenv("EXT_USAGE_SCAN_BUDGET_SEC", "45")))
    except (TypeError, ValueError):
        return 20.0


def _scan_cache_ttl_sec() -> int:
    """KPIs do not need to be second-fresh, and the scan is expensive, so this window is much
    longer than the dashboard default."""
    try:
        return max(30, int(os.getenv("EXT_USAGE_CACHE_TTL_SEC", "600")))
    except (TypeError, ValueError):
        return 600


def kpi_rows() -> dict:
    """The one bounded, cached pass over the table that every block below reads from.

    This endpoint first shipped with three separate unbounded scans of the SAME table - the
    EXTUSAGE, FEEDBACK and RECOMMEND rows each got their own. DynamoDB applies a scan filter
    after reading, so all three read everything, and on UAT the request returned 504. Because
    it died before finishing, the cache never filled and the timeout then repeated on every
    later call. One pass, bounded and cached, fixes both halves of that.
    """
    from src.utils import ttl_cache
    from src.utils.project_details import scan_kpi_rows
    return ttl_cache.get_or_compute(
        ("ext-usage-kpi-rows",),
        lambda: scan_kpi_rows(budget_sec=_scan_budget_sec()),
        deep_copy=False,
        ttl_override=_scan_cache_ttl_sec(),
    )


# ----------------------------------------------------------------------------- identity

def _norm(key: str) -> str:
    return str(key or "").strip().lower()


def usage_key(raw: str) -> str:
    """The stored identifier for one developer.

    The extension derives this on its own machine from the local login and sends it in place of
    the login, so the login is never transmitted, never stored and never displayed. What arrives
    is already an identifier: a fixed-length value that recognises the same person twice and says
    nothing about who they are.

    It carries the ext# prefix so it can never be confused with the dashboard sign-in values,
    which live in a different space entirely.

    Its only job is not double-counting. There is deliberately no way back from it to a person -
    not for an administrator, not for us, not for anyone holding the database.
    """
    value = _norm(raw)
    if not value:
        return ""
    return value if value.startswith(_KEY_PREFIX) else _KEY_PREFIX + value


# ----------------------------------------------------------------------------- capture

def record_build(install_id: str, project_name: str = "", ext_version: str = "",
                 env_kind: str = "", developer_key: str = "", failed: bool = False) -> bool:
    """One analysed build. Called from the upload path, so it must never raise and never slow
    the caller down noticeably."""
    try:
        from src.utils.project_details import save_extension_usage
        return save_extension_usage(
            install_id=install_id, project_name=project_name, ext_version=ext_version,
            env_kind=env_kind, dev_key=usage_key(developer_key), failed=failed,
        )
    except Exception:
        logger.exception("record_build failed - usage not counted (upload unaffected)")
        return False


def record_report(install_id: str, project_name: str = "", ext_version: str = "",
                  env_kind: str = "", developer_key: str = "",
                  recommendations: int = 0) -> bool:
    """One failure sent up for help, and whether anything came back.

    The unique key is tracked through what it does: how many times the person uploads, and how
    often a recommendation came back. Those are separate facts and this is the only place both
    are known - the failure report is what asks, and its answer is what returns. It deliberately
    does NOT add a
    build: a build is a fix that was uploaded, and counting a question as a build would inflate
    the adoption figure with the very events that were unsuccessful.
    """
    try:
        from src.utils.project_details import save_extension_usage
        return save_extension_usage(
            install_id=install_id, project_name=project_name, ext_version=ext_version,
            env_kind=env_kind, dev_key=usage_key(developer_key),
            builds=0, uploads=1, recommended=1 if int(recommendations or 0) > 0 else 0,
            answered=int(recommendations or 0),
        )
    except Exception:
        logger.exception("record_report failed - usage not counted (report unaffected)")
        return False


def record_install(install_id: str, ext_version: str = "", env_kind: str = "",
                   developer_key: str = "") -> bool:
    """An installation announcing itself, with no build attached.

    Without this, "who installed it" cannot be answered at all: a usage record is only written
    when a build completes, so somebody who installs the extension and never builds is
    completely invisible - and that is precisely the rollout case worth seeing. The "went quiet"
    filter has the same blind spot; it can find people who started and stopped, never people who
    never started.

    It writes ONLY the profile row, so `builds` stays 0 and the figure reads honestly as
    installed-but-never-used rather than inflating the build counts.

    This is NOT a heartbeat. The extension sends it once per installed version, so it says "this
    installation exists and is on version X" and nothing about whether anyone is at the machine.
    "We count builds, not presence" still holds.
    """
    try:
        from src.utils.project_details import save_extension_install
        return save_extension_install(
            install_id=install_id, ext_version=ext_version, env_kind=env_kind,
            dev_key=usage_key(developer_key),
        )
    except Exception:
        logger.exception("record_install failed - installation not counted")
        return False


def record_build_seen(install_id: str, project_name: str = "", ext_version: str = "",
                      env_kind: str = "", developer_key: str = "", failed: bool = False,
                      issues: int = 0, build: dict | None = None) -> bool:
    """Every build the extension parsed, success or failure (the number of builds that
    happened and the number that failed). Adds NOTHING to `builds`, which stays the count of fix
    uploads, so the older figures keep their meaning.

    `build` is the optional record of THIS build - {buildId, startedAt, finishedAt, durationSec,
    taskName} - which the card drill-down lists one by one. It is stored only when it carries a
    build id; an extension that sends none is still counted, just not listable."""
    try:
        from src.utils.project_details import save_extension_usage
        ok = save_extension_usage(
            install_id=install_id, project_name=project_name, ext_version=ext_version,
            env_kind=env_kind, dev_key=usage_key(developer_key),
            builds=0, seen_builds=1, seen_failures=1 if failed else 0,
            # The errors captured from a failed build; bounded so one runaway report cannot
            # distort the total.
            seen_issues=max(0, min(int(issues or 0), 500)) if failed else 0,
        )
    except Exception:
        logger.exception("record_build_seen failed - build not counted (build unaffected)")
        return False
    detail = build if isinstance(build, dict) else {}
    if str(detail.get("buildId") or "").strip():
        try:
            from src.utils.project_details import save_extension_build
            save_extension_build(
                install_id=install_id, build_id=str(detail.get("buildId") or ""),
                project_name=project_name, failed=failed,
                started_at=str(detail.get("startedAt") or ""),
                finished_at=str(detail.get("finishedAt") or ""),
                duration_sec=detail.get("durationSec"),
                task_name=str(detail.get("taskName") or ""),
                issues=int(issues or 0) if failed else 0, ext_version=ext_version,
            )
        except Exception:
            logger.exception("record_build_seen: build record not stored (build still counted)")
    return ok


# ----------------------------------------------------------------------------- scope

def _group_filter(rows: list, group: str, project_field: str = "project_name") -> list:
    """Keep the rows whose project resolves to `group` (the project-group filter).
    Uses the same resolution the dashboard cards and the recommendation scope use, so
    the three screens can never disagree about which group a project is in. Empty or ALL = no
    filter. Profile rows carry no project and are kept; they are counted per installation."""
    wanted = str(group or "").strip()
    if not wanted or wanted.upper() == "ALL":
        return rows
    from src.services.project_groups import build_group_map
    names = {str(r.get(project_field) or "").strip() for r in rows if r.get(project_field)}
    gmap = {k.lower(): v for k, v in build_group_map(names).items()}
    out = []
    for r in rows:
        proj = str(r.get(project_field) or "").strip().lower()
        if not proj:
            out.append(r)
            continue
        if gmap.get(proj) == wanted:
            out.append(r)
    return out


def _period(from_date: str, project: str, rows: list) -> dict:
    """The five numbers the page answers for the selected period:
    active users, builds, builds failed, issues captured, recommendation requests. Overall
    counts, never per person - per-user rows cannot be acted on because the user is not
    identified. Everything is read from the daily usage rows already written."""
    from src.utils.project_details import EXTUSAGE_PROFILE_SK
    proj = str(project or "").strip().lower()
    keys_by_install = {str(r.get("PK") or ""): str(r.get("dev_key") or "")
                       for r in rows if r.get("SK") == EXTUSAGE_PROFILE_SK and r.get("dev_key")}
    people, installs = set(), set()
    seen_builds = seen_failures = issues = requests = answered = 0
    build_reports = False
    for r in rows:
        if r.get("SK") == EXTUSAGE_PROFILE_SK:
            continue
        if str(r.get("use_date") or "") < from_date:
            continue
        if proj and proj != "all" and str(r.get("project_name") or "").strip().lower() != proj:
            continue
        install = str(r.get("PK") or "")
        installs.add(install)
        if keys_by_install.get(install):
            people.add(keys_by_install[install])
        sb, sf = int(r.get("seen_builds") or 0), int(r.get("seen_failures") or 0)
        if sb or sf:
            build_reports = True
        seen_builds += sb
        seen_failures += sf
        issues += int(r.get("builds") or 0)        # a captured failure, fixed and uploaded
        requests += int(r.get("uploads") or 0)     # a failure sent up for a recommendation
        answered += int(r.get("recommended") or 0)
    # One person on two machines is one user. Installations that sent no key are still users,
    # just ones the key cannot merge - so they are added as machines rather than dropped.
    unkeyed = sum(1 for i in installs if not keys_by_install.get(i))
    return {
        "active_users": len(people) + unkeyed,
        "active_users_basis": "people" if people else "installations",
        # None, not 0, until an extension that reports build outcomes has spoken: an older
        # fleet reads as "not reported yet", never as "no builds".
        "builds": seen_builds if build_reports else None,
        "builds_failed": seen_failures if build_reports else None,
        "issues_captured": issues,
        "recommendation_requests": requests,
        "recommendation_answered": answered,
    }


# ------------------------------------------------------------------------------------ the page
# What the Extension Usage page shows, in the words on the screen and the counters behind them:
#
#   Active Users             distinct people (usage key) with any activity; an installation that
#                            sends no key counts as one user, because it cannot be merged
#   Total Builds             seen_builds    - every build the extension parsed, green or red
#   Failed Builds            seen_failures  - builds that ended with errors
#   Issues Captured          seen_issues    - the errors captured from those failed builds
#   Uploads                  builds         - fixes confirmed and uploaded (one per /final-build)
#   Recommendation Requests  uploads        - failures sent up for a recommendation
#
# The last two counters carry historical names: `builds` was the first thing ever counted (a fix
# upload) and `uploads` is the failure REPORT being uploaded. The names on the screen are the
# meaning; the counters keep their names so stored rows need no migration.
_METRICS = (
    ("total_builds", "seen_builds"), ("failed_builds", "seen_failures"), ("issues_captured", "seen_issues"),
    ("uploads", "builds"), ("recommendation_requests", "uploads"),
)
# Reported only by extensions from 2.3.12 on; until one has spoken these are unknown, not zero.
_BUILD_METRICS = ("total_builds", "failed_builds", "issues_captured")


def _window_totals(rows: list, first: str, last: str, project: str) -> dict:
    """Totals and the per-day series for one date window [first, last], both inclusive."""
    from src.utils.project_details import EXTUSAGE_PROFILE_SK
    proj = str(project or "").strip().lower()
    keys = {str(r.get("PK") or ""): str(r.get("dev_key") or "")
            for r in rows if r.get("SK") == EXTUSAGE_PROFILE_SK and r.get("dev_key")}
    totals = {name: 0 for name, _ in _METRICS}
    totals["answered"] = 0
    users, per_day = set(), {}
    reported = False
    for r in rows:
        if r.get("SK") == EXTUSAGE_PROFILE_SK:
            continue
        day = str(r.get("use_date") or "")
        if not (first <= day <= last):
            continue
        if proj and proj != "all" and str(r.get("project_name") or "").strip().lower() != proj:
            continue
        install = str(r.get("PK") or "")
        user = keys.get(install) or ("install:" + install)
        users.add(user)
        slot = per_day.setdefault(day, {"users": set(), **{name: 0 for name, _ in _METRICS}})
        slot["users"].add(user)
        for name, field in _METRICS:
            n = int(r.get(field) or 0)
            totals[name] += n
            slot[name] += n
        totals["answered"] += int(r.get("recommended") or 0)
        if any(int(r.get(f) or 0) for f in ("seen_builds", "seen_failures", "seen_issues")):
            reported = True
    totals["active_users"] = len(users)
    return {"totals": totals, "per_day": per_day, "builds_reported": reported}


def _change(current, previous):
    """Percent change against the previous period. None when there is nothing to compare with -
    'up 100%' from zero would be a number without a meaning."""
    if current is None or previous in (None, 0):
        return None
    return round(100.0 * (current - previous) / previous, 1)


def _summary(days: int, from_date: str, to_date: str, project: str, rows: list) -> dict:
    """The six cards, the trend and the insights of the page in one block."""
    start = datetime.strptime(from_date, "%Y-%m-%d")
    prev_first = (start - timedelta(days=days)).strftime("%Y-%m-%d")
    prev_last = (start - timedelta(days=1)).strftime("%Y-%m-%d")
    cur = _window_totals(rows, from_date, to_date, project)
    prev = _window_totals(rows, prev_first, prev_last, project)
    # Daily rows are kept for a limited time; a previous period that reaches past it is not
    # comparable, and saying so is better than comparing against a half-empty window.
    try:
        from src.utils.project_details import _EXTUSAGE_DETAIL_RETENTION_DAYS as keep_days
    except Exception:
        keep_days = 90
    comparable = (2 * days) <= int(keep_days)

    def card(name):
        value, before = cur["totals"][name], prev["totals"][name]
        if name in _BUILD_METRICS and not cur["builds_reported"]:
            return {"value": None, "previous": None, "change_percent": None}
        if name in _BUILD_METRICS and not prev["builds_reported"]:
            before = None
        return {"value": value, "previous": before if comparable else None,
                "change_percent": _change(value, before) if comparable else None}

    names = ["active_users"] + [name for name, _ in _METRICS]
    cards = {name: card(name) for name in names}

    trend = []
    for offset in range(days):
        day = (start + timedelta(days=offset)).strftime("%Y-%m-%d")
        slot = cur["per_day"].get(day)
        point = {"date": day, "active_users": len(slot["users"]) if slot else 0}
        for name, _ in _METRICS:
            value = slot[name] if slot else 0
            point[name] = None if (name in _BUILD_METRICS and not cur["builds_reported"]) else value
        trend.append(point)

    builds, failed = cards["total_builds"]["value"], cards["failed_builds"]["value"]
    requests = cards["recommendation_requests"]["value"] or 0
    return {
        "cards": cards,
        "trend": trend,
        "builds_reported": cur["builds_reported"],
        "comparison": {"from": prev_first, "to": prev_last, "available": comparable},
        "insights": {
            "active_users_change_percent": cards["active_users"]["change_percent"],
            "total_builds": builds,
            "failed_builds": failed,
            "failed_build_rate_percent": _rate(failed, builds) if builds else None,
            "recommendation_requests": requests,
            "recommendation_answered": cur["totals"]["answered"],
            "answer_rate_percent": _rate(cur["totals"]["answered"], requests),
        },
    }


# ----------------------------------------------------------------------------- KPIs

def _window(days: int):
    days = max(1, min(int(days or DEFAULT_WINDOW_DAYS), 365))
    to_dt = datetime.now(UTC)
    from_dt = to_dt - timedelta(days=days - 1)
    return days, from_dt.strftime("%Y-%m-%d"), to_dt.strftime("%Y-%m-%d")


def _rate(hit: int, total: int):
    return round(100.0 * hit / total, 1) if total else None


def _adoption(days: int, from_date: str, project: str, rows: list,
              partial: bool = False) -> dict:
    """Installations, activity and version spread. Empty until a build reaches us from an
    extension new enough to send its installation id - reported as not-yet-tracking rather
    than as zero, so an old fleet never reads as "nobody is using it"."""
    from src.utils.project_details import EXTUSAGE_PROFILE_SK
    if not rows:
        # An unfinished scan is NOT the same as an empty table, and saying "nothing has reported"
        # about data we simply did not reach is the worst answer available - it reads as a
        # finding rather than as a gap, and it sent us looking for a fault in the extension when
        # the rows were sitting in the table all along.
        return {"tracking_started": False, "installations_known": 0, "never_built": 0,
                "active_installs": 0, "active_this_week": 0,
                "active_today": 0, "builds_analysed": 0, "projects_covered": 0,
                "versions": [], "daily": [],
                "note": ("The full history could not be read within the time allowed for this "
                         "request, so these figures are not complete. Reload in a moment, or "
                         "raise EXT_USAGE_SCAN_BUDGET_SEC if it persists."
                         if partial else
                         "No installation has reported yet. Adoption figures appear once the "
                         "extension version that sends them has been handed out.")}

    today = datetime.now(UTC).strftime("%Y-%m-%d")
    week_from = (datetime.now(UTC) - timedelta(days=6)).strftime("%Y-%m-%d")
    proj = str(project or "").strip().lower()

    per_day = defaultdict(lambda: {"installs": set(), "builds": 0, "failures": 0})
    installs, week, day_installs, projects, builds = set(), set(), set(), set(), 0
    for r in rows:
        if r.get("SK") == EXTUSAGE_PROFILE_SK:
            continue
        date = str(r.get("use_date") or "")
        if date < from_date:
            continue
        row_project = str(r.get("project_name") or "")
        if proj and proj != "all" and row_project != proj:
            continue
        install = str(r.get("PK") or "")
        count = int(r.get("builds") or 0)
        installs.add(install)
        projects.add(row_project)
        builds += count
        per_day[date]["installs"].add(install)
        per_day[date]["builds"] += count
        per_day[date]["failures"] += int(r.get("failures") or 0)
        if date >= week_from:
            week.add(install)
        if date == today:
            day_installs.add(install)

    profiles = [r for r in rows if r.get("SK") == EXTUSAGE_PROFILE_SK]
    versions = Counter(str(r.get("ext_version") or "unknown") for r in profiles)
    # Every installation that has ever announced itself, whether or not it has built. The
    # difference between this and active_installs IS the rollout problem, so it is reported
    # rather than left to be worked out.
    known = {str(r.get("PK") or "") for r in profiles}
    never_built = len(known - installs)
    return {
        "tracking_started": True,
        "installations_known": len(known),
        "never_built": never_built,
        "active_installs": len(installs),
        "active_this_week": len(week),
        "active_today": len(day_installs),
        "builds_analysed": builds,
        "projects_covered": len(projects),
        "versions": [{"version": v, "installs": n} for v, n in versions.most_common()],
        # Every series the chart can offer, so the admin picks what to look at rather than
        # being given one fixed view. Days with no activity are absent by design: the storage
        # only writes a row when a build happens, and inventing zero-rows here would be
        # inventing data.
        "daily": [{"date": d, "installs": len(v["installs"]), "builds": v["builds"],
                   "failures": v["failures"]}
                  for d, v in sorted(per_day.items())],
    }


def _value(from_date: str, to_date: str, project: str, group: str,
           votes: list, outcomes: list, traces: list) -> dict:
    """Whether the assistant is doing its job. Every number here comes from records the system
    already writes - no name, no login, no installation id is involved.

    The answer rate and the repeat rate are computed from TRACE rows, one per recommendation
    request. That is deliberate and it corrects two wrong numbers:

      * Answer rate was totalRecommended / totalErrors from the dashboard graph. Those count
        different things - recommended_count is how many times a STORED FIX was later
        recommended to others, while error_count is stored errors - so the ratio was not a rate
        at all and read 484.8% on UAT. A trace is one failure that asked for a recommendation,
        and shown_request_ids says whether it got one, so the two sides finally match.

      * Repeating failures counted signatures across CANDIDATE rows. One failure writes a row
        per candidate, all carrying the same signature, so every signature trivially appeared
        more than once and the number sat at 100%. Counting distinct TRACES per signature asks
        the real question: did this error come back on a different occasion.
    """
    proj = str(project or "").strip().lower()

    def _in_scope(row, date_field="created_date"):
        if proj and proj != "all" and str(row.get("project_name") or "").strip().lower() != proj:
            return False
        return str(row.get(date_field) or "")[:10] >= from_date

    # ---- answer rate, from traces
    answered = failures = 0
    for t in traces:
        if not _in_scope(t):
            continue
        failures += 1
        if [r for r in (t.get("shown_request_ids") or []) if str(r).strip()]:
            answered += 1

    # ---- votes
    helpful = not_helpful = 0
    for v in votes:
        if not _in_scope(v):
            continue
        if v.get("is_helpful") is True:
            helpful += 1
        elif v.get("is_helpful") is False:
            not_helpful += 1

    # ---- fixes confirmed by a later green build on the same task
    fixed = 0
    for o in outcomes:
        if not _in_scope(o):
            continue
        if str(o.get("outcome_type") or "") == "success_correlated":
            fixed += 1

    # ---- repeating failures, counted as distinct OCCASIONS per signature
    occasions = defaultdict(set)
    for t in traces:
        if not _in_scope(t):
            continue
        trace_id = str(t.get("trace_id") or t.get("SK") or "")
        for h in (t.get("query_signature_hashes") or []):
            if str(h).strip():
                occasions[f"{t.get('project_name')}|{h}"].add(trace_id)
    distinct = len(occasions)
    repeats = sum(1 for seen in occasions.values() if len(seen) > 1)

    return {
        "failures": failures,
        "answered": answered,
        "answer_rate_percent": _rate(answered, failures),
        "helpful": helpful,
        "not_helpful": not_helpful,
        "votes": helpful + not_helpful,
        "helpful_rate_percent": _rate(helpful, helpful + not_helpful),
        "fixed_after_recommendation": fixed,
        "distinct_failure_signatures": distinct,
        "repeating_failure_signatures": repeats,
        "repeat_rate_percent": _rate(repeats, distinct),
    }


def _active_people(from_date: str, rows: list) -> dict:
    """How many DISTINCT people, not how many machines.

    The question is "how many users are actively using the
    application", never who they are - so this returns counts only. The key is what makes the
    count distinct: one person on two machines is one person, which a per-installation count
    cannot express.

    Installations with no key are still counted as installations; they simply cannot contribute
    to the people count, and saying so is better than guessing at a number.
    """
    from src.utils.project_details import EXTUSAGE_PROFILE_SK

    keys_by_install = {}
    for r in rows:
        if r.get("SK") == EXTUSAGE_PROFILE_SK and r.get("dev_key"):
            keys_by_install[str(r.get("PK") or "")] = str(r["dev_key"])

    known, active, machines_per_person = set(keys_by_install.values()), set(), {}
    for r in rows:
        if r.get("SK") == EXTUSAGE_PROFILE_SK:
            key = keys_by_install.get(str(r.get("PK") or ""))
            if key:
                machines_per_person[key] = machines_per_person.get(key, 0) + 1
            continue
        if str(r.get("use_date") or "") < from_date:
            continue
        key = keys_by_install.get(str(r.get("PK") or ""))
        if key:
            active.add(key)

    return {
        "people_known": len(known),
        "people_active": len(active),
        "installs_without_key": sum(
            1 for r in rows
            if r.get("SK") == EXTUSAGE_PROFILE_SK and not r.get("dev_key")),
        "max_machines_per_person": max(machines_per_person.values()) if machines_per_person else 0,
        "rows": _people_rows(from_date, rows, keys_by_install),
    }


def _people_rows(from_date: str, rows: list, keys_by_install: dict) -> list:
    """One line per person: what they did, never who they are.

    The unique identifier is tracked through what it does - how many times the person uploads,
    and how often a recommendation came back - while the
    identifier itself must not appear on the dashboard. Both hold here: the key groups the
    rows, and then it is dropped. What leaves this function is a position number and a set of
    counts, which is not enough to name anybody.

    The line number is assigned by first appearance rather than by activity, so a person keeps
    the same line as the table is refreshed. Ordering by "most active" would renumber everybody
    the moment somebody ran a build, and a table whose rows change identity between two looks
    cannot be read across a period at all. It is a position on a list and nothing more - nothing
    stores it, and it means nothing outside this one response.
    """
    from src.utils.project_details import EXTUSAGE_PROFILE_SK

    people: dict = {}

    def _slot(key):
        return people.setdefault(key, {
            "machines": 0, "projects": set(), "active_days": set(),
            "builds": 0, "failures": 0, "uploads": 0, "recommended": 0,
            "first_seen": "", "last_seen": "",
        })

    for r in rows:
        key = keys_by_install.get(str(r.get("PK") or ""))
        if not key:
            continue
        person = _slot(key)
        if r.get("SK") == EXTUSAGE_PROFILE_SK:
            person["machines"] += 1
            first, last = str(r.get("first_seen") or ""), str(r.get("last_seen") or "")
            if first and (not person["first_seen"] or first < person["first_seen"]):
                person["first_seen"] = first
            if last > person["last_seen"]:
                person["last_seen"] = last
            continue
        day = str(r.get("use_date") or "")
        if day < from_date:
            # Outside the chosen period. The person still exists - their profile row above put
            # them in the table - but nothing they did before the window may be counted into it,
            # or the totals stop matching the period the screen says it is showing.
            continue
        person["active_days"].add(day)
        if r.get("project_name"):
            person["projects"].add(str(r["project_name"]))
        for field in ("builds", "failures", "uploads", "recommended"):
            person[field] += int(r.get(field) or 0)

    ordered = sorted(people.items(), key=lambda kv: (kv[1]["first_seen"] or "9999", kv[0]))
    out = []
    for position, (_key, person) in enumerate(ordered, start=1):
        out.append({
            # A line number, not a name. Calling it "Person 1" made a position on a list read
            # like a label the system had assigned to somebody and kept.
            "line": position,
            "machines": person["machines"],
            "projects": len(person["projects"]),
            "active_days": len(person["active_days"]),
            "uploads": person["uploads"],
            "recommended": person["recommended"],
            "builds": person["builds"],
            "failures": person["failures"],
            "first_seen": person["first_seen"][:10],
            "last_seen": person["last_seen"][:10],
            "active_in_period": bool(person["active_days"]),
        })
    return out


def compute_kpis(days: int = DEFAULT_WINDOW_DAYS, project: str = "", group: str = "",
                 refresh: bool = False) -> dict:
    """The whole tab in one call. Each block degrades on its own: a failure in one never
    empties the others."""
    days, from_date, to_date = _window(days)
    project = str(project or "").strip().lower()
    group = str(group or "").strip()
    if refresh:
        # The Refresh button: read the table again instead of answering from the cached pass.
        try:
            from src.utils import ttl_cache
            ttl_cache.invalidate_prefix("ext-usage-kpi-rows")
        except Exception:
            logger.exception("[ext-usage] cache refresh failed - serving the cached pass")

    def _safe(fn, fallback):
        try:
            return fn()
        except Exception:
            logger.exception("[ext-usage] block failed - returned as unavailable")
            return fallback

    # ONE bounded pass, cached for a long window. This endpoint first shipped with three
    # separate unbounded scans of the same table and returned 504 on UAT - and because the
    # request died before the cache could be filled, the timeout then repeated on every call.
    # The scan is deliberately deep-copy-free: these rows are only read here.
    rows = _safe(kpi_rows, {"usage": [], "feedback": [], "outcomes": [], "traces": [],
                            "scanned": 0, "partial": True, "seconds": 0})
    # Group filter: applied ONCE here, to every block, so the cards, the chart and the
    # value figures all describe the same set of projects.
    usage = _safe(lambda: _group_filter(rows.get("usage") or [], group), rows.get("usage") or [])
    feedback = _safe(lambda: _group_filter(rows.get("feedback") or [], group), rows.get("feedback") or [])
    outcomes = _safe(lambda: _group_filter(rows.get("outcomes") or [], group), rows.get("outcomes") or [])
    traces = _safe(lambda: _group_filter(rows.get("traces") or [], group), rows.get("traces") or [])

    return {
        "success": True,
        "data": {
            "range": {"from": from_date, "to": to_date, "days": days},
            "filters": {"project": project or "all", "group": group or "ALL"},
            "updated_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "summary": _safe(lambda: _summary(days, from_date, to_date, project, usage), {}),
            "period": _safe(lambda: _period(from_date, project, usage), {}),
            "adoption": _safe(lambda: _adoption(days, from_date, project, usage,
                                                bool(rows.get("partial"))), {}),
            "value": _safe(lambda: _value(from_date, to_date, project, group,
                                          feedback, outcomes, traces), {}),
            "people": _safe(lambda: _active_people(from_date, usage), {}),
            # Truncation is reported, never silent: a partial pass must not read as a complete
            # picture on a screen whose whole job is to be trusted as a count.
            "coverage": {
                "partial": bool(rows.get("partial")),
                "records_scanned": int(rows.get("scanned") or 0),
                "scan_seconds": rows.get("seconds"),
                "note": ("Figures are based on the most recent records only - the full history "
                         "did not fit the time budget for this request."
                         if rows.get("partial") else ""),
            },
        },
    }


# ----------------------------------------------------------------------------- card details
# Clicking a card on the Extension Usage page opens the records behind that number. The rows come
# from the same daily counters the card was summed from, through the same cached pass and the
# same group resolution, so a card and its detail list can never disagree.
#
# The counters say how many; the build records say which. Builds were first reported as counts
# only (one more build, failed or not, how many issues) against an installation, a day and a
# project, and those counts are what the cards sum. The drill-down needs the builds themselves,
# so the extension now also sends each build's record (id, status, times, duration) and it is
# stored as a row of its own (save_extension_build). The list is flat - one record per row,
# each naming its group and project - and a summary says how many groups and projects the
# records come from, so "21 builds" reads as "21 builds, from 2 projects in 1 group".
#
# Builds reported before the extension version that sends records are counted but cannot be
# listed; the gap is reported (buildsListed next to totalBuilds), never hidden.
#
# Every card opens the same drill-down: Metric -> Group -> Project -> the records. Build records
# exist only for the two build cards; for the others the finest record is one day of one
# project, because that is how the extension reports them.

METRIC_TYPES = ("active-users", "total-builds", "failed-builds", "issues-captured", "uploads",
                "recommendation-requests")
# Card -> the counter it sums (screen names on the left, stored names on the right; see _METRICS).
# active-users has no counter: a day counts when anybody was active, which is every stored day,
# and `users` is the set behind the figure.
_METRIC_FIELD = {"active-users": "users", "total-builds": "seen_builds",
                 "failed-builds": "seen_failures", "issues-captured": "seen_issues",
                 "uploads": "builds", "recommendation-requests": "uploads"}
_BUILD_TYPES = ("total-builds", "failed-builds")
_ROW_FIELDS = (("totalBuilds", "seen_builds"), ("failedBuilds", "seen_failures"),
               ("issuesCaptured", "seen_issues"), ("uploads", "builds"),
               ("recommendationRequests", "uploads"), ("recommendationsAnswered", "recommended"))
_DETAIL_PAGE_SIZE = 10
_DETAIL_PAGE_SIZE_MAX = 100
_ISO_DAY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}")
_MSG_FETCHED = "User metric details fetched successfully"
_MSG_EMPTY = "No user metric details found"
_MSG_FAILED = "Failed to fetch user metric details"


def _details_envelope(success: bool, message: str, data: list, page_number: int,
                      page_size: int, total: int, error: str = "") -> dict:
    total_pages = (total + page_size - 1) // page_size if total else 0
    out = {"success": success, "message": message, "data": data,
           "pagination": {"pageNumber": page_number, "pageSize": page_size,
                          "totalPages": total_pages, "totalRecords": total}}
    if error:
        out["error"] = error
    return out


def details_failure(page_number=1, page_size=_DETAIL_PAGE_SIZE, error: str = "") -> dict:
    """The error envelope the screen expects, with the pagination block it always reads."""
    return _details_envelope(False, _MSG_FAILED, [], page_number, page_size, 0, error)


def _int_arg(value, default: int, low: int, high: int) -> int:
    try:
        return max(low, min(int(value), high))
    except (TypeError, ValueError):
        return default


def _matches(project: str, search: str) -> bool:
    return not search or search in str(project or "").lower()


def _new_slot() -> dict:
    """One bucket of counters plus the users behind them (a set, so a person on two machines
    counts once at every level - the card's identity rule)."""
    return {"users": set(), **{f: 0 for _, f in _ROW_FIELDS}}


def _add(into: dict, slot: dict) -> None:
    into["users"] |= slot["users"]
    for _, f in _ROW_FIELDS:
        into[f] += slot[f]


def _counts(slot: dict) -> dict:
    out = {name: slot[f] for name, f in _ROW_FIELDS}
    # A build that was not reported as failed ended green. Clamped: the two counters are written
    # by separate requests, so a failure report racing ahead of its build must not read as -1.
    out["successfulBuilds"] = max(0, slot["seen_builds"] - slot["seen_failures"])
    out["activeUsers"] = len(slot["users"])
    return out


def _duration_text(seconds) -> str:
    """492 -> '8m 12s', 45 -> '45s', 3725 -> '1h 2m 5s'. Empty when unknown."""
    try:
        total = max(0, int(seconds))
    except (TypeError, ValueError):
        return ""
    hours, rest = divmod(total, 3600)
    minutes, secs = divmod(rest, 60)
    parts = ([f"{hours}h"] if hours else []) + ([f"{minutes}m"] if hours or minutes else []) + [f"{secs}s"]
    return " ".join(parts)


def _build_record(b: dict) -> dict:
    duration = b.get("duration_sec")
    return {
        "buildId": str(b.get("build_id") or ""),
        "buildStatus": str(b.get("build_status") or ""),
        "startedAt": str(b.get("started_at") or ""),
        "finishedAt": str(b.get("finished_at") or ""),
        "durationSec": int(duration) if duration is not None else None,
        "duration": _duration_text(duration),
        "taskName": str(b.get("task_name") or ""),
        "issues": int(b.get("issues") or 0),
    }


def _build_day(b: dict) -> str:
    """The day a build belongs to: its finish time when the extension sent an ISO one, else the
    moment the record arrived - so a build never vanishes over a date format."""
    finished = str(b.get("finished_at") or "")
    return finished[:10] if _ISO_DAY_RE.match(finished) else str(b.get("updated_date") or "")[:10]


def _builds_by_project(builds: list, from_date: str, to_date: str, kind: str) -> dict:
    """The individual build records per project, newest first, for the days in the window.
    Only the two build cards have them; failed-builds lists only the builds that failed."""
    if kind not in _BUILD_TYPES:
        return {}
    out: dict = defaultdict(list)
    for b in builds:
        if not (from_date <= _build_day(b) <= to_date):
            continue
        if kind == "failed-builds" and str(b.get("build_status") or "") != "failed":
            continue
        out[str(b.get("project_name") or "").strip().lower()].append(_build_record(b))
    for rows in out.values():
        rows.sort(key=lambda r: (r["finishedAt"], r["buildId"]), reverse=True)
    return out


def _breakdown(from_date: str, to_date: str, usage: list, builds: list, kind: str,
               search: str) -> tuple:
    """How a card's figure is distributed: Metric -> Group -> Project -> records, with the
    counters summed at every level. Returns (groups, summary).

    Only the days on which the chosen thing happened take part (a day with zero failed builds
    is not part of Failed Builds), and a project with no such day is not listed at all. The
    group of a project is resolved by the same rule the cards, the chart and the recommendation
    scope use, so a project cannot sit in one group here and another on the screen above.
    `search` keeps the projects whose own name or group name contains it.

    Under each project: `days`, one entry per day with that day's counters (the finest record
    the extension reports for most cards), and `builds`, the individual build records for the
    two build cards. Counts come from the daily counters (what the card shows); build records
    come from the rows the extension sends per build. The two differ for builds reported before
    records existed, so buildsListed sits next to totalBuilds rather than pretending the list is
    complete."""
    from src.utils.project_details import EXTUSAGE_PROFILE_SK
    field = _METRIC_FIELD[kind]
    keys = {str(r.get("PK") or ""): str(r.get("dev_key") or "")
            for r in usage if r.get("SK") == EXTUSAGE_PROFILE_SK and r.get("dev_key")}
    build_rows = _builds_by_project(builds, from_date, to_date, kind)
    days: dict = {}
    for r in usage:
        if r.get("SK") == EXTUSAGE_PROFILE_SK:
            continue
        day = str(r.get("use_date") or "")
        if not (from_date <= day <= to_date):
            continue
        project = str(r.get("project_name") or "").strip().lower()
        install = str(r.get("PK") or "")
        slot = days.setdefault((project, day), _new_slot())
        slot["users"].add(keys.get(install) or ("install:" + install))
        for _, f in _ROW_FIELDS:
            slot[f] += int(r.get(f) or 0)

    per_project: dict = defaultdict(dict)
    for (project, day), slot in days.items():
        if slot[field]:
            per_project[project][day] = slot
    empty = {"groups": 0, "projects": 0, "buildsListed": 0, **_counts(_new_slot())}
    if not per_project:
        # Nothing to group - return before build_group_map reads the group definitions out of
        # DynamoDB to answer a question about zero projects.
        return [], empty

    from src.services.project_groups import build_group_map, DEFAULT_GROUP
    gmap = build_group_map(list(per_project))
    groups: dict = {}
    for project, project_days in per_project.items():
        group = str(gmap.get(project) or DEFAULT_GROUP)
        if not (_matches(project, search) or _matches(group, search)):
            continue
        g = groups.setdefault(group, {"slot": _new_slot(), "projects": {}})
        p = {"slot": _new_slot(), "days": project_days}
        for slot in project_days.values():
            _add(p["slot"], slot)
            _add(g["slot"], slot)
        g["projects"][project] = p

    total, project_count, listed_total, out = _new_slot(), 0, 0, []
    for group in sorted(groups):
        g = groups[group]
        _add(total, g["slot"])
        projects, listed_group = [], 0
        for project in sorted(g["projects"]):
            p = g["projects"][project]
            project_count += 1
            project_builds = build_rows.get(project, [])
            listed_group += len(project_builds)
            projects.append({
                "projectName": project, **_counts(p["slot"]), "buildsListed": len(project_builds),
                "days": [{"date": day, **_counts(slot)}
                         for day, slot in sorted(p["days"].items(), reverse=True)],
                "builds": project_builds,
            })
        listed_total += listed_group
        out.append({"groupName": group, "projectCount": len(projects), **_counts(g["slot"]),
                    "buildsListed": listed_group, "projects": projects})
    return out, {"groups": len(out), "projects": project_count, "buildsListed": listed_total,
                 **_counts(total)}


_TABLE_COUNTS = ("totalBuilds", "failedBuilds", "successfulBuilds", "issuesCaptured", "uploads",
                 "recommendationRequests", "recommendationsAnswered", "activeUsers")


# Which figure `count` carries, per card. Every card has one, so `count` means the same thing on
# every row: the number this card is about.
_ROW_COUNT_FIELD = {
    "total-builds": "totalBuilds",
    "failed-builds": "failedBuilds",
    "active-users": "activeUsers",
    "issues-captured": "issuesCaptured",
    "uploads": "uploads",
    "recommendation-requests": "recommendationRequests",
}

# EVERY row has these keys, whichever card was clicked and whether or not builds were recorded.
# They are emptied, never omitted.
_ROW_TEMPLATE = {
    "projectName": "", "groupName": "", "date": "",
    "count": 0,
    "totalBuilds": 0, "failedBuilds": 0, "successfulBuilds": 0,
    "buildId": "", "buildStatus": "", "buildDateTime": "", "duration": "",
}


def _table_rows(groups: list, kind: str = "") -> list:
    """The records as a flat list for the drill-down table. ONE shape, always.

    Every row carries the same keys for every card. Rows previously carried only the fields their
    own card needed, which meant the shape changed when the card changed - switching to Uploads
    dropped the three build counts and added `count` - so the screen could not hold one table and
    one column set. A column the card does not use is emptied, not removed.

    What varies is the ROW, not its keys:

      a build card with builds recorded    one row per build; the build fields are filled and the
                                           counts describe that single build
      anything else                        one row per project per day; the build fields are empty

    `count` is the figure of the card that was clicked, so the column the table sorts by is the
    same column whatever the user drilled into. Newest first.
    """
    kind = str(kind or "").strip().lower()
    count_field = _ROW_COUNT_FIELD.get(kind, "totalBuilds")
    rows = []
    for g in groups:
        group_name = g["groupName"]
        for p in g["projects"]:
            name = p["projectName"]
            if p["builds"]:
                for b in p["builds"]:
                    # No build number, no row. A build reported without a record cannot be listed
                    # as a build, and a blank or invented number in that column would be worse
                    # than its absence - the card's count already includes it and `note` says so.
                    build_id = str(b["buildId"] or "").strip()
                    if not build_id:
                        continue
                    finished = b["finishedAt"]
                    failed = 1 if b["buildStatus"] == "failed" else 0
                    rows.append({**_ROW_TEMPLATE,
                        "projectName": name, "groupName": group_name,
                        # Not shown, but the table sorts and filters by day.
                        "date": finished[:10] if _ISO_DAY_RE.match(finished) else "",
                        "count": 1,
                        "totalBuilds": 1, "failedBuilds": failed,
                        "successfulBuilds": 1 - failed,
                        "buildId": build_id, "buildStatus": b["buildStatus"],
                        "buildDateTime": finished, "duration": b["duration"]})
            else:
                for d in p["days"]:
                    rows.append({**_ROW_TEMPLATE,
                        "projectName": name, "groupName": group_name, "date": d["date"],
                        "count": d[count_field],
                        "totalBuilds": d["totalBuilds"], "failedBuilds": d["failedBuilds"],
                        "successfulBuilds": d["successfulBuilds"]})
    rows.sort(key=lambda r: (r["date"], r["buildDateTime"], r["projectName"]), reverse=True)
    return rows


def metric_breakdown(metric_type, group="", days=None, search=""):
    """How one card's figure is distributed: Group -> Project -> records, with the totals.

    Returns (data, summary, window, partial). The distribution is NOT sent to the screen - the
    table lists rows, and the tree repeated every counter at group, project and day level, which
    was the bulk of the response. It is still what the counting rules are computed from, and it
    is what those rules are tested against, so it lives here rather than inside metric_details.
    """
    kind = str(metric_type or "").strip().lower()
    days, from_date, to_date = _window(_int_arg(days, DEFAULT_WINDOW_DAYS, 1, 365))
    # "All Groups" is what the screen sends for no group filter; _group_filter knows "" and ALL.
    group = str(group or "").strip()
    if group.lower() in ("all", "all groups"):
        group = ""
    search = str(search or "").strip().lower()

    rows = kpi_rows()
    usage = _group_filter(rows.get("usage") or [], group)
    builds = _group_filter(rows.get("builds") or [], group)
    data, summary = _breakdown(from_date, to_date, usage, builds, kind, search)
    return data, summary, {"from": from_date, "to": to_date, "days": days}, bool(rows.get("partial"))


def metric_details(metric_type, group="", days=None, page_number=None, page_size=None,
                   search="") -> tuple:
    """One card's drill-down as a flat list of table rows, paged by ROW.

    Returns (payload, http_status). The payload always carries success, message, data and
    pagination, so the screen reads one shape whatever happened. A bad card type is the caller's
    error (400); anything the table does wrong is reported as the failure envelope (500) by the
    route, never raised into the screen.

    `data` is the page of rows. Each row carries only the columns its own table shows - see
    _table_rows. The group/project/day tree the figures are computed from is not sent: the screen
    lists rows, and the tree repeated every counter three times over.
    """
    page_number = _int_arg(page_number, 1, 1, 10 ** 9)
    page_size = _int_arg(page_size, _DETAIL_PAGE_SIZE, 1, _DETAIL_PAGE_SIZE_MAX)
    kind = str(metric_type or "").strip().lower()
    if kind not in METRIC_TYPES:
        return details_failure(page_number, page_size,
                               "type must be one of: " + ", ".join(METRIC_TYPES)), 400
    data, summary, window, partial = metric_breakdown(kind, group, days, search)
    from_date, to_date, days = window["from"], window["to"], window["days"]

    # Paged by ROW, because a row is what the screen lists. Paging by group reported one record
    # for a page of eight rows, so the table could not show "1-8 of 11" or turn a page: a group
    # with forty rows and a group with one both counted as a single record.
    #
    # The rows are built from EVERY group that matched and then paged, not built from an already
    # paged slice of groups - otherwise a page could hold any number of rows between one and
    # several hundred.
    all_rows = _table_rows(data, kind)
    total = len(all_rows)
    start = (page_number - 1) * page_size
    payload = _details_envelope(True, _MSG_FETCHED if total else _MSG_EMPTY,
                                all_rows[start:start + page_size],
                                page_number, page_size, total)
    # The screen reads the rows and the pagination, and nothing else: the cards and the charts
    # above the table are served by the metrics endpoint, so a summary and the date window here
    # would be the same figures a second time. They are not sent.
    #
    # Two keys ARE sent, but only when they have something to say, so the ordinary response stays
    # down to data and pagination:
    #
    #   note      a count that cannot be listed. A card reading 25 above an empty table is
    #             otherwise unexplained, and the reason is not something the screen can work out.
    #   partial   the underlying read was truncated. Reported, never silent - the same rule the
    #             cards follow; its absence means the figures are whole.
    if kind in _BUILD_TYPES:
        counted = summary["failedBuilds"] if kind == "failed-builds" else summary["totalBuilds"]
        missing = counted - summary["buildsListed"]
        if missing > 0:
            payload["note"] = (
                f"{missing} of {counted} builds were reported without a build record "
                "(older extension version) and are counted but cannot be listed one by one.")
    if partial:
        payload["partial"] = True
    return payload, 200
