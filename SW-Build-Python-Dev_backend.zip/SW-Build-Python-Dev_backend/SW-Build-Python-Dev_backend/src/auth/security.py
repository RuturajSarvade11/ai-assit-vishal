"""
src/auth/security.py — password hashing, strong-password rules, and JWT (HS256), STDLIB ONLY.

No external dependency (works on the server with no pip install). This is the only place crypto
lives. The SSO swap later only replaces verify_token() to validate the IdP's token instead of ours;
nothing else (endpoints, role checks) changes.
"""
import os
import re
import hmac
import json
import time
import base64
import hashlib
import secrets
import logging

logger = logging.getLogger(__name__)

_JWT_SECRET = os.getenv("AUTH_JWT_SECRET", "").strip()
if not _JWT_SECRET:
    # Dev fallback so the app runs; set AUTH_JWT_SECRET to a long random value in UAT/prod.
    _JWT_SECRET = "dev-only-insecure-change-me-set-AUTH_JWT_SECRET"
    logger.warning("AUTH_JWT_SECRET not set — using an insecure dev fallback. Set it in UAT/prod.")
_JWT_TTL = int(os.getenv("AUTH_JWT_TTL_SECONDS", "28800"))   # 8 hours
_PBKDF2_ROUNDS = 200_000
PASSWORD_MIN_LEN = 8
_SPECIAL = r"""!@#$%^&*()_+\-=\[\]{};:'\",.<>/?\\|`~"""
_SPECIAL_DISPLAY = "!@#$%^&*()_+-=[]{};:',.<>/?|`~"


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")


def _b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


# ---------------------------------------------------------------- passwords
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"), salt, _PBKDF2_ROUNDS)
    return f"pbkdf2_sha256${_PBKDF2_ROUNDS}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, rounds, salt_hex, hash_hex = str(stored).split("$")
        dk = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                                 bytes.fromhex(salt_hex), int(rounds))
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


def validate_strong_password(pw: str):
    """(ok, message). Rule: >= 8 chars with lower + upper + digit + special character."""
    pw = pw or ""
    if len(pw) < PASSWORD_MIN_LEN:
        return False, f"Password must be at least {PASSWORD_MIN_LEN} characters."
    if not re.search(r"[a-z]", pw):
        return False, "Add a lowercase letter."
    if not re.search(r"[A-Z]", pw):
        return False, "Add an uppercase letter."
    if not re.search(r"[0-9]", pw):
        return False, "Add a digit."
    if not re.search(f"[{re.escape(_SPECIAL)}]", pw):
        return False, "Add a special character."
    return True, "ok"


def password_policy() -> dict:
    """The password rules — single source of truth the UI renders as labels (matches the validator)."""
    return {
        "min_length": PASSWORD_MIN_LEN,
        "require_lowercase": True,
        "require_uppercase": True,
        "require_digit": True,
        "require_special": True,
        "special_characters": _SPECIAL_DISPLAY,
        "rules": [
            f"At least {PASSWORD_MIN_LEN} characters",
            "One lowercase letter (a-z)",
            "One uppercase letter (A-Z)",
            "One digit (0-9)",
            "One special character (e.g. ! @ # $ % ^ & *)",
        ],
    }


# ---------------------------------------------------------------- JWT (HS256)
def issue_token(*, sub: str, name: str = "", info: str = "", role: str = "user",
                must_change: bool = False, ttl: int = None) -> str:
    now = int(time.time())
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {"sub": sub, "name": name, "info": info, "role": role, "must_change": bool(must_change),
               "iat": now, "exp": now + int(ttl or _JWT_TTL)}
    seg = (_b64u(json.dumps(header, separators=(",", ":")).encode("utf-8")) + "." +
           _b64u(json.dumps(payload, separators=(",", ":")).encode("utf-8")))
    sig = hmac.new(_JWT_SECRET.encode("utf-8"), seg.encode("ascii"), hashlib.sha256).digest()
    return seg + "." + _b64u(sig)


def verify_token(token: str):
    """Return the claims dict if the token is valid and unexpired, else None.

    *** SSO SWAP POINT ***: when SSO arrives, replace this body to validate the IdP's JWT
    (e.g. Azure AD via its JWKS) and map its groups -> role. The decorators/endpoints stay the same.
    """
    try:
        seg, sig_b64 = str(token).rsplit(".", 1)
        expected = hmac.new(_JWT_SECRET.encode("utf-8"), seg.encode("ascii"), hashlib.sha256).digest()
        if not hmac.compare_digest(_b64u(expected), sig_b64):
            return None
        payload = json.loads(_b64u_dec(seg.split(".", 1)[1]))
        if int(payload.get("exp", 0)) < int(time.time()):
            return None
        return payload
    except Exception:
        return None
