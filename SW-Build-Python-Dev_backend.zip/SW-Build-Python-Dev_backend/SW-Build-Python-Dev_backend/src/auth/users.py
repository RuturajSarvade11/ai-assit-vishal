"""
src/auth/users.py — DynamoDB-backed user store for dashboard auth.

Manual users now (seeded by seed_auth_users.py); when SSO arrives the identity comes from the IdP
and this store is only needed for role mapping (or replaced by SSO groups).
"""
import time
import logging

from src.databases.database import get_dynamodb
from src.configurations import config
from src.auth.security import hash_password

logger = logging.getLogger(__name__)

USERS_TABLE = f"auth_users{config.DYNAMODB_TABLE_SUFFIX}"

# Source of truth: (username, name, info/title, role, easy default password). name and info are
# SEPARATE (no em-dash), and everyone is "admin" (no "owner").
# Username = the person's Schaeffler EMAIL (login is email + password; matches the eventual Microsoft
# SSO identity). _norm() lowercases, so the email login is case-insensitive.
SEED_USERS = [
    ]
_DEFAULTS = {u: pw for u, _n, _i, _r, pw in SEED_USERS}


def _table():
    return get_dynamodb().Table(USERS_TABLE)


def _norm(username: str) -> str:
    return str(username or "").strip().lower()


def get_user(username: str):
    uname = _norm(username)
    if not uname:
        return None
    try:
        return _table().get_item(Key={"username": uname}).get("Item")
    except Exception:
        logger.exception("get_user failed | username=%s", uname)
        return None


def get_user_by_email(email: str):
    """Find a user by their EMAIL field (the login identity). Small user table, so a scan is fine.
    Falls back to the username-key lookup for legacy records where username == email (no email field)."""
    em = _norm(email)
    if not em:
        return None
    try:
        for it in _table().scan().get("Items", []):
            if _norm(it.get("email") or it.get("username")) == em:
                return it
    except Exception:
        logger.exception("get_user_by_email failed | email=%s", em)
    return get_user(em)  # legacy fallback (username == email)


def put_user(username: str, name: str, info: str, role: str, password_hash: str, must_change: bool = True,
             email: str = ""):
    now = int(time.time())
    uname = _norm(username)
    _table().put_item(Item={
        "username": uname, "email": _norm(email) or uname, "name": name, "info": info, "role": role,
        "password_hash": password_hash, "must_change_password": bool(must_change),
        "created_at": now, "updated_at": now, "password_updated_at": now,
    })


def update_password(username: str, password_hash: str):
    now = int(time.time())
    _table().update_item(
        Key={"username": _norm(username)},
        UpdateExpression="SET password_hash = :p, must_change_password = :m, "
                         "password_updated_at = :t, updated_at = :t",
        ExpressionAttributeValues={":p": password_hash, ":m": False, ":t": now},
    )


def default_password_for(username: str) -> str:
    return _DEFAULTS.get(_norm(username), "Welcome@123")


def list_users() -> list:
    """All users + their status (owner view). Never returns password hashes — so the owner can
    CHECK who still has must_change_password=True (never set their own password yet)."""
    try:
        items = _table().scan().get("Items", [])
    except Exception:
        logger.exception("list_users failed")
        return []
    out = [{"username": i.get("username"), "email": i.get("email", i.get("username")),
            "name": i.get("name"), "info": i.get("info", ""),
            "role": i.get("role"), "must_change_password": bool(i.get("must_change_password")),
            "password_updated_at": int(i.get("password_updated_at", 0) or 0),
            "updated_at": int(i.get("updated_at", 0) or 0)} for i in items]
    return sorted(out, key=lambda u: u.get("username") or "")


def reset_to_default(username: str):
    """Reset a user to their default password + must_change_password=True (owner action for a
    forgotten password). Returns {username, default_password} or None if the user is unknown."""
    uname = _norm(username)
    if not get_user(uname):
        return None
    default_pw = default_password_for(uname)
    now = int(time.time())
    _table().update_item(
        Key={"username": uname},
        UpdateExpression="SET password_hash = :p, must_change_password = :m, updated_at = :t",
        ExpressionAttributeValues={":p": hash_password(default_pw), ":m": True, ":t": now},
    )
    return {"username": uname, "default_password": default_pw}
