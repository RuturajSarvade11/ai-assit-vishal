"""
src/auth/sso_roles.py — admin/user decision for Microsoft SSO sign-ins:

  - The Microsoft token's roles/groups are IGNORED. The role comes from OUR OWN user store,
    keyed on the person's Schaeffler ID (e.g. sg586096@user.schaeffler.com).
  - The ID is NEVER stored in plain text: rows are keyed on an HMAC-SHA256 of the normalized
    ID (deterministic, so sign-in lookups work; irreversible, so reading the database exposes
    no IDs). Only a masked form (sg58***@user.schaeffler.com) is kept for the admin screen.
  - Bootstrap admins come from SSO_ADMIN_IDS (comma list of plain IDs, server .env only —
    the .env restriction was about the DATABASE).
  - The User Management list IS the access list. A sign-in from an ID
    that is not on it is refused (sign_in_decision) - no row, no session. Admins add people on
    the User Management page (default role: user) before they can sign in. SSO_ALLOW_UNLISTED=1
    restores the earlier open behaviour (first sign-in recorded with SSO_DEFAULT_ROLE).

Admin actions and reads stay fail-open on storage errors; the sign-in decision does not (see
sign_in_decision) - letting everyone in on an error is the open behaviour this replaces.
"""
import hashlib
import hmac
import logging
import os
import time

from src.auth.users import USERS_TABLE, get_user
from src.databases.database import get_dynamodb

logger = logging.getLogger(__name__)

_KEY_PREFIX = "sso#"
_VALID_ROLES = ("admin", "user")


def _table():
    return get_dynamodb().Table(USERS_TABLE)


def _norm(user_id: str) -> str:
    return str(user_id or "").strip().lower()


def _hash_secret() -> str:
    return (os.getenv("SSO_ID_HASH_SECRET") or os.getenv("AUTH_JWT_SECRET")
            or "dev-only-insecure-change-me-set-AUTH_JWT_SECRET").strip()


def _hash_id(user_id: str) -> str:
    return hmac.new(_hash_secret().encode("utf-8"),
                    _norm(user_id).encode("utf-8"), hashlib.sha256).hexdigest()


def _row_key(user_id: str) -> str:
    return _KEY_PREFIX + _hash_id(user_id)


def _mask_id(user_id: str) -> str:
    """sg586096@user.schaeffler.com -> sg58***@user.schaeffler.com (admin-screen display only)."""
    uid = _norm(user_id)
    if not uid:
        return ""
    local, _, domain = uid.partition("@")
    shown = local[:4] if len(local) > 4 else local[:1]
    return shown + "***" + ("@" + domain if domain else "")


def _bootstrap_admin_ids() -> set:
    return {_norm(x) for x in (os.getenv("SSO_ADMIN_IDS") or "").split(",") if _norm(x)}


def _default_role() -> str:
    role = _norm(os.getenv("SSO_DEFAULT_ROLE") or "user")
    return role if role in _VALID_ROLES else "user"


def _normalize_projects(projects) -> list:
    """Trimmed, de-duplicated (case-insensitive), bounded name list."""
    if not isinstance(projects, list):
        return []
    out, seen = [], set()
    for p in projects:
        name = str(p or "").strip()
        if name and name.lower() not in seen:
            seen.add(name.lower())
            out.append(name)
    return out[:200]


# Access is granted per PROJECT GROUP, not per project name: the project list grows, and an
# assignment made from names would silently miss every project added to the group afterwards.
# The stored row therefore keeps GROUP names, and the membership is resolved on each read
# (_projects_in_groups). Rows written before this still carry explicit `projects`; those are
# honoured alongside the groups so no existing assignment is lost.
_GROUP_EXPANSION_TTL_SEC = 60
_group_expansion_cache: dict = {}


def _projects_in_groups(groups) -> list:
    """Every project that belongs to one of these groups, as of now."""
    wanted = {str(g or "").strip().lower() for g in (groups or []) if str(g or "").strip()}
    if not wanted:
        return []
    cache_key = tuple(sorted(wanted))
    hit = _group_expansion_cache.get(cache_key)
    now = time.time()
    if hit and (now - hit[0]) < _GROUP_EXPANSION_TTL_SEC:
        return list(hit[1])
    from src.services.project_groups import build_group_map
    from src.utils.project_details import get_all_projects
    names = [str((row or {}).get("project_name") or "").strip()
             for row in (get_all_projects() or [])]
    names = [n for n in names if n]
    group_of = build_group_map(names)
    members = sorted({n for n in names
                      if str(group_of.get(n) or "").strip().lower() in wanted})
    _group_expansion_cache[cache_key] = (now, members)
    return list(members)


def _write_row(key: str, masked_id: str, name: str, role: str, created_at=None,
               projects=None, groups=None) -> dict:
    now = int(time.time())
    item = {
        "username": key,                    # sso#<hmac> — the plain ID is never stored
        "email": key,
        "masked_id": masked_id,
        "name": str(name or "").strip(),
        "info": "SSO",
        "role": role,
        "groups": _normalize_projects(groups),       # project GROUPS this user may see
        "projects": _normalize_projects(projects),   # individual projects assigned before groups
        "password_hash": "sso-login-only",  # never a valid pbkdf2 record -> password login impossible
        "must_change_password": False,
        "created_at": int(created_at or now),
        "updated_at": now,
        "last_login_at": now,
    }
    _table().put_item(Item=item)
    return item


def _row_view(item: dict, key: str) -> dict:
    return {"row_key": key, "masked_id": item.get("masked_id", ""), "name": item.get("name", ""),
            "role": item.get("role", ""), "groups": item.get("groups", []),
            "projects": item.get("projects", [])}


def role_for_sso_user(user_id: str, display_name: str = "") -> str:
    """The role for this sign-in. Existing row wins; else SSO_ADMIN_IDS bootstrap; else the
    default role. The sign-in is recorded (hashed key) so the admin screen can manage it later."""
    fallback = _default_role()
    if not _norm(user_id):
        return fallback
    try:
        key = _row_key(user_id)
        row = get_user(key)
        if row and _norm(row.get("role")) in _VALID_ROLES:
            role = _norm(row.get("role"))
            _write_row(key, _mask_id(user_id), display_name or row.get("name") or "", role,
                       created_at=row.get("created_at"), projects=row.get("projects"),
                       groups=row.get("groups"))
            return role
        role = "admin" if _norm(user_id) in _bootstrap_admin_ids() else fallback
        _write_row(key, _mask_id(user_id), display_name, role)
        logger.info("[sso-roles] first sign-in recorded | masked=%s role=%s", _mask_id(user_id), role)
        return role
    except Exception:
        logger.exception("role_for_sso_user failed — answering default role (sign-in never blocked)")
        return fallback


def _unlisted_allowed() -> bool:
    """The User Management list IS the access list. A Microsoft sign-in
    from someone who is not on it is refused - allowing everything by default is not
    acceptable. SSO_ALLOW_UNLISTED=1 restores the earlier open behaviour (every tenant
    user recorded on first sign-in with the default role) for a test environment."""
    return (os.getenv("SSO_ALLOW_UNLISTED") or "").strip().lower() in ("1", "true", "yes", "on")


def sign_in_decision(user_id: str, display_name: str = "") -> dict:
    """Whether this Microsoft sign-in may enter the dashboard, and as which role.

    Returns {"allowed": bool, "role": str, "reason": str}. Order of the decision:
      1. bootstrap admin (SSO_ADMIN_IDS) - always in, as admin, needs no storage
      2. on the User Management list (a row exists) - in, with the row's role
      3. not listed - refused, and NO row is written: the list stays the admin's own, it is not
         filled by whoever tried the door (unless SSO_ALLOW_UNLISTED=1, the old behaviour)
    A storage error refuses everyone but the bootstrap admins: silently letting everyone in on
    an error is exactly the open behaviour this replaces, and a refused admin sees it at once."""
    uid = _norm(user_id)
    fallback = _default_role()
    if not uid:
        return {"allowed": False, "role": fallback, "reason": "no_identity"}
    key = _row_key(user_id)
    masked = _mask_id(user_id)
    if uid in _bootstrap_admin_ids():
        try:
            row = get_user(key) or {}
            _write_row(key, masked, display_name or row.get("name") or "", "admin",
                       created_at=row.get("created_at"), projects=row.get("projects"),
                       groups=row.get("groups"))
        except Exception:
            logger.exception("[sso-roles] bootstrap admin row write failed - signed in anyway")
        return {"allowed": True, "role": "admin", "reason": "bootstrap_admin"}
    try:
        row = get_user(key)
    except Exception:
        logger.exception("[sso-roles] user store unreadable - refusing sign-in | masked=%s", masked)
        return {"allowed": False, "role": fallback, "reason": "store_error"}
    if row and _norm(row.get("role")) in _VALID_ROLES:
        role = _norm(row.get("role"))
        try:
            _write_row(key, masked, display_name or row.get("name") or "", role,
                       created_at=row.get("created_at"), projects=row.get("projects"),
                       groups=row.get("groups"))
        except Exception:
            logger.exception("[sso-roles] last sign-in update failed | masked=%s", masked)
        return {"allowed": True, "role": role, "reason": "listed"}
    if _unlisted_allowed():
        try:
            _write_row(key, masked, display_name, fallback)
            logger.info("[sso-roles] first sign-in recorded | masked=%s role=%s", masked, fallback)
        except Exception:
            logger.exception("[sso-roles] first sign-in row write failed | masked=%s", masked)
        return {"allowed": True, "role": fallback, "reason": "unlisted_allowed"}
    logger.info("[sso-roles] sign-in refused - not on the user list | masked=%s", masked)
    return {"allowed": False, "role": fallback, "reason": "not_listed"}


# A signed token stays valid until it expires, so checking the access list only at sign-in let a
# REMOVED user keep working for the rest of their session. Every authenticated request now asks
# whether the person is still listed, and with which role, so a removal or a role change takes
# effect at once. The answer is cached for a few seconds - the check runs on every request, and
# the row it reads changes only when an admin edits it, which clears the entry immediately.
_ACCESS_TTL_SEC = 30
_access_cache: dict = {}


def _forget_access(key: str) -> None:
    _access_cache.pop(key, None)


def current_access(user_id: str) -> dict:
    """Whether an existing session may continue, and the role it runs with.

    Returns {"allowed": bool, "role": str, "reason": str}. The rules are the sign-in rules, but
    nothing is written: this answers about a session that already exists.

    One deliberate difference from sign_in_decision: a storage error lets the session continue.
    Refusing here would sign out every user in the building on a transient DynamoDB error, and
    unlike a sign-in this grants no new access."""
    uid = _norm(user_id)
    fallback = _default_role()
    if not uid:
        return {"allowed": False, "role": fallback, "reason": "no_identity"}
    if uid in _bootstrap_admin_ids():
        return {"allowed": True, "role": "admin", "reason": "bootstrap_admin"}
    key = _row_key(user_id)
    now = time.time()
    hit = _access_cache.get(key)
    if hit and (now - hit[0]) < _ACCESS_TTL_SEC:
        return dict(hit[1])
    try:
        row = get_user(key)
    except Exception:
        logger.exception("[sso-roles] access re-check failed - session kept | masked=%s",
                         _mask_id(user_id))
        return {"allowed": True, "role": fallback, "reason": "store_error"}
    if row and _norm(row.get("role")) in _VALID_ROLES:
        answer = {"allowed": True, "role": _norm(row.get("role")), "reason": "listed"}
    elif _unlisted_allowed():
        answer = {"allowed": True, "role": fallback, "reason": "unlisted_allowed"}
    else:
        answer = {"allowed": False, "role": fallback, "reason": "not_listed"}
    _access_cache[key] = (now, dict(answer))
    return answer


def _resolve_target(user_id: str, row_key: str):
    """(key, row, masked) for an admin update. Admins may target a user either by the plain
    Schaeffler ID (adding someone new) or by the row_key from the list endpoint (editing an
    existing row without ever knowing the plain ID — the key is an irreversible hash)."""
    rk = str(row_key or "").strip()
    if rk:
        if not rk.startswith(_KEY_PREFIX):
            raise ValueError("unknown row_key")
        row = get_user(rk)
        if not row:
            raise ValueError("unknown row_key")
        return rk, row, str(row.get("masked_id") or "")
    if not _norm(user_id):
        raise ValueError("user_id or row_key is required")
    key = _row_key(user_id)
    return key, (get_user(key) or {}), _mask_id(user_id)


def set_sso_role(user_id: str, role: str, display_name: str = "", row_key: str = "") -> dict:
    """Admin action (dashboard user management): assign admin/user to a Schaeffler ID.
    Works before OR after the person's first sign-in."""
    role = _norm(role)
    if role not in _VALID_ROLES:
        raise ValueError("role must be admin or user")
    key, row, masked = _resolve_target(user_id, row_key)
    item = _write_row(key, masked, display_name or row.get("name") or "", role,
                      created_at=row.get("created_at"), projects=row.get("projects"),
                      groups=row.get("groups"))
    _forget_access(key)
    return _row_view(item, key)


def set_sso_groups(user_id: str, groups: list, display_name: str = "", row_key: str = "") -> dict:
    """Admin action: assign the project GROUPS this user may see. An empty list clears the
    assignment. Works before or after first sign-in; the user's role is kept."""
    if not isinstance(groups, list):
        raise ValueError("groups must be a list of project group names")
    key, row, masked = _resolve_target(user_id, row_key)
    role = _norm(row.get("role")) if _norm(row.get("role")) in _VALID_ROLES else _default_role()
    item = _write_row(key, masked, display_name or row.get("name") or "", role,
                      created_at=row.get("created_at"), projects=row.get("projects"),
                      groups=groups)
    _forget_access(key)
    return _row_view(item, key)


def set_sso_projects(user_id: str, projects: list, display_name: str = "", row_key: str = "") -> dict:
    """Admin action: assign individual dashboard projects. Kept for rows created before access
    moved to groups, and for the case where one project has to be granted on its own."""
    if not isinstance(projects, list):
        raise ValueError("projects must be a list of project names")
    key, row, masked = _resolve_target(user_id, row_key)
    role = _norm(row.get("role")) if _norm(row.get("role")) in _VALID_ROLES else _default_role()
    item = _write_row(key, masked, display_name or row.get("name") or "", role,
                      created_at=row.get("created_at"), projects=projects,
                      groups=row.get("groups"))
    _forget_access(key)
    return _row_view(item, key)


def projects_for_sso_user(user_id: str, role: str = "") -> dict:
    """What the signed-in user may see. Admins see everything. Otherwise the answer is the
    projects of the assigned GROUPS as they stand today, plus any individually assigned
    projects. A user with NEITHER sees nothing: access is granted, never assumed, so a person
    who has just been added sees an empty dashboard until an admin assigns them a group.
    RBAC_DEFAULT_ALLOW=1 restores the earlier behaviour of showing everything until assigned.

    The expansion happens here rather than at assignment time, so a project added to a group
    tomorrow is covered without anybody editing the user. A storage error answers "nothing"
    rather than "everything" - an empty dashboard is recoverable, showing another team's
    projects is not."""
    if _norm(role) == "admin":
        return {"all": True, "projects": [], "groups": []}
    allow_unassigned = (os.getenv("RBAC_DEFAULT_ALLOW") or "").strip().lower() in ("1", "true", "yes", "on")
    try:
        row = get_user(_row_key(user_id)) or {}
        groups = _normalize_projects(row.get("groups") if isinstance(row.get("groups"), list) else [])
        assigned = _normalize_projects(row.get("projects") if isinstance(row.get("projects"), list) else [])
        allowed = list(assigned)
        if groups:
            try:
                for name in _projects_in_groups(groups):
                    if name.lower() not in {a.lower() for a in allowed}:
                        allowed.append(name)
            except Exception:
                # The group could not be expanded (project list unreadable). Restricting to the
                # explicit projects is wrong in the other direction, so say what was assigned
                # and let the caller see the groups that could not be resolved.
                logger.exception("group expansion failed | groups=%s", groups)
        if groups or assigned:
            return {"all": False, "projects": sorted(allowed), "groups": groups}
        return {"all": allow_unassigned, "projects": [], "groups": []}
    except Exception:
        logger.exception("projects_for_sso_user failed — answering no projects")
        return {"all": False, "projects": [], "groups": []}


def delete_sso_user(row_key: str) -> dict:
    """Admin action: remove a user row. This removes the person's access - the
    list is the access list, so the next sign-in is refused until an admin adds them again
    (with SSO_ALLOW_UNLISTED=1 it is only a reset to the default role, as before)."""
    rk = str(row_key or "").strip()
    if not rk.startswith(_KEY_PREFIX):
        raise ValueError("unknown row_key")
    row = get_user(rk)
    if not row:
        raise ValueError("unknown row_key")
    _table().delete_item(Key={"username": rk})
    # Their open session ends with the next request, not when the token expires.
    _forget_access(rk)
    return {"masked_id": str(row.get("masked_id") or ""), "name": str(row.get("name") or "")}


def list_sso_users() -> list:
    """All SSO users for the admin screen — masked IDs only, never hashes or plain IDs."""
    try:
        items = _table().scan().get("Items", [])
    except Exception:
        logger.exception("list_sso_users failed")
        return []
    out = [{"row_key": i.get("username", ""),   # irreversible hash — safe for the admin UI, lets
                                                # edits target a row without knowing the plain ID
            "masked_id": i.get("masked_id", ""), "name": i.get("name", ""),
            "role": i.get("role", ""),
            "groups": [str(g) for g in (i.get("groups") or [])],
            "projects": [str(p) for p in (i.get("projects") or [])],
            "created_at": int(i.get("created_at", 0) or 0),
            "last_login_at": int(i.get("last_login_at", 0) or 0)}
           for i in items if str(i.get("username", "")).startswith(_KEY_PREFIX)]
    return sorted(out, key=lambda u: u.get("name") or u.get("masked_id") or "")
