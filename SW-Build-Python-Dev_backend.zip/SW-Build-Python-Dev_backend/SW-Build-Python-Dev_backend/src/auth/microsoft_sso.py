"""
src/auth/microsoft_sso.py — Sign in with the Schaeffler Microsoft account (Entra ID).

Flow (matches the approved app-registration request document):
  1. Dashboard sends the user to Microsoft's own sign-in page (GET /auth/microsoft/login).
  2. Microsoft redirects back to the dashboard's /auth/callback with a one-time code.
  3. Dashboard posts the code here (POST /auth/microsoft/token); the SERVER exchanges it
     using the client secret, validates the identity token, maps the role, and issues the
     SAME dashboard JWT the password login issues — everything downstream is unchanged.

ALL values come from the environment — the client secret is never in code or in git:
  MS_SSO_TENANT_ID       Schaeffler directory (tenant) id
  MS_SSO_CLIENT_ID       Application (client) id of the registration
  MS_SSO_CLIENT_SECRET   Client secret (server-side only)
  MS_SSO_REDIRECT_URIS   Comma list of ALLOWED redirect URIs (must equal the registered ones)
  MS_SSO_ADMIN_GROUPS    Comma list of directory group ids that map to the admin role (optional)
  MS_SSO_DEFAULT_ROLE    Role when no group mapping matches (default: admin — current policy
                         until the group-to-role mapping is provided by Schaeffler)
"""
import logging
import os
import secrets as _secrets
import time

import requests

logger = logging.getLogger(__name__)

_DEFAULT_REDIRECTS = (
    "https://pmt-ai.aws1678.vitesco.io:441/auth/callback,"

)


def _tenant() -> str:
    return (os.getenv("MS_SSO_TENANT_ID") or "").strip()


def _client_id() -> str:
    return (os.getenv("MS_SSO_CLIENT_ID") or "").strip()


def _client_secret() -> str:
    return (os.getenv("MS_SSO_CLIENT_SECRET") or "").strip()


def sso_enabled() -> bool:
    return bool(_tenant() and _client_id() and _client_secret())


def allowed_redirects() -> list:
    raw = os.getenv("MS_SSO_REDIRECT_URIS") or _DEFAULT_REDIRECTS
    return [u.strip() for u in raw.split(",") if u.strip()]


def public_config() -> dict:
    """What the dashboard may know — never the secret."""
    return {
        "enabled": sso_enabled(),
        "client_id": _client_id(),
        "tenant_id": _tenant(),
        "authority": f"https://login.microsoftonline.com/{_tenant()}" if _tenant() else "",
        "redirect_uris": allowed_redirects(),
    }


def build_authorize_url(redirect_uri: str, state: str = "") -> str:
    from urllib.parse import urlencode
    params = {
        "client_id": _client_id(),
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "response_mode": "query",
        # Basic sign-in ONLY - no Graph permission (User.Read removed): we read the ID-token
        # claims and never call Microsoft Graph. Keeps the admin-consent request minimal
        # (the Schaeffler tenant disables user consent - "Need admin approval").
        "scope": "openid profile email",
        "state": state or _secrets.token_urlsafe(16),
    }
    return f"https://login.microsoftonline.com/{_tenant()}/oauth2/v2.0/authorize?{urlencode(params)}"


def _decode_segment(seg: str) -> dict:
    import base64
    import json
    pad = "=" * (-len(seg) % 4)
    return json.loads(base64.urlsafe_b64decode(seg + pad))


def _validated_claims(id_token: str) -> dict:
    """Verify the identity token. Primary path: signature verification against Microsoft's
    published keys (PyJWT + JWKS). Fallback (logged): strict claim checks only — acceptable
    because the token was received DIRECTLY from Microsoft's token endpoint over TLS in the
    server-to-server exchange, never through the browser."""
    try:
        import jwt as pyjwt
        jwks_url = f"https://login.microsoftonline.com/{_tenant()}/discovery/v2.0/keys"
        jwk_client = pyjwt.PyJWKClient(jwks_url)
        key = jwk_client.get_signing_key_from_jwt(id_token).key
        return pyjwt.decode(id_token, key, algorithms=["RS256"], audience=_client_id())
    except Exception as err:
        logger.warning("SSO id_token signature verification unavailable (%s) — strict claim checks applied", err)
        claims = _decode_segment(id_token.split(".")[1])
        if claims.get("aud") != _client_id():
            raise ValueError("id_token audience mismatch")
        if _tenant() not in str(claims.get("iss", "")):
            raise ValueError("id_token issuer mismatch")
        if int(claims.get("exp", 0)) < int(time.time()):
            raise ValueError("id_token expired")
        return claims


def exchange_code(code: str, redirect_uri: str) -> dict:
    """Exchange the one-time code for tokens (server-side, with the secret) and return the
    validated user identity: {email, name, groups}."""
    token_url = f"https://login.microsoftonline.com/{_tenant()}/oauth2/v2.0/token"
    resp = requests.post(token_url, data={
        "client_id": _client_id(),
        "client_secret": _client_secret(),
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri,
        "scope": "openid profile email",
    }, timeout=30)
    body = resp.json() if resp.content else {}
    if resp.status_code != 200 or "id_token" not in body:
        detail = str(body.get("error_description") or body.get("error") or resp.status_code)[:300]
        logger.warning("SSO code exchange failed | %s", detail)
        raise ValueError(f"Microsoft sign-in failed: {detail}")

    claims = _validated_claims(body["id_token"])
    email = (claims.get("email") or claims.get("preferred_username") or claims.get("upn") or "").strip().lower()
    if not email:
        raise ValueError("Microsoft sign-in returned no email/username claim")
    return {
        "email": email,
        "name": (claims.get("name") or email).strip(),
        "groups": [str(g) for g in (claims.get("groups") or [])],
    }


def role_for(groups: list) -> str:
    """Directory groups -> dashboard role. Until Schaeffler provides the group-to-role
    mapping, every authenticated Schaeffler user gets MS_SSO_DEFAULT_ROLE (admin — the
    current dashboard policy). Once the mapping arrives, set MS_SSO_ADMIN_GROUPS and flip
    the default to 'user' — configuration only, no release."""
    admin_groups = {g.strip() for g in (os.getenv("MS_SSO_ADMIN_GROUPS") or "").split(",") if g.strip()}
    if admin_groups and any(g in admin_groups for g in (groups or [])):
        return "admin"
    if admin_groups:
        return (os.getenv("MS_SSO_DEFAULT_ROLE") or "user").strip() or "user"
    return (os.getenv("MS_SSO_DEFAULT_ROLE") or "admin").strip() or "admin"
