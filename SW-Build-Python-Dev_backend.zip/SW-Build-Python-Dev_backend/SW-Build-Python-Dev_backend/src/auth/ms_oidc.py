"""
src/auth/ms_oidc.py — app-level Microsoft (Entra ID) sign-in via MSAL, OIDC Authorization-Code flow.

This lets a user sign in with their Schaeffler Microsoft account WITHOUT any load-balancer / infra
change - the app itself runs the OIDC flow. It stays fully DORMANT until an Entra app registration
is configured (MS_TENANT_ID + MS_CLIENT_ID + MS_CLIENT_SECRET + MS_REDIRECT_URI); is_enabled() is
False until then, so the existing username/password login keeps working.

Flow: /auth/login/microsoft -> Microsoft sign-in (password + MFA on Microsoft's page) -> Microsoft
redirects to MS_REDIRECT_URI (= our /auth/callback) -> we read the identity + role claims and mint the
app's normal session token (issue_token), so require_auth / role checks downstream are unchanged.

Needs:  pip install msal   (imported lazily, so the app runs fine without it until MS login is used).
"""
import hashlib
import json
import os
import tempfile
import time
import threading
import logging

logger = logging.getLogger(__name__)

MS_TENANT_ID = os.getenv("MS_TENANT_ID", "").strip()
MS_CLIENT_ID = os.getenv("MS_CLIENT_ID", "").strip()
MS_CLIENT_SECRET = os.getenv("MS_CLIENT_SECRET", "").strip()
MS_REDIRECT_URI = os.getenv("MS_REDIRECT_URI", "").strip()  # e.g. https://pmt-ai.aws1678.vitesco.io/auth/callback
MS_AUTHORITY = (os.getenv("MS_AUTHORITY", "").strip()
                or (f"https://login.microsoftonline.com/{MS_TENANT_ID}" if MS_TENANT_ID else ""))
# Sign-in ONLY by default (no Graph permission). We only read the ID-token claims (extract_user),
# never call Microsoft Graph, so we don't need User.Read. Requesting no resource permission also
# avoids the admin-consent prompt IF the tenant allows user consent for basic sign-in. MSAL still
# adds the reserved openid/profile/offline_access. Override with MS_SCOPES if a resource is ever needed.
MS_SCOPES = [s for s in os.getenv("MS_SCOPES", "").split() if s]
MS_POST_LOGIN_REDIRECT = os.getenv("MS_POST_LOGIN_REDIRECT", "/").strip()
MS_ROLE_CLAIM = os.getenv("MS_ROLE_CLAIM", "roles").strip()  # which token claim carries the role: roles | groups
# Debug/test: when on, /auth/callback returns the sign-in result (identity + role + claims) as JSON
# instead of redirecting to the dashboard. Use it to confirm the login works end-to-end.
MS_LOGIN_DEBUG = os.getenv("MS_LOGIN_DEBUG", "").strip().lower() in ("1", "true", "yes", "on")

# In-flight OIDC flows, keyed by the OIDC `state`. Stored BOTH in memory (fast path) and on
# disk: the in-memory dict alone loses every in-flight login on a service restart and is
# invisible to any second worker process — both cases surface as the "login session expired
# or invalid state" error even though the user did everything right (seen on dev).
# Flow files are one-time use (deleted on first read) and swept after _TTL seconds.
_flows = {}
_lock = threading.Lock()
_TTL = 600
_FLOW_DIR = os.path.join(tempfile.gettempdir(), "sw_ms_oidc_flows")


def is_enabled() -> bool:
    return bool(MS_TENANT_ID and MS_CLIENT_ID and MS_CLIENT_SECRET and MS_REDIRECT_URI)


def _app():
    import msal
    return msal.ConfidentialClientApplication(
        MS_CLIENT_ID, authority=MS_AUTHORITY, client_credential=MS_CLIENT_SECRET)


def _flow_path(state: str) -> str:
    name = hashlib.sha256(str(state).encode("utf-8")).hexdigest()[:32]
    return os.path.join(_FLOW_DIR, name + ".json")


def _save_flow_to_disk(state: str, flow: dict) -> None:
    try:
        os.makedirs(_FLOW_DIR, exist_ok=True)
        with open(_flow_path(state), "w", encoding="utf-8") as fh:
            json.dump({"flow": flow, "ts": time.time()}, fh)
    except Exception:
        logger.exception("could not persist OIDC flow to disk - login still works unless the service restarts mid-login")


def _pop_flow_from_disk(state: str):
    path = _flow_path(state)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            entry = json.load(fh)
    except FileNotFoundError:
        return None
    except Exception:
        logger.exception("unreadable OIDC flow file %s", path)
        entry = None
    try:
        os.remove(path)
    except OSError:
        pass
    if not isinstance(entry, dict) or time.time() - float(entry.get("ts", 0)) > _TTL:
        return None
    flow = entry.get("flow")
    return flow if isinstance(flow, dict) else None


def _gc():
    now = time.time()
    for k in [k for k, v in _flows.items() if now - v[1] > _TTL]:
        _flows.pop(k, None)
    try:
        for name in os.listdir(_FLOW_DIR):
            path = os.path.join(_FLOW_DIR, name)
            try:
                if now - os.path.getmtime(path) > _TTL:
                    os.remove(path)
            except OSError:
                pass
    except OSError:
        pass  # flow dir not created yet


def begin_login() -> str:
    """Start the OIDC flow; stash it by state (memory + disk) and return Microsoft's
    authorization URL to redirect to."""
    flow = _app().initiate_auth_code_flow(MS_SCOPES, redirect_uri=MS_REDIRECT_URI)
    with _lock:
        _gc()
        _flows[flow["state"]] = (flow, time.time())
    _save_flow_to_disk(flow["state"], flow)
    return flow["auth_uri"]


def complete_login(args) -> tuple:
    """Finish the flow from the callback query args. Returns (id_token_claims, error)."""
    state = args.get("state")
    with _lock:
        entry = _flows.pop(state, None)
    flow = entry[0] if entry else _pop_flow_from_disk(state)
    if not flow:
        logger.warning(
            "MS OIDC state miss | state=%.12s... | in_memory_flows=%d | likely: service "
            "restarted mid-login, a different worker served the callback, the callback was "
            "refreshed (one-time use), or an old login link from browser history was used",
            str(state or ""), len(_flows),
        )
        return None, "login session expired or invalid state - please sign in again"
    try:
        result = _app().acquire_token_by_auth_code_flow(flow, dict(args))
    except Exception as e:
        logger.exception("MS OIDC token exchange failed")
        return None, f"token exchange failed: {e}"
    if "error" in result:
        return None, result.get("error_description") or result.get("error")
    claims = result.get("id_token_claims") or {}
    # DIRECTORY LOOKUP TOKEN (User Management lookup: type a NAME, get the Schaeffler ID
    # instead of asking people for it). When MS_SCOPES requests a Graph scope
    # (User.ReadBasic.All), the exchange also returns a Graph access token - cache it per
    # signed-in user so /admin/user-directory/search can query on THEIR behalf. Entirely
    # inert while MS_SCOPES is empty (today's default): no token arrives, nothing is cached,
    # sign-in is byte-identical.
    try:
        _at = str(result.get("access_token") or "")
        if _at and MS_SCOPES:
            _uname = str(claims.get("preferred_username") or claims.get("upn") or "").lower()
            if _uname:
                _exp = time.time() + max(60, int(result.get("expires_in") or 3600) - 120)
                _GRAPH_TOKENS[_uname] = (_at, _exp)
    except Exception:
        logger.exception("graph token capture failed (sign-in unaffected)")
    return claims, None


# {username_lower: (graph_access_token, epoch_expiry)} - only populated when MS_SCOPES asks
# for a Graph scope. In-memory by design: worst case after a restart the admin signs in again.
_GRAPH_TOKENS: dict = {}


def graph_token_for(username: str) -> str:
    """The cached Graph token of this signed-in user, '' when absent or expired."""
    entry = _GRAPH_TOKENS.get(str(username or "").lower())
    if not entry:
        return ""
    token, exp = entry
    return token if time.time() < exp else ""


def extract_user(claims: dict) -> tuple:
    """Pull (username, name, role, roles_list) from the Microsoft ID-token claims."""
    username = (claims.get("preferred_username") or claims.get("upn")
                or claims.get("email") or claims.get("sub") or "")
    name = claims.get("name") or username
    roles = claims.get(MS_ROLE_CLAIM) or claims.get("roles") or claims.get("groups") or []
    if isinstance(roles, str):
        roles = [roles]
    role = roles[0] if roles else "user"   # default until the directory sends a role claim
    return username, name, role, list(roles)
