"""
Dashboard "Artifact Configuration" — RULES model APIs (updated UI contract).

  GET    /api/artifact-rules                    all rules + summary
  POST   /api/artifact-rules                    create one rule            (201)
  PUT    /api/artifact-rules/<ruleId>           update one complete rule
  PATCH  /api/artifact-rules/<ruleId>/status    enable / disable
  DELETE /api/artifact-rules/<ruleId>           delete (200 WITH payload — contract forbids 204)
  POST   /api/artifact-rules/reset-defaults     replace with default rules

Every successful operation returns the SAME complete payload as GET (rules + summary) so the
frontend synchronizes its table and summary directly, never needing a follow-up GET. Errors use
the contract's standard shape: {success:false, message, error:{code, fieldErrors}} with
400/404/409/422/500.

GET is open (the extension will read rules here after its migration); mutations are admin-only,
and the JWT identity feeds the createdBy/updatedBy audit fields.

The legacy /api/artifact-configurations GET remains alive for the shipped extension.
"""
import logging

from flask import Blueprint, jsonify, request, g

from src.services import artifact_rules as ar
from src.routes.auth_route import require_role, require_role_if_token

logger = logging.getLogger(__name__)
artifact_rules_bp = Blueprint("artifact_rules", __name__)


def _actor() -> str:
    claims = getattr(g, "user", None) or {}
    return str(claims.get("name") or claims.get("sub") or "dashboard")


def _ok(record=None, message="Artifact configuration retrieved successfully.", status=200):
    return jsonify({
        "success": True,
        "message": message,
        "data": ar.full_view(record),
    }), status


def _fail(exc: ar.ArtifactRuleError):
    return jsonify({
        "success": False,
        "message": exc.message,
        "error": {"code": exc.code, "fieldErrors": exc.field_errors},
    }), exc.http_status


@artifact_rules_bp.errorhandler(Exception)
def _unexpected(exc):
    if isinstance(exc, ar.ArtifactRuleError):
        return _fail(exc)
    logger.exception("artifact-rules unexpected error")
    return jsonify({
        "success": False,
        "message": "Unexpected server error.",
        "error": {"code": "ARTIFACT_RULE_SERVER_ERROR", "fieldErrors": {}},
    }), 500


@artifact_rules_bp.route("/api/artifact-rules", methods=["GET"])
@require_role_if_token("admin")
def artifact_rules_get():
    # Shared read since the extension's native rules service (next VSIX): tokenless extension
    # requests pass; dashboard users with a non-admin role get 403 + data: [] via the gate.
    return _ok()


@artifact_rules_bp.route("/api/artifact-rules", methods=["POST"])
@require_role("admin")
def artifact_rules_create():
    try:
        record = ar.create_rule(request.get_json(silent=True) or {}, by=_actor())
        return _ok(record, "Artifact rule created successfully.", 201)
    except ar.ArtifactRuleError as exc:
        return _fail(exc)


@artifact_rules_bp.route("/api/artifact-rules/<rule_id>", methods=["PUT"])
@require_role("admin")
def artifact_rules_update(rule_id):
    try:
        record = ar.update_rule(rule_id, request.get_json(silent=True) or {}, by=_actor())
        return _ok(record, "Artifact rule updated successfully.")
    except ar.ArtifactRuleError as exc:
        return _fail(exc)


@artifact_rules_bp.route("/api/artifact-rules/<rule_id>/status", methods=["PATCH"])
@require_role("admin")
def artifact_rules_status(rule_id):
    body = request.get_json(silent=True) or {}
    try:
        record = ar.set_rule_status(rule_id, body.get("enabled"), by=_actor())
        return _ok(record, "Artifact rule status updated successfully.")
    except ar.ArtifactRuleError as exc:
        return _fail(exc)


@artifact_rules_bp.route("/api/artifact-rules/<rule_id>", methods=["DELETE"])
@require_role("admin")
def artifact_rules_delete(rule_id):
    try:
        record = ar.delete_rule(rule_id, by=_actor())
        # Contract: HTTP 200 with the remaining rules + recalculated summary — never 204.
        return _ok(record, "Artifact rule deleted successfully.")
    except ar.ArtifactRuleError as exc:
        return _fail(exc)


@artifact_rules_bp.route("/api/artifact-rules/reset-defaults", methods=["POST"])
@require_role("admin")
def artifact_rules_reset():
    record = ar.reset_defaults(by=_actor())
    return _ok(record, "Artifact configuration reset to defaults.")
