"""
Dashboard "System Tracking Configuration" APIs (UI contract).

  GET    /api/system-tracking/patterns                 all tracking rules
  POST   /api/system-tracking/patterns                 add one rule              (201)
  PUT    /api/system-tracking/patterns/<id>            update one rule (full payload)
  PATCH  /api/system-tracking/patterns/<id>/status     enable / disable only
  DELETE /api/system-tracking/patterns/<id>            delete (200 WITH list — contract forbids 204)
  POST   /api/system-tracking/patterns/reset-defaults  Reset to Default button
                                                       (in the UI design; contract table omits it —
                                                       flagged to the UI team, additive if unused)

Every success returns the complete refreshed tracking_patterns list so the frontend replaces its
table state without a follow-up GET. Errors: {success:false, message, error:{code, field}}.

GET is open — the EXTENSION will read this config at build-cycle start once its integration
lands (fail-open to the hardcoded defaults, per the design doc). Mutations are admin-only.
"""
import logging

from flask import Blueprint, jsonify, request

from src.services import system_tracking as st
from src.routes.auth_route import require_role, require_role_if_token

logger = logging.getLogger(__name__)
system_tracking_bp = Blueprint("system_tracking", __name__)


def _ok(record=None, message="Tracking configuration retrieved successfully.", status=200):
    return jsonify({
        "success": True,
        "message": message,
        "data": st.full_view(record),
    }), status


def _fail(exc: st.TrackingPatternError):
    error = {"code": exc.code}
    if exc.field:
        error["field"] = exc.field
    return jsonify({"success": False, "message": exc.message, "error": error}), exc.http_status


@system_tracking_bp.errorhandler(Exception)
def _unexpected(exc):
    if isinstance(exc, st.TrackingPatternError):
        return _fail(exc)
    logger.exception("system-tracking unexpected error")
    return jsonify({
        "success": False,
        "message": "Unexpected server error.",
        "error": {"code": "TRACKING_PATTERN_SERVER_ERROR"},
    }), 500


@system_tracking_bp.route("/api/system-tracking/patterns", methods=["GET"])
@require_role_if_token("admin")
def tracking_patterns_get():
    # Shared read: the EXTENSION consumes this tokenlessly (TrackingConfigService) and must keep
    # working; dashboard users with a non-admin role get 403 + data: [] via the gate.
    return _ok()


@system_tracking_bp.route("/api/system-tracking/patterns", methods=["POST"])
@require_role("admin")
def tracking_patterns_add():
    try:
        record = st.add_pattern(request.get_json(silent=True) or {})
        return _ok(record, "Tracking pattern added successfully.", 201)
    except st.TrackingPatternError as exc:
        return _fail(exc)


@system_tracking_bp.route("/api/system-tracking/patterns/<pattern_id>", methods=["PUT"])
@require_role("admin")
def tracking_patterns_update(pattern_id):
    try:
        record = st.update_pattern(pattern_id, request.get_json(silent=True) or {})
        return _ok(record, "Tracking pattern updated successfully.")
    except st.TrackingPatternError as exc:
        return _fail(exc)


@system_tracking_bp.route("/api/system-tracking/patterns/<pattern_id>/status", methods=["PATCH"])
@require_role("admin")
def tracking_patterns_status(pattern_id):
    body = request.get_json(silent=True) or {}
    try:
        record = st.set_pattern_status(pattern_id, body.get("status"))
        return _ok(record, "Tracking pattern status updated successfully.")
    except st.TrackingPatternError as exc:
        return _fail(exc)


@system_tracking_bp.route("/api/system-tracking/patterns/<pattern_id>", methods=["DELETE"])
@require_role("admin")
def tracking_patterns_delete(pattern_id):
    try:
        record = st.delete_pattern(pattern_id)
        # Contract: 200 WITH the remaining list — never 204.
        return _ok(record, "Tracking pattern deleted successfully.")
    except st.TrackingPatternError as exc:
        return _fail(exc)


@system_tracking_bp.route("/api/system-tracking/patterns/reset-defaults", methods=["POST"])
@require_role("admin")
def tracking_patterns_reset():
    record = st.reset_defaults()
    return _ok(record, "Tracking configuration reset to defaults.")
