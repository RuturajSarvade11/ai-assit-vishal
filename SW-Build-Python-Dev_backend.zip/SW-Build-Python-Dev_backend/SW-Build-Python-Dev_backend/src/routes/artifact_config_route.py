"""
Dashboard "Artifact Configuration" admin page APIs (UI team spec).

  GET    /api/artifact-configurations                                   full screen data
  POST   /api/artifact-configurations/folders                           add folder (+initial patterns)
  PUT    /api/artifact-configurations/folders/<id>                      update name/path
  PATCH  /api/artifact-configurations/folders/<id>/status               enable/disable
  DELETE /api/artifact-configurations/folders/<id>                      delete folder (+its patterns)
  POST   /api/artifact-configurations/folders/<id>/patterns             add one pattern
  DELETE /api/artifact-configurations/folders/<id>/patterns/<pid>       delete one pattern

LEGACY: the dashboard moved to the RULES model — /api/artifact-rules
(artifact_rules_route.py). This folder-based family stays because the SHIPPED extension reads the
GET for artifact collection; it retires once the extension migrates to rules. The former
folder-options and reset routes were dashboard-only and are removed.

Per the spec, EVERY action responds with the updated complete configuration (same data structure
as the GET) so the frontend replaces its screen state with the response. No "Save" endpoint —
each action persists immediately.

GET is open (the extension reads this config at artifact-collection time, like
/build-prediction/config); all mutations require the admin role, matching the other Admin
Settings pages. Full schemas in /docs.
"""
from flask import Blueprint, jsonify, request

from src.services import artifact_config as ac
from src.routes.auth_route import require_role, require_role_if_token

artifact_config_bp = Blueprint("artifact_config", __name__)


def _ok(cfg=None, selected=None, message="Success", status=200):
    return jsonify({
        "success": True,
        "message": message,
        "data": ac.full_view(cfg, selected_folder_id=selected),
    }), status


def _fail(message, status):
    return jsonify({"success": False, "message": message, "data": None}), status


@artifact_config_bp.route("/api/artifact-configurations", methods=["GET"])
@require_role_if_token("admin")
def artifact_config_get():
    # Shared read: every fielded extension consumes this tokenlessly for artifact collection;
    # dashboard users with a non-admin role get 403 + data: [] via the gate.
    return _ok(message="Artifact configuration fetched successfully")


# REMOVED per the updated UI contract: the dashboard moved to the rules model
# (/api/artifact-rules, see artifact_rules_route.py), which needs no folder dropdown and has its
# own reset-defaults. The folder-options and reset routes below were dashboard-only (the shipped
# extension reads only the GET above), so dropping them breaks nothing in the field.


@artifact_config_bp.route("/api/artifact-configurations/folders", methods=["POST"])
@require_role("admin")
def artifact_config_add_folder():
    body = request.get_json(silent=True) or {}
    try:
        cfg, fid = ac.add_folder(body)
        return _ok(cfg, fid, "Folder added successfully", 201)
    except ValueError as exc:
        return _fail(str(exc), 400)


@artifact_config_bp.route("/api/artifact-configurations/folders/<folder_id>", methods=["PUT"])
@require_role("admin")
def artifact_config_update_folder(folder_id):
    body = request.get_json(silent=True) or {}
    try:
        cfg, fid = ac.update_folder(folder_id, body)
        return _ok(cfg, fid, "Folder updated successfully")
    except ac.ArtifactConfigNotFound as exc:
        return _fail(str(exc), 404)
    except ValueError as exc:
        return _fail(str(exc), 400)


@artifact_config_bp.route("/api/artifact-configurations/folders/<folder_id>/status", methods=["PATCH"])
@require_role("admin")
def artifact_config_folder_status(folder_id):
    body = request.get_json(silent=True) or {}
    try:
        cfg, fid = ac.set_folder_status(folder_id, body.get("is_enabled"))
        return _ok(cfg, fid, "Folder status updated successfully")
    except ac.ArtifactConfigNotFound as exc:
        return _fail(str(exc), 404)
    except ValueError as exc:
        return _fail(str(exc), 400)


@artifact_config_bp.route("/api/artifact-configurations/folders/<folder_id>", methods=["DELETE"])
@require_role("admin")
def artifact_config_delete_folder(folder_id):
    try:
        cfg, fid = ac.delete_folder(folder_id)
        return _ok(cfg, fid, "Folder deleted successfully")
    except ac.ArtifactConfigNotFound as exc:
        return _fail(str(exc), 404)


@artifact_config_bp.route("/api/artifact-configurations/folders/<folder_id>/patterns", methods=["POST"])
@require_role("admin")
def artifact_config_add_pattern(folder_id):
    body = request.get_json(silent=True) or {}
    try:
        cfg, fid = ac.add_pattern(folder_id, body)
        return _ok(cfg, fid, "Pattern added successfully", 201)
    except ac.ArtifactConfigNotFound as exc:
        return _fail(str(exc), 404)
    except ValueError as exc:
        return _fail(str(exc), 400)


@artifact_config_bp.route(
    "/api/artifact-configurations/folders/<folder_id>/patterns/<pattern_id>", methods=["DELETE"])
@require_role("admin")
def artifact_config_delete_pattern(folder_id, pattern_id):
    try:
        cfg, fid = ac.delete_pattern(folder_id, pattern_id)
        return _ok(cfg, fid, "Pattern deleted successfully")
    except ac.ArtifactConfigNotFound as exc:
        return _fail(str(exc), 404)


