﻿# src/routes/route.py

import os
import json
import time
import uuid
from datetime import timedelta, UTC, datetime
import re
from flask import Flask, jsonify, request, send_from_directory, abort, send_file, g, has_request_context
from flask_cors import CORS
from werkzeug.utils import secure_filename
from werkzeug.exceptions import HTTPException
from urllib.parse import unquote
from src.services import handlers
from src.configurations import config
from src.utils.recommended import get_files_by_batch_id
from src.utils.payload_archive import upload_binary_artifact_zip, upload_task_runtime_artifact_zip, download_s3_zip_bytes
from src.utils.project_details import save_artifact_reference, get_artifact_references
from src.utils.content_fingerprint import content_fingerprint_for_bytes, prepare_artifact_for_storage
from src.routes.auth_route import require_role, require_role_if_token
import logging


class SafeRequestFormatter(logging.Formatter):
    def format(self, record):
        if not hasattr(record, "request_id"):
            record.request_id = "-"
        if not hasattr(record, "duration_ms"):
            record.duration_ms = "-"
        return super().format(record)


LOG_FORMAT = (
    "%(asctime)s | %(levelname)s | %(name)s | "
    "request_id=%(request_id)s | duration_ms=%(duration_ms)s | %(message)s"
)
logging.basicConfig(
    level=logging.INFO,
    format=LOG_FORMAT,
)
for _handler in logging.getLogger().handlers:
    _handler.setFormatter(SafeRequestFormatter(LOG_FORMAT))
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] =1024*1024*1024
# Allow the dashboard (served from a different port/origin) + Swagger to call the API, including the
# preflight (OPTIONS) for POST/PUT/DELETE and the Authorization header. supports_credentials with
# origins="*" makes flask-cors echo the caller's Origin (valid even when the frontend sends credentials,
# where a literal "*" would be rejected by the browser).
CORS(
    app,
    resources={r"/*": {"origins": "*"}},
    supports_credentials=True,
    allow_headers=["Content-Type", "Authorization", "X-Request-Id", "Accept"],
    expose_headers=["X-Request-Id"],
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
)

# W Adapter live POC endpoints (additive: /w-poc/recommend, /w-poc/feedback)
from src.routes.w_poc_route import w_poc_bp
app.register_blueprint(w_poc_bp)

# Dashboard auth endpoints (additive: /auth/login, /auth/set-password, /auth/me)
from src.routes.auth_route import auth_bp
app.register_blueprint(auth_bp)

# Live API docs for the UI developer (additive: /docs Swagger UI, /openapi.json)
from src.routes.docs_route import docs_bp
app.register_blueprint(docs_bp)

# W-adapter ON/OFF switch (additive: /admin/adapter-status, /admin/adapter-toggle)
from src.routes.admin_route import admin_bp
app.register_blueprint(admin_bp)

# Build prediction endpoints (/build-prediction/extension-files, /build-prediction/file-data)
from src.build_prediction.routes import build_prediction_bp
app.register_blueprint(build_prediction_bp)

# Artifact Configuration admin page (additive: /api/artifact-configurations*)
from src.routes.artifact_config_route import artifact_config_bp
app.register_blueprint(artifact_config_bp)

# Artifact Configuration RULES model (updated UI contract: /api/artifact-rules*).
# The legacy folder-based GET above stays alive for the shipped extension.
from src.routes.artifact_rules_route import artifact_rules_bp
app.register_blueprint(artifact_rules_bp)

# System Tracking Configuration (UI contract: /api/system-tracking/patterns*) —
# the admin-configurable file-change-tracking inclusion list.
from src.routes.system_tracking_route import system_tracking_bp
app.register_blueprint(system_tracking_bp)

# Self-running W trainer (no-op unless AUTO_TRAIN_ENABLED=1)
from src.services.adapter_trainer import start_auto_trainer
start_auto_trainer()

# UPLOAD_DIR = "./uploads"
# os.makedirs(UPLOAD_DIR, exist_ok=True)
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # src/routes
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, "..", ".."))
UPLOAD_DIR = os.path.join(PROJECT_ROOT, "uploads")

os.makedirs(UPLOAD_DIR, exist_ok=True)


def _current_request_id() -> str | None:
    return getattr(g, "request_id", None) if has_request_context() else None


def _resolve_actor_id() -> str:
    header_candidates = [
        request.headers.get("X-Actor-Id"),
        request.headers.get("X-User-Id"),
        request.headers.get("X-Authenticated-User"),
        request.headers.get("X-MS-CLIENT-PRINCIPAL-ID"),
    ]
    for raw in header_candidates:
        value = (raw or "").strip()
        if value:
            return value
    return "unknown"


def _error_response(error: Exception, status_code: int = 500):
    duration_ms = int((time.perf_counter() - getattr(g, "_start_time", time.perf_counter())) * 1000)
    logger.exception(
        "Request failed",
        extra={
            "request_id": _current_request_id(),
            "method": request.method,
            "path": request.path,
            "duration_ms": duration_ms,
        },
    )
    return jsonify(
        {
            "success": False,
            "error": str(error),
            "request_id": _current_request_id(),
        }
    ), status_code


@app.before_request
def _before_request():
    g.request_id = request.headers.get("X-Request-Id") or str(uuid.uuid4())
    g._start_time = time.perf_counter()
    logger.info(
        "Request started",
        extra={
            "request_id": g.request_id,
            "method": request.method,
            "path": request.path,
        },
    )


@app.after_request
def _after_request(response):
    rid = _current_request_id()
    if rid:
        response.headers["X-Request-Id"] = rid
    duration_ms = int((time.perf_counter() - getattr(g, "_start_time", time.perf_counter())) * 1000)
    logger.info(
        "Request completed",
        extra={
            "request_id": rid,
            "method": request.method,
            "path": request.path,
            "status_code": response.status_code,
            "duration_ms": duration_ms,
        },
    )
    return response


@app.errorhandler(Exception)
def _on_unhandled_error(error: Exception):
    return _error_response(error, 500)


@app.errorhandler(HTTPException)
def _on_http_error(error: HTTPException):
    duration_ms = int((time.perf_counter() - getattr(g, "_start_time", time.perf_counter())) * 1000)
    logger.exception(
        "HTTP exception",
        extra={
            "request_id": _current_request_id(),
            "method": request.method,
            "path": request.path,
            "duration_ms": duration_ms,
        },
    )
    return jsonify(
        {
            "success": False,
            "error": error.description,
            "request_id": _current_request_id(),
        }
    ), error.code or 500


# --------------------------------------------------
# BASIC
# --------------------------------------------------

@app.route("/")
def home():
    return "OK"



@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "service": "bsw-python-backend"
    }), 200


@app.route("/health/upload", methods=["GET"])
def health_upload():
    result = handlers.handle_upload_health_check()
    status_code = 200 if result.get("s3_ok") else 503
    return jsonify(result), status_code



@app.route("/login", methods=["POST"])
def login():
    try:
        if not request.is_json:
            return jsonify({"success": False, "error": "Content-Type must be application/json"}), 400
        payload = request.get_json(silent=True) or {}
        result = handlers.handle_login(payload)
        status = 200 if result.get("success") else 401
        return jsonify(result), status
    except Exception as e:
        return _error_response(e, 500)
# --------------------------------------------------
# FINAL BUILD
# --------------------------------------------------

@app.route("/final-build", methods=["POST"])
def final_build():
    try:
        # Keep this endpoint lightweight and predictable under concurrency.
        max_body_bytes = 5 * 1024 * 1024
        if request.content_length and request.content_length > max_body_bytes:
            return jsonify({
                "success": False,
                "error": "Payload too large for /final-build. Max allowed is 5 MB."
            }), 413

        if not request.is_json:
            return jsonify({
                "success": False,
                "error": "Content-Type must be application/json"
            }), 400

        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({
                "success": False,
                "error": "Invalid JSON body"
            }), 400

        required_keys = ("solution", "projectName", "taskName")
        missing_keys = [k for k in required_keys if k not in payload]
        if missing_keys:
            return jsonify({
                "success": False,
                "error": f"Missing required keys: {', '.join(missing_keys)}"
            }), 400

        if not isinstance(payload.get("solution"), list):
            return jsonify({
                "success": False,
                "error": "solution must be an array"
            }), 400
        if not payload.get("projectName") or not isinstance(payload.get("projectName"), str):
            return jsonify({
                "success": False,
                "error": "projectName must be a non-empty string"
            }), 400
        if not payload.get("taskName") or not isinstance(payload.get("taskName"), str):
            return jsonify({
                "success": False,
                "error": "taskName must be a non-empty string"
            }), 400

        solution_count = len(payload.get("solution", []))
        error_details = payload.get("errorDetails") if isinstance(payload.get("errorDetails"), list) else []
        error_count = len(error_details)
        error_chars = sum(len(str((e or {}).get("message", ""))) for e in error_details if isinstance(e, dict))
        batch_uuid = str(payload.get("uuid") or "")
        logger.info(
            "/final-build called | batch=%s | projectName=%s | taskName=%s | solution_count=%s | "
            "error_count=%s | error_chars=%s | projectType=%s",
            batch_uuid,
            payload.get("projectName"),
            payload.get("taskName"),
            solution_count,
            error_count,
            error_chars,
            payload.get("projectType"),
        )
        # Flag the client-reported "empty payload" bug: a request being created with no real
        # error content. Correlate this WARNING with the extension's PRE-UPLOAD snapshot by batch uuid.
        if error_count == 0 or error_chars == 0:
            logger.warning(
                "/final-build EMPTY-ERROR payload — request will be created with no error content | "
                "batch=%s | projectName=%s | taskName=%s | solution_count=%s",
                batch_uuid,
                payload.get("projectName"),
                payload.get("taskName"),
                solution_count,
            )

        payload["username"] = payload.get("developer_id") or _resolve_actor_id()
        result = handlers.handle_final_build(payload)

        # Adoption counting. One build = one count, keyed on the installation
        # id VS Code creates, which is not derived from any person. Older extensions send no
        # installId and are simply not counted - they are never guessed at. The developer login
        # is only read when EXT_IDENTITY_CAPTURE is on, and is sealed before it is stored.
        try:
            from src.services import extension_usage as _eu
            _install_id = str(payload.get("installId") or "").strip()
            if not _install_id:
                # Say so. An extension older than this change sends no installId, so the usage
                # tab stays empty - and with a silent skip there was nothing in the log to
                # explain why, which turns "the VSIX has not been handed out" into a hunt.
                logger.info("[ext-usage] no installId on this upload - usage not counted "
                            "(extension predates adoption reporting) | project=%s",
                            payload.get("projectName"))
            if _install_id:
                _eu.record_build(
                    install_id=_install_id,
                    project_name=str(payload.get("projectName") or ""),
                    ext_version=str(payload.get("extVersion") or ""),
                    env_kind=str(payload.get("envKind") or ""),
                    # An identifier the extension derived on its own machine - never a login.
                    # Deliberately NOT developer_id: that field already feeds payload["username"]
                    # on every stored record, and reusing it would change what is written for
                    # existing data.
                    developer_key=str(payload.get("usageKey") or ""),
                    failed=error_count > 0,
                )
        except Exception:
            logger.exception("extension usage counting failed - build unaffected")

        logger.info("/final-build completed successfully")
        return jsonify(result), 200

    except Exception as e:
        return _error_response(e, 500)


@app.route("/upload-precheck", methods=["POST"])
def upload_precheck():
    """Extension asks BEFORE opening the confirm webview whether this upload would be a
    full duplicate (storage proposal §7). Always answers 200; on any problem it answers
    skip_upload=False so the popup opens as today (fail-open, never blocks an upload)."""
    try:
        payload = request.get_json(silent=True)
        result = handlers.handle_upload_precheck(payload if isinstance(payload, dict) else {})
        return jsonify(result), 200
    except Exception as e:
        logger.warning("upload-precheck failed — answering fail-open | %s", e)
        return jsonify({"status": True, "duplicate": False, "skip_upload": False}), 200


@app.route("/final-build/<request_id>/resolution-description", methods=["POST"])
def update_final_build_resolution_description(request_id):
    try:
        if not request.is_json:
            return jsonify({
                "success": False,
                "error": "Content-Type must be application/json"
            }), 400

        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({
                "success": False,
                "error": "Invalid JSON body"
            }), 400

        description = payload.get("description")
        if description is not None and not isinstance(description, str):
            return jsonify({
                "success": False,
                "error": "description must be a string or null"
            }), 400

        result = handlers.handle_update_final_build_resolution_description(request_id, description)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except Exception as e:
        return _error_response(e, 500)


@app.route("/archive-payload", methods=["POST"])
@app.route("/archive-payload/<request_id>", methods=["POST"])
@app.route("/archive-payload/<request_id>/<int:is_last>", methods=["POST"])
def archive_payload(request_id=None, is_last=0):
    try:
        if not request.is_json:
            return jsonify({
                "success": False,
                "error": "Content-Type must be application/json"
            }), 400

        payload = request.get_json(silent=True)
        sync_finalize = str(request.args.get("sync", "0")).strip().lower() in ("1", "true", "yes")
        force_finalize = str(request.args.get("retry", "0")).strip().lower() in ("1", "true", "yes")
        developer_id = str(payload.get("developer_id") or "").strip() if isinstance(payload, dict) else ""

        result = handlers.handle_archive_payload(
            payload,
            request_id=request_id,
            is_last=bool(is_last),
            sync_finalize=sync_finalize,
            force_finalize=force_finalize,
            developer_id=developer_id,
        )
        return jsonify(result), 200
    except Exception as e:
        return _error_response(e, 500)


@app.route("/archive-payload/<request_id>/retry", methods=["POST"])
def retry_archive_payload(request_id):
    try:
        if not request.is_json:
            return jsonify({"success": False, "error": "Content-Type must be application/json"}), 400

        payload = request.get_json(silent=True)
        developer_id = str(payload.get("developer_id") or "").strip() if isinstance(payload, dict) else ""
        result = handlers.handle_retry_archive_payload(
            payload,
            request_id=request_id,
            developer_id=developer_id,
        )
        return jsonify(result), 200
    except Exception as e:
        return _error_response(e, 500)


@app.route("/archive-payload/<request_id>", methods=["GET"])
def get_archived_payload(request_id):
    try:
        result = handlers.handle_get_archived_payload(request_id)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except Exception as e:
        return _error_response(e, 500)


@app.route("/archive-payload/<request_id>/vector-status", methods=["GET"])
def get_archive_vector_status(request_id):
    try:
        result = handlers.handle_get_vectorization_status(request_id)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except Exception as e:
        return _error_response(e, 500)

from src.utils.oai_client import create_embedding

@app.route("/ping", methods=["GET"])
def ping():
    return jsonify({
        "success": True,
        "message": "ok",
        "request_id": _current_request_id(),
    }), 200


@app.route("/ping/deep", methods=["GET"])
def ping_deep():
    try:
        logger.info("/ping/deep called - testing embedding service")

        result = create_embedding("HELLO", request_id=_current_request_id())

        if not result:
            logger.error("Embedding returned empty result")
            return jsonify({
                "success": False,
                "message": "Embedding failed or returned empty result"
            }), 500

        logger.info(f"Embedding success — length={len(result)}")

        return jsonify({
            "success": True,
            "message": "Embedding service is working",
            "embedding_length": len(result),
            "request_id": _current_request_id(),
        }), 200

    except Exception as e:
        return _error_response(e, 500)


def _is_empty_artifact_content(content: bytes, file_name: str) -> bool:
    """EMPTY artifacts (zero bytes, or whitespace-only text) carry no failure signal — the S3 audit
    showed 22% of uploaded artifacts were empty. Server-side guard so even older extension builds
    can't store them (the extension also skips them at capture)."""
    if not content:
        return True
    lower = (file_name or "").strip().lower()
    if lower.endswith((".txt", ".log")):
        try:
            return not content.decode("utf-8", errors="replace").strip()
        except Exception:
            return False
    return False


# --------------------------------------------------
# BINARY STORE (multipart version - Flask only)
# --------------------------------------------------

@app.route("/binary-store", methods=["POST"])
def binary_store():

    # If JSON body → delegate to handler
    if request.is_json:
        result = handlers.handle_binary_store(request.get_json())
        return jsonify(result), 200

    # Otherwise assume multipart
    batch_id = request.form.get("uuid")
    request_id = str(request.form.get("request_id") or "").strip()
    developer_id = str(request.form.get("developer_id") or request.form.get("username") or "").strip()
    metadata_str = request.form.get("metadata")

    if not batch_id:
        return jsonify({"error": "uuid required"}), 400

    if "files" not in request.files:
        return jsonify({"error": "No files provided"}), 400

    files = request.files.getlist("files")
    metadata_list = []
    project_name = (request.form.get("project_name") or "").strip().lower()

    if metadata_str:
        metadata_list = json.loads(metadata_str)

    metadata_map = {}
    for m in metadata_list:
        if not isinstance(m, dict):
            continue
        file_key = str(m.get("fileName") or "").strip()
        if file_key:
            metadata_map[file_key] = m
    stored_files = []

    # Storage proposal: identical artifact content (after timestamp/volatile cleaning) is
    # stored once per request — a re-upload references the existing copy instead of writing
    # a second S3 object. Legacy rows without a fingerprint never match, so nothing is lost.
    known_fp_pairs = set()
    if request_id:
        for ref in get_artifact_references(request_id, "binary"):
            known_fp = str((ref or {}).get("content_fingerprint") or "").strip()
            if known_fp:
                known_fp_pairs.add((str(ref.get("file_name") or "").strip(), known_fp))

    for file in files:
        original_name = secure_filename(file.filename)
        meta = metadata_map.get(original_name, {})
        if not meta and original_name.startswith("DELETED_"):
            meta = metadata_map.get(original_name[len("DELETED_"):], {})
        action = str(meta.get("action") or "modified")
        content = file.read()
        if _is_empty_artifact_content(content, original_name):
            logger.info("binary artifact '%s' skipped — empty content (no failure signal)", original_name)
            continue
        intended_name = str(meta.get("originalFileName") or original_name)
        # Review decision: text artifacts are STORED display-cleaned (no timestamps on the
        # dashboard); the fingerprint stays computed from the original capture for dedup.
        content, fingerprint = prepare_artifact_for_storage(content, intended_name)
        if request_id and (intended_name, fingerprint) in known_fp_pairs:
            logger.info(
                "binary artifact '%s' skipped — identical content already stored for request %s (fp=%s)",
                original_name, request_id, fingerprint[:12],
            )
            continue
        archive = upload_binary_artifact_zip(
            batch_id=batch_id,
            file_name=intended_name,
            file_bytes=content,
            action=action,
            project_name=project_name,
        )
        stored_files.append(archive.get("s3_key"))
        if request_id and archive.get("s3_key"):
            save_artifact_reference(
                request_id=request_id,
                file_name=archive.get("file_name") or original_name,
                s3_key=archive.get("s3_key"),
                s3_bucket=config.S3_BUCKET,
                artifact_type="binary",
                content_fingerprint=fingerprint,
                evidence_eligible=not handlers._artifact_claimed_by_another_solution(
                    project_name, request_id, content, original_name),
            )
            known_fp_pairs.add((intended_name, fingerprint))
        try:
            embed_result = handlers.handle_artifact_text_embedding(
                project_name=project_name,
                file_name=str(meta.get("originalFileName") or original_name),
                file_bytes=content,
                s3_key=archive.get("s3_key") or "",
                batch_id=batch_id,
                request_id=request_id,
                artifact_type="binary",
                action=action,
                developer_id=developer_id,
                # Review gap (storage audit): binary summaries stored task_path="" so the
                # task-scoped learned-space filters never matched them. Pass it when the
                # uploader provides it; harmless "" otherwise.
                task_path=str(meta.get("taskPath") or meta.get("task_path") or ""),
            )
            if embed_result.get("success"):
                logger.debug(
                    "binary_store | artifact embeddings stored | file_name=%s | collection=%s | count=%d",
                    original_name,
                    embed_result.get("collection_name"),
                    embed_result.get("count", 0),
                )
            elif not embed_result.get("skipped"):
                logger.debug(
                    "binary_store | artifact embedding not stored | file_name=%s | reason=%s",
                    original_name,
                    embed_result.get("error") or embed_result.get("reason"),
                )
        except Exception:
            logger.exception("binary_store | failed to store artifact embeddings | file_name=%s", original_name)

    return jsonify({
        "message": "Files stored successfully",
        "batch_id": batch_id,
        "stored_files": stored_files
    }), 200


@app.route("/task-runtime-artifacts", methods=["POST"])
def task_runtime_artifacts():

    if request.is_json:
        result = handlers.handle_task_runtime_artifacts(request.get_json())
        return jsonify(result), 200

    batch_id = request.form.get("uuid")
    request_id = str(request.form.get("request_id") or "").strip()
    developer_id = str(request.form.get("developer_id") or request.form.get("username") or "").strip()
    metadata_str = request.form.get("metadata")

    if not batch_id:
        return jsonify({"error": "uuid required"}), 400

    if "files" not in request.files:
        return jsonify({"error": "No files provided"}), 400

    files = request.files.getlist("files")
    metadata_list = []
    project_name = (request.form.get("project_name") or "").strip().lower()

    if metadata_str:
        metadata_list = json.loads(metadata_str)

    metadata_map = {}
    for m in metadata_list:
        if not isinstance(m, dict):
            continue
        file_key = str(m.get("fileName") or "").strip()
        if file_key:
            metadata_map[file_key] = m
    stored_files = []

    # Same cleaned-content dedup as /binary-store (storage proposal): identical runtime
    # artifact content for this request is referenced, not re-stored.
    known_fp_pairs = set()
    if request_id:
        for ref in get_artifact_references(request_id, "runtime"):
            known_fp = str((ref or {}).get("content_fingerprint") or "").strip()
            if known_fp:
                known_fp_pairs.add((str(ref.get("file_name") or "").strip(), known_fp))

    for file in files:
        original_name = secure_filename(file.filename)
        meta = metadata_map.get(original_name, {})
        if not meta and original_name.startswith("DELETED_"):
            meta = metadata_map.get(original_name[len("DELETED_"):], {})
        action = str(meta.get("action") or "modified")
        content = file.read()
        if _is_empty_artifact_content(content, original_name):
            logger.info("runtime artifact '%s' skipped — empty content (no failure signal)", original_name)
            continue
        intended_name = str(meta.get("originalFileName") or original_name)
        # Same as /binary-store: store display-cleaned text, fingerprint the original capture.
        content, fingerprint = prepare_artifact_for_storage(content, intended_name)
        if request_id and (intended_name, fingerprint) in known_fp_pairs:
            logger.info(
                "runtime artifact '%s' skipped — identical content already stored for request %s (fp=%s)",
                original_name, request_id, fingerprint[:12],
            )
            continue
        archive = upload_task_runtime_artifact_zip(
            batch_id=batch_id,
            file_name=intended_name,
            file_bytes=content,
            action=action,
            project_name=project_name,
            source_folder=str(meta.get("sourceFolder") or ""),
            task_path=str(meta.get("taskPath") or ""),
        )
        stored_files.append(archive.get("s3_key"))
        if request_id and archive.get("s3_key"):
            save_artifact_reference(
                request_id=request_id,
                file_name=archive.get("file_name") or original_name,
                s3_key=archive.get("s3_key"),
                s3_bucket=config.S3_BUCKET,
                artifact_type="runtime",
                content_fingerprint=fingerprint,
                evidence_eligible=not handlers._artifact_claimed_by_another_solution(
                    project_name, request_id, content, original_name),
            )
            known_fp_pairs.add((intended_name, fingerprint))
        try:
            embed_result = handlers.handle_artifact_text_embedding(
                project_name=project_name,
                file_name=str(meta.get("originalFileName") or original_name),
                file_bytes=content,
                s3_key=archive.get("s3_key") or "",
                batch_id=batch_id,
                request_id=request_id,
                artifact_type="runtime",
                action=action,
                source_folder=str(meta.get("sourceFolder") or ""),
                task_path=str(meta.get("taskPath") or ""),
                developer_id=developer_id,
            )
            if embed_result.get("success"):
                logger.debug(
                    "task_runtime_artifacts | artifact embeddings stored | file_name=%s | collection=%s | count=%d",
                    original_name,
                    embed_result.get("collection_name"),
                    embed_result.get("count", 0),
                )
            elif not embed_result.get("skipped"):
                logger.debug(
                    "task_runtime_artifacts | artifact embedding not stored | file_name=%s | reason=%s",
                    original_name,
                    embed_result.get("error") or embed_result.get("reason"),
                )
        except Exception:
            logger.exception("task_runtime_artifacts | failed to store artifact embeddings | file_name=%s", original_name)

    if request_id and stored_files:
        try:
            handlers._enqueue_vectorization(request_id, force=True)
            logger.debug(
                "task_runtime_artifacts | re-enqueued vectorization | request_id=%s | files=%d",
                request_id, len(stored_files),
            )
        except Exception:
            logger.exception(
                "task_runtime_artifacts | failed to re-enqueue vectorization | request_id=%s", request_id
            )

    return jsonify({
        "message": "Runtime artifacts stored successfully",
        "batch_id": batch_id,
        "stored_files": stored_files
    }), 200



# --------------------------------------------------
# DASHBOARD
# --------------------------------------------------

@app.route("/get-all-projects", methods=["GET"])
def get_projects():
    return jsonify(handlers.handle_get_projects()), 200


# ---- Dashboard grouped view (SEPARATE from the admin config panel). Reflects admin-configured groups. ----
@app.route("/project-groups/summary", methods=["GET"])
def project_groups_summary():
    # Each group (defined + Other) with its project count.
    return jsonify(handlers.handle_project_group_summary()), 200


@app.route("/project-groups/projects", methods=["GET"])
def project_groups_projects():
    # Projects in a group, newest first. Omit limit (or <=0) to get ALL (the "View All" case).
    # search = case-insensitive substring on project name, applied before limit.
    group_type = request.args.get("groupType") or request.args.get("groupName") or ""
    search = request.args.get("search") or request.args.get("searchText") or request.args.get("q") or ""
    try:
        limit = int(request.args.get("limit") or 0)
    except (TypeError, ValueError):
        limit = 0
    return jsonify(handlers.handle_projects_by_group(group_type, limit, search=search)), 200


@app.route("/project-groups/dashboard", methods=["GET"])
def project_groups_dashboard():
    # Dashboard load: every group (+ Other) with its project COUNT only, recent group first.
    try:
        limit = int(request.args.get("limit") or 4)
    except (TypeError, ValueError):
        limit = 4
    return jsonify(handlers.handle_grouped_dashboard(limit)), 200


@app.route("/recommendation-trace/<request_id>", methods=["GET"])
@require_role("owner", "admin")
def recommendation_trace_for_request(request_id):
    # Paste a request id -> the decision chains in which its solution
    # was recommended (query, every candidate with real scores, threshold, adapter state,
    # what was shown). Team/debug only - never part of the user-facing display.
    from src.utils import recommendation_trace
    # The table view: the matched artifact and its similarity are left out (for_table).
    traces = recommendation_trace.for_table(recommendation_trace.get_traces_for_request(request_id))
    token_usage = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0, "llm_calls": 0}
    try:
        from src.utils import project_details
        token_usage = project_details.get_token_usage_for_request(request_id)
        if token_usage.get("llm_calls"):
            return jsonify({"success": True, "request_id": request_id,
                            "recommendation_token_usage": token_usage,
                            "traces": traces}), 200
        project_names = {str(trace.get("project_name") or "").strip()
                         for trace in traces if trace.get("project_name")}
        explicit_project = str(request.args.get("projectName") or "").strip()
        if explicit_project:
            project_names.add(explicit_project)
        if not project_names:
            request_payload = project_details.get_final_build_payload(request_id) or {}
            request_project = str(request_payload.get("project_name") or "").strip()
            if request_project:
                project_names.add(request_project)
        for project_name in project_names:
            usage = project_details.get_token_usage_map_for_project(project_name).get(request_id, {})
            for key in token_usage:
                token_usage[key] += int(usage.get(key) or 0)
    except Exception:
        logger.exception("Failed to get recommendation token usage for request=%s", request_id)
    return jsonify({"success": True, "request_id": request_id,
                    "recommendation_token_usage": token_usage,
                    "traces": traces}), 200


@app.route("/recommendation-trace/<trace_id>/explain/<request_id>", methods=["GET"])
@require_role("owner", "admin")
def recommendation_trace_explain(trace_id, request_id):
    # The breakdown goes one level deeper than the trace - how each step and each number came
    # about. It is not displayed on the dashboard by default, only where debugging needs it, and
    # the values are calculated at click time rather than kept pre-calculated.
    # So this is a request-time recomputation, not a stored explanation, and it runs through the
    # same scoring function that produced the number in the first place.
    return jsonify(handlers.handle_trace_explain(trace_id, request_id)), 200


@app.route("/recommendation-traces/recent", methods=["GET"])
@require_role("owner", "admin")
def recommendation_traces_recent():
    from src.utils import recommendation_trace
    limit = request.args.get("limit") or 25
    return jsonify({"success": True,
                    "traces": recommendation_trace.for_table(
                        recommendation_trace.list_recent(int(limit)))}), 200


@app.route("/adapter-impact", methods=["GET"])
def adapter_impact():
    # Dashboard: the feedback-loop impact number - helpful-rate with the W
    # adapter on vs off, optional ?project= narrows to one project.
    return jsonify(handlers.handle_adapter_impact(request.args.get("project") or "")), 200


@app.route("/extension-usage", methods=["GET"])
@require_role("owner", "admin")
def extension_usage():
    # A tab under User Management showing who uses the extension and
    # how much. Three blocks with different privacy answers - adoption (installation ids, no
    # personal data), value (records we already keep, nothing new), and the per-developer list
    # (personal data, off unless EXT_IDENTITY_CAPTURE is set and approval is in place).
    from src.services import extension_usage as _eu
    try:
        days = int(request.args.get("days") or _eu.DEFAULT_WINDOW_DAYS)
    except (TypeError, ValueError):
        days = _eu.DEFAULT_WINDOW_DAYS
    # The Refresh button: drop the cached table pass so the figures are read again now.
    refresh = str(request.args.get("refresh") or "").strip().lower() in ("1", "true", "yes")
    return jsonify(_eu.compute_kpis(days=days,
                                    project=request.args.get("project") or "",
                                    group=request.args.get("group") or "",
                                    refresh=refresh)), 200


@app.route("/extension-usage/ping", methods=["POST"])
def extension_usage_ping():
    # An installation announcing itself, sent once per installed version - NOT a heartbeat.
    # Without it "who installed but never used it" cannot be answered, because a usage record
    # only exists once a build completes. Unauthenticated like the other extension endpoints,
    # and it can only ever create or refresh one profile row.
    from src.services import extension_usage as _eu
    payload = request.get_json(silent=True) or {}
    install_id = str(payload.get("installId") or "").strip()
    if not install_id:
        return jsonify({"status": False, "error": "installId is required"}), 400
    ok = _eu.record_install(
        install_id=install_id,
        ext_version=str(payload.get("extVersion") or ""),
        env_kind=str(payload.get("envKind") or ""),
        developer_key=str(payload.get("usageKey") or ""),
    )
    return jsonify({"status": bool(ok)}), 200


@app.route("/extension-usage/build", methods=["POST"])
def extension_usage_build():
    # The usage page must show, for a period, how many builds happened and how
    # many failed. Until now the server only heard about a build when a FIX was uploaded, so
    # "builds" undercounted every build that never failed. The extension now reports each build
    # outcome it parses (report.html / TD5 log), success or failure - a count, keyed on the
    # installation id like every other usage row. Unauthenticated like the other extension
    # endpoints; it can only ever add to two counters.
    from src.services import extension_usage as _eu
    payload = request.get_json(silent=True) or {}
    install_id = str(payload.get("installId") or "").strip()
    if not install_id:
        return jsonify({"status": False, "error": "installId is required"}), 400
    ok = _eu.record_build_seen(
        install_id=install_id,
        project_name=str(payload.get("projectName") or ""),
        ext_version=str(payload.get("extVersion") or ""),
        env_kind=str(payload.get("envKind") or ""),
        developer_key=str(payload.get("usageKey") or ""),
        failed=bool(payload.get("failed")),
        issues=payload.get("issues") or 0,
        # Optional record of THIS build {buildId, startedAt, finishedAt, durationSec, taskName}:
        # the Extension Usage drill-down lists builds one by one, and counters cannot say which.
        build=payload.get("build"),
    )
    return jsonify({"status": bool(ok)}), 200


@app.route("/extension-usage/forget", methods=["POST"])
@require_role("owner", "admin")
def extension_usage_forget():
    # Erasure: removes the link between the stored value and a person. The usage counters stay,
    # so the adoption trend is undamaged and those rows can never again be traced to anyone.
    from src.services import extension_usage as _eu
    from src.utils.project_details import clear_extension_identity
    payload = request.get_json(silent=True) or {}
    login = str(payload.get("login") or "").strip()
    if not login:
        return jsonify({"success": False, "error": "login is required"}), 400
    cleared = clear_extension_identity(_eu.seal(login))
    logger.info("[ext-usage] identity link removed | profiles_cleared=%d", cleared)
    return jsonify({"success": True, "profiles_cleared": cleared}), 200


@app.route("/graphData", methods=["GET"])
def graph_data():
    # Dashboard graph: per-project error/recommended counts for a date range, optional group filter
    # (groupName=ALL or omitted => all projects) and optional single-project filter (projectName —
    # the chart filter must be able to narrow to ONE project, groups alone could not).
    return jsonify(handlers.handle_graph_data(
        from_date=request.args.get("fromDate"),
        to_date=request.args.get("toDate"),
        group_name=request.args.get("groupName"),
        project_name=request.args.get("projectName"),
        page_number=request.args.get("pageNumber"),
        page_size=request.args.get("pageSize"),
        # groupBy=group rolls the bars up to project GROUP. Omitted => per project,
        # exactly as before.
        group_by=request.args.get("groupBy"),
    )), 200


# ---- Recommendation Configuration (admin): the relevance threshold ----
@app.route("/recommendation-config", methods=["GET"])
@require_role_if_token("owner", "admin")
def get_recommendation_config():
    from src.services import recommendation_config as rc
    return jsonify({"success": True, "data": rc.get_config()}), 200


@app.route("/recommendation-accuracy", methods=["GET"])
@require_role("owner", "admin")
def get_recommendation_accuracy():
    """Hit@1 / Hit@3 / in-pool rate / MRR of recommendations, measured against the fixes
    developers actually uploaded afterwards. ?project_name=<p>&days=<n> (default 30)."""
    from src.services import recommendation_accuracy as ra
    try:
        days = int(request.args.get("days") or 30)
    except ValueError:
        days = 30
    project = (request.args.get("project_name") or "").strip()
    return jsonify({"success": True, "data": ra.get_summary(project_name=project, days=days)}), 200


@app.route("/recommendation-config", methods=["PUT", "POST"])
@require_role("owner", "admin")
def update_recommendation_config():
    from src.services import recommendation_config as rc
    body = request.get_json(silent=True) or {}
    updates = {key: body[key] for key in
               ("minSimilarityPercent", "taskMatchWeight", "artifactMatchWeight",
                "minSemanticSimilarity", "downvoteSinkMinVotes", "similarityWeightedScoring",
                "distinctiveMatchWeight", "scoringMode", "evidenceScale", "supportScale",
                # base identity weights + the LLM-promotion switch
                "baseTaskWeight", "baseFileWeight", "baseTokenWeight", "llmPromoteEnabled",
                "evidenceSimilarityWeight", "historyWeightCeiling", "fileContentMatchWeight",
                "afterPatternWeight", "semanticMatchBase", "exactMatchBase",
                "evidenceContrastMinSpread",
                # same-error feedback support points (helper tier, capped by evidence)
                "feedbackSupportWeight",
                # popularity multipliers + helper share of evidence (accuracy pass)
                "usageHitsWeight", "shownHistoryWeight", "helperEvidenceRatio",
                "errorTextArtifactWeight", "ambiguityMargin")
               if key in body}
    if not updates:
        return jsonify({
            "success": False,
            "message": "provide at least one of: minSimilarityPercent (0-100, percent of "
                       "similarity a shown candidate must reach), "
                       "taskMatchWeight (0-30), artifactMatchWeight (0-60), "
                       "minSemanticSimilarity (0-1), downvoteSinkMinVotes (1-10), "
                       "similarityWeightedScoring (true/false)",
        }), 400
    try:
        updated_by = ""
        try:
            from flask import g as _g
            updated_by = str((getattr(_g, "user", None) or {}).get("sub") or "")
        except Exception:
            updated_by = ""
        data = rc.set_values(updates, updated_by=updated_by)
        return jsonify({"success": True, "data": data}), 200
    except (TypeError, ValueError):
        return jsonify({
            "success": False,
            "message": "invalid value: minSimilarityPercent 0-100, taskMatchWeight 0-30, "
                       "similarityWeightedScoring true/false",
        }), 400


# ---- Project Group Configuration (admin). Identity = project NAME (projects are derived). ----
# The page's GETs carry the same gate as its mutations (previously user-role tokens
# still received group data here after the admin-GET auth batch). The extension never calls
# these, so the strict decorator is safe — wrong role gets 403 + data: [].
@app.route("/allGroupData", methods=["GET"])
@require_role("owner", "admin")
def all_group_data():
    return jsonify(handlers.handle_all_group_data(
        page_number=request.args.get("pageNumber"),
        page_size=request.args.get("pageSize"),
        search_text=request.args.get("searchText"),
        from_date=request.args.get("fromDate"),
        to_date=request.args.get("toDate"),
    )), 200


@app.route("/groupProjectsData", methods=["GET"])
@require_role("owner", "admin")
def group_projects_data():
    group_name = request.args.get("groupName") or ""
    if not group_name.strip():
        return jsonify({"success": False, "message": "groupName is required"}), 400
    return jsonify(handlers.handle_group_projects_data(
        group_name=group_name,
        page_number=request.args.get("pageNumber"),
        page_size=request.args.get("pageSize"),
        search_text=request.args.get("searchText"),
        from_date=request.args.get("fromDate"),
        to_date=request.args.get("toDate"),
    )), 200


@app.route("/otherProjectsData", methods=["GET"])
@require_role("owner", "admin")
def other_projects_data():
    return jsonify(handlers.handle_other_projects_data(
        page_number=request.args.get("pageNumber"),
        page_size=request.args.get("pageSize"),
        search_text=request.args.get("searchText"),
    )), 200


@app.route("/addGroup", methods=["POST"])
@require_role("owner", "admin")
def add_group():
    body = request.get_json(silent=True) or {}
    try:
        return jsonify(handlers.handle_add_group(body.get("groupName"), body.get("projectPattern"))), 200
    except ValueError as e:
        return jsonify({"success": False, "message": str(e)}), 400


@app.route("/updateGroup", methods=["PUT"])
@require_role("owner", "admin")
def update_group_route():
    body = request.get_json(silent=True) or {}
    try:
        return jsonify(handlers.handle_update_group(
            body.get("oldGroupName"), body.get("groupName"), body.get("projectPattern"))), 200
    except ValueError as e:
        return jsonify({"success": False, "message": str(e)}), 400


@app.route("/addProjectInGroup", methods=["POST"])
@require_role("owner", "admin")
def add_project_in_group():
    body = request.get_json(silent=True) or {}
    # accept projectNames (preferred) or projectIds (treated as names) for UI compatibility
    names = body.get("projectNames") or body.get("projectIds") or []
    try:
        return jsonify(handlers.handle_add_projects_in_group(body.get("groupName"), names)), 200
    except ValueError as e:
        return jsonify({"success": False, "message": str(e)}), 400


@app.route("/deleteProjectFromGroup", methods=["POST"])
@require_role("owner", "admin")
def delete_project_from_group():
    body = request.get_json(silent=True) or {}
    project_name = body.get("projectName") or body.get("projectId")
    try:
        return jsonify(handlers.handle_delete_project_from_group(body.get("groupName"), project_name)), 200
    except ValueError as e:
        return jsonify({"success": False, "message": str(e)}), 400


@app.route("/deleteGroup", methods=["DELETE"])
@require_role("owner", "admin")
def delete_group_route():
    body = request.get_json(silent=True) or {}
    try:
        return jsonify(handlers.handle_delete_group(body.get("groupName"))), 200
    except ValueError as e:
        return jsonify({"success": False, "message": str(e)}), 400


# ===================================================================================================
# PROJECT NAMING CONVENTION (29-Sep): derive customer + project from the project name instead of
# filing every new project into a group by hand. GET is open like the sibling config reads; writing
# the convention is admin-only because it decides which projects share evidence.
# ===================================================================================================
@app.route("/project-naming", methods=["GET"])
def get_project_naming():
    from src.services import project_naming
    return jsonify({"success": True, "data": project_naming.public_view(), "message": "Success"}), 200


@app.route("/project-naming", methods=["PUT", "POST"])
@require_role("owner", "admin")
def update_project_naming():
    from src.services import project_naming
    body = request.get_json(silent=True) or {}
    updated_by = ""
    try:
        from flask import g as _g
        updated_by = str((getattr(_g, "user", None) or {}).get("sub") or "")
    except Exception:
        updated_by = ""
    try:
        cfg = project_naming.set_config(
            enabled=body.get("namingEnabled", body.get("enabled")),
            regex=body.get("namingRegex", body.get("regex")),
            updated_by=updated_by,
        )
        return jsonify({"success": True, "data": project_naming.public_view(cfg),
                        "message": "Naming convention updated"}), 200
    except (ValueError, TypeError) as e:
        return jsonify({"success": False, "data": None, "message": str(e)}), 400


@app.route("/project-naming/preview", methods=["GET", "POST"])
@require_role("owner", "admin")
def preview_project_naming():
    """Dry-run a convention over the REAL project names without switching it on.

    This exists because the convention decides evidence sharing estate-wide, and a regex that is
    one character wrong would either merge two customers or recognise nobody. The caller sees the
    customer -> project tree it would produce AND, just as important, every project name that does
    NOT match - those keep today's behaviour, and a long unmatched list means the expression is
    wrong rather than the estate being unconventional.
    """
    import re as _re
    from src.services import project_naming
    body = request.get_json(silent=True) or {}
    pattern = str(request.args.get("regex") or body.get("namingRegex") or body.get("regex") or "").strip()
    if not pattern:
        pattern = str(project_naming.get_config().get("namingRegex") or "").strip()
    if not pattern:
        return jsonify({"success": False, "data": None,
                        "message": "No naming convention is configured. Pass ?regex=... to try one "
                                   f"(example: {project_naming.EXAMPLE_REGEX})"}), 400
    try:
        compiled = _re.compile(pattern)
    except _re.error as e:
        return jsonify({"success": False, "data": None,
                        "message": f"namingRegex is not a valid regular expression: {e}"}), 400
    if "customer" not in compiled.groupindex or "project" not in compiled.groupindex:
        return jsonify({"success": False, "data": None,
                        "message": "namingRegex must define (?P<customer>...) and (?P<project>...)"}), 400
    try:
        from src.utils.project_details import get_all_projects
        names = sorted({str((row or {}).get("project_name") or "").strip()
                        for row in (get_all_projects() or [])
                        if str((row or {}).get("project_name") or "").strip()})
    except Exception:
        logger.exception("project naming preview could not list projects")
        names = []
    tree, unmatched = {}, []
    for name in names:
        # Must normalise EXACTLY as project_naming._normalize does - lower-case only, separators
        # kept. A preview that normalised differently from the resolver would approve an expression
        # that then behaved differently in production, which is worse than no preview at all.
        match = compiled.match(project_naming._normalize(name))
        customer = str((match.groupdict().get("customer") if match else "") or "").strip().lower()
        project = str((match.groupdict().get("project") if match else "") or "").strip().lower()
        if not customer:
            unmatched.append(name)
            continue
        tree.setdefault(customer, {}).setdefault(project, []).append(name)
    return jsonify({"success": True, "message": "Success", "data": {
        "namingRegex": pattern,
        "projectsTotal": len(names),
        "matched": len(names) - len(unmatched),
        "customers": [
            {"customer": customer,
             "projects": [{"project": project, "projectNames": sorted(members)}
                          for project, members in sorted(projects.items())]}
            for customer, projects in sorted(tree.items())
        ],
        "unmatchedProjectNames": unmatched,
    }}), 200

@app.route("/developers", methods=["GET"])
def get_developers():
    try:
        from src.utils.project_details import get_all_developers
        return jsonify(get_all_developers()), 200
    except Exception as e:
        return _error_response(e, 500)


@app.route("/get-all-project-name", methods=["GET"])
def get_all_project_name():
    try:
        result = handlers.handle_get_all_project_names()
        status = 200 if result.get("success") else 500
        return jsonify(result), status
    except Exception as e:
        return _error_response(e, 500)


@app.route("/get-tasks/<project_name>", methods=["GET"])
def get_tasks(project_name):
    s_date = request.args.get('s_date')
    c_date = request.args.get('c_date')
    return jsonify(
        handlers.handle_get_tasks(project_name, s_date, c_date)
    ), 200


@app.route("/get-total-errors/<project_name>", methods=["GET"])
def get_total_errors(project_name):
    s_date = request.args.get('s_date')
    c_date = request.args.get('c_date')
    username = request.args.get('username') or _resolve_actor_id()
    search = request.args.get("search") or request.args.get("searchText") or request.args.get("q") or ""
    return jsonify(
        handlers.handle_get_total_errors(
            project_name, s_date, c_date, username=username,
            page_number=request.args.get("pageNumber"),
            page_size=request.args.get("pageSize"),
            search=search,
            task=request.args.get("task") or "",
        )
    ), 200


@app.route("/daily-activity", methods=["GET"])
def daily_activity():
    s_date = request.args.get("s_date")
    c_date = request.args.get("c_date")
    # Accept both groupType and group_name for compatibility
    group_name = request.args.get("groupType") or request.args.get("group_name")
    return jsonify(handlers.handle_get_daily_activity(
        s_date=s_date, c_date=c_date,
        group_name=group_name,
        page_number=request.args.get("pageNumber"),
        page_size=request.args.get("pageSize"),
    )), 200

@app.route("/daily-activity/export", methods=["GET"])
def daily_activity_export():
    """Recent Activity -> Excel. Same filters as /daily-activity, every matching row, as a real
    .xlsx: header frozen and filterable, columns auto-sized to the data, long text wrapped.

    Server-side on purpose: the rows never travel to the browser as JSON first, and a
    workbook can carry formatting a CSV cannot - the CSV attempt split records across rows
    wherever solution text contained a newline.
    """
    from src.utils.excel_export import Column, build_workbook

    s_date = request.args.get("s_date")
    c_date = request.args.get("c_date")
    group_name = request.args.get("groupType") or request.args.get("group_name")
    search_text = request.args.get("searchText")

    rows = handlers.handle_export_daily_activity(
        s_date=s_date, c_date=c_date, group_name=group_name, search_text=search_text)

    def _solution(row):
        sol = row.get("solution")
        if not isinstance(sol, list):
            return ""
        out = []
        for entry in sol:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("fileName") or entry.get("filePath") or "").strip()
            changes = entry.get("changes")
            text = " | ".join(str(c) for c in changes) if isinstance(changes, list) else ""
            out.append(f"{name}: {text}" if name and text else (text or name))
        return " || ".join(p for p in out if p)

    def _date(row):
        raw = str(row.get("created_date") or "")
        # YYYY-MM-DDTHH:MM:SSZ -> YYYY-MM-DD HH:MM:SS, readable and still sortable as text.
        return raw.replace("T", " ").replace("Z", "").strip()

    # Same columns, same order as the Recent Activity table, so the file matches the screen.
    columns = [
        Column("Group Name",   lambda r: r.get("groupType"),        min_width=12, max_width=24),
        Column("Project Name", lambda r: r.get("project_name"),     min_width=14, max_width=30),
        Column("Error ID",     lambda r: r.get("request_id"),       min_width=14, max_width=40),
        Column("Error",        lambda r: r.get("task_name"),        min_width=16, max_width=45),
        # The stored key is resolutionDescription (camelCase); the other two are fallbacks so a
        # row from an older write path still exports its text instead of a blank cell.
        Column("Description",  lambda r: (r.get("resolutionDescription")
                                          or r.get("description")
                                          or r.get("resolution_description")),
               min_width=16, max_width=50, wrap=True),
        Column("Rec Solution", _solution,                            min_width=24, max_width=80, wrap=True),
        Column("Rec Count",    lambda r: r.get("recommended_count", 0), min_width=10, max_width=14),
        Column("Date",         _date,                                min_width=18, max_width=22),
    ]

    context = [
        f"Recent Activity export - {len(rows)} row(s)",
        f"Date range: {s_date or 'all'} to {c_date or 'all'}"
        + (f"   |   Group: {group_name}" if group_name else "")
        + (f"   |   Search: {search_text}" if search_text else ""),
    ]

    stream = build_workbook(rows, columns, "Recent Activity", context)
    parts = ["recent-activity", (s_date or "all"), "to", (c_date or "all")]
    if group_name:
        parts.append(re.sub(r"[^A-Za-z0-9_-]+", "", str(group_name)))
    filename = "_".join(parts) + ".xlsx"
    return send_file(
        stream,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=filename,
    )


@app.route("/get-solution-by-request/<request_id>", methods=["GET"])
def get_solution_by_request(request_id):
    # Optional ?projectName= lets the response include recommendation_token_usage (token rows
    # are stored per project, so the lookup needs it).
    result = handlers.handle_get_solution_by_request_id(
        request_id, project_name=request.args.get("projectName") or ""
    )
    status = 200 if result.get("success") else 404
    return jsonify(result), status


@app.route("/get-errors-by-request/<request_id>", methods=["GET"])
def get_errors_by_request(request_id):
    result = handlers.handle_get_error_messages_by_request_id(request_id)
    status = 200 if result.get("success") else 404
    return jsonify(result), status


@app.route("/delete-requests", methods=["POST"])
@require_role("owner", "admin")
def delete_requests():
    try:
        if not request.is_json:
            return jsonify({"success": False, "error": "Content-Type must be application/json"}), 400
        result = handlers.handle_delete_requests(request.get_json(silent=True) or {})
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/delete-project", methods=["POST", "DELETE"])
@app.route("/delete-project/<path:project_name>", methods=["DELETE"])
@require_role("owner", "admin")
def delete_project(project_name=None):
    # Removes ONE project and everything filed under it: every request (the /delete-requests
    # sweep per request) plus the project's own rows. Unlike /deleteProjectFromGroup, which only
    # moves a project to Other. The name comes from the path, else the JSON body
    # (projectName / project_name), else ?projectName=.
    body = request.get_json(silent=True) or {}
    name = (project_name or body.get("projectName") or body.get("project_name")
            or request.args.get("projectName") or "")
    claims = getattr(g, "user", None) or {}
    actor = str(claims.get("username") or claims.get("email") or claims.get("sub") or _resolve_actor_id())
    try:
        return jsonify(handlers.handle_delete_project(name, actor=actor)), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/get-day-week-wise-count/<project_name>", methods=["GET"])
def get_week_day_wise_count(project_name):
    s_date = request.args.get('s_date')
    c_date = request.args.get('c_date')
    return jsonify(
        handlers.handle_get_week_day_wise_count(project_name, s_date, c_date)
    ), 200


@app.route("/graph/projects", methods=["GET"])
def graph_projects():
    s_date = request.args.get("s_date")
    c_date = request.args.get("c_date")
    return jsonify(handlers.handle_graph_projects(s_date, c_date)), 200

# --------------------------------------------------
# RECOMMENDATIONS
# --------------------------------------------------

@app.route("/recommendations", methods=["POST"])
def recommendations():
    result = handlers.handle_recommendations(request.get_json())
    return jsonify(result), 200


@app.route("/error-report/feedback", methods=["POST"])
def error_report_feedback():
    if not request.is_json:
        return jsonify({"status": "error", "error": "Content-Type must be application/json"}), 400
    result = handlers.handle_recommendation_feedback(request.get_json(silent=True) or {})
    status_code = 200 if result.get("status") is True else 400
    return jsonify(result), status_code


from flask import jsonify, request
from src.services import handlers


@app.route("/data-injection", methods=["GET"])
@require_role("owner", "admin")
def list_data_injection():
    try:
        result = handlers.list_all_injected_documents_by_project_handler()
        status = 200 if result.get("success") else 500
        return jsonify(result), status
    except Exception as e:
        return _error_response(e, 500)


@app.route("/files", methods=["GET"])
@require_role("owner", "admin")
def list_injected_files():
    """Data Injection page — flat file list, optionally narrowed to ONE project.

    Query params:
      - project_name (optional): only that project's files (case-insensitive;
        omit for all projects' files in one flat list)

    Example:  GET /files?project_name=1g_hio_000u0_uat
    """
    try:
        project_name = (request.args.get("project_name") or "").strip()
        result = handlers.list_injected_files_handler(project_name=project_name)
        status = 200 if result.get("success") else 500
        return jsonify(result), status
    except Exception as e:
        return _error_response(e, 500)


@app.route("/data-injection", methods=["POST"])
@require_role("owner", "admin")
def data_injection():
    """
    Accepts only multipart/form-data:
      - project_name (required)
      - file (required)

    Example:
      curl --location 'http://127.0.0.1:9052/data-injection' \
        --form 'project_name=sw-prj-1ghio_000u0' \
        --form 'file=@"/path/to/file.pdf"'
    """
    try:
        project_name = (request.form.get("project_name") or "").strip()
        upload = request.files.get("file")

        if not project_name:
            return jsonify({
                "success": False,
                "error": "project_name is required",
                "request_id": _current_request_id(),
            }), 400

        if not upload:
            return jsonify({
                "success": False,
                "error": "file is required",
                "request_id": _current_request_id(),
            }), 400

        file_bytes = upload.read()
        if not file_bytes:
            return jsonify({
                "success": False,
                "error": "file is empty",
                "request_id": _current_request_id(),
            }), 400

        result = handlers.handle_file_data_injection(
            project_name=project_name,
            file_name=upload.filename or "upload.bin",
            file_bytes=file_bytes,
        )

        status = 200 if result.get("success") else 400

        if "request_id" not in result:
            result["request_id"] = _current_request_id()

        return jsonify(result), status

    except Exception as e:
        return _error_response(e, 500)
    
    
@app.route("/get-data-injection", methods=["GET"])
def get_data_injection():
    """
    Fetch inserted document chunks based on query.

    Query params:
      - query (required)
      - project_name (optional)
      - top_k (optional, default 5)

    Example:
      /get-data-injection?query=build%20rules&project_name=sw-prj-1ghio_000u0&top_k=5
    """
    try:
        query = (request.args.get("query") or "").strip()
        project_name = (request.args.get("project_name") or "").strip()
        top_k_raw = (request.args.get("top_k") or "5").strip()

        if not query:
            return jsonify({
                "success": False,
                "error": "query is required",
                "request_id": _current_request_id(),
            }), 400

        try:
            top_k = max(1, min(int(top_k_raw), 20))
        except ValueError:
            return jsonify({
                "success": False,
                "error": "top_k must be an integer",
                "request_id": _current_request_id(),
            }), 400

        result = handlers.get_data_injection_by_query(
            query=query,
            project_name=project_name,
            top_k=top_k,
        )

        status = 200 if result.get("success") else 404
        if "request_id" not in result:
            result["request_id"] = _current_request_id()

        return jsonify(result), status

    except Exception as e:
        return _error_response(e, 500)
    

@app.route("/check-data-injection", methods=["GET"])
def check_data_injection():
    """
    Check whether data injection happened for a given request_id.

    Query params:
      - request_id (required)

    Example:
      /check-data-injection?request_id=b4a49a1a-7d00-43b9-bb04-67cac1614fb2-1
    """
    try:
        request_id = (request.args.get("request_id") or "").strip()

        if not request_id:
            return jsonify({
                "success": False,
                "error": "request_id is required",
                "request_id": _current_request_id(),
            }), 400

        result = handlers.check_data_injection_by_request_id(request_id=request_id)

        status = 200 if result.get("success") else 404
        if "request_id" not in result:
            result["request_id"] = _current_request_id()
        return jsonify(result), status

    except Exception as e:
        return _error_response(e, 500)

@app.route("/copilot/session/start", methods=["POST"])
def copilot_session_start():
    try:
        if not request.is_json:
            return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400
        payload = request.get_json(silent=True) or {}
        if not payload.get("actor_id") or str(payload.get("actor_id")).strip().lower() == "global":
            payload["actor_id"] = _resolve_actor_id()
        result = handlers.handle_copilot_session_start(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/copilot/session/touch", methods=["POST"])
def copilot_session_touch():
    try:
        if not request.is_json:
            return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400
        payload = request.get_json(silent=True) or {}
        if not payload.get("actor_id") or str(payload.get("actor_id")).strip().lower() == "global":
            payload["actor_id"] = _resolve_actor_id()
        result = handlers.handle_copilot_session_start(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/copilot/session/active", methods=["GET"])
def copilot_session_active():
    try:
        payload = {
            "project_name": request.args.get("project_name", ""),
            "client_id": request.args.get("client_id", "global"),
            "actor_id": request.args.get("actor_id", _resolve_actor_id()),
            "workspace_id": request.args.get("workspace_id", ""),
        }
        if payload["project_name"]:
            result = handlers.handle_get_active_copilot_session(payload)
        else:
            result = handlers.handle_get_active_copilot_session_auto(payload)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/copilot/session/recommendations", methods=["GET"])
def copilot_session_recommendations():
    try:
        payload = {
            "project_name": request.args.get("project_name", ""),
            "client_id": request.args.get("client_id", "global"),
            "actor_id": request.args.get("actor_id", _resolve_actor_id()),
            "workspace_id": request.args.get("workspace_id", ""),
        }
        if payload["project_name"]:
            result = handlers.handle_copilot_recommend_by_session(payload)
        else:
            result = handlers.handle_copilot_recommend_by_active_auto(payload)
        status_code = 200 if result.get("status") == "success" else 404
        return jsonify(result), status_code
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/copilot/recommendations/by-uuid", methods=["POST"])
def copilot_recommendations_by_uuid():
    try:
        if not request.is_json:
            return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400
        result = handlers.handle_copilot_recommend_by_uuid(request.get_json(silent=True) or {})
        status_code = 200 if result.get("status") == "success" else 404
        return jsonify(result), status_code
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/copilot/session/report", methods=["POST"])
def copilot_session_report():
    try:
        project_name = (request.form.get("project_name") or "").strip()
        actor_id = (request.form.get("actor_id") or "").strip()
        if not actor_id or actor_id.lower() == "global":
            actor_id = _resolve_actor_id()
        client_id = (request.form.get("client_id") or "global").strip() or "global"
        workspace_id = (request.form.get("workspace_id") or "").strip()
        build_context_id = (request.form.get("build_context_id") or "").strip()
        report_version = int(request.form.get("report_version") or 0)
        if not project_name:
            return jsonify({"status": False, "error": "project_name is required"}), 400
        if "file" not in request.files:
            return jsonify({"status": False, "error": "report file is required"}), 400
        file = request.files["file"]
        report_bytes = file.read()
        result = handlers.handle_copilot_report_snapshot(
            project_name=project_name,
            report_bytes=report_bytes,
            actor_id=actor_id,
            client_id=client_id,
            workspace_id=workspace_id,
            build_context_id=build_context_id,
            report_version=report_version,
        )
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/copilot/session/active-current", methods=["GET"])
def copilot_session_active_current():
    try:
        actor_id = (request.args.get("actor_id", "") or "").strip()
        if not actor_id or actor_id.lower() == "global":
            actor_id = _resolve_actor_id()
        payload = {
            "actor_id": actor_id,
            "project_name": request.args.get("project_name", ""),
            "client_id": request.args.get("client_id", ""),
            "workspace_id": request.args.get("workspace_id", ""),
        }
        result = handlers.handle_get_active_copilot_session_auto(payload)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/copilot/session/recommendations/current", methods=["GET"])
def copilot_session_recommendations_current():
    try:
        actor_id = (request.args.get("actor_id", "") or "").strip()
        if not actor_id or actor_id.lower() == "global":
            actor_id = _resolve_actor_id()
        payload = {
            "actor_id": actor_id,
            "project_name": request.args.get("project_name", ""),
            "client_id": request.args.get("client_id", ""),
            "workspace_id": request.args.get("workspace_id", ""),
            "query_text": request.args.get("query_text", ""),
            "doc_top_k": request.args.get("doc_top_k", "5"),
        }
        result = handlers.handle_copilot_recommend_by_active_auto(payload)
        status_code = 200 if result.get("status") == "success" else 404
        return jsonify(result), status_code
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/copilot/session/build-success", methods=["POST"])
def copilot_session_build_success():
    try:
        if not request.is_json:
            return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400
        payload = request.get_json(silent=True) or {}
        if not payload.get("actor_id") or str(payload.get("actor_id")).strip().lower() == "global":
            payload["actor_id"] = _resolve_actor_id()
        result = handlers.handle_copilot_build_success(payload)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/scope", methods=["POST"])
def predict_scope():
    try:
        if not request.is_json:
            return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400
        payload = request.get_json(silent=True) or {}
        if not payload.get("actor_id") or str(payload.get("actor_id")).strip().lower() == "global":
            payload["actor_id"] = _resolve_actor_id()
        result = handlers.handle_predict_scope(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/pending-scope", methods=["GET"])
def predict_pending_scope():
    try:
        payload = {
            "project_name": request.args.get("project_name", ""),
            "client_id": request.args.get("client_id", "global"),
            "actor_id": request.args.get("actor_id", _resolve_actor_id()),
        }
        result = handlers.handle_get_predict_pending_scope(payload)
        return jsonify(result), 200
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/result", methods=["POST"])
def predict_result():
    try:
        if not request.is_json:
            return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400
        payload = request.get_json(silent=True) or {}
        if not payload.get("actor_id") or str(payload.get("actor_id")).strip().lower() == "global":
            payload["actor_id"] = _resolve_actor_id()
        result = handlers.handle_predict_result(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/result/current", methods=["GET"])
def predict_result_current():
    try:
        payload = {
            "project_name": request.args.get("project_name", ""),
            "client_id": request.args.get("client_id", "global"),
            "actor_id": request.args.get("actor_id", _resolve_actor_id()),
        }
        result = handlers.handle_get_predict_result_current(payload)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/report-scope", methods=["GET", "POST"])
def predict_report_scope():
    try:
        if request.method == "POST":
            payload = request.get_json(silent=True) or {}
            if not payload.get("actor_id") or str(payload.get("actor_id")).strip().lower() == "global":
                payload["actor_id"] = _resolve_actor_id()
        else:
            payload = {
                "project_name": request.args.get("project_name", ""),
                "actor_id": request.args.get("actor_id", _resolve_actor_id()),
            }
        result = handlers.handle_predict_report_scope(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/report", methods=["POST"])
def predict_report():
    try:
        if not request.is_json:
            return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400
        payload = request.get_json(silent=True) or {}
        if not payload.get("actor_id") or str(payload.get("actor_id")).strip().lower() == "global":
            payload["actor_id"] = _resolve_actor_id()
        result = handlers.handle_predict_report(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/shadow-metrics/<project_name>", methods=["GET"])
def predict_shadow_metrics(project_name):
    """Shadow-mode accuracy (judging step B): per-project totals + per-pattern right/wrong
    counts, aggregated on demand from the judged shadow reports."""
    try:
        limit = int(request.args.get("limit", "200") or "200")
        from src.services import shadow_judge
        return jsonify(shadow_judge.shadow_metrics(project_name, limit=limit)), 200
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/history/<project_name>", methods=["GET"])
def predict_history(project_name):
    try:
        limit = int(request.args.get("limit", "100") or "100")
        # ?kind=shadow lists the silent failure-time captures; default hides them.
        kind = (request.args.get("kind") or "standard").strip().lower()
        result = handlers.handle_get_prediction_history(project_name, limit=limit, kind=kind)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/history/report/<prediction_report_id>", methods=["GET"])
def predict_history_report(prediction_report_id):
    try:
        result = handlers.handle_get_prediction_history_report(prediction_report_id)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/predict/embed-texts", methods=["POST"])
def predict_embed_texts():
    try:
        if not request.is_json:
            return jsonify({"status": False, "error": "Content-Type must be application/json"}), 400
        payload = request.get_json(silent=True) or {}
        result = handlers.handle_predict_embed_texts(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/maintenance/recommendation-outcomes/compact", methods=["POST"])
def maintenance_compact_recommendation_outcomes():
    try:
        payload = request.get_json(silent=True) or {} if request.is_json else {}
        result = handlers.handle_compact_recommendation_outcomes(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/maintenance/request-metadata/compact", methods=["POST"])
def maintenance_compact_request_metadata():
    try:
        payload = request.get_json(silent=True) or {} if request.is_json else {}
        result = handlers.handle_compact_request_metadata(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/maintenance/storage-health", methods=["GET"])
def maintenance_storage_health():
    try:
        result = handlers.handle_storage_health_summary()
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/maintenance/run", methods=["POST"])
def maintenance_run():
    try:
        payload = request.get_json(silent=True) or {} if request.is_json else {}
        result = handlers.handle_run_maintenance(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/maintenance/last-run", methods=["GET"])
def maintenance_last_run():
    try:
        payload = {"name": request.args.get("name", "default")}
        result = handlers.handle_get_latest_maintenance_run(payload)
        status_code = 200 if result.get("status") else 404
        return jsonify(result), status_code
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


@app.route("/maintenance/admin-summary", methods=["GET"])
def maintenance_admin_summary():
    try:
        payload = {
            "name": request.args.get("name", "default"),
            "hot_threshold": request.args.get("hot_threshold", ""),
            "warm_threshold": request.args.get("warm_threshold", ""),
            "archive_only_threshold": request.args.get("archive_only_threshold", ""),
            "expired_threshold": request.args.get("expired_threshold", ""),
        }
        result = handlers.handle_maintenance_admin_summary(payload)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"status": False, "error": str(e)}), 400
    except Exception as e:
        return _error_response(e, 500)


# --------------------------------------------------
# CREATE INDEX
# --------------------------------------------------

@app.route("/create-index", methods=["GET"])
def create_index():
    try:
        result = handlers.handle_create_index()
        return jsonify(result), 200
    except Exception as e:
        return _error_response(e, 500)


# --------------------------------------------------
# REPORT ERRORS
# --------------------------------------------------

# @app.route("/report-errors", methods=["POST"])
# def report_errors():
#     html = request.get_data(as_text=True)
#     project_name=html["project_name"]
#     result = handlers.handle_report_errors(html)

#     status = 200 if result.get("status") == "success" else 500
#     return jsonify(result), status
def _build_report_error_output(
    project_name: str,
    result: dict,
    query_text: str = "",
    doc_top_k: int = 5,
):
    base_url = str(config.BACKEND_PUBLIC_BASE_URL or "").rstrip("/")
    raw_recs = result.get("recommendations")
    raw_llm = str(result.get("llm_analysis") or "")
    logger.debug(
        "_build_report_error_output | start | project_name=%s | raw_recommendations_count=%d | llm_analysis_present=%s | llm_analysis_chars=%d",
        project_name,
        len(raw_recs) if isinstance(raw_recs, list) else 0,
        bool(raw_llm),
        len(raw_llm),
    )

    def _diff_link(request_id: str | None) -> str | None:
        if request_id:
            return f"{base_url}/diff_view/request/{request_id}"
        return None

    recommendations = raw_recs if isinstance(raw_recs, list) else []
    weak_recommendations = result.get("weak_recommendations")
    weak_recommendations = weak_recommendations if isinstance(weak_recommendations, list) else []
    if len(recommendations) < 3:
        seen_request_ids = {
            str(rec.get("request_id") or rec.get("batch_id") or "").strip()
            for rec in recommendations if isinstance(rec, dict)
        }
        for rec in weak_recommendations:
            if len(recommendations) >= 3:
                break
            if not isinstance(rec, dict):
                continue
            if rec.get("match_status") != "below_threshold" or not rec.get("solution"):
                continue
            request_id = str(rec.get("request_id") or rec.get("batch_id") or "").strip()
            if request_id and request_id in seen_request_ids:
                continue
            rec["is_weak_match"] = True
            recommendations.append(rec)
            if request_id:
                seen_request_ids.add(request_id)

    output = []
    for rec in recommendations:
        if not isinstance(rec, dict):
            continue
        req_id = rec.get("request_id") or rec.get("batch_id")
        out_rec = {
            "compare_diff_link": _diff_link(req_id),
            "request_id": req_id,
            "solution": rec.get("solution", []),
            "created_date": rec.get("created_date"),
            "uploaded_at": rec.get("uploaded_at") or rec.get("created_date"),
            "resolution_description": str(rec.get("resolution_description") or "").strip(),
            "thumbs_up": int(rec.get("thumbs_up") or 0),
            "thumbs_down": int(rec.get("thumbs_down") or 0),
            # Per-candidate relevance numbers (informational): calibration + UI honesty.
            "final_score": rec.get("final_score"),
            "confidence_score": rec.get("confidence_score"),
            "match_status": rec.get("match_status"),
            # HOW the candidate was found and how similar its error is, so the webview can
            # label a similarity the way the trace does: match_type exact/semantic/task,
            # similarity = the error cosine (1.0 for an exact signature), on the same basis for
            # every row; similarity_source is '' normally and names only an abnormal case:
            # 'no_error_text' = the stored row had nothing to compare (similarity blank),
            # 'embedding_unavailable' / 'no_query_text' = no comparison could be made.
            "match_type": rec.get("match_type"),
            "similarity": rec.get("similarity"),
            "similarity_source": str(rec.get("similarity_source") or ""),
            "confidence_source": str(rec.get("confidence_source") or ""),
        }
        # Forward LLM-selection badge fields when the chosen fix was promoted, so the
        # extension can render the "Recommended fix" badge + rationale.
        if rec.get("is_recommended"):
            out_rec["is_recommended"] = True
            if rec.get("selection_confidence"):
                out_rec["selection_confidence"] = rec.get("selection_confidence")
            if rec.get("why_this_fix"):
                out_rec["why_this_fix"] = rec.get("why_this_fix")
        # Forward the closest-match badge. Weak-match presentation is handled by match_status
        # at the response level; do not send the per-card warning flag to the extension.
        if rec.get("is_closest_match"):
            out_rec["is_closest_match"] = True
        if rec.get("is_weak_match"):
            out_rec["is_weak_match"] = True
        output.append(out_rec)
    _desc_present = [r.get("request_id") for r in output if str(r.get("resolution_description") or "").strip()]
    logger.info(
        "_build_report_error_output | recommendation formatting done | project_name=%s | output_rows=%d | "
        "with_resolution_description=%d | desc_request_ids=%s | llm_analysis_present=%s",
        project_name,
        len(output),
        len(_desc_present),
        _desc_present[:5],
        bool(raw_llm),
    )

    derived_query = str(query_text or result.get("query_error") or "").strip()
    document_context = result.get("document_context")
    if not isinstance(document_context, dict):
        document_context = handlers.build_document_context(
            query_text=derived_query,
            project_name=project_name,
            top_k=doc_top_k,
        )
    context_enrichment = result.get("context_enrichment")
    if not isinstance(context_enrichment, dict):
        context_enrichment = {
            "enabled": False,
            "query": derived_query,
            "semantic_results_used": 0,
            "artifact_results_used": 0,
            "refined_context": {
                "issue_summary": "",
                "contextual_findings": [],
                "recommended_actions": [],
                "possible_resolutions": [],
                "caveats": [],
            },
        }
    logger.debug(
        "_build_report_error_output | document context built | project_name=%s | query_present=%s | result_count=%d",
        project_name,
        bool(derived_query),
        len(document_context.get("results") or []) if isinstance(document_context, dict) else 0,
    )

    return {
        "recommendations": output,
        # Relevance transparency (threshold work): the gate's verdict and score
        # are part of the envelope, so calibration runs and the UI can see HOW similar the
        # match actually was — previously these never left the handler.
        "match_status": str(result.get("match_status") or ""),
        "confidence_score": result.get("confidence_score"),
        "llm_analysis": raw_llm,
        "llm_analysis_status": str(result.get("llm_analysis_status") or "ok"),
        "llm_analysis_message": str(result.get("llm_analysis_message") or ""),
        "llm_selection": result.get("llm_selection") or {},
        "query_signature_hashes": result.get("query_signature_hashes") or [],
        "feedback_token": result.get("feedback_token") or "",
        # The envelope WHITELISTS fields - trace_id (webview footer copy-paste)
        # and task_match (same-task confirmation) were being dropped here even though the
        # handler returned them, so the extension never saw them.
        "trace_id": str(result.get("trace_id") or ""),
        "task_match": result.get("task_match") or {},
        # Rank 1 clear / likely / ambiguous (tied with other different fixes).
        "decision": result.get("decision") or {},
        "document_context": document_context,
        "context_enrichment": context_enrichment,
    }


def _handle_report_errors_upload(enveloped: bool = False):

    # Get project name from form-data
    project_name = request.form.get("project_name", "").strip()

    if not project_name:
        return jsonify({
            "status": "error",
            "error": "project_name is required"
        }), 400

    # Get uploaded file
    if "file" not in request.files:
        return jsonify({
            "status": "error",
            "error": "HTML file is required"
        }), 400

    file = request.files["file"]

    # Read file content
    html = file.read().decode("utf-8")
    query_text = (request.form.get("query_text") or "").strip()
    copilot_query = (request.form.get("copilot_query") or "").strip()

    # Artifact evidence: compact tail excerpts of the CURRENT failure's collected
    # artifacts (build/task logs), JSON [{name, text}]. Optional — older extensions simply don't
    # send it. Used to disambiguate near-identical error texts at ranking time.
    artifact_text = ""
    artifact_debug: list = []
    artifact_excerpt_parts: list = []
    artifact_excerpts_raw = (request.form.get("artifact_excerpts") or "").strip()
    if artifact_excerpts_raw:
        try:
            import json as _aj
            parts = _aj.loads(artifact_excerpts_raw)
            valid = [p for p in (parts if isinstance(parts, list) else [])
                     if isinstance(p, dict) and str(p.get("text") or "").strip()]
            # 12000 chars shared across the files, and each file keeps its TAIL: logs put the
            # failure last, and cutting the joined text from the head dropped the failure line of
            # every real-size log (and every file after the first) before the comparison ran.
            per_file = max(1000, 12000 // max(1, len(valid)))
            chunks = []
            for p in valid:
                name = str(p.get("name") or "")
                text = str(p.get("text") or "")
                chunks.append(f"{name}\n{text[-per_file:]}")
                artifact_debug.append((name, len(text)))
                artifact_excerpt_parts.append({"name": name, "text": text})
            artifact_text = "\n".join(chunks)
        except Exception:
            artifact_text = ""
    try:
        doc_top_k = int((request.form.get("doc_top_k") or "5").strip())
    except ValueError:
        doc_top_k = 5
    doc_top_k = max(1, min(doc_top_k, 20))

    logger.info(
        "_handle_report_errors_upload | file_read | project_name=%s | html_chars=%d | enveloped=%s | query_text_present=%s | copilot_query_present=%s | doc_top_k=%d",
        project_name,
        len(html),
        enveloped,
        bool(query_text),
        bool(copilot_query),
        doc_top_k,
    )

    # Changed-file identity: the report's error LOCATION is the task script, not the
    # file the developer touched. The client sends THIS cycle's changed-file basenames — the
    # true file signal for ranking fixes that modified the same files first.
    changed_files: list = []
    changed_files_raw = (request.form.get("changed_files") or "").strip()
    if changed_files_raw:
        try:
            import json as _cj
            parsed = _cj.loads(changed_files_raw)
            if isinstance(parsed, list):
                changed_files = [str(x or "").strip() for x in parsed if str(x or "").strip()][:20]
        except Exception:
            changed_files = []

    # [RECO-DEBUG] Everything the client sent, in one grep-able block for live debugging:
    # copy these lines together with the [RECO-DEBUG]/[RERANK] lines from handlers to diagnose
    # a live recommendation without touching the developer's machine.
    logger.info("[RECO-DEBUG] ===== INCOMING /report-errors =====")
    logger.info("[RECO-DEBUG] project=%s | report_format=%r | html_chars=%d",
                project_name, (request.form.get("report_format") or "").strip(), len(html))
    logger.info("[RECO-DEBUG] query_text (%d chars): %r", len(query_text), query_text[:600])
    logger.info("[RECO-DEBUG] copilot_query (%d chars): %r", len(copilot_query), copilot_query[:300])
    logger.info("[RECO-DEBUG] changed_files (%d): %r", len(changed_files), changed_files)
    logger.info("[RECO-DEBUG] artifact_excerpts: %d file(s) %r | combined_chars=%d",
                len(artifact_debug), artifact_debug, len(artifact_text))
    if artifact_text:
        logger.info("[RECO-DEBUG] artifact_text preview: %r", artifact_text[:600])

    result = handlers.handle_report_errors(
        html, project_name, query_text=query_text, copilot_query=copilot_query,
        artifact_text=artifact_text,
        report_format=(request.form.get("report_format") or "").strip(),
        changed_files=changed_files,
        # The LIVE task from the user's VS Code session (never stored) - covers TD5
        # too, where there is no report.html to parse requestedTasks from.
        user_task=(request.form.get("user_task") or "").strip(),
        # The query's artifact content goes into the trace for comparison.
        artifact_excerpts=artifact_excerpt_parts,
        # The scope the DEVELOPER chose for this request (project / customer / global). Absent
        # means "use the configured default" - the 30-Sep review put this choice in their hands,
        # so it travels with the request rather than being an administrator's setting.
        requested_scope=(request.form.get("recommendation_scope")
                 or request.form.get("scope")
                 or request.form.get("requested_scope") or "").strip(),
    )
    logger.debug(
        "_handle_report_errors_upload | handler_returned | project_name=%s | status=%s | "
        "recommendations_count=%d | llm_analysis_present=%s | llm_analysis_chars=%d",
        project_name,
        result.get("status"),
        len(result.get("recommendations") or []) if isinstance(result.get("recommendations"), list) else 0,
        bool(str(result.get("llm_analysis") or "")),
        len(str(result.get("llm_analysis") or "")),
    )

    # Usage counting: how many times a person uploads, and how often a recommendation came
    # back. This is the only point
    # where both halves are known - the failure that was sent up, and whether an answer came
    # back. Keyed on the installation id, attributed to a person only through the key the
    # extension derives on its own machine. Never blocks the response.
    try:
        from src.services import extension_usage as _eu
        _rep_install = str(request.form.get("install_id") or request.form.get("installId") or "").strip()
        if _rep_install:
            _recs = result.get("recommendations")
            _eu.record_report(
                install_id=_rep_install,
                project_name=project_name,
                ext_version=str(request.form.get("ext_version") or "").strip(),
                env_kind=str(request.form.get("env_kind") or "").strip(),
                developer_key=str(request.form.get("usage_key") or request.form.get("usageKey") or "").strip(),
                recommendations=len(_recs) if isinstance(_recs, list) else 0,
            )
        else:
            logger.info("[ext-usage] no install_id on this failure report - the ask and the "
                        "answer are not counted against anybody | project=%s", project_name)
    except Exception:
        logger.exception("extension usage counting failed - report unaffected")

    if result.get("status") == "success":
        output = _build_report_error_output(
            project_name,
            result,
            query_text=query_text,
            doc_top_k=doc_top_k,
        )
        if enveloped:
            _usage = result.get("llm_token_usage") or {}
            return jsonify({
                "response_schema_version": "1",
                "project_name": project_name,
                "recommendations": output["recommendations"],
                "query_signature_hashes": output.get("query_signature_hashes") or [],
                "feedback_token": output.get("feedback_token") or "",
                "llm_analysis": output["llm_analysis"],
                "llm_analysis_status": output.get("llm_analysis_status") or "ok",
                "llm_analysis_message": output.get("llm_analysis_message") or "",
                "llm_selection": output.get("llm_selection") or {},
                "document_context": output.get("document_context") or {},
                "context_enrichment": output.get("context_enrichment") or {},
                # The ENVELOPED response is a second whitelist - these fields
                # were dropped here even after the inner output builder passed them through,
                # so the extension webview never received the trace id (or the gate verdict).
                "trace_id": str(output.get("trace_id") or ""),
                "task_match": output.get("task_match") or {},
                "decision": output.get("decision") or {},
                "match_status": str(output.get("match_status") or ""),
                "confidence_score": output.get("confidence_score"),
                "llm_token_usage": {
                    "prompt_tokens": _usage.get("prompt_tokens", 0),
                    "output_tokens": _usage.get("output_tokens", 0),
                    "total_tokens": _usage.get("total_tokens", 0),
                },
            }), 200
        return jsonify(output), 200

    return jsonify(result), 500


@app.route("/report-errors", methods=["POST"])
def report_errors():
    return _handle_report_errors_upload()


@app.route("/error-report", methods=["POST"])
def error_report():
    return _handle_report_errors_upload(enveloped=True)


@app.route("/report-errors/by-message", methods=["POST"])
def report_errors_by_message():
    if not request.is_json:
        return jsonify({"status": "error", "error": "Content-Type must be application/json"}), 400

    payload = request.get_json(silent=True) or {}
    project_name = str(payload.get("project_name") or payload.get("projectName") or "").strip()
    error_message = str(payload.get("error_message") or "").strip()
    query_text = str(payload.get("query_text") or "").strip()
    try:
        doc_top_k = int(payload.get("doc_top_k") or 5)
    except (TypeError, ValueError):
        doc_top_k = 5
    doc_top_k = max(1, min(doc_top_k, 20))

    if not project_name:
        return jsonify({"status": "error", "error": "project_name is required"}), 400
    if not error_message:
        return jsonify({"status": "error", "error": "error_message is required"}), 400

    result = handlers.handle_report_errors_by_message(project_name, error_message, payload)
    logger.debug(
        "report_errors_by_message | handler_returned | project_name=%s | status=%s | "
        "recommendations_count=%d | llm_analysis_present=%s | llm_analysis_chars=%d",
        project_name,
        result.get("status"),
        len(result.get("recommendations") or []) if isinstance(result.get("recommendations"), list) else 0,
        bool(str(result.get("llm_analysis") or "")),
        len(str(result.get("llm_analysis") or "")),
    )
    if result.get("status") == "success":
        output = _build_report_error_output(
            project_name,
            result,
            query_text=query_text or error_message,
            doc_top_k=doc_top_k,
        )
        return jsonify(output), 200

    return jsonify(result), 500


@app.route("/recommendation-report/<name>", methods=["GET"])
def recommendation_report(name):
    report_dir = os.path.join(UPLOAD_DIR, "recommendation_reports")
    safe_name = secure_filename(name)
    return send_from_directory(report_dir, safe_name, as_attachment=False)



from urllib.parse import unquote

@app.route("/download-files/<batch_id>", methods=["GET"])
def download_files(batch_id):

    requested_file = request.args.get("file")

    if not requested_file:
        files = get_files_by_batch_id(batch_id)
        if not files:
            abort(404, description="No files found")

        return jsonify({
            "batch_id": batch_id,
            "files": [f.replace(f"{batch_id}-", "", 1) for f in files]
        })

    requested_file = unquote(requested_file)
    requested_file = secure_filename(requested_file)

    full_filename = f"{batch_id}-{requested_file}"

    file_path = os.path.join(UPLOAD_DIR, full_filename)

    if not os.path.exists(file_path):
        abort(404, description="File not found")

    return send_file(
        file_path,
        as_attachment=True,
        download_name=requested_file
    )


_ALLOWED_ARTIFACT_PREFIXES = (
    "task-runtime-artifacts/",
    "binary-artifacts/",
)

_S3_URL_PREFIXES = (
    f"https://{config.S3_BUCKET}.s3.{config.S3_REGION}.amazonaws.com/",
    f"https://{config.S3_BUCKET}.s3.amazonaws.com/",
)


def _extract_s3_key_from_url(url: str) -> str | None:
    """Extract the S3 key from a full S3 HTTPS URL, or return None if not recognised."""
    for prefix in _S3_URL_PREFIXES:
        if url.startswith(prefix):
            return url[len(prefix):]
    return None


@app.route("/download-artifact", methods=["GET"])
def download_artifact():
    s3_key = (request.args.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
    if not s3_key:
        return jsonify({"error": "s3_key query parameter is required"}), 400
    if not any(s3_key.startswith(p) for p in _ALLOWED_ARTIFACT_PREFIXES):
        return jsonify({"error": "Invalid s3_key"}), 400
    try:
        from io import BytesIO
        data, file_name = download_s3_zip_bytes(s3_key)
        return send_file(
            BytesIO(data),
            as_attachment=True,
            download_name=file_name,
            mimetype="application/zip",
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 404


@app.route("/view-artifact", methods=["GET"])
def view_artifact():
    """Serve the RAW artifact file (.txt/.log) as plain text for in-browser viewing — lets the
    client open the literal source file behind an evidence item. The artifact zip stores the
    original file bytes; we unzip and return them decoded (UTF-8, errors=replace)."""
    from io import BytesIO
    from zipfile import ZipFile
    from flask import Response
    s3_key = (request.args.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
    if not s3_key:
        return jsonify({"error": "s3_key query parameter is required"}), 400
    if not any(s3_key.startswith(p) for p in _ALLOWED_ARTIFACT_PREFIXES):
        return jsonify({"error": "Invalid s3_key"}), 400
    try:
        data, file_name = download_s3_zip_bytes(s3_key)
        with ZipFile(BytesIO(data), "r") as zf:
            names = zf.namelist()
            raw = zf.read(names[0]) if names else b""
        text = raw.decode("utf-8", errors="replace")
        # Review decision (timestamps): the VIEW is always timestamp-free. Cleaning at serve time
        # covers artifacts stored BEFORE the cleaned-storage change too; the /download-zip route
        # keeps the exact stored bytes for anyone needing the untouched file.
        from src.utils.content_fingerprint import clean_volatile_text_for_display
        text = clean_volatile_text_for_display(text)
        resp = Response(text, mimetype="text/plain; charset=utf-8")
        resp.headers["Content-Disposition"] = f'inline; filename="{(file_name or "artifact")}.txt"'
        return resp
    except Exception as e:
        return jsonify({"error": str(e)}), 404


@app.route("/download-zip", methods=["GET"])
def download_zip():
    """Download a zip artifact given a full S3 HTTPS URL.

    Query params:
        url  – full S3 URL, e.g. https://pmt-ai-s3.s3.ap-south-1.amazonaws.com/task-runtime-artifacts/...
    """
    from io import BytesIO
    raw_url = (request.args.get("url") or "").strip()
    if not raw_url:
        return jsonify({"error": "url query parameter is required"}), 400

    s3_key = _extract_s3_key_from_url(raw_url)
    if s3_key is None:
        return jsonify({"error": "Unrecognised S3 URL"}), 400

    # Strip any URL-encoding artefacts that can come from the query string
    s3_key = s3_key.rstrip('"').rstrip("%22")

    if not any(s3_key.startswith(p) for p in _ALLOWED_ARTIFACT_PREFIXES):
        return jsonify({"error": "Invalid artifact path"}), 400

    try:
        data, file_name = download_s3_zip_bytes(s3_key)
        return send_file(
            BytesIO(data),
            as_attachment=True,
            download_name=file_name,
            mimetype="application/zip",
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 404


@app.route("/download-all-artifacts/<request_id>", methods=["GET"])
def download_all_artifacts(request_id):
    """Bundle all binary + log artifacts for a request_id into one zip and download it.

    Contents are extracted from each artifact zip so the bundle contains actual
    files (not nested zips). Files are placed under binary/ or logs/ subfolders.
    """
    from io import BytesIO
    from zipfile import ZipFile, ZIP_DEFLATED

    request_id = (request_id or "").strip()
    if not request_id:
        return jsonify({"error": "request_id is required"}), 400

    binary_refs = get_artifact_references(request_id, "binary")
    runtime_refs = get_artifact_references(request_id, "runtime")

    if not binary_refs and not runtime_refs:
        return jsonify({"error": "No artifacts found for request_id"}), 404

    bundle = BytesIO()
    added = 0
    errors = []

    with ZipFile(bundle, mode="w", compression=ZIP_DEFLATED) as out_zf:
        for artifact_type, refs in (("binary", binary_refs), ("logs", runtime_refs)):
            seen_names = {}
            for ref in refs:
                s3_key = (ref.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
                if not s3_key:
                    continue
                if not any(s3_key.startswith(p) for p in _ALLOWED_ARTIFACT_PREFIXES):
                    continue
                try:
                    zip_bytes, _ = download_s3_zip_bytes(s3_key)
                    with ZipFile(BytesIO(zip_bytes), "r") as inner_zf:
                        for entry in inner_zf.namelist():
                            raw_name = entry.rsplit("/", 1)[-1] or entry
                            # deduplicate names within the same subfolder
                            count = seen_names.get(raw_name, 0)
                            seen_names[raw_name] = count + 1
                            dest_name = f"{artifact_type}/{raw_name}" if count == 0 else f"{artifact_type}/{count}_{raw_name}"
                            out_zf.writestr(dest_name, inner_zf.read(entry))
                            added += 1
                except Exception as exc:
                    errors.append({"s3_key": s3_key, "error": str(exc)})

    if added == 0:
        return jsonify({"error": "Failed to download any artifacts", "details": errors}), 502

    bundle.seek(0)
    return send_file(
        bundle,
        as_attachment=True,
        download_name=f"{request_id}-artifacts.zip",
        mimetype="application/zip",
    )


# --------------------------------------------------
# DIFF API
# --------------------------------------------------

@app.route("/show-diff-page/<request_id>", methods=["POST"])
def show_diff_page(request_id):
    return jsonify(
        handlers.handle_show_diff_page_by_request(request_id)
    ), 200


@app.route("/show-diff-page/vector/<vector_id>", methods=["POST"])
def show_diff_page_vector(vector_id):
    return jsonify(
        handlers.handle_show_diff_page(vector_id)
    ), 200


# Dashboard Diff Viewer module (UI dev spec): before/after file content per changed file for a
# request. Same data source as /show-diff-page/<request_id>, wrapped in the {success, message,
# data} envelope; the frontend computes the line-by-line diff itself. Documented in /docs.
@app.route("/difference-viewer/<request_id>", methods=["GET"])
def difference_viewer(request_id):
    try:
        data = handlers.handle_difference_viewer(request_id)
    except Exception as e:
        return _error_response(e, 500)
    if not data:
        return jsonify({
            "success": False,
            "message": "No diff data found for this request",
            "data": None,
        }), 404
    return jsonify({
        "success": True,
        "message": "Diff details fetched successfully",
        "data": data,
    }), 200




# --------------------------------------------------
# STATIC IMAGES
# --------------------------------------------------

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
IMAGE_DIR = os.path.join(PROJECT_ROOT, "images")


@app.route("/image/<name>")
def return_image(name):
    images = {
        "icon": "icons.png",
        "history": "history.png",
        "compare": "compareicon.png",
        "vector": "Vector.png"
    }

    if name not in images:
        return {"error": "Image not found"}, 404

    image_path = os.path.join(IMAGE_DIR, images[name])

    if not os.path.exists(image_path):
        return {"error": "File not found"}, 404

    return send_file(image_path, mimetype="image/png")


# --------------------------------------------------
# DIFF VIEW UI (KEEP AS IS)
# --------------------------------------------------

_ARTIFACT_DIFF_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Artifact Diff</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/diff2html/bundles/css/diff2html.min.css">
<style>
  html,body{height:100%;margin:0;font-family:"Segoe UI",Arial,sans-serif;background:#f4f5f7;color:#222;}
  .wrap{display:flex;flex-direction:column;height:100vh;}
  .topbar{background:#0b7a43;color:#fff;padding:10px 16px;font-size:14px;line-height:1.5;flex:0 0 auto;}
  .legend{display:flex;gap:18px;align-items:center;padding:8px 16px;background:#fff;
          border-bottom:1px solid #e3e3e3;font-size:13px;color:#444;flex-wrap:wrap;flex:0 0 auto;}
  .chip{display:inline-flex;align-items:center;gap:6px;}
  .sw{width:14px;height:14px;border-radius:3px;display:inline-block;border:1px solid rgba(0,0,0,.18);}
  .sw.red{background:#f8ccd0;} .sw.green{background:#c7e9c8;} .sw.white{background:#fff;}
  .controls{margin-left:auto;display:flex;gap:8px;}
  .btn{border:1px solid #cfcfcf;background:#fff;border-radius:6px;padding:5px 12px;font-size:13px;cursor:pointer;color:#333;}
  .btn.active{background:#0b7a43;color:#fff;border-color:#0b7a43;}
  .diffhost{flex:1 1 auto;overflow:auto;padding:12px 16px;}
  .d2h-wrapper{font-size:12.5px;}
  .d2h-file-header{display:none;}            /* hide diff2html's own file header - we have our own bar */
  .empty{padding:48px 16px;text-align:center;color:#666;font-size:15px;}
</style>
</head>
<body>
<div class="wrap">
  <div class="topbar">__INFO__</div>
  <div class="legend">
    <span class="chip"><span class="sw red"></span> Removed since previous build</span>
    <span class="chip"><span class="sw green"></span> Added / changed this build</span>
    <span class="chip"><span class="sw white"></span> Unchanged</span>
    <div class="controls">
      <button class="btn active" id="btnSide">Side-by-side</button>
      <button class="btn" id="btnInline">Inline</button>
    </div>
  </div>
  <div class="diffhost"><div id="diff"></div></div>
</div>
<script src="https://cdn.jsdelivr.net/npm/diff2html/bundles/js/diff2html.min.js"></script>
<script>
  var diffString = __DIFF_JSON__;
  var identical = __IDENTICAL__;
  var host = document.getElementById('diff');
  var btnSide = document.getElementById('btnSide');
  var btnInline = document.getElementById('btnInline');
  function render(fmt){
    if(identical || !diffString || !diffString.trim()){
      host.innerHTML = '<div class="empty">No differences &mdash; the kept content matches the original '
                     + '(only noise / timestamps were normalised).</div>';
      return;
    }
    host.innerHTML = Diff2Html.html(diffString, {
      outputFormat: fmt, drawFileList: false, matching: 'lines'
    });
  }
  btnSide.onclick = function(){ btnSide.classList.add('active'); btnInline.classList.remove('active'); render('side-by-side'); };
  btnInline.onclick = function(){ btnInline.classList.add('active'); btnSide.classList.remove('active'); render('line-by-line'); };
  // side-by-side on wide screens, inline on narrow - so it fits every resolution
  var startFmt = window.innerWidth < 900 ? 'line-by-line' : 'side-by-side';
  if(startFmt === 'line-by-line'){ btnInline.classList.add('active'); btnSide.classList.remove('active'); }
  render(startFmt);
</script>
</body>
</html>"""


@app.route("/artifact-diff", methods=["GET"])
def artifact_diff():
    import difflib
    import json as _json
    import html as _htmlmod
    res = handlers.handle_artifact_diff(request.args.get("s3_key", ""), request.args.get("project", ""))
    if not res:
        return "Missing or unknown s3_key", 400
    fname = str(res.get("file_name") or "artifact")
    previous = res.get("previous") or ""
    original = res.get("original") or ""
    if previous.strip():
        # TRUE git-style diff: previous build (old) vs current file (new). Same file, two versions ->
        # mostly UNCHANGED (white), with RED = removed since last build, GREEN = added this build.
        # The highlighted lines are exactly what we send to the AI; unchanged (white) is skipped.
        left, right = previous.splitlines() or [""], original.splitlines() or [""]
        left_tag, right_tag = "previous build", "current build"
        info = (f"<b>{_htmlmod.escape(fname)}</b> &mdash; what changed in this build cycle: "
                f"previous build ({res['previous_chars']:,} chars) &rarr; this build "
                f"({res['original_chars']:,} chars). Green = added/changed, red = removed, "
                f"white = unchanged.")
    else:
        # First time we've collected this file (no previous build to compare against yet).
        left, right = original.splitlines() or [""], (res.get("kept") or "").splitlines() or [""]
        left_tag, right_tag = "this build", "this build"
        info = (f"<b>{_htmlmod.escape(fname)}</b> &mdash; first time this file was collected "
                f"({res['original_chars']:,} chars) &mdash; no previous build to compare against yet.")
    # unified diff with context (n=3) collapses unchanged regions; diff2html colors removals red,
    # additions green, context white.
    diff_text = "\n".join(difflib.unified_diff(
        left, right, fromfile=f"a/{fname} ({left_tag})", tofile=f"b/{fname} ({right_tag})",
        lineterm="", n=3))
    identical = not diff_text.strip()
    _MAX = 800_000  # cap so a very large artifact never freezes the browser
    if len(diff_text) > _MAX:
        diff_text = diff_text[:_MAX]
        info += " &middot; <i>diff truncated for display</i>"
    # json.dumps -> safe JS string literal; neutralise any literal </script> in the content
    diff_js = _json.dumps(diff_text).replace("</", "<\\/")
    return (_ARTIFACT_DIFF_TEMPLATE
            .replace("__INFO__", info)
            .replace("__DIFF_JSON__", diff_js)
            .replace("__IDENTICAL__", "true" if identical else "false"))


@app.route("/diff_view/<vector_id>", methods=["GET"])
@app.route("/diff_view/request/<request_id>", methods=["GET"])
def diff_view(vector_id=None, request_id=None):
    return """
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Compare Changes</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/diff2html/bundles/css/diff2html.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

    <style>
        :root {
            --header-height: 48px;
            --border-color: #ddd;
            --sidebar-bg: #f7f7f7;
        }

        html,
        body {
            height: 100%;
            margin: 0;
            font-family: "Segoe UI", sans-serif;
            background: #4f4f4f;
            overflow: hidden;
        }

        .app {
            display: flex;
            height: 100%;
            background: #fff;
        }

        .sidebar {
            width: 260px;
            background: var(--sidebar-bg);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            transition: width 0.25s ease;
        }

        .sidebar-header {
            height: var(--header-height);
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 12px;
            border-bottom: 1px solid var(--border-color);
            background: #ffffff;
            font-size: 14px;
            font-weight: 600;
        }

        .sidebar-header img {
            height: 22px;
        }

        .sidebar-title {
            white-space: nowrap;
        }

        .collapse-btn {
            margin-left: auto;
            background: transparent;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color: #555;
        }

        .file-list {
            flex: 1;
            overflow: auto;
        }

        .file {
            padding: 10px 16px;
            font-size: 13px;
            cursor: pointer;
            display: flex;
            gap: 8px;
            align-items: center;
            border-bottom: 1px solid #eee;
        }

        .file:hover {
            background: #e0f0ff;
        }

        .file.active {
            background: #eef5f2;
            color: #007ACC;
            font-weight: 600;
        }

        /* COLLAPSED SIDEBAR */
        .sidebar.collapsed {
            width: 64px;
        }

        .sidebar.collapsed .sidebar-title,
        .sidebar.collapsed .file-name {
            display: none;
        }

        .sidebar.collapsed .file {
            justify-content: center;
            padding: 12px 0;
            position: relative;
        }

        .sidebar.collapsed .file i {
            font-size: 18px;
        }

        .sidebar.collapsed .file:hover::after {
            content: attr(data-name);
            position: absolute;
            left: 72px;
            background: #333;
            color: #fff;
            padding: 4px 8px;
            font-size: 12px;
            border-radius: 4px;
            white-space: nowrap;
            pointer-events: none;
        }

        .component {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .component-header {
            height: var(--header-height);
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 12px;
            border-bottom: 1px solid var(--border-color);
            background: #fafafa;
        }

        .path-download {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
            min-width: 0;
        }

        .file-path {
            font-size: 13px;
            color: #444;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .download-wrapper {
            position: relative;
        }

        .download-btn {
            background: #334155;
            border: none;
            color: #fff;
            padding: 4px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        .download-menu {
            position: absolute;
            top: 40px;
            right: 0;
            background: #fff;
            border: 1px solid #00893D;
            border-radius: 6px;
            display: none;
            min-width: 180px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, .2);
            z-index: 100;
        }

        .download-menu .item {
            padding: 10px 14px;
            font-size: 13px;
            cursor: pointer;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .download-menu .item:hover {
            background: #E6F4EC;
        }

        .logo {
            margin-left: auto;
            height: 22px;
        }

        .content {
            flex: 1;
            overflow: auto;
            position: relative;
        }

        .diff-header {
            display: flex;
            font-size: 13px;
            border-bottom: 1px solid var(--border-color);
            position: sticky;
            top: 0;
            z-index: 30;
            background: #fff;
        }

        .diff-header .left,
        .diff-header .right {
            width: 50%;
            padding: 6px 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .diff-title {
            display: flex;
            align-items: center;
            gap: 6px;
            min-width: 0;
        }

        .diff-nav {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .diff-nav button {
            border: 1px solid rgba(0, 0, 0, 0.15);
            background: rgba(255, 255, 255, 0.85);
            color: inherit;
            border-radius: 6px;
            padding: 2px 8px;
            cursor: pointer;
            font-size: 12px;
            line-height: 18px;
        }

        .diff-nav button:hover {
            background: #fff;
        }

        .diff-nav button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .diff-nav button:active {
            transform: translateY(1px);
        }

        .d2h-jump-highlight td {
            outline: none !important;
        }

        .diff-header .left {
            background: #ffecec;
            color: #b00000;
        }

        .diff-header .right {
            background: #e8f8ee;
            color: #0a7a3a;
            border-left: 3px solid #1976d2;
        }

        .diff-header img {
            width: 16px;
            height: 16px;
        }

        .d2h-file-header {
            display: none;
        }

        .d2h-code-linenumber,
        .d2h-code-side-linenumber {
            position: sticky !important;
            left: 0 !important;
            top: auto !important;
            z-index: 10;
            background: #f7f7f7 !important;
            border-right: 1px solid var(--border-color);
            isolation: isolate;
            overflow: hidden;
        }

        .d2h-diff-table {
            border-collapse: collapse !important;
            border-spacing: 0 !important;
        }

        /* Ensure the sticky line-number gutter is always opaque, matching row colors */
        tr.d2h-del td.d2h-code-linenumber,
        tr.d2h-del td.d2h-code-side-linenumber {
            background: #ffecec !important;
        }

        tr.d2h-ins td.d2h-code-linenumber,
        tr.d2h-ins td.d2h-code-side-linenumber {
            background: #e8f8ee !important;
        }

        tr.d2h-info td.d2h-code-linenumber,
        tr.d2h-info td.d2h-code-side-linenumber {
            background: #f1f1f1 !important;
        }

        .sidebar.collapsed .sidebar-logo {
            display: none;
        }

        .sidebar.collapsed .sidebar-header {
            justify-content: center;
            padding: 0;
        }

        .sidebar.collapsed .collapse-btn {
            /* background: #e6f2ff; */
            /* border-radius: 50%; */
            padding: 8px;
        }

        .d2h-del {
            background-color: #ffecec !important;
        }

        .d2h-ins {
            background-color: #e8f8ee !important;
        }
    </style>
</head>

<body>

    <div class="app">

        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="/image/compare" class="sidebar-logo" id="sidebarLogo">

                <button class="collapse-btn" id="collapseBtn">
                    <i class="fa-solid fa-chevron-left"></i>
                </button>
            </div>


            <div class="file-list" id="fileList"></div>
        </aside>

        <section class="component">

            <div class="component-header">
                <div class="path-download">
                    <div class="file-path" id="filePath"></div>

                    <div class="download-wrapper">
                        <button class="download-btn" id="downloadBtn">
                            <i class="fa-solid fa-download"></i>
                        </button>

                        <div class="download-menu" id="downloadMenu">
                            <div class="item" data-type="old">
                                <i class="fa-solid fa-file"></i> Download Original
                            </div>
                            <div class="item" data-type="new">
                                <i class="fa-solid fa-file-pen"></i> Download Modified
                            </div>
                        </div>
                    </div>
                </div>

                <img src="/image/icon" class="logo">
            </div>

            <div class="content">
                <div id="diff"></div>
            </div>

        </section>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/diff@5.1.0/dist/diff.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/diff2html/bundles/js/diff2html.min.js"></script>

    <script>
        // Where this application is mounted, worked out from the page's own address.
        //
        // On the servers the app is served under /agent, so a URL written as "/image/icon" or
        // "/show-diff-page/..." leaves the prefix off and resolves at the domain root - the
        // images 404 and the diff never loads. Taking everything before "/diff_view/" gives
        // "/agent" there and "" when the app is served at the root, so the same page works
        // either way without the proxy having to set anything.
        const BASE = window.location.pathname.split("/diff_view/")[0];

        // The images are written into the markup above with a leading slash; rewrite them once,
        // here, rather than in four places. This runs with the body already parsed.
        document.querySelectorAll('img[src^="/image/"]').forEach(function (el) {
            el.setAttribute("src", BASE + el.getAttribute("src"));
        });

        function getVectorIdFromUrl() {
            const parts = window.location.pathname.split("/");
            return parts[parts.length - 1];
        }

        async function fetchCompareData() {
            const vectorId = getVectorIdFromUrl();
            const API_URL = `${BASE}/show-diff-page/${vectorId}`;

            const res = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                }
            });

            if (!res.ok) {
                throw new Error("Failed to fetch diff data");
            }
            const data = await res.json();
            return {
                files: data.diff_files.map(file => ({
                    name: file.file_name,
                    path: file.file_path || "",
                    oldText: decodeEscapedNewlines(file.before_file_text) ?? "",
                    newText: decodeEscapedNewlines(file.after_file_text) ?? ""
                }))
            };
        }


        function decodeEscapedNewlines(text) {
            if (!text) return "";
            try {
                return JSON.parse(`"${text.replace(/"/g, '\"')}"`);
            } catch {
                return text;
            }
        }


        let files = [];
        let currentFile = null;

        async function init() {
            const data = await fetchCompareData();
            files = data.files;
            renderFileList();
            showDiff(0, document.querySelector(".file"));
        }

        function renderFileList() {
            const list = document.getElementById("fileList");
            list.innerHTML = "";

            files.forEach((f, i) => {
                const div = document.createElement("div");
                div.className = "file" + (i === 0 ? " active" : "");
                div.setAttribute("data-name", f.name);
                div.innerHTML = `
            <i class="fa-solid fa-file-code"></i>
            <span class="file-name">${f.name}</span>
        `;

                div.onclick = () => {
                    showDiff(i, div);
                };

                list.appendChild(div);
            });
        }

        function addedCount(diff) {
            return (diff.match(/^\+/gm) || []).length;
        }

        function showDiff(index, el) {
            currentFile = files[index];
            document.getElementById("filePath").textContent = currentFile.path;

            document.querySelectorAll(".file").forEach(f => f.classList.remove("active"));
            el.classList.add("active");

            const diffText = Diff.createTwoFilesPatch(
                currentFile.path,
                currentFile.path,
                currentFile.oldText,
                currentFile.newText,
                "Original",
                "Modified",
                { context: Infinity }
            );

            document.getElementById("diff").innerHTML = `
         <div class="diff-header">
             <div class="left">
             <div class="diff-title">
                 <img src="${BASE}/image/history">
                 <span>Original Version</span>
             </div>
             <div class="diff-nav">
                 <button type="button" id="prevChangeBtn" title="Previous change">? Prev</button>
             </div>
             </div>
             <div class="right">
             <div class="diff-title">
                 <img src="${BASE}/image/vector">
                 <span>Updated Version +${addedCount(diffText) - 1} Lines</span>
             </div>
             <div class="diff-nav">
                 <button type="button" id="nextChangeBtn" title="Next change">Next ?</button>
             </div>
             </div>
         </div>
         ${Diff2Html.html(diffText, {
                outputFormat: "side-by-side",
                drawFileList: false
            })}
         `;
            queueMicrotask(() => {
                const content = document.querySelector(".content");
                content?.scrollTo({ top: 0, left: 0 });
                setupDiffScrollSync();
                setupDiffChangeNav();
            });
        }

        let cleanupDiffScrollSync = null;
        let diffScrollSyncState = { left: null, right: null };
        let cleanupDiffChangeNav = null;

        function setupDiffScrollSync() {
            if (typeof cleanupDiffScrollSync === "function") cleanupDiffScrollSync();

            const root = document.getElementById("diff");
            if (!root) return;

            const selectorGroups = [
                ".d2h-file-side-diff",
                ".d2h-code-wrapper",
                ".d2h-file-diff"
            ];

            const isScrollable = (el) =>
                !!el &&
                (el.scrollHeight > el.clientHeight || el.scrollWidth > el.clientWidth);

            let left = null;
            let right = null;

            for (const selector of selectorGroups) {
                const matches = Array.from(root.querySelectorAll(selector)).filter(isScrollable);
                if (matches.length >= 2) {
                    const sorted = matches
                        .map((el) => ({ el, left: el.getBoundingClientRect().left }))
                        .sort((a, b) => a.left - b.left)
                        .map((x) => x.el);
                    left = sorted[0];
                    right = sorted[sorted.length - 1];
                    break;
                }
            }

            if (!left || !right || left === right) {
                cleanupDiffScrollSync = null;
                return;
            }

            diffScrollSyncState = { left, right };

            left.scrollTop = 0;
            right.scrollTop = 0;
            left.scrollLeft = 0;
            right.scrollLeft = 0;

            let syncingFrom = null;
            const sync = (from, to) => {
                syncingFrom = from;
                to.scrollTop = from.scrollTop;
                to.scrollLeft = from.scrollLeft;
                requestAnimationFrame(() => {
                    if (syncingFrom === from) syncingFrom = null;
                });
            };

            const onLeft = () => {
                if (syncingFrom === right) return;
                sync(left, right);
            };
            const onRight = () => {
                if (syncingFrom === left) return;
                sync(right, left);
            };

            left.addEventListener("scroll", onLeft, { passive: true });
            right.addEventListener("scroll", onRight, { passive: true });

            cleanupDiffScrollSync = () => {
                left.removeEventListener("scroll", onLeft);
                right.removeEventListener("scroll", onRight);
                cleanupDiffScrollSync = null;
                diffScrollSyncState = { left: null, right: null };
            };
        }

        function setupDiffChangeNav() {
            if (typeof cleanupDiffChangeNav === "function") cleanupDiffChangeNav();

            const root = document.getElementById("diff");
            const prevBtn = document.getElementById("prevChangeBtn");
            const nextBtn = document.getElementById("nextChangeBtn");
            if (!root || !prevBtn || !nextBtn) return;

            const contentScroller = document.querySelector(".content");
            const leftPane = diffScrollSyncState?.left || null;
            const rightPane = diffScrollSyncState?.right || null;
            const isVertScrollable = (el) => !!el && (el.scrollHeight - el.clientHeight) > 1;
            const verticalScroller =
                (isVertScrollable(contentScroller) && contentScroller) ||
                (isVertScrollable(leftPane) && leftPane) ||
                (isVertScrollable(rightPane) && rightPane) ||
                null;

            const getScrollParent = (el) => {
                let node = el?.parentElement;
                while (node) {
                    const style = window.getComputedStyle(node);
                    const overflowY = style.overflowY;
                    const canScrollY = (overflowY === "auto" || overflowY === "scroll") && node.scrollHeight > node.clientHeight;
                    if (canScrollY) return node;
                    node = node.parentElement;
                }
                return contentScroller || document.scrollingElement || document.documentElement;
            };

            const getScroller = (el) => {
                if (contentScroller && contentScroller.scrollHeight > contentScroller.clientHeight) return contentScroller;
                return getScrollParent(el);
            };

            const getTargets = () => {
                const rows = [];

                for (const tr of root.querySelectorAll("tr.d2h-del, tr.d2h-ins")) {
                    rows.push(tr);
                }

                const rowSet = new Set(rows);
                for (const cell of root.querySelectorAll("td.d2h-del, td.d2h-ins")) {
                    const tr = cell.closest("tr");
                    if (tr) rowSet.add(tr);
                }

                return Array.from(rowSet).filter((tr) => tr.offsetParent !== null);
            };

            const getTopInScroller = (target, scroller) => {
                const targetRect = target.getBoundingClientRect();
                const scrollRect = scroller.getBoundingClientRect?.() || { top: 0 };
                return (targetRect.top - scrollRect.top) + scroller.scrollTop;
            };

            let lastHighlighted = null;
            const highlight = (tr) => {
                if (lastHighlighted) lastHighlighted.classList.remove("d2h-jump-highlight");
                lastHighlighted = tr;
                tr.classList.add("d2h-jump-highlight");
                window.setTimeout(() => {
                    tr.classList.remove("d2h-jump-highlight");
                    if (lastHighlighted === tr) lastHighlighted = null;
                }, 1200);
            };

            let scroller = null;
            let positionsOld = [];
            let positionsNew = [];
            let isJumping = false;
            let jumpResetTimer = null;
            let baseLineOffset = 18;

            const epsilon = 6;

            const getHeaderOffset = () => {
                const header = root.querySelector(".diff-header");
                if (!header) return 0;
                if (scroller && contentScroller && scroller === contentScroller) return header.offsetHeight || 64;
                return 0;
            };

            const setJumping = () => {
                isJumping = true;
                if (jumpResetTimer) window.clearTimeout(jumpResetTimer);
                prevBtn.disabled = true;
                nextBtn.disabled = true;
            };

            const endJumping = () => {
                isJumping = false;
                updateButtons();
            };

            const waitForScrollStop = () => {
                if (!scroller) {
                    endJumping();
                    return;
                }

                const start = performance.now();
                let finished = false;
                let quietTimer = null;
                let hardTimer = null;

                const finish = () => {
                    if (finished) return;
                    finished = true;
                    if (quietTimer) window.clearTimeout(quietTimer);
                    if (hardTimer) window.clearTimeout(hardTimer);
                    scroller.removeEventListener("scroll", onJumpScroll);
                    endJumping();
                };

                const armQuiet = () => {
                    if (quietTimer) window.clearTimeout(quietTimer);
                    quietTimer = window.setTimeout(finish, 140);
                };

                const onJumpScroll = () => {
                    armQuiet();
                    if (performance.now() - start > 2000) finish();
                };

                scroller.addEventListener("scroll", onJumpScroll, { passive: true });
                armQuiet();
                hardTimer = window.setTimeout(finish, 2200);
            };

            const refresh = () => {
                const allTargets = getTargets();
                if (!allTargets.length) {
                    scroller = verticalScroller || contentScroller || document.scrollingElement || document.documentElement;
                    positionsOld = [];
                    positionsNew = [];
                    return;
                }

                scroller = verticalScroller || getScroller(allTargets[0]);
                const sampleLine =
                    root.querySelector(".d2h-code-line") ||
                    root.querySelector("td.d2h-code-line") ||
                    root.querySelector(".d2h-code-side-line") ||
                    root.querySelector("td.d2h-code-side-line");
                if (sampleLine) {
                    const lh = parseFloat(window.getComputedStyle(sampleLine).lineHeight);
                    if (Number.isFinite(lh) && lh > 0) baseLineOffset = lh;
                    else {
                        const h = sampleLine.getBoundingClientRect().height;
                        if (Number.isFinite(h) && h > 0) baseLineOffset = h;
                    }
                }

                const buildPositions = (kind) => {
                    const rows = new Set();
                    for (const tr of root.querySelectorAll(`tr.d2h-${kind}`)) rows.add(tr);
                    for (const td of root.querySelectorAll(`td.d2h-${kind}`)) {
                        const tr = td.closest("tr");
                        if (tr) rows.add(tr);
                    }
                    return Array.from(rows)
                        .filter((tr) => tr.offsetParent !== null)
                        .map((tr) => ({ tr, top: getTopInScroller(tr, scroller) }))
                        .sort((a, b) => a.top - b.top);
                };

                positionsOld = buildPositions("del");
                positionsNew = buildPositions("ins");
            };

            const updateButtons = () => {
                const newIdx = computeIndexFromScroll(positionsNew);
                prevBtn.disabled = (scroller?.scrollTop ?? 0) <= 0.5;
                nextBtn.disabled = positionsNew.length === 0 || newIdx >= positionsNew.length - 1;
            };

            const computeIndexFromScroll = (pos) => {
                if (!pos.length) return -1;
                const y = scroller.scrollTop + getHeaderOffset() + baseLineOffset + epsilon;
                let idx = -1;
                for (let i = 0; i < pos.length; i++) {
                    if (pos[i].top <= y) idx = i;
                    else break;
                }
                return idx;
            };

            const jumpToTop = () => {
                setJumping();
                scroller.scrollTo({ top: 0, behavior: "smooth" });
                updateButtons();
                waitForScrollStop();
            };

            const jumpToIndex = (pos, idx) => {
                if (!pos.length) return;
                const clamped = Math.max(0, Math.min(idx, pos.length - 1));
                const target = pos[clamped].tr;
                const top = pos[clamped].top;
                setJumping();
                let destTop = top - getHeaderOffset() - baseLineOffset;
                if (destTop <= 0) destTop = 1;
                scroller.scrollTo({ top: destTop, behavior: "smooth" });
                highlight(target);
                updateButtons();
                waitForScrollStop();
            };

            const jump = (direction) => {
                if (isJumping) return;
                refresh();
                updateButtons();

                if (direction === "next") {
                    const idx = computeIndexFromScroll(positionsNew);
                    jumpToIndex(positionsNew, idx + 1);
                    return;
                }

                const idx = computeIndexFromScroll(positionsOld);
                if (!positionsOld.length) {
                    jumpToTop();
                    return;
                }
                if (idx <= 0) jumpToTop();
                else jumpToIndex(positionsOld, idx - 1);
            };

            const onPrev = () => jump("prev");
            const onNext = () => jump("next");

            prevBtn.addEventListener("click", onPrev);
            nextBtn.addEventListener("click", onNext);

            cleanupDiffChangeNav = () => {
                prevBtn.removeEventListener("click", onPrev);
                nextBtn.removeEventListener("click", onNext);
                cleanupDiffChangeNav = null;
            };

            refresh();
            updateButtons();

            const onScroll = () => {
                if (!scroller) return;
                if (isJumping) return;
                updateButtons();
            };
            scroller?.addEventListener("scroll", onScroll, { passive: true });

            const previousCleanup = cleanupDiffChangeNav;
            cleanupDiffChangeNav = () => {
                previousCleanup?.();
                scroller?.removeEventListener("scroll", onScroll);
                cleanupDiffChangeNav = null;
            };
        }

        const sidebar = document.querySelector(".sidebar");
        const collapseBtn = document.getElementById("collapseBtn");
        const downloadBtn = document.getElementById("downloadBtn");
        const downloadMenu = document.getElementById("downloadMenu");

        collapseBtn.onclick = () => {
            const collapsed = sidebar.classList.toggle("collapsed");
            collapseBtn.innerHTML = collapsed
                ? '<i class="fa-solid fa-chevron-right"></i>'
                : '<i class="fa-solid fa-chevron-left"></i>';
        };

        downloadBtn.onclick = (e) => {
            e.stopPropagation();
            downloadMenu.style.display =
                downloadMenu.style.display === "block" ? "none" : "block";
        };

        document.querySelectorAll(".download-menu .item").forEach(item => {
            item.onclick = () => {
                if (!currentFile) return;

                const type = item.dataset.type;
                const content =
                    type === "old" ? currentFile.oldText : currentFile.newText;

                const BOM = "﻿";

                const blob = new Blob(
                    [BOM + content],
                    { type: "text/plain;charset=utf-8" }
                );

                const a = document.createElement("a");
                a.href = URL.createObjectURL(blob);

                a.download = currentFile.name.replace(/\.[^/.]+$/, "") +
                    (type === "old" ? "_ORIGINAL.txt" : "_MODIFIED.txt");

                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);

                URL.revokeObjectURL(a.href);
            };
        });

        document.addEventListener("click", () => {
            downloadMenu.style.display = "none";
        });

        init();
    </script>


</body>

</html>
    """

###all-documents###
@app.route("/s3/documents", methods=["GET"])
def get_s3_documents():
    try:
        prefix = (request.args.get("prefix") or "").strip()
        # Default ON for the documents view: the same document re-uploaded across cycles produces
        # several keys with the same file name — show each name once. Pass unique_names=false for all.
        unique_names = str(request.args.get("unique_names", "true")).strip().lower() in {
            "1", "true", "yes"
        }
        # No default action filter — pass ?action=uploaded to restrict to new-style uploads only,
        # or ?action=modified for files injected before the "uploaded" action was introduced.
        # Omitting the filter returns all files for the project (safe because project_name scopes the prefix).
        action = (request.args.get("action") or "").strip()
        project_name = (request.args.get("project_name") or "").strip() or None

        result = handlers.list_s3_documents_handler(
            prefix=prefix,
            unique_names=unique_names,
            action=action,
            project_name=project_name,
        )
        return jsonify(result), 200

    except Exception as e:
        return _error_response(e, 500)





















# # src/routes/route.py

# import re
# import json
# import uuid
# import traceback
# from typing import List, Dict
# from flask import Flask, jsonify, request, send_file, send_from_directory, abort
# from flask_cors import CORS
# from werkzeug.utils import secure_filename

# from src.configurations import config

# from src.utils.project_details import (
#     get_project_id,
#     save_solution,
#     save_error_log,
#     get_all_projects,
#     get_total_error_count,
#     get_total_task,
#     get_total_error,
#     get_error_log_by_vector_id,
#     set_recommended_count,
#     get_week_sise_count,
#     save_file_snapshot,
#     get_solution_id,
#     get_diff_files,
#     save_binary_metadata,
# )

# from src.utils.recommended import (
#     save_error_on_vector_db,
#     search_similar_errors,
#     get_files_by_batch_id,
#     get_files_by_batch_id,
# )

# from src.utils.json_extractor import (
#     extract_kts_errors
# )

# # ✅ Azure Search imports (FIXED)
# from src.azure_search.ai_search_client_with_embedding import (
#     hybrid_semantic_search
# )
# from src.azure_search.ai_search_client import upload_document
# from src.utils.oai_client import create_embedding

# app = Flask(__name__)

# # app = Flask(__name__, template_folder="src/templates")
# CORS(app)

# # ------------------------------------------------------------------
# # BASIC HEALTH CHECK
# # ------------------------------------------------------------------

# @app.route("/")
# def home():
#     return "OK"

# # ------------------------------------------------------------------
# # HEALTH CHECK
# # ------------------------------------------------------------------
# @app.route("/health", methods=["GET"])
# def health():
#     return jsonify({
#         "status": "ok",
#         "service": "bsw-python-backend"
#     }), 200


# # ------------------------------------------------------------------
# # FINAL BUILD (PRIMARY PIPELINE)
# # ------------------------------------------------------------------
# @app.route("/final-build", methods=["POST"])
# def final_build():
#     data = request.get_json()

#     batch_id = data.get("batchId")
#     all_changes = data.get("all_changes")
#     all_solution = data.get("solution")

#     kts_errors, project_name, process_file, developer_id, snapshot_files = \
#         extract_kts_errors(all_changes)

#     project_id = get_project_id(project_name)

#     solution_id = save_solution(
#         solution_json=json.dumps(all_solution, indent=4),
#         complete_json=all_changes,
#         project_id=project_id,
#         batch_id=batch_id
#     )

#     for snapshot in snapshot_files:
#         save_file_snapshot(snapshot, solution_id)

#     for kts_error in kts_errors.get("errorDetails", []):
#         vector_id = str(uuid.uuid4())

#         save_error_on_vector_db(
#             vector_id=vector_id,
#             error_message=json.dumps(kts_error.get("message")),
#             all_solution=json.dumps(all_solution, indent=4),
#             batch_id=batch_id
#         )

#         save_error_log(
#             error_message=json.dumps(kts_error.get("message")),
#             process=process_file,
#             developer_id=developer_id,
#             project_id=project_id,
#             solution_id=solution_id,
#             vector_id=vector_id,
#             created_by=None
#         )

#     return jsonify({
#         "message": "Data processed successfully",
#         "solution_id": solution_id,
#         "project_id": project_id,
#         "batch_id": batch_id
#     })

# import os
# from werkzeug.utils import secure_filename

# UPLOAD_DIR = "./uploads"
# os.makedirs(UPLOAD_DIR, exist_ok=True)


# @app.route("/binary-store", methods=["POST"])
# def binary_store():
#     batch_id = request.form.get("uuid")
#     metadata_str = request.form.get("metadata")

#     if not batch_id:
#         return jsonify({"error": "uuid (batchId) is required"}), 400

#     if "files" not in request.files:
#         return jsonify({"error": "No files provided"}), 400

#     files = request.files.getlist("files")
#     metadata_list = json.loads(metadata_str) if metadata_str else []

#     stored_files = []

#     # map metadata by filename for quick lookup
#     metadata_map = {m["fileName"]: m for m in metadata_list}

#     for file in files:
#         original_name = secure_filename(file.filename)
#         new_name = f"{batch_id}-{original_name}"
#         save_path = os.path.join(UPLOAD_DIR, new_name)

#         file.save(save_path)
#         stored_files.append(new_name)

#         # ✅ store metadata in DynamoDB
#         meta = metadata_map.get(original_name, {})

#         save_binary_metadata(
#             batch_id=batch_id,
#             file_name=original_name,
#             file_path=meta.get("filePath"),
#             action=meta.get("action"),
#             stored_path=save_path
#         )

#     return jsonify({
#         "message": "Files + metadata stored successfully",
#         "batch_id": batch_id,
#         "stored_files": stored_files
#     })

# # ------------------------------------------------------------------
# # PROJECT DASHBOARD ROUTES
# # ------------------------------------------------------------------
# @app.route("/get-all-projects", methods=["GET"])
# def get_projects():
#     projects = get_all_projects()
#     return jsonify({
#         "projects": projects,
#         "success": True
#     }), 200


# @app.route("/get-total-error-count/<project_name>", methods=["GET"])
# def get_total_error_count_route(project_name):
#     data = get_total_error_count(project_name)
#     return jsonify({
#         "data": data,
#         "success": True
#     }), 200


# @app.route("/get-tasks/<project_name>", methods=["GET"])
# def get_tasks(project_name):
#     tasks = get_total_task(project_name)
#     return jsonify({
#         "tasks": tasks,
#         "success": True
#     }), 200


# @app.route("/get-total-errors/<project_name>", methods=["GET"])
# def get_total_errors(project_name):
#     errors = get_total_error(project_name)
#     return jsonify({
#         "projects": errors,
#         "success": True,
#         "count": len(errors)
#     }), 200


# @app.route("/get-day-week-wise-count/<project_name>", methods=["GET"])
# def get_week_day_wise_count_route(project_name):
#     results = get_week_sise_count(project_name)
#     return jsonify({
#         "success": True,
#         "results": results
#     }), 200


# # ------------------------------------------------------------------
# # VECTOR RECOMMENDATIONS (CHROMA DB)
# # ------------------------------------------------------------------
# @app.route("/recommendations", methods=["POST"])
# def recommendations():
#     data = request.get_json()

#     results = search_similar_errors(
#         data.get("error_message"),
#         top_k=2
#     )

#     ids = results.get("ids", [[]])[0]

#     for vector_id in ids:
#         error_log_id = get_error_log_by_vector_id(vector_id)
#         if error_log_id:
#             set_recommended_count(error_log_id, 1)

#     return jsonify({
#         "message": "Recommendations endpoint",
#         "results": results
#     }), 200


# # ------------------------------------------------------------------
# # AZURE SEARCH – INDEX CREATION
# # ------------------------------------------------------------------
# @app.route("/create-index", methods=["GET"])
# def create_index():
#     from src.azure_search.ai_search_index_client_with_embedding import (
#         create_example_index_with_embedding
#     )
#     try:
#         index_response = create_example_index_with_embedding(
#             index_name=config.INDEX_NAME
#         )
#         return jsonify({
#             "message": "Index created successfully",
#             "index_response": index_response
#         }), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500


# # ------------------------------------------------------------------
# # REPORT.HTML ERROR PARSING
# # ------------------------------------------------------------------
# def extract_errors_from_report_html(html: str) -> List[Dict[str, str]]:
#     match = re.search(
#         r"// begin-report-data\s*(\{.*?\})\s*// end-report-data",
#         html,
#         re.DOTALL
#     )

#     if not match:
#         raise ValueError("No embedded report data found")

#     report_json = json.loads(match.group(1))
#     diagnostics = report_json.get("diagnostics", [])

#     errors = []
#     for diag in diagnostics:
#         severity = diag.get("severity", "UNKNOWN")
#         for detail in diag.get("problemDetails", []):
#             text = detail.get("text")
#             if text:
#                 errors.append({
#                     "severity": severity,
#                     "message": text.strip()
#                 })

#     if not errors:
#         raise ValueError("No errors found in report")

#     return errors


# @app.route("/report-errors", methods=["POST"])
# def report_errors():
#     try:
#         html = request.get_data(as_text=True)

#         errors = extract_errors_from_report_html(html)
#         msg = errors[0]["message"]

#         results = search_similar_errors(msg, top_k=2)

#         ids = results.get("ids", [[]])[0]
#         metadatas = results.get("metadatas", [[]])[0]

#         batch_ids = set()

#         # increase recommendation count
#         for vector_id in ids:
#             error_log_id = get_error_log_by_vector_id(vector_id)
#             if error_log_id:
#                 set_recommended_count(error_log_id, 1)

#         # collect unique batch ids
#         for meta in metadatas:
#             if meta and meta.get("batch_id"):
#                 batch_ids.add(meta["batch_id"])

#         if not batch_ids:
#             return jsonify({
#                 "status": "success",
#                 "errors": results,
#                 "recommended_files": []
#             }), 200

#         # ✅ only one URL per batch
#         files_metadata = [
#             {
#                 "batch_id": batch_id,
#                 "downloadUrl": f"/download-files/{batch_id}"
#             }
#             for batch_id in batch_ids
#         ]

#         return jsonify({
#             "status": "success",
#             "errors": results,
#             "recommended_files": files_metadata
#         }), 200

#     except Exception as e:
#         traceback.print_exc()
#         return jsonify({
#             "status": "error",
#             "error": str(e)
#         }), 500



# @app.route("/download-files/<batch_id>", methods=["GET"])
# def download_files(batch_id):

#     files = get_files_by_batch_id(batch_id)

#     if not files:
#         abort(404, description="No files found for this batch")

#     requested_file = request.args.get("file")

#     if requested_file:
#         requested_file = secure_filename(requested_file)

#         matched = next(
#             (f for f in files if f.endswith(f"-{requested_file}")),
#             None
#         )

#         if not matched:
#             abort(404, description="File not found")

#         return send_from_directory(
#             UPLOAD_DIR,
#             matched,
#             as_attachment=True,
#             download_name=requested_file
#         )

#     return jsonify({
#         "batch_id": batch_id,
#         "files": [f.replace(f"{batch_id}-", "", 1) for f in files]
#     })


# # ------------------------------------------------------------------
# # DIFF VIEW API
# # ------------------------------------------------------------------
# @app.route("/show-diff-page/<vector_id>", methods=["POST"])
# def show_diff_page(vector_id):
#     solution_id = get_solution_id(vector_id)
#     diff_files = get_diff_files(solution_id)
#     return jsonify({
#         "message": "Show diff page",
#         "solution_id": solution_id,
#         "diff_files": diff_files
#     }), 200


# # ------------------------------------------------------------------
# # STATIC IMAGES
# # ------------------------------------------------------------------
# # @app.route("/image/<name>", methods=["GET"])
# # def return_image(name):
# #     images = {
# #         "icon": "../images/icons.png",
# #         "history": "../images/history.png",
# #         "compare": "../images/compareicon.png",
# #         "vector": "../images/vector.png"
# #     }

# #     if name not in images:
# #         return {"error": "Image not found"}, 404

# #     return send_file(
# #         images[name],
# #         mimetype="image/png",
# #         as_attachment=False
# #     )


# import os
# from flask import send_file

# # routes.py is inside src/routes/
# CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

# # Go up: routes -> src -> AI_SW_BACKEND
# PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))

# IMAGE_DIR = os.path.join(PROJECT_ROOT, "images")

# @app.route("/image/<name>")
# def return_image(name):
#     images = {
#         "icon": "icons.png",
#         "history": "history.png",
#         "compare": "compareicon.png",
#         "vector": "Vector.png"   # correct case
#     }

#     if name not in images:
#         return {"error": "Image not found"}, 404

#     image_path = os.path.join(IMAGE_DIR, images[name])

#     if not os.path.exists(image_path):
#         return {
#             "error": "File not found",
#             "expected_path": image_path
#         }, 404

#     return send_file(image_path, mimetype="image/png")


# # ------------------------------------------------------------------
# # DIFF VIEW UI
# # ------------------------------------------------------------------
# @app.route("/diff_view/<vector_id>", methods=["GET"])
# def diff_view(vector_id):
    
#    return """ 

# <!DOCTYPE html>
# <html lang="en">

# <head>
#     <meta charset="UTF-8" />
#     <title>Compare Changes</title>

#     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/diff2html/bundles/css/diff2html.min.css">
#     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

#     <style>
#         :root {
#             --header-height: 48px;
#             --border-color: #ddd;
#             --sidebar-bg: #f7f7f7;
#         }

#         html,
#         body {
#             height: 100%;
#             margin: 0;
#             font-family: "Segoe UI", sans-serif;
#             background: #4f4f4f;
#             overflow: hidden;
#         }

#         .app {
#             display: flex;
#             height: 100%;
#             background: #fff;
#         }

#         .sidebar {
#             width: 260px;
#             background: var(--sidebar-bg);
#             border-right: 1px solid var(--border-color);
#             display: flex;
#             flex-direction: column;
#             transition: width 0.25s ease;
#         }

#         .sidebar-header {
#             height: var(--header-height);
#             display: flex;
#             align-items: center;
#             gap: 10px;
#             padding: 0 12px;
#             border-bottom: 1px solid var(--border-color);
#             background: #ffffff;
#             font-size: 14px;
#             font-weight: 600;
#         }

#         .sidebar-header img {
#             height: 22px;
#         }

#         .sidebar-title {
#             white-space: nowrap;
#         }

#         .collapse-btn {
#             margin-left: auto;
#             background: transparent;
#             border: none;
#             cursor: pointer;
#             font-size: 16px;
#             color: #555;
#         }

#         .file-list {
#             flex: 1;
#             overflow: auto;
#         }

#         .file {
#             padding: 10px 16px;
#             font-size: 13px;
#             cursor: pointer;
#             display: flex;
#             gap: 8px;
#             align-items: center;
#             border-bottom: 1px solid #eee;
#         }

#         .file:hover {
#             background: #e0f0ff;
#         }

#         .file.active {
#             background: #eef5f2;
#             color: #007ACC;
#             font-weight: 600;
#         }

#         /* COLLAPSED SIDEBAR */
#         .sidebar.collapsed {
#             width: 64px;
#         }

#         .sidebar.collapsed .sidebar-title,
#         .sidebar.collapsed .file-name {
#             display: none;
#         }

#         .sidebar.collapsed .file {
#             justify-content: center;
#             padding: 12px 0;
#             position: relative;
#         }

#         .sidebar.collapsed .file i {
#             font-size: 18px;
#         }

#         .sidebar.collapsed .file:hover::after {
#             content: attr(data-name);
#             position: absolute;
#             left: 72px;
#             background: #333;
#             color: #fff;
#             padding: 4px 8px;
#             font-size: 12px;
#             border-radius: 4px;
#             white-space: nowrap;
#             pointer-events: none;
#         }

#         .component {
#             flex: 1;
#             display: flex;
#             flex-direction: column;
#             overflow: hidden;
#         }

#         .component-header {
#             height: var(--header-height);
#             display: flex;
#             align-items: center;
#             gap: 12px;
#             padding: 0 12px;
#             border-bottom: 1px solid var(--border-color);
#             background: #fafafa;
#         }

#         .path-download {
#             display: flex;
#             align-items: center;
#             gap: 10px;
#             flex: 1;
#             min-width: 0;
#         }

#         .file-path {
#             font-size: 13px;
#             color: #444;
#             white-space: nowrap;
#             overflow: hidden;
#             text-overflow: ellipsis;
#         }

#         .download-wrapper {
#             position: relative;
#         }

#         .download-btn {
#             background: #334155;
#             border: none;
#             color: #fff;
#             padding: 4px 15px;
#             border-radius: 5px;
#             cursor: pointer;
#         }

#         .download-menu {
#             position: absolute;
#             top: 40px;
#             right: 0;
#             background: #fff;
#             border: 1px solid #00893D;
#             border-radius: 6px;
#             display: none;
#             min-width: 180px;
#             box-shadow: 0 4px 10px rgba(0, 0, 0, .2);
#             z-index: 100;
#         }

#         .download-menu .item {
#             padding: 10px 14px;
#             font-size: 13px;
#             cursor: pointer;
#             display: flex;
#             gap: 8px;
#             align-items: center;
#         }

#         .download-menu .item:hover {
#             background: #E6F4EC;
#         }

#         .logo {
#             margin-left: auto;
#             height: 22px;
#         }

#         .content {
#             flex: 1;
#             overflow: auto;
#         }

#         .diff-header {
#             display: flex;
#             font-size: 13px;
#             border-bottom: 1px solid var(--border-color);
#         }

#         .diff-header .left,
#         .diff-header .right {
#             width: 50%;
#             padding: 6px 12px;
#             font-weight: 600;
#             display: flex;
#             align-items: center;
#             gap: 6px;
#         }

#         .diff-header .left {
#             background: #ffecec;
#             color: #b00000;
#         }

#         .diff-header .right {
#             background: #e8f8ee;
#             color: #0a7a3a;
#             border-left: 3px solid #1976d2;
#         }

#         .diff-header img {
#             width: 16px;
#             height: 16px;
#         }

#         .d2h-file-header {
#             display: none;
#         }

#         .d2h-code-linenumber,
#         .d2h-code-side-linenumber {
#             position: relative !important;
#             top: auto !important;
#             background: transparent !important;
#         }

#         .sidebar.collapsed .sidebar-logo {
#             display: none;
#         }

#         .sidebar.collapsed .sidebar-header {
#             justify-content: center;
#             padding: 0;
#         }

#         .sidebar.collapsed .collapse-btn {
#             /* background: #e6f2ff; */
#             /* border-radius: 50%; */
#             padding: 8px;
#         }

#         .d2h-del {
#             background-color: #ffecec !important;
#         }

#         .d2h-ins {
#             background-color: #e8f8ee !important;
#         }
#     </style>
# </head>

# <body>

#     <div class="app">

#         <aside class="sidebar">
#             <div class="sidebar-header">
#                 <img src="https://pmt-ai.aws1678.vitesco.io/image/compare" class="sidebar-logo"
#                     id="sidebarLogo">

#                 <button class="collapse-btn" id="collapseBtn">
#                     <i class="fa-solid fa-chevron-left"></i>
#                 </button>
#             </div>


#             <div class="file-list" id="fileList"></div>
#         </aside>

#         <section class="component">

#             <div class="component-header">
#                 <div class="path-download">
#                     <div class="file-path" id="filePath"></div>

#                     <div class="download-wrapper">
#                         <button class="download-btn" id="downloadBtn">
#                             <i class="fa-solid fa-download"></i>
#                         </button>

#                         <div class="download-menu" id="downloadMenu">
#                             <div class="item" data-type="old">
#                                 <i class="fa-solid fa-file"></i> Download Original
#                             </div>
#                             <div class="item" data-type="new">
#                                 <i class="fa-solid fa-file-pen"></i> Download Modified
#                             </div>
#                         </div>
#                     </div>
#                 </div>

#                 <img src="https://pmt-ai.aws1678.vitesco.io/image/icon" class="logo">
#             </div>

#             <div class="content">
#                 <div id="diff"></div>
#             </div>

#         </section>
#     </div>

#     <script src="https://cdn.jsdelivr.net/npm/diff@5.1.0/dist/diff.min.js"></script>
#     <script src="https://cdn.jsdelivr.net/npm/diff2html/bundles/js/diff2html.min.js"></script>

#     <script>
#        function getVectorIdFromUrl() {
#     const parts = window.location.pathname.split("/");
#     return parts[parts.length - 1];
# }

# async function fetchCompareData() {
#     const vectorId = getVectorIdFromUrl();

#     const API_URL = `/show-diff-page/${vectorId}`;

#     const res = await fetch(API_URL, {
#         method: "POST",
#         headers: {
#             "Content-Type": "application/json"
#         }
#     });

#     if (!res.ok) {
#         throw new Error("Failed to fetch diff data");
#     }

#     const data = await res.json();
#     console.log(data)
#     return {
#         files: data.diff_files.map(file => ({
#             name: file.file_name,
#             path: file.file_path || "",
#             oldText: decodeEscapedNewlines(file.before_file_text) ?? "",
#             newText: decodeEscapedNewlines(file.after_file_text) ?? ""
#         }))
#     };
# }


# function decodeEscapedNewlines(text) {
#     if (!text) return "";
#     try {
#         return JSON.parse(`"${text.replace(/"/g, '\\"')}"`);
#     } catch {
#         return text;
#     }
# }


#         let files = [];
#         let currentFile = null;

#         async function init() {
#             const data = await fetchCompareData();
#             files = data.files;
#             renderFileList();
#             showDiff(0, document.querySelector(".file"));
#         }

#         function renderFileList() {
#             const list = document.getElementById("fileList");
#             list.innerHTML = "";

#             files.forEach((f, i) => {
#                 const div = document.createElement("div");
#                 div.className = "file" + (i === 0 ? " active" : "");
#                 div.setAttribute("data-name", f.name);
#                 div.innerHTML = `
#         <i class="fa-solid fa-file-code"></i>
#         <span class="file-name">${f.name}</span>
#       `;

#                 div.onclick = () => {
#                     if (sidebar.classList.contains("collapsed")) return;
#                     showDiff(i, div);
#                 };

#                 list.appendChild(div);
#             });
#         }

#         function addedCount(diff) {
#             return (diff.match(/^\+/gm) || []).length;
#         }

#         function showDiff(index, el) {
#             currentFile = files[index];
#             document.getElementById("filePath").textContent = currentFile.path;

#             document.querySelectorAll(".file").forEach(f => f.classList.remove("active"));
#             el.classList.add("active");

#             const diffText = Diff.createTwoFilesPatch(
#                 currentFile.path,
#                 currentFile.path,
#                 currentFile.oldText,
#                 currentFile.newText,
#                 "Original",
#                 "Modified",
#                 { context: Infinity }
#             );

#             document.getElementById("diff").innerHTML = `
#       <div class="diff-header">
#         <div class="left">
#           <img src="https://pmt-ai.aws1678.vitesco.io/image/history">
#           <span>Original Version</span>
#         </div>
#         <div class="right">
#           <img src="https://pmt-ai.aws1678.vitesco.io/image/vector">
#           <span>Updated Version +${addedCount(diffText) - 1} Lines</span>
#         </div>
#       </div>
#       ${Diff2Html.html(diffText, {
#                 outputFormat: "side-by-side",
#                 drawFileList: false
#             })}
#     `;
#         }

#         const sidebar = document.querySelector(".sidebar");
#         const collapseBtn = document.getElementById("collapseBtn");
#         const downloadBtn = document.getElementById("downloadBtn");
#         const downloadMenu = document.getElementById("downloadMenu");

#         collapseBtn.onclick = () => {
#             const collapsed = sidebar.classList.toggle("collapsed");
#             collapseBtn.innerHTML = collapsed
#                 ? '<i class="fa-solid fa-chevron-right"></i>'
#                 : '<i class="fa-solid fa-chevron-left"></i>';
#         };

#         downloadBtn.onclick = (e) => {
#             e.stopPropagation();
#             downloadMenu.style.display =
#                 downloadMenu.style.display === "block" ? "none" : "block";
#         };

#         document.querySelectorAll(".download-menu .item").forEach(item => {
#             item.onclick = () => {
#                 if (!currentFile) return;

#                 const type = item.dataset.type;
#                 const content =
#                     type === "old" ? currentFile.oldText : currentFile.newText;

#                 const BOM = "\uFEFF";

#                 const blob = new Blob(
#                     [BOM + content],
#                     { type: "text/plain;charset=utf-8" }
#                 );

#                 const a = document.createElement("a");
#                 a.href = URL.createObjectURL(blob);

#                 a.download = currentFile.name.replace(/\.[^/.]+$/, "") +
#                     (type === "old" ? "_ORIGINAL.txt" : "_MODIFIED.txt");

#                 document.body.appendChild(a);
#                 a.click();
#                 document.body.removeChild(a);

#                 URL.revokeObjectURL(a.href);
#             };
#         });

#         document.addEventListener("click", () => {
#             downloadMenu.style.display = "none";
#         });

#         init();
#     </script>


# </body>

# </html>

# """

