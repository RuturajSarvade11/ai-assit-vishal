"""
src/routes/admin_route.py — W-adapter ON/OFF switch (owner/admin only).

  GET  /admin/adapter-status                          -> {global_enabled, project_overrides, updated_by, updated_at}
  POST /admin/adapter-toggle  {enabled}               -> set the GLOBAL default
  POST /admin/adapter-toggle  {project, enabled}      -> set/replace a PER-PROJECT override
  POST /admin/adapter-toggle  {project, clear:true}   -> remove a project override (falls back to global)

Effective state for a project = its override if set, else the global default (see adapter_settings).

Two adapter DOMAINS exist ("error" = the original W on error vectors, "artifact" = W_artifact on
artifact vectors). Both endpoints accept an optional domain — "domain" body field on the toggle,
?domain= on the status — defaulting to "error", so existing dashboard calls are unchanged. The
no-args status response additionally carries the artifact settings under "artifact".
"""
import logging

from flask import Blueprint, request, jsonify, g

from src.routes.auth_route import require_auth, require_role
from src.services import adapter_settings
from src.services import adapter_trainer
from src.auth import users as auth_users

logger = logging.getLogger(__name__)
admin_bp = Blueprint("admin", __name__)


def _group_member_projects(group_name: str) -> list:
    return adapter_settings.member_projects_of(group_name)


def _view(data: dict) -> dict:
    return {"global_enabled": data["global_enabled"], "project_overrides": data["project_overrides"],
            "group_overrides": data.get("group_overrides") or {},
            "updated_by": data["updated_by"], "updated_at": data["updated_at"]}


@admin_bp.route("/admin/adapter-status", methods=["GET", "OPTIONS"])
@require_auth()
def adapter_status():
    domain = (request.args.get("domain") or "error").strip().lower()
    data = adapter_settings.get_settings(force=True, domain=domain)
    is_admin = str((g.user or {}).get("role") or "").strip().lower() in ("owner", "admin")
    project = (request.args.get("project") or "").strip().lower()
    if project:
        # Per-project effective state. Resolution order: project override >
        # group override > global. ANY signed-in user may read the effective on/off (the Home
        # toggle displays it to everyone); the configuration details (source, group, member
        # projects for the group-wide warning) are answered to admins only.
        group_display = adapter_settings._group_of(project)
        group = group_display.lower()
        overrides = data["project_overrides"]
        group_overrides = data.get("group_overrides") or {}
        if project in overrides:
            enabled, source = overrides[project], "override"
        elif group and group in group_overrides:
            enabled, source = group_overrides[group], "group"
        else:
            enabled, source = data["global_enabled"], "global"
        if not is_admin:
            return jsonify({"project": project, "enabled": bool(enabled), "domain": domain})
        return jsonify({"project": project, "enabled": bool(enabled), "source": source,
                        "group": group_display,
                        "group_projects": _group_member_projects(group_display),
                        "domain": domain})
    if not is_admin:
        return jsonify({"success": False, "data": [], "error": "forbidden", "code": "forbidden",
                        "message": "You do not have access to this action. Please contact an administrator."}), 403
    view = _view(data)
    if domain == "error":
        # Additive: the default (error) status also reports the artifact adapter, so the
        # dashboard sees both switches with one call.
        view["artifact"] = _view(adapter_settings.get_settings(force=True, domain="artifact"))
    return jsonify(view)


@admin_bp.route("/admin/adapter-toggle", methods=["POST", "OPTIONS"])
@require_role("owner", "admin")
def adapter_toggle():
    d = request.get_json(force=True, silent=True) or {}
    by = (g.user or {}).get("sub", "unknown")
    domain = (d.get("domain") or "error").strip().lower()
    project = (d.get("project") or "").strip()
    group = (d.get("group") or "").strip()
    if group:
        # Group-wise adapter configuration — one switch per project
        # group, applied to every project in it (a project override still wins).
        if d.get("clear"):
            data = adapter_settings.clear_group(group, by, domain=domain)
            logger.info("[admin] adapter group override cleared | domain=%s | group=%s | by=%s", domain, group, by)
        else:
            if "enabled" not in d:
                return jsonify({"error": "provide 'enabled' for the group, or 'clear': true"}), 400
            data = adapter_settings.set_group(group, bool(d.get("enabled")), by, domain=domain)
            logger.info("[admin] adapter group override | domain=%s | group=%s | enabled=%s | by=%s",
                        domain, group, bool(d.get("enabled")), by)
        view = _view(data)
        view["domain"] = domain
        return jsonify(view)
    if project:
        if d.get("clear"):
            data = adapter_settings.clear_project(project, by, domain=domain)
            logger.info("[admin] adapter override cleared | domain=%s | project=%s | by=%s", domain, project, by)
        else:
            if "enabled" not in d:
                return jsonify({"error": "provide 'enabled' for the project, or 'clear': true"}), 400
            data = adapter_settings.set_project(project, bool(d.get("enabled")), by, domain=domain)
            logger.info("[admin] adapter project override | domain=%s | project=%s | enabled=%s | by=%s",
                        domain, project, bool(d.get("enabled")), by)
    else:
        if "enabled" not in d:
            return jsonify({"error": "provide 'enabled' (global) or 'project' + 'enabled'"}), 400
        data = adapter_settings.set_global(bool(d.get("enabled")), by, domain=domain)
        logger.info("[admin] adapter GLOBAL default | domain=%s | enabled=%s | by=%s", domain, bool(d.get("enabled")), by)
    view = _view(data)
    view["domain"] = domain
    return jsonify(view)


@admin_bp.route("/admin/adapter-train", methods=["POST", "OPTIONS"])
@require_role("owner", "admin")
def adapter_train():
    """Train W now from the latest feedback (in-process, no script). Runs on a background thread;
    poll /admin/adapter-train-status for the result."""
    force = bool((request.get_json(force=True, silent=True) or {}).get("force"))
    started = adapter_trainer.trigger_async(force=force)
    by = (g.user or {}).get("sub", "unknown")
    logger.info("[admin] train-now requested | by=%s | started=%s | force=%s", by, started, force)
    if not started:
        return jsonify({"started": False, "error": "a training cycle is already running"}), 409
    return jsonify({"started": True, "message": "training started; poll /admin/adapter-train-status"})


@admin_bp.route("/admin/adapter-train-status", methods=["GET", "OPTIONS"])
@require_role("owner", "admin")
def adapter_train_status():
    return jsonify(adapter_trainer.status())


@admin_bp.route("/admin/users", methods=["GET", "OPTIONS"])
@require_role("owner", "admin")
def list_users():
    """Owner view: who has set their own password yet (must_change_password)."""
    return jsonify({"users": auth_users.list_users()})


@admin_bp.route("/admin/user-metrics/details", methods=["GET", "OPTIONS"])
@require_role("owner", "admin")
def user_metrics_details():
    """How one card's figure on the Extension Usage page (User Management) is distributed:
    Metric -> Group -> Project -> records, counters summed at every level, paged by group.

    ?type=        one of active-users | total-builds | failed-builds | issues-captured |
                  uploads | recommendation-requests
    ?groupName=   project group, or "All Groups"
    ?days=        window ending today (default 30)
    ?pageNumber=  ?pageSize=   paging over GROUPS (default 1 / 10)
    ?search=      project or group name contains (case-insensitive)

    Every answer has the same shape - success, message, data, pagination - so the screen never
    has to guess. The counting itself lives in extension_usage; a failure there is returned as
    the failure envelope with a 500, never as a bare exception page.
    """
    from src.services import extension_usage as _eu
    args = request.args
    try:
        payload, status = _eu.metric_details(
            metric_type=args.get("type"), group=args.get("groupName"), days=args.get("days"),
            page_number=args.get("pageNumber"), page_size=args.get("pageSize"),
            search=args.get("search"))
    except Exception:
        logger.exception("[admin] user-metrics details failed | type=%s", args.get("type"))
        return jsonify(_eu.details_failure()), 500
    return jsonify(payload), status


@admin_bp.route("/admin/users/reset-password", methods=["POST", "OPTIONS"])
@require_role("owner", "admin")
def reset_user_password():
    """Reset a user back to their default password (forgotten-password). They must change it on next
    login. (A proper self-service / email reset is planned later.)"""
    username = ((request.get_json(force=True, silent=True) or {}).get("username") or "").strip()
    if not username:
        return jsonify({"error": "username required"}), 400
    res = auth_users.reset_to_default(username)
    if not res:
        return jsonify({"error": "user not found"}), 404
    by = (g.user or {}).get("sub", "unknown")
    logger.info("[admin] password reset to default | user=%s | by=%s", res["username"], by)
    return jsonify({"username": res["username"], "default_password": res["default_password"],
                    "must_change_password": True,
                    "message": "Share this default with the user; they must change it on next login."})
