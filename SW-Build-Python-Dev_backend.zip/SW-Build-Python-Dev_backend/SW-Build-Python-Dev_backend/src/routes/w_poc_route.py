"""
W Adapter - live POC endpoints (additive blueprint; registered in route.py).

Live whenever the backend runs. Paste a real error -> it is embedded with the REAL
text-embedding-3-large, the REAL recommendation retrieval returns the same-error
candidate fixes (coupled by request_id), and each Helpful / Not-helpful click runs
the SAME contrastive W update the production adapter uses. The separate w_demo.html
UI calls these endpoints. CORS is already enabled globally on the app.

    POST /w-poc/recommend   {error_text, project_name}
    POST /w-poc/feedback    {session, solution, helpful}
    GET  /w-poc/health
"""
import json
import uuid
import logging

import numpy as np
from flask import Blueprint, request, jsonify

from src.utils.oai_client import create_embedding
from src.utils.recommended import search_similar_errors, collection

logger = logging.getLogger(__name__)
w_poc_bp = Blueprint("w_poc", __name__)

RED, ETA, STEPS, WCAP = 5, 0.05, 4, 5.0
_SESS: dict = {}


def _embed(text):
    return np.asarray(create_embedding(text or ""), dtype=np.float64)


def _solution_label(meta):
    meta = meta or {}
    desc = str(meta.get("resolution_description") or "").strip()
    if desc:
        return desc[:100]
    sol = meta.get("solution")
    if isinstance(sol, str):
        try:
            sol = json.loads(sol)
        except Exception:
            return sol[:100]
    if isinstance(sol, list) and sol and isinstance(sol[0], dict):
        f = sol[0]
        ch = " ".join(str(c) for c in (f.get("changes") or []))[:80]
        return f"{f.get('fileName', 'fix')}: {ch}".strip()
    return "historical fix"


def _candidates(error_text, project, k=4):
    res = search_similar_errors(error_text, project, top_k=10, allow_global_fallback=True)
    ids = (res.get("ids") or [[]])[0]
    metas = (res.get("metadatas") or [[]])[0]
    seen, picked = set(), []
    for i, vid in enumerate(ids):
        m = metas[i] if i < len(metas) else {}
        rid = str((m or {}).get("request_id") or (m or {}).get("vector_id") or vid)
        if rid in seen:
            continue
        seen.add(rid)
        picked.append((vid, m))
        if len(picked) >= k:
            break
    got = collection.get(ids=[v for v, _ in picked], include=["embeddings"]) if picked else {}
    emb_by_id = {gid: np.asarray(e, dtype=np.float64)
                 for gid, e in zip(got.get("ids", []), got.get("embeddings", []))}
    out = []
    for vid, m in picked:
        emb = emb_by_id.get(vid)
        if emb is None:
            continue
        out.append({"name": _solution_label(m),
                    "text": str((m or {}).get("compare_diff_link") or ""),
                    "emb": emb})
    return out


def _reducer(vecs):
    raw = np.vstack(vecs)
    mu = raw.mean(0)
    comps = np.linalg.svd(raw - mu, full_matrices=False)[2][:RED]
    if comps.shape[0] < RED:                       # few vectors -> pad to RED dims
        comps = np.vstack([comps, np.zeros((RED - comps.shape[0], comps.shape[1]))])

    def red(v):
        z = comps @ (v - mu)
        n = np.linalg.norm(z)
        return (z / n if n else z) * 2.0
    return red


def _D(W, e, s):
    a = e - s
    return float(a @ (W @ W.T) @ a)


def _state(sid, error_text=None):
    s = _SESS[sid]
    W, e = s["W"], s["e"]
    rows, best, bd = [], None, 1e9
    for c in s["cands"]:
        d = _D(W, e, c["s"])
        a = e - c["s"]
        if d < bd:
            bd, best = d, c["key"]
        rows.append({"key": c["key"], "name": c["name"], "text": c["text"],
                     "s": [round(x, 3) for x in c["s"]],
                     "a": [round(x, 3) for x in a], "D": round(d, 3)})
    out = {"session": sid, "mode": "REAL backend (text-embedding-3-large)", "dims": RED,
           "e": [round(x, 3) for x in e], "W": np.round(W, 3).tolist(),
           "M": np.round(W @ W.T, 3).tolist(), "best": best, "solutions": rows}
    if error_text is not None:
        out["error_text"] = error_text
    return out


@w_poc_bp.route("/w-poc/recommend", methods=["POST", "OPTIONS"])
def recommend():
    if request.method == "OPTIONS":
        return ("", 204)
    d = request.get_json(force=True, silent=True) or {}
    error_text = (d.get("error_text") or "").strip()
    project = (d.get("project_name") or "").strip().lower()
    if not error_text:
        return jsonify({"error": "paste an error message first"}), 400
    try:
        e_emb = _embed(error_text)
        cands = _candidates(error_text, project)
    except Exception as ex:
        logger.exception("[w-poc] recommend failed")
        return jsonify({"error": f"recommend failed: {ex}"}), 500
    if not cands:
        return jsonify({"error": "no similar errors found for this project yet"}), 200
    red = _reducer([e_emb] + [c["emb"] for c in cands])
    sid = uuid.uuid4().hex
    _SESS[sid] = {"e": red(e_emb), "W": np.eye(RED),
                  "cands": [{"key": chr(65 + i), "name": c["name"], "text": c["text"], "s": red(c["emb"])}
                            for i, c in enumerate(cands)]}
    if len(_SESS) > 200:
        _SESS.pop(next(iter(_SESS)))
    return jsonify(_state(sid, error_text))


@w_poc_bp.route("/w-poc/feedback", methods=["POST", "OPTIONS"])
def feedback():
    if request.method == "OPTIONS":
        return ("", 204)
    d = request.get_json(force=True, silent=True) or {}
    sid, key, helpful = d.get("session"), d.get("solution"), bool(d.get("helpful"))
    if sid not in _SESS:
        return jsonify({"error": "session expired - click Get recommendation again"}), 400
    s = _SESS[sid]
    e = s["e"]
    c = next((x for x in s["cands"] if x["key"] == key), None)
    if not c:
        return jsonify({"error": "unknown solution"}), 400
    before = _D(s["W"], e, c["s"])
    a = e - c["s"]
    oa = np.outer(a, a)
    for _ in range(STEPS):
        s["W"] = (np.eye(RED) - 2 * ETA * (oa if helpful else -oa)) @ s["W"]
    nrm = np.linalg.norm(s["W"], 2)
    if nrm > WCAP:
        s["W"] = s["W"] * (WCAP / nrm)
    st = _state(sid)
    st["click"] = {"key": key, "helpful": helpful, "a": [round(x, 3) for x in a],
                   "aaT": np.round(oa, 3).tolist(), "before": round(before, 3),
                   "after": round(_D(s["W"], e, c["s"]), 3)}
    return jsonify(st)


@w_poc_bp.get("/w-poc/health")
def health():
    return jsonify({"ok": True, "sessions": len(_SESS)})
