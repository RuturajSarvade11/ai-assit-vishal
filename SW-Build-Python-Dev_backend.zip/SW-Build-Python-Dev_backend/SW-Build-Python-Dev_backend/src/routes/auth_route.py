"""
src/routes/auth_route.py — dashboard auth endpoints (manual users now, SSO-ready).

  POST /auth/login         {username, password}      -> {token, user, must_change_password}
  POST /auth/set-password  {new_password}  (Bearer)  -> {token, user}     (first-login / change)
  GET  /auth/me            (Bearer)                   -> {user}

Protect any endpoint with @require_role("owner", "admin"). CORS is already global on the app.
"""
import logging
from functools import wraps

from flask import Blueprint, request, jsonify, g, redirect

from src.auth.security import (verify_password, hash_password, validate_strong_password,
                               issue_token, verify_token, password_policy)
from src.auth.users import get_user, get_user_by_email, update_password

logger = logging.getLogger(__name__)
auth_bp = Blueprint("auth", __name__)


def _claims_from_request():
    auth = request.headers.get("Authorization", "")
    if not auth.lower().startswith("bearer "):
        return None
    return verify_token(auth.split(" ", 1)[1].strip())


def _enforce_access_list(claims: dict):
    """Re-check an SSO session against the User Management list on every request.

    The token is signed and stays valid until it expires, so removing somebody from the list
    used to leave their open session working until then. Returns (claims, None) to continue -
    with the role refreshed from the store, so a demotion applies at once too - or
    (claims, response) to refuse. Password accounts are not affected."""
    if str(claims.get("info") or "").strip().upper() != "SSO":
        return claims, None
    try:
        from src.auth import sso_roles
        access = sso_roles.current_access(str(claims.get("sub") or ""))
    except Exception:
        logger.exception("access re-check failed - session kept")
        return claims, None
    if not access["allowed"]:
        logger.info("[auth] session refused - %s", access["reason"])
        return claims, (jsonify({"error": "access not granted", "code": "access_revoked",
                                 "message": "Your access has been removed. Please contact your "
                                            "administrator."}), 401)
    if access["role"] != claims.get("role"):
        claims = {**claims, "role": access["role"]}
    return claims, None


def require_auth(allow_must_change: bool = False):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **k):
            if request.method == "OPTIONS":
                return ("", 204)
            claims = _claims_from_request()
            if not claims:
                # Distinguish an EXPIRED/INVALID session (a Bearer token WAS sent but was rejected by
                # verify_token) from a never-authenticated request (no token at all). The UI uses the
                # `code` to show "session expired - please sign in again" vs a plain login redirect.
                had_token = request.headers.get("Authorization", "").lower().startswith("bearer ")
                if had_token:
                    return jsonify({"error": "session expired", "code": "session_expired"}), 401
                return jsonify({"error": "not authenticated", "code": "not_authenticated"}), 401
            if claims.get("must_change") and not allow_must_change:
                return jsonify({"error": "password change required", "must_change_password": True}), 403
            claims, denied = _enforce_access_list(claims)
            if denied:
                return denied
            g.user = claims
            return fn(*a, **k)
        return wrapper
    return deco


def require_role(*roles):
    """For admin-only endpoints (e.g. the adapter toggle). Rejects must_change tokens.

    The role comes from the SIGNED JWT issued at login — never from anything the client stores —
    so flipping the role in session/local storage cannot grant access here. The 403 body carries
    code + message so the UI can render its "no access" screen directly."""
    def deco(fn):
        @wraps(fn)
        @require_auth(allow_must_change=False)
        def wrapper(*a, **k):
            if g.user.get("role") not in roles:
                # "data": [] per the dashboard contract - non-admin roles must receive 403
                # with an empty payload, never partial data.
                return jsonify({
                    "success": False,
                    "data": [],
                    "error": "forbidden",
                    "code": "forbidden",
                    "message": "You do not have access to this action. Please contact an administrator.",
                }), 403
            return fn(*a, **k)
        return wrapper
    return deco


def require_role_if_token(*roles):
    """Role gate for admin-page READS that the VS Code extension ALSO consumes without a login
    (artifact configuration, tracking patterns, prediction config).

    - No Authorization header (the extension): request passes through unchanged - guarding these
      outright would break artifact collection / tracking / prediction config on every installed
      extension, which has no dashboard session.
    - Bearer token present (a dashboard user): the role is enforced exactly like require_role -
      a non-admin account gets 403 + data: [], an invalid/expired token gets 401.

    Follow-up (tracked): once extensions authenticate with an API key, these endpoints move to a
    full require_role."""
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **k):
            if request.method == "OPTIONS":
                return ("", 204)
            authz = request.headers.get("Authorization", "")
            if not authz.lower().startswith("bearer "):
                return fn(*a, **k)
            claims = verify_token(authz.split(" ", 1)[1].strip())
            if not claims:
                return jsonify({"error": "session expired", "code": "session_expired"}), 401
            if claims.get("must_change"):
                return jsonify({"error": "password change required", "must_change_password": True}), 403
            claims, denied = _enforce_access_list(claims)
            if denied:
                return denied
            if claims.get("role") not in roles:
                return jsonify({
                    "success": False,
                    "data": [],
                    "error": "forbidden",
                    "code": "forbidden",
                    "message": "You do not have access to this action. Please contact an administrator.",
                }), 403
            g.user = claims
            return fn(*a, **k)
        return wrapper
    return deco


def _user_view(claims):
    return {"username": claims.get("sub"), "email": claims.get("sub"), "name": claims.get("name"),
            "info": claims.get("info", ""), "role": claims.get("role"),
            "must_change_password": bool(claims.get("must_change"))}


@auth_bp.route("/auth/login", methods=["POST", "OPTIONS"])
def login():
    if request.method == "OPTIONS":
        return ("", 204)
    d = request.get_json(force=True, silent=True) or {}
    email_in = (d.get("email") or d.get("username") or "").strip().lower()
    password = d.get("password") or ""
    user = get_user_by_email(email_in)   # match on the EMAIL field (the login identity)
    if not user or not verify_password(password, user.get("password_hash", "")):
        return jsonify({"error": "invalid email or password"}), 401
    must_change = bool(user.get("must_change_password"))
    sub = user.get("username") or email_in           # DynamoDB key — used by /auth/me & set-password
    email = user.get("email", sub)
    token = issue_token(sub=sub, name=user.get("name", ""), info=user.get("info", ""),
                        role=user.get("role", "user"), must_change=must_change)
    return jsonify({"token": token, "must_change_password": must_change,
                    "user": {"username": sub, "email": email, "name": user.get("name", ""),
                             "info": user.get("info", ""), "role": user.get("role", "user")}})


@auth_bp.route("/auth/microsoft/config", methods=["GET", "OPTIONS"])
def microsoft_config():
    """Public SSO configuration for the dashboard (client id / tenant / authority — never
    the secret). enabled=false until the server has the registration values in its env."""
    if request.method == "OPTIONS":
        return ("", 204)
    from src.auth import microsoft_sso
    return jsonify(microsoft_sso.public_config())


@auth_bp.route("/auth/microsoft/login", methods=["GET"])
def microsoft_login():
    """Entry point of the Microsoft sign-in: 302 to Microsoft's own sign-in page. The
    redirect_uri must be one of the ALLOWED (registered) callback URLs — exact match."""
    from src.auth import microsoft_sso
    if not microsoft_sso.sso_enabled():
        return jsonify({"error": "Microsoft sign-in is not configured on this server"}), 503
    redirect_uri = (request.args.get("redirect_uri") or "").strip()
    if redirect_uri not in microsoft_sso.allowed_redirects():
        return jsonify({"error": "redirect_uri is not in the allowed list"}), 400
    state = (request.args.get("state") or "").strip()
    return redirect(microsoft_sso.build_authorize_url(redirect_uri, state), code=302)


@auth_bp.route("/auth/microsoft/token", methods=["POST", "OPTIONS"])
def microsoft_token():
    """The dashboard posts the one-time code from Microsoft's redirect; the SERVER exchanges
    it with the client secret, maps the role, and answers with the SAME body as /auth/login
    — token + user — so the dashboard session handling is identical for both login kinds.
    First Microsoft sign-in of a user creates their dashboard record automatically."""
    if request.method == "OPTIONS":
        return ("", 204)
    from src.auth import microsoft_sso
    from src.auth.users import put_user
    if not microsoft_sso.sso_enabled():
        return jsonify({"error": "Microsoft sign-in is not configured on this server"}), 503

    d = request.get_json(force=True, silent=True) or {}
    code = (d.get("code") or "").strip()
    redirect_uri = (d.get("redirect_uri") or "").strip()
    if not code:
        return jsonify({"error": "code is required"}), 400
    if redirect_uri not in microsoft_sso.allowed_redirects():
        return jsonify({"error": "redirect_uri is not in the allowed list"}), 400

    try:
        identity = microsoft_sso.exchange_code(code, redirect_uri)
    except ValueError as err:
        return jsonify({"error": str(err)}), 401
    except Exception:
        logger.exception("Microsoft sign-in failed unexpectedly")
        return jsonify({"error": "Microsoft sign-in failed — please try again"}), 502

    email = identity["email"]
    user = get_user_by_email(email)
    role = (user or {}).get("role") or microsoft_sso.role_for(identity.get("groups") or [])
    name = identity.get("name") or (user or {}).get("name") or email
    if not user:
        # First SSO sign-in: create the dashboard record. No usable password — identity
        # lives with Microsoft; an unguessable random hash blocks the password login path.
        import secrets as _secrets
        put_user(email, name, "Microsoft SSO", role, hash_password(_secrets.token_urlsafe(32)),
                 must_change=False, email=email)
        logger.info("SSO first sign-in — user created | email=%s role=%s", email, role)
    sub = (user or {}).get("username") or email

    token = issue_token(sub=sub, name=name, info=(user or {}).get("info", "Microsoft SSO"),
                        role=role, must_change=False)
    return jsonify({"token": token, "must_change_password": False,
                    "user": {"username": sub, "email": email, "name": name,
                             "info": (user or {}).get("info", "Microsoft SSO"), "role": role}})


@auth_bp.route("/auth/set-password", methods=["POST", "OPTIONS"])
@require_auth(allow_must_change=True)
def set_password():
    d = request.get_json(force=True, silent=True) or {}
    new_pw = d.get("new_password") or ""
    ok, msg = validate_strong_password(new_pw)
    if not ok:
        return jsonify({"error": msg}), 400
    username = g.user.get("sub")
    user = get_user(username)
    if not user:
        return jsonify({"error": "user not found"}), 404
    update_password(username, hash_password(new_pw))
    token = issue_token(sub=username, name=user.get("name", ""), info=user.get("info", ""),
                        role=user.get("role", "user"), must_change=False)
    return jsonify({"token": token, "user": {"username": username, "email": user.get("email", username),
                                             "name": user.get("name", ""),
                                             "info": user.get("info", ""), "role": user.get("role", "user")}})


@auth_bp.route("/auth/me", methods=["GET", "OPTIONS"])
@require_auth()
def me():
    return jsonify({"user": _user_view(g.user)})


@auth_bp.route("/auth/password-policy", methods=["GET"])
def password_policy_endpoint():
    """Public — the UI renders these rule labels on the set-password screen."""
    return jsonify(password_policy())


@auth_bp.route("/auth/config", methods=["GET"])
def auth_config():
    """The UI calls this to decide what to show: the 'Sign in with Microsoft' button (when enabled)
    or the username/password form."""
    from src.auth import ms_oidc
    enabled = ms_oidc.is_enabled()
    return jsonify({
        "microsoft_login_enabled": enabled,
        "microsoft_login_url": "/auth/login/microsoft" if enabled else None,
        "password_login_enabled": True,
    })


@auth_bp.route("/auth/login/microsoft", methods=["GET"])
def ms_login():
    """Start Microsoft sign-in: redirect the browser to Microsoft (password + MFA happen there)."""
    from src.auth import ms_oidc
    if not ms_oidc.is_enabled():
        return jsonify({"error": "Microsoft login is not configured",
                        "need": ["MS_TENANT_ID", "MS_CLIENT_ID", "MS_CLIENT_SECRET", "MS_REDIRECT_URI"]}), 503
    try:
        return redirect(ms_oidc.begin_login())
    except Exception as e:
        logger.exception("ms_login failed")
        return jsonify({"error": f"could not start Microsoft login: {e}"}), 500


@auth_bp.route("/admin/user-directory/search", methods=["GET"])
@require_role("owner", "admin")
def user_directory_search():
    """Type a NAME, get the Schaeffler ID (User Management lookup) - so an admin never has
    to ask a colleague for their sg-id. Searches Microsoft Entra with the CALLING ADMIN's own
    Graph token (delegated User.ReadBasic.All), captured at their SSO sign-in. Every
    unavailable state answers enabled:false with the reason, so the UI can fall back to manual
    entry instead of erroring - the feature lights up by configuration, never breaks login."""
    from src.auth import ms_oidc
    q = str(request.args.get("q") or "").strip()
    if len(q) < 2:
        return jsonify({"enabled": True, "results": []})
    if not ms_oidc.MS_SCOPES:
        return jsonify({"enabled": False,
                        "reason": "Directory search is not configured (MS_SCOPES is empty). "
                                  "Grant Graph User.ReadBasic.All + admin consent, then set "
                                  "MS_SCOPES=User.ReadBasic.All and restart."})
    token = ms_oidc.graph_token_for(str(g.user.get("sub") or ""))
    if not token:
        return jsonify({"enabled": False,
                        "reason": "Sign in via Microsoft SSO (again) to enable directory "
                                  "search - the lookup runs with your own account."})
    # Escape single quotes per OData; startswith on the display name and the principal, so
    # typing either a name or the beginning of an sg-id works.
    safe = q.replace("'", "''")
    url = ("https://graph.microsoft.com/v1.0/users"
           f"?$filter=startswith(displayName,'{safe}') or startswith(userPrincipalName,'{safe}')"
           "&$select=displayName,userPrincipalName,mail&$top=8")
    try:
        import requests as _rq
        resp = _rq.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=10)
        if resp.status_code == 403:
            return jsonify({"enabled": False,
                            "reason": "The Entra app lacks the User.ReadBasic.All permission "
                                      "(or consent) - ask the app owner to grant it."})
        if resp.status_code == 401:
            return jsonify({"enabled": False,
                            "reason": "Directory session expired - sign in via Microsoft "
                                      "SSO again."})
        resp.raise_for_status()
        out = []
        for u in (resp.json().get("value") or []):
            upn = str(u.get("userPrincipalName") or "")
            out.append({
                "name": str(u.get("displayName") or ""),
                "principal": upn,
                # The bare Schaeffler ID the Add User form wants (domain is re-added there).
                "schaeffler_id": upn.split("@")[0] if "@" in upn else upn,
            })
        return jsonify({"enabled": True, "results": out})
    except Exception as exc:
        logger.warning("user directory search failed: %s", exc)
        return jsonify({"enabled": False, "reason": "Directory search failed - enter the "
                                                    "Schaeffler ID manually."})


def _login_page_url(post_login_redirect: str, query: str) -> str:
    """The dashboard's login page with a query string in front of the hash route, the same shape
    the token redirect uses: https://host/?sso_error=not_listed#/login."""
    dest = str(post_login_redirect or "/")
    base = dest.split("#", 1)[0]
    sep = "&" if "?" in base else "?"
    return f"{base}{sep}{query}#/login"


@auth_bp.route("/auth/callback", methods=["GET"])
def ms_callback():
    """Microsoft redirects here after sign-in. We read the identity + role and mint the app session
    token, then send the user to the dashboard with the token."""
    from urllib.parse import quote
    from src.auth import ms_oidc
    if not ms_oidc.is_enabled():
        return jsonify({"error": "Microsoft login is not configured"}), 503
    claims, err = ms_oidc.complete_login(request.args)
    if err:
        return jsonify({"error": err}), 401
    username, name, _token_role, _token_roles = ms_oidc.extract_user(claims)
    if not username:
        return jsonify({"error": "Microsoft did not return a user identity",
                        "claim_keys": sorted((claims or {}).keys())}), 401
    # The Microsoft token's roles/groups are NOT used. Admin-vs-user is
    # decided by OUR user store, keyed on the (hashed) Schaeffler ID — see src/auth/sso_roles.py.
    from src.auth import sso_roles
    # The User Management list is the access list. Not on it -> back to
    # the login page with the reason, no session, no row written. See sso_roles.sign_in_decision.
    decision = sso_roles.sign_in_decision(username, name)
    role = decision["role"]
    if not decision["allowed"]:
        logger.info("[ms-login] refused name=%s reason=%s", name, decision["reason"])
        if ms_oidc.MS_LOGIN_DEBUG:
            return jsonify({"signed_in": False, "principal": username, "name": name,
                            "reason": decision["reason"]}), 403
        return redirect(_login_page_url(ms_oidc.MS_POST_LOGIN_REDIRECT, "sso_error=" + quote(decision["reason"])))
    token = issue_token(sub=username, name=name, info="SSO", role=role, must_change=False)
    logger.info("[ms-login] signed in name=%s role=%s tid=%s claim_keys=%s",
                name, role, (claims or {}).get("tid"), sorted((claims or {}).keys()))
    # Debug/test mode: show exactly who signed in + their role + claims, instead of redirecting away.
    if ms_oidc.MS_LOGIN_DEBUG:
        return jsonify({"signed_in": True, "principal": username, "name": name, "role": role,
                        "role_source": "app user store (hashed Schaeffler id)",
                        "claims": claims, "token": token})
    dest = ms_oidc.MS_POST_LOGIN_REDIRECT or "/"
    # Append the token as a query param BEFORE any hash route, so an Angular hash-routing SPA
    # (URL like https://dashboard/#/) can read it from window.location.search and store it.
    if "#" in dest:
        base, frag = dest.split("#", 1)
        sep = "&" if "?" in base else "?"
        target = f"{base}{sep}token={quote(token)}#{frag}"
    else:
        sep = "&" if "?" in dest else "?"
        target = f"{dest}{sep}token={quote(token)}"
    return redirect(target)


@auth_bp.route("/auth/sso-users", methods=["GET"])
@require_role("owner", "admin")
def sso_users_list():
    """Admin screen: every SSO user (masked IDs only — the plain Schaeffler ID is never stored)."""
    from src.auth import sso_roles
    return jsonify({"users": sso_roles.list_sso_users()})


@auth_bp.route("/auth/sso-users/role", methods=["POST"])
@require_role("owner", "admin")
def sso_users_set_role():
    """Admin screen: assign admin/user to a Schaeffler ID (works before or after first sign-in).
    Body: {"user_id": "sgXXXXXX@user.schaeffler.com", "role": "admin"|"user", "name": "optional"}"""
    from src.auth import sso_roles
    body = request.get_json(silent=True) or {}
    try:
        entry = sso_roles.set_sso_role(str(body.get("user_id") or ""),
                                       str(body.get("role") or ""),
                                       str(body.get("name") or ""),
                                       str(body.get("row_key") or ""))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"status": True, "user": entry})


@auth_bp.route("/auth/sso-users/projects", methods=["POST"])
@require_role("owner", "admin")
def sso_users_set_projects():
    """Admin screen (RBAC): assign the dashboard projects a user may see.
    Body: {"user_id": "sgXXXXXX@user.schaeffler.com", "projects": ["proj1", ...], "name": "optional"}
    An empty list clears the assignment (user falls back to the default visibility)."""
    from src.auth import sso_roles
    body = request.get_json(silent=True) or {}
    try:
        entry = sso_roles.set_sso_projects(str(body.get("user_id") or ""),
                                           body.get("projects"),
                                           str(body.get("name") or ""),
                                           str(body.get("row_key") or ""))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"status": True, "user": entry})


@auth_bp.route("/auth/sso-users/groups", methods=["POST"])
@require_role("owner", "admin")
def sso_users_set_groups():
    """Admin screen: assign the project GROUPS a user may see.
    Body: {"user_id": "sgXXXXXX@user.schaeffler.com", "groups": ["HIP26", ...], "name": "optional"}
    An empty list clears the assignment. Membership is resolved on every read, so a project
    added to the group later is covered without editing the user."""
    from src.auth import sso_roles
    body = request.get_json(silent=True) or {}
    try:
        entry = sso_roles.set_sso_groups(str(body.get("user_id") or ""),
                                         body.get("groups"),
                                         str(body.get("name") or ""),
                                         str(body.get("row_key") or ""))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"status": True, "user": entry})


@auth_bp.route("/auth/sso-users/delete", methods=["POST"])
@require_role("owner", "admin")
def sso_users_delete():
    """Admin screen: remove a user row by row_key. Removing is a reset-to-default, not a ban —
    the person can sign in again and starts fresh with the default role."""
    from src.auth import sso_roles
    body = request.get_json(silent=True) or {}
    try:
        removed = sso_roles.delete_sso_user(str(body.get("row_key") or ""))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"status": True, "removed": removed})


@auth_bp.route("/auth/my-projects", methods=["GET"])
@require_auth()
def my_projects():
    """The signed-in user's project visibility — the dashboard filters its project list with this.
    Admins: all_projects=true. Users with an assignment: only those projects. Users nobody
    assigned yet: everything, unless RBAC_DEFAULT_DENY=1 (request-based access switch)."""
    from src.auth import sso_roles
    res = sso_roles.projects_for_sso_user(g.user.get("sub"), g.user.get("role"))
    return jsonify({"role": g.user.get("role"), "all_projects": res["all"],
                    "projects": res["projects"], "groups": res.get("groups") or []})


@auth_bp.route("/auth/whoami", methods=["GET"])
def whoami():
    """DIAGNOSTIC: shows whether the upstream auth layer (Azure App Service Authentication / a reverse
    proxy / API gateway) already injects the signed-in user — i.e. whether we can log a user in
    DIRECTLY with no username/password.

    Deploy the backend behind Schaeffler's authentication, open this URL in a browser that is already
    signed in to Schaeffler/Microsoft, and read 'direct_login_possible':
      true  -> the identity (and usually roles/groups) arrives in a header -> we trust it, NO login form.
      false -> nothing is in front injecting identity yet -> SSO/principal not wired in this environment.
    """
    import base64
    import json

    def _b64url(s):
        return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

    id_headers = ["X-MS-CLIENT-PRINCIPAL-ID", "X-MS-CLIENT-PRINCIPAL-NAME", "X-MS-CLIENT-PRINCIPAL-IDP",
                  "X-MS-CLIENT-PRINCIPAL", "X-Authenticated-User", "X-User-Id", "X-Actor-Id",
                  "X-Forwarded-User", "X-Forwarded-Email", "X-Forwarded-Groups", "X-Forwarded-Preferred-Username",
                  "Remote-User", "Remote-Groups",
                  # AWS ALB OIDC authentication (authenticate-oidc) injects these once enabled:
                  "X-Amzn-Oidc-Identity", "X-Amzn-Oidc-Data", "X-Amzn-Oidc-Accesstoken"]
    secret_h = ("x-ms-client-principal", "x-amzn-oidc-data", "x-amzn-oidc-accesstoken")
    seen = {h: ("<token present>" if h.lower() in secret_h else request.headers.get(h))
            for h in id_headers if request.headers.get(h)}

    # Azure EasyAuth forwards a base64 JSON claims blob (identity + roles/groups) in X-MS-CLIENT-PRINCIPAL
    claims = None
    blob = request.headers.get("X-MS-CLIENT-PRINCIPAL")
    if blob:
        try:
            claims = json.loads(base64.b64decode(blob).decode("utf-8"))
        except Exception:
            claims = "present but could not decode"

    # AWS ALB OIDC: x-amzn-oidc-data is a JWT (header.payload.signature) holding the user claims
    alb_claims = None
    alb = request.headers.get("X-Amzn-Oidc-Data")
    if alb and alb.count(".") >= 2:
        try:
            alb_claims = json.loads(_b64url(alb.split(".")[1]).decode("utf-8"))
        except Exception:
            alb_claims = "present but could not decode"

    principal = (request.headers.get("X-Amzn-Oidc-Identity")
                 or (isinstance(alb_claims, dict) and (alb_claims.get("email") or alb_claims.get("preferred_username")
                                                       or alb_claims.get("upn") or alb_claims.get("sub")))
                 or request.headers.get("X-MS-CLIENT-PRINCIPAL-NAME")
                 or request.headers.get("X-MS-CLIENT-PRINCIPAL-ID")
                 or request.headers.get("X-Authenticated-User")
                 or request.headers.get("X-Forwarded-User")
                 or request.headers.get("X-User-Id"))
    redacted = {k: ("<redacted>" if k.lower() in ("authorization", "cookie", "proxy-authorization") + secret_h else v)
                for k, v in request.headers.items()}
    return jsonify({
        "direct_login_possible": bool(principal),
        "principal": principal,
        "identity_headers_seen": seen,
        "decoded_ms_client_principal": claims,       # Azure App Service Auth path
        "decoded_alb_oidc_claims": alb_claims,       # AWS ALB authenticate-oidc path (identity + groups/roles)
        "all_request_headers": redacted,
        "note": "If direct_login_possible is true, the upstream auth injected the user -> we log in with "
                "NO username/password (roles come from the decoded claims / a groups header). If false: "
                "X-Forwarded-* / X-Amzn-Trace-Id means an AWS ALB is in front but ALB OIDC auth is NOT "
                "enabled. Enabling ALB authenticate-oidc against Microsoft Entra ID injects "
                "X-Amzn-Oidc-Identity + X-Amzn-Oidc-Data and this flips to true.",
    })
