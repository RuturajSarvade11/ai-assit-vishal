"""
Feedback adapter (the learned step "W") for the recommendation engine.

W is a single linear map applied on top of the FROZEN base embeddings (z = x @ W).
It is trained from confirmed error -> fix associations (and, later, explicit
Helpful / Not-helpful feedback) so the semantic search FINDS the fix proven to
work for a kind of error - and generalises to errors it has never seen. It is NOT
a re-ranker: it changes WHAT the search retrieves, in a learned space.

Design guarantees:
  * the base 3072-number embeddings are never modified or re-embedded;
  * W is small, versioned and reversible (one .npy + .json sidecar);
  * numpy only (no torch / sklearn);
  * OFF by default - while config.FEEDBACK_ADAPTER_ENABLED is false or no valid
    adapter file exists, transform() is a safe no-op and callers keep today's
    behaviour exactly.

This module owns the math + I/O + (no-op-safe) query-time transform. Building the
training dataset from the real stores lives in train_feedback_adapter.py.
"""
import json
import logging
import os
import time

import numpy as np

from src.configurations import config

logger = logging.getLogger("app.feedback_adapter")

_EPS = 1e-9
# One adapter per embedding DOMAIN ("error" = the original W, "artifact" = W_artifact for the
# artifact-evidence search). Same math, separate files, separate runtime toggles. All public
# functions default to "error" so existing callers keep today's behaviour unchanged.
_DOMAIN_PATHS = {
    "error": lambda: config.FEEDBACK_ADAPTER_PATH,
    "artifact": lambda: config.FEEDBACK_ADAPTER_ARTIFACT_PATH,
}
# cached active adapter per domain (reloaded when the file changes on disk)
_active = {}


def _domain_path(domain: str) -> str:
    getter = _DOMAIN_PATHS.get(str(domain or "error"))
    return getter() if getter else config.FEEDBACK_ADAPTER_PATH


# ----------------------------------------------------------------------------
# math
# ----------------------------------------------------------------------------
def l2norm(X, eps=_EPS):
    X = np.asarray(X, dtype=np.float64)
    if X.ndim == 1:
        return X / max(float(np.linalg.norm(X)), eps)
    n = np.linalg.norm(X, axis=1, keepdims=True)
    return X / np.maximum(n, eps)


# Largest gradient step allowed per epoch - see the note in train_adapter.
_MAX_GRAD_NORM = 1.0


def _sample_pairs(labels, rng, max_pos=6000, neg_ratio=2):
    by = {}
    for i, y in enumerate(labels):
        by.setdefault(y, []).append(i)
    pos = []
    for idxs in by.values():
        if len(idxs) < 2:
            continue
        idxs = np.array(idxs)
        for a in range(len(idxs)):
            for b in range(a + 1, len(idxs)):
                pos.append((idxs[a], idxs[b]))
    rng.shuffle(pos)
    pos = pos[:max_pos]
    n = len(labels)
    neg = []
    for _ in range(len(pos) * neg_ratio):
        i, j = int(rng.integers(n)), int(rng.integers(n))
        if labels[i] != labels[j]:
            neg.append((i, j))
    return np.array(pos), np.array(neg)


def train_adapter(X, labels, dim_out=None, epochs=None, lr=None, margin=None,
                  batch=None, seed=0, verbose=False,
                  vote_pos=None, vote_neg=None, vote_weight=None):
    """Contrastive linear adapter: same-fix close, different-fix apart.
    W is initialised to identity when square, so the untrained state equals the
    baseline and training can only re-shape (never lose) the space.

    vote_pos / vote_neg are index pairs derived from developer feedback - a thumbs up says the
    error belongs with the fix that was recommended, a thumbs down says it does not. They enter
    the same contrastive objective as the proven-fix pairs but at vote_weight, which is lower on
    purpose: a fix that made the build pass is stronger evidence than a click. Empty or weight 0
    reproduces the previous behaviour exactly."""
    epochs = config.FEEDBACK_ADAPTER_EPOCHS if epochs is None else epochs
    lr = config.FEEDBACK_ADAPTER_LR if lr is None else lr
    margin = config.FEEDBACK_ADAPTER_MARGIN if margin is None else margin
    batch = config.FEEDBACK_ADAPTER_BATCH if batch is None else batch

    rng = np.random.default_rng(seed)
    X = l2norm(X)
    N, D = X.shape
    dim_out = D if not dim_out else int(dim_out)
    W = np.eye(D) if dim_out == D else rng.normal(0, 1.0 / np.sqrt(D), size=(D, dim_out))

    pos, neg = _sample_pairs(labels, rng)
    vw = float(config.FEEDBACK_ADAPTER_VOTE_WEIGHT if vote_weight is None else vote_weight)
    vpos = np.asarray(vote_pos, dtype=int).reshape(-1, 2) if vote_pos is not None and len(vote_pos) else np.empty((0, 2), int)
    vneg = np.asarray(vote_neg, dtype=int).reshape(-1, 2) if vote_neg is not None and len(vote_neg) else np.empty((0, 2), int)
    if vw <= 0:
        vpos = vneg = np.empty((0, 2), int)
    if len(pos) == 0 and len(vpos) == 0:
        logger.warning("feedback_adapter: no positive pairs (no shared-fix errors, no upvotes) - returning identity-like W")
        return W.astype(np.float32)
    if len(vpos) or len(vneg):
        logger.info("feedback_adapter: %d vote pair(s) at weight %.2f (%d up, %d down)",
                    len(vpos) + len(vneg), vw, len(vpos), len(vneg))
    m2 = float(margin) * float(margin)
    for ep in range(int(epochs)):
        pi = pos[rng.integers(len(pos), size=min(batch, len(pos)))] if len(pos) else np.empty((0, 2), int)
        ni = neg[rng.integers(len(neg), size=min(batch, len(neg)))] if len(neg) else np.empty((0, 2), int)
        # Votes are few next to the proven-fix corpus, so they are used in FULL every round
        # rather than sampled - sampling a handful of pairs out of a batch of hundreds would
        # mean most rounds never saw one at all.
        blocks, weights = [], []
        if len(pi):
            blocks.append(X[pi[:, 0]] - X[pi[:, 1]]); weights.append(("pos", len(pi), 1.0))
        if len(ni):
            blocks.append(X[ni[:, 0]] - X[ni[:, 1]]); weights.append(("neg", len(ni), 1.0))
        if len(vpos):
            blocks.append(X[vpos[:, 0]] - X[vpos[:, 1]]); weights.append(("pos", len(vpos), vw))
        if len(vneg):
            blocks.append(X[vneg[:, 0]] - X[vneg[:, 1]]); weights.append(("neg", len(vneg), vw))
        A = np.vstack(blocks)
        Z = A @ W
        d2 = np.sum(Z * Z, axis=1)
        w = np.empty(len(A))
        at = 0
        for kind, count, weight in weights:
            if kind == "pos":
                w[at:at + count] = weight
            else:
                # A negative pair pushes only while it is still inside the margin; once far
                # enough apart it contributes nothing, which is what stops the space being
                # torn open by a handful of downvotes.
                w[at:at + count] = -weight * (d2[at:at + count] < m2).astype(np.float64)
            at += count
        grad = 2.0 * A.T @ (w[:, None] * Z) / len(A)
        # Bound the step. Plain gradient descent is only stable while the learning rate times
        # the curvature stays under 2, and with FEW pairs it does not: a single pair at lr 0.5
        # sits exactly on that boundary, so the update flips sign every epoch and an even number
        # of epochs lands back on the identity - training that reports success and has learned
        # nothing. Averaged over hundreds of proven-fix pairs the gradient is small and this
        # bound almost never binds, so the established path is unchanged; it exists for the
        # vote-driven case, where the pairs are few by nature.
        _gn = float(np.linalg.norm(grad))
        if _gn > _MAX_GRAD_NORM:
            grad = grad * (_MAX_GRAD_NORM / _gn)
        W -= lr * grad
        if verbose:
            E = int(epochs)
            if ep == 0 or (ep + 1) % max(1, E // 10) == 0:
                npos = len(pi)
                pos_d2 = float(d2[:npos].mean())
                neg_d2 = float(d2[npos:].mean()) if len(ni) else float("nan")
                print(f"  [adapter] epoch {ep+1}/{E}  pos_d2={pos_d2:.3f}  neg_d2={neg_d2:.3f}", flush=True)
    return W.astype(np.float32)


def retrieve(Xtr, Xte, W=None, k=1):
    Ztr = l2norm(Xtr @ W) if W is not None else l2norm(Xtr)
    Zte = l2norm(Xte @ W) if W is not None else l2norm(Xte)
    sims = Zte @ Ztr.T
    return np.argsort(-sims, axis=1)[:, :k]


def topk_accuracy(Xtr, ytr, Xte, yte, W=None, ks=(1, 3)):
    ytr, yte = np.asarray(ytr), np.asarray(yte)
    Ztr = l2norm(Xtr @ W) if W is not None else l2norm(Xtr)
    Zte = l2norm(Xte @ W) if W is not None else l2norm(Xte)
    order = np.argsort(-(Zte @ Ztr.T), axis=1)
    out = {}
    for k in ks:
        hit = sum(1 for r in range(len(Zte)) if yte[r] in ytr[order[r, :k]])
        out[k] = hit / max(len(Zte), 1)
    return out


def evaluate_and_train(X, labels, dim_out=None, test_frac=None, seed=2, verbose=False):
    """Held-out split (a held-out fix must also appear in train), then baseline vs
    trained retrieval. Returns metrics + the trained W (trained on the train split)."""
    test_frac = config.FEEDBACK_ADAPTER_TEST_FRAC if test_frac is None else test_frac
    labels = np.asarray(labels)
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(labels))
    cut = int(len(labels) * (1 - test_frac))
    tr, te = idx[:cut], idx[cut:]
    seen = set(labels[tr])
    te = np.array([i for i in te if labels[i] in seen])
    if len(te) == 0 or len(tr) == 0:
        return {"ok": False, "reason": "not enough data for a held-out split"}, None

    Xtr, ytr, Xte, yte = X[tr], labels[tr], X[te], labels[te]
    base = topk_accuracy(Xtr, ytr, Xte, yte, W=None)
    W = train_adapter(Xtr, ytr, dim_out=dim_out, seed=0, verbose=verbose)
    learned = topk_accuracy(Xtr, ytr, Xte, yte, W=W)
    return {
        "ok": True,
        "n_train": int(len(tr)),
        "n_heldout": int(len(te)),
        "n_fixes": int(len(set(labels.tolist()))),
        "baseline": base,
        "learned": learned,
        "gain_top1_pp": round((learned[1] - base[1]) * 100, 2),
        "gain_top3_pp": round((learned[3] - base[3]) * 100, 2),
        "input_dim": int(X.shape[1]),
        "output_dim": int(W.shape[1]),
    }, W


# ----------------------------------------------------------------------------
# I/O
# ----------------------------------------------------------------------------
def save_adapter(W, meta, path=None):
    path = path or config.FEEDBACK_ADAPTER_PATH
    if not path.endswith(".npy"):
        path = path + ".npy"
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    np.save(path, np.asarray(W, dtype=np.float32))
    meta = dict(meta or {})
    meta.setdefault("saved_at", time.strftime("%Y-%m-%dT%H:%M:%S"))
    meta.setdefault("base_model", getattr(config, "EMBEDDING_MODEL", None))
    meta["shape"] = list(np.asarray(W).shape)
    with open(_meta_path(path), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)
    logger.info("feedback_adapter saved | path=%s | shape=%s", path, meta["shape"])
    return path


def _meta_path(path):
    base = path[:-4] if path.endswith(".npy") else path
    return base + ".json"


def load_adapter(path=None):
    """Return (W, meta) or (None, None). np.save appends .npy, so accept both."""
    path = path or config.FEEDBACK_ADAPTER_PATH
    candidates = [path] if os.path.exists(path) else []
    if path.endswith(".npy") and not candidates and os.path.exists(path):
        candidates = [path]
    if not candidates and os.path.exists(path + ".npy"):
        path = path + ".npy"
        candidates = [path]
    if not candidates:
        return None, None
    try:
        W = np.load(path)
        meta = {}
        mp = _meta_path(path)
        if os.path.exists(mp):
            with open(mp, encoding="utf-8") as f:
                meta = json.load(f)
        return W.astype(np.float64), meta
    except Exception as exc:
        logger.warning("feedback_adapter load failed | path=%s | err=%s", path, exc)
        return None, None


# ----------------------------------------------------------------------------
# query-time application (safe no-op unless enabled + a valid adapter is present)
# ----------------------------------------------------------------------------
def is_active(domain: str = "error"):
    # "Active" now means only: a trained W exists and loads. Whether it is APPLIED is the runtime
    # ON/OFF decision made at the recommendation gate (adapter_settings.adapter_enabled_for), not the
    # env flag — so the dashboard switch is the real control.
    return _get_W(domain) is not None


def _get_W(domain: str = "error"):
    """Cached load of the adapter W for a domain — loads whenever the .npy file exists (reloads on
    mtime change). The env flag no longer hard-gates this; application is decided by the runtime
    toggle upstream."""
    path = _domain_path(domain)
    real = path if os.path.exists(path) else (path + ".npy" if os.path.exists(path + ".npy") else None)
    if real is None:
        return None
    mtime = os.path.getmtime(real)
    cached = _active.get(domain)
    if cached is None or cached.get("W") is None or cached.get("path") != real or cached.get("mtime") != mtime:
        W, meta = load_adapter(real)
        _active[domain] = {"path": real, "mtime": mtime, "W": W, "meta": meta}
        if W is not None:
            logger.info("feedback_adapter ACTIVE | domain=%s | path=%s | shape=%s", domain, real, getattr(W, "shape", None))
    return _active[domain]["W"]


def transform(vectors, domain: str = "error"):
    """Apply the active adapter of a domain to one vector (D,) or a batch (N, D).
    Safe no-op (returns input unchanged) when disabled, missing, or dim-mismatched."""
    W = _get_W(domain)
    if W is None:
        return vectors
    arr = np.asarray(vectors, dtype=np.float64)
    in_dim = arr.shape[-1]
    if in_dim != W.shape[0]:
        logger.warning("feedback_adapter dim mismatch (domain=%s, in=%s, W=%s) - skipping", domain, in_dim, W.shape)
        return vectors
    z = arr @ W
    return z.tolist() if isinstance(vectors, list) else z
