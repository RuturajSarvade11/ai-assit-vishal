"""
src/utils/recommendation_trace.py — the decision chain behind every recommendation.

Every request made by the user must be traceable: what the error at the user end was, what the
system recommended, and HOW it recommended it, all stored where it can be looked up afterwards.
This module stores exactly that, per recommendation
request:

  - a trace id (recommendation requests finally have an identity of their own)
  - the query as the system saw it (error text truncated, signature hashes, task, changed files)
  - every candidate considered with its REAL score components (match/context/final, match type,
    status against the threshold, feedback counts) and the final ranking
  - the threshold in force and the adapter on/off state at that moment
  - which candidates were actually shown

Storage (existing data table, no new table):
  - main row     PK="RECTRACE"      SK="<iso>#<trace_id>"     (recent traces listable)
  - pointer rows PK=<shown req id>  SK="TRACEREF#<iso>#<trace_id>"  (paste a request id on the
    team endpoint -> its traces)

Retention: default 45 days; when a NOT-HELPFUL vote lands on a shown request the
trace is flagged and kept ~7 months - those are the analysis / future-training material. Helpful
ones expire quietly. Every function is fail-open: tracing must never break a recommendation.
"""
import logging
import time
import uuid
from datetime import datetime, timezone

from src.utils.project_details import ai_assisted_data_table

logger = logging.getLogger(__name__)

_MAIN_PK = "RECTRACE"
# 30-day retention for normal chains; the not-helpful-flagged ones
# (analysis / future training material) keep the long window.
_DEFAULT_RETENTION_DAYS = 30
_FLAGGED_RETENTION_DAYS = 210
_MAX_TEXT = 700
_MAX_CANDIDATES = 10


def _iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _expires(days: int) -> int:
    return int(time.time()) + days * 24 * 3600


def _clip(value, limit: int = _MAX_TEXT) -> str:
    text = str(value or "")
    return text if len(text) <= limit else text[:limit] + " ...[truncated]"


def _solution_snippet(cand) -> list:
    """The exact change lines the candidate's stored solution recommends (per-file), so the
    trace shows WHAT was recommended, not just which file. Up to 4 lines, clipped."""
    out = []
    try:
        for item in (cand.get("solution") or []):
            if not isinstance(item, dict):
                continue
            fname = str(item.get("filePath") or item.get("fileName") or "").strip()
            changes = item.get("changes")
            for change in (changes if isinstance(changes, list) else []):
                text = str(change or "").strip()
                if not text:
                    continue
                out.append(_clip((fname + " :: " if fname else "") + text, 240))
                if len(out) >= 4:
                    return out
    except Exception:
        pass
    return out


def save_trace(*, project_name: str, endpoint: str, query_error: str,
               query_signature_hashes, task_path: str, changed_files,
               candidates, shown_request_ids, threshold_min_final,
               adapter_error_on, adapter_artifact_on, gate_status: str,
               query_context=None, query_artifacts=None, adapter_state=None,
               scoring_config=None, threshold_min_confidence=None) -> str:
    """Persist one decision chain. Returns the trace id ('' on failure — never raises)."""
    try:
        trace_id = uuid.uuid4().hex[:16]
        now_iso = _iso_now()
        compact_candidates = []
        for rank, cand in enumerate(list(candidates or [])[:_MAX_CANDIDATES], start=1):
            compact_candidates.append({
                "rank": rank,
                "request_id": str(cand.get("request_id") or ""),
                "match_type": str(cand.get("match_type") or ""),
                "match_status": str(cand.get("match_status") or ""),
                "match_score": str(cand.get("match_score") or 0),
                "context_score": str(cand.get("context_score") or 0),
                "final_score": str(cand.get("final_score") or 0),
                "similarity": str(cand.get("similarity")) if cand.get("similarity") is not None else "",
                # The similarity that actually earns match points: error text AND artifact
                # evidence combined. Error text alone is noise between candidates that
                # share one report error, so the combined value is what the page shows.
                "evidence_similarity": str(cand.get("evidence_similarity"))
                                       if cand.get("evidence_similarity") is not None else "",
                "distance": str(cand.get("distance")) if cand.get("distance") is not None else "",
                # The one term that is NOT inside match or context: the distinctive-overlap
                # bonus is applied last, straight onto the final score (so the context trims
                # cannot take it back). Stored so the table can show final = match + context
                # + this, instead of a Final nobody can reconcile with the columns beside it.
                "distinctive_points": str(cand.get("distinctive_points"))
                                      if cand.get("distinctive_points") is not None else "",
                "distinctive_overlap": str(cand.get("distinctive_overlap"))
                                       if cand.get("distinctive_overlap") is not None else "",
                # '' normally - the cosine is the same measure for every row, vector search or
                # task ledger. Names only an abnormal case: 'no_error_text' (nothing to compare,
                # similarity blank), 'embedding_unavailable', 'no_query_text'.
                "similarity_source": str(cand.get("similarity_source") or ""),
                # Every number must decompose - context = base(task/file/token
                # overlap) + patch(embedding match) + success(confirmed outcomes) + after-fix
                # pattern + admin task weight. Stored per candidate, shown on the trace page.
                "context_components": {k: str(v) for k, v in (cand.get("context_components") or {}).items()},
                # Named matches behind the base score - WHICH task/file/token data actually hit.
                "base_matches": {k: (v if isinstance(v, list) else str(v))
                                 for k, v in (cand.get("base_matches") or {}).items()},
                "artifact_match_similarity": str(cand.get("artifact_match_similarity"))
                                             if cand.get("artifact_match_similarity") is not None else "",
                # HOW the similarity was built, not just what it came to. One figure explains
                # nothing: "here we have no idea what is this 0.69 and where it came from"
                # (07-Oct). Carries the error and artifact figures separately, the weight that
                # joined them, the vector/rare-token split inside the artifact figure, the REAL
                # match base, and how many artifacts were compared - which answers the sharper
                # question underneath it, whether a candidate carrying twenty artifacts beats one
                # carrying two. It does not: the best single pair wins and scores are never summed.
                "similarity_components": {k: str(v) for k, v in
                                          (cand.get("similarity_components") or {}).items()},
                # WHICH stored artifact matched, with the download link so the
                # file can be opened from the trace and its content confirmed.
                "artifact_matched": {k: _clip(v, 500)
                                     for k, v in (cand.get("artifact_matched") or {}).items()},
                # HOW the adapter influenced this candidate (fusion provenance)
                # and the exact factors that produced the display order - no more assuming.
                "adapter_influence": {k: str(v) for k, v in (cand.get("adapter_influence") or {}).items()
                                      if v is not None},
                "rank_factors": {k: str(v) for k, v in (cand.get("rank_factors") or {}).items()},
                # Proof of how feedback influenced the solution. The rank this
                # candidate got, and the rank it WOULD have had if the two vote-derived terms of
                # the ordering key were neutralised - both measured on the same pool, so the
                # difference is the votes' actual effect on this request rather than a claim.
                "feedback_influence": {k: str(v) for k, v in (cand.get("feedback_influence") or {}).items()},
                "task_name": _clip(cand.get("task_name") or "", 200),
                "file_name": _clip(cand.get("file_name") or "", 200),
                "candidate_error": _clip(cand.get("error_message") or cand.get("document") or "", 300),
                "solution_lines": _solution_snippet(cand),
                "thumbs_up": int(cand.get("thumbs_up") or 0),
                "thumbs_down": int(cand.get("thumbs_down") or 0),
                # Ranking tier that sits ABOVE final score: net helpful votes developers gave
                # this solution FOR THIS SAME ERROR. Without it in the trace the display order
                # looks wrong whenever a validated solution outranks a higher-scored one.
                "validated_for_error": int(cand.get("fb_link_net") or 0),
                "task_match_weight_applied": str(cand.get("task_match_weight_applied") or 0),
                # WHY a candidate has no artifact evidence - four states
                # were indistinguishable on the trace (no artifacts stored / excluded as another
                # fix's log / compared but no match / never retrieved by the search window).
                "evidence_state": str(cand.get("evidence_state") or ""),
                "shown": str(cand.get("request_id") or "") in set(shown_request_ids or []),
            })

        item = {
            "PK": _MAIN_PK,
            "SK": f"{now_iso}#{trace_id}",
            "trace_id": trace_id,
            "created_date": now_iso,
            "project_name": str(project_name or "").strip().lower(),
            "endpoint": str(endpoint or ""),
            "query_error": _clip(query_error),
            "query_signature_hashes": [str(h) for h in (query_signature_hashes or [])][:10],
            "task_path": _clip(task_path or "", 300),
            "changed_files": [_clip(f, 200) for f in (changed_files or [])][:10],
            # WHAT the query offered for context matching (a context score of 0 must be
            # diagnosable - empty query side vs empty candidate side are different problems).
            "query_context": {
                "requested_task": _clip(str((query_context or {}).get("requested_task") or ""), 200),
                "task_paths": [_clip(x, 200) for x in ((query_context or {}).get("task_paths") or [])][:5],
                "file_names": [_clip(x, 200) for x in ((query_context or {}).get("file_names") or [])][:8],
                "tokens": [_clip(x, 80) for x in ((query_context or {}).get("tokens") or [])][:12],
            } if isinstance(query_context, dict) else {},
            # The artifact content the query carried (what the artifact matching
            # actually compared against) - shown expandable on the trace card.
            "query_artifacts": [
                {"name": _clip((a or {}).get("name"), 200), "text": _clip((a or {}).get("text"), 1500)}
                for a in (query_artifacts or []) if isinstance(a, dict)
            ][:5],
            "candidates": compact_candidates,
            "shown_request_ids": [str(r) for r in (shown_request_ids or [])],
            "threshold_min_final": str(threshold_min_final or 0),
            # The confidence (similarity) a shown candidate had to reach - minSimilarityPercent/100.
            "threshold_min_confidence": str(threshold_min_confidence if threshold_min_confidence is not None else 0),
            "adapter_error_on": bool(adapter_error_on) if adapter_error_on is not None else None,
            "adapter_artifact_on": bool(adapter_artifact_on) if adapter_artifact_on is not None else None,
            # WHY the per-candidate Adapter column is empty: switch off / no trained adapter /
            # active (then the ranks themselves explain each candidate).
            "adapter_state": {k: (str(v) if v is not None else "")
                              for k, v in (adapter_state or {}).items()},
            "gate_status": str(gate_status or ""),
            # The knobs actually live for THIS request + which config row served them.
            "scoring_config": {str(k): str(v) for k, v in (scoring_config or {}).items()},
            "not_helpful_flag": False,
            "expires_at": _expires(_DEFAULT_RETENTION_DAYS),
        }
        ai_assisted_data_table.put_item(Item=item)

        # Trace-id pointer (users copy the trace id from the webview and paste it
        # on the dashboard) - lookup by trace id resolves through this row.
        ai_assisted_data_table.put_item(Item={
            "PK": trace_id,
            "SK": f"TRACE#{now_iso}",
            "trace_id": trace_id,
            "trace_sk": item["SK"],
            "created_date": now_iso,
            "project_name": item["project_name"],
            "expires_at": item["expires_at"],
        })

        for req_id in {str(r) for r in (shown_request_ids or []) if str(r).strip()}:
            ai_assisted_data_table.put_item(Item={
                "PK": req_id,
                "SK": f"TRACEREF#{now_iso}#{trace_id}",
                "trace_id": trace_id,
                "trace_sk": item["SK"],
                "created_date": now_iso,
                "project_name": item["project_name"],
                "expires_at": item["expires_at"],
            })
        return trace_id
    except Exception:
        logger.exception("save_trace failed (recommendation flow unaffected)")
        return ""


def mark_llm_pick(trace_id: str, chosen_request_id: str, confidence: str = "",
                  promoted: bool = False, note: str = "") -> bool:
    """The LLM evidence-selection layer runs AFTER the trace snapshot and can PROMOTE its
    picked fix to Candidate 1 in what the developer sees (promote-but-keep-others). Stamp
    the pick on the stored trace so the trace page EXPLAINS the webview order instead of
    contradicting it (observed: the webview showed the right fix first, the trace table
    still showed the deterministic pre-promotion order). Fail-open like every trace write."""
    try:
        from boto3.dynamodb.conditions import Key
        tid = str(trace_id or "").strip()
        rid = str(chosen_request_id or "").strip()
        if not tid or not rid:
            return False
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(tid) & Key("SK").begins_with("TRACE#"))
        pointers = list(res.get("Items", []))
        trace_sk = str((pointers[0] if pointers else {}).get("trace_sk") or "")
        if not trace_sk:
            return False
        ai_assisted_data_table.update_item(
            Key={"PK": _MAIN_PK, "SK": trace_sk},
            UpdateExpression="SET llm_pick = :p",
            ExpressionAttributeValues={":p": {
                "request_id": rid,
                "confidence": str(confidence or ""),
                "promoted": bool(promoted),
                "note": _clip(note, 300),
            }},
        )
        return True
    except Exception:
        logger.exception("mark_llm_pick failed (trace page keeps the pre-promotion order)")
        return False


def get_traces_for_request(request_id: str) -> list:
    """Every stored decision chain in which this request was shown — newest first."""
    try:
        from boto3.dynamodb.conditions import Key
        lookup_id = str(request_id or "").strip()
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(lookup_id)
            & Key("SK").begins_with("TRACEREF#"),
            ScanIndexForward=False,
        )
        pointers = list(res.get("Items", []))
        if not pointers:
            # Not an error id - try it as a TRACE id (pointer written at save time).
            res = ai_assisted_data_table.query(
                KeyConditionExpression=Key("PK").eq(lookup_id)
                & Key("SK").begins_with("TRACE#"),
                ScanIndexForward=False,
            )
            pointers = list(res.get("Items", []))
        traces = []
        for pointer in pointers:
            main = ai_assisted_data_table.get_item(
                Key={"PK": _MAIN_PK, "SK": pointer.get("trace_sk", "")}).get("Item")
            if main:
                traces.append(main)
        return traces
    except Exception:
        logger.exception("get_traces_for_request failed")
        return []


def list_recent(limit: int = 25) -> list:
    """The newest decision chains across all requests (team debugging view)."""
    try:
        from boto3.dynamodb.conditions import Key
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(_MAIN_PK),
            ScanIndexForward=False,
            Limit=max(1, min(int(limit or 25), 200)),
        )
        return res.get("Items", [])
    except Exception:
        logger.exception("list_recent traces failed")
        return []


# Per-candidate fields the dashboard TABLE must not receive. Asked for directly (08-Oct): the
# Recommended Solution column showed a "debug.log" chip and the Similarity column a second line
# "art 0.235" - the matched artifact and its similarity. Both still belong on the trace page's
# deeper breakdown (the explain endpoint reads the stored row directly, so it keeps them) and
# they stay STORED, so nothing is lost; only the two table endpoints leave them out.
_TABLE_HIDDEN_CANDIDATE_KEYS = ("artifact_matched", "artifact_match_similarity")

# What the table says for a candidate that has nothing to recommend. These are orphan vectors:
# a stored error whose solution record no longer exists (deleted, or not carried over in the
# server move) and which neither the live-sibling lookup nor the archive backfill could rescue.
# The row showed "-" in Task and Recommended Solution, which reads as a broken row; the label
# says what it is. Chosen over hiding the rows (08-Oct): an admin should see that the index
# still carries leftovers to clean up (purge_request.py). Never shown to developers - the gate
# marks them 'none' - and they sort last.
SOLUTION_MISSING_LABEL = "stored solution missing"


def _label_missing_solution(cand: dict) -> dict:
    lines = cand.get("solution_lines")
    if isinstance(lines, list) and any(str(x or "").strip() for x in lines):
        return cand
    cand = dict(cand)
    cand["solution_missing"] = True
    cand["solution_lines"] = [SOLUTION_MISSING_LABEL]
    if not str(cand.get("task_name") or "").strip():
        cand["task_name"] = SOLUTION_MISSING_LABEL
    return cand


def for_table(traces) -> list:
    """Copies of the stored traces shaped for the dashboard table.

    Per candidate: the artifact display fields are removed, and a candidate with no stored
    solution is labelled (solution_missing = True, and the label in the Task and Recommended
    Solution columns where they were empty). Shallow where it can be: the trace dict and its
    candidate list are copied, the candidate dicts are rebuilt, everything else is shared. Rows
    that are not dicts, or carry no candidate list, pass through untouched. Never raises - a
    malformed row is returned as it is rather than hiding the whole listing."""
    out = []
    for trace in list(traces or []):
        try:
            if not isinstance(trace, dict) or not isinstance(trace.get("candidates"), list):
                out.append(trace)
                continue
            copy = dict(trace)
            copy["candidates"] = [
                _label_missing_solution(
                    {k: v for k, v in cand.items() if k not in _TABLE_HIDDEN_CANDIDATE_KEYS})
                if isinstance(cand, dict) else cand
                for cand in trace["candidates"]
            ]
            out.append(copy)
        except Exception:
            logger.exception("for_table: trace left as stored")
            out.append(trace)
    return out


def flag_not_helpful(request_id: str) -> int:
    """A NOT-HELPFUL vote arrived for this request: flag every trace that showed it and extend
    retention — these are the cases the team analyzes and the future training signal."""
    flagged = 0
    try:
        from boto3.dynamodb.conditions import Key
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(str(request_id or "").strip())
            & Key("SK").begins_with("TRACEREF#"),
        )
        extended = _expires(_FLAGGED_RETENTION_DAYS)
        for pointer in res.get("Items", []):
            for key in ({"PK": _MAIN_PK, "SK": pointer.get("trace_sk", "")},
                        {"PK": pointer["PK"], "SK": pointer["SK"]}):
                try:
                    ai_assisted_data_table.update_item(
                        Key=key,
                        UpdateExpression="SET not_helpful_flag = :flag, expires_at = :exp",
                        ExpressionAttributeValues={":flag": True, ":exp": extended},
                    )
                except Exception:
                    logger.exception("trace flag update failed | key=%s", key)
            flagged += 1
    except Exception:
        logger.exception("flag_not_helpful failed")
    return flagged
