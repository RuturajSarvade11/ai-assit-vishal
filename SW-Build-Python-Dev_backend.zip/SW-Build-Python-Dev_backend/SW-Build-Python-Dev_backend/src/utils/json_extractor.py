import json
import logging

import src.utils.log_setup  # noqa: F401

logger = logging.getLogger(__name__)


def extract_kts_errors(data):
    logger.debug("extract_kts_errors | input_item_count=%d", len(data) if data else 0)
    project_name = None
    process_file = None
    developer_id = None

    snapshot_files = []
    kts_errors = {
        "errorDetails": []
    }
    seen_messages = set()

    for item in data:
        file_name = item.get("fileName")
        language = item.get("language")
        error_count = len(item.get("errorDetails") or [])
        logger.debug(
            "extract_kts_errors | processing file | fileName=%s | language=%s | errorDetails_count=%d",
            file_name, language, error_count,
        )
        # ✅ ALWAYS store snapshots (all files)
        snapshot_files.append({
            "fileName": file_name,
            "snapshotBefore": item.get("snapshotBefore", {}).get("content"),
            "snapshotAfter": item.get("snapshotAfter", {}).get("content"),
            "path": item.get("filePath")
        })

        # ✅ Collect ALL KTS errors
        if item.get("errorDetails"):
            for err in item.get("errorDetails", []):
                msg = err.get("message")
                if msg and msg not in seen_messages:
                    seen_messages.add(msg)
                    kts_errors["errorDetails"].append({
                        "message": msg
                    })

            # set metadata only once
            if project_name is None or item.get("language") == ".kts":
                project_name = item.get("projectName")
                process_file = item.get("fileName")
                developer_id = item.get("developerId")

    logger.debug(
        "extract_kts_errors | done | project_name=%s | process_file=%s | "
        "unique_errors=%d | snapshot_files=%d",
        project_name, process_file,
        len(kts_errors["errorDetails"]), len(snapshot_files),
    )
    return kts_errors, project_name, process_file, developer_id, snapshot_files
