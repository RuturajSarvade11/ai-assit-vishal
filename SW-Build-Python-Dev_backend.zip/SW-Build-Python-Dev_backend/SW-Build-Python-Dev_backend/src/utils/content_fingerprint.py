"""Content fingerprints for duplicate detection (storage/duplicate-handling proposal).

A fingerprint is a sha256 over CLEANED content: volatile parts (timestamps, uuids,
absolute paths, durations, hex addresses) are removed first, so two captures of the
same logical content taken at different times produce the SAME fingerprint. This is
the artifact-side counterpart of the error-signature normalization in handlers.

Used by:
  - /archive-payload            per-file payload fingerprint (payload_content_fingerprint)
  - /binary-store, /task-runtime-artifacts   artifact bytes fingerprint
  - /upload-precheck            extension asks "is all of this already known?" before the popup
  - backfill_content_fingerprints.py         stamps fingerprints on pre-existing rows

Every function here is total: bad input returns a deterministic value, never raises.
"""
import hashlib
import json
import re

# Keys whose values change on every upload without changing the meaning of the content.
# Dropped before fingerprinting a payload dict. Lowercased comparison.
_VOLATILE_KEYS = {
    "uuid",
    "batchid",
    "batch_id",
    "request_id",
    "requestid",
    "created_date",
    "createddate",
    "updated_date",
    "updateddate",
    "timestamp",
    "time_stamp",
    "uploaded_at",
    "uploadedat",
    "date",
    "developer_id",
    "developerid",
    "username",
}

_TEXT_EXTENSIONS = (
    ".txt", ".log", ".json", ".xml", ".yml", ".yaml", ".properties", ".ini", ".cfg",
    ".gradle", ".kts", ".kt", ".java", ".groovy", ".py", ".c", ".cpp", ".h", ".hpp",
    ".md", ".csv", ".html", ".htm", ".bat", ".sh", ".cmd", ".mk", ".map", ".lst",
)


def clean_volatile_text(value: str) -> str:
    """Remove the parts of a text that legitimately differ between two captures of the
    same content: timestamps, dates, durations, uuids, absolute paths, hex addresses.
    Mirrors the error-signature normalization so both sides agree on what 'same' means."""
    text = (value or "").replace("\r", "")
    text = text.lower()
    text = re.sub(r"\b[0-9a-f]{8}-[0-9a-f-]{27,}\b", "<uuid>", text)
    # ISO datetime first (date+time in one token), then month-name forms, then bare parts.
    text = re.sub(
        r"\b\d{4}-\d{2}-\d{2}[t ]\d{1,2}:\d{2}:\d{2}(?:[.,]\d+)?(?:z|[+-]\d{2}:?\d{2})?",
        "<ts>",
        text,
    )
    text = re.sub(
        r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\s+\d{1,2},\s+\d{4}\s+\d{1,2}:\d{2}:\d{2}\s+(?:am|pm)\b",
        "<ts>",
        text,
    )
    text = re.sub(
        r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\s+\d{1,2},\s+\d{4}\b",
        "<date>",
        text,
    )
    text = re.sub(r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b", "<date>", text)
    text = re.sub(r"\b\d{1,2}[-/.]\d{1,2}[-/.]\d{4}\b", "<date>", text)
    text = re.sub(r"\b\d{1,2}:\d{2}:\d{2}(?:[.,]\d+)?(?:z|[+-]\d{2}:\d{2})?", "<time>", text)
    text = re.sub(r"\b(?:am|pm)\b", "", text)
    # Epoch timestamps: seconds (10 digits) and milliseconds (13 digits), 2017..2064 range.
    text = re.sub(r"\b1[5-9]\d{11}\b", "<epoch>", text)
    text = re.sub(r"\b1[5-9]\d{8}\b", "<epoch>", text)
    # Durations wrapped in brackets: "in [4] ms", "[0] ms" (GBE snapshot lines). The bare rule
    # below cannot see them because ']' separates the digits from the unit — without this
    # the SAME error hashed differently between a [4] ms and a [7] ms run, so the
    # exact-identity stage never fired on re-collected errors.
    text = re.sub(r"\[\s*\d+(?:[.,]\d+)?\s*\]\s*(?:ms|msec|millis|milliseconds|secs?|seconds|mins?|minutes|hrs?|hours|[smh])\b", "<dur>", text)
    # Durations like "in 248 ms", "took 5s", "BUILD FAILED in 1m 5s".
    text = re.sub(r"\b\d+(?:\.\d+)?\s?(?:ms|msec|millis|milliseconds|secs?|seconds|mins?|minutes|h|hrs?|hours|[smh])\b", "<dur>", text)
    text = re.sub(r"\b0x[0-9a-f]+\b", "<hex>", text)
    # Stack-trace line numbers keep the file name, drop the moving line number.
    text = re.sub(r"\b(\w+\.(?:java|kts?|scala|groovy|py|c|cpp|h|hpp)):\d+", r"\1:<line>", text)
    text = re.sub(r"[a-z]:[\\/][^\s\"']+", "<path>", text)
    text = re.sub(r"/[^\s\"']+", "<path>", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def clean_volatile_text_for_display(value: str) -> str:
    """DISPLAY-safe cleaning: remove timestamps/dates/durations from text that
    gets STORED and shown on the dashboard, while preserving line structure, case, paths and
    everything a reader needs. The aggressive clean_volatile_text (lowercased, whitespace-
    collapsed, paths tokenized) stays fingerprint-only. Fingerprints are always computed from the
    ORIGINAL capture (see prepare_artifact_for_storage), so they stay comparable with everything
    stored before this change — the aggressive cleaner neutralizes timestamps for dedup anyway.
    """
    text = str(value or "").replace("\r\n", "\n").replace("\r", "\n")
    if not text:
        return text
    out_lines = []
    for line in text.split("\n"):
        ln = line
        ln = re.sub(r"\b\d{4}-\d{2}-\d{2}[Tt ]\d{1,2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|z|[+-]\d{2}:?\d{2})?", "", ln)
        ln = re.sub(
            r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}(?:\s+\d{1,2}:\d{2}:\d{2}(?:\s*[AP]M)?)?",
            "", ln, flags=re.IGNORECASE,
        )
        ln = re.sub(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{4}\s+\d{1,2}:\d{2}:\d{2}(?:\s*[AP]M)?", "", ln, flags=re.IGNORECASE)
        ln = re.sub(r"\b\d{1,2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|z|[+-]\d{2}:\d{2})?\b", "", ln)
        ln = re.sub(r"\[\s*\]|\(\s*\)", "", ln)          # brackets emptied by the removals
        ln = re.sub(r"[ \t]{2,}", " ", ln).rstrip()      # collapse doubled spaces, keep the line
        out_lines.append(ln)
    return "\n".join(out_lines)


def _looks_like_text(data: bytes, file_name: str = "") -> bool:
    if not data:
        return True
    name = (file_name or "").strip().lower()
    if name.endswith(_TEXT_EXTENSIONS):
        return True
    if b"\x00" in data[:4096]:
        return False
    sample = data[:8192]
    try:
        decoded = sample.decode("utf-8", errors="replace")
    except Exception:
        return False
    if not decoded:
        return False
    return (decoded.count("�") / len(decoded)) < 0.05


def content_fingerprint_for_bytes(data: bytes, file_name: str = "") -> str:
    """Fingerprint for an uploaded artifact. Text-like content is cleaned first, so a
    re-capture of the same log with new timestamps maps to the same fingerprint.
    Binary content is hashed as-is."""
    if data is None:
        data = b""
    if isinstance(data, str):
        data = data.encode("utf-8", errors="replace")
    try:
        if _looks_like_text(data, file_name):
            cleaned = clean_volatile_text(data.decode("utf-8", errors="replace"))
            return hashlib.sha256(cleaned.encode("utf-8")).hexdigest()
    except Exception:
        pass
    return hashlib.sha256(data).hexdigest()


def prepare_artifact_for_storage(content: bytes, file_name: str = ""):
    """(stored_bytes, content_fingerprint) for an uploaded artifact.

    Order matters and is the whole point of this helper: the fingerprint comes from the ORIGINAL
    capture (stable against every previously stored fingerprint — the aggressive cleaner already
    neutralizes timestamps for dedup), while the STORED bytes are display-cleaned for text-like
    files (dashboards never show timestamps). Binary content is stored as-is."""
    if content is None:
        content = b""
    if isinstance(content, str):
        content = content.encode("utf-8", errors="replace")
    fingerprint = content_fingerprint_for_bytes(content, file_name)
    try:
        if content and _looks_like_text(content, file_name):
            cleaned = clean_volatile_text_for_display(content.decode("utf-8", errors="replace"))
            return cleaned.encode("utf-8"), fingerprint
    except Exception:
        pass
    return content, fingerprint


def _scrub_volatile(node):
    if isinstance(node, dict):
        return {
            key: _scrub_volatile(value)
            for key, value in node.items()
            if str(key).strip().lower() not in _VOLATILE_KEYS
        }
    if isinstance(node, list):
        return [_scrub_volatile(item) for item in node]
    return node


def payload_content_fingerprint(payload) -> str:
    """Fingerprint for one archive file payload (the per-file dict sent to /archive-payload).
    Volatile keys are dropped, the rest is canonicalized to JSON, cleaned, and hashed."""
    try:
        scrubbed = _scrub_volatile(payload if isinstance(payload, (dict, list)) else {"value": payload})
        canonical = json.dumps(scrubbed, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str)
    except Exception:
        canonical = str(payload)
    cleaned = clean_volatile_text(canonical)
    return hashlib.sha256(cleaned.encode("utf-8")).hexdigest()
