import numpy as np
import os
import zipfile
import time
import logging
from io import BytesIO
from typing import Dict, List

import src.utils.log_setup  # noqa: F401
from src.utils.oai_client import create_embedding, create_embeddings_batch, embedding_token_budget
from src.configurations import config
from src.utils import feedback_adapter

logger = logging.getLogger(__name__)

logger.debug(
    "ChromaDB init | PersistentClient path=%s", config.CHROMA_VECTOR_STORE_PATH
)
from src.azure_search.azure_collection import open_collection  # T3: Azure read / dual-write / azure-only
# AZURE_ONLY -> never open a local Chroma store (client stays None, chromadb is never even imported,
# so the package can be uninstalled); otherwise import + open it lazily as before.
if getattr(config, "AZURE_ONLY", False):
    client = None
else:
    import chromadb
    client = chromadb.PersistentClient(path=config.CHROMA_VECTOR_STORE_PATH)
collection = open_collection(
    config.CHROMA_COLLECTION_ERROR,
    lambda: client.get_or_create_collection(name=config.CHROMA_COLLECTION_ERROR))
logger.debug(
    "ChromaDB collection ready | name=%s", config.CHROMA_COLLECTION_ERROR
)

_EMPTY_QUERY_RESULT = {"ids": [[]], "metadatas": [[]], "distances": [[]], "documents": [[]]}


def _safe_query(_collection, **kwargs):
    """Run a ChromaDB query but never let a corrupted/inconsistent vector store 500 the whole
    request. ChromaDB can raise InternalError ('Error finding id') when its index references a
    record that is missing/corrupted in the store. In that case we log and return an EMPTY result
    so the recommendation degrades to 'no historical match' instead of crashing — the affected
    collection should then be rebuilt/repaired from the source data (S3/DynamoDB).
    """
    try:
        return _collection.query(**kwargs)
    except Exception as exc:
        # A dimension mismatch here is not corruption, it is a mis-built index, and it fails
        # EVERY query rather than one - worth naming so it is not read as a transient fault.
        if "vector dimensions" in str(exc) or "InvalidVectorQuery" in str(exc):
            logger.error(
                "[learned-space] the index rejected this query for a DIMENSION MISMATCH. The "
                "index was built for a different adapter width, so no learned result can ever "
                "be returned and the fusion silently falls back to the base ranking. Rebuild "
                "the learned index at the current adapter width. | %s", exc)
            return {"ids": [[]], "metadatas": [[]], "documents": [[]], "distances": [[]]}
        logger.error(
            "ChromaDB query failed — treating as no match (REBUILD this collection) | collection=%s | error=%s",
            getattr(_collection, "name", "<?>"), exc,
        )
        return {k: [list(v[0])] for k, v in _EMPTY_QUERY_RESULT.items()}


def _chunks(items: List[Dict], size: int):
    for i in range(0, len(items), size):
        yield items[i:i + size]

def error_embed_budget() -> tuple:
    """(max_chars, max_lines, max_tokens) for embedding an ERROR text - the SAME on the store and
    the query side.

    The store side has read a budget for as long as block mode existed; the query side did not,
    and embedded the reported error with the embedder's defaults, 1500 characters / 40 lines
    from the front - a stored vector held a whole failure block while the vector that searched
    for it held the first forty lines of the report. The sides have to be built the same way or
    the distance between them measures the asymmetry rather than the error.

    In block mode the budget is the MODEL'S, in tokens (embedding_token_budget), and nothing
    else cuts: no character cap and no line cap (0 = none). A 28,000-character cap looked
    generous and was over the model's token limit on every real build log, so the call was
    rejected and the retry embedded half; a 400-line cap dropped lines that fitted. Text over
    the token budget is CHUNKED before it gets here (chunk_text_by_tokens), one vector per
    chunk, so the whole message is embedded and stored. Both caps stay env-tunable for a
    deployment that wants them. (None, None, None) outside block mode means the embedder
    defaults, which is what the stored vectors were built with there."""
    block_mode = os.getenv("VECTOR_BLOCK_MODE", "0").strip().lower() in ("1", "true", "yes", "on")
    if not block_mode:
        return None, None, None
    return (max(0, int(os.getenv("EMBEDDING_ERROR_MAX_CHARS", "0"))),
            max(0, int(os.getenv("EMBEDDING_ERROR_MAX_LINES", "0"))),
            max(64, int(os.getenv("EMBEDDING_ERROR_MAX_TOKENS", str(embedding_token_budget())))))


def save_error_on_vector_db(vector_id, error_message, all_solution,project_name, batch_id):
    logger.debug(
        "ChromaDB INSERT | collection=%s | vector_id=%s | project_name=%s | batch_id=%s",
        config.CHROMA_COLLECTION_ERROR, vector_id, project_name, batch_id,
    )
    _chars, _lines, _tokens = error_embed_budget()
    embedding = create_embedding(error_message, max_chars=_chars, max_lines=_lines, max_tokens=_tokens)
    compare_diff_link = (
        f"{config.BACKEND_PUBLIC_BASE_URL}/diff_view/request/{batch_id}"
        if batch_id
        else f"{config.BACKEND_PUBLIC_BASE_URL}/diff_view/{vector_id}"
    )

    collection.add(
        ids=[vector_id],
        embeddings=[embedding],
        metadatas=[{
            "solution": all_solution,
            "batch_id": batch_id, 
            "compare_diff_link": compare_diff_link,
            "vector_id": vector_id,
            "project_name": project_name,
            "error_signature_hash": None,
        }]
    )
    logger.debug(
        "ChromaDB INSERT success | collection=%s | vector_id=%s",
        config.CHROMA_COLLECTION_ERROR, vector_id,
    )


def save_errors_on_vector_db_batch(items: List[Dict]) -> None:
    """
    Batch insert errors + embeddings into vector DB in one embedding request.
    """
    if not items:
        logger.warning("ChromaDB BATCH UPSERT skipped | collection=%s | items list is empty", config.CHROMA_COLLECTION_ERROR)
        return

    batch_size = max(1, int(os.getenv("EMBEDDING_BATCH_SIZE", "8")))
    batch_sleep_ms = max(0, int(os.getenv("EMBEDDING_BATCH_SLEEP_MS", "200")))

    # Block mode keeps a whole failure block as one vector, so the embedding +
    # stored document/metadata caps are raised for the error path only. Defaults
    # (off) preserve the existing 1500 / 1000 / 500 char behavior exactly.
    block_mode = os.getenv("VECTOR_BLOCK_MODE", "0").strip().lower() in ("1", "true", "yes", "on")
    # One budget for both sides: error_embed_budget() is what the query path reads too.
    err_embed_chars, err_embed_lines, err_embed_tokens = error_embed_budget()
    if block_mode:
        # The DOCUMENT is stored whole: it is the text the vector was built from, what the
        # trace shows and what the wording tiers compare, and a chunk already fits the model.
        # ERROR_DOC_STORE_CHARS caps it only when a deployment sets it (0 = whole).
        doc_cap = max(0, int(os.getenv("ERROR_DOC_STORE_CHARS", "0"))) or None
        meta_cap = max(500, int(os.getenv("ERROR_META_STORE_CHARS", "2000")))
    else:
        doc_cap = 1000
        meta_cap = 500

    embedding_cache: Dict[str, List[float]] = {}
    logger.debug(
        "ChromaDB BATCH UPSERT start | collection=%s | total_items=%d | batch_size=%d",
        config.CHROMA_COLLECTION_ERROR, len(items), batch_size,
    )

    for chunk in _chunks(items, batch_size):
        texts = [item["error_message"] for item in chunk]
        missing_texts = [t for t in texts if t not in embedding_cache]

        if missing_texts:
            new_embeddings = create_embeddings_batch(
                missing_texts, max_chars=err_embed_chars, max_lines=err_embed_lines,
                max_tokens=err_embed_tokens,
            )
            for text, emb in zip(missing_texts, new_embeddings):
                embedding_cache[text] = emb

        embeddings = [embedding_cache[t] for t in texts]

        collection.upsert(
            ids=[item["vector_id"] for item in chunk],
            embeddings=embeddings,
            documents=[(item["error_message"][:doc_cap] if doc_cap else item["error_message"]) for item in chunk],
            metadatas=[
                {
                    "solution": item["all_solution"],
                    "batch_id": item["batch_id"],
                    "request_id": item.get("request_id"),
                    "s3_key": item.get("s3_key"),
                    "file_name": item.get("file_name"),
                    "compare_diff_link": (
                        f"{config.BACKEND_PUBLIC_BASE_URL}/diff_view/request/{item.get('request_id') or item.get('batch_id')}"
                        if (item.get("request_id") or item.get("batch_id"))
                        else f"{config.BACKEND_PUBLIC_BASE_URL}/diff_view/{item['vector_id']}"
                    ),
                    "vector_id": item["vector_id"],
                    "project_name": item["project_name"],
                    "error_signature_hash": item.get("error_signature_hash"),
                    "error_message": item["error_message"][:meta_cap],
                    "task_path": item.get("task_path") or "",
                }
                for item in chunk
            ]
        )
        logger.debug(
            "ChromaDB BATCH UPSERT chunk done | collection=%s | chunk_size=%d",
            config.CHROMA_COLLECTION_ERROR, len(chunk),
        )
        if batch_sleep_ms > 0:
            time.sleep(batch_sleep_ms / 1000.0)

    logger.debug(
        "ChromaDB BATCH UPSERT complete | collection=%s | total_items=%d",
        config.CHROMA_COLLECTION_ERROR, len(items),
    )



def _scope_filter(project_name, task_path=None):
    """The project/group filter for a search level.

    Under the default project scope this returns EXACTLY the dict each level built before, so the
    emitted query is byte-identical. Under group scope it widens to the projects in the same
    DEFINED group - ungrouped projects never widen.

    Applied as a widened FILTER, never as an extra fallback level: every level here returns
    terminally on any non-empty result, and a filtered vector search is nearest-neighbour with no
    distance floor, so the project level is non-empty whenever the project has a single stored
    vector. A "group level" appended after it would fire only for projects that have never stored
    anything - i.e. never for the projects the sharing is meant to help.
    """
    p = str(project_name or "").strip().lower()
    extra = {"task_path": task_path} if task_path else None
    try:
        from src.services.project_groups import scope_where
        from src.services.recommendation_config import get_config
        if str((get_config() or {}).get("recommendationScope") or "project") == "group":
            return scope_where(p, extra=extra)
    except Exception:
        logger.exception("scope filter failed - using project scope")
    base = {"project_name": p}
    return {"$and": [base, extra]} if extra else base


def _scope_members(project_name):
    """The projects a search may return: [project] under project scope; the DEFINED group's
    members under group scope (group is the scope, "Other" stays project). Any failure
    answers the project alone - failing open would widen the search, the opposite of safe."""
    p = str(project_name or "").strip().lower()
    if not p:
        return []
    try:
        from src.services.project_groups import resolve_scope_projects
        from src.services.recommendation_config import get_config
        if str((get_config() or {}).get("recommendationScope") or "project") == "group":
            members, _mode = resolve_scope_projects(p)
            names = {str(m or "").strip().lower() for m in (members or []) if str(m or "").strip()}
            names.add(p)
            return sorted(names)
    except Exception:
        logger.exception("scope members failed - using project scope")
    return [p]


def search_similar_errors(error_message, project_name, top_k=10, task_path=None, allow_global_fallback=True):
    """
    Search for similar errors in ChromaDB with optional task-based filtering.

    Args:
        error_message: Error message text to search for
        project_name: Project name for scoping
        top_k: Number of results to return (default: 10, increased from 2)
        task_path: Optional task path for hierarchical filtering (e.g., ":TARGETS:HIP26:aramis")
        allow_global_fallback: When False, do NOT fall back to a cross-project query if
            the project-scoped search is empty. Error->solution recommendations are
            project-specific (a fix from another project references paths that don't
            exist here), so the recommendation path disables this to return empty
            ("no recommendation") instead of a misleading cross-project match.

    Returns:
        ChromaDB query result with ids, metadatas, distances
    """
    normalized_project = (project_name or "").strip().lower()
    normalized_task = (task_path or "").strip()
    # NOTE: recommendation (error->solution) stays PROJECT-scoped on purpose - a fix from another
    # project references paths/tasks that don't exist here. Only the artifact-evidence search is
    # global (see the data-injection searches in handlers + config.DATA_INJECTION_GLOBAL).

    logger.debug(
        "ChromaDB QUERY | collection=%s | project_name=%s | task_path=%s | top_k=%d",
        config.CHROMA_COLLECTION_ERROR, normalized_project or "<all>", normalized_task or "<none>", top_k,
    )
    
    # The SAME budget the stored vectors were built with - see error_embed_budget.
    _chars, _lines, _tokens = error_embed_budget()
    embedding = create_embedding(error_message or "", max_chars=_chars, max_lines=_lines, max_tokens=_tokens)
    
    # Filtering strategy (task_path extracted directly from report.html)
    # 1. Exact task + project match
    # 2. Project-only match
    # 3. Global fallback
    
    if normalized_project and normalized_task:
        # Level 1: Exact task + project match
        exact_task_result = _safe_query(collection, 
            query_embeddings=[embedding],
            where=_scope_filter(normalized_project, normalized_task),
            n_results=top_k,
            include=["metadatas", "distances", "documents"]
        )
        exact_task_ids = (exact_task_result.get("ids") or [[]])[0] or []
        if exact_task_ids:
            logger.debug(
                "ChromaDB QUERY result | collection=%s | match_level=exact_task | results_count=%d",
                config.CHROMA_COLLECTION_ERROR, len(exact_task_ids),
            )
            # Add match level to metadata
            metadatas = (exact_task_result.get("metadatas") or [[]])[0] or []
            for meta in metadatas:
                if isinstance(meta, dict):
                    meta["task_match_level"] = "exact"
            return exact_task_result
        
        
        logger.debug(
            "ChromaDB QUERY task-filtered returned empty | collection=%s | task_path=%s | fallback to project-only",
            config.CHROMA_COLLECTION_ERROR, normalized_task,
        )
    
    # Level 3: Project-only match (original behavior)
    if normalized_project:
        scoped = _safe_query(collection, 
            query_embeddings=[embedding],
            where=_scope_filter(normalized_project),
            n_results=top_k,
            include=["metadatas", "distances", "documents"]
        )
        scoped_ids = (scoped.get("ids") or [[]])[0] or []
        if scoped_ids:
            logger.debug(
                "ChromaDB QUERY result | collection=%s | match_level=project | results_count=%d",
                config.CHROMA_COLLECTION_ERROR, len(scoped_ids),
            )
            metadatas = (scoped.get("metadatas") or [[]])[0] or []
            for meta in metadatas:
                if isinstance(meta, dict):
                    meta["task_match_level"] = "project"
            return scoped
        logger.debug(
            "ChromaDB QUERY scoped returned empty | collection=%s | fallback to global query",
            config.CHROMA_COLLECTION_ERROR,
        )

    # Level 4: Global fallback (no filters)
    if not allow_global_fallback:
        # Project-scoped search was empty and cross-project results are not allowed.
        # Return empty so the caller reports "no recommendation" rather than a fix
        # from an unrelated project.
        logger.debug(
            "ChromaDB QUERY | collection=%s | project-scoped empty and global fallback disabled -> empty",
            config.CHROMA_COLLECTION_ERROR,
        )
        return {"ids": [[]], "metadatas": [[]], "distances": [[]], "documents": [[]]}

    global_result = _safe_query(collection, 
        query_embeddings=[embedding],
        n_results=top_k,
        include=["metadatas", "distances"]
    )
    global_ids = (global_result.get("ids") or [[]])[0] or []
    if not global_ids:
        logger.warning(
            "ChromaDB QUERY returned empty | collection=%s | project_name=%s | task_path=%s",
            config.CHROMA_COLLECTION_ERROR, normalized_project or "<all>", normalized_task or "<none>",
        )
    else:
        logger.debug(
            "ChromaDB QUERY result | collection=%s | match_level=global | results_count=%d",
            config.CHROMA_COLLECTION_ERROR, len(global_ids),
        )
        metadatas = (global_result.get("metadatas") or [[]])[0] or []
        for meta in metadatas:
            if isinstance(meta, dict):
                meta["task_match_level"] = "global"
    return global_result


# =====================================================================================
# Feedback adapter (learned step W) - one space decides, the other is recorded.
# Either the adapter is applied or it is not. Adapter ON ->
# the LEARNED-space ranking and its distances are the pool; OFF -> the base ranking. No rank
# fusion in between. Both searches still run when a W is loaded, because the trace must show
# the similarity in BOTH spaces for every candidate - that is how the adapter's effect is judged
# without applying it. Any failure falls back to the base result, so recommendations never break.
# =====================================================================================
_learned_collection_cache = None


def _get_learned_collection():
    global _learned_collection_cache
    if _learned_collection_cache is None:
        name = config.FEEDBACK_ADAPTER_LEARNED_COLLECTION
        if client is None:
            # AZURE_ONLY: the learned space is its OWN Azure index (built by the trainer). Until a
            # training run creates it, queries just return empty -> fusion degrades to base search.
            from src.azure_search.azure_collection import AzureCollection
            try:
                _learned_collection_cache = AzureCollection(name)
            except Exception:
                return None
        else:
            _learned_collection_cache = client.get_or_create_collection(name=name)
    return _learned_collection_cache


def _search_learned_space(error_message, project_name, top_k=10, task_path=None, allow_global_fallback=True):
    """Same project/task scoping as search_similar_errors, but in the LEARNED space:
    the query embedding is passed through adapter W and unit-normalised (the stored
    learned vectors are normalised) before matching the learned-space collection."""
    lc = _get_learned_collection()
    if lc is None:  # AZURE_ONLY / learned space unavailable -> fused search degrades to base only
        return _EMPTY_QUERY_RESULT
    _chars, _lines, _tokens = error_embed_budget()
    base_emb = create_embedding(error_message or "", max_chars=_chars, max_lines=_lines, max_tokens=_tokens)
    z = np.asarray(feedback_adapter.transform(base_emb), dtype=np.float64)
    # The learned index is created with the OUTPUT width of the adapter that built it. Promote a
    # W of a different width - or none at all, since transform() is then a no-op that passes the
    # full-width vector straight through - and every query is rejected for a dimension mismatch,
    # caught below, and returned as empty. The fusion then quietly falls back to the base ranking
    # while the state still says "active". Saying the width out loud makes that five seconds to
    # diagnose instead of a hunt through a stack trace.
    logger.debug("learned-space query | adapter_output_dim=%d | collection=%s",
                 int(z.shape[-1]), config.FEEDBACK_ADAPTER_LEARNED_COLLECTION)
    zq = (z / (float(np.linalg.norm(z)) or 1e-9)).tolist()
    normalized_project = (project_name or "").strip().lower()
    normalized_task = (task_path or "").strip()
    inc = ["metadatas", "distances", "documents"]
    if normalized_project and normalized_task:
        r = _safe_query(lc, query_embeddings=[zq],
                        where=_scope_filter(normalized_project, normalized_task),
                        n_results=top_k, include=inc)
        if (r.get("ids") or [[]])[0]:
            return r
    if normalized_project:
        r = _safe_query(lc, query_embeddings=[zq], where=_scope_filter(normalized_project),
                        n_results=top_k, include=inc)
        if (r.get("ids") or [[]])[0]:
            return r
    if not allow_global_fallback:
        return {"ids": [[]], "metadatas": [[]], "distances": [[]], "documents": [[]]}
    return _safe_query(lc, query_embeddings=[zq], n_results=top_k, include=inc)


def _ranked(res):
    """{vector id: (rank, distance)} of one ChromaDB-shaped result, rank starting at 1."""
    ids = (res.get("ids") or [[]])[0] or []
    dists = (res.get("distances") or [[]])[0] or []
    out: Dict[str, tuple] = {}
    for rank, vid in enumerate(ids, start=1):
        if vid and vid not in out:
            out[vid] = (rank, dists[rank - 1] if rank - 1 < len(dists) else None)
    return out


def _pool_from(chosen, other, chosen_label, top_k):
    """The ranking of ONE space, annotated with what the other space said about each candidate.

    The pool is either the base ranking or the learned ranking - never a
    rank fusion of the two. `chosen` decides the order AND the distance the rest of the pipeline
    reads (`distances`), so with the adapter on the similarity that earns match points is the
    learned-space similarity. What the trace needs from the other space is recorded on every
    meta, in the field names the trace already reads:

      adapter_rank_base / adapter_rank_learned          rank in each space, None = not retrieved
      adapter_distance_base / adapter_distance_learned  distance in each space, None = not retrieved

    None is kept as None on purpose: "the other space did not retrieve this at all" is a real and
    different finding from "the other space scored it low"."""
    other_label = "learned" if chosen_label == "base" else "base"
    other_ranked = _ranked(other)
    ids = [v for v in ((chosen.get("ids") or [[]])[0] or []) if v][:top_k]
    metas = (chosen.get("metadatas") or [[]])[0] or []
    docs = (chosen.get("documents") or [[]])[0] or []
    dists = (chosen.get("distances") or [[]])[0] or []
    metas_out, docs_out, dists_out = [], [], []
    for rank, vid in enumerate(ids, start=1):
        meta = dict(metas[rank - 1]) if rank - 1 < len(metas) and isinstance(metas[rank - 1], dict) else {}
        own_dist = dists[rank - 1] if rank - 1 < len(dists) else None
        other_rank, other_dist = other_ranked.get(vid, (None, None))
        meta[f"adapter_rank_{chosen_label}"] = rank
        meta[f"adapter_distance_{chosen_label}"] = own_dist
        meta[f"adapter_rank_{other_label}"] = other_rank
        meta[f"adapter_distance_{other_label}"] = other_dist
        meta["adapter_space"] = chosen_label
        metas_out.append(meta)
        docs_out.append(docs[rank - 1] if rank - 1 < len(docs) else None)
        dists_out.append(own_dist)
    return {"ids": [ids], "metadatas": [metas_out], "documents": [docs_out], "distances": [dists_out]}


def search_similar_errors_fused(error_message, project_name, top_k=10, task_path=None, allow_global_fallback=True):
    """Drop-in for search_similar_errors: the LEARNED ranking when the adapter is on for this
    project, the BASE ranking otherwise - each annotated with the other space's numbers when a
    W is loaded, so the trace always shows both similarities. Name kept for the callers."""
    base = search_similar_errors(error_message, project_name, top_k=top_k,
                                 task_path=task_path, allow_global_fallback=allow_global_fallback)
    try:
        if not feedback_adapter.is_active():
            # No W loaded: there is no second space to show, base is the only ranking.
            return base
        # Runtime ON/OFF switch (admin-controlled, global default + per-project override).
        # Unreadable settings -> treat as ON (the previous behaviour).
        try:
            from src.services.adapter_settings import adapter_enabled_for
            runtime_on = adapter_enabled_for(project_name)
        except Exception:
            runtime_on = True
        learned = _search_learned_space(error_message, project_name, top_k=top_k,
                                        task_path=task_path, allow_global_fallback=allow_global_fallback)
        if not ((learned.get("ids") or [[]])[0]):
            # Learned index empty or not built: base decides, and the trace can say the
            # adapter retrieved nothing (every adapter_*_learned stays None).
            return _pool_from(base, learned, "base", top_k) if runtime_on else base
        chosen_label = "learned" if runtime_on else "base"
        pool = _pool_from(learned if runtime_on else base, base if runtime_on else learned,
                          chosen_label, top_k)
        logger.debug(
            "feedback adapter | space=%s base=%d learned=%d pool=%d",
            chosen_label, len((base.get("ids") or [[]])[0]), len((learned.get("ids") or [[]])[0]),
            len((pool.get("ids") or [[]])[0]),
        )
        return pool
    except Exception as exc:
        logger.warning("learned-space search failed - using base ranking | %s", exc)
        return base


def search_errors_by_signatures(project_name, signature_hashes, top_k=2):
    normalized_project = (project_name or "").strip().lower()
    logger.debug(
        "Vector store QUERY by signatures | collection=%s | project_name=%s | signature_count=%d | top_k=%d",
        config.CHROMA_COLLECTION_ERROR, normalized_project or "<all>",
        len(signature_hashes) if signature_hashes else 0, top_k,
    )
    if not signature_hashes:
        logger.debug("Vector store QUERY by signatures | no signature_hashes provided, returning empty")
        return {"ids": [[]], "metadatas": [[]], "documents": [[]]}

    ids = []
    metadatas = []
    documents = []
    seen = set()
    # Group scope: the exact-signature lookup widens with the other sources - the
    # filter is the scope (the project alone, or every member of its defined group) and the
    # post-filter accepts any member. Under project scope both are byte-identical to before.
    scope_members = set(_scope_members(normalized_project)) if normalized_project else set()

    for signature in signature_hashes:
        if not signature:
            continue
        where_clause = {"error_signature_hash": signature}
        if normalized_project:
            where_clause = {
                "$and": [
                    _scope_filter(normalized_project),
                    {"error_signature_hash": signature},
                ]
            }

        try:
            rows = collection.get(
                where=where_clause,
                include=["metadatas", "documents"],
            )
        except Exception:
            # Compatibility fallback for Chroma deployments that don't accept $and.
            # The fallback itself must also fail-open - a store outage
            # here degraded to a 500 while the semantic path degraded gracefully.
            try:
                rows = collection.get(
                    where={"error_signature_hash": signature},
                    include=["metadatas", "documents"],
                )
            except Exception:
                logger.warning("signature lookup failed for %s - treating as no match", signature)
                continue
        row_ids = rows.get("ids") or []
        row_metas = rows.get("metadatas") or []
        row_docs = rows.get("documents") or []

        for idx, vector_id in enumerate(row_ids):
            if not vector_id or vector_id in seen:
                continue
            meta = row_metas[idx] if idx < len(row_metas) else {}
            if normalized_project and isinstance(meta, dict):
                if (meta.get("project_name") or "").strip().lower() not in scope_members:
                    continue
            seen.add(vector_id)
            ids.append(vector_id)
            metadatas.append(meta if isinstance(meta, dict) else {})
            documents.append(row_docs[idx] if idx < len(row_docs) else "")
            if len(ids) >= top_k:
                return {"ids": [ids], "metadatas": [metadatas], "documents": [documents]}

    if not ids:
        logger.warning(
            "Vector store QUERY by signatures returned empty | collection=%s | project_name=%s",
            config.CHROMA_COLLECTION_ERROR, normalized_project or "<all>",
        )
    else:
        logger.debug(
            "Vector store QUERY by signatures result | collection=%s | results_count=%d",
            config.CHROMA_COLLECTION_ERROR, len(ids),
        )
    return {"ids": [ids], "metadatas": [metadatas], "documents": [documents]}


def delete_error_vectors(vector_ids: List[str]) -> int:
    ids = [str(vector_id).strip() for vector_id in (vector_ids or []) if str(vector_id).strip()]
    if not ids:
        logger.debug("ChromaDB DELETE | collection=%s | no vector_ids provided, skipping", config.CHROMA_COLLECTION_ERROR)
        return 0
    logger.debug(
        "ChromaDB DELETE | collection=%s | vector_ids_count=%d | ids=%s",
        config.CHROMA_COLLECTION_ERROR, len(ids), ids,
    )
    collection.delete(ids=ids)
    logger.debug(
        "ChromaDB DELETE success | collection=%s | deleted_count=%d",
        config.CHROMA_COLLECTION_ERROR, len(ids),
    )
    return len(ids)


# UPLOAD_DIR = "./uploads"
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # src/routes
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, "..", ".."))
UPLOAD_DIR = os.path.join(PROJECT_ROOT, "uploads")

os.makedirs(UPLOAD_DIR, exist_ok=True)



def get_files_by_batch_id(batch_id):
    files = []
    logger.debug("get_files_by_batch_id | UPLOAD_DIR=%s | batch_id=%s", UPLOAD_DIR, batch_id)

    if not os.path.exists(UPLOAD_DIR):
        logger.warning("get_files_by_batch_id | UPLOAD_DIR does not exist | path=%s", UPLOAD_DIR)
        return files

    for name in os.listdir(UPLOAD_DIR):
        if name.startswith(f"{batch_id}-"):
            files.append(name)

    logger.debug("get_files_by_batch_id | batch_id=%s | files_found=%d", batch_id, len(files))
    return files
