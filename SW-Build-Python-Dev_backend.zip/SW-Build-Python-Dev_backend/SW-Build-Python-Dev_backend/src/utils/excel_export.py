"""Excel (.xlsx) export helper.

WHY SERVER-SIDE (chosen after trying it in the browser): building the file here
is faster - the rows never have to travel to the browser as JSON first - and it produces a real
workbook rather than a CSV. The CSV version had two problems that a spreadsheet cannot fix
afterwards: solution text contains newlines, which split one record across several rows, and
every column arrived at default width so the reader had to size them by hand.

The file is meant to be readable the moment it opens: header styled in Schaeffler green and
frozen, filters on, columns sized to their content, long text wrapped instead of spilling.
"""
from io import BytesIO
from typing import Callable, List, Sequence

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# Schaeffler green, matching the dashboard.
_HEADER_FILL = PatternFill("solid", fgColor="0B7A43")
_HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
_HEADER_ALIGN = Alignment(horizontal="left", vertical="center")
_CELL_ALIGN = Alignment(vertical="top", wrap_text=True)
_THIN = Side(style="thin", color="D9DEDB")
_BORDER = Border(bottom=_THIN)

# Excel refuses a cell over 32767 characters; keep well under and say so when trimming.
_MAX_CELL = 8000


class Column:
    """One export column: its header, how to read it from a row, and how wide to make it."""

    def __init__(self, header: str, value: Callable[[dict], object],
                 min_width: int = 10, max_width: int = 60, wrap: bool = False):
        self.header = header
        self.value = value
        # Widths are MEASURED from the data (all column cells arrange automatically with
        # the data), not fixed - a fixed width is wrong for every dataset except the one it was
        # picked for. The bounds only stop a single very long value from making a column
        # unusable, and stop a short column collapsing under its own header.
        self.min_width = min_width
        self.max_width = max_width
        self.wrap = wrap


def _clean(value) -> str:
    """One cell, one line. Newlines and tabs in stored solution text are exactly what shattered
    the CSV export into unreadable fragments."""
    text = "" if value is None else str(value)
    text = text.replace("\r\n", " ").replace("\n", " ").replace("\r", " ").replace("\t", " ")
    text = " ".join(text.split())
    if len(text) > _MAX_CELL:
        text = text[:_MAX_CELL] + f" ... [trimmed, {len(text)} chars]"
    return text


def build_workbook(rows: Sequence[dict], columns: List[Column], sheet_title: str,
                   context_lines: Sequence[str] = ()) -> BytesIO:
    """Return an .xlsx in memory. context_lines appear above the table - the filters the export
    was taken with, so a file opened weeks later still explains itself."""
    wb = Workbook()
    ws = wb.active
    ws.title = (sheet_title or "Export")[:31]          # Excel's sheet-name limit

    first_data_row = 1
    if context_lines:
        for offset, line in enumerate(context_lines):
            cell = ws.cell(row=1 + offset, column=1, value=line)
            cell.font = Font(italic=True, size=9, color="55605A")
        first_data_row = len(context_lines) + 2         # blank line between context and table

    header_row = first_data_row
    for idx, col in enumerate(columns, start=1):
        cell = ws.cell(row=header_row, column=idx, value=col.header)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = _HEADER_ALIGN
    ws.row_dimensions[header_row].height = 20

    # Widest value seen per column, so the widths below fit THIS export's data.
    widest = [len(col.header) for col in columns]

    for r, row in enumerate(rows, start=header_row + 1):
        for c, col in enumerate(columns, start=1):
            try:
                raw = col.value(row)
            except Exception:
                raw = ""
            text = _clean(raw)
            cell = ws.cell(row=r, column=c, value=text)
            cell.border = _BORDER
            cell.alignment = _CELL_ALIGN if col.wrap else Alignment(vertical="top")
            if len(text) > widest[c - 1]:
                widest[c - 1] = len(text)

    for idx, col in enumerate(columns, start=1):
        # +2 for the cell padding Excel adds; clamped so nothing collapses or runs off screen.
        fitted = min(max(widest[idx - 1] + 2, col.min_width), col.max_width)
        ws.column_dimensions[get_column_letter(idx)].width = fitted

    last_col = get_column_letter(len(columns))
    last_row = header_row + len(rows)
    # Filters on the header, and the header stays visible while scrolling a long export.
    ws.auto_filter.ref = f"A{header_row}:{last_col}{max(last_row, header_row)}"
    ws.freeze_panes = ws.cell(row=header_row + 1, column=1)

    stream = BytesIO()
    wb.save(stream)
    stream.seek(0)
    return stream
