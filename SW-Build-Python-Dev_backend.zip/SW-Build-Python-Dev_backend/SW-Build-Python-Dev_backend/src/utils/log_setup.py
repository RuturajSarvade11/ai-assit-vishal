# src/utils/log_setup.py
"""
Centralised logging initialisation.

Call setup_logging() once at import time from any module.  It is fully
idempotent: if a FileHandler targeting logs/app.txt is already attached to
the root logger the function returns immediately so modules can safely import
this at the top without worrying about duplicate handlers.

Behaviour
---------
- Creates  <project_root>/logs/  directory (if absent).
- Opens    <project_root>/logs/app.txt  in append mode.
- Attaches a DEBUG-level FileHandler to the root logger.
- Leaves any existing StreamHandlers at INFO so the console stays clean.
- Sets root logger level to DEBUG so file receives everything.
- Silences chatty third-party libraries at WARNING level.
"""

import logging
import os
from pathlib import Path

# Resolve project root:  src/utils/log_setup.py  →  ../../  → project root
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_LOG_DIR = _PROJECT_ROOT / "logs"
_LOG_FILE = _LOG_DIR / "app.txt"

_FILE_FORMAT = (
    "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
)

# Third-party libraries that produce enormous DEBUG output
_NOISY_LIBS = [
    "botocore",
    "boto3",
    "urllib3",
    "s3transfer",
    "azure",
    "httpx",
    "httpcore",
    "openai",
    "hpack",
    "h2",
    "h11",
]


def setup_logging() -> None:
    """Idempotent logging bootstrap.  Safe to call from every module."""
    root = logging.getLogger()

    # Idempotency guard: skip if our file handler is already attached
    for handler in root.handlers:
        if isinstance(handler, logging.FileHandler):
            try:
                if handler.baseFilename == str(_LOG_FILE.resolve()):
                    return
            except Exception:
                pass

    # Create logs directory
    _LOG_DIR.mkdir(parents=True, exist_ok=True)

    # File handler — DEBUG level, append mode
    file_handler = logging.FileHandler(str(_LOG_FILE), mode="a", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(_FILE_FORMAT))

    # Raise existing console (Stream) handlers to INFO to avoid stdout flood
    for handler in root.handlers:
        if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
            if handler.level < logging.INFO:
                handler.setLevel(logging.INFO)

    root.setLevel(logging.DEBUG)
    root.addHandler(file_handler)

    # Console (stream) handler — so logs are visible in the console regardless of the WSGI server.
    # Waitress (unlike the Flask dev server) does NOT print request logs to stdout, so without an
    # explicit console handler the console looks dead even though the file keeps logging. Add one
    # at INFO by default (tunable via LOG_CONSOLE_LEVEL=DEBUG/INFO/WARNING; set OFF to disable).
    _console_level = os.getenv("LOG_CONSOLE_LEVEL", "INFO").strip().upper()
    _has_console = any(
        isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
        for h in root.handlers
    )
    if _console_level != "OFF" and not _has_console:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(getattr(logging, _console_level, logging.INFO))
        console_handler.setFormatter(logging.Formatter(_FILE_FORMAT))
        root.addHandler(console_handler)

    # Silence noisy third-party libraries
    for lib in _NOISY_LIBS:
        logging.getLogger(lib).setLevel(logging.WARNING)

    logging.getLogger(__name__).debug(
        "Logging initialised | log_file=%s", str(_LOG_FILE)
    )


# Auto-initialise on first import
setup_logging()
