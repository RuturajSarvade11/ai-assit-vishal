import os
import uuid
import json
import hashlib
import logging
import re
import time
from decimal import Decimal
from datetime import datetime, UTC
from boto3.dynamodb.conditions import Attr, Key
from botocore.exceptions import ClientError

import src.utils.log_setup  # noqa: F401
from src.databases.database import get_dynamodb, get_table
from src.utils.payload_archive import list_payload_archives_for_request
from src.configurations import config as _config

logger = logging.getLogger(__name__)

_sfx = _config.DYNAMODB_TABLE_SUFFIX
dynamodb = get_dynamodb()

project_table = dynamodb.Table(f"project{_sfx}")
solution_table = dynamodb.Table(f"solution{_sfx}")
error_log_table = dynamodb.Table(f"error_log{_sfx}")
recommended_table = dynamodb.Table(f"recommended{_sfx}")
solution_files_table = dynamodb.Table(f"solution_files{_sfx}")
binary_files_table = dynamodb.Table(f"binary_files{_sfx}")
final_build_payload_table = dynamodb.Table(f"final_build_payload{_sfx}")
ai_assisted_data_table = get_table()
logger.debug(
    "DynamoDB tables init | suffix=%s | tables=[project%s, solution%s, error_log%s, "
    "recommended%s, solution_files%s, binary_files%s, final_build_payload%s, %s]",
    _sfx, _sfx, _sfx, _sfx, _sfx, _sfx, _sfx, _sfx, ai_assisted_data_table.name,
)
ARCHIVE_SK = "ARCHIVE"
VECTOR_SK = "VECTOR"
ERROR_SK = "ERROR"
FIX_SK = "FIX"
BINARY_SK = "BINARY"
RUNTIME_SK = "RUNTIME"
VECTORIZE_SK = "VECTORIZE_STATUS"
RECOMMEND_SUMMARY_SK = "RECOMMEND#SUMMARY"
MCP_SESSION_SK = "MCP_SESSION#STATE"
MCP_ERROR_SESSION_SK = "MCP_SESSION#ERROR_STATE"
MCP_ERROR_LAST_SK = "MCP_SESSION#ERROR_LAST"
MCP_ERROR_CONTEXT_SK = "MCP_SESSION#ERROR_CONTEXT"
MCP_ERROR_ARCHIVE_INDEX_SK = "MCP_SESSION#ERROR_ARCHIVE_INDEX"
MCP_PREDICT_SESSION_SK = "MCP_PREDICT#SESSION"
PREDICT_HISTORY_SK = "PREDICT_HISTORY"
MAINTENANCE_RUN_SK = "MAINTENANCE#RUN"
MAINTENANCE_LATEST_SK = "MAINTENANCE#LATEST"
_HOT_RETENTION_DAYS = 90
_WARM_RETENTION_DAYS = 365
_ARCHIVE_RETENTION_DAYS = 1095
_RECOMMEND_SHOWN_RETENTION_DAYS = 180
_RECOMMEND_SUCCESS_RETENTION_DAYS = 730


def _now_utc() -> datetime:
    return datetime.now(UTC)


def _iso_utc(dt: datetime | None = None) -> str:
    return (dt or _now_utc()).strftime("%Y-%m-%dT%H:%M:%SZ")


def _epoch_utc(dt: datetime | None = None) -> int:
    base = dt or _now_utc()
    return int(base.timestamp())


def _retention_epoch(days: int, start: datetime | None = None) -> int:
    base = start or _now_utc()
    return int((base.timestamp()) + max(1, int(days)) * 86400)


def _to_decimal(value: float | int | str) -> Decimal:
    return Decimal(str(value if value is not None else 0))


def _parse_iso_utc(value: str) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        if text.endswith("Z"):
            return datetime.fromisoformat(text.replace("Z", "+00:00"))
        return datetime.fromisoformat(text)
    except Exception:
        return None


def _days_since(value: str, now: datetime | None = None) -> float:
    dt = _parse_iso_utc(value)
    if not dt:
        return 9999.0
    now_dt = now or _now_utc()
    try:
        delta = now_dt - dt
        return max(0.0, delta.total_seconds() / 86400.0)
    except Exception:
        return 9999.0


def _table_key_names(table) -> set[str]:
    try:
        table.load()
        schema = table.key_schema or []
        return {str(k.get("AttributeName") or "") for k in schema if isinstance(k, dict)}
    except Exception:
        return set()


def _item_key(table, item: dict) -> dict | None:
    if not isinstance(item, dict):
        return None
    key_names = _table_key_names(table)
    if not key_names:
        return None
    key = {name: item.get(name) for name in key_names if name in item}
    if len(key) != len(key_names):
        return None
    return key


def _final_build_keys(request_id: str) -> tuple[dict, dict]:
    """
    Return (key, extra_item_fields) for current final_build_payload table schema.
    Supports both legacy key schema (request_id) and new schema (PK/SK).
    """
    key_names = _table_key_names(final_build_payload_table)
    if "PK" in key_names and "SK" in key_names:
        return (
            {"PK": f"FINAL_BUILD#{request_id}", "SK": "PAYLOAD"},
            {"PK": f"FINAL_BUILD#{request_id}", "SK": "PAYLOAD"},
        )
    return ({"request_id": request_id}, {"request_id": request_id})


def _is_key_schema_mismatch(err: ClientError) -> bool:
    code = (err.response or {}).get("Error", {}).get("Code", "")
    msg = ((err.response or {}).get("Error", {}).get("Message", "") or "").lower()
    return code == "ValidationException" and "key element does not match the schema" in msg


def _strip_payload_for_dynamo(payload: dict) -> str:
    """
    Build a DynamoDB-safe payload JSON string.

    DynamoDB stores only the solution + project/task mapping.
    Everything else (errorDetails, all_changes, patch context) lives in S3 archive.

    Fields always removed:
      - errorDetails  : raw build-log text — large for big projects, not needed for lookups
      - all_changes   : raw file snapshots — archived to S3 separately
      - patch         : 10-line code context per changeObject — needed for embedding only,
                        computed in-memory before this call

    If the stripped payload still exceeds DynamoDB's 400 KB limit (e.g. solution
    has hundreds of changeObjects), changeObjects are dropped entirely as a last resort —
    `changes` (compact string array) is sufficient for all DynamoDB consumers.
    """
    _DYNAMO_MAX_BYTES = 380_000  # hard limit 400 KB; leave 20 KB headroom for other fields

    # Always-strip fields — large blobs that belong in S3, not DynamoDB
    stripped: dict = {
        k: v for k, v in payload.items()
        if k not in {"errorDetails", "all_changes", "snapshotBefore", "snapshotAfter", "modifiedFunctions"}
    }

    # Always strip `patch` from changeObjects — only needed for embedding (done before this call)
    # Also strip snapshotBefore/snapshotAfter — large XML/HTML strings stored in S3, not DynamoDB
    # Strip on COPIES. The previous in-place pops mutated the CALLER's
    # payload, so _store_patch_prediction_features (which runs AFTER the save) never saw the
    # patch/snapshot data - the patch scoring source was silently dead for every new upload -
    # and the upload-time duplicate check hashed a payload whose stored twin had already lost
    # these fields, so identical re-uploads minted new rows.
    solution = stripped.get("solution")
    if isinstance(solution, list):
        copied_solution = []
        for file_item in solution:
            if not isinstance(file_item, dict):
                copied_solution.append(file_item)
                continue
            file_copy = {k: v for k, v in file_item.items()
                         if k not in ("snapshotBefore", "snapshotAfter")}
            objs = file_copy.get("changeObjects")
            if isinstance(objs, list):
                file_copy["changeObjects"] = [
                    ({k: v for k, v in o.items() if k != "patch"} if isinstance(o, dict) else o)
                    for o in objs
                ]
            copied_solution.append(file_copy)
        solution = copied_solution
        stripped["solution"] = solution

    serialized = json.dumps(stripped, separators=(",", ":"))
    if len(serialized.encode("utf-8")) <= _DYNAMO_MAX_BYTES:
        return serialized

    # Last resort: drop changeObjects entirely — `changes` string array is enough for lookups
    if isinstance(solution, list):
        for file_item in solution:
            if isinstance(file_item, dict):
                file_item.pop("changeObjects", None)
    return json.dumps(stripped, separators=(",", ":"))


def save_final_build_payload(request_id: str, payload: dict):
    _, key_item = _final_build_keys(request_id)
    project_type = str(payload.get("projectType") or "").strip().lower()
    stripped = _strip_payload_for_dynamo(payload)
    logger.debug(
        "DynamoDB PUT | table=%s | request_id=%s | project=%s | payload_bytes=%d",
        final_build_payload_table.name, request_id,
        payload.get("projectName"), len(stripped.encode("utf-8")),
    )
    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    item = {
        **key_item,
        "request_id": request_id,
        "batch_id": payload.get("uuid", ""),
        "project_name": payload.get("projectName"),
        "task_name": payload.get("taskName"),
        "username": payload.get("username", ""),
        "payload_json": stripped,
        "created_date": now_iso,
        # Storage proposal: keep the original sighting separate from re-uploads.
        # first_seen_date never changes; last_seen_date/upload_count move on every duplicate.
        "first_seen_date": now_iso,
        "last_seen_date": now_iso,
        "upload_count": 1,
    }
    if project_type:
        item["project_type"] = project_type
    final_build_payload_table.put_item(Item=item)
    logger.debug("DynamoDB PUT success | table=%s | request_id=%s", final_build_payload_table.name, request_id)


def update_final_build_resolution_description(request_id: str, description: str | None):
    if not request_id:
        return False

    key, _ = _final_build_keys(request_id)
    res = final_build_payload_table.get_item(Key=key)
    item = res.get("Item") or {}
    if not item:
        return False

    payload_raw = item.get("payload_json")
    payload = {}
    if isinstance(payload_raw, str):
        try:
            payload = json.loads(payload_raw)
        except Exception:
            payload = {}
    elif isinstance(payload_raw, dict):
        payload = dict(payload_raw)

    payload["resolutionDescription"] = description if description else None

    final_build_payload_table.update_item(
        Key=key,
        UpdateExpression=(
            "SET payload_json = :payload_json, "
            "resolution_description = :resolution_description, "
            "updated_date = :updated_date"
        ),
        ExpressionAttributeValues={
            ":payload_json": _strip_payload_for_dynamo(payload),
            ":resolution_description": description if description else None,
            ":updated_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
        ConditionExpression="attribute_exists(request_id) OR attribute_exists(PK)",
    )
    return True


def touch_final_build_payload(request_id: str, task_name: str = "") -> bool:
    """
    Update created_date to now on an existing final_build_payload record so it
    appears within the current date-range window on the UI.
    Returns True if the record was updated, False otherwise.
    """
    if not request_id:
        return False
    key, _ = _final_build_keys(request_id)
    try:
        # created_date still moves so the record surfaces in the UI date window (shipped
        # behavior). Additive per the storage proposal: first_seen_date keeps the ORIGINAL
        # date (from the pre-update created_date), last_seen_date/upload_count track re-uploads.
        # All reads inside an UpdateExpression see the pre-update item, so if_not_exists
        # captures the old created_date before it is overwritten.
        # The TASK also refreshes: a duplicate error re-uploaded from another
        # task must show the task it JUST failed on, not the one from months ago — the dashboard
        # row and the same-task recommendation boost both read task_name.
        update_expression = (
            "SET first_seen_date = if_not_exists(first_seen_date, created_date), "
            "last_seen_date = :now, "
            "upload_count = if_not_exists(upload_count, :one) + :one, "
            "created_date = :now, updated_date = :now"
        )
        values = {
            ":now": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            ":one": 1,
        }
        clean_task = str(task_name or "").strip()
        if clean_task:
            update_expression += ", task_name = :task_name"
            values[":task_name"] = clean_task
        final_build_payload_table.update_item(
            Key=key,
            UpdateExpression=update_expression,
            ConditionExpression="attribute_exists(request_id) OR attribute_exists(PK)",
            ExpressionAttributeValues=values,
        )
        logger.debug(
            "DynamoDB touch | table=%s | request_id=%s | created_date refreshed",
            final_build_payload_table.name, request_id,
        )
        return True
    except ClientError as err:
        code = err.response.get("Error", {}).get("Code", "")
        if code in {"ConditionalCheckFailedException", "ResourceNotFoundException"}:
            return False
        raise


def update_project_type_in_final_build(request_id: str, project_type: str):
    """
    Stamp project_type on an existing final_build_payload record.
    No-op if the record does not exist or project_type is empty.
    """
    if not request_id or not project_type:
        return
    key, _ = _final_build_keys(request_id)
    try:
        final_build_payload_table.update_item(
            Key=key,
            UpdateExpression="SET project_type = :pt",
            ConditionExpression="attribute_exists(request_id) OR attribute_exists(PK)",
            ExpressionAttributeValues={":pt": project_type},
        )
    except ClientError as err:
        code = err.response.get("Error", {}).get("Code", "")
        if code not in {"ConditionalCheckFailedException", "ResourceNotFoundException"}:
            raise


def ensure_final_build_payload(request_id: str, payload: dict):
    if not request_id or not str(request_id).strip():
        return
    _, key_item = _final_build_keys(request_id)
    key_names = _table_key_names(final_build_payload_table)
    cond_attr = "PK" if "PK" in key_names else "request_id"
    developer_id = str(payload.get("developer_id") or payload.get("username") or "").strip()
    try:
        item = {
            **key_item,
            "request_id": request_id,
            "project_name": payload.get("projectName"),
            "task_name": payload.get("taskName"),
            "payload_json": _strip_payload_for_dynamo(payload),
            "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        if developer_id:
            item["developer_id"] = developer_id
        final_build_payload_table.put_item(
            Item=item,
            ConditionExpression=f"attribute_not_exists({cond_attr})",
        )
    except ClientError as err:
        if err.response.get("Error", {}).get("Code", "") != "ConditionalCheckFailedException":
            raise


def get_final_build_payload(request_id: str):
    try:
        key, _ = _final_build_keys(request_id)
        logger.debug("DynamoDB GET | table=%s | request_id=%s | key=%s", final_build_payload_table.name, request_id, key)
        res = final_build_payload_table.get_item(Key=key)
    except Exception:
        logger.warning("DynamoDB GET failed | table=%s | request_id=%s", final_build_payload_table.name, request_id)
        return None

    item = res.get("Item")
    if not item:
        logger.warning("DynamoDB GET | table=%s | request_id=%s | item NOT FOUND", final_build_payload_table.name, request_id)
        return None
    logger.debug("DynamoDB GET | table=%s | request_id=%s | item FOUND", final_build_payload_table.name, request_id)

    payload_raw = item.get("payload_json")
    payload = {}
    if isinstance(payload_raw, str):
        try:
            payload = json.loads(payload_raw)
        except Exception:
            payload = {}
    elif isinstance(payload_raw, dict):
        payload = payload_raw

    return {
        "request_id": item.get("request_id"),
        "project_name": item.get("project_name") or payload.get("projectName"),
        "task_name": item.get("task_name") or payload.get("taskName"),
        "first_seen_date": item.get("first_seen_date") or item.get("created_date"),
        "solution": payload.get("solution", []),
        # The developer's resolution description is stored in its own column (set via
        # update_final_build_resolution_description), with the payload as a fallback. Expose
        # both naming conventions so callers (incl. recommendation hydration) find it.
        "resolutionDescription": item.get("resolution_description") or payload.get("resolutionDescription"),
        "resolution_description": item.get("resolution_description") or payload.get("resolutionDescription") or "",
        "payload_json": payload,
        "created_date": item.get("created_date"),
        "recommended_count": item.get("recommended_count", payload.get("recommended_count", [])),
    }


def delete_final_build_payload(request_id: str) -> bool:
    if not request_id:
        return False
    key, _ = _final_build_keys(request_id)
    try:
        final_build_payload_table.delete_item(Key=key)
        return True
    except Exception:
        return False


def get_archive_references_from_db(request_id: str) -> list[dict]:
    """Fast DynamoDB query for archive references — O(1) vs O(bucket_size) S3 LIST scan."""
    if not request_id:
        return []
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(request_id) & Key("SK").begins_with(f"{ARCHIVE_SK}#"),
        )
        return res.get("Items", [])
    except Exception:
        return []


def list_request_scoped_items(request_id: str) -> list[dict]:
    if not request_id:
        return []
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(request_id),
        )
        return res.get("Items", [])
    except Exception:
        return []


def list_request_reference_items(request_id: str) -> list[dict]:
    if not request_id:
        return []
    try:
        rows = _scan_all(ai_assisted_data_table, filter_expression=Attr("request_id").eq(request_id))
    except Exception:
        return []

    deduped = []
    seen = set()
    for row in rows:
        pk = str(row.get("PK") or "")
        sk = str(row.get("SK") or "")
        key = (pk, sk)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    return deduped


def delete_ai_assisted_items(items: list[dict]) -> int:
    return delete_table_items(ai_assisted_data_table, items)


def list_vector_reference_items_by_vector_id(vector_id: str) -> list[dict]:
    if not vector_id:
        return []
    try:
        return _scan_all(ai_assisted_data_table, filter_expression=Attr("vector_id").eq(vector_id))
    except Exception:
        return []


def list_final_build_payloads_by_project(project_name: str):
    project_norm = _normalize_project_name(project_name)
    if not project_norm:
        return []

    rows = _scan_all(final_build_payload_table)
    out = []
    for row in rows:
        payload = _payload_json_dict(row)
        row_project = _normalize_project_name(
            row.get("project_name") or payload.get("projectName")
        )
        if row_project != project_norm:
            continue
        out.append(
            {
                "request_id": row.get("request_id"),
                "project_name": row_project,
                "task_name": row.get("task_name") or payload.get("taskName"),
                "payload_json": payload,
                "created_date": row.get("created_date"),
            }
        )
    return out


# -------------------------------------------------
# PROJECT-WIDE DELETE (DELETE /delete-project)
# -------------------------------------------------
# Rows that belong to a PROJECT rather than to one request: MCP session state, prediction
# history, error-signature indexes, copilot archives. Their PK carries the project name as the
# second '#'-separated segment (see the *_pk builders in this module). The per-request sweep
# never reaches them because they carry no request_id.
_PROJECT_PK_PREFIXES = (
    ERROR_SK, "MCPSESSION", "MCPERRORSESSION", "MCPERRORCONTEXT", "MCPPREDICT",
    "PREDICT_HISTORY", "MCPERRORARCHIVE",
)


def _project_name_spellings(project_name) -> list[str]:
    """The raw spelling and the normalized one, deduplicated - keys were written both ways over time."""
    raw = str(project_name or "").strip()
    return list(dict.fromkeys([raw, _normalize_project_name(raw)])) if raw else []


def list_project_scoped_items(project_name: str) -> list[dict]:
    """Every ai_assisted_data row that belongs to this project (case-insensitive on the name):
    a PK of the form <PREFIX>#<project>#... for the known project-keyed prefixes, or a
    project_name attribute equal to it. One filtered scan; empty on any failure."""
    project_norm = _normalize_project_name(project_name)
    if not project_norm:
        return []
    condition = None
    for spelling in _project_name_spellings(project_name):
        for expr in (Attr("PK").contains(f"#{spelling}"), Attr("project_name").eq(spelling)):
            condition = expr if condition is None else (condition | expr)
    try:
        rows = _scan_all(ai_assisted_data_table, filter_expression=condition)
    except Exception:
        logger.exception("list_project_scoped_items scan failed | project=%s", project_norm)
        return []

    out, seen = [], set()
    for row in rows:
        pk = str(row.get("PK") or "")
        sk = str(row.get("SK") or "")
        parts = pk.split("#")
        by_pk = len(parts) >= 2 and parts[0] in _PROJECT_PK_PREFIXES and _normalize_project_name(parts[1]) == project_norm
        by_attr = _normalize_project_name(row.get("project_name")) == project_norm
        if not (by_pk or by_attr) or (pk, sk) in seen:
            continue
        seen.add((pk, sk))
        out.append(row)
    return out


def delete_project_row(project_name: str) -> int:
    """Drop the `project` table row for this name (raw and normalized spelling). Returns how many existed."""
    removed = 0
    for name in _project_name_spellings(project_name):
        logger.debug("DynamoDB DELETE | table=%s | project_name=%s", project_table.name, name)
        res = project_table.delete_item(Key={"project_name": name}, ReturnValues="ALL_OLD")
        if res.get("Attributes"):
            removed += 1
    return removed


def append_final_build_recommendation_hit(
    request_id: str,
    recommended: bool = True,
    hit_date: str | None = None,
):
    if not hit_date:
        hit_date = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    key, _ = _final_build_keys(request_id)
    key_names = _table_key_names(final_build_payload_table)
    cond_attr = "PK" if "PK" in key_names else "request_id"

    # Load current row to build increasing count.
    res = final_build_payload_table.get_item(Key=key)
    item = res.get("Item") or {}
    history = item.get("recommended_count")
    if not isinstance(history, list):
        payload = _payload_json_dict(item)
        history = payload.get("recommended_count")
    if not isinstance(history, list):
        history = []

    last_count = 0
    if history:
        try:
            last_count = int((history[-1] or {}).get("count") or 0)
        except Exception:
            last_count = len(history)
    next_count = max(1, last_count + 1)

    hit = {
        "count": next_count,
        "recommended": bool(recommended),
        "Date": hit_date,
    }
    history.append(hit)

    final_build_payload_table.update_item(
        Key=key,
        UpdateExpression=(
            "SET recommended_count = :recommended_count, "
            "updated_date = :updated_date"
        ),
        ExpressionAttributeValues={
            ":recommended_count": history,
            ":updated_date": hit_date,
        },
        ConditionExpression=f"attribute_exists({cond_attr})",
        ReturnValues="UPDATED_NEW",
    )

    return hit


def save_archived_payload_reference(
    request_id: str,
    project_name: str,
    env: str,
    file_name: str,
    file_key_name: str,
    s3_bucket: str,
    s3_key: str,
    sha256: str,
    etag: str,
    compressed_size: int,
    created_date: str,
    project_type: str = "",
    developer_id: str = "",
    content_fingerprint: str = "",
):
    sk = f"{ARCHIVE_SK}#{file_key_name}"
    logger.debug(
        "DynamoDB PUT | table=%s | PK=%s | SK=%s | s3_bucket=%s | s3_key=%s | file_name=%s | compressed_size=%d",
        ai_assisted_data_table.name, request_id, sk, s3_bucket, s3_key, file_name, compressed_size,
    )
    item = {
        "PK": request_id,
        "SK": f"{ARCHIVE_SK}#{file_key_name}",
        "request_id": request_id,
        "project_name": project_name,
        "env": env,
        "file_name": file_name,
        "file_key_name": file_key_name,
        "s3_bucket": s3_bucket,
        "s3_key": s3_key,
        "sha256": sha256,
        "etag": etag,
        "compressed_size": compressed_size,
        "created_date": created_date,
    }
    if project_type:
        item["project_type"] = project_type
    if developer_id:
        item["developer_id"] = developer_id
    if str(content_fingerprint or "").strip():
        item["content_fingerprint"] = str(content_fingerprint).strip()
    ai_assisted_data_table.put_item(
        Item=item,
        ConditionExpression="attribute_not_exists(PK) AND attribute_not_exists(SK)",
    )


def get_archived_payload_references(request_id: str):
    # S3-only archive lookup by request_id (no DynamoDB dependency for archive fetch).
    return list_payload_archives_for_request(request_id)


def get_archived_payload_reference(request_id: str):
    items = get_archived_payload_references(request_id)
    return items[0] if items else None


def save_vector_reference(
    request_id: str,
    vector_id: str,
    project_name: str,
    env: str,
    s3_key: str,
    file_name: str,
    error_signature_hash: str,
):
    now = _now_utc()
    ref_token = hashlib.sha1(f"{vector_id}|{s3_key}".encode("utf-8")).hexdigest()[:16]
    sk = f"{VECTOR_SK}#{vector_id}#{ref_token}"
    logger.debug(
        "DynamoDB PUT | table=%s | PK=%s | SK=%s | vector_id=%s | s3_key=%s | file_name=%s",
        ai_assisted_data_table.name, request_id, sk, vector_id, s3_key, file_name,
    )
    ai_assisted_data_table.put_item(
        Item={
            "PK": request_id,
            "SK": f"{VECTOR_SK}#{vector_id}#{ref_token}",
            "request_id": request_id,
            "vector_id": vector_id,
            "project_name": project_name,
            "env": env,
            "s3_key": s3_key,
            "file_name": file_name,
            "error_signature_hash": error_signature_hash,
            "metadata_mode": "compact",
            "storage_tier": "hot",
            "archive_only_after": _retention_epoch(_WARM_RETENTION_DAYS, now),
            "expires_at": _retention_epoch(_ARCHIVE_RETENTION_DAYS, now),
            "created_date": _iso_utc(now),
        },
        ConditionExpression="attribute_not_exists(PK) AND attribute_not_exists(SK)",
    )


def get_vector_references(request_id: str):
    logger.debug("DynamoDB QUERY | table=%s | PK=%s | SK begins_with=%s#", ai_assisted_data_table.name, request_id, VECTOR_SK)
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(request_id) & Key("SK").begins_with(f"{VECTOR_SK}#"),
        )
        items = []
        for item in res.get("Items", []):
            tier = classify_storage_tier(item)
            if tier == "expired":
                continue
            item["effective_storage_tier"] = tier
            items.append(item)
        items.sort(key=lambda row: 0 if str(row.get("effective_storage_tier") or "") == "hot" else 1)
        if not items:
            logger.warning("DynamoDB QUERY | table=%s | request_id=%s | vector references EMPTY", ai_assisted_data_table.name, request_id)
        else:
            logger.debug("DynamoDB QUERY | table=%s | request_id=%s | vector_references_count=%d", ai_assisted_data_table.name, request_id, len(items))
        return items
    except Exception:
        logger.warning("DynamoDB QUERY failed | table=%s | request_id=%s", ai_assisted_data_table.name, request_id)
        return []


def _error_pk(project_name: str, env: str, error_hash: str) -> str:
    return f"{ERROR_SK}#{project_name}#{env}#{error_hash}"


def get_error_vector_index(project_name: str, env: str, error_hash: str):
    try:
        res = ai_assisted_data_table.get_item(
            Key={"PK": _error_pk(project_name, env, error_hash), "SK": "VECTOR"}
        )
        return res.get("Item")
    except Exception:
        return None


def classify_storage_tier(item: dict | None) -> str:
    if not isinstance(item, dict):
        return "unknown"
    now_epoch = _epoch_utc()
    expires_at = int(item.get("expires_at", 0) or 0)
    archive_only_after = int(item.get("archive_only_after", 0) or 0)
    explicit = str(item.get("storage_tier") or "").strip().lower()
    if expires_at and expires_at <= now_epoch:
        return "expired"
    if archive_only_after and archive_only_after <= now_epoch:
        return "archive-only"
    if explicit in {"hot", "warm"}:
        return explicit
    return "hot"


def get_error_signature_summary(project_name: str, env: str, error_hash: str):
    try:
        res = ai_assisted_data_table.get_item(
            Key={"PK": _error_pk(project_name, env, error_hash), "SK": "SUMMARY"}
        )
        item = res.get("Item")
        if not isinstance(item, dict):
            return None
        item["effective_storage_tier"] = classify_storage_tier(item)
        return item
    except Exception:
        return None


def save_error_vector_index(
    project_name: str,
    env: str,
    error_hash: str,
    error_message: str,
    vector_id: str,
):
    now = _now_utc()
    pk = _error_pk(project_name, env, error_hash)
    logger.debug(
        "DynamoDB UPDATE | table=%s | PK=%s | SK=VECTOR | error_hash=%s | vector_id=%s",
        ai_assisted_data_table.name, pk, error_hash, vector_id,
    )
    ai_assisted_data_table.update_item(
        Key={"PK": _error_pk(project_name, env, error_hash), "SK": "VECTOR"},
        UpdateExpression=(
            "SET project_name = :project_name, "
            "env = :env, "
            "error_hash = :error_hash, "
            "vector_id = :vector_id, "
            "metadata_mode = :metadata_mode, "
            "storage_tier = :storage_tier, "
            "archive_only_after = :archive_only_after, "
            "created_date = if_not_exists(created_date, :created_date), "
            "updated_date = :updated_date"
        ),
        ExpressionAttributeValues={
            ":project_name": project_name,
            ":env": env,
            ":error_hash": error_hash,
            ":vector_id": vector_id,
            ":metadata_mode": "compact",
            ":storage_tier": "hot",
            ":archive_only_after": _retention_epoch(_WARM_RETENTION_DAYS, now),
            ":created_date": _iso_utc(now),
            ":updated_date": _iso_utc(now),
        },
    )


def touch_error_signature_summary(
    project_name: str,
    env: str,
    error_hash: str,
    task_path: str = "",
    request_id: str = "",
    file_name: str = "",
    new_solution_reference: bool = False,
    hit_date: str | None = None,
):
    if not hit_date:
        hit_date = _iso_utc()

    task_path = str(task_path or "").strip()
    request_id = str(request_id or "").strip()
    file_name = str(file_name or "").strip()

    update_expression = (
        "SET project_name = :project_name, "
        "env = :env, "
        "error_hash = :error_hash, "
        "latest_task_path = :latest_task_path, "
        "latest_request_id = :latest_request_id, "
        "latest_file_name = :latest_file_name, "
        "metadata_mode = :metadata_mode, "
        "storage_tier = :storage_tier, "
        "summary_version = :summary_version, "
        "archive_only_after = :archive_only_after, "
        "first_seen_date = if_not_exists(first_seen_date, :hit_date), "
        "last_seen_date = :hit_date, "
        "updated_date = :hit_date, "
        "occurrence_count = if_not_exists(occurrence_count, :zero) + :one"
    )
    values = {
        ":project_name": project_name,
        ":env": env,
        ":error_hash": error_hash,
        ":latest_task_path": task_path,
        ":latest_request_id": request_id,
        ":latest_file_name": file_name,
        ":metadata_mode": "compact",
        ":storage_tier": "hot",
        ":summary_version": 1,
        ":archive_only_after": _retention_epoch(_ARCHIVE_RETENTION_DAYS),
        ":hit_date": hit_date,
        ":zero": 0,
        ":one": 1,
    }
    if new_solution_reference:
        update_expression += ", unique_solution_count = if_not_exists(unique_solution_count, :zero) + :one"

    logger.debug(
        "DynamoDB UPDATE (signature summary) | table=%s | PK=%s | project=%s | env=%s | error_hash=%s",
        ai_assisted_data_table.name, _error_pk(project_name, env, error_hash), project_name, env, error_hash,
    )
    ai_assisted_data_table.update_item(
        Key={"PK": _error_pk(project_name, env, error_hash), "SK": "SUMMARY"},
        UpdateExpression=update_expression,
        ExpressionAttributeValues=values,
    )


def save_error_solution_reference(
    project_name: str,
    env: str,
    error_hash: str,
    request_id: str,
    s3_key: str,
    file_name: str,
    task_path: str = "",
    solution_signature_hash: str = "",
):
    now = _now_utc()
    ref_token = hashlib.sha1(f"{request_id}|{s3_key}".encode("utf-8")).hexdigest()[:16]
    sk = f"SOL#{request_id}#{ref_token}"
    pk = _error_pk(project_name, env, error_hash)
    logger.debug(
        "DynamoDB PUT (solution ref) | table=%s | PK=%s | SK=%s | s3_key=%s | file_name=%s",
        ai_assisted_data_table.name, pk, sk, s3_key, file_name,
    )
    try:
        ai_assisted_data_table.put_item(
            Item={
                "PK": pk,
                "SK": sk,
                "request_id": request_id,
                "s3_key": s3_key,
                "file_name": file_name,
                "task_path": str(task_path or "").strip(),
                "solution_signature_hash": str(solution_signature_hash or "").strip(),
                "metadata_mode": "compact",
                "storage_tier": "hot",
                "archive_only_after": _retention_epoch(_WARM_RETENTION_DAYS, now),
                "expires_at": _retention_epoch(_ARCHIVE_RETENTION_DAYS, now),
                "created_date": _iso_utc(now),
            },
            ConditionExpression="attribute_not_exists(PK) AND attribute_not_exists(SK)",
        )
        return True
    except ClientError as err:
        if err.response.get("Error", {}).get("Code", "") == "ConditionalCheckFailedException":
            logger.debug("DynamoDB PUT skipped (already exists) | table=%s | PK=%s | SK=%s", ai_assisted_data_table.name, pk, sk)
            return False
        raise

def get_error_solution_references_summary_first(
    project_name: str,
    env: str,
    error_hash: str,
):
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(_error_pk(project_name, env, error_hash)) & Key("SK").begins_with("SOL#"),
        )
        items = []
        for item in res.get("Items", []):
            tier = classify_storage_tier(item)
            if tier == "expired":
                continue
            item["effective_storage_tier"] = tier
            items.append(item)
        items.sort(
            key=lambda row: (
                0 if str(row.get("effective_storage_tier") or "") == "hot" else 1,
                -int(bool(row.get("task_path"))),
                str(row.get("created_date") or ""),
            ),
            reverse=True,
        )
        return items
    except Exception:
        return []


def save_fix_instance(
    request_id: str,
    change_id: str,
    project_name: str,
    env: str,
    risk_side: str,
    task_path: str,
    file_name: str,
    file_path: str,
    feature_s3_key: str,
    patch_hash: str,
    change_fingerprint: str,
    config_tokens: list[str],
    created_date: str,
):
    now = _now_utc()
    sk = f"{FIX_SK}#{change_id}"
    logger.debug(
        "DynamoDB PUT | table=%s | PK=%s | SK=%s | change_id=%s | file_name=%s | file_path=%s",
        ai_assisted_data_table.name, request_id, sk, change_id, file_name, file_path,
    )
    ai_assisted_data_table.put_item(
        Item={
            "PK": request_id,
            "SK": sk,
            "request_id": request_id,
            "change_id": change_id,
            "project_name": project_name,
            "env": env,
            "risk_side": str(risk_side or "").strip(),
            "task_path": str(task_path or "").strip(),
            "file_name": str(file_name or "").strip(),
            "file_path": str(file_path or "").strip(),
            "feature_s3_key": str(feature_s3_key or "").strip(),
            "patch_hash": str(patch_hash or "").strip(),
            "change_fingerprint": str(change_fingerprint or "").strip(),
            "config_tokens": list(config_tokens or []),
            "metadata_mode": "compact",
            "storage_tier": "hot",
            "archive_only_after": _retention_epoch(_WARM_RETENTION_DAYS, now),
            "expires_at": _retention_epoch(_ARCHIVE_RETENTION_DAYS, now),
            "created_date": created_date,
        },
        ConditionExpression="attribute_not_exists(PK) AND attribute_not_exists(SK)",
    )


def get_fix_instances(request_id: str):
    logger.debug("DynamoDB QUERY | table=%s | PK=%s | SK begins_with=%s#", ai_assisted_data_table.name, request_id, FIX_SK)
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(request_id) & Key("SK").begins_with(f"{FIX_SK}#"),
        )
        items = res.get("Items", [])
        now_epoch = _epoch_utc()
        out = []
        for item in items:
            expires_at = int(item.get("expires_at", 0) or 0)
            if expires_at and expires_at <= now_epoch:
                continue
            out.append(item)
        logger.debug("DynamoDB QUERY | table=%s | PK=%s | fix_instances_count=%d", ai_assisted_data_table.name, request_id, len(out))
        return out
    except Exception:
        logger.warning("DynamoDB QUERY failed | table=%s | PK=%s", ai_assisted_data_table.name, request_id)
        return []


def save_recommendation_outcome(
    request_id: str,
    project_name: str = "",
    recommended: bool = True,
    outcome_type: str = "shown",
    source: str = "",
    match_status: str = "",
    confidence_score: float | int = 0.0,
    query_signature_hashes: list[str] | None = None,
    hit_date: str | None = None,
    is_helpful: bool | None = None,
    feedback_token: str = "",
    adapter_enabled: bool | None = None,
):
    if not request_id:
        return None
    if not hit_date:
        hit_date = _iso_utc()

    project_name = str(project_name or "").strip().lower()
    outcome_type = str(outcome_type or "shown").strip().lower() or "shown"
    source = str(source or "").strip()
    match_status = str(match_status or "").strip().lower()
    hashes = [str(x).strip().lower() for x in (query_signature_hashes or []) if str(x).strip()]
    event_id = str(uuid.uuid4())
    retention_days = (
        _RECOMMEND_SUCCESS_RETENTION_DAYS
        if outcome_type in ("success_correlated", "user_feedback")
        else _RECOMMEND_SHOWN_RETENTION_DAYS
    )

    logger.debug(
        "DynamoDB PUT (recommendation outcome) | table=%s | request_id=%s | outcome_type=%s | source=%s | match_status=%s",
        ai_assisted_data_table.name, request_id, outcome_type, source, match_status,
    )
    # user_feedback uses feedback_token (unique per error-report call) in SK so:
    #   - same build occurrence, click 👍 twice → same token → overwrites → count 1
    #   - different build occurrence, click 👍 both → different token → new record → count 2
    if outcome_type == "user_feedback":
        token_key = str(feedback_token or "").strip() or (hashes[0] if hashes else event_id)
        sk = f"FEEDBACK#{token_key}"
    else:
        sk = f"RECOMMEND#{hit_date}#{event_id}"

    item: dict = {
        "PK": request_id,
        "SK": sk,
        "request_id": request_id,
        "project_name": project_name,
        "recommended": bool(recommended),
        "outcome_type": outcome_type,
        "source": source,
        "match_status": match_status,
        "confidence_score": _to_decimal(confidence_score or 0.0),
        "query_signature_hashes": hashes,
        "metadata_mode": "compact",
        "storage_tier": "hot" if outcome_type in ("success_correlated", "user_feedback") else "warm",
        "expires_at": _retention_epoch(retention_days),
        "created_date": hit_date,
        "updated_date": hit_date,
    }
    if is_helpful is not None:
        item["is_helpful"] = bool(is_helpful)
    # A measurable impact number for the feedback
    # loop — record whether the W adapter was ACTIVE for this project at event time, so the
    # dashboard can compare the helpful-rate with the adapter on vs off.
    if adapter_enabled is not None:
        item["adapter_enabled"] = bool(adapter_enabled)
    ai_assisted_data_table.put_item(Item=item)

    ai_assisted_data_table.update_item(
        Key={"PK": request_id, "SK": RECOMMEND_SUMMARY_SK},
        UpdateExpression=(
            "SET project_name = :project_name, "
            "recommended = :recommended, "
            "last_outcome_type = :last_outcome_type, "
            "last_source = :last_source, "
            "last_match_status = :last_match_status, "
            "last_confidence_score = :last_confidence_score, "
            "last_query_signature_hashes = :last_query_signature_hashes, "
            "metadata_mode = :metadata_mode, "
            "storage_tier = :storage_tier, "
            "archive_only_after = :archive_only_after, "
            "last_hit_date = :last_hit_date, "
            "updated_date = :updated_date "
            "ADD hit_count :one"
        ),
        ExpressionAttributeValues={
            ":project_name": project_name,
            ":recommended": bool(recommended),
            ":last_outcome_type": outcome_type,
            ":last_source": source,
            ":last_match_status": match_status,
            ":last_confidence_score": _to_decimal(confidence_score or 0.0),
            ":last_query_signature_hashes": hashes,
            ":metadata_mode": "compact",
            ":storage_tier": "hot" if outcome_type == "success_correlated" else "warm",
            ":archive_only_after": _retention_epoch(_ARCHIVE_RETENTION_DAYS),
            ":last_hit_date": hit_date,
            ":updated_date": hit_date,
            ":one": 1,
        },
    )

    return {
        "request_id": request_id,
        "project_name": project_name,
        "outcome_type": outcome_type,
        "source": source,
        "match_status": match_status,
        "confidence_score": float(confidence_score or 0.0),
        "query_signature_hashes": hashes,
        "created_date": hit_date,
    }


def save_token_usage(
    project_name: str,
    request_id: str = "",
    related_request_ids: list[str] | None = None,
    prompt_tokens: int = 0,
    output_tokens: int = 0,
    total_tokens: int = 0,
    operation_type: str = "recommendation",
    timestamp: str | None = None,
):
    """
    Save token usage data for tracking LLM API consumption by project.
    
    Args:
        project_name: Name of the project
        request_id: Optional request ID for correlation
        prompt_tokens: Number of input/prompt tokens used
        output_tokens: Number of output/completion tokens used
        total_tokens: Total tokens used
        operation_type: Type of operation (recommendation, analysis, etc.)
        timestamp: ISO timestamp (auto-generated if not provided)
    """
    if not project_name:
        return None
    
    project_name = str(project_name or "").strip().lower()
    if not timestamp:
        timestamp = _iso_utc()
    
    event_id = str(uuid.uuid4())
    sk = f"TOKEN_USAGE#{timestamp}#{event_id}"
    
    item = {
        "PK": f"PROJECT#{project_name}",
        "SK": sk,
        "project_name": project_name,
        "request_id": str(request_id or "").strip(),
        "prompt_tokens": int(prompt_tokens or 0),
        "output_tokens": int(output_tokens or 0),
        "total_tokens": int(total_tokens or 0),
        "operation_type": str(operation_type or "recommendation").strip().lower(),
        "created_date": timestamp,
        "updated_date": timestamp,
        "metadata_mode": "compact",
        "storage_tier": "warm",
        "expires_at": _retention_epoch(_RECOMMEND_SHOWN_RETENTION_DAYS),  # 180 days retention
    }
    
    try:
        ai_assisted_data_table.put_item(Item=item)
        related_ids = {
            str(value or "").strip()
            for value in [request_id, *(related_request_ids or [])]
            if str(value or "").strip()
        }
        for related_id in related_ids:
            try:
                ai_assisted_data_table.put_item(Item={
                    "PK": related_id,
                    "SK": f"TOKEN_USAGE#{timestamp}#{event_id}",
                    "request_id": related_id,
                    "project_name": project_name,
                    "prompt_tokens": int(prompt_tokens or 0),
                    "output_tokens": int(output_tokens or 0),
                    "total_tokens": int(total_tokens or 0),
                    "operation_type": str(operation_type or "recommendation").strip().lower(),
                    "created_date": timestamp,
                    "expires_at": item["expires_at"],
                    "usage_event_id": event_id,
                })
            except Exception as e:
                logger.warning("Failed to index token usage | request=%s | error=%s", related_id, str(e))
        logger.debug(
            "DynamoDB PUT (token usage) | table=%s | project=%s | total_tokens=%d | operation=%s",
            ai_assisted_data_table.name, project_name, total_tokens, operation_type,
        )
        return {
            "project_name": project_name,
            "prompt_tokens": prompt_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "operation_type": operation_type,
            "created_date": timestamp,
        }
    except Exception as e:
        logger.warning("Failed to save token usage | project=%s | error=%s", project_name, str(e))
        return None


def get_token_usage_by_project(
    project_name: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    operation_type: str | None = None,
) -> dict:
    """
    Retrieve token usage statistics aggregated by project.
    
    Args:
        project_name: Optional specific project name to filter (returns all projects if None)
        start_date: Optional ISO timestamp for start of range
        end_date: Optional ISO timestamp for end of range
        operation_type: Optional operation type filter (recommendation, analysis, etc.)
    
    Returns:
        Dictionary with aggregated token usage statistics per project
    """
    try:
        results = {}
        
        if project_name:
            # Query specific project
            project_name = str(project_name).strip().lower()
            pk = f"PROJECT#{project_name}"
            
            query_kwargs = {
                "KeyConditionExpression": Key("PK").eq(pk) & Key("SK").begins_with("TOKEN_USAGE#"),
            }
            
            response = ai_assisted_data_table.query(**query_kwargs)
            items = response.get("Items", [])
            
            # Handle pagination
            while response.get("LastEvaluatedKey"):
                query_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
                response = ai_assisted_data_table.query(**query_kwargs)
                items.extend(response.get("Items", []))
            
            results[project_name] = _aggregate_token_usage(items, start_date, end_date, operation_type)
        else:
            # Scan all projects
            scan_kwargs = {
                "FilterExpression": Attr("SK").begins_with("TOKEN_USAGE#"),
            }
            
            response = ai_assisted_data_table.scan(**scan_kwargs)
            items = response.get("Items", [])
            
            # Handle pagination
            while response.get("LastEvaluatedKey"):
                scan_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
                response = ai_assisted_data_table.scan(**scan_kwargs)
                items.extend(response.get("Items", []))
            
            # Group by project
            by_project = {}
            for item in items:
                proj = str(item.get("project_name") or "").strip().lower()
                if proj:
                    if proj not in by_project:
                        by_project[proj] = []
                    by_project[proj].append(item)
            
            # Aggregate each project
            for proj, proj_items in by_project.items():
                results[proj] = _aggregate_token_usage(proj_items, start_date, end_date, operation_type)
        
        # Calculate totals
        total_prompt = sum(p.get("total_prompt_tokens", 0) for p in results.values())
        total_output = sum(p.get("total_output_tokens", 0) for p in results.values())
        total_all = sum(p.get("total_tokens", 0) for p in results.values())
        total_requests = sum(p.get("request_count", 0) for p in results.values())
        
        return {
            "success": True,
            "projects": results,
            "summary": {
                "total_projects": len(results),
                "total_prompt_tokens": total_prompt,
                "total_output_tokens": total_output,
                "total_tokens": total_all,
                "total_requests": total_requests,
            },
            "filters": {
                "project_name": project_name,
                "start_date": start_date,
                "end_date": end_date,
                "operation_type": operation_type,
            },
        }
    except Exception as e:
        logger.exception("Failed to get token usage by project")
        return {
            "success": False,
            "error": str(e),
            "projects": {},
            "summary": {},
        }


def _aggregate_token_usage(
    items: list[dict],
    start_date: str | None = None,
    end_date: str | None = None,
    operation_type: str | None = None,
) -> dict:
    """Helper function to aggregate token usage from a list of items."""
    filtered_items = []
    
    for item in items:
        # Filter by date range
        if start_date:
            item_date = str(item.get("created_date") or "")
            if item_date < start_date:
                continue
        if end_date:
            item_date = str(item.get("created_date") or "")
            if item_date > end_date:
                continue
        
        # Filter by operation type
        if operation_type:
            item_op_type = str(item.get("operation_type") or "").strip().lower()
            if item_op_type != operation_type.strip().lower():
                continue
        
        filtered_items.append(item)
    
    # Aggregate
    total_prompt = sum(int(item.get("prompt_tokens") or 0) for item in filtered_items)
    total_output = sum(int(item.get("output_tokens") or 0) for item in filtered_items)
    total_tokens = sum(int(item.get("total_tokens") or 0) for item in filtered_items)
    
    # Group by operation type
    by_operation = {}
    for item in filtered_items:
        op_type = str(item.get("operation_type") or "recommendation").strip().lower()
        if op_type not in by_operation:
            by_operation[op_type] = {
                "count": 0,
                "prompt_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
            }
        by_operation[op_type]["count"] += 1
        by_operation[op_type]["prompt_tokens"] += int(item.get("prompt_tokens") or 0)
        by_operation[op_type]["output_tokens"] += int(item.get("output_tokens") or 0)
        by_operation[op_type]["total_tokens"] += int(item.get("total_tokens") or 0)
    
    return {
        "request_count": len(filtered_items),
        "total_prompt_tokens": total_prompt,
        "total_output_tokens": total_output,
        "total_tokens": total_tokens,
        "average_tokens_per_request": int(total_tokens / len(filtered_items)) if filtered_items else 0,
        "by_operation_type": by_operation,
    }


def get_token_usage_map_for_project(project_name: str, operation_type: str = "recommendation") -> dict:
    """request_id -> aggregated LLM token usage for ONE project (single query, TOKEN_USAGE# rows).

    Dashboard solution lists join this on each row's request_id so every recommendation shows the
    tokens ITS generation used — the same way each artifact shows its summary token_usage. A
    request regenerated N times has N stored events; they are summed and llm_calls counts them.
    Rows without a request_id can't be tied to a dashboard row and are skipped (they still count
    in the per-project totals from get_token_usage_by_project)."""
    project = str(project_name or "").strip().lower()
    if not project:
        return {}
    try:
        query_kwargs = {
            "KeyConditionExpression": Key("PK").eq(f"PROJECT#{project}") & Key("SK").begins_with("TOKEN_USAGE#"),
        }
        response = ai_assisted_data_table.query(**query_kwargs)
        items = response.get("Items", [])
        while response.get("LastEvaluatedKey"):
            query_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
            response = ai_assisted_data_table.query(**query_kwargs)
            items.extend(response.get("Items", []))
    except Exception as e:
        logger.warning("Failed to build token usage map | project=%s | error=%s", project, str(e))
        return {}

    op_filter = str(operation_type or "").strip().lower()
    usage_map: dict = {}
    for item in items:
        if op_filter and str(item.get("operation_type") or "").strip().lower() != op_filter:
            continue
        request_id = str(item.get("request_id") or "").strip()
        if not request_id:
            continue
        entry = usage_map.setdefault(request_id, {
            "prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0, "llm_calls": 0,
        })
        entry["prompt_tokens"] += int(item.get("prompt_tokens") or 0)
        entry["output_tokens"] += int(item.get("output_tokens") or 0)
        entry["total_tokens"] += int(item.get("total_tokens") or 0)
        entry["llm_calls"] += 1
    return usage_map


def get_token_usage_for_request(request_id: str, operation_type: str = "recommendation") -> dict:
    """Aggregate indexed token usage for one request, independent of project lookup."""
    request_key = str(request_id or "").strip()
    usage = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0, "llm_calls": 0}
    if not request_key:
        return usage
    try:
        query_kwargs = {
            "KeyConditionExpression": Key("PK").eq(request_key) & Key("SK").begins_with("TOKEN_USAGE#"),
        }
        response = ai_assisted_data_table.query(**query_kwargs)
        items = response.get("Items", [])
        while response.get("LastEvaluatedKey"):
            query_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
            response = ai_assisted_data_table.query(**query_kwargs)
            items.extend(response.get("Items", []))
    except Exception as e:
        logger.warning("Failed to get token usage for request=%s | error=%s", request_key, str(e))
        return usage

    op_filter = str(operation_type or "").strip().lower()
    for item in items:
        if op_filter and str(item.get("operation_type") or "").strip().lower() != op_filter:
            continue
        usage["prompt_tokens"] += int(item.get("prompt_tokens") or 0)
        usage["output_tokens"] += int(item.get("output_tokens") or 0)
        usage["total_tokens"] += int(item.get("total_tokens") or 0)
        usage["llm_calls"] += 1
    return usage


def save_active_recommendation_context(
    project_name: str,
    actor_id: str = "global",
    client_id: str = "global",
    workspace_id: str = "",
    request_ids: list[str] | None = None,
    primary_request_id: str = "",
    shown_at: str | None = None,
):
    if not shown_at:
        shown_at = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    req_ids = [str(x).strip() for x in (request_ids or []) if str(x).strip()]
    primary_request_id = str(primary_request_id or "").strip()
    safe_workspace_id = str(workspace_id or "").strip()

    update_expr = (
        "SET last_recommended_request_ids = :last_recommended_request_ids, "
        "last_recommended_request_id = :last_recommended_request_id, "
        "last_recommendation_shown_at = :last_recommendation_shown_at, "
        "updated_date = :updated_date"
    )
    values = {
        ":last_recommended_request_ids": req_ids,
        ":last_recommended_request_id": primary_request_id,
        ":last_recommendation_shown_at": shown_at,
        ":updated_date": shown_at,
    }

    ai_assisted_data_table.update_item(
        Key={"PK": _mcp_error_session_pk(project_name, actor_id, client_id), "SK": MCP_ERROR_SESSION_SK},
        UpdateExpression=update_expr,
        ExpressionAttributeValues=values,
    )

    if safe_workspace_id:
        ai_assisted_data_table.update_item(
            Key={"PK": _mcp_error_context_pk(project_name, actor_id, client_id, safe_workspace_id), "SK": MCP_ERROR_CONTEXT_SK},
            UpdateExpression=update_expr,
            ExpressionAttributeValues=values,
        )

    ai_assisted_data_table.update_item(
        Key={"PK": _mcp_actor_pk(actor_id), "SK": MCP_ERROR_LAST_SK},
        UpdateExpression=update_expr,
        ExpressionAttributeValues=values,
    )


def get_recommendation_outcome_summary(request_id: str):
    if not request_id:
        return None
    try:
        res = ai_assisted_data_table.get_item(
            Key={"PK": request_id, "SK": RECOMMEND_SUMMARY_SK}
        )
        item = res.get("Item")
        return item if isinstance(item, dict) else None
    except Exception:
        return None


def list_recommendation_outcomes(request_id: str):
    if not request_id:
        return []
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(request_id) & Key("SK").begins_with("RECOMMEND#"),
        )
        items = res.get("Items", [])
        now_epoch = _epoch_utc()
        out = []
        for x in items:
            if str(x.get("SK") or "") == RECOMMEND_SUMMARY_SK:
                continue
            expires_at = int(x.get("expires_at", 0) or 0)
            if expires_at and expires_at <= now_epoch:
                continue
            out.append(x)
        return out
    except Exception:
        return []


def list_all_recommendation_feedback():
    """ALL user Helpful/Not-helpful votes across requests (adapter-impact aggregation).
    Paginated scan filtered to FEEDBACK# rows; expired votes skipped; fail-open []."""
    try:
        from boto3.dynamodb.conditions import Attr
        items = []
        kwargs = {"FilterExpression": Attr("SK").begins_with("FEEDBACK#")}
        while True:
            res = ai_assisted_data_table.scan(**kwargs)
            items.extend(res.get("Items", []))
            last = res.get("LastEvaluatedKey")
            if not last:
                break
            kwargs["ExclusiveStartKey"] = last
        now_epoch = _epoch_utc()
        return [x for x in items
                if not (int(x.get("expires_at", 0) or 0) and int(x.get("expires_at", 0) or 0) <= now_epoch)]
    except Exception:
        logger.exception("list_all_recommendation_feedback failed - returning []")
        return []


def list_recommendation_feedback(request_id: str):
    """Return the user Helpful/Not-helpful votes for a recommendation.

    Votes are stored with SK 'FEEDBACK#<token>', while list_recommendation_outcomes only
    queries 'RECOMMEND#...' - so it does NOT return votes. This fetches them explicitly so
    the per-solution thumbs_up/thumbs_down counts (and the error->solution link) can be built.
    """
    if not request_id:
        return []
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(request_id) & Key("SK").begins_with("FEEDBACK#"),
        )
        now_epoch = _epoch_utc()
        out = []
        for x in res.get("Items", []):
            expires_at = int(x.get("expires_at", 0) or 0)
            if expires_at and expires_at <= now_epoch:
                continue
            out.append(x)
        return out
    except Exception:
        return []


def compact_recommendation_outcomes(
    max_age_days_shown: int = _RECOMMEND_SHOWN_RETENTION_DAYS,
    max_age_days_success: int = _RECOMMEND_SUCCESS_RETENTION_DAYS,
):
    now = _now_utc()
    scan_kwargs = {
        "FilterExpression": Attr("SK").begins_with("RECOMMEND#") & Attr("SK").ne(RECOMMEND_SUMMARY_SK),
    }
    scanned = 0
    downgraded = 0
    deleted = 0

    while True:
        res = ai_assisted_data_table.scan(**scan_kwargs)
        items = res.get("Items", [])
        scanned += len(items)

        for item in items:
            pk = str(item.get("PK") or "").strip()
            sk = str(item.get("SK") or "").strip()
            if not pk or not sk:
                continue
            outcome_type = str(item.get("outcome_type") or "shown").strip().lower()
            created_date = str(item.get("created_date") or "").strip()
            age_days = _days_since(created_date, now=now)
            retention_days = max_age_days_success if outcome_type == "success_correlated" else max_age_days_shown
            next_tier = "hot" if outcome_type == "success_correlated" and age_days <= 30 else "warm"

            if age_days > retention_days:
                ai_assisted_data_table.delete_item(Key={"PK": pk, "SK": sk})
                deleted += 1
                continue

            current_tier = str(item.get("storage_tier") or "").strip().lower()
            if current_tier != next_tier:
                ai_assisted_data_table.update_item(
                    Key={"PK": pk, "SK": sk},
                    UpdateExpression="SET storage_tier = :storage_tier, updated_date = :updated_date",
                    ExpressionAttributeValues={
                        ":storage_tier": next_tier,
                        ":updated_date": _iso_utc(now),
                    },
                )
                downgraded += 1

        lek = res.get("LastEvaluatedKey")
        if not lek:
            break
        scan_kwargs["ExclusiveStartKey"] = lek

    return {
        "scanned": scanned,
        "downgraded": downgraded,
        "deleted": deleted,
        "run_at": _iso_utc(now),
    }


def compact_request_metadata(
    fix_retention_days: int = _ARCHIVE_RETENTION_DAYS,
    vector_retention_days: int = _ARCHIVE_RETENTION_DAYS,
    warm_after_days: int = _WARM_RETENTION_DAYS,
):
    now = _now_utc()
    scan_kwargs = {
        "FilterExpression": Attr("SK").begins_with(f"{FIX_SK}#") | Attr("SK").begins_with(f"{VECTOR_SK}#"),
    }
    scanned = 0
    downgraded = 0
    deleted = 0

    while True:
        res = ai_assisted_data_table.scan(**scan_kwargs)
        items = res.get("Items", [])
        scanned += len(items)

        for item in items:
            pk = str(item.get("PK") or "").strip()
            sk = str(item.get("SK") or "").strip()
            if not pk or not sk:
                continue
            created_date = str(item.get("created_date") or "").strip()
            age_days = _days_since(created_date, now=now)
            retention_days = fix_retention_days if sk.startswith(f"{FIX_SK}#") else vector_retention_days
            next_tier = "hot" if age_days <= warm_after_days else "warm"

            if age_days > retention_days:
                ai_assisted_data_table.delete_item(Key={"PK": pk, "SK": sk})
                deleted += 1
                continue

            current_tier = str(item.get("storage_tier") or "").strip().lower()
            if current_tier != next_tier:
                ai_assisted_data_table.update_item(
                    Key={"PK": pk, "SK": sk},
                    UpdateExpression="SET storage_tier = :storage_tier, updated_date = :updated_date",
                    ExpressionAttributeValues={
                        ":storage_tier": next_tier,
                        ":updated_date": _iso_utc(now),
                    },
                )
                downgraded += 1

        lek = res.get("LastEvaluatedKey")
        if not lek:
            break
        scan_kwargs["ExclusiveStartKey"] = lek

    return {
        "scanned": scanned,
        "downgraded": downgraded,
        "deleted": deleted,
        "run_at": _iso_utc(now),
    }


def get_storage_health_summary():
    scan_kwargs = {
        "FilterExpression": (
            Attr("metadata_mode").eq("compact")
            | Attr("SK").eq("SUMMARY")
            | Attr("SK").eq(RECOMMEND_SUMMARY_SK)
        ),
    }
    counts = {
        "hot": 0,
        "warm": 0,
        "archive-only": 0,
        "expired": 0,
        "unknown": 0,
    }
    by_prefix: dict[str, int] = {}
    scanned = 0

    while True:
        res = ai_assisted_data_table.scan(**scan_kwargs)
        items = res.get("Items", [])
        scanned += len(items)

        for item in items:
            tier = classify_storage_tier(item)
            counts[tier] = counts.get(tier, 0) + 1
            sk = str(item.get("SK") or "").strip()
            prefix = sk.split("#", 1)[0] if sk else "UNKNOWN"
            by_prefix[prefix] = int(by_prefix.get(prefix) or 0) + 1

        lek = res.get("LastEvaluatedKey")
        if not lek:
            break
        scan_kwargs["ExclusiveStartKey"] = lek

    return {
        "scanned": scanned,
        "tiers": counts,
        "by_prefix": by_prefix,
        "run_at": _iso_utc(),
    }


def save_maintenance_run_result(name: str, payload: dict):
    if not isinstance(payload, dict):
        payload = {}
    now = _now_utc()
    run_at = _iso_utc(now)
    pk = _maintenance_pk(name)
    run_id = str(uuid.uuid4())
    logger.debug("DynamoDB PUT (maintenance run) | table=%s | name=%s | run_at=%s", ai_assisted_data_table.name, name, run_at)
    item = {
        "PK": pk,
        "SK": f"{MAINTENANCE_RUN_SK}#{run_at}#{run_id}",
        "name": (name or "default").strip().lower() or "default",
        "result_json": json.dumps(payload, separators=(",", ":")),
        "created_date": run_at,
    }
    ai_assisted_data_table.put_item(Item=item)
    ai_assisted_data_table.put_item(
        Item={
            "PK": pk,
            "SK": MAINTENANCE_LATEST_SK,
            "name": (name or "default").strip().lower() or "default",
            "result_json": json.dumps(payload, separators=(",", ":")),
            "created_date": run_at,
            "updated_date": run_at,
        }
    )
    return {"name": item["name"], "run_at": run_at}


def get_latest_maintenance_run_result(name: str):
    try:
        res = ai_assisted_data_table.get_item(
            Key={"PK": _maintenance_pk(name), "SK": MAINTENANCE_LATEST_SK}
        )
        item = res.get("Item")
        if not isinstance(item, dict):
            return None
        raw = item.get("result_json")
        payload = {}
        if isinstance(raw, str):
            try:
                payload = json.loads(raw)
            except Exception:
                payload = {}
        return {
            "name": item.get("name"),
            "updated_date": item.get("updated_date") or item.get("created_date"),
            "result": payload,
        }
    except Exception:
        return None



def create_vectorization_status(request_id: str, status: str = "queued") -> bool:
    logger.debug("DynamoDB PUT (vectorization status) | table=%s | request_id=%s | status=%s", ai_assisted_data_table.name, request_id, status)
    now = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        ai_assisted_data_table.put_item(
            Item={
                "PK": request_id,
                "SK": VECTORIZE_SK,
                "request_id": request_id,
                "status": status,
                "vector_count": 0,
                "last_error": "",
                "created_date": now,
                "updated_date": now,
            },
            ConditionExpression="attribute_not_exists(PK) AND attribute_not_exists(SK)",
        )
        return True
    except ClientError as err:
        if err.response.get("Error", {}).get("Code", "") == "ConditionalCheckFailedException":
            logger.warning("DynamoDB PUT skipped (already exists) | table=%s | request_id=%s | vectorization status", ai_assisted_data_table.name, request_id)
            return False
        raise


def update_vectorization_status(
    request_id: str,
    status: str,
    vector_count: int | None = None,
    last_error: str | None = None,
):
    logger.debug("DynamoDB UPDATE (vectorization status) | table=%s | request_id=%s | status=%s | vector_count=%s | last_error=%s", ai_assisted_data_table.name, request_id, status, vector_count, last_error)
    expr = ["#st = :status", "updated_date = :updated_date"]
    vals = {
        ":status": status,
        ":updated_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    names = {"#st": "status"}

    if vector_count is not None:
        expr.append("vector_count = :vector_count")
        vals[":vector_count"] = int(vector_count)
    if last_error is not None:
        expr.append("last_error = :last_error")
        vals[":last_error"] = str(last_error)

    try:
        ai_assisted_data_table.update_item(
            Key={"PK": request_id, "SK": VECTORIZE_SK},
            UpdateExpression="SET " + ", ".join(expr),
            ExpressionAttributeValues=vals,
            ExpressionAttributeNames=names,
        )
        return
    except ClientError as err:
        if not _is_key_schema_mismatch(err):
            raise

    # Compatibility fallback when table hash key is request_id only.
    ai_assisted_data_table.update_item(
        Key={"request_id": request_id},
        UpdateExpression="SET " + ", ".join(expr),
        ExpressionAttributeValues=vals,
        ExpressionAttributeNames=names,
    )


def get_vectorization_status(request_id: str):
    logger.debug("DynamoDB GET (vectorization status) | table=%s | request_id=%s", ai_assisted_data_table.name, request_id)
    try:
        res = ai_assisted_data_table.get_item(
            Key={"PK": request_id, "SK": VECTORIZE_SK}
        )
        item = res.get("Item")
        if item and item.get("status"):
            return item
    except ClientError as err:
        if not _is_key_schema_mismatch(err):
            return None
    except Exception:
        return None

    # Compatibility fallback when table hash key is request_id only.
    try:
        res = ai_assisted_data_table.get_item(
            Key={"request_id": request_id}
        )
        item = res.get("Item")
        if item and item.get("status"):
            return item
    except Exception:
        return None
    logger.warning("DynamoDB GET | table=%s | request_id=%s | vectorization status NOT FOUND", ai_assisted_data_table.name, request_id)
    return None


def _mcp_session_pk(project_name: str, actor_id: str) -> str:
    return f"MCPSESSION#{project_name}#{actor_id}"


def _mcp_error_session_pk(project_name: str, actor_id: str, client_id: str) -> str:
    safe_client_id = (client_id or "global").strip() or "global"
    return f"MCPERRORSESSION#{project_name}#{actor_id}#{safe_client_id}"


def _mcp_error_context_pk(project_name: str, actor_id: str, client_id: str, workspace_id: str) -> str:
    safe_client_id = (client_id or "global").strip() or "global"
    safe_workspace_id = (workspace_id or "default").strip() or "default"
    return f"MCPERRORCONTEXT#{project_name}#{actor_id}#{safe_client_id}#{safe_workspace_id}"


def _mcp_actor_pk(actor_id: str) -> str:
    safe_actor_id = (actor_id or "global").strip() or "global"
    return f"MCPACTOR#{safe_actor_id}"


def _mcp_predict_session_pk(project_name: str, actor_id: str, client_id: str) -> str:
    safe_project = (project_name or "").strip().lower() or "unknown-project"
    safe_actor = (actor_id or "global").strip() or "global"
    safe_client = (client_id or "global").strip() or "global"
    return f"MCPPREDICT#{safe_project}#{safe_actor}#{safe_client}"


def _maintenance_pk(name: str = "default") -> str:
    safe_name = (name or "default").strip().lower() or "default"
    return f"MAINTENANCE#{safe_name}"


def _predict_history_pk(project_name: str) -> str:
    safe_project = (project_name or "").strip().lower() or "unknown-project"
    return f"PREDICT_HISTORY#{safe_project}"


def _predict_history_row_pk(prediction_report_id: str) -> str:
    safe_id = (prediction_report_id or "").strip() or "unknown-report"
    return f"PREDICT_REPORT#{safe_id}"


def get_active_predict_session(
    project_name: str,
    actor_id: str = "global",
    client_id: str = "global",
):
    now_epoch = int(time.time())
    try:
        res = ai_assisted_data_table.get_item(
            Key={
                "PK": _mcp_predict_session_pk(project_name, actor_id, client_id),
                "SK": MCP_PREDICT_SESSION_SK,
            }
        )
        item = res.get("Item")
        if not item:
            return None
        expires_at = int(item.get("expires_at", 0))
        if expires_at <= now_epoch:
            return None
        return item
    except Exception:
        return None


def touch_predict_session(
    project_name: str,
    prediction_session_id: str,
    scope_payload: dict,
    actor_id: str = "global",
    client_id: str = "global",
    ttl_hours: int = 24,
):
    now_epoch = int(time.time())
    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    expires_at = now_epoch + max(1, int(ttl_hours)) * 3600
    current = get_active_predict_session(project_name, actor_id, client_id) or {}
    ai_assisted_data_table.put_item(
        Item={
            "PK": _mcp_predict_session_pk(project_name, actor_id, client_id),
            "SK": MCP_PREDICT_SESSION_SK,
            "project_name": project_name,
            "actor_id": actor_id,
            "client_id": client_id,
            "prediction_session_id": prediction_session_id,
            "status": "scope_ready",
            "scope_json": json.dumps(scope_payload, separators=(",", ":")),
            # New scope must not reuse old result payload.
            "result_json": "",
            "created_date": current.get("created_date", now_iso),
            "updated_date": now_iso,
            "expires_at": expires_at,
        }
    )
    return {
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "prediction_session_id": prediction_session_id,
        "status": "scope_ready",
        "updated_date": now_iso,
        "expires_at": expires_at,
    }


def save_predict_result(
    project_name: str,
    actor_id: str,
    client_id: str,
    prediction_session_id: str,
    result_payload: dict,
    ttl_hours: int = 24,
):
    now_epoch = int(time.time())
    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    expires_at = now_epoch + max(1, int(ttl_hours)) * 3600
    current = get_active_predict_session(project_name, actor_id, client_id) or {}
    pk = _mcp_predict_session_pk(project_name, actor_id, client_id)
    logger.debug(
        "DynamoDB PUT (predict result) | table=%s | PK=%s | project=%s | prediction_session_id=%s | status=completed",
        ai_assisted_data_table.name, pk, project_name, prediction_session_id,
    )
    ai_assisted_data_table.put_item(
        Item={
            "PK": pk,
            "SK": MCP_PREDICT_SESSION_SK,
            "project_name": project_name,
            "actor_id": actor_id,
            "client_id": client_id,
            "prediction_session_id": prediction_session_id,
            "status": "completed",
            "scope_json": current.get("scope_json", ""),
            "result_json": json.dumps(result_payload, separators=(",", ":")),
            "created_date": current.get("created_date", now_iso),
            "updated_date": now_iso,
            "expires_at": expires_at,
        }
    )


def save_prediction_history_report(
    *,
    prediction_report_id: str,
    project_name: str,
    actor_id: str = "global",
    client_id: str = "global",
    developer_id: str = "",
    request_id: str = "",
    report_payload: dict,
    created_date: str | None = None,
    report_kind: str = "",
):
    report_id = str(prediction_report_id or "").strip()
    project = str(project_name or "").strip().lower()
    if not report_id or not project or not isinstance(report_payload, dict):
        raise ValueError("prediction_report_id, project_name and report_payload are required")

    created_at = str(created_date or _iso_utc()).strip() or _iso_utc()
    summary = report_payload.get("summary") if isinstance(report_payload.get("summary"), dict) else {}
    matches = report_payload.get("issues") if isinstance(report_payload.get("issues"), list) else []

    logger.debug(
        "DynamoDB PUT (prediction history report) | table=%s | report_id=%s | project=%s | matches_count=%d",
        ai_assisted_data_table.name, report_id, project, len(matches),
    )
    kind = str(report_kind or "").strip().lower()
    item = {
        "PK": _predict_history_pk(project),
        "SK": f"{created_at}#{report_id}",
        "prediction_report_id": report_id,
        "project_name": project,
        "actor_id": str(actor_id or "global").strip() or "global",
        "client_id": str(client_id or "global").strip() or "global",
        "developer_id": str(developer_id or "").strip(),
        "request_id": str(request_id or "").strip(),
        "report_json": json.dumps(report_payload, separators=(",", ":")),
        "summary_json": json.dumps(summary, separators=(",", ":")),
        "matches_count": len(matches),
        "created_date": created_at,
        "updated_date": created_at,
        "metadata_mode": "compact",
        "storage_tier": "hot",
    }
    if kind:
        item["report_kind"] = kind
    ai_assisted_data_table.put_item(Item=item)

    row_item = {
        "PK": _predict_history_row_pk(report_id),
        "SK": PREDICT_HISTORY_SK,
        "prediction_report_id": report_id,
        "project_name": project,
        "actor_id": str(actor_id or "global").strip() or "global",
        "client_id": str(client_id or "global").strip() or "global",
        "developer_id": str(developer_id or "").strip(),
        "request_id": str(request_id or "").strip(),
        "created_date": created_at,
        "updated_date": created_at,
        "report_json": json.dumps(report_payload, separators=(",", ":")),
        "summary_json": json.dumps(summary, separators=(",", ":")),
        "matches_count": len(matches),
        "metadata_mode": "compact",
        "storage_tier": "hot",
    }
    if kind:
        row_item["report_kind"] = kind
    ai_assisted_data_table.put_item(Item=row_item)

    return {
        "prediction_report_id": report_id,
        "project_name": project,
        "created_date": created_at,
        "matches_count": len(matches),
    }


def _parse_json_field(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    return {}


def attach_shadow_judgement(*, project_name: str, prediction_report_id: str, created_date: str, judgement: dict):
    """Store the shadow-judging result ON the report rows (additive attributes: judgement_json +
    judged_at). Both storage rows are updated so listings and by-id reads agree."""
    report_id = str(prediction_report_id or "").strip()
    project = str(project_name or "").strip().lower()
    created = str(created_date or "").strip()
    if not report_id or not project or not isinstance(judgement, dict):
        raise ValueError("project_name, prediction_report_id and judgement are required")
    payload = json.dumps(judgement, separators=(",", ":"), default=str)
    judged_at = str(judgement.get("judged_at") or _iso_utc())
    expr = "SET judgement_json = :j, judged_at = :t"
    vals = {":j": payload, ":t": judged_at}
    if created:
        ai_assisted_data_table.update_item(
            Key={"PK": _predict_history_pk(project), "SK": f"{created}#{report_id}"},
            UpdateExpression=expr, ExpressionAttributeValues=vals,
        )
    ai_assisted_data_table.update_item(
        Key={"PK": _predict_history_row_pk(report_id), "SK": PREDICT_HISTORY_SK},
        UpdateExpression=expr, ExpressionAttributeValues=vals,
    )


def _report_kind_matches(row: dict, kind: str) -> bool:
    """kind='standard' (default) hides shadow rows from the client-facing pages;
    'shadow' selects only shadow captures; 'all' returns everything."""
    if kind == "all":
        return True
    row_kind = str((row or {}).get("report_kind") or "").strip().lower()
    if kind == "shadow":
        return row_kind == "shadow"
    return row_kind != "shadow"


def list_prediction_history_reports(project_name: str, limit: int = 100, kind: str = "standard") -> list[dict]:
    project = str(project_name or "").strip().lower()
    if not project:
        return []
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(_predict_history_pk(project)),
            ScanIndexForward=False,
            Limit=max(1, int(limit)),
        )
    except Exception:
        return []

    kind = str(kind or "standard").strip().lower()
    items = []
    for row in res.get("Items", []):
        if not _report_kind_matches(row, kind):
            continue
        report = _parse_json_field(row.get("report_json"))
        average_risk_score = float(report.get("average_risk_score") or 0.0)
        items.append(
            {
                "prediction_report_id": row.get("prediction_report_id"),
                "project_name": row.get("project_name"),
                "actor_id": row.get("actor_id"),
                "client_id": row.get("client_id"),
                "developer_id": row.get("developer_id"),
                "request_id": row.get("request_id"),
                "created_date": row.get("created_date"),
                "matches_count": int(row.get("matches_count") or 0),
                "summary": _parse_json_field(row.get("summary_json")),
                "result": str(report.get("result") or "").strip(),
                "has_matches": bool(report.get("has_matches") or False),
                "matches_found": int(report.get("matches_found") or 0),
                "selected_files_count": int(report.get("selected_files_count") or 0),
                "files_scanned": int(report.get("files_scanned") or 0),
                "total_rule_files_available": int(report.get("total_rule_files_available") or 0),
                "matched_rule_files_count": int(report.get("matched_rule_files_count") or 0),
                "rules_returned_count": int(report.get("rules_returned_count") or 0),
                "scope_reduction_percent": float(report.get("scope_reduction_percent") or 0.0),
                "rules_skipped_old": int(report.get("rules_skipped_old") or 0),
                "rules_skipped_weak": int(report.get("rules_skipped_weak") or 0),
                "average_risk_score": average_risk_score,
                # Reports store the score on a 0-100 scale; only a true fraction (<= 1.0)
                # needs the x100 conversion. (Fixes the pre-existing 10000.0% display bug.)
                "average_risk_percent": round(average_risk_score * 100.0 if average_risk_score <= 1.0 else average_risk_score, 2),
                "report_kind": str(row.get("report_kind") or "standard"),
                "judged_at": str(row.get("judged_at") or "") or None,
                "judgement": _parse_json_field(row.get("judgement_json")) or None,
            }
        )
    return items


def list_prediction_history_reports_with_report(project_name: str, limit: int = 200, kind: str = "standard") -> list[dict]:
    """Like list_prediction_history_reports, but includes the PARSED report payload per row, so the
    dashboard report APIs (/prediction-reports) can compute per-card breakdowns (flagged files,
    risk bands) without a second fetch per report. Additive — the existing list function that
    /predict/history uses is untouched. Default kind='standard' hides shadow captures."""
    project = str(project_name or "").strip().lower()
    if not project:
        return []
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(_predict_history_pk(project)),
            ScanIndexForward=False,
            Limit=max(1, int(limit)),
        )
    except Exception:
        return []

    kind = str(kind or "standard").strip().lower()
    items = []
    for row in res.get("Items", []):
        if not _report_kind_matches(row, kind):
            continue
        items.append(
            {
                "prediction_report_id": row.get("prediction_report_id"),
                "project_name": row.get("project_name"),
                "created_date": row.get("created_date"),
                "matches_count": int(row.get("matches_count") or 0),
                "report": _parse_json_field(row.get("report_json")),
                "report_kind": str(row.get("report_kind") or "standard"),
                "judged_at": str(row.get("judged_at") or "") or None,
                "judgement": _parse_json_field(row.get("judgement_json")) or None,
            }
        )
    return items


def get_prediction_history_report(prediction_report_id: str):
    report_id = str(prediction_report_id or "").strip()
    if not report_id:
        return None
    try:
        res = ai_assisted_data_table.get_item(
            Key={"PK": _predict_history_row_pk(report_id), "SK": PREDICT_HISTORY_SK}
        )
    except Exception:
        return None

    item = res.get("Item")
    if not isinstance(item, dict):
        return None
    return {
        "prediction_report_id": item.get("prediction_report_id"),
        "project_name": item.get("project_name"),
        "actor_id": item.get("actor_id"),
        "client_id": item.get("client_id"),
        "developer_id": item.get("developer_id"),
        "request_id": item.get("request_id"),
        "created_date": item.get("created_date"),
        "matches_count": int(item.get("matches_count") or 0),
        "summary": _parse_json_field(item.get("summary_json")),
        "report": _parse_json_field(item.get("report_json")),
        "report_kind": str(item.get("report_kind") or "standard"),
        "judged_at": str(item.get("judged_at") or "") or None,
        "judgement": _parse_json_field(item.get("judgement_json")) or None,
    }


def get_active_copilot_session(project_name: str, actor_id: str = "global"):
    now_epoch = int(time.time())
    try:
        res = ai_assisted_data_table.get_item(
            Key={
                "PK": _mcp_session_pk(project_name, actor_id),
                "SK": MCP_SESSION_SK,
            }
        )
        item = res.get("Item")
        if not item:
            return None

        expires_at = int(item.get("expires_at", 0))
        if expires_at <= now_epoch:
            return None
        return item
    except Exception:
        return None


def touch_copilot_session(
    project_name: str,
    actor_id: str = "global",
    ttl_hours: int = 24,
):
    now_epoch = int(time.time())
    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    expires_at = now_epoch + max(1, int(ttl_hours)) * 3600

    current = get_active_copilot_session(project_name=project_name, actor_id=actor_id)
    session_id = (current or {}).get("session_id") or str(uuid.uuid4())
    pk = _mcp_session_pk(project_name, actor_id)
    logger.debug(
        "DynamoDB PUT (copilot session) | table=%s | PK=%s | project=%s | actor=%s | session_id=%s | is_new=%s",
        ai_assisted_data_table.name, pk, project_name, actor_id, session_id, current is None,
    )
    ai_assisted_data_table.put_item(
        Item={
            "PK": pk,
            "SK": MCP_SESSION_SK,
            "project_name": project_name,
            "actor_id": actor_id,
            "session_id": session_id,
            "created_date": (current or {}).get("created_date", now_iso),
            "updated_date": now_iso,
            "expires_at": expires_at,
        }
    )

    return {
        "session_id": session_id,
        "project_name": project_name,
        "actor_id": actor_id,
        "updated_date": now_iso,
        "expires_at": expires_at,
        "is_new": current is None,
    }


def get_active_copilot_error_session(
    project_name: str,
    actor_id: str = "global",
    client_id: str = "global",
):
    now_epoch = int(time.time())
    try:
        res = ai_assisted_data_table.get_item(
            Key={
                "PK": _mcp_error_session_pk(project_name, actor_id, client_id),
                "SK": MCP_ERROR_SESSION_SK,
            }
        )
        item = res.get("Item")
        if not item:
            return None

        expires_at = int(item.get("expires_at", 0))
        if expires_at <= now_epoch:
            return None
        return item
    except Exception:
        return None


def get_active_copilot_error_context(
    project_name: str,
    actor_id: str = "global",
    client_id: str = "global",
    workspace_id: str = "",
):
    safe_workspace_id = str(workspace_id or "").strip()
    if not safe_workspace_id:
        return None
    now_epoch = int(time.time())
    try:
        res = ai_assisted_data_table.get_item(
            Key={
                "PK": _mcp_error_context_pk(project_name, actor_id, client_id, safe_workspace_id),
                "SK": MCP_ERROR_CONTEXT_SK,
            }
        )
        item = res.get("Item")
        if not item:
            return None
        expires_at = int(item.get("expires_at", 0))
        if expires_at <= now_epoch:
            return None
        return item
    except Exception:
        return None


def touch_copilot_error_session(
    project_name: str,
    request_id: str,
    error_message: str,
    s3_key: str,
    error_signature: str = "",
    actor_id: str = "global",
    client_id: str = "global",
    file_path: str = "",
    task_path: str = "",
    local_patch_contexts: list[str] | None = None,
    workspace_id: str = "",
    build_context_id: str = "",
    report_version: int = 0,
    ttl_hours: int = 24,
    requested_task: str = "",
):
    now_epoch = int(time.time())
    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    expires_at = now_epoch + max(1, int(ttl_hours)) * 3600

    safe_workspace_id = str(workspace_id or "").strip()
    current = None
    if safe_workspace_id:
        current = get_active_copilot_error_context(
            project_name=project_name,
            actor_id=actor_id,
            client_id=client_id,
            workspace_id=safe_workspace_id,
        )
    if not current:
        current = get_active_copilot_error_session(
            project_name=project_name,
            actor_id=actor_id,
            client_id=client_id,
        )
    current_signature = str((current or {}).get("error_signature") or "").strip()
    incoming_signature = str(error_signature or "").strip()
    current_build_context_id = str((current or {}).get("build_context_id") or "").strip()
    incoming_build_context_id = str(build_context_id or "").strip()
    same_signature = bool(current) and current_signature and current_signature == incoming_signature
    same_build_context = (
        not incoming_build_context_id
        or not current_build_context_id
        or current_build_context_id == incoming_build_context_id
    )
    reuse_session = same_signature and same_build_context
    session_id = (current or {}).get("session_id") if reuse_session else str(uuid.uuid4())
    created_date = (current or {}).get("created_date", now_iso) if reuse_session else now_iso

    pk = _mcp_error_session_pk(project_name, actor_id, client_id)
    logger.debug(
        "DynamoDB PUT (copilot error session) | table=%s | PK=%s | project=%s | actor=%s | "
        "request_id=%s | error_signature=%.40s | is_new=%s | workspace_id=%s",
        ai_assisted_data_table.name, pk, project_name, actor_id,
        request_id, error_signature or "", current is None, safe_workspace_id,
    )
    ai_assisted_data_table.put_item(
        Item={
            "PK": pk,
            "SK": MCP_ERROR_SESSION_SK,
            "project_name": project_name,
            "actor_id": actor_id,
            "client_id": client_id,
            "session_id": session_id,
            "request_id": request_id,
            "error_message": error_message,
            "error_signature": error_signature,
            "s3_key": s3_key,
            "file_path": str(file_path or "").strip(),
            "task_path": str(task_path or "").strip(),
            # The build type, i.e. the task the USER actually ran
            # (problemsReport.requestedTasks). Held on the SESSION only - it carries a TTL and is
            # never part of the stored error or fix - so the value is not persisted
            # while the failure->success pairing can still check it.
            "requested_task": str(requested_task or "").strip(),
            "local_patch_contexts": list(local_patch_contexts or []),
            "workspace_id": str(workspace_id or "").strip(),
            "build_context_id": incoming_build_context_id,
            "report_version": int(report_version or 0),
            "created_date": created_date,
            "updated_date": now_iso,
            "expires_at": expires_at,
        }
    )

    if safe_workspace_id:
        ai_assisted_data_table.put_item(
            Item={
                "PK": _mcp_error_context_pk(project_name, actor_id, client_id, safe_workspace_id),
                "SK": MCP_ERROR_CONTEXT_SK,
                "project_name": project_name,
                "actor_id": actor_id,
                "client_id": client_id,
                "workspace_id": safe_workspace_id,
                "session_id": session_id,
                "request_id": request_id,
                "error_message": error_message,
                "error_signature": error_signature,
                "s3_key": s3_key,
                "file_path": str(file_path or "").strip(),
                "task_path": str(task_path or "").strip(),
                "requested_task": str(requested_task or "").strip(),
                "local_patch_contexts": list(local_patch_contexts or []),
                "build_context_id": incoming_build_context_id,
                "report_version": int(report_version or 0),
                "created_date": created_date,
                "updated_date": now_iso,
                "expires_at": expires_at,
            }
        )

    ai_assisted_data_table.put_item(
        Item={
            "PK": _mcp_actor_pk(actor_id),
            "SK": MCP_ERROR_LAST_SK,
            "actor_id": actor_id,
            "client_id": client_id,
            "project_name": project_name,
            "request_id": request_id,
            "error_message": error_message,
            "error_signature": error_signature,
            "s3_key": s3_key,
            "file_path": str(file_path or "").strip(),
            "task_path": str(task_path or "").strip(),
            "requested_task": str(requested_task or "").strip(),
            "local_patch_contexts": list(local_patch_contexts or []),
            "workspace_id": str(workspace_id or "").strip(),
            "build_context_id": incoming_build_context_id,
            "report_version": int(report_version or 0),
            "session_id": session_id,
            "updated_date": now_iso,
            "expires_at": expires_at,
        }
    )

    return {
        "session_id": session_id,
        "project_name": project_name,
        "actor_id": actor_id,
        "client_id": client_id,
        "request_id": request_id,
        "error_message": error_message,
        "error_signature": error_signature,
        "s3_key": s3_key,
        "workspace_id": str(workspace_id or "").strip(),
        "build_context_id": incoming_build_context_id,
        "report_version": int(report_version or 0),
        "updated_date": now_iso,
        "expires_at": expires_at,
        "is_new": not reuse_session,
    }


def get_last_copilot_error_session_for_actor(actor_id: str = "global"):
    now_epoch = int(time.time())
    try:
        res = ai_assisted_data_table.get_item(
            Key={
                "PK": _mcp_actor_pk(actor_id),
                "SK": MCP_ERROR_LAST_SK,
            }
        )
        item = res.get("Item")
        if not item:
            return None
        expires_at = int(item.get("expires_at", 0))
        if expires_at <= now_epoch:
            return None
        return item
    except Exception:
        return None


def _mcp_error_archive_index_pk(project_name: str, error_signature: str) -> str:
    safe_project = (project_name or "").strip().lower() or "unknown-project"
    safe_sig = (error_signature or "").strip().lower() or "unknown-signature"
    return f"MCPERRORARCHIVE#{safe_project}#{safe_sig}"


def get_copilot_error_archive_index(project_name: str, error_signature: str):
    if not project_name or not error_signature:
        return None
    now_epoch = int(time.time())
    try:
        res = ai_assisted_data_table.get_item(
            Key={
                "PK": _mcp_error_archive_index_pk(project_name, error_signature),
                "SK": MCP_ERROR_ARCHIVE_INDEX_SK,
            }
        )
        item = res.get("Item")
        if not item:
            return None
        expires_at = int(item.get("expires_at", 0))
        if expires_at and expires_at <= now_epoch:
            return None
        return item
    except Exception:
        return None


def save_copilot_error_archive_index(
    project_name: str,
    error_signature: str,
    s3_key: str,
    canonical_request_id: str = "",
    ttl_days: int = 180,
):
    if not project_name or not error_signature or not s3_key:
        return
    now_epoch = int(time.time())
    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    expires_at = now_epoch + max(1, int(ttl_days)) * 24 * 3600
    ai_assisted_data_table.put_item(
        Item={
            "PK": _mcp_error_archive_index_pk(project_name, error_signature),
            "SK": MCP_ERROR_ARCHIVE_INDEX_SK,
            "project_name": (project_name or "").strip().lower(),
            "error_signature": (error_signature or "").strip().lower(),
            "s3_key": s3_key,
            "canonical_request_id": canonical_request_id or "",
            "created_date": now_iso,
            "updated_date": now_iso,
            "expires_at": expires_at,
        }
    )


# -------------------------------------------------
# PROJECT
# -------------------------------------------------

def get_project_id(project_name):
    logger.debug("DynamoDB GET | table=%s | project_name=%s", project_table.name, project_name)
    res = project_table.get_item(
        Key={"project_name": project_name}
    )
    if res.get("Item"):
        logger.debug("DynamoDB GET | table=%s | project_name=%s | existing project found | id=%s", project_table.name, project_name, res["Item"]["id"])
        return res["Item"]["id"]

    project_id = str(uuid.uuid4())
    logger.debug("DynamoDB PUT | table=%s | project_name=%s | new project created | id=%s", project_table.name, project_name, project_id)
    project_table.put_item(Item={
        "id": project_id,
        "project_name": project_name,
        "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    return project_id


# -------------------------------------------------
# SOLUTION
# -------------------------------------------------

def save_solution(solution_json, complete_json, project_id, batch_id):
    for change in complete_json:
        change["snapshotBefore"] = None
        change["snapshotAfter"] = None

    solution_id = str(uuid.uuid4())
    logger.debug("DynamoDB PUT | table=%s | solution_id=%s | project_id=%s | batch_id=%s", solution_table.name, solution_id, project_id, batch_id)
    solution_table.put_item(Item={
        "id": solution_id,
        "project_id": project_id,
        "batch_id": batch_id,  # ✅ NEW
        "solution_json": solution_json,
        "complete_json": json.dumps(complete_json),
        "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    return solution_id


# -------------------------------------------------
# ERROR LOG
# -------------------------------------------------

def save_error_log(error_message, process, developer_id,
                   project_id, solution_id=None,
                   created_by=None, vector_id=None):

    error_id = str(uuid.uuid4())
    logger.debug("DynamoDB PUT | table=%s | error_id=%s | project_id=%s | developer_id=%s", error_log_table.name, error_id, project_id, developer_id)
    error_log_table.put_item(Item={
        "id": error_id,
        "vector_id": vector_id,
        "error_message": error_message,
        "process": process,
        "developer_id": developer_id,
        "project_id": project_id,
        "solution_id": solution_id,
        "recommended_count": 0,
        "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    return error_id


def save_error_logs_bulk(items):
    """
    Batch write error logs to reduce round trips and blocking time.
    """
    if not items:
        logger.warning("DynamoDB BATCH WRITE | table=%s | items EMPTY, skipping", error_log_table.name)
        return

    logger.debug("DynamoDB BATCH WRITE | table=%s | count=%d", error_log_table.name, len(items))
    with error_log_table.batch_writer() as batch:
        for item in items:
            batch.put_item(Item={
                "id": str(uuid.uuid4()),
                "vector_id": item.get("vector_id"),
                "error_message": item.get("error_message"),
                "process": item.get("process"),
                "developer_id": item.get("developer_id"),
                "project_id": item.get("project_id"),
                "solution_id": item.get("solution_id"),
                "recommended_count": 0,
                "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })

def save_binary_metadata(
    batch_id,
    file_name,
    file_path,
    action,
    stored_path,
    s3_key=None,
    payload_sha256=None,
    zip_sha256=None,
    payload_size=None,
    compressed_size=None,
    artifact_group=None,
    task_path=None,
    source_folder=None,
    project_name=None,
):
    binary_id = str(uuid.uuid4())
    logger.debug(
        "DynamoDB PUT | table=%s | binary_id=%s | batch_id=%s | file_name=%s | action=%s | s3_key=%s",
        binary_files_table.name, binary_id, batch_id, file_name, action, s3_key,
    )
    binary_files_table.put_item(
        Item={
            "binary_id": binary_id,
            "batch_id": batch_id,
            "file_name": file_name,
            "original_file_path": file_path,
            "action": action,
            "stored_path": stored_path,
            "s3_key": s3_key,
            "payload_sha256": payload_sha256,
            "zip_sha256": zip_sha256,
            "payload_size": payload_size,
            "compressed_size": compressed_size,
            "artifact_group": artifact_group,
            "task_path": task_path,
            "source_folder": source_folder,
            "project_name": project_name,
            "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    )


def get_artifacts_by_batch_id(batch_id: str) -> list:
    if not batch_id:
        return []
    try:
        res = binary_files_table.scan(
            FilterExpression=Attr("batch_id").eq(batch_id),
            ProjectionExpression="s3_key, file_name"
        )
        return res.get("Items", [])
    except Exception:
        return []


def list_binary_metadata_by_batch_id(batch_id: str) -> list[dict]:
    if not batch_id:
        return []
    try:
        return _scan_all(binary_files_table, filter_expression=Attr("batch_id").eq(batch_id))
    except Exception:
        return []


def delete_binary_metadata_by_batch_id(batch_id: str) -> int:
    return delete_table_items(binary_files_table, list_binary_metadata_by_batch_id(batch_id))


def save_artifact_reference(
    request_id: str,
    file_name: str,
    s3_key: str,
    s3_bucket: str,
    artifact_type: str,
    content_fingerprint: str = "",
    evidence_eligible: bool = True,
):
    """Store a binary or runtime artifact reference keyed by request_id.

    With a content_fingerprint the sort key includes a fingerprint suffix, so a re-upload
    of the same file NAME with different content ADDS a new reference row instead of
    overwriting the previous one (storage proposal: never overwrite, keep history).
    Readers use begins_with(prefix#) queries and see all versions. Without a fingerprint
    (legacy callers) the old overwrite-by-name behavior is kept unchanged.
    """
    if not request_id or not s3_key:
        return
    sk_prefix = BINARY_SK if artifact_type == "binary" else RUNTIME_SK
    safe_name = (file_name or "").strip() or s3_key.split("/")[-1]
    fingerprint = str(content_fingerprint or "").strip()
    sk = f"{sk_prefix}#{safe_name}#{fingerprint[:12]}" if fingerprint else f"{sk_prefix}#{safe_name}"
    logger.debug(
        "DynamoDB PUT (artifact ref) | table=%s | PK=%s | SK=%s | s3_key=%s | artifact_type=%s",
        ai_assisted_data_table.name, request_id, sk, s3_key, artifact_type,
    )
    item = {
        "PK": request_id,
        "SK": sk,
        "request_id": request_id,
        "file_name": safe_name,
        "s3_key": s3_key,
        "s3_bucket": s3_bucket,
        "artifact_type": artifact_type,
        "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    if fingerprint:
        item["content_fingerprint"] = fingerprint
    # Ingest gate: the file is ALWAYS stored - we never drop a developer's data - but a
    # log proven to be about a DIFFERENT stored fix is marked so it can never serve as evidence
    # for this one. Absent attribute = eligible, so every existing row keeps its meaning.
    if not evidence_eligible:
        item["evidence_eligible"] = False
    try:
        ai_assisted_data_table.put_item(Item=item)
    except Exception:
        logger.warning(
            "DynamoDB PUT (artifact ref) failed | table=%s | PK=%s | SK=%s",
            ai_assisted_data_table.name, request_id, sk,
        )


def get_artifact_references(request_id: str, artifact_type: str) -> list:
    """Query ai_assisted_data_table for artifact refs by request_id and type."""
    if not request_id:
        return []
    sk_prefix = BINARY_SK if artifact_type == "binary" else RUNTIME_SK
    logger.debug("DynamoDB QUERY | table=%s | PK=%s | SK begins_with=%s# | artifact_type=%s", ai_assisted_data_table.name, request_id, sk_prefix, artifact_type)
    try:
        res = ai_assisted_data_table.query(
            KeyConditionExpression=Key("PK").eq(request_id) & Key("SK").begins_with(f"{sk_prefix}#")
        )
        items = res.get("Items", [])
        if not items:
            logger.warning("DynamoDB QUERY | table=%s | request_id=%s | artifact_type=%s | NO ITEMS found", ai_assisted_data_table.name, request_id, artifact_type)
        else:
            logger.debug("DynamoDB QUERY | table=%s | request_id=%s | artifact_type=%s | count=%d", ai_assisted_data_table.name, request_id, artifact_type, len(items))
        return items
    except Exception:
        logger.warning("DynamoDB QUERY failed | table=%s | request_id=%s | artifact_type=%s", ai_assisted_data_table.name, request_id, artifact_type)
        return []


def _clean_s3_key(s3_key: str) -> str:
    return s3_key.strip().rstrip('"').rstrip("%22")


def _artifact_download_url(s3_key: str) -> str:
    from src.configurations import config as _cfg
    base = (getattr(_cfg, "BACKEND_PUBLIC_BASE_URL", "") or "").rstrip("/")
    return f"{base}/download-artifact?s3_key={s3_key}"


def get_error_log_by_vector_id(vector_id):
    try:
        res = error_log_table.scan(
            FilterExpression=Attr("vector_id").eq(vector_id)
        )
    except Exception:
        return None
    if res.get("Items"):
        return res["Items"][0].get("id")
    return None


# -------------------------------------------------
# RECOMMENDED
# -------------------------------------------------

def set_recommended_count(error_log_id, count):
    """
    Insert a NEW recommendation entry every time (MySQL-like behavior)
    """
    item = {
        "id": str(uuid.uuid4()),
        "error_log_id": error_log_id,
        "count": count,
        "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    try:
        recommended_table.put_item(Item=item)
        return item["id"]
    except Exception:
        return None


# -------------------------------------------------
# DASHBOARD QUERIES
# -------------------------------------------------

def _scan_all(table, filter_expression=None):
    logger.debug("DynamoDB SCAN | table=%s | has_filter=%s", table.name, filter_expression is not None)
    kwargs = {}
    if filter_expression is not None:
        kwargs["FilterExpression"] = filter_expression

    items = []
    start_key = None
    while True:
        page_kwargs = dict(kwargs)
        if start_key:
            page_kwargs["ExclusiveStartKey"] = start_key
        res = table.scan(**page_kwargs)
        items.extend(res.get("Items", []))
        start_key = res.get("LastEvaluatedKey")
        if not start_key:
            break
    if not items:
        logger.warning("DynamoDB SCAN | table=%s | result EMPTY", table.name)
    else:
        logger.debug("DynamoDB SCAN | table=%s | total_items=%d", table.name, len(items))
    return items


def delete_table_items(table, items: list[dict]) -> int:
    logger.debug("DynamoDB BATCH DELETE | table=%s | items_to_delete=%d", table.name, len(items or []))
    deleted = 0
    with table.batch_writer() as batch:
        for item in items or []:
            key = _item_key(table, item)
            if not key:
                continue
            batch.delete_item(Key=key)
            deleted += 1
    logger.debug("DynamoDB BATCH DELETE done | table=%s | deleted=%d", table.name, deleted)
    return deleted


def _normalize_project_name(project_name):
    if project_name is None:
        return ""
    return str(project_name).strip().lower()


def _parse_created_datetime(value):
    if not value:
        return None
    raw = str(value).strip()
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw, fmt)
        except Exception:
            continue
    try:
        if raw.endswith("Z"):
            raw = raw[:-1] + "+00:00"
        dt = datetime.fromisoformat(raw)
        if dt.tzinfo is not None:
            return dt.astimezone(UTC).replace(tzinfo=None)
        return dt
    except Exception:
        return None


def _parse_range_date(value):
    if not value:
        return None
    v = str(value).strip()
    # Accept both formats the dashboard uses: DD-MM-YYYY (legacy) and YYYY-MM-DD / ISO (what the UI
    # now sends). Previously only DD-MM-YYYY was accepted, so an ISO date raised ValueError -> 500.
    for fmt in ("%d-%m-%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(v, fmt).date()
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(v.replace("Z", "+00:00")).date()
    except Exception:
        logger.warning("_parse_range_date: unrecognized date format %r - ignoring this bound", v)
        return None


def _in_range(created_date, s_date, c_date):
    if not s_date or not c_date:
        return True
    dt = _parse_created_datetime(created_date)
    if not dt:
        return False
    return s_date <= dt.date() <= c_date


def _recommended_hits_count(item):
    hits = item.get("recommended_count", [])
    if not hits:
        payload = _payload_json_dict(item)
        hits = payload.get("recommended_count", [])
 
    try:
        # low-level DynamoDB shape: {"L": [...]}
        return len(hits.get("L", []))
    except AttributeError:
        # already-decoded shape: [...]
        return len(hits or [])


def _payload_json_dict(row):
    payload = row.get("payload_json")
    if isinstance(payload, dict):
        return payload
    if isinstance(payload, str):
        try:
            parsed = json.loads(payload)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            return {}
    return {}


def _vector_rows():
    rows = _scan_all(ai_assisted_data_table)
    output = []
    for row in rows:
        sk = str(row.get("SK") or "")
        if sk.startswith(f"{VECTOR_SK}#") or row.get("vector_id"):
            output.append(row)
    return output


def _request_to_project_map(final_rows):
    mapping = {}
    for row in final_rows:
        req = row.get("request_id")
        if not req:
            continue
        payload = _payload_json_dict(row)
        project = _normalize_project_name(
            row.get("project_name") or payload.get("projectName")
        )
        if project:
            mapping[req] = project
    return mapping


def _resolve_vector_project(row, request_project_map):
    project = _normalize_project_name(row.get("project_name"))
    if project:
        return project
    req = row.get("request_id") or row.get("PK")
    return request_project_map.get(req, "")


def _cached_final_build_scan():
    """The raw final_build_payload full-table scan, cached. EVERY dashboard endpoint funnels
    through _final_build_rows, and each call re-scanned the whole table - at ~2 minutes per
    scan on the degraded dev DynamoDB Local (one get-tasks call measured 134s) the
    entire UI went blank. One scan now serves all endpoints for the TTL window; rows are
    READ-ONLY downstream (consumers build new dicts), so no per-call deep copy. Uploads
    invalidate the 'finalrows' key immediately via _invalidate_dashboard_read_cache."""
    from src.utils import ttl_cache
    ttl = None
    try:
        ttl = float(os.getenv("FINAL_ROWS_CACHE_TTL_SEC", "600"))
    except (TypeError, ValueError):
        ttl = 600.0
    return ttl_cache.get_or_compute(
        ("finalrows",),
        lambda: _scan_all(final_build_payload_table),
        deep_copy=False,
        ttl_override=ttl,
    )


def _final_build_rows(project_name=None, s_date=None, c_date=None):
    rows = _cached_final_build_scan()
    project_norm = _normalize_project_name(project_name) if project_name else ""
    start_date = _parse_range_date(s_date) if s_date else None
    end_date = _parse_range_date(c_date) if c_date else None

    output = []
    for row in rows:
        payload_json = _payload_json_dict(row)
        row_project = _normalize_project_name(
            row.get("project_name")
            or payload_json.get("projectName")
        )
        if project_norm and row_project != project_norm:
            continue
        if not _in_range(row.get("created_date"), start_date, end_date):
            continue
        output.append(row)
    return output


def get_all_projects():
    final_rows = _final_build_rows()
    stats = {}

    for row in final_rows:
        payload = _payload_json_dict(row)
        project = _normalize_project_name(
            row.get("project_name") or payload.get("projectName")
        ) or "unknown-project"
        created = row.get("created_date")

        project_type = payload.get("projectType") or row.get("project_type") or ""
        if isinstance(project_type, str):
            project_type = project_type.strip().lower()

        developer = str(row.get("developer_id") or row.get("username") or "").strip()

        if project not in stats:
            stats[project] = {
                "project_name": project,
                "last_analysis": created,
                "error_count": 0,
                "recommended_count": 0,
                "projectType": project_type,
                "developers": [],
            }

        stats[project]["error_count"] += 1
        stats[project]["recommended_count"] += _recommended_hits_count(row)

        if developer and developer not in stats[project]["developers"]:
            stats[project]["developers"].append(developer)

        prev = stats[project]["last_analysis"]
        if (not prev) or (created and created > prev):
            stats[project]["last_analysis"] = created
            if project_type:
                stats[project]["projectType"] = project_type

    return [stats[p] for p in sorted(stats.keys())]


def get_all_developers():
    final_rows = _final_build_rows()
    devs = {}

    for row in final_rows:
        developer = str(row.get("developer_id") or row.get("username") or "").strip()
        if not developer:
            continue

        payload = _payload_json_dict(row)
        project = _normalize_project_name(
            row.get("project_name") or payload.get("projectName")
        ) or "unknown-project"
        created = row.get("created_date")

        if developer not in devs:
            devs[developer] = {
                "developer_id": developer,
                "projects": [],
                "last_activity": created,
            }

        if project not in devs[developer]["projects"]:
            devs[developer]["projects"].append(project)

        prev = devs[developer]["last_activity"]
        if (not prev) or (created and created > prev):
            devs[developer]["last_activity"] = created

    return sorted(devs.values(), key=lambda d: d["last_activity"] or "", reverse=True)


def get_total_task(project_name, s_date, c_date):
    project_norm = _normalize_project_name(project_name)
    final_rows = _final_build_rows(project_name=project_norm, s_date=s_date, c_date=c_date)

    output = {}
    for row in final_rows:
        payload = _payload_json_dict(row)
        task = (row.get("task_name") or payload.get("taskName") or "unknown-task")
        task = str(task).strip() or "unknown-task"
        output.setdefault(
            task,
            {
                "task": task,
                "errorDetected": 0,
                "recommendedSolution": 0,
            },
        )
        # Count records in final_build_payload for this task.
        output[task]["errorDetected"] += 1
        output[task]["recommendedSolution"] += _recommended_hits_count(row)

    return list(output.values())


def get_total_error(project_name, s_date, c_date):
    project_norm = _normalize_project_name(project_name)
    final_rows = _final_build_rows(project_name=project_norm, s_date=s_date, c_date=c_date)
    if not final_rows:
        return []

    last_analysis = None
    recommended_total = 0
    for row in final_rows:
        created = row.get("created_date")
        if not last_analysis or (created and created > last_analysis):
            last_analysis = created
        recommended_total += _recommended_hits_count(row)

    return [
        {
            "project_name": project_norm,
            "last_analysis": last_analysis,
            "error_count": len(final_rows),
            "recommended_count": recommended_total,
        }
    ]


# def get_project_solutions(project_name, s_date, c_date):
#     """
#     Return final_build_payload rows for a project with solution arrays extracted
#     from payload_json.
#     """
#     project_norm = _normalize_project_name(project_name)
#     final_rows = _final_build_rows(project_name=project_norm, s_date=s_date, c_date=c_date)
#     output = []

#     for row in final_rows:
#         payload = _payload_json_dict(row)
#         solution = payload.get("solution")
#         if not isinstance(solution, list):
#             solution = []

#         output.append(
#             {
#                 "request_id": row.get("request_id"),
#                 "task_name": row.get("task_name") or payload.get("taskName"),
#                  "recommended_count": _recommended_hits_count(row),
#                 "solution": solution,
#             }
#         )

#     output.sort(key=lambda item: str(item.get("created_date") or ""), reverse=True)
#     return output


def _group_artifact_versions(refs: list) -> list:
    """One artifact row per FILE NAME (observed: three debug.log rows on one request).
    Byte-identical copies (same content sha in the S3 key suffix) collapse outright;
    different-content versions keep only the LATEST as the row, with the older ones carried
    additively in previous_versions (oldest first) — the same presentation rule the Compare
    view uses. Storage is untouched: every version stays stored and downloadable."""
    groups: dict = {}
    order: list = []
    for a in refs or []:
        if not (isinstance(a, dict) and a.get("s3_key")):
            continue
        name = str(a.get("file_name") or "").strip().lower()
        if name not in groups:
            groups[name] = []
            order.append(name)
        groups[name].append(a)

    out = []
    for name in order:
        seen_sha = set()
        unique = []
        for a in sorted(groups[name], key=lambda r: str(r.get("created_date") or "")):
            m = re.search(r"-([0-9a-f]{12})\.zip$", str(a.get("s3_key") or ""), re.IGNORECASE)
            sha = m.group(1).lower() if m else str(a.get("s3_key"))
            if sha in seen_sha:
                continue
            seen_sha.add(sha)
            unique.append(a)
        if not unique:
            continue
        primary = dict(unique[-1])
        primary["versions_total"] = len(unique)
        primary["previous_versions"] = [
            {
                "file_name": v.get("file_name"),
                "s3_key": v.get("s3_key"),
                "artifact_type": v.get("artifact_type"),
                "created_date": v.get("created_date"),
            }
            for v in unique[:-1]
        ]
        out.append(primary)
    return out


def get_project_solutions(project_name, s_date, c_date):
    """
    Return final_build_payload rows for a project with solution arrays extracted
    from payload_json.
    """
    project_norm = _normalize_project_name(project_name)
    final_rows = _final_build_rows(project_name=project_norm, s_date=s_date, c_date=c_date)
    output = []

    for row in final_rows:
        payload = _payload_json_dict(row)
        solution = payload.get("solution")
        if not isinstance(solution, list):
            solution = []

        request_id = row.get("request_id")
        binary_artifacts = get_artifact_references(request_id, "binary") if request_id else []
        runtime_artifacts = get_artifact_references(request_id, "runtime") if request_id else []
        all_artifacts = _group_artifact_versions(binary_artifacts + runtime_artifacts)
        binary_links = [
            _artifact_download_url(_clean_s3_key(a["s3_key"])) for a in all_artifacts
            if a.get("s3_key") and not str(a.get("file_name", "")).endswith(".log")
        ]
        log_links = [
            _artifact_download_url(_clean_s3_key(a["s3_key"])) for a in all_artifacts
            if a.get("s3_key") and str(a.get("file_name", "")).endswith(".log")
        ]

        output.append(
            {
                "request_id": row.get("request_id"),
                "task_name": row.get("task_name") or payload.get("taskName"),
                "recommended_count": _recommended_hits_count(row),
                "username": row.get("username", ""),
                "developer_id": row.get("developer_id") or row.get("username", ""),
                "created_date": row.get("created_date"),
                "solution": solution,
                # Per UI request: "binary" keeps the download URLs (links) AND carries the detailed
                # artifacts[]. Each artifact has file_name/s3_key/artifact_type here; the AI summary and
                # view-as-text raw_url are attached later in handle_get_total_errors. One entry per file.
                "binary": {
                    "links": [
                        _artifact_download_url(_clean_s3_key(a.get("s3_key") or ""))
                        for a in all_artifacts if a.get("s3_key")
                    ],
                    "artifacts": [
                        {
                            "file_name": a.get("file_name"),
                            "s3_key": _clean_s3_key(a.get("s3_key") or ""),
                            "artifact_type": a.get("artifact_type"),
                            # One row per file: this entry is the LATEST content-version; older
                            # versions ride along additively for a history affordance in the UI.
                            "versions_total": int(a.get("versions_total") or 1),
                            "previous_versions": [
                                {
                                    "file_name": v.get("file_name"),
                                    "s3_key": _clean_s3_key(v.get("s3_key") or ""),
                                    "artifact_type": v.get("artifact_type"),
                                    "created_date": v.get("created_date"),
                                    "download_url": _artifact_download_url(_clean_s3_key(v.get("s3_key") or "")),
                                }
                                for v in (a.get("previous_versions") or [])
                            ],
                        }
                        for a in all_artifacts if a.get("s3_key")
                    ],
                },
                "logs": log_links,
                "projectType": row.get("project_type") or payload.get("projectType") or "",
                "resolutionDescription": row.get("resolution_description") or payload.get("resolutionDescription") or "",
            }
        )

    output.sort(key=lambda item: str(item.get("created_date") or ""), reverse=True)
    return output

def get_graph_projects_data(s_date=None, c_date=None):
    """
    Single-call graph data for all projects.

    Returns per-project summary (error_count, recommended_count, project_type,
    last_analysis) plus a daily breakdown array — all scoped to [s_date, c_date].
    Used by GET /graph/projects.
    """
    today = datetime.now().strftime("%d-%m-%Y")
    s = s_date or today
    c = c_date or today

    # ── One scan for date-filtered rows ─────────────────────────────────────
    date_rows = _final_build_rows(project_name=None, s_date=s, c_date=c)

    # ── One scan for all-time rows (project_type + true last_analysis) ───────
    all_rows = _final_build_rows()

    # Build project_type and all-time last_analysis from the full scan
    meta: dict = {}
    for row in all_rows:
        payload = _payload_json_dict(row)
        project = _normalize_project_name(
            row.get("project_name") or payload.get("projectName")
        ) or "unknown-project"
        created = row.get("created_date") or ""
        project_type = (
            row.get("project_type") or payload.get("projectType") or ""
        ).strip().lower()

        if project not in meta:
            meta[project] = {"project_type": project_type, "last_analysis": created}
        else:
            if project_type:
                meta[project]["project_type"] = project_type
            if created > meta[project]["last_analysis"]:
                meta[project]["last_analysis"] = created

    # ── Aggregate date-filtered rows per project + per day ───────────────────
    projects: dict = {}

    for row in date_rows:
        payload = _payload_json_dict(row)
        project = _normalize_project_name(
            row.get("project_name") or payload.get("projectName")
        ) or "unknown-project"
        created_dt = _parse_created_datetime(row.get("created_date"))
        day = created_dt.strftime("%Y-%m-%d") if created_dt and created_dt != datetime.min else None
        rec = _recommended_hits_count(row)

        if project not in projects:
            projects[project] = {
                "project_name": project,
                "project_type": (meta.get(project) or {}).get("project_type", ""),
                "last_analysis": (meta.get(project) or {}).get("last_analysis", ""),
                "error_count": 0,
                "recommended_count": 0,
                "daily": {},
            }

        projects[project]["error_count"] += 1
        projects[project]["recommended_count"] += rec

        if day:
            if day not in projects[project]["daily"]:
                projects[project]["daily"][day] = {"date": day, "error_count": 0, "recommended_count": 0}
            projects[project]["daily"][day]["error_count"] += 1
            projects[project]["daily"][day]["recommended_count"] += rec

    # ── Flatten daily dict → sorted list ─────────────────────────────────────
    result = []
    for p in sorted(projects.keys()):
        item = projects[p]
        daily_list = sorted(item["daily"].values(), key=lambda x: x["date"])
        result.append({
            "project_name": item["project_name"],
            "project_type": item["project_type"],
            "last_analysis": item["last_analysis"],
            "error_count": item["error_count"],
            "recommended_count": item["recommended_count"],
            "daily": daily_list,
        })

    total_errors = sum(p["error_count"] for p in result)
    total_recommended = sum(p["recommended_count"] for p in result)

    return {
        "date_range": {"from": s, "to": c},
        "summary": {
            "total_projects": len(result),
            "total_errors": total_errors,
            "total_recommended": total_recommended,
        },
        "projects": result,
    }

def get_daily_activity_solutions(s_date=None, c_date=None):
    """
   Return final_build_payload rows across ALL projects for a date range.    
   Defaults to today if no dates provided.
    """
    today = datetime.now().strftime("%d-%m-%Y")
    final_rows = _final_build_rows(project_name=None, s_date=s_date or today, c_date=c_date or today)
    output = []

    for row in final_rows:
        payload = _payload_json_dict(row)
        solution = payload.get("solution")
        if not isinstance(solution, list):
            solution = []

        request_id = row.get("request_id")
        binary_artifacts = get_artifact_references(request_id, "binary") if request_id else []
        runtime_artifacts = get_artifact_references(request_id, "runtime") if request_id else []
        all_artifacts = _group_artifact_versions(binary_artifacts + runtime_artifacts)
        log_links = [
            _artifact_download_url(_clean_s3_key(a["s3_key"])) for a in all_artifacts
            if a.get("s3_key") and str(a.get("file_name", "")).endswith(".log")
        ]

        output.append(
            {
                "project_name": row.get("project_name") or payload.get("projectName") or "",
                "request_id": request_id,
                "task_name": row.get("task_name") or payload.get("taskName"),
                "recommended_count": _recommended_hits_count(row),
                "username": row.get("username", ""),
                "developer_id": row.get("developer_id") or row.get("username", ""),
                "created_date": row.get("created_date"),
                "solution": solution,
                # Same shape as get_project_solutions so daily-activity gets the SAME enrichment
                # (summary/token_usage/raw_url/diff_link) as get-total-errors: links AND artifacts[].
                "binary": {
                    "links": [
                        _artifact_download_url(_clean_s3_key(a.get("s3_key") or ""))
                        for a in all_artifacts if a.get("s3_key")
                    ],
                    "artifacts": [
                        {
                            "file_name": a.get("file_name"),
                            "s3_key": _clean_s3_key(a.get("s3_key") or ""),
                            "artifact_type": a.get("artifact_type"),
                            # One row per file: this entry is the LATEST content-version; older
                            # versions ride along additively for a history affordance in the UI.
                            "versions_total": int(a.get("versions_total") or 1),
                            "previous_versions": [
                                {
                                    "file_name": v.get("file_name"),
                                    "s3_key": _clean_s3_key(v.get("s3_key") or ""),
                                    "artifact_type": v.get("artifact_type"),
                                    "created_date": v.get("created_date"),
                                    "download_url": _artifact_download_url(_clean_s3_key(v.get("s3_key") or "")),
                                }
                                for v in (a.get("previous_versions") or [])
                            ],
                        }
                        for a in all_artifacts if a.get("s3_key")
                    ],
                },
                "logs": log_links,
                "projectType": row.get("project_type") or payload.get("projectType") or "",
                "resolutionDescription": row.get("resolution_description") or payload.get("resolutionDescription") or "",
            }
        )

    output.sort(key=lambda item: str(item.get("created_date") or ""), reverse=True)
    return output


# def get_week_sise_count(project_name, s_date, c_date):
#     project_norm = _normalize_project_name(project_name)
#     final_rows = _final_build_rows(project_name=project_norm, s_date=s_date, c_date=c_date)
#     request_project_map = _request_to_project_map(final_rows)
#     request_ids = {row.get("request_id") for row in final_rows if row.get("request_id")}
#     vectors = []
#     for row in _vector_rows():
#         req = row.get("request_id") or row.get("PK")
#         resolved_project = _resolve_vector_project(row, request_project_map)
#         if req in request_ids or resolved_project == project_norm:
#             vectors.append(row)

#     vector_count_by_request = {}
#     for row in vectors:
#         req = row.get("request_id") or row.get("PK")
#         if not req:
#             continue
#         vector_count_by_request[req] = vector_count_by_request.get(req, 0) + 1

#     output = {}
#     for row in final_rows:
#         created = _parse_created_datetime(row.get("created_date"))
#         if not created:
#             continue
#         day = created.strftime("%Y-%m-%d")
#         request_id = row.get("request_id")
#         output.setdefault(
#             day,
#             {
#                 "project_name": project_norm,
#                 "day_date": day,
#                 "error_count": 0,
#                 "recommended_count": 0,
#             },
#         )
#         output[day]["error_count"] += vector_count_by_request.get(request_id, 0)
#         output[day]["recommended_count"] += _recommended_hits_count(row)

#     return list(output.values())

from datetime import datetime

def get_week_sise_count(project_name, s_date, c_date):
    project_norm = _normalize_project_name(project_name)
    final_rows = _final_build_rows(
        project_name=project_norm,
        s_date=s_date,
        c_date=c_date
    )

    output = {}

    for row in final_rows:
        created = _parse_created_datetime(row.get("created_date"))
        if not created:
            continue

        day_key = created.strftime("%Y-%m-%d")
        request_id = row.get("request_id")

        if day_key not in output:
            output[day_key] = {
                "project_name": project_norm,
                "day_date": day_key,
                "error_ids": set(),
                "recommended_count": 0,
            }

        if request_id:
            output[day_key]["error_ids"].add(request_id)

        output[day_key]["recommended_count"] += _recommended_hits_count(row)

    results = []
    for day in sorted(output.keys()):
        item = output[day]
        results.append({
            "project_name": item["project_name"],
            "day_date": item["day_date"],
            "error_count": len(item["error_ids"]),
            "recommended_count": item["recommended_count"],
        })

    return results


# -------------------------------------------------
# FILE SNAPSHOTS / DIFF
# -------------------------------------------------

def save_file_snapshot(snapshot, solution_id):
    solution_files_table.put_item(Item={
        "solution_file_id": str(uuid.uuid4()),
        "solution_id": solution_id,
        "file_name": snapshot.get("fileName"),
        "file_path": snapshot.get("path"),
        "before_file_text": snapshot.get("snapshotBefore"),
        "after_file_text": snapshot.get("snapshotAfter"),
        "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })


def save_file_snapshots_bulk(snapshots, solution_id):
    """
    Batch write file snapshots to reduce round trips and blocking time.
    """
    if not snapshots:
        return

    with solution_files_table.batch_writer() as batch:
        for snapshot in snapshots:
            batch.put_item(Item={
                "solution_file_id": str(uuid.uuid4()),
                "solution_id": solution_id,
                "file_name": snapshot.get("fileName"),
                "file_path": snapshot.get("path"),
                "before_file_text": snapshot.get("snapshotBefore"),
                "after_file_text": snapshot.get("snapshotAfter"),
                "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })


def get_solution_id(vector_id):
    res = error_log_table.scan(
        FilterExpression=Attr("vector_id").eq(vector_id)
    )
    if res["Items"]:
        return {"solution_id": res["Items"][0]["solution_id"]}
    return None


def get_diff_files(solution_id):
    res = solution_files_table.scan(
        FilterExpression=Attr("solution_id").eq(solution_id["solution_id"])
    )
    return res["Items"]


def list_solutions_by_batch_id(batch_id: str) -> list[dict]:
    if not batch_id:
        return []
    try:
        return _scan_all(solution_table, filter_expression=Attr("batch_id").eq(batch_id))
    except Exception:
        return []


def list_solution_files(solution_id: str) -> list[dict]:
    if not solution_id:
        return []
    try:
        return _scan_all(solution_files_table, filter_expression=Attr("solution_id").eq(solution_id))
    except Exception:
        return []


def list_error_logs_by_vector_ids(vector_ids: list[str]) -> list[dict]:
    ids = [str(vector_id).strip() for vector_id in (vector_ids or []) if str(vector_id).strip()]
    if not ids:
        return []
    items = []
    seen = set()
    for vector_id in ids:
        try:
            rows = _scan_all(error_log_table, filter_expression=Attr("vector_id").eq(vector_id))
        except Exception:
            rows = []
        for row in rows:
            row_id = str(row.get("id") or "")
            if not row_id or row_id in seen:
                continue
            seen.add(row_id)
            items.append(row)
    return items


def list_error_logs_by_solution_ids(solution_ids: list[str]) -> list[dict]:
    ids = [str(solution_id).strip() for solution_id in (solution_ids or []) if str(solution_id).strip()]
    if not ids:
        return []
    items = []
    seen = set()
    for solution_id in ids:
        try:
            rows = _scan_all(error_log_table, filter_expression=Attr("solution_id").eq(solution_id))
        except Exception:
            rows = []
        for row in rows:
            row_id = str(row.get("id") or "")
            if not row_id or row_id in seen:
                continue
            seen.add(row_id)
            items.append(row)
    return items


def delete_solutions_by_batch_id(batch_id: str) -> dict:
    solutions = list_solutions_by_batch_id(batch_id)
    solution_ids = [str(item.get("id") or "").strip() for item in solutions if str(item.get("id") or "").strip()]
    solution_files = []
    for solution_id in solution_ids:
        solution_files.extend(list_solution_files(solution_id))
    deleted_files = delete_table_items(solution_files_table, solution_files)
    deleted_solutions = delete_table_items(solution_table, solutions)
    return {
        "solutions_deleted": deleted_solutions,
        "solution_files_deleted": deleted_files,
        "solution_ids": solution_ids,
    }


def delete_error_logs(vector_ids: list[str] | None = None, solution_ids: list[str] | None = None) -> int:
    items = []
    seen = set()
    for row in list_error_logs_by_vector_ids(vector_ids or []):
        row_id = str(row.get("id") or "")
        if row_id and row_id not in seen:
            seen.add(row_id)
            items.append(row)
    for row in list_error_logs_by_solution_ids(solution_ids or []):
        row_id = str(row.get("id") or "")
        if row_id and row_id not in seen:
            seen.add(row_id)
            items.append(row)
    return delete_table_items(error_log_table, items)





# ======================= Extension usage (adoption KPIs) =======================
# A tab under User Management showing who uses the extension and how
# much. Storage follows the two questions the request contains, which have different privacy
# answers, so they are kept in different rows:
#
#   EXTUSAGE#<install_id> / USE#<date>#<project>   daily counters, TTL'd
#   EXTUSAGE#<install_id> / PROFILE                first/last seen, version, sealed identity
#
# install_id is the id VS Code creates per installation - it is not derived from any person.
# dev_key is a value the extension derived on its own machine, never a login; every
# adoption number below works without them. See src/services/extension_usage.py for the
# sealing rule and the KPI aggregation.

EXTUSAGE_PK_PREFIX = "EXTUSAGE#"
EXTUSAGE_PROFILE_SK = "PROFILE"
EXTUSAGE_BUILD_SK_PREFIX = "BUILD#"
_EXTUSAGE_DETAIL_RETENTION_DAYS = 90


def save_extension_usage(install_id: str, project_name: str = "", ext_version: str = "",
                         env_kind: str = "", dev_key: str = "",
                         failed: bool = False, used_at: str | None = None,
                         builds: int = 1, uploads: int = 0,
                         recommended: int = 0, answered: int = 0,
                         seen_builds: int = 0, seen_failures: int = 0,
                         seen_issues: int = 0) -> bool:
    """Count one piece of extension activity against an installation. Never raises: usage
    counting must degrade quietly rather than fail an upload the developer is waiting on.

    The question moved from "how many builds" to what each person actually does -
    how many times they send a failure up, and how many times they get an answer back. Those are
    two different events on two different endpoints, so the counters are passed in rather than
    assumed: the fix upload adds a build, the failure report adds an upload and, when the search
    returned something, a recommendation. Counting them in one place would either double-count
    or miss whichever half did not happen.
    """
    install = str(install_id or "").strip()
    if not install:
        return False
    used_at = used_at or _iso_utc()
    day = used_at[:10]
    project = str(project_name or "").strip().lower() or "unknown"
    pk = EXTUSAGE_PK_PREFIX + install

    try:
        ai_assisted_data_table.update_item(
            Key={"PK": pk, "SK": f"USE#{day}#{project}"},
            UpdateExpression=(
                "ADD builds :one, failures :f, uploads :u, recommended :r, answered :a, "
                "seen_builds :sb, seen_failures :sf, seen_issues :si "
                "SET project_name = :p, use_date = :d, ext_version = :v, "
                "expires_at = :exp, updated_date = :now"
            ),
            ExpressionAttributeValues={
                ":one": int(builds or 0),
                ":f": 1 if failed else 0,
                ":u": int(uploads or 0),
                ":r": int(recommended or 0),
                ":a": int(answered or 0),
                # The number of builds that happened / builds that failed over a period.
                # The extension now reports EVERY build it sees (success or failure) through
                # /extension-usage/build; these two counters are that report. They are separate
                # from `builds` (fix uploads) and `failures` so the older meaning is untouched.
                ":sb": int(seen_builds or 0),
                ":sf": int(seen_failures or 0),
                # The errors the extension captured from a failed build ("Issues Captured").
                ":si": int(seen_issues or 0),
                ":p": project,
                ":d": day,
                ":v": str(ext_version or "").strip(),
                ":exp": _retention_epoch(_EXTUSAGE_DETAIL_RETENTION_DAYS),
                ":now": used_at,
            },
        )
    except Exception:
        logger.warning("extension usage counter failed | install=%s | project=%s", install[:8], project)
        return False

    # The profile row carries no TTL: the adoption trend must survive the detail rows expiring.
    expr = ("SET first_seen = if_not_exists(first_seen, :now), last_seen = :now, "
            "ext_version = :v, env_kind = :e, updated_date = :now")
    values = {":now": used_at, ":v": str(ext_version or "").strip(),
              ":e": str(env_kind or "").strip()}
    if dev_key:
        # The only identity value stored. It is derived on the developer's own machine, so the
        # login never reaches us; this recognises the same person twice and nothing more.
        expr += ", dev_key = :k"
        values[":k"] = str(dev_key)
    try:
        ai_assisted_data_table.update_item(
            Key={"PK": pk, "SK": EXTUSAGE_PROFILE_SK},
            UpdateExpression=expr,
            ExpressionAttributeValues=values,
        )
    except Exception:
        logger.warning("extension usage profile failed | install=%s", install[:8])
    return True


def save_extension_install(install_id: str, ext_version: str = "", env_kind: str = "",
                           dev_key: str = "", seen_at: str | None = None) -> bool:
    """An installation announcing itself. Writes the PROFILE row only - no daily counter row -
    so an installation that never builds is visible without inflating any build figure."""
    install = str(install_id or "").strip()
    if not install:
        return False
    seen_at = seen_at or _iso_utc()
    expr = ("SET first_seen = if_not_exists(first_seen, :now), last_seen = if_not_exists(last_seen, :now), "
            "ext_version = :v, env_kind = :e, updated_date = :now")
    values = {":now": seen_at, ":v": str(ext_version or "").strip(), ":e": str(env_kind or "").strip()}
    if dev_key:
        expr += ", dev_key = :k"
        values[":k"] = str(dev_key)
    try:
        ai_assisted_data_table.update_item(
            Key={"PK": EXTUSAGE_PK_PREFIX + install, "SK": EXTUSAGE_PROFILE_SK},
            UpdateExpression=expr, ExpressionAttributeValues=values,
        )
        return True
    except Exception:
        logger.warning("extension install record failed | install=%s", install[:8])
        return False


def save_extension_build(install_id: str, build_id: str, project_name: str = "",
                         failed: bool = False, started_at: str = "", finished_at: str = "",
                         duration_sec=None, task_name: str = "", issues: int = 0,
                         ext_version: str = "", seen_at: str | None = None) -> bool:
    """ONE build, as a record of its own - the row the card drill-down lists.

    The daily counters say how many builds happened; they cannot say which. The Extension Usage
    drill-down must list the actual builds behind a card (group -> project -> build, with its
    status, time and duration), and that needs a row per build. It is written next to the
    counters, under the same installation key, so the same scan and the same group rule serve
    both, and it carries the same retention as the daily rows.

    Keyed on finish time + the extension's build id: two installations never collide, and a
    replayed report overwrites itself rather than listing one build twice. Never raises - the
    build the developer is waiting on must not fail because its record did not store.
    """
    install = str(install_id or "").strip()
    build = str(build_id or "").strip()
    if not install or not build:
        return False
    seen_at = seen_at or _iso_utc()
    finished = str(finished_at or "").strip() or seen_at
    item = {
        "PK": EXTUSAGE_PK_PREFIX + install,
        "SK": f"{EXTUSAGE_BUILD_SK_PREFIX}{finished}#{build}",
        "build_id": build,
        "project_name": str(project_name or "").strip().lower() or "unknown",
        "build_status": "failed" if failed else "success",
        "started_at": str(started_at or "").strip(),
        "finished_at": finished,
        "task_name": str(task_name or "").strip(),
        "issues": max(0, min(int(issues or 0), 500)),
        "ext_version": str(ext_version or "").strip(),
        "expires_at": _retention_epoch(_EXTUSAGE_DETAIL_RETENTION_DAYS),
        "updated_date": seen_at,
    }
    try:
        item["duration_sec"] = max(0, int(duration_sec))
    except (TypeError, ValueError):
        pass  # not sent, or not a number: the build is still listed, without a duration
    try:
        ai_assisted_data_table.put_item(Item=item)
        return True
    except Exception:
        logger.warning("extension build record failed | install=%s | build=%s", install[:8], build[:40])
        return False


def list_extension_usage():
    """Every EXTUSAGE row (daily counters and profiles). Paginated scan, expired rows skipped,
    fail-open [] - the same shape list_all_recommendation_feedback uses."""
    try:
        items = []
        kwargs = {"FilterExpression": Attr("PK").begins_with(EXTUSAGE_PK_PREFIX)}
        while True:
            res = ai_assisted_data_table.scan(**kwargs)
            items.extend(res.get("Items", []))
            last = res.get("LastEvaluatedKey")
            if not last:
                break
            kwargs["ExclusiveStartKey"] = last
        now_epoch = _epoch_utc()
        return [x for x in items
                if not (int(x.get("expires_at", 0) or 0) and int(x.get("expires_at", 0) or 0) <= now_epoch)]
    except Exception:
        logger.exception("list_extension_usage failed - returning []")
        return []


def clear_extension_identity(dev_key: str) -> int:
    """Erasure: drop the identity link from every profile row carrying this key. The usage
    counters stay, so the adoption trend is undamaged and the rows can never again be traced
    back to a person. Returns how many profiles were cleared."""
    key = str(dev_key or "").strip()
    if not key:
        return 0
    cleared = 0
    for row in list_extension_usage():
        if row.get("SK") != EXTUSAGE_PROFILE_SK or str(row.get("dev_key") or "") != key:
            continue
        try:
            ai_assisted_data_table.update_item(
                Key={"PK": row["PK"], "SK": EXTUSAGE_PROFILE_SK},
                UpdateExpression="REMOVE dev_key SET updated_date = :now",
                ExpressionAttributeValues={":now": _iso_utc()},
            )
            cleared += 1
        except Exception:
            logger.warning("clear_extension_identity failed for %s", row.get("PK"))
    return cleared


def list_all_recommendation_outcomes():
    """ALL RECOMMEND# outcome rows across requests (shown / success_correlated), excluding the
    per-request summary row. Feeds the value KPIs. Paginated scan, expired rows skipped,
    fail-open []."""
    try:
        items = []
        kwargs = {"FilterExpression": (Attr("SK").begins_with("RECOMMEND#")
                                       & Attr("SK").ne(RECOMMEND_SUMMARY_SK))}
        while True:
            res = ai_assisted_data_table.scan(**kwargs)
            items.extend(res.get("Items", []))
            last = res.get("LastEvaluatedKey")
            if not last:
                break
            kwargs["ExclusiveStartKey"] = last
        now_epoch = _epoch_utc()
        return [x for x in items
                if not (int(x.get("expires_at", 0) or 0) and int(x.get("expires_at", 0) or 0) <= now_epoch)]
    except Exception:
        logger.exception("list_all_recommendation_outcomes failed - returning []")
        return []


def scan_kpi_rows(budget_sec: float = 20.0, page_size: int = 500) -> dict:
    """ONE bounded pass over the table for the Extension Usage KPIs.

    The KPI endpoint originally called list_extension_usage,
    list_all_recommendation_feedback and list_all_recommendation_outcomes. Each is a paginated
    scan with a FilterExpression, and DynamoDB applies a filter AFTER reading, so every one of
    them read the WHOLE table - three times, unbounded. On UAT that returned 504 before the
    cache could ever be filled, so the timeout repeated on every request forever.

    Two fixes here. The three passes become one, bucketed by key, because they all wanted
    different rows out of the same table rather than different tables. And the pass carries a
    wall-clock budget, so a large table returns a partial answer instead of no answer.

    Truncation is REPORTED, never silent: `partial` and `scanned` travel with the result so the
    screen can say the figures are based on a sample rather than implying they are complete.
    """
    started = time.time()
    buckets = {"usage": [], "builds": [], "feedback": [], "outcomes": [], "traces": []}
    scanned = 0
    partial = False
    try:
        kwargs = {"Limit": max(50, int(page_size))}
        while True:
            res = ai_assisted_data_table.scan(**kwargs)
            for row in res.get("Items", []):
                scanned += 1
                sk = str(row.get("SK") or "")
                pk = str(row.get("PK") or "")
                if pk.startswith(EXTUSAGE_PK_PREFIX):
                    # Per-build records share the installation key with the daily counters but
                    # are a different kind of row; kept apart so no counter loop ever sees one.
                    if sk.startswith(EXTUSAGE_BUILD_SK_PREFIX):
                        buckets["builds"].append(row)
                    else:
                        buckets["usage"].append(row)
                elif pk == "RECTRACE":
                    # One trace = ONE failure that asked for a recommendation. This is the only
                    # row type that records a request which produced NOTHING, so it is the only
                    # honest denominator for "how often did a failure get an answer".
                    buckets["traces"].append(row)
                elif sk.startswith("FEEDBACK#"):
                    buckets["feedback"].append(row)
                elif sk.startswith("RECOMMEND#") and sk != RECOMMEND_SUMMARY_SK:
                    buckets["outcomes"].append(row)
            last = res.get("LastEvaluatedKey")
            if not last:
                break
            if time.time() - started > budget_sec:
                partial = True
                logger.warning("scan_kpi_rows hit the %.0fs budget after %d rows - partial result",
                               budget_sec, scanned)
                break
            kwargs["ExclusiveStartKey"] = last
    except Exception:
        logger.exception("scan_kpi_rows failed - returning whatever was collected")
        partial = True

    now_epoch = _epoch_utc()

    def _live(rows):
        return [r for r in rows
                if not (int(r.get("expires_at", 0) or 0) and int(r.get("expires_at", 0) or 0) <= now_epoch)]

    return {
        "usage": _live(buckets["usage"]),
        "builds": _live(buckets["builds"]),
        "feedback": _live(buckets["feedback"]),
        "outcomes": _live(buckets["outcomes"]),
        "traces": _live(buckets["traces"]),
        "scanned": scanned,
        "partial": partial,
        "seconds": round(time.time() - started, 2),
    }
