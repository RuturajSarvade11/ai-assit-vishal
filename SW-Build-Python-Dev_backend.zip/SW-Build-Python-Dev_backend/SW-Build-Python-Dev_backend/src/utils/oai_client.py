# src/utils/oai_client.py
from typing import Any, Dict, List
import os
import time
import logging
import random
import re
import json
import difflib

import httpx
from flask import g, has_request_context
from openai import AzureOpenAI, RateLimitError, APITimeoutError, APIConnectionError

from src.configurations import config

logger = logging.getLogger("app.embedding")
_EMBEDDING_TIMEOUT = httpx.Timeout(connect=5.0, read=30.0, write=30.0, pool=5.0)
_EMBEDDING_MAX_RETRIES = max(1, int(os.getenv("EMBEDDING_RETRIES", "4")))
_EMBEDDING_RETRY_BASE_SEC = max(0.5, float(os.getenv("EMBEDDING_RETRY_BASE_SEC", "2.0")))
_EMBEDDING_MAX_CHARS = max(200, int(os.getenv("EMBEDDING_MAX_CHARS", "1500")))
_EMBEDDING_MAX_LINES = max(5, int(os.getenv("EMBEDDING_MAX_LINES", "40")))
# Floor for graceful shrink-and-retry when an input exceeds the model token limit.
_EMBEDDING_MIN_CHARS = max(200, int(os.getenv("EMBEDDING_MIN_CHARS", "1000")))

# Substrings that identify a "context too long" rejection from the embeddings API,
# as opposed to a transient/rate-limit error. Used to drive shrink-and-retry.
_CONTEXT_LENGTH_MARKERS = (
    "maximum context length",
    "context_length_exceeded",
    "reduce the length",
    "longer than the model",
    "string too long",
    "please reduce your prompt",
)


def _is_context_length_error(exc: Exception) -> bool:
    s = str(exc).lower()
    return any(marker in s for marker in _CONTEXT_LENGTH_MARKERS)

# Shared client to avoid recreating transport/auth state for each request.
# Prefer an API key (bypasses MFA / Conditional Access); fall back to the AAD (az-login) credential.
_oai_auth = ({"api_key": config.AZURE_OPENAI_API_KEY}
             if getattr(config, "AZURE_OPENAI_API_KEY", "")
             else {"azure_ad_token_provider": config.AZURE_OPENAI_TOKEN_PROVIDER})
_client = AzureOpenAI(
    api_version=config.OAI_API_VERSION,
    azure_endpoint=config.OPEN_AI_ENDPOINT,
    timeout=_EMBEDDING_TIMEOUT,
    max_retries=1,
    **_oai_auth,
)

# Chat completions (analysis/selection) run on larger prompts than embeddings and legitimately
# take longer, so give them a dedicated, more generous read timeout (still bounded).
_CHAT_TIMEOUT = httpx.Timeout(
    connect=5.0,
    read=max(20.0, float(os.getenv("CHAT_READ_TIMEOUT_SEC", "60"))),
    write=30.0,
    pool=5.0,
)

# DEFAULT_MODEL (e.g. gpt-5-nano) is a REASONING model: it uses 'max_completion_tokens' (not
# 'max_tokens'), and with no output cap + default reasoning effort it can "think" for minutes on
# a complex prompt and time out. We bound the output and set LOW reasoning effort so these short,
# structured tasks (root-cause sentence, JSON selection, ≤200-word summary) return in seconds.
# Both are env-tunable; reasoning_effort is only sent when set to a valid value (so swapping to a
# non-reasoning model stays compatible — just set CHAT_REASONING_EFFORT="").
_CHAT_MAX_COMPLETION_TOKENS = max(256, int(os.getenv("CHAT_MAX_COMPLETION_TOKENS", "3000")))
_CHAT_REASONING_EFFORT = os.getenv("CHAT_REASONING_EFFORT", "low").strip().lower()

# 429 handling: rate-limit rejections are INSTANT (unlike timeouts), so retrying them with backoff
# is cheap and absorbs production bursts instead of failing data. Timeouts stay fail-fast
# (max_retries=0); ONLY RateLimitError is retried here, honouring the server's Retry-After when
# present. Foreground (recommendation) gets a few quick retries inside its 120s budget; background
# summarization can afford more.
_CHAT_RATE_LIMIT_RETRIES = max(0, int(os.getenv("CHAT_RATE_LIMIT_RETRIES", "3")))
_CHAT_RATE_LIMIT_BASE_SEC = max(0.5, float(os.getenv("CHAT_RATE_LIMIT_BASE_SEC", "2.0")))
_SUMMARY_RATE_LIMIT_RETRIES = max(0, int(os.getenv("SUMMARY_RATE_LIMIT_RETRIES", "6")))


def _rate_limit_delay_sec(exc: Exception, attempt: int) -> float:
    """Delay before the next attempt after a 429: server's Retry-After when given, otherwise
    exponential backoff with jitter (base 2s -> 2,4,8,... capped at 60s)."""
    try:
        headers = getattr(getattr(exc, "response", None), "headers", None) or {}
        ra = headers.get("retry-after") or headers.get("Retry-After")
        if ra:
            return min(60.0, max(0.5, float(ra)))
        ra_ms = headers.get("retry-after-ms")
        if ra_ms:
            return min(60.0, max(0.5, float(ra_ms) / 1000.0))
    except Exception:
        pass
    return min(60.0, _CHAT_RATE_LIMIT_BASE_SEC * (2 ** (attempt - 1)) + random.uniform(0, 1))

# Use the FULL artifact (per client): important signal can be ANYWHERE in the file, so we do not
# truncate to a small slice. The ONLY bound is the model's input CAPACITY — this cap is sized to sit
# safely inside gpt-5-nano's context window (leaving headroom for the prompt + output), so an
# artifact is sent WHOLE and is trimmed only if it would otherwise exceed what the model can accept.
# ~600,000 chars ≈ ~150-200k tokens, well under gpt-5-nano's input window. Tunable via
# ARTIFACT_SUMMARY_INPUT_CHARS (raise toward the model limit if your deployment allows).
_ARTIFACT_SUMMARY_INPUT_CHARS = max(2000, int(os.getenv("ARTIFACT_SUMMARY_INPUT_CHARS", "600000")))

# Large-log handling: log FORMATS vary, so CODE must not use content patterns
# to guess which lines are "the failure". Reduction therefore happens in two pattern-free stages:
#   1) format-agnostic STRUCTURAL reduction (stack-trace compaction + exact duplicate-line collapse)
#      — these shrink by repetition/structure, never by keyword;
#   2) if the result still exceeds one model call, MAP-REDUCE summarisation — the model reads EVERY
#      chunk and decides relevance itself, then the partials are combined. No regex decides content.
# Keyword/marker extraction is retained but OPT-IN only (ARTIFACT_KEYWORD_EXTRACTION=1); off by
# default per the client's "don't rely on any pattern" guidance.
_ARTIFACT_COMPRESS_TRIGGER = max(10000, int(os.getenv("ARTIFACT_COMPRESS_TRIGGER_CHARS", "40000")))
# A single summary call handles up to this many chars; beyond it we map-reduce. ~50k chars is a
# small, fast, quota-friendly call (one big 600k call is exactly what triggered the 429 storms).
_MAP_REDUCE_CHUNK_CHARS = max(8000, int(os.getenv("ARTIFACT_CHUNK_CHARS", "50000")))
# Upper bound on map calls per file. If reduced content needs more chunks than this, chunks are
# sampled at EVEN POSITIONS across the file (always incl. first + last) — a positional bound, not a
# content pattern, so no region is preferentially dropped.
_MAP_REDUCE_MAX_CHUNKS = max(2, int(os.getenv("ARTIFACT_MAX_CHUNKS", "12")))
_ARTIFACT_KEYWORD_EXTRACTION = os.getenv("ARTIFACT_KEYWORD_EXTRACTION", "0").strip().lower() in ("1", "true", "yes", "on")
# Diff-vs-previous-run (opt-in via ARTIFACT_DIFF_SUMMARY in handlers): only use the delta when the
# changed lines are at most this fraction of the file (else the file changed too much to be worth it).
_ARTIFACT_DIFF_MAX_RATIO = float(os.getenv("ARTIFACT_DIFF_MAX_RATIO", "0.6"))
_DELTA_NOTE = "Summarised only the lines that changed since the previous run of this file."
# Build failure-section extraction (token saver). Default ON. The build orchestration log is Apache
# Ant / CESSAR-CT (Artop): a long run of successful targets/generators, then a terminal "BUILD FAILED"
# block. We keep only that failure block (which names the failing generator and the *_errors.log to
# read) and drop the successful bulk + the Java framework stack trace. Uses the build engine's OWN
# terminal markers, not generic keyword guessing. Toggle: ARTIFACT_BUILD_FAILURE_EXTRACT.
# OFF by default: we no longer force a build-failure pattern search to cut the log. Basic noise/
# timestamp stripping stays, and the changed-content diff keeps only what changed vs the previous
# run. Set ARTIFACT_BUILD_FAILURE_EXTRACT=1 to re-enable the pattern cut.
_ARTIFACT_BUILD_FAILURE_EXTRACT = os.getenv("ARTIFACT_BUILD_FAILURE_EXTRACT", "0").strip().lower() in ("1", "true", "yes", "on")
_FAILURE_NOTE = ("Kept only the build failure section (BUILD FAILED + the generator error block); "
                 "successful build output and the Java stack trace were omitted to save tokens.")
_ANT_BUILD_FAILED_RE = re.compile(r"^\s*BUILD FAILED\b")
_ANT_ERROR_ECHO_RE = re.compile(r"An error occurred during execution")
_ANT_STACKFRAME_RE = re.compile(r"^\s*(?:at\s+\S|\.\.\.\s*\d+\s+more\b)")
_ANT_FAILURE_MARGIN_BEFORE = 8

# Opt-in keyword markers (only used when ARTIFACT_KEYWORD_EXTRACTION=1).
_FAILURE_MARKER_RE = re.compile(
    r"error|fail|fatal|exception|caused by|#####|cannot|could not|not found|missing|undefined"
    r"|denied|abort|invalid|refused|build failed|what went wrong|finished with errors"
    r"|\[mod\]|\[add\]|\[del\]|\bchanged\b",
    re.I,
)
_STACK_FRAME_RE = re.compile(r"^\s*(at\s+[\w$.<>/\[\]]+\(|\.\.\.\s*\d+\s+more)")
_COMPRESS_CTX_BEFORE = max(10, int(os.getenv("ARTIFACT_COMPRESS_CONTEXT_BEFORE", "10")))
_COMPRESS_CTX_AFTER = max(5, int(os.getenv("ARTIFACT_COMPRESS_CONTEXT_AFTER", "25")))

# Shared summariser prompt (single-call path AND the map-reduce 'reduce' step use the same contract).
_SUMMARY_SYSTEM = (
    "You summarize build/runtime artifacts for semantic retrieval. "
    "Focus only on information that identifies WHY a build failed and WHAT specifically failed. "
    "Exclude completely: port numbers, process IDs, memory addresses, timestamps, "
    "absolute file paths, environment variable values, tool version strings, "
    "system configuration details, and any numeric IDs unrelated to the error. "
    "Include only: file names mentioned in failures, process or task names that failed, "
    "missing files or dependencies, configuration keys directly causing the failure, "
    "and specific error codes or exception names."
)
_SUMMARY_SECTIONS = (
    "Output plain text bullets under these sections only — skip any section with no relevant content:\n"
    "- Error Signals: specific errors, exceptions, or failure indicators\n"
    "- Missing or Failing Components: file names, modules, or processes that are absent or broken\n"
    "- Root Cause Clues: configuration or dependency issues that explain the failure\n"
    "- Key Evidence: facts that would help match this scenario to a future similar failure\n"
    "Keep under 200 words. Omit any line that contains only system metadata."
)
# 'Map' step: the model reads ONE chunk of a larger log and pulls failure facts (or says NONE).
_MAP_SYSTEM = (
    "You are reading ONE PART of a larger build/runtime log that ended in a failure. "
    "Extract only failure-relevant facts from THIS part: specific errors, exceptions, missing or "
    "broken files / modules / processes, and configuration or dependency problems. "
    "Ignore success and progress noise. "
    "If this part contains no failure-relevant information, reply with exactly: NONE"
)


def _structural_reduce(text: str) -> str:
    """Format-AGNOSTIC size reduction only: stack-trace compaction + exact duplicate-line collapse.
    No content patterns decide what is important. When ARTIFACT_KEYWORD_EXTRACTION=1 (opt-in), it
    additionally keeps only marker-flagged regions + head/tail — but the default path never does."""
    lines = text.replace("\r", "").split("\n")

    # 1) Stack-trace compaction: keep the first 3 frames of each run, collapse the rest.
    compacted: List[str] = []
    frame_run = 0
    for ln in lines:
        if _STACK_FRAME_RE.match(ln):
            frame_run += 1
            if frame_run <= 3:
                compacted.append(ln)
            elif frame_run == 4:
                compacted.append("    ... [stack frames compacted]")
        else:
            frame_run = 0
            compacted.append(ln)

    # 2) Duplicate-line collapse: identical (non-trivial) lines kept once, annotated with a count.
    first_seen: dict = {}
    dup_counts: dict = {}
    kept: List[str] = []
    for ln in compacted:
        key = ln.strip()
        if len(key) > 15:
            if key in first_seen:
                dup_counts[first_seen[key]] = dup_counts.get(first_seen[key], 1) + 1
                continue
            first_seen[key] = len(kept)
        kept.append(ln)
    lines = [
        f"{ln}   [repeated x{dup_counts[i]}]" if i in dup_counts else ln
        for i, ln in enumerate(kept)
    ]

    if not _ARTIFACT_KEYWORD_EXTRACTION:
        return "\n".join(lines)

    # OPT-IN ONLY: keyword-marker failure-block extraction (head/tail + windows around markers).
    n = len(lines)
    head, tail = 30, 60
    selected = [False] * n
    for i in range(min(head, n)):
        selected[i] = True
    for i in range(max(0, n - tail), n):
        selected[i] = True
    for i, ln in enumerate(lines):
        if _FAILURE_MARKER_RE.search(ln):
            for j in range(max(0, i - _COMPRESS_CTX_BEFORE), min(n, i + _COMPRESS_CTX_AFTER + 1)):
                selected[j] = True
    parts: List[str] = []
    skipped = 0
    for i, ln in enumerate(lines):
        if selected[i]:
            if skipped:
                parts.append(f"... [skipped {skipped} lines] ...")
                skipped = 0
            parts.append(ln)
        else:
            skipped += 1
    if skipped:
        parts.append(f"... [skipped {skipped} lines] ...")
    return "\n".join(parts)


def _split_into_chunks(text: str, chunk_chars: int, max_chunks: int) -> List[str]:
    """Split on line boundaries into <= chunk_chars pieces. If more than max_chunks result, keep an
    EVENLY-SPACED sample across the file (always first + last) — positional, not content-based."""
    chunks: List[str] = []
    cur: List[str] = []
    cur_len = 0
    for ln in text.split("\n"):
        add = len(ln) + 1
        if cur and cur_len + add > chunk_chars:
            chunks.append("\n".join(cur))
            cur, cur_len = [], 0
        cur.append(ln)
        cur_len += add
    if cur:
        chunks.append("\n".join(cur))
    if len(chunks) <= max_chunks:
        return chunks
    step = (len(chunks) - 1) / (max_chunks - 1)
    idxs = sorted({round(i * step) for i in range(max_chunks)})
    return [chunks[i] for i in idxs]


# Offline tokenizer for RECOMPUTING token counts without calling the LLM (used by the token-audit
# backfill for already-summarised files). tiktoken is optional: if absent we fall back to a ~4
# chars/token estimate and flag the audit as approximate.
try:  # pragma: no cover - import guard
    import tiktoken as _tiktoken
    try:
        _TOKEN_ENC = _tiktoken.get_encoding("o200k_base")
    except Exception:
        _TOKEN_ENC = _tiktoken.get_encoding("cl100k_base")
except Exception:
    _TOKEN_ENC = None

TOKEN_BASIS = "tiktoken" if _TOKEN_ENC is not None else "approx"


def _count_tokens(text: str) -> int:
    s = str(text or "")
    if _TOKEN_ENC is not None:
        try:
            return len(_TOKEN_ENC.encode(s))
        except Exception:
            pass
    return max(0, round(len(s) / 4))  # heuristic fallback (~4 chars/token)


def _token_step(label: str, usage: dict) -> dict:
    """One row of the per-artifact token audit: input (prompt) / output (completion) / total tokens."""
    u = usage or {}
    return {
        "step": label,
        "input": int(u.get("prompt_tokens", 0) or 0),
        "output": int(u.get("output_tokens", 0) or 0),
        "total": int(u.get("total_tokens", 0) or 0),
    }


def _build_token_audit(mode: str, original_chars: int, reduced_chars: int,
                       steps: List[dict], total: dict, source: str = "live") -> dict:
    """Store the RAW per-artifact token data only. The dashboard presentation (the flat `tags` list)
    is built at API time from this — see handlers._token_usage_view — so the stored shape stays
    stable and the UI shape can change with NO re-store. `source` = "live" | "recomputed"."""
    oc = int(original_chars or 0)
    rc = int(reduced_chars or 0)
    reduced_pct = int(round((1 - rc / oc) * 100)) if oc > 0 and rc <= oc else 0
    pt = int((total or {}).get("prompt_tokens", 0) or 0)
    ot = int((total or {}).get("output_tokens", 0) or 0)
    tt = int((total or {}).get("total_tokens", 0) or 0)
    return {
        "mode": mode,
        "source": source,
        "input_chars": {"original": oc, "after_reduction": rc, "reduced_pct": reduced_pct},
        "steps": steps or [],
        "totals": {"input": pt, "output": ot, "total": tt},
    }


def _map_reduce_summarize(file_name: str, chunks: List[str], request_id) -> tuple[str, dict, list]:
    """Pattern-free summary of content larger than one call: the model reads EVERY chunk and pulls
    the failure facts (map), then those partials are merged into the final structured summary
    (reduce). Relevance is judged by the model on the real content, not by any regex.
    Returns (summary, total_usage, per_step_audit)."""
    fname = str(file_name or "").strip()
    total = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    steps: List[dict] = []

    def _accum(usage):
        for k in total:
            total[k] += int((usage or {}).get(k, 0) or 0)

    partials: List[str] = []
    for idx, chunk in enumerate(chunks, start=1):
        user = f"Artifact file name: {fname}\nPart {idx} of {len(chunks)}.\n\n{chunk[:_MAP_REDUCE_CHUNK_CHARS]}"
        content, usage = create_chat_completion(
            user_message=user, system_message=_MAP_SYSTEM, rate_limit_retries=_SUMMARY_RATE_LIMIT_RETRIES,
        )
        _accum(usage)
        steps.append(_token_step(f"Stage {idx}", usage))
        facts = str(content or "").strip()
        if facts and facts.upper() != "NONE":
            partials.append(f"[part {idx}] {facts}")

    logger.info("artifact map-reduce | file=%s | chunks=%d | parts_with_findings=%d", fname, len(chunks), len(partials))
    if not partials:
        return "", total, steps

    combined = "\n".join(partials)[:_ARTIFACT_SUMMARY_INPUT_CHARS]
    content, usage = create_chat_completion(
        user_message=(
            f"Artifact file name: {fname}\n\n"
            "Below are failure-relevant facts extracted from consecutive parts of ONE large build "
            "log. Merge them into a single summary and remove duplicate points.\n"
            f"{_SUMMARY_SECTIONS}\n\nExtracted facts:\n{combined}"
        ),
        system_message=_SUMMARY_SYSTEM, rate_limit_retries=_SUMMARY_RATE_LIMIT_RETRIES,
    )
    _accum(usage)
    steps.append(_token_step("Combine", usage))
    return str(content or "").strip(), total, steps

# Deterministic "save context + clean data" pre-strip, applied BEFORE the summariser/LLM. Removes
# ONLY pure volatile noise that is never the failure signal (timestamps, memory addresses, labelled
# PIDs) — these appear on nearly every log line, so stripping them up front shrinks the prompt and
# gives the model clean input. Context-dependent items (tool versions, environment values,
# connection names, config) are intentionally NOT stripped here — they can BE the error, so the LLM
# prompt decides those in context. Disable via STRIP_VOLATILE_NOISE=0.
_NOISE_STRIP_PATTERNS = [
    # Java-style log timestamps: "Jun 10, 2026 11:03:16 PM"
    (re.compile(r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\s+\d{1,2},\s+\d{4}\s+\d{1,2}:\d{2}:\d{2}\s*(?:am|pm)?\b", re.I), ""),
    # ISO timestamps: YYYY-MM-DDTHH:MM:SS(.fff)(Z|+HH:MM)
    (re.compile(r"\b\d{4}-\d{2}-\d{2}[ tT]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:z|[+-]\d{2}:\d{2})?\b", re.I), ""),
    # bare clock times: 23:03:16(.123)
    (re.compile(r"\b\d{1,2}:\d{2}:\d{2}(?:\.\d+)?\b"), ""),
    # memory / hex addresses: 0xDEADBEEF
    (re.compile(r"\b0x[0-9a-fA-F]{4,}\b"), "<addr>"),
    # labelled process ids: "PID 16236", "process id: 16236"
    (re.compile(r"\b(pid|process[ _-]?id)\b\s*[:=]?\s*\d+", re.I), r"\1 <pid>"),
]


def _strip_volatile_noise(text: str) -> str:
    if os.getenv("STRIP_VOLATILE_NOISE", "1").strip().lower() in ("0", "false", "no", "off"):
        return str(text or "")
    s = str(text or "")
    for pat, repl in _NOISE_STRIP_PATTERNS:
        s = pat.sub(repl, s)
    # Collapse the gaps left behind so we actually save context.
    s = re.sub(r"[ \t]{2,}", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s

# LLM prompts must stay bounded for truly huge logs, but the OLD 1,500+1,500 head/tail dropped the
# MIDDLE of the error — which can hold the one distinguishing line between two otherwise-similar
# failures, so the LLM pick could not tell them apart. gpt-5-nano's context is large and noise is
# now pre-stripped, so we keep far more: errors up to ~16,000 chars go to the LLM WHOLE (middle
# included); only genuinely huge logs are trimmed. NOTE: search/RRF already embeds the FULL error —
# this budget only governs the LLM analysis/selection prompt.
_PROMPT_ERROR_HEAD = max(500, int(os.getenv("PROMPT_ERROR_HEAD_CHARS", "8000")))
_PROMPT_ERROR_TAIL = max(500, int(os.getenv("PROMPT_ERROR_TAIL_CHARS", "8000")))

# Length of each RRF evidence preview shown to the LLM. 300 chars was too short to reveal the
# distinguishing MIDDLE of two near-identical historical errors, so the selection couldn't tell
# them apart. Raised so the model sees enough of each evidence item. Tunable via PROMPT_EVIDENCE_CHARS.
_PROMPT_EVIDENCE_CHARS = max(300, int(os.getenv("PROMPT_EVIDENCE_CHARS", "4000")))


def _trim_error_for_prompt(text: str) -> str:
    # Strip pure volatile noise (timestamps/addresses/PIDs) first — saves context and cleans the
    # error before the LLM, while keeping error-relevant config/version/env for the model to judge.
    s = _strip_volatile_noise(str(text or ""))
    if len(s) <= _PROMPT_ERROR_HEAD + _PROMPT_ERROR_TAIL + 64:
        return s
    return s[:_PROMPT_ERROR_HEAD] + "\n… [error trimmed for length] …\n" + s[-_PROMPT_ERROR_TAIL:]


def _resolve_request_id(request_id: str | None) -> str | None:
    if request_id:
        return request_id
    if has_request_context():
        return getattr(g, "request_id", None)
    return None



# ---------------------------------------------------------------- the model's input limit
# The embedding model accepts a bounded number of TOKENS per input (text-embedding-3-*: 8191).
# Characters are not tokens: measured on a GBE build log, 28,000 characters were 9,247 tokens,
# so a character budget sized "safely" by prose was over the limit for every real log, the call
# was rejected, and the shrink-and-retry below embedded only the tail. The budget is therefore
# counted in tokens - exactly (tiktoken, the tokenizer these models use) when it is installed,
# otherwise by a deliberately conservative characters-per-token estimate - and text over the
# limit is CHUNKED on line boundaries so every part of an error message is embedded, never cut.
_EMBEDDING_MODEL_MAX_TOKENS = max(256, int(os.getenv("EMBEDDING_MODEL_MAX_TOKENS", "8191")))
_EMBEDDING_TOKEN_MARGIN = max(0, int(os.getenv("EMBEDDING_TOKEN_MARGIN", "191")))
# Fallback only. 2.5 is below anything measured on a build log (3.03), so the estimate errs
# towards MORE tokens and a chunk sized by it stays inside the real limit.
_EMBEDDING_CHARS_PER_TOKEN = max(1.0, float(os.getenv("EMBEDDING_CHARS_PER_TOKEN", "2.5")))
_token_encoder = None
_token_encoder_tried = False


def embedding_token_budget() -> int:
    """The most tokens one embedded input may hold: the model limit less a safety margin."""
    return max(64, _EMBEDDING_MODEL_MAX_TOKENS - _EMBEDDING_TOKEN_MARGIN)


def _encoder():
    global _token_encoder, _token_encoder_tried
    if not _token_encoder_tried:
        _token_encoder_tried = True
        try:
            import tiktoken  # optional: exact counts when present
            _token_encoder = tiktoken.get_encoding("cl100k_base")
        except Exception:
            _token_encoder = None
            logger.info("tiktoken not installed - embedding budgets use the %.2f chars/token "
                        "estimate (install tiktoken for exact counts)", _EMBEDDING_CHARS_PER_TOKEN)
    return _token_encoder


def embedding_token_count(text: str) -> int:
    """Tokens the embedding model will see for `text`: exact with tiktoken, else a conservative
    estimate (rounded up, never under)."""
    s = str(text or "")
    if not s:
        return 0
    enc = _encoder()
    if enc is not None:
        return len(enc.encode(s, disallowed_special=()))
    return int(-(-len(s) // _EMBEDDING_CHARS_PER_TOKEN))


def _split_long_line(line: str, max_tokens: int) -> List[str]:
    """A single line over the budget is split into budget-sized pieces (exactly, by tokens, when
    the tokenizer is present; by the estimate otherwise). Nothing is dropped."""
    if embedding_token_count(line) <= max_tokens:
        return [line]
    enc = _encoder()
    if enc is not None:
        ids = enc.encode(line, disallowed_special=())
        return [enc.decode(ids[i:i + max_tokens]) for i in range(0, len(ids), max_tokens)]
    step = max(1, int(max_tokens * _EMBEDDING_CHARS_PER_TOKEN))
    return [line[i:i + step] for i in range(0, len(line), step)]


def _joined_tokens(lines) -> int:
    """Exact token count of the form the embedder sends: the lines joined with " | "."""
    return embedding_token_count(" | ".join(lines))


def chunk_text_by_tokens(text: str, max_tokens: int | None = None) -> List[str]:
    """Split `text` on line boundaries into pieces that each fit the token budget, keeping every
    line in order. Counted on the PREPARED form (whitespace collapsed, lines joined with " | ")
    because that is what the embedder sends, and VERIFIED exactly on the joined chunk - per-line
    counts plus a separator estimate came out ~1 token per line short on a real log, which is
    enough to push a 285-line chunk over the limit. A text within budget comes back whole."""
    budget = embedding_token_budget() if max_tokens is None else max(64, int(max_tokens))
    raw = str(text or "").replace("\r", "")
    if embedding_token_count(raw) <= budget:
        return [raw] if raw.strip() else []
    prepared: List[str] = []
    for line in raw.split("\n"):
        p = re.sub(r"\s+", " ", line).strip()
        if p:
            prepared.extend(_split_long_line(p, budget))
    chunks: List[str] = []
    current: List[str] = []
    size = 0
    i = 0
    while i < len(prepared):
        piece = prepared[i]
        cost = embedding_token_count((" | " if current else "") + piece)
        if current and size + cost > budget:
            # Close the chunk, verified on the exact joined form; give back lines until it fits.
            while len(current) > 1 and _joined_tokens(current) > budget:
                i -= 1
                current.pop()
            chunks.append("\n".join(current))
            current, size = [], 0
            continue
        current.append(piece)
        size += cost
        i += 1
    if current:
        while len(current) > 1 and _joined_tokens(current) > budget:
            chunks.append("\n".join(current[:-1]))
            current = current[-1:]
        chunks.append("\n".join(current))
    return chunks


def _prepare_text_for_embedding(
    text: str,
    max_chars: int | None = None,
    max_lines: int | None = None,
    max_tokens: int | None = None,
) -> str:
    # Defaults preserve existing behavior; callers (e.g. the error path in block
    # mode) may pass a larger budget so genuine multi-line errors are not truncated.
    #
    # OVER BUDGET, THE END IS KEPT. Build logs put the failure LAST: the command line, the
    # interpreter path and the input files open every log, and the error sits at the bottom.
    # Keeping the FIRST N lines / chars embedded the preamble every build shares and dropped
    # the one part that identified the failure - measured on a 100-step log, the query vector
    # held 1,500 chars of progress chatter and not the error line at all. A text under budget
    # is untouched, nothing is reordered, and no marker decides which lines count.
    # None = the embedder's defaults; 0 = NO cap of that kind (the token budget alone decides,
    # which is what the error path in block mode asks for so nothing of a message is dropped).
    cap_chars = _EMBEDDING_MAX_CHARS if max_chars is None else (0 if int(max_chars) <= 0 else max(200, int(max_chars)))
    cap_lines = _EMBEDDING_MAX_LINES if max_lines is None else (0 if int(max_lines) <= 0 else max(5, int(max_lines)))
    cap_tokens = embedding_token_budget() if max_tokens is None else max(64, int(max_tokens))
    raw = (text or "").replace("\r", "")
    compact_lines: List[str] = []

    for line in raw.split("\n"):
        s = re.sub(r"\s+", " ", line).strip()
        if not s:
            continue
        # Drop noisy Java stack trace lines that add tokens but little semantic value.
        if s.startswith("at ") or s.startswith("... "):
            continue
        compact_lines.append(s)

    if not compact_lines:
        compact = re.sub(r"\s+", " ", raw.replace("\n", " ")).strip()
        if cap_chars and len(compact) > cap_chars:
            compact = compact[-cap_chars:]
        return _fit_tokens_from_end(compact, cap_tokens)

    if cap_lines and len(compact_lines) > cap_lines:
        compact_lines = compact_lines[-cap_lines:]

    compact = " | ".join(compact_lines)
    if not cap_chars or len(compact) <= cap_chars:
        return _fit_lines_from_end(compact_lines, compact, cap_tokens)

    # Over the character budget: the LAST whole lines that fit, in their original order.
    kept: List[str] = []
    size = 0
    for s in reversed(compact_lines):
        add = len(s) + (3 if kept else 0)  # 3 = the " | " separator
        if size + add > cap_chars:
            break
        kept.append(s)
        size += add
    if kept:
        kept.reverse()
        return _fit_lines_from_end(kept, " | ".join(kept), cap_tokens)
    # The final line alone is over budget: keep its end, which is where the message is.
    return _fit_tokens_from_end(compact[-cap_chars:], cap_tokens)


def _fit_lines_from_end(lines: List[str], joined: str, cap_tokens: int) -> str:
    """The token limit is the model's, not ours: a text the store chunked correctly fits it
    already, so this is a guard for callers that did not chunk (legacy defaults, artifacts). Over
    the limit, the LAST whole lines that fit are kept, in order - the failure is at the end."""
    if embedding_token_count(joined) <= cap_tokens:
        return joined
    kept: List[str] = []
    size = 0
    for s in reversed(lines):
        cost = embedding_token_count((" | " if kept else "") + s)
        if size + cost > cap_tokens:
            break
        kept.append(s)
        size += cost
    kept.reverse()
    # Verified on the exact joined form: drop from the FRONT until it fits (the failure is at the end).
    while len(kept) > 1 and _joined_tokens(kept) > cap_tokens:
        kept.pop(0)
    if kept and _joined_tokens(kept) <= cap_tokens:
        return " | ".join(kept)
    return _fit_tokens_from_end(lines[-1], cap_tokens)


def _fit_tokens_from_end(text: str, cap_tokens: int) -> str:
    """One piece of text cut to the token budget from the FRONT, so its end survives."""
    if embedding_token_count(text) <= cap_tokens:
        return text
    enc = _encoder()
    if enc is not None:
        ids = enc.encode(text, disallowed_special=())
        return enc.decode(ids[-cap_tokens:])
    return text[-int(cap_tokens * _EMBEDDING_CHARS_PER_TOKEN):]


def create_embeddings_batch(
    texts: List[str],
    request_id: str | None = None,
    max_chars: int | None = None,
    max_lines: int | None = None,
    max_tokens: int | None = None,
) -> List[List[float]]:
    """
    Create embeddings in a single API call.
    """
    if not texts:
        return []

    rid = _resolve_request_id(request_id)
    start = time.perf_counter()
    # Char budget for this call. The model limit is token-based, so on a
    # context-length rejection we shrink this and retry rather than fail the job.
    work_max_chars = max_chars
    clean_inputs = [
        _prepare_text_for_embedding(t or "", max_chars=work_max_chars, max_lines=max_lines,
                                    max_tokens=max_tokens)
        for t in texts
    ]

    last_exc: Exception | None = None
    for attempt in range(1, _EMBEDDING_MAX_RETRIES + 1):
        try:
            response = _client.embeddings.create(
                input=clean_inputs,
                model=config.EMBEDDING_MODEL,
                timeout=_EMBEDDING_TIMEOUT,
            )
            duration_ms = int((time.perf_counter() - start) * 1000)
            logger.info(
                "Embedding ok",
                extra={"request_id": rid, "duration_ms": duration_ms, "text_count": len(clean_inputs)},
            )
            return [row.embedding for row in response.data]
        except Exception as exc:
            last_exc = exc
            is_rate_limited = isinstance(exc, RateLimitError) or "429" in str(exc) or "Too Many Requests" in str(exc)
            if is_rate_limited and attempt < _EMBEDDING_MAX_RETRIES:
                sleep_sec = (_EMBEDDING_RETRY_BASE_SEC * (2 ** (attempt - 1))) + random.uniform(0.0, 0.25)
                duration_ms = int((time.perf_counter() - start) * 1000)
                logger.warning(
                    "Embedding rate-limited, retrying",
                    extra={
                        "request_id": rid,
                        "duration_ms": duration_ms,
                        "text_count": len(clean_inputs),
                        "attempt": attempt,
                    },
                )
                time.sleep(sleep_sec)
                continue
            # Graceful degradation: input exceeds the model's token limit. Halve the
            # char budget and retry so a large error still stores (truncated) instead
            # of failing the whole request's vectorization.
            if _is_context_length_error(exc) and attempt < _EMBEDDING_MAX_RETRIES:
                longest = max((len(t) for t in clean_inputs), default=0)
                new_cap = max(_EMBEDDING_MIN_CHARS, longest // 2)
                if longest > _EMBEDDING_MIN_CHARS and new_cap < longest:
                    logger.warning(
                        "Embedding input too long, shrinking and retrying",
                        extra={
                            "request_id": rid,
                            "text_count": len(clean_inputs),
                            "attempt": attempt,
                            "prev_max_chars": longest,
                            "new_max_chars": new_cap,
                        },
                    )
                    work_max_chars = new_cap
                    clean_inputs = [
                        _prepare_text_for_embedding(t or "", max_chars=work_max_chars, max_lines=max_lines,
                                                    max_tokens=max_tokens)
                        for t in texts
                    ]
                    continue
            break

    duration_ms = int((time.perf_counter() - start) * 1000)
    logger.exception(
        "Embedding failed",
        extra={"request_id": rid, "duration_ms": duration_ms, "text_count": len(clean_inputs)},
    )
    raise RuntimeError(
        f"Embedding request failed after {duration_ms} ms (request_id={rid})"
    ) from last_exc


def create_embedding(
    text: str,
    request_id: str | None = None,
    max_chars: int | None = None,
    max_lines: int | None = None,
    max_tokens: int | None = None,
) -> List[float]:
    """
    Backward-compatible single-item embedding helper.
    """
    embeddings = create_embeddings_batch(
        [text], request_id=request_id, max_chars=max_chars, max_lines=max_lines,
        max_tokens=max_tokens,
    )
    return embeddings[0] if embeddings else []


def create_chat_completion(
    user_message: str,
    system_message: str = "You are an AI assistant",
    rate_limit_retries: int | None = None,
) -> tuple[str, dict]:
    """
    Create chat completion using Azure OpenAI.
    Returns (content, token_usage) where token_usage has keys:
    prompt_tokens, output_tokens, total_tokens, tokens_used.
    """
    # max_retries=0: do NOT let the client retry a slow/timed-out chat call — that just doubles
    # the wait (60s -> 120s). Fail fast and let the caller degrade gracefully (the recommendation
    # has its own single retry + graceful fallback). The dedicated chat timeout bounds one attempt.
    # EXCEPTION: 429 rate-limit rejections are instant, so they ARE retried below with backoff —
    # under production bursts a 429 must not become lost data.
    # max_completion_tokens + low reasoning_effort keep the reasoning model (gpt-5-nano) fast and
    # bounded so it doesn't "think" for minutes and time out.
    _chat_kwargs = dict(
        model=config.DEFAULT_MODEL,
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_message},
        ],
        seed=42,
        timeout=_CHAT_TIMEOUT,
        max_completion_tokens=_CHAT_MAX_COMPLETION_TOKENS,
    )
    if _CHAT_REASONING_EFFORT in ("minimal", "low", "medium", "high"):
        _chat_kwargs["reasoning_effort"] = _CHAT_REASONING_EFFORT

    attempts = (_CHAT_RATE_LIMIT_RETRIES if rate_limit_retries is None else max(0, int(rate_limit_retries))) + 1
    response = None
    for attempt in range(1, attempts + 1):
        try:
            response = _client.with_options(max_retries=0).chat.completions.create(**_chat_kwargs)
            break
        except RateLimitError as exc:
            if attempt >= attempts:
                logger.error("chat completion rate-limited (429) — retries exhausted (%d attempts)", attempts)
                raise
            delay = _rate_limit_delay_sec(exc, attempt)
            logger.warning(
                "chat completion rate-limited (429) — retrying in %.1fs (attempt %d/%d)",
                delay, attempt, attempts,
            )
            time.sleep(delay)

    usage = response.usage
    token_usage = {
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
        "output_tokens": getattr(usage, "completion_tokens", 0) or 0,
        "total_tokens": getattr(usage, "total_tokens", 0) or 0,
    }
    return response.choices[0].message.content, token_usage


def analyze_errors_and_solutions(
    errors: List[Dict],
    solutions: List[Dict],
    request_id: str | None = None,
) -> tuple[str, dict]:
    """
    Send build errors and historical solutions to the LLM and return a meaningful
    analysis: root cause explanation, why historical solutions worked, and a
    specific recommended action for the developer.

    Returns (analysis_text, token_usage) where token_usage has keys:
    prompt_tokens, completion_tokens, total_tokens.
    Returns ("", zero_usage) if LLM analysis is disabled or no errors are provided.
    """
    rid = _resolve_request_id(request_id)

    logger.debug(
        "analyze_errors_and_solutions | start | request_id=%s | error_count=%d | solution_count=%d",
        rid, len(errors or []), len(solutions or []),
    )

    _empty_usage: dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    if not getattr(config, "LLM_ANALYSIS_ENABLED", True):
        logger.debug(
            "analyze_errors_and_solutions | skipped | reason=LLM_ANALYSIS_ENABLED=false | request_id=%s", rid,
        )
        return "", _empty_usage

    error_lines: List[str] = []
    for err in (errors or []):
        if not isinstance(err, dict):
            logger.debug(
                "analyze_errors_and_solutions | skipping non-dict error item | type=%s | request_id=%s",
                type(err).__name__, rid,
            )
            continue
        msg = _trim_error_for_prompt(str(err.get("message") or err.get("problemDetails") or "").strip())
        if msg:
            error_lines.append(f"- {msg}")

    logger.debug(
        "analyze_errors_and_solutions | extracted_error_lines=%d | request_id=%s",
        len(error_lines), rid,
    )

    if not error_lines:
        logger.debug(
            "analyze_errors_and_solutions | skipped | reason=no_extractable_error_messages | request_id=%s", rid,
        )
        return "", _empty_usage

    solution_lines: List[str] = []
    capped_solutions = (solutions or [])[:3]
    logger.debug(
        "analyze_errors_and_solutions | packing solutions | total_available=%d | capped_to=%d | request_id=%s",
        len(solutions or []), len(capped_solutions), rid,
    )
    for idx, sol in enumerate(capped_solutions, start=1):
        if not isinstance(sol, dict):
            logger.debug(
                "analyze_errors_and_solutions | skipping non-dict solution idx=%d | request_id=%s", idx, rid,
            )
            continue
        req_id = str(sol.get("request_id") or sol.get("batch_id") or "").strip()
        items = sol.get("solution") or []
        if not isinstance(items, list):
            items = []
        sol_parts: List[str] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            fp = str(item.get("filePath") or item.get("fileName") or "").strip()
            changes = item.get("changes") or []
            if not isinstance(changes, list):
                changes = []
            for ch in changes:
                ch_text = str(ch or "").strip()
                if ch_text:
                    sol_parts.append(f"  File: {fp} | Change: {ch_text}")
        if sol_parts:
            solution_lines.append(f"Historical Solution {idx} (request_id={req_id or 'N/A'}):")
            solution_lines.extend(sol_parts)
            logger.debug(
                "analyze_errors_and_solutions | packed_solution | idx=%d | sol_request_id=%s | change_lines=%d | request_id=%s",
                idx, req_id or "N/A", len(sol_parts), rid,
            )
        else:
            logger.debug(
                "analyze_errors_and_solutions | solution idx=%d has no packable changes | sol_request_id=%s | request_id=%s",
                idx, req_id or "N/A", rid,
            )

    errors_block = "\n".join(error_lines)
    solutions_block = (
        "\n".join(solution_lines) if solution_lines else "No historical solutions found."
    )

    logger.debug(
        "analyze_errors_and_solutions | prompt_built | request_id=%s | errors_chars=%d | solutions_chars=%d | has_solution_context=%s",
        rid, len(errors_block), len(solutions_block), bool(solution_lines),
    )

    system_message = (
        "You are a senior build engineer speaking directly to the developer. "
        "Start with what to fix and where — be specific, name the file or config if visible. "
        "One sentence why it failed. One sentence to confirm it is fixed. "
        "Maximum 3 sentences total. No headers, no bullets, no preamble."
    )
    user_message = (
        f"Build Errors:\n{errors_block}\n\n"
        f"Historical Solutions:\n{solutions_block}\n\n"
        "Provide your analysis."
    )

    logger.debug(
        "analyze_errors_and_solutions | calling LLM | model=%s | request_id=%s",
        config.DEFAULT_MODEL, rid,
    )
    start = time.perf_counter()
    try:
        result, token_usage = create_chat_completion(user_message=user_message, system_message=system_message)
        duration_ms = int((time.perf_counter() - start) * 1000)
        analysis_len = len(result or "")
        logger.info(
            "analyze_errors_and_solutions | LLM call ok | request_id=%s | duration_ms=%d | analysis_chars=%d"
            " | prompt_tokens=%d | output_tokens=%d | total_tokens=%d",
            rid, duration_ms, analysis_len,
            token_usage["prompt_tokens"], token_usage["output_tokens"], token_usage["total_tokens"],
        )
        logger.debug(
            "analyze_errors_and_solutions | analysis_preview | request_id=%s | preview=%.300s",
            rid, (result or "").replace("\n", " "),
        )
        return result or "", token_usage
    except Exception as exc:
        duration_ms = int((time.perf_counter() - start) * 1000)
        logger.warning(
            "analyze_errors_and_solutions | LLM call failed | request_id=%s | duration_ms=%d | error=%s",
            rid, duration_ms, str(exc),
        )
        return "", _empty_usage


def _compact_context_hits(items: List[Dict], *, limit: int = 3) -> List[Dict[str, str]]:
    compact: List[Dict[str, str]] = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        compact.append(
            {
                "file_name": str(item.get("file_name") or "").strip(),
                "request_id": str(item.get("request_id") or "").strip(),
                "batch_id": str(item.get("batch_id") or "").strip(),
                "artifact_type": str(item.get("artifact_type") or "").strip(),
                "distance": str(item.get("distance") if item.get("distance") is not None else "").strip(),
                "preview": str(item.get("preview") or item.get("document") or "").strip()[:450],
            }
        )
        if len(compact) >= max(1, int(limit)):
            break
    return compact


def _parse_json_object(text: str) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        pass

    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        try:
            parsed = json.loads(raw[start : end + 1])
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    return {}


def refine_recommendation_context(
    *,
    query_error: str,
    semantic_results: List[Dict],
    artifact_results: List[Dict],
    request_id: str | None = None,
) -> tuple[Dict[str, Any], dict]:
    rid = _resolve_request_id(request_id)
    empty_usage = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    empty_context: Dict[str, Any] = {
        "issue_summary": "",
        "contextual_findings": [],
        "recommended_actions": [],
        "possible_resolutions": [],
        "caveats": [],
    }

    query = str(query_error or "").strip()
    if not query:
        return empty_context, empty_usage

    doc_hits = _compact_context_hits(semantic_results, limit=3)
    artifact_hits = _compact_context_hits(artifact_results, limit=3)

    system_message = (
        "You are a build-troubleshooting context refiner. "
        "Given semantic knowledge hits and artifact hits, produce a concise JSON object only. "
        "Do not include markdown."
    )
    user_message = (
        "Return valid JSON with keys: issue_summary (string), contextual_findings (array of strings), "
        "recommended_actions (array of strings), possible_resolutions (array of strings), caveats (array of strings).\n\n"
        f"Primary error query:\n{query}\n\n"
        f"Semantic knowledge hits (top {len(doc_hits)}):\n{json.dumps(doc_hits, ensure_ascii=False)}\n\n"
        f"Artifact context hits (top {len(artifact_hits)}):\n{json.dumps(artifact_hits, ensure_ascii=False)}"
    )

    try:
        content, token_usage = create_chat_completion(user_message=user_message, system_message=system_message)
        parsed = _parse_json_object(content)
        if not parsed:
            return empty_context, token_usage
        return {
            "issue_summary": str(parsed.get("issue_summary") or "").strip(),
            "contextual_findings": [str(x).strip() for x in (parsed.get("contextual_findings") or []) if str(x).strip()][:6],
            "recommended_actions": [str(x).strip() for x in (parsed.get("recommended_actions") or []) if str(x).strip()][:6],
            "possible_resolutions": [str(x).strip() for x in (parsed.get("possible_resolutions") or []) if str(x).strip()][:6],
            "caveats": [str(x).strip() for x in (parsed.get("caveats") or []) if str(x).strip()][:4],
        }, token_usage
    except Exception:
        logger.exception("refine_recommendation_context | LLM context refinement failed | request_id=%s", rid)
        return empty_context, empty_usage


def analyze_errors_and_solutions_with_refined_context(
    *,
    errors: List[Dict],
    solutions: List[Dict],
    refined_context: Dict[str, Any] | None,
    request_id: str | None = None,
) -> tuple[str, dict]:
    rid = _resolve_request_id(request_id)
    _empty_usage: dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    if not getattr(config, "LLM_ANALYSIS_ENABLED", True):
        return "", _empty_usage

    error_lines: List[str] = []
    for err in errors or []:
        if not isinstance(err, dict):
            continue
        msg = _trim_error_for_prompt(str(err.get("message") or err.get("problemDetails") or "").strip())
        if msg:
            error_lines.append(f"- {msg}")

    if not error_lines:
        return "", _empty_usage

    solution_lines: List[str] = []
    for idx, sol in enumerate((solutions or [])[:3], start=1):
        if not isinstance(sol, dict):
            continue
        req_id = str(sol.get("request_id") or sol.get("batch_id") or "").strip()
        items = sol.get("solution") or []
        if not isinstance(items, list):
            items = []
        changes: List[str] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            fp = str(item.get("filePath") or item.get("fileName") or "").strip()
            raw_changes = item.get("changes") or []
            if not isinstance(raw_changes, list):
                raw_changes = []
            for ch in raw_changes:
                c = str(ch or "").strip()
                if c:
                    changes.append(f"  File: {fp} | Change: {c}")
        if changes:
            solution_lines.append(f"Historical Solution {idx} (request_id={req_id or 'N/A'}):")
            solution_lines.extend(changes)

    refined = refined_context if isinstance(refined_context, dict) else {}
    refined_block = json.dumps(
        {
            "issue_summary": str(refined.get("issue_summary") or "").strip(),
            "contextual_findings": refined.get("contextual_findings") or [],
            "recommended_actions": refined.get("recommended_actions") or [],
            "possible_resolutions": refined.get("possible_resolutions") or [],
            "caveats": refined.get("caveats") or [],
        },
        ensure_ascii=False,
    )

    system_message = (
        "You are a software build error analysis assistant. "
        "Use errors, historical solutions, and refined context to produce concise actionable guidance. "
        "Return plain text bullets in under 140 words."
    )
    user_message = (
        f"Build Errors:\n{'\n'.join(error_lines)}\n\n"
        f"Historical Solutions:\n{'\n'.join(solution_lines) if solution_lines else 'No historical solutions found.'}\n\n"
        f"Refined Context:\n{refined_block}\n\n"
        "Provide: root cause summary, most likely fix steps, and one validation checklist."
    )

    try:
        result, token_usage = create_chat_completion(user_message=user_message, system_message=system_message)
        return (result or "").strip(), token_usage
    except Exception:
        logger.exception("analyze_errors_and_solutions_with_refined_context | LLM call failed | request_id=%s", rid)
        return "", _empty_usage


def _changed_content(previous_text: str, current_text: str) -> str:
    """Return only the lines that are NEW or CHANGED in current vs previous (stdlib difflib, line
    level). Used by the opt-in diff-vs-previous-run path so large logs that barely change between
    runs are summarised from just the delta."""
    sm = difflib.SequenceMatcher(a=previous_text.splitlines(), b=current_text.splitlines(), autojunk=False)
    cur = current_text.splitlines()
    out: List[str] = []
    for tag, _i1, _i2, j1, j2 in sm.get_opcodes():
        if tag in ("replace", "insert"):
            out.extend(cur[j1:j2])
    return "\n".join(out)


def artifact_reduced_text_for_view(file_name: str, artifact_text: str, previous_text: str = "") -> str:
    """The text we KEEP for an artifact = basic noise/timestamp strip + changed-content vs the
    previous run (when available and smaller). Mirrors the pre-summary reduction for the diff view;
    read-only, no LLM call. The build-failure pattern cut is intentionally NOT applied here."""
    text = _strip_volatile_noise(str(artifact_text or "").strip())
    prev = _strip_volatile_noise(str(previous_text or "").strip())
    if prev and len(text) > _MAP_REDUCE_CHUNK_CHARS:
        changed = _changed_content(prev, text)
        if changed.strip() and len(changed) <= len(text) * _ARTIFACT_DIFF_MAX_RATIO:
            text = changed
    return text


def _looks_like_ant_build(text: str) -> bool:
    """True when the log is an Apache Ant / CESSAR-CT build log, so failure-section extraction can be
    applied. We only extract from FAILING builds (terminal 'BUILD FAILED'); other text skips it."""
    return ("BUILD FAILED" in text
            or "Build sequence for target(s)" in text
            or bool(re.search(r"^\s+\[(?:echo|mkdir|ant|antcall|copy|zip|move|property|delete)\]",
                              text, re.MULTILINE)))


def _extract_ant_failure_section(text: str) -> str:
    """Keep only the terminal failure block of an Ant/CESSAR build log and drop the (huge) successful
    output before it. Anchor = the tooling's 'An error occurred during execution' echo, else the
    'BUILD FAILED' line; keep from a small margin before that to the end. The Java framework stack
    trace (lines like 'at org.apache...' / '... 33 more') is dropped. What remains is the BUILD FAILED
    line, the nested ':<line>: error occurred' chain, and the '#####' generator-error blocks that name
    the failing generator and the *_errors.log to read. Returns "" when there is no failure marker."""
    lines = text.split("\n")
    n = len(lines)

    anchor = -1
    for i, ln in enumerate(lines):
        if _ANT_ERROR_ECHO_RE.search(ln):
            anchor = i
            break
    if anchor == -1:
        for i, ln in enumerate(lines):
            if _ANT_BUILD_FAILED_RE.match(ln):
                anchor = i
                break
    if anchor == -1:
        return ""  # no Ant failure marker -> caller keeps the full text

    start = max(0, anchor - _ANT_FAILURE_MARGIN_BEFORE)
    out: List[str] = []
    if start > 0:
        out.append("[... successful build output omitted ...]")
    dropped_run = False
    for ln in lines[start:]:
        if _ANT_STACKFRAME_RE.match(ln):
            if not dropped_run:
                out.append("\t[stack trace omitted]")
                dropped_run = True
            continue
        dropped_run = False
        out.append(ln)
    return "\n".join(out)


def summarize_artifact_content_for_embedding(
    *,
    file_name: str,
    artifact_text: str,
    request_id: str | None = None,
    previous_text: str = "",
) -> tuple[str, dict]:
    rid = _resolve_request_id(request_id)
    _empty_usage: dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    raw_text = str(artifact_text or "")
    text = raw_text.strip()
    if not text:
        return "", _empty_usage

    fname = str(file_name or "").strip()
    # Original size the client sees ("this file is N chars") — before any reduction.
    original_chars = len(raw_text)

    # Strip pure volatile noise (timestamps / addresses / PIDs) up front — saves context and gives
    # the summariser clean input. Error-relevant config/version/env is left for the prompt to judge.
    text = _strip_volatile_noise(text)

    # Build failure-section extraction (token saver). Keep only the terminal BUILD FAILED block of an
    # Ant/CESSAR build log and drop the successful bulk + Java stack trace. Self-gating: applies only
    # when a failure marker is present AND it actually shrinks the text; otherwise the full text is
    # kept, so nothing is lost for content that is not a failing build log.
    failure_extract_used = False
    if _ARTIFACT_BUILD_FAILURE_EXTRACT and _looks_like_ant_build(text):
        extracted = _extract_ant_failure_section(text)
        if extracted and len(extracted) < len(text):
            logger.info("artifact build failure-extract | file=%s | %d -> %d chars (%.0f%% reduction)",
                        fname, len(text), len(extracted), (1 - len(extracted) / max(1, len(text))) * 100)
            text = extracted
            failure_extract_used = True

    # DELTA vs previous run (opt-in; the caller passes the previous run's text only when the feature
    # is on and this is a large file). Summarise just the lines that changed since the last run, when
    # that is meaningfully smaller. Falls back to the full text otherwise — existing behaviour.
    delta_used = False
    prev = _strip_volatile_noise(str(previous_text or "").strip())
    if prev and len(text) > _MAP_REDUCE_CHUNK_CHARS:
        changed = _changed_content(prev, text)
        if changed.strip() and len(changed) <= len(text) * _ARTIFACT_DIFF_MAX_RATIO:
            logger.info("artifact delta-vs-previous | file=%s | %d -> %d changed chars",
                        fname, len(text), len(changed))
            text = changed
            delta_used = True

    # Large logs: format-AGNOSTIC structural reduction (stack compaction + duplicate collapse). No
    # content patterns decide what is kept (per client). build.log can still exceed one call after
    # this — that case is handled by map-reduce below, not by guessing what a "failure line" is.
    original_len = len(text)
    if original_len > _ARTIFACT_COMPRESS_TRIGGER:
        text = _structural_reduce(text)
        logger.info(
            "artifact structural-reduce | file=%s | %d -> %d chars (%.0f%% reduction)",
            fname, original_len, len(text), (1 - len(text) / max(1, original_len)) * 100,
        )

    # Input size fed to the summariser, AFTER noise strip + structural reduction ("after deduction,
    # before summaries"). The audit reports original -> after_reduction so the client can see both.
    reduced_chars = len(text)
    audit_note = _FAILURE_NOTE if failure_extract_used else (_DELTA_NOTE if delta_used else "")

    try:
        # Still larger than one summary call after reduction -> MAP-REDUCE: the model reads every
        # chunk and decides relevance itself (no regex), then the partials are merged. This is the
        # pattern-free path for logs bigger than the context window / per-minute quota.
        if len(text) > _MAP_REDUCE_CHUNK_CHARS:
            chunks = _split_into_chunks(text, _MAP_REDUCE_CHUNK_CHARS, _MAP_REDUCE_MAX_CHUNKS)
            logger.info("artifact over single-call budget | file=%s | %d chars -> %d chunk(s) (map-reduce)",
                        fname, len(text), len(chunks))
            summary, total, steps = _map_reduce_summarize(file_name, chunks, request_id)
            audit = _build_token_audit("map-reduce", original_chars, reduced_chars, steps, total)
            if audit_note:
                audit["note"] = audit_note
            return (summary, audit) if summary else ("", audit)

        # Fits in one call. Background summarization can afford generous 429 patience.
        user_message = (
            f"Artifact file name: {fname}\n\n"
            f"Summarize this build artifact for semantic embedding. {_SUMMARY_SECTIONS}\n\n"
            f"Artifact content:\n{text}"
        )
        content, usage = create_chat_completion(
            user_message=user_message,
            system_message=_SUMMARY_SYSTEM,
            rate_limit_retries=_SUMMARY_RATE_LIMIT_RETRIES,
        )
        summary = str(content or "").strip()
        audit = _build_token_audit(
            "single-call", original_chars, reduced_chars, [_token_step("Summary", usage)], usage)
        if audit_note:
            audit["note"] = audit_note
        if not summary:
            return "", audit
        return summary, audit
    except (RateLimitError, APITimeoutError, APIConnectionError):
        # Propagate TRANSIENT failures (429 exhausted, connect/read timeout, connection error):
        # the caller must treat this file as NOT summarised (retryable later via backfill) — NOT
        # fall back to storing raw text. The raw fallback would chunk-embed the whole file (hundreds
        # of vectors for a large log) AND the content-dedup would then permanently block a proper
        # summary for this content.
        logger.error("summarize_artifact_content_for_embedding | transient LLM failure (retryable) | request_id=%s", rid)
        raise
    except Exception:
        # Non-transient failures only (e.g. content filter / bad request): fail-open to raw text so
        # the pipeline stays operational — retrying would not help these.
        logger.exception("summarize_artifact_content_for_embedding | LLM call failed | request_id=%s", rid)
        return "", _empty_usage


def recompute_artifact_token_audit(*, file_name: str, artifact_text: str, summary_text: str) -> dict:
    """Recompute the token audit for an ALREADY-summarised artifact WITHOUT calling the LLM.

    Used to backfill token_usage onto records summarised before the audit existed. The reduction
    (noise strip + structural reduce) and prompt construction mirror the live path exactly, and a
    tokeniser counts the tokens. Returns the same shape as the live audit, with source="recomputed".

    Accuracy:
      - single-call files: EXACT — input is the same prompt sent live, output is the stored summary.
      - map-reduce files: input per part and the final output are exact, but the intermediate
        per-part OUTPUTS were never stored, so they are returned as null (only inputs + final
        summary are known). The flat/total numbers reflect what is recoverable.
    token_basis is "tiktoken" when available, else "approx" (~4 chars/token).
    """
    raw_text = str(artifact_text or "")
    text = raw_text.strip()
    if not text:
        return {}
    fname = str(file_name or "").strip()
    original_chars = len(raw_text)

    text = _strip_volatile_noise(text)
    if len(text) > _ARTIFACT_COMPRESS_TRIGGER:
        text = _structural_reduce(text)
    reduced_chars = len(text)

    summary = str(summary_text or "").strip()
    out_tokens = _count_tokens(summary)

    if len(text) > _MAP_REDUCE_CHUNK_CHARS:
        chunks = _split_into_chunks(text, _MAP_REDUCE_CHUNK_CHARS, _MAP_REDUCE_MAX_CHUNKS)
        steps: List[dict] = []
        total = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}
        for idx, chunk in enumerate(chunks, start=1):
            user = f"Artifact file name: {fname}\nPart {idx} of {len(chunks)}.\n\n{chunk[:_MAP_REDUCE_CHUNK_CHARS]}"
            in_t = _count_tokens(_MAP_SYSTEM) + _count_tokens(user)
            steps.append({"step": f"Stage {idx}", "input": in_t, "output": None, "total": None})
            total["prompt_tokens"] += in_t
        # Reduce step: input (the per-part facts) was not stored, so it is unknown; output = summary.
        steps.append({"step": "Combine", "input": None, "output": out_tokens, "total": None})
        total["output_tokens"] = out_tokens
        total["total_tokens"] = total["prompt_tokens"] + total["output_tokens"]
        audit = _build_token_audit("map-reduce", original_chars, reduced_chars, steps, total, source="recomputed")
        audit["token_basis"] = TOKEN_BASIS
        audit["note"] = ("Per-part outputs were not stored at summary time; only the inputs and the "
                         "final summary are known for large (map-reduce) files.")
        return audit

    user_message = (
        f"Artifact file name: {fname}\n\n"
        f"Summarize this build artifact for semantic embedding. {_SUMMARY_SECTIONS}\n\n"
        f"Artifact content:\n{text}"
    )
    in_t = _count_tokens(_SUMMARY_SYSTEM) + _count_tokens(user_message)
    total = {"prompt_tokens": in_t, "output_tokens": out_tokens, "total_tokens": in_t + out_tokens}
    steps = [{"step": "Summary", "input": in_t, "output": out_tokens, "total": in_t + out_tokens}]
    audit = _build_token_audit("single-call", original_chars, reduced_chars, steps, total, source="recomputed")
    audit["token_basis"] = TOKEN_BASIS
    return audit


def analyze_with_unified_evidence(
    *,
    errors: List[Dict],
    unified_evidence: List[Dict],
    query_text: str,
    request_id: str | None = None,
) -> tuple[str, dict]:
    """
    LLM Root Cause Analysis using the Top-3 RRF unified evidence items.
    unified_evidence items carry a 'source' tag: historical_error | artifact | document.
    Returns (analysis_text, token_usage).
    """
    rid = _resolve_request_id(request_id)
    _empty_usage: dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    if not getattr(config, "LLM_ANALYSIS_ENABLED", True):
        return "", _empty_usage

    error_lines: List[str] = []
    for err in errors or []:
        if not isinstance(err, dict):
            continue
        msg = _trim_error_for_prompt(str(err.get("message") or err.get("problemDetails") or "").strip())
        if msg:
            error_lines.append(f"- {msg}")

    if not error_lines:
        return "", _empty_usage

    evidence_lines: List[str] = []
    for rank, item in enumerate((unified_evidence or [])[:3], start=1):
        if not isinstance(item, dict):
            continue
        source = str(item.get("source") or "unknown")
        rrf_score = round(float(item.get("rrf_score") or 0.0), 4)

        if source == "historical_error":
            req_id = str(item.get("request_id") or "").strip()
            err_msg = str(item.get("error_message") or "").strip()
            task_lvl = str(item.get("task_match_level") or "").strip()
            evidence_lines.append(
                f"[{rank}] Historical Error (score={rrf_score}, match={task_lvl}, request_id={req_id or 'N/A'}): {err_msg[:_PROMPT_EVIDENCE_CHARS]}"
            )
        elif source == "artifact":
            file_name = str(item.get("file_name") or "").strip()
            preview = str(item.get("document") or "").strip()[:_PROMPT_EVIDENCE_CHARS]
            task_lvl = str(item.get("task_match_level") or "").strip()
            evidence_lines.append(
                f"[{rank}] Artifact (score={rrf_score}, match={task_lvl}, file={file_name}): {preview}"
            )
        elif source == "document":
            preview = str(item.get("document") or item.get("preview") or "").strip()[:_PROMPT_EVIDENCE_CHARS]
            evidence_lines.append(
                f"[{rank}] Knowledge Document (score={rrf_score}): {preview}"
            )
        else:
            evidence_lines.append(
                f"[{rank}] Evidence (source={source}, score={rrf_score}): {json.dumps(item, ensure_ascii=False)[:_PROMPT_EVIDENCE_CHARS]}"
            )

    system_message = (
        "You are a senior build engineer speaking directly to the developer. "
        "Use the build errors and evidence to give one direct actionable fix — name the file or config if visible. "
        "One sentence why it failed. One sentence to confirm it is fixed. "
        "Maximum 3 sentences total. No headers, no bullets, no preamble."
    )
    user_message = (
        f"Query: {str(query_text or '').strip()}\n\n"
        f"Build Errors:\n{chr(10).join(error_lines)}\n\n"
        f"Top-3 Unified Evidence (RRF fused):\n{chr(10).join(evidence_lines) if evidence_lines else 'No evidence available.'}\n\n"
        "Provide root cause analysis."
    )

    logger.debug(
        "analyze_with_unified_evidence | prompt | request_id=%s | evidence_count=%d\n"
        "--- SYSTEM ---\n%s\n--- USER ---\n%s\n--- END ---",
        rid, len(evidence_lines), system_message, user_message,
    )

    try:
        result, token_usage = create_chat_completion(user_message=user_message, system_message=system_message)
        return (result or "").strip(), token_usage
    except Exception:
        logger.exception("analyze_with_unified_evidence | LLM call failed | request_id=%s", rid)
        return "", _empty_usage


def _extract_json_object(text: str) -> dict:
    """Best-effort parse of a JSON object from an LLM reply (tolerates fences/prose)."""
    s = (text or "").strip()
    if not s:
        return {}
    if s.startswith("```"):
        s = re.sub(r"^```[a-zA-Z]*\n?", "", s)
        s = re.sub(r"\n?```$", "", s).strip()
    try:
        obj = json.loads(s)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        pass
    start, end = s.find("{"), s.rfind("}")
    if start != -1 and end > start:
        try:
            obj = json.loads(s[start:end + 1])
            return obj if isinstance(obj, dict) else {}
        except Exception:
            return {}
    return {}


def analyze_and_select_solution_with_unified_evidence(
    *,
    errors: List[Dict],
    unified_evidence: List[Dict],
    candidate_solutions: List[Dict],
    query_text: str,
    request_id: str | None = None,
) -> tuple[str, dict, dict]:
    """
    LLM-driven solution selection over RRF evidence + candidate historical fixes.

    The model SELECTS the one historical fix (by request_id) that resolves the current
    error and explains why; it never invents or edits change lines. Returns
    (analysis_text, selection, token_usage) where selection is::

        {
          "root_cause": str,
          "chosen_request_id": str,   # guaranteed to be one of the candidate ids, or ""
          "confidence": "high"|"medium"|"low",
          "why_this_fix": str,
          "missing_line": str,        # optional, for prediction-style flagging
        }

    On any failure returns ("", {}, usage) so callers fall back to existing analysis.
    """
    rid = _resolve_request_id(request_id)
    _empty_usage: dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    if not getattr(config, "LLM_ANALYSIS_ENABLED", True):
        return "", {}, _empty_usage

    error_lines: List[str] = []
    for err in errors or []:
        if isinstance(err, dict):
            m = _trim_error_for_prompt(str(err.get("message") or err.get("problemDetails") or "").strip())
            if m:
                error_lines.append(f"- {m}")
    if not error_lines:
        return "", {}, _empty_usage

    # Catalog of candidate fixes, keyed by request_id. Only candidates with real
    # change lines qualify, so the model can only choose a fix that actually exists.
    candidate_ids: List[str] = []
    candidate_lines: List[str] = []
    for sol in (candidate_solutions or [])[:5]:
        if not isinstance(sol, dict):
            continue
        req = str(sol.get("request_id") or sol.get("batch_id") or "").strip()
        if not req or req in candidate_ids:
            continue
        items = sol.get("solution") or []
        if not isinstance(items, list):
            continue
        changes: List[str] = []
        for it in items:
            if not isinstance(it, dict):
                continue
            fp = str(it.get("filePath") or it.get("fileName") or "").strip()
            raw_changes = it.get("changes") or []
            if not isinstance(raw_changes, list):
                continue
            for ch in raw_changes:
                c = str(ch or "").strip()
                if c:
                    changes.append(f"    {fp} | {c}")
        if not changes:
            continue
        candidate_ids.append(req)
        candidate_lines.append(f"request_id={req}:")
        candidate_lines.extend(changes[:20])
        artifact_match = sol.get("artifact_matched") if isinstance(sol.get("artifact_matched"), dict) else {}
        artifact_text = str(artifact_match.get("evidence_text") or "").strip()
        if artifact_text:
            artifact_name = str(artifact_match.get("file_name") or "stored artifact").strip()
            candidate_lines.append(
                f"    [candidate-linked artifact evidence: {artifact_name}; use only for request_id={req}]"
            )
            candidate_lines.append("    " + artifact_text[:1800].replace("\n", "\n    "))
        thumbs_up = int(sol.get("thumbs_up") or 0)
        thumbs_down = int(sol.get("thumbs_down") or 0)
        if thumbs_up or thumbs_down:
            candidate_lines.append(f"    [user feedback] helpful={thumbs_up} not-helpful={thumbs_down}")

    if not candidate_ids:
        logger.info(
            "[LLM] pick SKIPPED — no candidate fixes carry change-lines to choose from | request_id=%s", rid
        )
        return "", {}, _empty_usage

    evidence_lines: List[str] = []
    for rank, item in enumerate((unified_evidence or [])[:3], start=1):
        if not isinstance(item, dict):
            continue
        source = str(item.get("source") or "unknown")
        req = str(item.get("request_id") or "").strip()
        prev = str(
            item.get("error_message") or item.get("document") or item.get("preview") or ""
        ).strip()[:_PROMPT_EVIDENCE_CHARS]
        evidence_lines.append(f"[{rank}] {source} (request_id={req or 'N/A'}): {prev}")

    system_message = (
        "You are a senior build engineer selecting the correct historical fix for a build failure. "
        "You are given the current error, RRF-ranked evidence, and a catalog of candidate historical "
        "fixes (each tied to a request_id). Choose the ONE candidate whose changes resolve the current "
        "error, or none if none apply. You may ONLY choose a request_id from the provided catalog. "
        "Never invent or modify change lines. "
        "Candidate-linked artifact evidence appears inside the matching candidate block; use it as "
        "direct evidence for that candidate and never transfer it to another request_id. When it "
        "names the current failure, prioritize that evidence over task similarity or historical frequency. "
        "IMPORTANT: several candidates may share the SAME error template but encode DIFFERENT fixes — "
        "for example the same failure resolved by setting a value (such as a version) to different "
        "targets. Treat those as distinct, valid options, not duplicates. Pick the ONE whose change "
        "best resolves the CURRENT error; if the correct target value cannot be determined from the "
        "error alone, pick the most frequently used target and lower your confidence accordingly. "
        "Always set chosen_request_id when at least one candidate is plausibly relevant, so the picked "
        "fix can be shown first. When candidates differ only by such a value, summarize the options in "
        "'analysis' (e.g. 'most fixes set the version to R0; one used R123 — choose the correct release "
        "for your project'). "
        "Each candidate fix may include a [user feedback] line showing how many engineers marked it "
        "helpful or not-helpful. Use this as an additional relevance signal when selecting the best fix. "
        "Respond with STRICT JSON only — no prose, no code fences."
    )
    schema = (
        '{'
        '"root_cause": "one sentence on why it failed", '
        '"chosen_request_id": "one request_id from the catalog, or empty if none fits", '
        '"confidence": "high|medium|low", '
        '"why_this_fix": "one sentence on why this fix matches", '
        '"missing_line": "the single required line the current code lacks, or empty", '
        '"analysis": "developer-facing summary, max 3 sentences"'
        '}'
    )
    user_message = (
        f"Query: {str(query_text or '').strip()}\n\n"
        f"Build Errors:\n{chr(10).join(error_lines)}\n\n"
        f"RRF Evidence:\n{chr(10).join(evidence_lines) if evidence_lines else 'None'}\n\n"
        f"Candidate Historical Fixes:\n{chr(10).join(candidate_lines)}\n\n"
        f"Respond with strict JSON exactly matching this shape:\n{schema}"
    )

    try:
        content, usage = create_chat_completion(user_message=user_message, system_message=system_message)
    except Exception:
        logger.exception(
            "analyze_and_select_solution_with_unified_evidence | LLM call failed | request_id=%s", rid
        )
        return "", {}, _empty_usage

    parsed = _extract_json_object(content)
    if not parsed:
        logger.warning(
            "[LLM] pick EMPTY — model returned unparseable / non-JSON selection | request_id=%s | "
            "content_preview=%.160s",
            rid, str(content or "").replace("\n", " ")[:160],
        )
        return "", {}, usage

    chosen = str(parsed.get("chosen_request_id") or "").strip()
    if chosen and chosen not in candidate_ids:
        # Guardrail: reject any request_id the model invented or hallucinated.
        chosen = ""
    confidence = str(parsed.get("confidence") or "").strip().lower()
    if confidence not in ("high", "medium", "low"):
        confidence = "low"

    selection = {
        "root_cause": str(parsed.get("root_cause") or "").strip(),
        "chosen_request_id": chosen,
        "confidence": confidence,
        "why_this_fix": str(parsed.get("why_this_fix") or "").strip(),
        "missing_line": str(parsed.get("missing_line") or "").strip(),
    }
    analysis_text = str(parsed.get("analysis") or selection["root_cause"] or "").strip()
    return analysis_text, selection, usage


def analyze_errors_and_solutions_with_combined_context(
    *,
    errors: List[Dict],
    solutions: List[Dict],
    semantic_results: List[Dict],
    artifact_results: List[Dict],
    query_text: str,
    request_id: str | None = None,
) -> tuple[str, dict]:
    rid = _resolve_request_id(request_id)
    _empty_usage: dict = {"prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0}

    if not getattr(config, "LLM_ANALYSIS_ENABLED", True):
        return "", _empty_usage

    error_lines: List[str] = []
    for err in errors or []:
        if not isinstance(err, dict):
            continue
        msg = _trim_error_for_prompt(str(err.get("message") or err.get("problemDetails") or "").strip())
        if msg:
            error_lines.append(f"- {msg}")

    solution_lines: List[str] = []
    for idx, sol in enumerate((solutions or [])[:3], start=1):
        if not isinstance(sol, dict):
            continue
        req_id = str(sol.get("request_id") or sol.get("batch_id") or "").strip()
        items = sol.get("solution") or []
        if not isinstance(items, list):
            items = []
        changes: List[str] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            fp = str(item.get("filePath") or item.get("fileName") or "").strip()
            raw_changes = item.get("changes") or []
            if not isinstance(raw_changes, list):
                raw_changes = []
            for ch in raw_changes:
                c = str(ch or "").strip()
                if c:
                    changes.append(f"  File: {fp} | Change: {c}")
        if changes:
            solution_lines.append(f"Historical Solution {idx} (request_id={req_id or 'N/A'}):")
            solution_lines.extend(changes)

    doc_hits = _compact_context_hits(semantic_results, limit=3)
    artifact_hits = _compact_context_hits(artifact_results, limit=3)

    system_message = (
        "You are a software build troubleshooting assistant. "
        "Use the provided errors, historical fixes, semantic knowledge matches, and artifact summary matches together in one pass. "
        "Return concise, actionable output in plain text bullets under 180 words."
    )
    user_message = (
        f"Primary query:\n{str(query_text or '').strip()}\n\n"
        f"Build Errors:\n{'\n'.join(error_lines) if error_lines else '- N/A'}\n\n"
        f"Historical Solutions:\n{'\n'.join(solution_lines) if solution_lines else 'No historical solutions found.'}\n\n"
        f"Semantic Knowledge Hits:\n{json.dumps(doc_hits, ensure_ascii=False)}\n\n"
        f"Artifact Summary Hits:\n{json.dumps(artifact_hits, ensure_ascii=False)}\n\n"
        "Provide:\n"
        "1) Root cause understanding\n"
        "2) Final recommendation steps\n"
        "3) Resolution guidance and validation checklist"
    )

    try:
        result, token_usage = create_chat_completion(user_message=user_message, system_message=system_message)
        return (result or "").strip(), token_usage
    except Exception:
        logger.exception("analyze_errors_and_solutions_with_combined_context | LLM call failed | request_id=%s", rid)
        return "", _empty_usage
