# src/utils/test_oai_client.py

from src.utils.oai_client import (
    create_embedding,
    create_chat_completion
)
from src.configurations import config


def main():
    print("===== AZURE OPENAI CONFIG CHECK =====")
    print("OPEN_AI_ENDPOINT:", config.OPEN_AI_ENDPOINT)
    print("OAI_API_VERSION:", config.OAI_API_VERSION)
    print("EMBEDDING_MODEL:", config.EMBEDDING_MODEL)
    print("DEFAULT_MODEL:", config.DEFAULT_MODEL)
    print("====================================\n")

    print("----- Embedding Test -----")
    embedding = create_embedding("Hello world")
    print("Embedding length:", len(embedding))
    print("First 10 values:", embedding[:10])

    print("\n----- Chat Completion Test -----")
    reply = create_chat_completion(
        user_message="What is the capital of France?"
    )
    print("Model reply:", reply)


if __name__ == "__main__":
    main()
