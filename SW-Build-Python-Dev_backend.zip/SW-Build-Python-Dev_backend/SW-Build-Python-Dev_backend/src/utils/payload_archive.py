import base64
import gzip
import hashlib
import json
import logging
import os
import random
import re
import time
import uuid
from datetime import datetime, UTC
from functools import lru_cache
from io import BytesIO
from typing import Any, Callable
from zipfile import ZIP_DEFLATED, ZipFile

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

import src.utils.log_setup  # noqa: F401
from src.configurations import config
from src.utils import s3_dedup

logger = logging.getLogger(__name__)

AWS_REGION = config.S3_REGION
S3_BUCKET = config.S3_BUCKET
FOLDER_PREFIX = "AI-assited-data/"
PAYLOAD_FILENAME = "payload.json"
# Default MUST match config.py (which defaults to "test"); a mismatched default tags S3 keys
# with a different env than the rest of the app. Always set APP_ENV explicitly per environment.
APP_ENV = os.getenv("APP_ENV", os.getenv("ENVIRONMENT", "test")).strip().lower()
COPILOT_RECOMMENDATION_PREFIX = "recommendation/"
BINARY_ARTIFACTS_PREFIX = "binary-artifacts/"
TASK_RUNTIME_ARTIFACTS_PREFIX = "task-runtime-artifacts/"
PREDICTION_FEATURES_PREFIX = "prediction-features/"

_S3_CONFIG = Config(
    connect_timeout=2,
    read_timeout=5,
    max_pool_connections=300,
    retries={"max_attempts": 3, "mode": "adaptive"},
)


@lru_cache(maxsize=1)
def get_s3_client():
    """
    Uses EC2 IAM role automatically - no keys needed.
    """
    logger.debug("S3 client initializing | bucket=%s | region=%s", S3_BUCKET, AWS_REGION)
    return boto3.client("s3", region_name=AWS_REGION, config=_S3_CONFIG)


def _with_retries(func: Callable[[], Any], attempts: int = 5):
    last_err = None
    for i in range(attempts):
        try:
            return func()
        except ClientError as err:
            last_err = err
            code = err.response.get("Error", {}).get("Code", "")
            if code in {"NoSuchKey", "NoSuchBucket", "AccessDenied"}:
                raise
            # bounded exponential backoff with jitter
            sleep_s = min(2.0, 0.15 * (2 ** i)) + random.uniform(0, 0.1)
            time.sleep(sleep_s)
    raise last_err


def ensure_folder_exists(prefix: str = FOLDER_PREFIX):
    """
    Create folder prefix if not already present.
    Safe to run multiple times.
    """
    if not prefix.endswith("/"):
        prefix = f"{prefix}/"

    logger.debug("S3 ensure_folder_exists | bucket=%s | prefix=%s", S3_BUCKET, prefix)

    def _create_marker():
        return get_s3_client().put_object(Bucket=S3_BUCKET, Key=prefix, Body=b"")

    try:
        _with_retries(_create_marker)
        logger.debug("S3 ensure_folder_exists success | bucket=%s | prefix=%s", S3_BUCKET, prefix)
    except ClientError as exc:
        logger.warning(
            "S3 ensure_folder_exists failed (upload may still succeed) | bucket=%s | prefix=%s | error=%s",
            S3_BUCKET, prefix, exc,
        )
        # If marker object create fails, upload path may still succeed.
        pass


def _register_or_adopt_canonical(project: str, env: str, sha256: str, s3_key: str, size: int) -> str:
    """After uploading new content, register it as the canonical copy. If a concurrent upload of
    the SAME content won the registration race (rare), adopt the winner: reference it, remove our
    redundant just-uploaded object, and return the winner's key."""
    try:
        if s3_dedup.register_new(project, env, sha256, s3_key, size):
            return s3_key
        winner = s3_dedup.find_existing(project, env, sha256)
        if winner and winner != s3_key:
            s3_dedup.add_reference(project, env, sha256)
            try:
                get_s3_client().delete_object(Bucket=S3_BUCKET, Key=s3_key)
                logger.info("S3 dedup race | removed redundant upload %s, adopted %s", s3_key, winner)
            except Exception:
                logger.warning("S3 dedup race | could not remove redundant upload %s", s3_key)
            return winner
    except Exception:
        logger.warning("S3 dedup registration failed | s3_key=%s (object kept, dedup skipped)", s3_key)
    return s3_key


def _build_zip_bytes(payload: dict) -> tuple[bytes, str]:
    raw_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    digest = hashlib.sha256(raw_json.encode("utf-8")).hexdigest()

    buff = BytesIO()
    with ZipFile(buff, mode="w", compression=ZIP_DEFLATED) as zf:
        zf.writestr(PAYLOAD_FILENAME, raw_json.encode("utf-8"))
    return buff.getvalue(), digest


def _hash_text(value: str) -> str:
    text = (value or "").strip()
    if not text:
        return hashlib.sha1(b"empty").hexdigest()
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def _extract_file_payloads(payload: dict) -> list[tuple[str, dict]]:
    """
    Extract logical file-level payloads from common frontend shapes.
    Returns list of (file_name, payload_chunk) tuples.
    """
    file_payloads: list[tuple[str, dict]] = []

    def add_items(items):
        for idx, item in enumerate(items, start=1):
            if not isinstance(item, dict):
                continue
            name = item.get("fileName") or item.get("name") or f"file-{idx}.json"
            file_payloads.append((str(name), item))

    if payload.get("fileName"):
        # Per-file archive payload from the extension — store the whole payload as one file
        # so all top-level fields (snapshotBefore, snapshotAfter, modifiedFunctions, etc.)
        # are preserved in S3. Must come before the `solution` check because the extension
        # also embeds a `solution` sub-array inside this payload.
        file_payloads.append((str(payload["fileName"]), payload))
    elif isinstance(payload.get("files"), list):
        add_items(payload["files"])
    elif isinstance(payload.get("all_changes"), list):
        add_items(payload["all_changes"])
    elif isinstance(payload.get("solution"), list):
        add_items(payload["solution"])
    else:
        file_payloads.append(("payload.json", payload))

    if not file_payloads:
        file_payloads.append(("payload.json", payload))

    return file_payloads


def _safe_segment(value: str, default: str) -> str:
    cleaned = (value or "").strip().lower()
    cleaned = re.sub(r"[^a-z0-9._-]+", "-", cleaned).strip("-")
    return cleaned or default


def _get_storage_env() -> str:
    env = _safe_segment(APP_ENV, "test")
    if env not in {"test", "prod"}:
        return "test"
    return env


def upload_payload_zip(payload: dict, project_name: str, request_id: str | None = None) -> dict:
    if not request_id:
        request_id = str(uuid.uuid4())

    project_segment = _safe_segment(project_name, "unknown-project")
    storage_env = _get_storage_env()
    request_segment = _safe_segment(request_id, "unknown-request")

    project_folder = f"{FOLDER_PREFIX}{project_segment}/"
    env_folder = f"{project_folder}{storage_env}/"
    request_folder = f"{env_folder}{request_segment}/"

    body, digest = _build_zip_bytes(payload)
    s3_key = f"{request_folder}{request_segment}.zip"

    content_md5 = base64.b64encode(hashlib.md5(body).digest()).decode("ascii")

    logger.debug(
        "S3 UPLOAD | bucket=%s | key=%s | size_bytes=%d | sha256=%.16s",
        S3_BUCKET, s3_key, len(body), digest,
    )

    def _put_zip():
        return get_s3_client().put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=body,
            ContentType="application/zip",
            ContentMD5=content_md5,
            ServerSideEncryption="AES256",
            Metadata={
                "request_id": request_id,
                "project_name": project_segment,
                "env": storage_env,
                "sha256": digest,
            },
        )

    put_resp = _with_retries(_put_zip)
    etag = (put_resp.get("ETag") or "").replace('"', "")
    logger.debug(
        "S3 UPLOAD success | bucket=%s | key=%s | etag=%s",
        S3_BUCKET, s3_key, etag,
    )

    return {
        "request_id": request_id,
        "project_name": project_segment,
        "env": storage_env,
        "s3_bucket": S3_BUCKET,
        "s3_key": s3_key,
        "sha256": digest,
        "etag": etag,
        "compressed_size": len(body),
        "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def upload_copilot_error_payload_zip(
    project_name: str,
    request_id: str,
    error_message: str,
    payload: dict,
) -> dict:
    project_segment = _safe_segment(project_name, "unknown-project")
    request_segment = _safe_segment(request_id, "unknown-request")
    error_hash = _hash_text(error_message)
    storage_env = _get_storage_env()

    body, digest = _build_zip_bytes(payload)
    s3_key = (
        f"{COPILOT_RECOMMENDATION_PREFIX}"
        f"{project_segment}/{request_segment}/{error_hash}.zip"
    )
    content_md5 = base64.b64encode(hashlib.md5(body).digest()).decode("ascii")

    logger.debug(
        "S3 UPLOAD copilot error | bucket=%s | key=%s | error_hash=%s | size_bytes=%d | sha256=%.16s",
        S3_BUCKET, s3_key, error_hash, len(body), digest,
    )

    def _put_zip():
        return get_s3_client().put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=body,
            ContentType="application/zip",
            ContentMD5=content_md5,
            ServerSideEncryption="AES256",
            Metadata={
                "request_id": request_segment,
                "project_name": project_segment,
                "env": storage_env,
                "error_hash": error_hash,
                "sha256": digest,
            },
        )

    put_resp = _with_retries(_put_zip)
    etag = (put_resp.get("ETag") or "").replace('"', "")
    logger.debug(
        "S3 UPLOAD copilot error success | bucket=%s | key=%s | etag=%s",
        S3_BUCKET, s3_key, etag,
    )
    return {
        "request_id": request_segment,
        "project_name": project_segment,
        "env": storage_env,
        "s3_bucket": S3_BUCKET,
        "s3_key": s3_key,
        "error_hash": error_hash,
        "sha256": digest,
        "etag": etag,
        "compressed_size": len(body),
        "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def upload_payload_zips(
    payload: dict,
    project_name: str,
    request_id: str | None = None,
    existing_refs: list | None = None,
) -> dict:
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from src.utils.content_fingerprint import payload_content_fingerprint

    if not request_id:
        request_id = str(uuid.uuid4())

    project_segment = _safe_segment(project_name, "unknown-project")
    storage_env = _get_storage_env()
    request_segment = _safe_segment(request_id, "unknown-request")
    request_folder = f"{FOLDER_PREFIX}{project_segment}/{storage_env}/{request_segment}/"

    file_payloads = _extract_file_payloads(payload)
    logger.debug(
        "S3 UPLOAD multi-zip | bucket=%s | request_id=%s | file_count=%d | folder=%s",
        S3_BUCKET, request_id, len(file_payloads), request_folder,
    )

    # Dedup context from the request's already-stored archive references (storage proposal):
    # a file whose CLEANED content fingerprint is already stored is a true duplicate and is
    # skipped; same file NAME with different content becomes a new content-version instead of
    # overwriting the existing S3 object (old zips stay untouched, history preserved).
    known_fps_by_name: dict[str, set] = {}
    known_raw_sha_by_name: dict[str, set] = {}
    known_key_names: set = set()
    for ref in existing_refs or []:
        if not isinstance(ref, dict):
            continue
        ref_name = str(ref.get("file_name") or "").strip()
        ref_fp = str(ref.get("content_fingerprint") or "").strip()
        ref_sha = str(ref.get("sha256") or "").strip()
        ref_key_name = str(ref.get("file_key_name") or "").strip()
        if ref_name and ref_fp:
            known_fps_by_name.setdefault(ref_name, set()).add(ref_fp)
        if ref_name and ref_sha:
            known_raw_sha_by_name.setdefault(ref_name, set()).add(ref_sha)
        if ref_key_name:
            known_key_names.add(ref_key_name)

    # Step 1: build all zip bytes sequentially (CPU-bound, no I/O — fast).
    used_names: dict[str, int] = {}
    pending = []
    skipped_files = []
    for original_name, item_payload in file_payloads:
        file_segment = _safe_segment(original_name, "payload")
        used_names[file_segment] = used_names.get(file_segment, 0) + 1
        if used_names[file_segment] > 1:
            file_segment = f"{file_segment}-{used_names[file_segment]}"

        fingerprint = payload_content_fingerprint(item_payload)
        body, digest = _build_zip_bytes(item_payload if isinstance(item_payload, dict) else {"value": item_payload})

        if existing_refs is not None:
            if fingerprint in known_fps_by_name.get(original_name, set()) or digest in known_raw_sha_by_name.get(original_name, set()):
                skipped_files.append({"file_name": original_name, "content_fingerprint": fingerprint, "reason": "duplicate_content"})
                logger.info(
                    "S3 UPLOAD skipped | request_id=%s | file=%s | identical content already stored (fp=%s)",
                    request_id, original_name, fingerprint[:12],
                )
                continue
            if file_segment in known_key_names:
                versioned = f"{file_segment}~{fingerprint[:12]}"
                if versioned in known_key_names:
                    skipped_files.append({"file_name": original_name, "content_fingerprint": fingerprint, "reason": "duplicate_content"})
                    continue
                file_segment = versioned

        s3_key = f"{request_folder}{file_segment}.zip"
        content_md5 = base64.b64encode(hashlib.md5(body).digest()).decode("ascii")
        logger.debug(
            "S3 UPLOAD zip file | bucket=%s | key=%s | original_name=%s | size_bytes=%d",
            S3_BUCKET, s3_key, original_name, len(body),
        )
        pending.append((original_name, file_segment, s3_key, body, digest, content_md5, fingerprint))

    # Step 2: upload all files to S3 in parallel so N files take ~1× latency, not N×.
    def _upload_one(entry):
        original_name, file_segment, s3_key, body, digest, content_md5, fingerprint = entry
        def _put_zip():
            return get_s3_client().put_object(
                Bucket=S3_BUCKET,
                Key=s3_key,
                Body=body,
                ContentType="application/zip",
                ContentMD5=content_md5,
                ServerSideEncryption="AES256",
                Metadata={
                    "request_id": request_id,
                    "project_name": project_segment,
                    "env": storage_env,
                    "file_name": file_segment,
                    "sha256": digest,
                    "content_fingerprint": fingerprint,
                },
            )
        put_resp = _with_retries(_put_zip)
        etag = (put_resp.get("ETag") or "").replace('"', "")
        logger.debug("S3 UPLOAD zip file success | bucket=%s | key=%s | etag=%s", S3_BUCKET, s3_key, etag)
        return {
            "request_id": request_id,
            "project_name": project_segment,
            "env": storage_env,
            "file_name": original_name,
            "file_key_name": file_segment,
            "s3_bucket": S3_BUCKET,
            "s3_key": s3_key,
            "sha256": digest,
            "content_fingerprint": fingerprint,
            "etag": etag,
            "compressed_size": len(body),
            "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    items = [None] * len(pending)
    if pending:  # every file can be a skipped duplicate — nothing left to upload
        max_workers = min(len(pending), 8)
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_index = {executor.submit(_upload_one, entry): i for i, entry in enumerate(pending)}
            for future in as_completed(future_to_index):
                idx = future_to_index[future]
                items[idx] = future.result()  # re-raises on exception

    logger.debug(
        "S3 UPLOAD multi-zip complete | bucket=%s | request_id=%s | files_uploaded=%d | duplicates_skipped=%d",
        S3_BUCKET, request_id, len(items), len(skipped_files),
    )
    return {
        "request_id": request_id,
        "project_name": project_segment,
        "env": storage_env,
        "items": items,
        "skipped_files": skipped_files,
    }


def download_payload_zip(s3_key: str, expected_sha256: str | None = None) -> dict:
    logger.debug("S3 DOWNLOAD | bucket=%s | key=%s", S3_BUCKET, s3_key)
    resp = _with_retries(lambda: get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key))
    zip_data = resp["Body"].read()
    logger.debug("S3 DOWNLOAD received | bucket=%s | key=%s | size_bytes=%d", S3_BUCKET, s3_key, len(zip_data))

    with ZipFile(BytesIO(zip_data), mode="r") as zf:
        raw = zf.read(PAYLOAD_FILENAME)

    raw_text = raw.decode("utf-8")
    digest = hashlib.sha256(raw).hexdigest()

    if expected_sha256 and digest != expected_sha256:
        logger.error(
            "S3 DOWNLOAD sha256 mismatch | bucket=%s | key=%s | expected=%.16s | actual=%.16s",
            S3_BUCKET, s3_key, expected_sha256, digest,
        )
        raise ValueError("Payload integrity check failed (sha256 mismatch)")

    logger.debug(
        "S3 DOWNLOAD integrity OK | bucket=%s | key=%s | sha256=%.16s",
        S3_BUCKET, s3_key, digest,
    )
    return json.loads(raw_text)


def list_payload_archives_for_request(request_id: str) -> list[dict]:
    """
    Resolve archived payload ZIP objects directly from S3 by request_id folder segment.
    This avoids DynamoDB lookup for diff retrieval.
    """
    request_segment = _safe_segment(request_id, "")
    if not request_segment:
        logger.warning("list_payload_archives_for_request | empty request_id, returning []")
        return []

    logger.debug(
        "S3 LIST | bucket=%s | prefix=%s | request_id=%s",
        S3_BUCKET, FOLDER_PREFIX, request_segment,
    )
    client = get_s3_client()
    paginator = client.get_paginator("list_objects_v2")
    marker = f"/{request_segment}/"
    seen_keys = set()
    matches: list[dict] = []

    for page in paginator.paginate(
        Bucket=S3_BUCKET,
        Prefix=FOLDER_PREFIX,
        PaginationConfig={"PageSize": 1000},
    ):
        for obj in page.get("Contents", []):
            key = obj.get("Key", "")
            if not key.endswith(".zip"):
                continue
            if marker not in key:
                continue
            if key in seen_keys:
                continue

            seen_keys.add(key)
            parts = key.split("/")
            project_name = parts[1] if len(parts) > 1 else "unknown-project"
            env = parts[2] if len(parts) > 2 else "test"
            file_name = key.rsplit("/", 1)[-1]
            file_key_name = file_name[:-4] if file_name.lower().endswith(".zip") else file_name
            last_modified = obj.get("LastModified")
            created_date = (
                last_modified.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
                if last_modified
                else datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
            )

            matches.append(
                {
                    "request_id": request_segment,
                    "project_name": project_name,
                    "env": env,
                    "file_name": file_key_name,
                    "file_key_name": file_key_name,
                    "s3_bucket": S3_BUCKET,
                    "s3_key": key,
                    "sha256": None,
                    "etag": (obj.get("ETag") or "").replace('"', ""),
                    "compressed_size": int(obj.get("Size", 0)),
                    "created_date": created_date,
                }
            )

    matches.sort(
        key=lambda item: (
            item.get("created_date") or "",
            item.get("file_name") or "",
            item.get("s3_key") or "",
        )
    )
    if not matches:
        logger.warning(
            "S3 LIST returned empty | bucket=%s | prefix=%s | request_id=%s",
            S3_BUCKET, FOLDER_PREFIX, request_segment,
        )
    else:
        logger.debug(
            "S3 LIST result | bucket=%s | request_id=%s | count=%d",
            S3_BUCKET, request_segment, len(matches),
        )
    return matches


def list_copilot_error_payload_archives(project_name: str, request_id: str) -> list[dict]:
    """
    List copilot archived error payload zips for one project/request pair.
    Stored under: recommendation/{project_name}/{request_id}/{error_hash}.zip
    """
    project_segment = _safe_segment(project_name, "")
    request_segment = _safe_segment(request_id, "")
    if not project_segment or not request_segment:
        return []

    prefix = f"{COPILOT_RECOMMENDATION_PREFIX}{project_segment}/{request_segment}/"
    logger.debug(
        "S3 LIST copilot error archives | bucket=%s | prefix=%s",
        S3_BUCKET, prefix,
    )
    client = get_s3_client()
    paginator = client.get_paginator("list_objects_v2")
    matches: list[dict] = []

    for page in paginator.paginate(
        Bucket=S3_BUCKET,
        Prefix=prefix,
        PaginationConfig={"PageSize": 1000},
    ):
        for obj in page.get("Contents", []):
            key = obj.get("Key", "")
            if not key.endswith(".zip"):
                continue
            last_modified = obj.get("LastModified")
            created_date = (
                last_modified.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
                if last_modified
                else datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
            )
            matches.append(
                {
                    "request_id": request_segment,
                    "project_name": project_segment,
                    "s3_bucket": S3_BUCKET,
                    "s3_key": key,
                    "compressed_size": int(obj.get("Size", 0)),
                    "created_date": created_date,
                }
            )

    matches.sort(key=lambda x: x.get("created_date") or "", reverse=True)
    if not matches:
        logger.warning(
            "S3 LIST copilot error archives empty | bucket=%s | prefix=%s",
            S3_BUCKET, prefix,
        )
    else:
        logger.debug(
            "S3 LIST copilot error archives result | bucket=%s | prefix=%s | count=%d",
            S3_BUCKET, prefix, len(matches),
        )
    return matches


def upload_binary_artifact_zip(
    batch_id: str,
    file_name: str,
    file_bytes: bytes,
    action: str = "modified",
    project_name: str = "",
    force_upload: bool = False,
) -> dict:
    batch_segment = _safe_segment(batch_id, "unknown-batch")
    file_segment = _safe_segment(file_name, "binary")
    action_segment = _safe_segment(action, "modified")
    project_segment = _safe_segment(project_name, "unknown-project")
    storage_env = _get_storage_env()

    raw = file_bytes or b""
    payload_sha256 = hashlib.sha256(raw).hexdigest()

    # Content dedup (single-instance storage) — same content already stored for this project+env
    # -> reference the existing object instead of writing a duplicate. See upload_task_runtime_artifact_zip.
    # force_upload=True bypasses dedup so a renamed file still gets its own S3 key.
    if s3_dedup.dedup_enabled() and not force_upload:
        existing_key = s3_dedup.find_existing(project_segment, storage_env, payload_sha256)
        if existing_key:
            s3_dedup.add_reference(project_segment, storage_env, payload_sha256)
            logger.info(
                "S3 dedup HIT (binary artifact) | file=%s | sha=%s | reusing %s",
                file_name, payload_sha256[:12], existing_key,
            )
            return {
                "batch_id": batch_segment,
                "project_name": project_segment,
                "env": storage_env,
                "s3_bucket": S3_BUCKET,
                "s3_key": existing_key,
                "action": action_segment,
                "file_name": file_name,
                "payload_sha256": payload_sha256,
                "zip_sha256": "",
                "etag": "",
                "payload_size": len(raw),
                "compressed_size": 0,
                "deduplicated": True,
                "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            }

    buff = BytesIO()
    with ZipFile(buff, mode="w", compression=ZIP_DEFLATED) as zf:
        zf.writestr(file_name or "binary.bin", raw)
    body = buff.getvalue()
    zip_sha256 = hashlib.sha256(body).hexdigest()
    content_md5 = base64.b64encode(hashlib.md5(body).digest()).decode("ascii")

    s3_key = (
        f"{BINARY_ARTIFACTS_PREFIX}"
        f"{project_segment}/{storage_env}/{batch_segment}/{action_segment}/"
        f"{file_segment}-{payload_sha256[:12]}.zip"
    )
    logger.debug(
        "S3 UPLOAD binary artifact | bucket=%s | key=%s | file_name=%s | action=%s | payload_bytes=%d | zip_bytes=%d",
        S3_BUCKET, s3_key, file_name, action_segment, len(raw), len(body),
    )

    def _put_zip():
        return get_s3_client().put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=body,
            ContentType="application/zip",
            ContentMD5=content_md5,
            ServerSideEncryption="AES256",
            Metadata={
                "batch_id": batch_segment,
                "project_name": project_segment,
                "env": storage_env,
                "file_name": file_name or file_segment,
                "action": action_segment,
                "payload_sha256": payload_sha256,
                "zip_sha256": zip_sha256,
            },
        )

    put_resp = _with_retries(_put_zip)
    etag = (put_resp.get("ETag") or "").replace('"', "")
    logger.debug(
        "S3 UPLOAD binary artifact success | bucket=%s | key=%s | etag=%s",
        S3_BUCKET, s3_key, etag,
    )
    # force_upload=True means the caller intentionally wants a new key (e.g. renamed file) —
    # skip both the pre-check (already skipped above) AND the post-upload race registration so
    # the new key is kept as-is in S3 rather than being replaced by the canonical copy.
    if s3_dedup.dedup_enabled() and not force_upload:
        s3_key = _register_or_adopt_canonical(
            project_segment, storage_env, payload_sha256, s3_key, len(raw)
        )
    return {
        "batch_id": batch_segment,
        "project_name": project_segment,
        "env": storage_env,
        "s3_bucket": S3_BUCKET,
        "s3_key": s3_key,
        "action": action_segment,
        "file_name": file_name,
        "payload_sha256": payload_sha256,
        "zip_sha256": zip_sha256,
        "etag": etag,
        "payload_size": len(raw),
        "compressed_size": len(body),
        "deduplicated": False,
        "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def upload_task_runtime_artifact_zip(
    batch_id: str,
    file_name: str,
    file_bytes: bytes,
    action: str = "modified",
    project_name: str = "",
    source_folder: str = "",
    task_path: str = "",
) -> dict:
    batch_segment = _safe_segment(batch_id, "unknown-batch")
    file_segment = _safe_segment(file_name, "runtime-artifact")
    action_segment = _safe_segment(action, "modified")
    project_segment = _safe_segment(project_name, "unknown-project")
    source_segment = _safe_segment(source_folder, "")
    task_segment = _safe_segment(task_path.replace(":", "-"), "")
    storage_env = _get_storage_env()

    raw = file_bytes or b""
    payload_sha256 = hashlib.sha256(raw).hexdigest()

    # Content dedup (single-instance storage): identical file content already stored for this
    # project+env -> skip the S3 write, count a reference, and point this upload at the existing
    # object. No data is lost — the per-request DynamoDB reference is still saved by the caller.
    if s3_dedup.dedup_enabled():
        existing_key = s3_dedup.find_existing(project_segment, storage_env, payload_sha256)
        if existing_key:
            s3_dedup.add_reference(project_segment, storage_env, payload_sha256)
            logger.info(
                "S3 dedup HIT (runtime artifact) | file=%s | sha=%s | reusing %s",
                file_name, payload_sha256[:12], existing_key,
            )
            return {
                "batch_id": batch_segment,
                "project_name": project_segment,
                "env": storage_env,
                "s3_bucket": S3_BUCKET,
                "s3_key": existing_key,
                "action": action_segment,
                "source_folder": source_segment,
                "task_path": task_path or "",
                "file_name": file_name,
                "payload_sha256": payload_sha256,
                "zip_sha256": "",
                "etag": "",
                "payload_size": len(raw),
                "compressed_size": 0,
                "deduplicated": True,
                "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            }

    buff = BytesIO()
    with ZipFile(buff, mode="w", compression=ZIP_DEFLATED) as zf:
        zf.writestr(file_name or "runtime-artifact.bin", raw)
    body = buff.getvalue()
    zip_sha256 = hashlib.sha256(body).hexdigest()
    content_md5 = base64.b64encode(hashlib.md5(body).digest()).decode("ascii")

    s3_key = (
        f"{TASK_RUNTIME_ARTIFACTS_PREFIX}"
        f"{project_segment}/{storage_env}/{batch_segment}/{action_segment}/"
        f"{(task_segment + '/') if task_segment else ''}"
        f"{(source_segment + '/') if source_segment else ''}"
        f"{file_segment}-{payload_sha256[:12]}.zip"
    )
    logger.debug(
        "S3 UPLOAD runtime artifact | bucket=%s | key=%s | file_name=%s | action=%s | task_path=%s | payload_bytes=%d | zip_bytes=%d",
        S3_BUCKET, s3_key, file_name, action_segment, task_path or "", len(raw), len(body),
    )

    def _put_zip():
        return get_s3_client().put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=body,
            ContentType="application/zip",
            ContentMD5=content_md5,
            ServerSideEncryption="AES256",
            Metadata={
                "batch_id": batch_segment,
                "project_name": project_segment,
                "env": storage_env,
                "file_name": file_name or file_segment,
                "action": action_segment,
                "source_folder": source_segment,
                "task_path": task_path or "",
                "payload_sha256": payload_sha256,
                "zip_sha256": zip_sha256,
            },
        )

    put_resp = _with_retries(_put_zip)
    etag = (put_resp.get("ETag") or "").replace('"', "")
    logger.debug(
        "S3 UPLOAD runtime artifact success | bucket=%s | key=%s | etag=%s",
        S3_BUCKET, s3_key, etag,
    )
    if s3_dedup.dedup_enabled():
        s3_key = _register_or_adopt_canonical(
            project_segment, storage_env, payload_sha256, s3_key, len(raw)
        )
    return {
        "batch_id": batch_segment,
        "project_name": project_segment,
        "env": storage_env,
        "s3_bucket": S3_BUCKET,
        "s3_key": s3_key,
        "action": action_segment,
        "source_folder": source_segment,
        "task_path": task_path or "",
        "file_name": file_name,
        "payload_sha256": payload_sha256,
        "zip_sha256": zip_sha256,
        "etag": etag,
        "payload_size": len(raw),
        "compressed_size": len(body),
        "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def upload_prediction_feature_json(
    *,
    project_name: str,
    request_id: str,
    change_id: str,
    payload: dict,
) -> dict:
    project_segment = _safe_segment(project_name, "unknown-project")
    request_segment = _safe_segment(request_id, "unknown-request")
    change_segment = _safe_segment(change_id, "unknown-change")
    storage_env = _get_storage_env()

    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    body = gzip.compress(raw, compresslevel=6)
    payload_sha256 = hashlib.sha256(raw).hexdigest()
    zip_sha256 = hashlib.sha256(body).hexdigest()
    content_md5 = base64.b64encode(hashlib.md5(body).digest()).decode("ascii")

    s3_key = (
        f"{PREDICTION_FEATURES_PREFIX}"
        f"{project_segment}/{storage_env}/{request_segment}/{change_segment}.json.gz"
    )
    logger.debug(
        "S3 UPLOAD prediction feature | bucket=%s | key=%s | change_id=%s | payload_bytes=%d | compressed_bytes=%d",
        S3_BUCKET, s3_key, change_id, len(raw), len(body),
    )

    def _put_obj():
        return get_s3_client().put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=body,
            ContentType="application/gzip",
            ContentMD5=content_md5,
            ServerSideEncryption="AES256",
            Metadata={
                "request_id": request_segment,
                "project_name": project_segment,
                "env": storage_env,
                "change_id": change_segment,
                "payload_sha256": payload_sha256,
                "zip_sha256": zip_sha256,
            },
        )

    put_resp = _with_retries(_put_obj)
    etag = (put_resp.get("ETag") or "").replace('"', "")
    logger.debug(
        "S3 UPLOAD prediction feature success | bucket=%s | key=%s | etag=%s",
        S3_BUCKET, s3_key, etag,
    )
    return {
        "request_id": request_segment,
        "project_name": project_segment,
        "env": storage_env,
        "change_id": change_segment,
        "s3_bucket": S3_BUCKET,
        "s3_key": s3_key,
        "payload_sha256": payload_sha256,
        "zip_sha256": zip_sha256,
        "compressed_size": len(body),
        "etag": etag,
        "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def list_prediction_feature_archives(project_name: str, limit: int = 200) -> list[dict]:
    project_segment = _safe_segment(project_name, "")
    if not project_segment:
        return []
    prefix = f"{PREDICTION_FEATURES_PREFIX}{project_segment}/"
    logger.debug("S3 LIST prediction features | bucket=%s | prefix=%s", S3_BUCKET, prefix)
    client = get_s3_client()
    paginator = client.get_paginator("list_objects_v2")
    items: list[dict] = []

    for page in paginator.paginate(
        Bucket=S3_BUCKET,
        Prefix=prefix,
        PaginationConfig={"PageSize": 1000},
    ):
        for obj in page.get("Contents", []):
            key = obj.get("Key", "")
            if not key.endswith(".json.gz"):
                continue
            last_modified = obj.get("LastModified")
            created_date = (
                last_modified.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
                if last_modified
                else datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
            )
            items.append(
                {
                    "project_name": project_segment,
                    "s3_bucket": S3_BUCKET,
                    "s3_key": key,
                    "etag": (obj.get("ETag") or "").replace('"', ""),
                    "compressed_size": int(obj.get("Size", 0)),
                    "created_date": created_date,
                }
            )
    items.sort(key=lambda x: x.get("created_date") or "", reverse=True)
    result = items[: max(1, int(limit))]
    logger.debug(
        "S3 LIST prediction features result | bucket=%s | prefix=%s | count=%d",
        S3_BUCKET, prefix, len(result),
    )
    return result


def download_prediction_feature_json(s3_key: str) -> dict:
    logger.debug("S3 DOWNLOAD prediction feature | bucket=%s | key=%s", S3_BUCKET, s3_key)
    resp = _with_retries(lambda: get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key))
    raw = resp["Body"].read()
    logger.debug("S3 DOWNLOAD prediction feature received | bucket=%s | key=%s | size_bytes=%d", S3_BUCKET, s3_key, len(raw))
    decoded = gzip.decompress(raw).decode("utf-8")
    return json.loads(decoded)


def generate_presigned_download_url(s3_key: str, expires_in: int = 3600) -> str:
    """Return a presigned S3 GET URL valid for `expires_in` seconds."""
    logger.debug("S3 presigned URL | bucket=%s | key=%s | expires_in=%ds", S3_BUCKET, s3_key, expires_in)
    return get_s3_client().generate_presigned_url(
        "get_object",
        Params={"Bucket": S3_BUCKET, "Key": s3_key},
        ExpiresIn=expires_in,
    )


def download_s3_zip_bytes(s3_key: str) -> tuple[bytes, str]:
    """Fetch a zip from S3 and return (raw_bytes, filename)."""
    logger.debug("S3 DOWNLOAD zip bytes | bucket=%s | key=%s", S3_BUCKET, s3_key)
    resp = _with_retries(lambda: get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key))
    data = resp["Body"].read()
    file_name = s3_key.rsplit("/", 1)[-1]
    logger.debug("S3 DOWNLOAD zip bytes received | bucket=%s | key=%s | file_name=%s | size_bytes=%d", S3_BUCKET, s3_key, file_name, len(data))
    return data, file_name
