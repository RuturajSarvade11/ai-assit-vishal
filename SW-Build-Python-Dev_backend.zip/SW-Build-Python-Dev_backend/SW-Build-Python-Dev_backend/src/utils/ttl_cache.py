"""
src/utils/ttl_cache.py — tiny thread-safe TTL cache for the dashboard READ path.

The paginated dashboard endpoints refetch and reprocess the ENTIRE date range on every
page click just to return 10 rows — on UAT that meant 30-60 seconds per click (measured
on Recent Activity). Caching the expensive fetch stage for a short
window makes the first click pay the full cost once; every following click (next page,
sort, search, tile reconciliation) answers from memory.

This never reduces what is shown (locked rule: perf work never cuts data): the same rows
flow through the same pipeline — they are just not refetched within the TTL. New uploads
invalidate the affected keys immediately; everything else is at most TTL seconds stale.
DASHBOARD_CACHE_TTL_SEC tunes the window (default 60; 0 disables caching entirely).
"""
import copy
import os
import threading
import time

_lock = threading.Lock()
_store = {}   # key -> (expires_at, value)
_inflight = {}   # key -> threading.Event: single-flight guard (one compute per key at a time)
_MAX_ENTRIES = 200
_INFLIGHT_WAIT_SEC = 300.0


def ttl_seconds() -> int:
    try:
        return max(0, int(os.getenv("DASHBOARD_CACHE_TTL_SEC", "60")))
    except (TypeError, ValueError):
        return 60


def get_or_compute(key, compute, deep_copy: bool = True, ttl_override=None):
    """Cached value for key, computing (and storing) it on a miss.

    deep_copy=True hands every caller its OWN copy of the value, so the dashboard's
    in-place enrichment (summaries, token fields, feedback counts) never mutates the
    shared cached rows across concurrent requests. Pass deep_copy=False only for
    values that are read-only downstream.

    ttl_override: per-key TTL in seconds for values whose recompute is very expensive
    (e.g. the full-table scan). DASHBOARD_CACHE_TTL_SEC=0 stays the master kill switch:
    when it disables caching, overrides are ignored too."""
    ttl = ttl_seconds()
    if ttl <= 0:
        return compute()
    if ttl_override is not None:
        try:
            ttl = max(1.0, float(ttl_override))
        except (TypeError, ValueError):
            pass
    now = time.time()
    with _lock:
        entry = _store.get(key)
        if entry and entry[0] > now:
            return copy.deepcopy(entry[1]) if deep_copy else entry[1]
        # Single-flight (the dashboard fires ~6 endpoints at once against a cold cache,
        # and EACH started its own multi-minute scan - a stampede that hammered the DB and
        # made every request time out). First caller becomes the leader and computes;
        # everyone else waits for its result instead of re-running the same expensive fetch.
        waiter = _inflight.get(key)
        if waiter is None:
            _inflight[key] = threading.Event()
        # (holding the lock only for the dict ops above - compute happens outside)
    if waiter is not None:
        waiter.wait(timeout=_INFLIGHT_WAIT_SEC)
        with _lock:
            entry = _store.get(key)
            if entry and entry[0] > time.time():
                return copy.deepcopy(entry[1]) if deep_copy else entry[1]
        # Leader failed or value already expired - fall through and compute ourselves.
    try:
        value = compute()   # outside the lock — a slow fetch must never block other keys
    finally:
        with _lock:
            done = _inflight.pop(key, None)
        if done is not None:
            done.set()
    with _lock:
        if len(_store) >= _MAX_ENTRIES:
            for stale in [k for k, v in _store.items() if v[0] <= now]:
                _store.pop(stale, None)
            if len(_store) >= _MAX_ENTRIES and _store:
                _store.pop(min(_store, key=lambda k: _store[k][0]), None)
        _store[key] = (now + ttl, value)
    return copy.deepcopy(value) if deep_copy else value


def invalidate_prefix(prefix: str) -> None:
    """Drop every cached tuple-key whose first element starts with prefix — called on
    writes (a new upload) so the dashboard shows the new row immediately, not after TTL."""
    with _lock:
        for key in [k for k in _store
                    if isinstance(k, tuple) and k and str(k[0]).startswith(str(prefix))]:
            _store.pop(key, None)


def clear() -> None:
    with _lock:
        _store.clear()
