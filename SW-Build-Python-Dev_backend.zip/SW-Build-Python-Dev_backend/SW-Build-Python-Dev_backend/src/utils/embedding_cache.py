"""Resumable, cached re-embedding of stored documents.

WHY THIS EXISTS. On Azure the `embedding` field is non-retrievable, so every training path has to
reconstruct vectors by re-embedding the stored document text. Each of those paths did the same
thing: one pass over the corpus in batches of 200, keeping nothing. That has two consequences we
hit for real on dev:

  - A rate limit anywhere in the run fails the WHOLE run. create_embeddings_batch retries the
    same 200-document call, hits the same limit, and after ~4.5 minutes the job dies having
    produced nothing. The first audit run ended exactly this way:
    "dataset build FAILED: Embedding request failed after 264728 ms".
  - Every retry starts from zero and re-pays for work that already succeeded, which makes the
    next attempt no more likely to finish than the last.

So the corpus is embedded in SMALL batches, and every batch is written to a disk cache keyed by a
hash of the text before the next one starts. A rate-limited run resumes where it stopped instead
of restarting, and a second training run over a mostly-unchanged corpus costs almost nothing.

The cache is keyed by the text itself, so it stays correct when documents are added or removed
and is simply wrong-free if a document changes (a changed document is a new key). It is a CACHE:
deleting the file costs time, never correctness. It is invalidated by the embedding model name,
because vectors from two models must never be mixed in one space.
"""
import hashlib
import logging
import os
import threading
import time

import numpy as np

from src.configurations import config

logger = logging.getLogger(__name__)

# STARTING batch size - it halves itself on failure, so this is an opening bid rather than a
# setting that has to be right. 16 because 64 failed outright on dev: each document is capped at
# EMBEDDING_MAX_CHARS (1500), so 64 of them is ~96k characters in a single request, and the quota
# that matters is tokens per request rather than documents per request.
BATCH = max(1, int(os.getenv("EMBED_CACHE_BATCH", "16")))

# Optional pause between successful batches, for a deployment whose limit is tokens per MINUTE:
# shrinking the batch does not help there, only slowing down does.
PACE_SEC = max(0.0, float(os.getenv("EMBED_CACHE_PACE_SEC", "0")))

_lock = threading.Lock()


def _cache_path() -> str:
    """Sits with the adapter weights - same lifecycle, same thing to wipe when retraining fresh."""
    base = os.path.dirname(str(config.FEEDBACK_ADAPTER_PATH or "./feedback_adapter/W")) or "."
    model = str(getattr(config, "EMBEDDING_MODEL", "") or "model").replace("/", "_")
    env = str(getattr(config, "APP_ENV", "") or "test")
    return os.path.join(base, f"embed_cache_{env}_{model}.npz")


def _key(text: str) -> str:
    return hashlib.sha1((text or "").encode("utf-8", "replace")).hexdigest()


def _load():
    path = _cache_path()
    if not os.path.exists(path):
        return {}
    try:
        with np.load(path, allow_pickle=False) as data:
            keys, vecs = data["keys"], data["vecs"]
        return {str(k): vecs[i] for i, k in enumerate(keys)}
    except Exception:
        # A corrupt cache must cost time, never a run: start empty and rewrite it.
        logger.warning("embedding cache unreadable - starting empty | path=%s", path, exc_info=True)
        return {}


def _save(cache) -> None:
    path = _cache_path()
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        keys = list(cache.keys())
        vecs = np.asarray([cache[k] for k in keys], dtype=np.float32)
        tmp = path + ".tmp"
        # Write through a HANDLE, not a path: savez_compressed appends '.npz' to any path that
        # does not already end in it, so passing '<name>.npz.tmp' silently produced
        # '<name>.npz.tmp.npz' and the replace below then failed - the cache never persisted and
        # every run re-embedded from scratch, which is the entire bug this module exists to fix.
        with open(tmp, "wb") as handle:
            np.savez_compressed(handle, keys=np.asarray(keys), vecs=vecs)
        os.replace(tmp, path)      # atomic: an interrupted save never leaves a half-written cache
    except Exception:
        logger.warning("embedding cache save failed (run continues)", exc_info=True)


def embed_documents(docs, label: str = "") -> list:
    """Vectors for `docs`, in order. Cached on disk and resumable across runs.

    Raises whatever the embedding client raises if a batch cannot be embedded - but everything
    already embedded is saved first, so re-running continues from that point.
    """
    docs = [str(d or "") for d in docs]
    if not docs:
        return []

    with _lock:
        cache = _load()
        wanted = {_key(d) for d in docs}
        missing_keys, missing_texts, seen = [], [], set()
        for d in docs:
            k = _key(d)
            if k in cache or k in seen:
                continue
            seen.add(k)
            missing_keys.append(k)
            missing_texts.append(d)

        hits = len(wanted) - len(missing_keys)
        logger.info("embedding cache | %s | %d unique docs | %d cached | %d to embed | batch=%d",
                    label or "corpus", len(wanted), hits, len(missing_keys), BATCH)

        if missing_texts:
            from src.utils.oai_client import create_embeddings_batch
            done = 0
            size = BATCH
            i = 0
            while i < len(missing_texts):
                chunk_keys = missing_keys[i:i + size]
                chunk_texts = missing_texts[i:i + size]
                try:
                    vectors = create_embeddings_batch(chunk_texts)
                except Exception:
                    # ADAPTIVE SHRINK. A fixed batch size is a guess about someone
                    # else's quota, and on dev the guess was wrong in a way that made NO
                    # progress at all: the very first batch of 64 failed, so 0 of 627 documents
                    # were embedded. The limit is tokens per request, not documents, so the only
                    # honest response to a failure is to ask for less and try again. Halving
                    # converges on whatever this deployment actually allows in a few attempts.
                    if size > 1:
                        size = max(1, size // 2)
                        logger.warning("embedding cache | %s | batch failed - retrying with %d",
                                       label or "corpus", size)
                        continue
                    _save(cache)
                    logger.error("embedding stopped after %d/%d even at batch=1 - progress SAVED,"
                                 " re-run to resume", done, len(missing_texts))
                    raise
                for k, v in zip(chunk_keys, vectors):
                    cache[k] = np.asarray(v, dtype=np.float32)
                done += len(chunk_keys)
                i += len(chunk_keys)
                # Persist BEFORE the next call: a rate limit on the next batch must not throw
                # away what this one just paid for.
                _save(cache)
                logger.info("embedding cache | %s | %d/%d embedded (batch=%d)",
                            label or "corpus", done, len(missing_texts), size)
                if PACE_SEC:
                    time.sleep(PACE_SEC)

        return [cache[_key(d)].tolist() for d in docs]


def stats() -> dict:
    path = _cache_path()
    cache = _load()
    return {"path": path, "exists": os.path.exists(path), "vectors": len(cache),
            "size_bytes": os.path.getsize(path) if os.path.exists(path) else 0}
