"""
S3 content dedup index (single-instance storage for artifacts).

Industry-standard content addressing: a file's identity is its sha256. The FIRST upload of a given
content (per project+env) stores the object; every later upload of the same content skips the S3
write and just adds a REFERENCE to the existing object. No information is ever lost — every
request keeps its own DynamoDB reference row; only redundant bytes are stored once.

Deletion safety: requests can share one object, so deletes must be reference-aware. The index
keeps an atomic refcount per content; an object is physically deleted ONLY when its last
reference is released. Objects with no index entry ("untracked", uploaded before dedup existed)
keep the original delete behaviour.

Index layout (ai_assisted_data table — schemaless PK/SK):
  PK = "S3CAS#{project}#{env}"   SK = "SHA#{sha256}"   -> s3_key, size, refcount, created_date
  PK = "S3CASKEY#{s3_key}"       SK = "CAS"            -> sha256, project_name, env   (reverse)

Scoped per project+env on purpose: content is never shared across projects or environments.
Toggle with S3_CONTENT_DEDUP (default on).
"""
import logging
import os
from datetime import datetime, UTC

from botocore.exceptions import ClientError

from src.databases.database import get_table

logger = logging.getLogger(__name__)


def dedup_enabled() -> bool:
    return str(os.getenv("S3_CONTENT_DEDUP", "1")).strip().lower() in ("1", "true", "yes", "on")


def _main_key(project: str, env: str, sha256: str) -> dict:
    return {"PK": f"S3CAS#{project}#{env}", "SK": f"SHA#{sha256}"}


def _reverse_key(s3_key: str) -> dict:
    return {"PK": f"S3CASKEY#{s3_key}", "SK": "CAS"}


def find_existing(project: str, env: str, sha256: str) -> str:
    """Return the canonical s3_key for this content, or "" when unseen."""
    try:
        res = get_table().get_item(Key=_main_key(project, env, sha256))
        item = res.get("Item")
        return str(item.get("s3_key") or "") if isinstance(item, dict) else ""
    except Exception:
        logger.warning("s3_dedup find_existing failed | sha=%s", sha256)
        return ""


def add_reference(project: str, env: str, sha256: str) -> None:
    """Atomically count one more reference to existing content."""
    try:
        get_table().update_item(
            Key=_main_key(project, env, sha256),
            UpdateExpression="ADD refcount :one",
            ExpressionAttributeValues={":one": 1},
        )
    except Exception:
        logger.warning("s3_dedup add_reference failed | sha=%s", sha256)


def register_new(project: str, env: str, sha256: str, s3_key: str, size: int) -> bool:
    """Register freshly-uploaded content as the canonical copy (refcount=1).
    Returns False if another writer registered the same content first (rare race) —
    the caller should then re-lookup and reference the winner instead."""
    table = get_table()
    try:
        table.put_item(
            Item={
                **_main_key(project, env, sha256),
                "s3_key": s3_key,
                "size": int(size or 0),
                "refcount": 1,
                "created_date": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            },
            ConditionExpression="attribute_not_exists(PK)",
        )
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
            return False
        raise
    try:
        table.put_item(Item={
            **_reverse_key(s3_key),
            "sha256": sha256,
            "project_name": project,
            "env": env,
        })
    except Exception:
        logger.warning("s3_dedup reverse-pointer write failed | s3_key=%s", s3_key)
    return True


def release_key(s3_key: str) -> str:
    """Release one reference to an object before deleting it.
    Returns: "untracked" — not in the index (pre-dedup object): caller deletes as before;
             "keep"      — other requests still reference it: caller must NOT delete;
             "delete"    — last reference released: caller deletes; index rows removed here."""
    key = str(s3_key or "").strip()
    if not key:
        return "untracked"
    table = get_table()
    try:
        rev = table.get_item(Key=_reverse_key(key)).get("Item")
    except Exception:
        logger.warning("s3_dedup release_key reverse lookup failed | s3_key=%s", key)
        return "untracked"
    if not isinstance(rev, dict):
        return "untracked"

    sha256 = str(rev.get("sha256") or "")
    project = str(rev.get("project_name") or "")
    env = str(rev.get("env") or "")
    try:
        res = table.update_item(
            Key=_main_key(project, env, sha256),
            UpdateExpression="ADD refcount :minus",
            ExpressionAttributeValues={":minus": -1},
            ReturnValues="UPDATED_NEW",
        )
        remaining = int(res.get("Attributes", {}).get("refcount", 0))
    except Exception:
        logger.warning("s3_dedup release_key decrement failed | s3_key=%s — keeping object (safe side)", key)
        return "keep"

    if remaining > 0:
        logger.info("s3_dedup | object still shared (refcount=%d) — kept | s3_key=%s", remaining, key)
        return "keep"
    try:
        table.delete_item(Key=_main_key(project, env, sha256))
        table.delete_item(Key=_reverse_key(key))
    except Exception:
        logger.warning("s3_dedup index cleanup failed | s3_key=%s", key)
    return "delete"
