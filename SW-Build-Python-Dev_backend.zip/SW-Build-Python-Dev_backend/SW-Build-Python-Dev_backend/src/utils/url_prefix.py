"""Serve the API under a path prefix as well as at the root (new Schaeffler servers, Sep-2026).

On the new servers the dashboard and the API share one host name and the load balancer sends
everything under `/agent` to this backend:

    https://aiasb.schaeffler.cloud          -> dashboard  (local port 8033)
    https://aiasb.schaeffler.cloud/agent/*  -> this API   (local port 8034)

Whether the load balancer strips `/agent` before forwarding is its configuration, not ours, so
the application accepts BOTH shapes: a request for `/agent/final-build` is handled exactly like
`/final-build`. The stripped part moves to SCRIPT_NAME, which is what WSGI defines for this, so
`url_for` keeps generating correct links. Requests without the prefix are untouched, so the old
servers and local runs behave as before.

URL_PATH_PREFIX (default `/agent`) names the prefix; set it empty to switch this off.
"""
import os


class _StripPrefix:
    def __init__(self, wsgi_app, prefix: str):
        self._app = wsgi_app
        self._prefix = prefix

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO", "") or ""
        if path == self._prefix or path.startswith(self._prefix + "/"):
            environ["SCRIPT_NAME"] = (environ.get("SCRIPT_NAME", "") or "") + self._prefix
            environ["PATH_INFO"] = path[len(self._prefix):] or "/"
        return self._app(environ, start_response)


def mount_under_prefix(flask_app, prefix: str | None = None) -> str:
    """Wrap the Flask app once. Returns the prefix in force ('' when disabled)."""
    value = os.getenv("URL_PATH_PREFIX", "/agent") if prefix is None else prefix
    value = "/" + str(value or "").strip().strip("/") if str(value or "").strip().strip("/") else ""
    if value and not isinstance(flask_app.wsgi_app, _StripPrefix):
        flask_app.wsgi_app = _StripPrefix(flask_app.wsgi_app, value)
    return value
