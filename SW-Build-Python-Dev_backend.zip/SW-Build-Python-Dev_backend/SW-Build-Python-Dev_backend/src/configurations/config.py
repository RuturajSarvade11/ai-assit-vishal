# src/configurations/config.py

import os
import logging
from pathlib import Path
from dotenv import load_dotenv

from azure.identity import (
    DefaultAzureCredential,
    get_bearer_token_provider,
    AzureCliCredential,
    ChainedTokenCredential,
    ClientSecretCredential,
    InteractiveBrowserCredential,
)
try:
    from azure.identity import TokenCachePersistenceOptions
except Exception:
    TokenCachePersistenceOptions = None

# --------------------------------------------------
# LOAD ENV
# --------------------------------------------------
# load_dotenv()
load_dotenv(override=True)

# --------------------------------------------------
# BASE PATH
# --------------------------------------------------
DIRNAME = Path(__file__).parent.parent.absolute()

# --------------------------------------------------
# AZURE AUTH
# --------------------------------------------------
AZURE_AUTH_MODE = os.getenv("AZURE_AUTH_MODE", "auto").strip().lower()
_interactive_auth = os.getenv("AZURE_INTERACTIVE_AUTH", "0").strip().lower() in ("1", "true", "yes")
AZURE_TENANT_ID = os.getenv("AZURE_TENANT_ID", "").strip()
AZURE_CLIENT_ID = os.getenv("AZURE_CLIENT_ID", "").strip()
AZURE_CLIENT_SECRET = os.getenv("AZURE_CLIENT_SECRET", "").strip()
_azure_identity_kwargs = {"tenant_id": AZURE_TENANT_ID} if AZURE_TENANT_ID else {}


def _ensure_azure_cli_on_path():
    candidates = [os.getenv("AZURE_CLI_PATH", "").strip()]
    if os.name == "nt":
        candidates.extend((
            os.path.join(os.getenv("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                         "Microsoft SDKs", "Azure", "CLI2", "wbin"),
            os.path.join(os.getenv("ProgramFiles", r"C:\Program Files"),
                         "Microsoft SDKs", "Azure", "CLI2", "wbin"),
        ))

    current_path = os.environ.get("PATH", "").split(os.pathsep)
    normalized_path = {os.path.normcase(os.path.normpath(item.strip('"'))) for item in current_path}
    for candidate in candidates:
        if candidate and os.path.isfile(os.path.join(candidate, "az.cmd")):
            normalized_candidate = os.path.normcase(os.path.normpath(candidate))
            if normalized_candidate not in normalized_path:
                os.environ["PATH"] = candidate + os.pathsep + os.environ.get("PATH", "")
            return


_ensure_azure_cli_on_path()


def _build_interactive_credential():
    kwargs = dict(_azure_identity_kwargs)
    cache_name = os.getenv("AZURE_TOKEN_CACHE_NAME", "ai-sw-backend")
    if TokenCachePersistenceOptions is not None:
        kwargs["cache_persistence_options"] = TokenCachePersistenceOptions(
            name=cache_name,
            allow_unencrypted_storage=True,
        )
    return InteractiveBrowserCredential(**kwargs)

def _build_azure_credential():
    interactive_requested = _interactive_auth or AZURE_AUTH_MODE == "interactive"
    if AZURE_AUTH_MODE == "service_principal":
        if not (AZURE_TENANT_ID and AZURE_CLIENT_ID and AZURE_CLIENT_SECRET):
            raise ValueError(
                "AZURE_AUTH_MODE=service_principal requires AZURE_TENANT_ID, "
                "AZURE_CLIENT_ID, and AZURE_CLIENT_SECRET."
            )
        return ClientSecretCredential(
            tenant_id=AZURE_TENANT_ID,
            client_id=AZURE_CLIENT_ID,
            client_secret=AZURE_CLIENT_SECRET,
        )

    if AZURE_AUTH_MODE == "interactive":
        return _build_interactive_credential()

    if AZURE_AUTH_MODE == "cli":
        return AzureCliCredential(**_azure_identity_kwargs)

    if AZURE_AUTH_MODE == "default":
        return DefaultAzureCredential(exclude_interactive_browser_credential=True)

    # auto mode:
    # 1. Service principal when fully configured
    # 2. Interactive browser when explicitly requested
    # 3. Azure CLI + Default fallback
    if AZURE_TENANT_ID and AZURE_CLIENT_ID and AZURE_CLIENT_SECRET:
        return ClientSecretCredential(
            tenant_id=AZURE_TENANT_ID,
            client_id=AZURE_CLIENT_ID,
            client_secret=AZURE_CLIENT_SECRET,
        )
    if interactive_requested:
        return _build_interactive_credential()
    return ChainedTokenCredential(
        AzureCliCredential(**_azure_identity_kwargs),
        DefaultAzureCredential(exclude_interactive_browser_credential=True),
    )


AZURE_CREDENTIAL = _build_azure_credential()

AZURE_OPENAI_TOKEN_PROVIDER = get_bearer_token_provider(
    AZURE_CREDENTIAL,
    "https://cognitiveservices.azure.com/.default"
)

# API-KEY auth fallback - bypasses MFA / Conditional Access on the tenant (keys are resource-scoped,
# NOT user identities, so they are not subject to user MFA/device policies). When set, the backend
# uses the key instead of the az-login (AAD) credential. Leave blank to use AAD as before.
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY", "").strip()
AZURE_SEARCH_API_KEY = os.getenv("AZURE_SEARCH_API_KEY", "").strip()

# Avoid noisy Azure auth HTTP logs at INFO level.
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.WARNING)
logging.getLogger("azure.identity").setLevel(logging.WARNING)

import src.utils.log_setup  # noqa: F401

# --------------------------------------------------
# AZURE OPENAI / SEARCH CONFIG
# --------------------------------------------------
SEARCH_SERVICE_ENDPOINT = os.getenv("SEARCH_SERVICE_ENDPOINT")
DOCUMENT_INTELLIGENCE_ENDPOINT = os.getenv("DOCUMENT_INTELLIGENCE_ENDPOINT")
OPEN_AI_ENDPOINT = os.getenv("OPEN_AI_ENDPOINT")

OAI_API_VERSION = os.getenv("OAI_API_VERSION")
DOCINT_API_VERSION = os.getenv("DOCINT_API_VERSION")

EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL")
DEFAULT_MODEL = os.getenv("DEFAULT_MODEL")

# --------------------------------------------------
# BACKEND URLS
# --------------------------------------------------
APP_ENV = os.getenv("APP_ENV", os.getenv("ENVIRONMENT", "test")).strip().lower()


def _env_suffix(sep: str) -> str:
    """Resource-name suffix derived from APP_ENV so a SINGLE switch drives every environment.
    uat/prod share the base names (no suffix, matching the original layout); 'dev' -> '<sep>dev';
    any other env -> '<sep><env>' so a brand-new environment gets isolated names automatically.
    Every value below can still be overridden by setting its own env var explicitly.
    """
    if APP_ENV in ("uat", "prod", ""):
        return ""
    return f"{sep}{APP_ENV}"


_SFX = _env_suffix("_")     # underscore suffix: DynamoDB tables, Chroma collections + store path
_S3_SFX = _env_suffix("-")  # hyphen suffix: S3 bucket name

# PORT defaults per env (dev=9055, uat/prod=9052) — override with PORT if needed.
_PORT = os.getenv("PORT", "9055" if APP_ENV == "dev" else "9052")
_BACKEND_HOST = os.getenv("BACKEND_HOST", "10.116.57.117")
_DEFAULT_BACKEND_BASE_BY_ENV = {
    "uat": "https://pmt-ai.aws1678.vitesco.io:442",
    "prod": "https://pmt-ai.aws1678.vitesco.io:442",
    "production": "https://pmt-ai.aws1678.vitesco.io:442",
    "test": f"http://{_BACKEND_HOST}:{_PORT}",
    "qa":   f"http://{_BACKEND_HOST}:{_PORT}",
    "dev":  "https://pmt-ai.aws1678.vitesco.io",
}
BACKEND_PUBLIC_BASE_URL = os.getenv(
    "BACKEND_PUBLIC_BASE_URL",
    _DEFAULT_BACKEND_BASE_BY_ENV.get(APP_ENV, f"http://{_BACKEND_HOST}:{_PORT}"),
).rstrip("/")
REPORT_ERRORS_API_URL = os.getenv(
    "REPORT_ERRORS_API_URL",
    f"{BACKEND_PUBLIC_BASE_URL}/report-errors",
).strip()
REPORT_ERRORS_TIMEOUT_SEC = int(os.getenv("REPORT_ERRORS_TIMEOUT_SEC", "120"))

# LLM analysis of errors and solutions before presenting to Copilot user
LLM_ANALYSIS_ENABLED = os.getenv("LLM_ANALYSIS_ENABLED", "true").strip().lower() in ("1", "true", "yes")

# LLM-driven selection of the exact historical fix (promote + badge). Default off.
LLM_SELECTION_ENABLED = os.getenv("LLM_SELECTION_ENABLED", "false").strip().lower() in ("1", "true", "yes")


# SIMPLE LOGIN (optional; set env vars to enable)
# --------------------------------------------------
LOGIN_USERNAME = os.getenv("LOGIN_USERNAME", "").strip()
LOGIN_PASSWORD = os.getenv("LOGIN_PASSWORD", "").strip()

# --------------------------------------------------
# AZURE SEARCH CONSTANTS
# --------------------------------------------------
INDEX_NAME = "ai-assist-bsw"
VECTOR_FIELD = "error_messageVector"
K_NEAREST_NEIGHBORS = 1
SEMANTIC_CONFIG_NAME = "ai-assist-config"
SELECT_FIELDS = ["error_id", "error_message", "solution"]

# --------------------------------------------------
# DYNAMODB CONFIG
# --------------------------------------------------
DYNAMODB_REGION = os.getenv("DYNAMODB_REGION", "eu-central-1")
# Derived from APP_ENV: dev -> DynamoDB Local; uat/prod -> AWS cloud (empty). Override with
# DYNAMODB_ENDPOINT (set it empty to force cloud even in dev).
DYNAMODB_ENDPOINT = os.getenv(
    "DYNAMODB_ENDPOINT", "http://localhost:8000" if APP_ENV == "dev" else ""
).strip()
# Derived suffix: dev -> "_dev"; uat/prod -> "" (table names unchanged).
DYNAMODB_TABLE_SUFFIX = os.getenv("DYNAMODB_TABLE_SUFFIX", _SFX).strip()

# --------------------------------------------------
# S3 CONFIG (bucket name derived from APP_ENV: pmt-ai-s3 / pmt-ai-s3-dev)
# --------------------------------------------------
S3_REGION = os.getenv("S3_REGION", "ap-south-1")
_S3_BUCKET_BASE = os.getenv("S3_BUCKET_BASE", "pmt-ai-s3")
S3_BUCKET = os.getenv("S3_BUCKET", f"{_S3_BUCKET_BASE}{_S3_SFX}")

# --------------------------------------------------
# CHROMADB CONFIG (path + collection names derived from APP_ENV)
# --------------------------------------------------
CHROMA_VECTOR_STORE_PATH = os.getenv("CHROMA_VECTOR_STORE_PATH", f"./SchaefflerVectorStore{_SFX}")
CHROMA_COLLECTION_ERROR  = os.getenv("CHROMA_COLLECTION_ERROR", f"error_with_solution{_SFX}")
CHROMA_COLLECTION_DOCS   = os.getenv("CHROMA_COLLECTION_DOCS", f"document_data_injection{_SFX}")
CHROMA_COLLECTION_ARTIFACTS = os.getenv("CHROMA_COLLECTION_ARTIFACTS", f"artifact_embeddings{_SFX}")

# --------------------------------------------------
# FEEDBACK ADAPTER (learned step "W") - ADDITIVE, OFF BY DEFAULT
# A small linear map applied on top of the FROZEN base embeddings (z = x @ W) so
# the search FINDS the fix proven to work for a kind of error. While disabled,
# the base vectors and all existing behaviour are completely unchanged. It turns
# on only when a validated adapter file exists AND FEEDBACK_ADAPTER_ENABLED=1.
# --------------------------------------------------
FEEDBACK_ADAPTER_ENABLED = os.getenv("FEEDBACK_ADAPTER_ENABLED", "false").strip().lower() in ("1", "true", "yes")
FEEDBACK_ADAPTER_PATH = os.getenv("FEEDBACK_ADAPTER_PATH", f"./feedback_adapter/adapter_W{_SFX}.npy")
FEEDBACK_ADAPTER_DIM = int(os.getenv("FEEDBACK_ADAPTER_DIM", "0"))            # 0 -> same size as input (3072)
FEEDBACK_ADAPTER_EPOCHS = int(os.getenv("FEEDBACK_ADAPTER_EPOCHS", "400"))
FEEDBACK_ADAPTER_LR = float(os.getenv("FEEDBACK_ADAPTER_LR", "0.5"))
FEEDBACK_ADAPTER_MARGIN = float(os.getenv("FEEDBACK_ADAPTER_MARGIN", "1.0"))
FEEDBACK_ADAPTER_BATCH = int(os.getenv("FEEDBACK_ADAPTER_BATCH", "512"))
FEEDBACK_ADAPTER_TEST_FRAC = float(os.getenv("FEEDBACK_ADAPTER_TEST_FRAC", "0.3"))
# a fix must be shared by >= this many DISTINCT errors to be a usable training/eval signal
FEEDBACK_ADAPTER_MIN_CLUSTER = int(os.getenv("FEEDBACK_ADAPTER_MIN_CLUSTER", "2"))
# promote a newly trained adapter only if held-out top-1 improves by >= this many points
FEEDBACK_ADAPTER_MIN_GAIN_PP = float(os.getenv("FEEDBACK_ADAPTER_MIN_GAIN_PP", "2.0"))
# How much a developer's vote counts against a proven fix when training W (the
# adapter should respond to feedback). A fix that made the build pass is stronger evidence than
# a click, so votes enter the same objective at a lower weight. 0 disables them entirely and
# reproduces the fix-only behaviour exactly.
FEEDBACK_ADAPTER_VOTE_WEIGHT = float(os.getenv("FEEDBACK_ADAPTER_VOTE_WEIGHT", "0"))
# parallel collection holding the W-transformed (learned-space) error vectors. When the adapter
# is on it is the ranking that is used; the base ranking is still searched so the trace can show
# both similarities (no rank fusion). Rebuilt by build_learned_space.py.
FEEDBACK_ADAPTER_LEARNED_COLLECTION = os.getenv(
    "FEEDBACK_ADAPTER_LEARNED_COLLECTION", f"{CHROMA_COLLECTION_ERROR}_learned")

# SHADOW-MODE prediction capture (prediction-feedback enhancement, roadmap step A): on build
# FAILURE the extension silently runs the prediction on the broken state and stores the report
# server-side (report_kind="shadow", never shown on the client-facing report pages). This is the
# server-side kill switch - when off, incoming shadow reports are acknowledged but not stored.
SHADOW_PREDICTION_CAPTURE_ENABLED = os.getenv("SHADOW_PREDICTION_CAPTURE_ENABLED", "true").strip().lower() in ("1", "true", "yes")

# ARTIFACT-domain adapter (W_artifact) - prediction-feedback enhancement, one adapter per
# embedding domain. Same math/trainer as the error adapter, but trained on ARTIFACT vectors
# (artifact chunk -> proven-fix pairs) and applied to the artifact-evidence search. Separate
# file + separate runtime toggle, so error and artifact learning switch independently.
FEEDBACK_ADAPTER_ARTIFACT_ENABLED = os.getenv("FEEDBACK_ADAPTER_ARTIFACT_ENABLED", "false").strip().lower() in ("1", "true", "yes")
FEEDBACK_ADAPTER_ARTIFACT_PATH = os.getenv("FEEDBACK_ADAPTER_ARTIFACT_PATH", f"./feedback_adapter/adapter_W_artifact{_SFX}.npy")
FEEDBACK_ADAPTER_ARTIFACT_LEARNED_COLLECTION = os.getenv(
    "FEEDBACK_ADAPTER_ARTIFACT_LEARNED_COLLECTION", f"{CHROMA_COLLECTION_ARTIFACTS}_learned")

# T13 - GLOBAL (cross-project) DATA-INJECTION search: ARTIFACTS + DOCUMENTS. ON by default (client:
# artifacts/tasks/documents are reusable knowledge - task names are unique - so they should NOT be
# tightly coupled to a project). Recommendation (error->solution) STAYS project-scoped: a fix from
# another project references paths that don't exist here. Set DATA_INJECTION_GLOBAL=0 to restore
# project-scoped artifact + document search.
DATA_INJECTION_GLOBAL = os.getenv("DATA_INJECTION_GLOBAL", "1").strip().lower() in ("1", "true", "yes", "on")

# T3 - shift vector search/storage to Azure AI Search. When ON: READS come from Azure and WRITES are
# DUAL-written to BOTH Chroma AND Azure (no data loss, hot rollback). OFF by default -> Chroma only.
# Verify parity on dev (counts + sample queries) before enabling on UAT.
# VECTOR_STORE is a friendly single switch in the .env ('azure' | 'chroma'); it sets the DEFAULT for
# USE_AZURE_SEARCH so `VECTOR_STORE=azure` is not a silent no-op. An explicit USE_AZURE_SEARCH /
# AZURE_ONLY still takes precedence.
_VECTOR_STORE = os.getenv("VECTOR_STORE", "").strip().lower()
USE_AZURE_SEARCH = os.getenv("USE_AZURE_SEARCH",
                             "1" if _VECTOR_STORE == "azure" else "0").strip().lower() in ("1", "true", "yes", "on")
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT",
                                  "https://cscspq001aiswbuildq.search.windows.net").rstrip("/")
# AZURE_ONLY: decommission Chroma entirely - NO local store is created or opened; reads AND writes go
# ONLY to Azure. The W-adapter learned space (Chroma-only, not yet migrated) is disabled in this mode.
# Enable only after parity is verified. Implies USE_AZURE_SEARCH.
AZURE_ONLY = os.getenv("AZURE_ONLY", "0").strip().lower() in ("1", "true", "yes", "on")
if AZURE_ONLY:
    USE_AZURE_SEARCH = True

# --------------------------------------------------
# LIVE FEEDBACK LINK (online, no scripts) - the human-driven loop.
# When a developer marks a solution Helpful for an error, that (error -> solution) link is
# used to SURFACE the human-validated solution the next time the SAME error appears. It is
# updated automatically on every vote (the feedback is already stored live) and applied at
# query time - no training script, no scheduled job. Boost-only (never demotes), and inert
# until such votes exist. Kill-switch: set FEEDBACK_LINK_BOOST_ENABLED=0.
# --------------------------------------------------
FEEDBACK_LINK_BOOST_ENABLED = os.getenv("FEEDBACK_LINK_BOOST_ENABLED", "true").strip().lower() in ("1", "true", "yes")

# --------------------------------------------------
# RECOMMENDATION RELEVANCE THRESHOLD: a query with NO relevant match in the
# database must not receive confident-looking top-3 results ("whichever is on top of the list").
# Candidates whose final_score falls below this value are NOT shown; the response says
# "no sufficiently similar past error" instead. DEFAULT 0 = gate OFF (behavior unchanged) —
# the value is set AFTER calibration trials (exact / close / deviated / unrelated probes).
# final_score scale: see _evaluate_recommendation_strength.
# --------------------------------------------------
try:
    RECOMMENDATION_MIN_FINAL_SCORE = float(os.getenv("RECOMMENDATION_MIN_FINAL_SCORE", "0") or 0)
except ValueError:
    RECOMMENDATION_MIN_FINAL_SCORE = 0.0

# --------------------------------------------------
# SAMPLE / DEMO FILES (UNCHANGED)
# --------------------------------------------------
EXAMPLE_DOCUMENTS = [
    {
        "bookId": "3005",
        "title": "Mastering Cloud Computing",
        "author": "Alice Johnson",
        "description": (
            "A practical guide to cloud computing concepts, "
            "including Azure, AWS, scalability, and security best practices."
        ),
        "genre": "Technology",
    },
    {
        "bookId": "3006",
        "title": "Mindful Living",
        "author": "Robert Brown",
        "description": (
            "An inspiring book on mindfulness, stress reduction, "
            "meditation techniques, and achieving mental well-being."
        ),
        "genre": "Health",
    }
]

EXAMPLE_DOCUMENT_PATH = os.path.abspath(
    os.path.join(DIRNAME, "files/aks_onboarding.pdf")
)

EXAMPLE_IMAGE_PATH = os.path.abspath(
    os.path.join(DIRNAME, "files/triangle.png")
)

# --------------------------------------------------
# STARTUP CONFIG SUMMARY
# --------------------------------------------------
_cfg_logger = logging.getLogger(__name__)
_cfg_logger.debug(
    "Config loaded | APP_ENV=%s | PORT=%s | BACKEND_HOST=%s | BACKEND_PUBLIC_BASE_URL=%s",
    APP_ENV, _PORT, _BACKEND_HOST, BACKEND_PUBLIC_BASE_URL,
)
_cfg_logger.debug(
    "DynamoDB config | region=%s | endpoint=%s | table_suffix=%s",
    DYNAMODB_REGION, DYNAMODB_ENDPOINT or "<AWS cloud>", DYNAMODB_TABLE_SUFFIX or "<none>",
)
_cfg_logger.debug(
    "S3 config | region=%s | bucket=%s",
    S3_REGION, S3_BUCKET,
)
_cfg_logger.debug(
    "ChromaDB config | path=%s | collection_error=%s | collection_docs=%s",
    CHROMA_VECTOR_STORE_PATH, CHROMA_COLLECTION_ERROR, CHROMA_COLLECTION_DOCS,
)
