"""
Fire ONE real recommendation through the full pipeline (search + task-ledger recall +
hybrid artifact fusion + rerank + gate + trace save) with the live master/task4 inputs —
no VS Code needed. Creates a REAL new trace; read it with verify_task4_case.py.

    python simulate_recommendation.py                 # ctc_aurix 6.2r1p456 failure (default)
    python verify_task4_case.py --expect-top dff04ba7

    python simulate_recommendation.py --case python   # the VICE-VERSA test: python 3.112120.0
    python verify_task4_case.py --expect-token 3.112120.0 --expect-top 7a6f17c8

The two cases share the SAME task and near-identical report chatter — only the artifact
root cause differs. Running both proves the ranking is EVIDENCE-DYNAMIC, not a static
preference: whichever failure the live debug.log names, THAT family's solution wins.

Uses the same code the running service uses, imported fresh from THIS checkout — so it
exercises the pulled commits even before the service restart (the service still needs the
restart for the VS Code path).
"""
import argparse
import sys

import src.utils.log_setup  # noqa: F401
from src.services import handlers

ERROR_MESSAGE = """Created inputs snapshot in [4] ms
Copied input files in [5] ms
Creating snapshot for [c:\\LegacyApp\\ctc_aurix\\6.2r1p4].
Created  snapshot for [c:\\LegacyApp\\ctc_aurix\\6.2r1p4] in [0] ms
Local installation of tool ctc_aurix:6.2r1p4 is UP-TO-DATE
Finished installing all relevant tools for the GBE process task4
Starting the execution of the command line(s)  for the GBE process task4
cmd
/c
c:/LegacyApp/python/3.10.0/python.exe
D:\\Build type error\\TestGbe\\build\\master\\task4/in/read_json_config.py
D:\\Build type error\\TestGbe\\build\\master\\task4/in/config.json
D:\\Build type error\\TestGbe\\build\\master\\task4/out
2026-08-24 18:11:26 - read_json_config.py starting...
Error parsing input file
2026-08-24 18:11:26,619 'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p456'."""

DEBUG_LOG = """2026-08-24 18:11:26,615 [INFO] 2026-08-24 18:11:26 - read_json_config.py starting...
2026-08-24 18:11:26,615 [DEBUG] Detailed debug log file=D:\\Build type error\\TestGbe\\build\\master\\task4\\log\\debug.log
2026-08-24 18:11:26,616 [DEBUG] Script started.
2026-08-24 18:11:26,616 [DEBUG] json_path=D:\\Build type error\\TestGbe\\build\\master\\task4\\in\\config.json
2026-08-24 18:11:26,616 [DEBUG] output_dir=D:\\Build type error\\TestGbe\\build\\master\\task4\\out
2026-08-24 18:11:26,616 [DEBUG] log_dir=D:\\Build type error\\TestGbe\\build\\master\\task4\\log
2026-08-24 18:11:26,616 [DEBUG] Reading JSON file from disk.
2026-08-24 18:11:26,618 [DEBUG] Starting validation for config root keys: ['project', 'build', 'tools', 'targets']
2026-08-24 18:11:26,618 [ERROR] Error parsing input file
2026-08-24 18:11:26,619 [DEBUG] 'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p456'."""


# The vice-versa case: SAME task, same chatter — the artifact names PYTHON as the culprit.
PY_ROOT_CAUSE = "'tools[name=python].version' must be '3.10.0' but got '3.112120.0'."
ERROR_MESSAGE_PY = ERROR_MESSAGE.replace(
    "'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p456'.", PY_ROOT_CAUSE)
DEBUG_LOG_PY = DEBUG_LOG.replace(
    "'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p456'.", PY_ROOT_CAUSE)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", choices=["ctc", "python"], default="ctc",
                    help="which root cause the live artifacts name (default: ctc)")
    args = ap.parse_args()
    message, log = ((ERROR_MESSAGE_PY, DEBUG_LOG_PY) if args.case == "python"
                    else (ERROR_MESSAGE, DEBUG_LOG))
    print(f"SIMULATING: {args.case} failure on :TARGETS:master:task4")
    result = handlers._run_report_error_recommendation(
        project_name="testgbe",
        errors=[{
            "severity": "ERROR",
            "message": message,
            "task_path": ":TARGETS:master:task4",
            "file_path": "task4.process.gradle.kts",
        }],
        task_path=":TARGETS:master:task4",
        query_artifact_text="debug.log\n" + log,
        query_changed_files=["config.xml"],
        user_requested_task="TARGETS:master:task4",
        query_artifact_excerpts=[{"name": "debug.log", "text": log}],
    )
    trace_id = str((result or {}).get("trace_id") or "")
    recs = (result or {}).get("recommendations") or []
    print()
    print(f"NEW TRACE: {trace_id or '(no trace id returned)'}")
    print(f"match_status: {(result or {}).get('match_status')}")
    for r in recs[:5]:
        print(f"  rank {r.get('rank')}: {str(r.get('request_id'))[:8]} | task={r.get('task_name')} "
              f"| type={r.get('match_type')} | final={r.get('final_score')}")
    print()
    print("Now run:  python verify_task4_case.py --expect-top dff04ba7")
    return 0


if __name__ == "__main__":
    sys.exit(main())
