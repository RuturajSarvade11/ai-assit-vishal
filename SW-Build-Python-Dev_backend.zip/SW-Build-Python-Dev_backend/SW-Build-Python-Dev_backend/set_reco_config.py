"""
Set recommendation-config knobs directly on the server (the admin API requires a token,
and the dashboard page does not yet expose every knob — artifactMatchWeight included).

    python set_reco_config.py artifactMatchWeight=30
    python set_reco_config.py taskMatchWeight=10 artifactMatchWeight=30
    python set_reco_config.py --show

Valid keys: minSimilarityPercent (0-100), taskMatchWeight (0-30), artifactMatchWeight
(0-60), minSemanticSimilarity (0-1), downvoteSinkMinVotes (1-10),
similarityWeightedScoring (true/false), distinctiveMatchWeight (0-60, 0 = off),
scoringMode (additive|evidence), evidenceScale, supportScale, fileContentMatchWeight,
feedbackSupportWeight. Values are clamped by the config module itself.

    python set_reco_config.py distinctiveMatchWeight=0
    python set_reco_config.py scoringMode=evidence
"""
import sys

import src.utils.log_setup  # noqa: F401
from src.services import recommendation_config as rc

VALID = {"minSimilarityPercent", "taskMatchWeight", "artifactMatchWeight",
         "minSemanticSimilarity", "downvoteSinkMinVotes", "similarityWeightedScoring",
         "baseTaskWeight", "baseFileWeight", "baseTokenWeight", "llmPromoteEnabled",
         "evidenceSimilarityWeight", "historyWeightCeiling",
         "afterPatternWeight", "semanticMatchBase",
         # Same keys the admin API accepts (route.py update_recommendation_config) - these
         # were missing here, so the hidden-bonus weight and the scoring mode could only be
         # changed with a token and curl.
         "distinctiveMatchWeight", "scoringMode", "evidenceScale", "supportScale",
         "fileContentMatchWeight", "feedbackSupportWeight"}


def main() -> int:
    args = [a for a in sys.argv[1:] if a.strip()]
    if not args or args == ["--show"]:
        print("current config:", rc.get_config(force=True))
        return 0
    updates = {}
    for arg in args:
        if "=" not in arg:
            print(f"ignored (expected key=value): {arg}")
            continue
        key, _, value = arg.partition("=")
        key = key.strip()
        if key not in VALID:
            print(f"ignored (unknown key): {key} — valid: {sorted(VALID)}")
            continue
        v = value.strip()
        updates[key] = (v.lower() in ("1", "true", "yes", "on")) if key in ("similarityWeightedScoring", "llmPromoteEnabled") else v
    if not updates:
        print("nothing to update")
        return 1
    result = rc.set_values(updates, updated_by="set_reco_config.py")
    print("updated:", updates)
    print("config now:", rc.get_config(force=True))
    return 0


if __name__ == "__main__":
    main()
