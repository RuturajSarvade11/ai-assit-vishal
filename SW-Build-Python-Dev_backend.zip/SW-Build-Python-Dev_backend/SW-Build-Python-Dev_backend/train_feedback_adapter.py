"""
Train + validate + (promote) the feedback adapter "W" from REAL data.

Reads the error_with_solution embeddings (Chroma) and resolves each error's
proven-fix signature (DynamoDB final-build payload, using the backend's own
solution normalisation) to build (error vector -> fix label) pairs. Trains the
adapter on a train split, validates on a HELD-OUT split, and saves it ONLY if
held-out top-1 improves by >= FEEDBACK_ADAPTER_MIN_GAIN_PP.

SAFETY: read-only on Chroma / S3 / DynamoDB (get / get_item only). Writes ONLY the
adapter file (config.FEEDBACK_ADAPTER_PATH). It never modifies the live store's
vectors and never changes recommendation behaviour - the adapter stays inert
until FEEDBACK_ADAPTER_ENABLED=1 (query wiring is Phase 2). To avoid embedded-
Chroma concurrency / version-migration on open, run against a COPY of the vector
store (set CHROMA_VECTOR_STORE_PATH to the copy) or when the backend is idle.

Run in the backend venv with APP_ENV set:
    python train_feedback_adapter.py             # train + promote if it passes the gate
    python train_feedback_adapter.py --dry-run   # evaluate only, never save
    python train_feedback_adapter.py --dim 512   # smaller/faster adapter output size
"""
import argparse
import hashlib
import json
import re
import time
from collections import defaultdict

import numpy as np

from src.configurations import config
from src.utils.project_details import get_final_build_payload
from src.utils import feedback_adapter as fa


# --- fix signature: TRAINING-side grouping only. Deliberately tolerant (whitespace/line-marker
# normalization) so the same logical fix groups together for adapter training. This is NOT the
# storage duplicate decision — storage identity is a plain exact checksum over the solution
# content (approved storage doc, Section 6): see handlers._solution_signature_hash_from_payload. ---
def _normalize_solution_value(value):
    if isinstance(value, dict):
        if "fileName" in value or "changes" in value:
            entry = {}
            if "fileName" in value:
                entry["fileName"] = _normalize_solution_value(value.get("fileName"))
            if "changes" in value:
                entry["changes"] = _normalize_solution_value(value.get("changes"))
            return entry
        ignored = {"request_id", "uuid", "created_date", "updated_date", "recommended_count"}
        return {str(k): _normalize_solution_value(v)
                for k, v in sorted(value.items(), key=lambda i: str(i[0]))
                if str(k) not in ignored}
    if isinstance(value, list):
        items = [_normalize_solution_value(i) for i in value]
        try:
            return sorted(items, key=lambda i: json.dumps(i, sort_keys=True, separators=(",", ":")))
        except Exception:
            return items
    if isinstance(value, str):
        clean = re.sub(r"\[\[line:\d+\]\]|\[\[hunk:\d+\]\]", "", value)
        return " ".join(clean.replace("\r", "").split())
    return value


def _solution_signature(payload):
    if not isinstance(payload, dict):
        return ""
    sol = payload.get("solution", [])
    if not isinstance(sol, list) or not sol:
        return ""
    canonical = json.dumps(_normalize_solution_value(sol), sort_keys=True, separators=(",", ":"))
    return hashlib.sha1(canonical.encode("utf-8")).hexdigest()


def build_dataset(col=None):
    # col=None -> standalone CLI run (own client). The in-process auto-trainer passes the backend's
    # live collection so there is only ONE Chroma client (serialized writes = no corruption).
    if col is None:
        print(f"APP_ENV={config.APP_ENV} | store={config.CHROMA_VECTOR_STORE_PATH} | "
              f"collection={config.CHROMA_COLLECTION_ERROR}")
        import chromadb  # lazy: only the standalone-CLI path needs Chroma (the in-process trainer passes col)
        client = chromadb.PersistentClient(path=config.CHROMA_VECTOR_STORE_PATH)
        col = client.get_collection(config.CHROMA_COLLECTION_ERROR)
    data = col.get(include=["embeddings", "documents", "metadatas"])
    embs = data.get("embeddings")
    embs = [] if embs is None else embs
    docs = data.get("documents") or []
    metas = data.get("metadatas") or []
    # Azure: the `embedding` field is non-retrievable, so the collection returns no vectors. Recover
    # them by RE-EMBEDDING the stored error text (the `document` field IS retrievable) - same model,
    # same text => same space as the live query path. (Chroma returns embeddings, so this is skipped.)
    if docs and (len(embs) == 0 or embs[0] is None or len(embs[0]) == 0):
        # Cached and resumable: the previous one-shot pass in batches of 200 lost the
        # whole run to a single rate limit and kept nothing, so each retry was no likelier to
        # finish than the last. See src/utils/embedding_cache.py.
        from src.utils.embedding_cache import embed_documents
        embs = embed_documents(docs, label="error corpus")

    payload_cache = {}
    vecs, labels, sigs = [], [], []
    skip = defaultdict(int)
    for i, m in enumerate(metas):
        emb = embs[i] if i < len(embs) else None
        if emb is None or len(emb) == 0:
            skip["no_embedding"] += 1
            continue
        req = (m.get("request_id") or "").strip()
        if not req:
            skip["no_request_id"] += 1
            continue
        if req not in payload_cache:
            try:
                payload_cache[req] = get_final_build_payload(req) or {}
            except Exception:
                payload_cache[req] = {}
        sig = _solution_signature(payload_cache[req])
        if not sig:
            skip["no_solution"] += 1
            continue
        vecs.append(np.asarray(emb, dtype=np.float32))
        labels.append(sig)
        sigs.append(m.get("error_signature_hash") or "")
    X = np.vstack(vecs) if vecs else np.empty((0, 0))
    return X, labels, sigs, dict(skip)


def filter_clusters(X, labels, sigs, min_cluster):
    by = defaultdict(set)
    for lab, es in zip(labels, sigs):
        by[lab].add(es)
    keep = [i for i, lab in enumerate(labels) if len(by[lab]) >= min_cluster]
    sizes = sorted((len(v) for v in by.values() if len(v) >= min_cluster), reverse=True)
    return X[keep], [labels[i] for i in keep], sizes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="evaluate only; never save")
    ap.add_argument("--dim", type=int, default=(config.FEEDBACK_ADAPTER_DIM or 0))
    ap.add_argument("--min-gain", type=float, default=config.FEEDBACK_ADAPTER_MIN_GAIN_PP)
    args = ap.parse_args()

    t0 = time.time()
    X, labels, sigs, skip = build_dataset()
    print(f"raw usable (vector, fix) pairs: {len(labels)} | skipped={skip}")
    if len(labels) == 0:
        print("No data. Aborting.")
        return

    Xc, yc, sizes = filter_clusters(X, labels, sigs, config.FEEDBACK_ADAPTER_MIN_CLUSTER)
    print(f"after cluster filter (fix shared by >= {config.FEEDBACK_ADAPTER_MIN_CLUSTER} distinct errors): "
          f"{len(yc)} errors across {len(sizes)} fixes | top cluster sizes={sizes[:12]}")
    if len(yc) < 20:
        print("Too few usable pairs for a stable adapter - collect more resolved fixes first. Aborting.")
        return

    dim_msg = f"{args.dim}" if args.dim else f"{Xc.shape[1]} (full)"
    print(f"training adapter (output dim={dim_msg}) ... full 3072 takes a few minutes on CPU; "
          f"use --dim 512 for a quick run. Live progress below:", flush=True)
    res, W = fa.evaluate_and_train(Xc, yc, dim_out=(args.dim or None), verbose=True)
    if not res.get("ok"):
        print("Eval failed:", res.get("reason"))
        return
    b, l = res["baseline"], res["learned"]
    print("\n=== held-out validation (unseen errors) ===")
    print(f"  train={res['n_train']} held-out={res['n_heldout']} fixes={res['n_fixes']} "
          f"dim={res['input_dim']}->{res['output_dim']}")
    print(f"  top-1: {b[1]*100:5.1f}% -> {l[1]*100:5.1f}%  ({res['gain_top1_pp']:+.1f}pp)")
    print(f"  top-3: {b[3]*100:5.1f}% -> {l[3]*100:5.1f}%  ({res['gain_top3_pp']:+.1f}pp)")

    passes_gate = (l[1] > b[1]) and (res["gain_top1_pp"] >= args.min_gain)
    if args.dry_run:
        print(f"\nDRY-RUN: not saving. (gate {'PASS' if passes_gate else 'FAIL'} at >= {args.min_gain}pp)")
    elif passes_gate:
        meta = {"metrics": res, "trained_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "app_env": config.APP_ENV, "min_gain_pp": args.min_gain}
        path = fa.save_adapter(W, meta)
        print(f"\nPROMOTED -> saved adapter to {path}")
        print("It stays inert until FEEDBACK_ADAPTER_ENABLED=1 (query wiring is Phase 2).")
    else:
        print(f"\nNOT promoted (held-out gain {res['gain_top1_pp']:+.1f}pp < {args.min_gain}pp). No file written.")
    print(f"done in {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
