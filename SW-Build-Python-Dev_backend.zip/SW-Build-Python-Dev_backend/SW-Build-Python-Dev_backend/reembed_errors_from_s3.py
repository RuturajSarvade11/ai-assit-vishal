"""
Re-embed all ERROR vectors from the S3 raw (the source of truth), so OLD data that was stored in
CHUNKS becomes a SINGLE full-error vector per error. Retrieval then matches the whole error in one
go instead of against fragmented chunks.

Why: older errors were embedded in chunks (pre block-mode), which splits one failure's signal
across several vectors and weakens matching. The full raw error is preserved in S3 (keyed by
request_id), so we rebuild the error collection cleanly:
  * each error -> ONE vector holding the full error, up to the embedding model's capacity
    (text-embedding-3-large ~ 8,191 tokens ~ 28k chars, set by VECTOR_BLOCK_MODE caps);
  * nothing in S3 or DynamoDB is modified — only the ERROR vector collection is rebuilt from them;
  * artifact and document collections are left untouched.

NOTE: errors LARGER than the embedding capacity are currently truncated to the cap by the embedder
(no single vector can hold more). If you have such errors and want them chunked instead of trimmed,
say so and we'll add overflow-chunking — but virtually all build errors sit well under the cap.

REQUIRES VECTOR_BLOCK_MODE=1 (single-vector errors). Run with the backend STOPPED, in the venv,
with the target .env (APP_ENV):

    python reembed_errors_from_s3.py --dry-run   # count requests, change nothing
    python reembed_errors_from_s3.py             # rebuild error vectors from S3

TIP: back up the Chroma folder first (only the error collection is rebuilt).
"""
import logging
import os
import sys
import time

import src.utils.log_setup  # noqa: F401

from src.configurations import config
from src.utils import project_details as pd
from src.utils import recommended as rec
from src.services import handlers
from src.services.handlers import _finalize_request_vectors

log = logging.getLogger("reembed_errors")
DRY_RUN = "--dry-run" in sys.argv


def reset_error_collection() -> None:
    """Drop + recreate ONLY the error collection, removing the old chunked vectors. The fresh
    collection is repopulated from S3 below. Artifact/document collections are untouched.

    IMPORTANT: the embedder (recommended.py) holds a module-level `collection` object bound at
    import. We must reset through recommended's OWN client AND rebind recommended.collection, or
    every upsert hits the deleted collection ('Collection [...] does not exist')."""
    name = config.CHROMA_COLLECTION_ERROR
    if DRY_RUN:
        log.info("[dry-run] would reset error collection '%s'", name)
        return
    try:
        rec.client.delete_collection(name)
        log.info("deleted error collection '%s' (old chunked vectors removed)", name)
    except Exception as exc:
        log.warning("delete '%s' (may not exist): %s", name, exc)
    # Rebind the module-level collection the embedder actually uses, so upserts hit the fresh one.
    rec.collection = rec.client.get_or_create_collection(name)
    log.info("recreated + rebound empty error collection '%s'", name)


def all_request_ids() -> list[str]:
    rows = pd._scan_all(pd.final_build_payload_table)
    ids = {str(r.get("request_id")).strip() for r in rows if r.get("request_id")}
    ids.discard("")
    return sorted(ids)


# --- Signature dedup for the migration: ONE vector per unique error message --------------------
# The collection was just reset, so the persistent dedup index would skip everything ("already
# vectorized") and produce an empty collection. We therefore drive dedup from a FRESH in-memory
# index that we rebuild as we go: the first time a signature is seen it is embedded once; every
# duplicate (same error across many S3 payloads) REUSES that one vector instead of adding another.
# We still write the REAL DynamoDB index (overwrite, no deletes) so future uploads dedup correctly.
_seen_index: dict = {}
_real_save_index = handlers.save_error_vector_index


def _mig_get_index(project_name, env, error_hash):
    return _seen_index.get((str(project_name), str(env), str(error_hash)))


def _mig_save_index(project_name, env, error_hash, error_message, vector_id):
    _seen_index[(str(project_name), str(env), str(error_hash))] = {"vector_id": vector_id}
    try:
        return _real_save_index(
            project_name=project_name, env=env, error_hash=error_hash,
            error_message=error_message, vector_id=vector_id,
        )
    except Exception as exc:
        log.warning("save_error_vector_index failed | hash=%s | %s", error_hash, exc)
        return None


def main() -> None:
    block_mode = str(os.getenv("VECTOR_BLOCK_MODE", "0")).strip().lower() in ("1", "true", "yes", "on")
    log.info(
        "RE-EMBED start | APP_ENV=%s | collection=%s | block_mode=%s | dry_run=%s",
        config.APP_ENV, config.CHROMA_COLLECTION_ERROR, block_mode, DRY_RUN,
    )
    log.info("Rebuilds only the ERROR vector collection from S3 raw. DynamoDB and S3 are NOT modified.")
    if not block_mode:
        log.warning("VECTOR_BLOCK_MODE is OFF — errors would be re-embedded in the OLD chunked way. "
                    "Set VECTOR_BLOCK_MODE=1 before running so each error becomes a single vector.")

    reset_error_collection()

    # Dedup by error signature: keep ONE embedding per unique error message. Use a fresh in-memory
    # index (the collection was just reset) and mirror writes to the real DynamoDB index. Duplicate
    # errors across many S3 payloads collapse to a single vector instead of one per copy.
    if not DRY_RUN:
        handlers.get_error_vector_index = _mig_get_index
        handlers.save_error_vector_index = _mig_save_index

    ids = all_request_ids()
    log.info("re-embedding %d request(s) from S3 raw (dedup by error signature)", len(ids))
    if DRY_RUN:
        log.info("[dry-run] would re-embed %d requests — exiting without changes", len(ids))
        return

    ok = fail = 0
    started = time.monotonic()
    for i, rid in enumerate(ids, 1):
        try:
            _finalize_request_vectors(rid)
            ok += 1
        except Exception as exc:
            fail += 1
            log.error("[%d/%d] request_id=%s FAILED: %s", i, len(ids), rid, exc)
        if i % 20 == 0 or i == len(ids):
            log.info("progress %d/%d | ok=%d | fail=%d | elapsed=%ds", i, len(ids), ok, fail, int(time.monotonic() - started))

    log.info(
        "RE-EMBED done | ok=%d | fail=%d | total_requests=%d | UNIQUE error vectors embedded=%d "
        "(duplicates collapsed)", ok, fail, len(ids), len(_seen_index),
    )
    if fail:
        log.warning("Some requests failed (their S3 payload may be missing). No history was deleted; "
                    "re-run after fixing S3 access to rebuild those too.")


if __name__ == "__main__":
    main()
