"""Backend down-alert watchdog.

THE SCENARIO: a developer restarts the backend service and forgets to start it
again. It then sits down until somebody happens to notice. An email must go out when that happens.

WHY THIS RUNS OUTSIDE THE APP: a stopped process cannot report that it stopped. Anything inside
the backend can only tell you about failures it SURVIVES. So this is a separate, tiny process on
the same machine, run every few minutes by Task Scheduler / cron. It only needs the machine to be
up, which is exactly the case being watched.

WHY IT DOES NOT PAGE ON EVERY RESTART: a deliberate restart takes seconds, and an alert every time
a developer restarts would train everyone to ignore the alerts. It emails only after FAIL_STREAK
consecutive failed checks, and only on a CHANGE of state - one mail when it goes down, one when it
comes back, nothing in between however long the outage lasts.

    python watchdog_alert.py            # one check (what the scheduler runs)
    python watchdog_alert.py --status   # show current state, send nothing
    python watchdog_alert.py --test     # send a test email, prove SES works

Configuration comes from the same .env the backend uses. Until the SES values are filled in the
watchdog still runs and still tracks state - it just logs instead of mailing, so it can be
installed and verified before the credentials arrive.
"""
import argparse
import json
import os
import smtplib
import socket
import sys
import time
from datetime import datetime, timezone
from email.message import EmailMessage

try:
    from dotenv import load_dotenv
    load_dotenv(override=True)
except Exception:                                     # dotenv is optional for this script
    pass

import urllib.error
import urllib.request

# --- what to watch -------------------------------------------------------------------------
HEALTH_URL = (os.getenv("WATCHDOG_HEALTH_URL")
              or f"http://127.0.0.1:{os.getenv('PORT', '9052')}/health")
TIMEOUT_SEC = int(os.getenv("WATCHDOG_TIMEOUT_SEC", "10"))
# Consecutive failures before the first alert. With a 2-minute schedule, 3 gives a ~6 minute
# grace window - long enough that a normal restart never alerts, short enough to be useful.
FAIL_STREAK = int(os.getenv("WATCHDOG_FAIL_STREAK", "3"))
STATE_FILE = os.getenv("WATCHDOG_STATE_FILE") or os.path.join(
    os.path.dirname(os.path.abspath(__file__)), ".watchdog_state.json")

# --- how to mail (Amazon SES over SMTP) ----------------------------------------------------
SES_HOST = os.getenv("SES_SMTP_HOST", "").strip()
SES_PORT = int(os.getenv("SES_SMTP_PORT", "587"))
SES_USER = os.getenv("SES_SMTP_USERNAME", "").strip()
SES_PASS = os.getenv("SES_SMTP_PASSWORD", "").strip()
MAIL_FROM = os.getenv("ALERT_MAIL_FROM", "").strip()
MAIL_TO = [a.strip() for a in os.getenv("ALERT_MAIL_TO", "").split(",") if a.strip()]
ENV_LABEL = os.getenv("APP_ENV", "unknown").upper()
HOSTNAME = socket.gethostname()


def _now() -> str:
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")


def _log(message: str) -> None:
    print(f"{_now()} | {message}", flush=True)


def _mail_configured() -> bool:
    return bool(SES_HOST and SES_USER and SES_PASS and MAIL_FROM and MAIL_TO)


def check_health() -> tuple[bool, str]:
    """(healthy, detail). Any failure to get a 2xx counts as down - including a refused
    connection, which is exactly what a stopped process looks like."""
    try:
        req = urllib.request.Request(HEALTH_URL, headers={"User-Agent": "sw-build-watchdog"})
        with urllib.request.urlopen(req, timeout=TIMEOUT_SEC) as resp:
            code = resp.getcode()
            if 200 <= code < 300:
                return True, f"HTTP {code}"
            return False, f"HTTP {code}"
    except urllib.error.HTTPError as exc:
        return False, f"HTTP {exc.code}"
    except urllib.error.URLError as exc:
        # ConnectionRefused lands here: the port is closed, i.e. the service is not running.
        return False, f"unreachable ({exc.reason})"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _read_state() -> dict:
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {"consecutive_failures": 0, "alerted_down": False, "last_change": ""}


def _write_state(state: dict) -> None:
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as fh:
            json.dump(state, fh, indent=2)
    except Exception as exc:                          # never let bookkeeping break the check
        _log(f"WARN could not write state file: {exc}")


def send_mail(subject: str, body: str) -> bool:
    if not _mail_configured():
        _log("mail NOT configured (SES_SMTP_* / ALERT_MAIL_* missing) - would have sent:")
        _log(f"    subject: {subject}")
        return False
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = MAIL_FROM
    msg["To"] = ", ".join(MAIL_TO)
    msg.set_content(body)
    try:
        with smtplib.SMTP(SES_HOST, SES_PORT, timeout=30) as smtp:
            smtp.starttls()
            smtp.login(SES_USER, SES_PASS)
            smtp.send_message(msg)
        _log(f"mail sent to {', '.join(MAIL_TO)}: {subject}")
        return True
    except Exception as exc:
        _log(f"ERROR sending mail: {type(exc).__name__}: {exc}")
        return False


def _down_body(detail: str, failures: int) -> str:
    return (
        f"The AI Assisted SW Build backend is not responding.\n\n"
        f"Environment : {ENV_LABEL}\n"
        f"Machine     : {HOSTNAME}\n"
        f"Checked     : {HEALTH_URL}\n"
        f"Result      : {detail}\n"
        f"Failed      : {failures} consecutive checks\n"
        f"Time        : {_now()}\n\n"
        f"The most common cause is the service being stopped for a restart and not started\n"
        f"again. To start it, on that machine:\n\n"
        f"    cd <backend folder>\n"
        f"    python main.py\n\n"
        f"You will get a second email automatically when it is back up.\n"
    )


def _up_body(downtime_since: str) -> str:
    return (
        f"The AI Assisted SW Build backend is responding again.\n\n"
        f"Environment : {ENV_LABEL}\n"
        f"Machine     : {HOSTNAME}\n"
        f"Checked     : {HEALTH_URL}\n"
        f"Down since  : {downtime_since or 'unknown'}\n"
        f"Recovered   : {_now()}\n"
    )


def run_once() -> int:
    state = _read_state()
    healthy, detail = check_health()

    if healthy:
        if state.get("alerted_down"):
            send_mail(f"[{ENV_LABEL}] AI SW Build backend is BACK UP",
                      _up_body(state.get("last_change", "")))
            _log(f"RECOVERED ({detail}) - recovery mail sent")
        else:
            _log(f"ok ({detail})")
        _write_state({"consecutive_failures": 0, "alerted_down": False,
                      "last_change": _now() if state.get("alerted_down") else state.get("last_change", "")})
        return 0

    failures = int(state.get("consecutive_failures") or 0) + 1
    already = bool(state.get("alerted_down"))
    _log(f"DOWN ({detail}) - failure {failures}/{FAIL_STREAK}")

    if failures >= FAIL_STREAK and not already:
        send_mail(f"[{ENV_LABEL}] AI SW Build backend is DOWN", _down_body(detail, failures))
        already = True
        _log("down mail sent")
    elif already:
        # Still down - deliberately silent, one alert per outage.
        _log("still down - no further mail until it recovers")

    _write_state({"consecutive_failures": failures, "alerted_down": already,
                  "last_change": state.get("last_change") or _now()})
    return 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--status", action="store_true", help="show configuration and state, send nothing")
    ap.add_argument("--test", action="store_true", help="send a test email and exit")
    args = ap.parse_args()

    if args.status:
        healthy, detail = check_health()
        state = _read_state()
        print(f"health url      : {HEALTH_URL}")
        print(f"health now      : {'UP' if healthy else 'DOWN'} ({detail})")
        print(f"alert after     : {FAIL_STREAK} consecutive failures")
        print(f"mail configured : {_mail_configured()}")
        print(f"mail to         : {', '.join(MAIL_TO) or '(none)'}")
        print(f"state file      : {STATE_FILE}")
        print(f"state           : {json.dumps(state)}")
        return 0

    if args.test:
        ok = send_mail(f"[{ENV_LABEL}] AI SW Build alert test",
                       f"This is a test from the backend watchdog.\n\n"
                       f"Machine : {HOSTNAME}\nTime    : {_now()}\n\n"
                       f"If you received this, down-alerts will reach you.\n")
        return 0 if ok else 1

    return run_once()


if __name__ == "__main__":
    sys.exit(main())
