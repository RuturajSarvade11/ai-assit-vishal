# =====================================================================================
# Accuracy test - Sankar's exact case from report 4.html (task4, TestGbe)
# Full A/B/C: baseline -> similarity weighting -> artifact match. Prints the complete
# per-candidate decomposition so we can SEE what the pipeline actually used.
#
# PREREQUISITE: backend running this branch (commit 1604cced or later) - pull + restart.
# Run on the server (or any machine that reaches the API):
#   powershell -ExecutionPolicy Bypass -File .\test_sankar_case.ps1
#   powershell -ExecutionPolicy Bypass -File .\test_sankar_case.ps1 -Base "http://localhost:9055"
# It prompts for the dashboard admin password - credentials are never stored here.
# =====================================================================================
param(
    [string]$Base = "http://localhost:9055",
    [string]$Email = "omkar.kadam2-ext@mail.schaeffler.com",
    [string]$Password = ""
)

if ($Password -eq "") {
    $secure = Read-Host "Dashboard password for $Email" -AsSecureString
    $Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
        [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure))
}

# ---- login ----
$loginBody = @{ email = $Email; password = $Password } | ConvertTo-Json
try {
    $login = Invoke-RestMethod -Method Post -Uri "$Base/auth/login" -ContentType "application/json" -Body $loginBody
} catch {
    Write-Host "LOGIN FAILED - check the password and rerun. ($($_.Exception.Message))" -ForegroundColor Red
    exit 1
}
if (-not $login.token) {
    Write-Host "LOGIN FAILED - no token returned. Check credentials." -ForegroundColor Red
    exit 1
}
$h = @{ Authorization = "Bearer $($login.token)" }
Write-Host "Logged in." -ForegroundColor Green

function Set-RecoConfig([string]$json) {
    Invoke-RestMethod -Method Put -Uri "$Base/recommendation-config" -Headers $h -ContentType "application/json" -Body $json | Out-Null
}

# ---- the EXACT error from Sankar's report 4.html (task4 ERROR diagnostic) ----
$errorText = @'
com.vitesco.gbe.exception.ProcessExecutionException: task4 Execution failed with exit code 1
2026-08-19 10:38:20 - read_json_config.py starting...
Error parsing input file
'@

$body = @{
    projectName   = "testgbe"
    error_message = $errorText
    taskPath      = ":TARGETS:master:task4"
    path          = "task4.process.gradle.kts"
} | ConvertTo-Json

function Show-LatestTrace([string]$label) {
    $t = Invoke-RestMethod -Uri "$Base/recommendation-traces/recent?limit=1" -Headers $h
    $trace = $t.traces[0]
    Write-Host "`n=== $label | trace $($trace.trace_id) | gate: $($trace.gate_status) | threshold: $($trace.threshold_min_final) | adapter: $($trace.adapter_error_on) ===" -ForegroundColor Cyan
    $trace.candidates | Format-Table rank, @{n='req';e={$_.request_id.Substring(0,8)}}, similarity,
        match_score, context_score, final_score,
        @{n='ctx split (base/patch/success/pattern/artifact/task)';e={
            $c = $_.context_components
            if ($c) { "$($c.base)/$($c.patch)/$($c.success)/$($c.after_pattern)/$($c.artifact)/$($c.task_weight)" } else { '-' }
        }},
        @{n='artifact sim';e={$_.artifact_match_similarity}},
        shown, task_name -AutoSize -Wrap | Out-Host
    return $trace.trace_id
}

function Run-Case([string]$label) {
    $r = Invoke-RestMethod -Method Post -Uri "$Base/recommendations" -Headers $h -ContentType "application/json" -Body $body
    Write-Host "Returned matches: $(@($r.matched_ids).Count)"
    return Show-LatestTrace $label
}

# ---- A: BASELINE (all knobs off) ----
Write-Host "`nA: baseline - all knobs OFF..." -ForegroundColor Yellow
Set-RecoConfig '{"similarityWeightedScoring": false, "artifactMatchWeight": 0, "taskMatchWeight": 0}'
Start-Sleep 31
$tA = Run-Case "A: BASELINE"

# ---- B: similarity weighting ON ----
Write-Host "B: similarity weighting ON..." -ForegroundColor Yellow
Set-RecoConfig '{"similarityWeightedScoring": true}'
Start-Sleep 31
$tB = Run-Case "B: SIMILARITY WEIGHTED"

# ---- C: + artifact match ON (weight 10) ----
Write-Host "C: + artifact match weight 10..." -ForegroundColor Yellow
Set-RecoConfig '{"artifactMatchWeight": 10}'
Start-Sleep 31
$tC = Run-Case "C: SIMILARITY + ARTIFACT"

Write-Host "`nConfig now in force:" -ForegroundColor Yellow
(Invoke-RestMethod -Uri "$Base/recommendation-config" -Headers $h).data | Format-List | Out-Host

Write-Host "Traces: A=$tA B=$tB C=$tC - open Admin Settings -> Recommendation Trace to compare cards." -ForegroundColor Green
Write-Host "Reading C: the 'artifact sim' column is the proof the pipeline touched the stored artifacts."
Write-Host "artifact sim empty on every row = candidates have no artifact summaries stored (that is the gap to fix at upload)."
