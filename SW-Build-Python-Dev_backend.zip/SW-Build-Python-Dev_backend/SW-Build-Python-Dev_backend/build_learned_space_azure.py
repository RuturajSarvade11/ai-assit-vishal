"""
build_learned_space_azure.py - fill the adapter's search index on Azure.

Training produces the adapter W. It does NOT fill the parallel index that the second search
reads, and that is a separate step which has been missing on Azure: build_learned_space.py opens
Chroma directly, so on an AZURE_ONLY deployment it cannot run at all. The result was an adapter
that could be trained and switched on while every learned query returned nothing, the fusion
quietly fell back to the base ranking, and the trace reported "active" throughout.

    python build_learned_space_azure.py --dry-run     # transform and report, write nothing
    python build_learned_space_azure.py               # create the index and upload
    python build_learned_space_azure.py --domain artifact

What it does:

  1. loads the promoted adapter for the domain
  2. reads the base collection - on Azure the stored vectors are non-retrievable, so the error
     TEXT is re-embedded through the same model the live query path uses, which is what keeps
     the two in the same space
  3. applies W and unit-normalises, because the search compares by dot product
  4. recreates the index AT THE ADAPTER'S OUTPUT WIDTH and uploads

Step 4 is the one that bit us. An index built for one adapter width rejects every query from an
adapter of another, and the rejection was being handled as though the store were corrupt - so it
looked like an empty index rather than a mismatched one. The width is printed here and checked
before anything is written.
"""
import argparse
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

BATCH = 500


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--domain", default="error", choices=["error", "artifact"])
    ap.add_argument("--dry-run", action="store_true", help="transform and report; write nothing")
    ap.add_argument("--limit", type=int, default=0, help="only the first N records (for a trial run)")
    args = ap.parse_args()

    from src.configurations import config
    from src.utils import feedback_adapter as fa
    from src.azure_search.azure_collection import ensure_azure_index, AzureCollection, to_index_name

    if args.domain == "error":
        base_name = config.CHROMA_COLLECTION_ERROR
        learned_name = config.FEEDBACK_ADAPTER_LEARNED_COLLECTION
        adapter_path = config.FEEDBACK_ADAPTER_PATH
    else:
        base_name = config.CHROMA_COLLECTION_ARTIFACTS
        learned_name = config.FEEDBACK_ADAPTER_ARTIFACT_LEARNED_COLLECTION
        adapter_path = config.FEEDBACK_ADAPTER_ARTIFACT_PATH

    print(f"domain={args.domain}  base={base_name}  ->  learned={learned_name}")
    print(f"index name: {to_index_name(learned_name)}")

    W, meta = fa.load_adapter(adapter_path)
    if W is None:
        print(f"\nNo adapter at {adapter_path}.")
        print("Train one first (train_feedback_adapter.py), then promote it (promote_adapter.py).")
        print("Without an adapter there is nothing to build a learned space FROM.")
        return 1
    in_dim, out_dim = int(W.shape[0]), int(W.shape[1])
    print(f"adapter W: {in_dim} -> {out_dim}"
          + (f"  (trained {meta.get('saved_at')})" if meta.get("saved_at") else ""))

    # ---------------------------------------------------------------- read the base corpus
    base = AzureCollection(base_name)
    data = base.get(include=["embeddings", "documents", "metadatas"])
    ids = data.get("ids") or []
    docs = data.get("documents") or []
    metas = data.get("metadatas") or []
    embs = data.get("embeddings") or []
    if args.limit:
        ids, docs, metas = ids[:args.limit], docs[:args.limit], metas[:args.limit]
        embs = embs[:args.limit] if len(embs) else embs
    print(f"base records: {len(ids)}")
    if not ids:
        print("nothing to build.")
        return 1

    if len(embs) == 0 or embs[0] is None or len(embs[0]) == 0:
        # Azure marks the vector field non-retrievable, so the stored vectors do not come back.
        # Re-embedding the stored TEXT with the same model puts them in the same space as the
        # live query, which is the only thing that makes the comparison meaningful.
        print("stored vectors are not retrievable - re-embedding the stored text")
        from src.utils.embedding_cache import embed_documents
        embs = embed_documents(docs, label=f"{args.domain} corpus")

    keep = [i for i, e in enumerate(embs) if e is not None and len(e)]
    if len(keep) != len(ids):
        print(f"  {len(ids) - len(keep)} record(s) had no vector and are skipped")
    X = np.asarray([embs[i] for i in keep], dtype=np.float64)
    ids = [ids[i] for i in keep]
    docs = [docs[i] if i < len(docs) else "" for i in keep]
    metas = [metas[i] if i < len(metas) else {} for i in keep]

    if X.shape[1] != in_dim:
        print(f"\nDIMENSION MISMATCH: the corpus is {X.shape[1]} wide, the adapter expects {in_dim}.")
        print("The adapter was trained against a different embedding model or size. Retrain it.")
        return 1

    Z = fa.l2norm(X @ W).astype(np.float32)
    print(f"transformed: {X.shape} -> {Z.shape}")

    if args.dry_run:
        print("\ndry run - nothing written.")
        print(f"the index would be recreated at width {out_dim} with {len(Z)} vector(s).")
        return 0

    # ---------------------------------------------------------------- write
    # recreate=True is deliberate. A leftover index of a different width rejects every query,
    # and that failure is indistinguishable from an empty one at the point it is felt.
    print(f"recreating the index at width {out_dim} ...")
    ensure_azure_index(learned_name, out_dim, recreate=True)
    learned = AzureCollection(learned_name)

    t0 = time.time()
    for i in range(0, len(ids), BATCH):
        learned.upsert(
            ids=ids[i:i + BATCH],
            embeddings=[z.tolist() for z in Z[i:i + BATCH]],
            documents=docs[i:i + BATCH],
            metadatas=metas[i:i + BATCH],
        )
        print(f"  {min(i + BATCH, len(ids))}/{len(ids)}", flush=True)
    print(f"\ndone in {time.time() - t0:.1f}s - {len(ids)} vector(s) at width {out_dim}")
    print("\nCheck it took: python debug_adapter_effect.py --project <name> --query \"<error text>\"")
    print("'in BOTH' must be greater than zero, or the adapter still cannot affect a score.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
