"""
backfill_raw_vectors.py — re-store existing error vectors from their RAW archived payloads.

Why: the pipeline is now RAW end-to-end — collection, embedding and
recommendation all use the verbatim error text. Vectors stored BEFORE this change were built
from focused slices (character-window cuts, 1000-char caps in the pre-block era), so a raw
query meets non-raw stored text and identity/similarity breaks. The archived S3 payload zips
hold the ORIGINAL raw capture — this script re-derives the raw blocks from them through the
PRODUCTION vectorization path and then removes the superseded focused-slice vectors.

Per request id:
  1. read current vector references (old vectors + their signatures)
  2. rebuild raw blocks from the archived payloads (same code the live pipeline runs)
  3. skip when the stored signatures already match the raw ones (already raw = idempotent)
  4. --apply: run handlers._finalize_request_vectors(request_id)  -> raw vectors + signature
     index/summary/reference rows, env-family resolved, duplicate-solution semantics intact
  5. delete ONLY the old vector ids that the raw family did not keep, plus their reference
     rows and dangling signature-index rows. Never deletes when step 4 produced nothing.

Usage (backend box, venv active — DRY-RUN by default, nothing is written):

  python backfill_raw_vectors.py                      # dry-run, project TESTGBE
  python backfill_raw_vectors.py --apply              # do it, project TESTGBE
  python backfill_raw_vectors.py --project X --apply  # another project
  python backfill_raw_vectors.py --request-id <id> --apply   # a single request
  python backfill_raw_vectors.py --limit 5 --apply    # first N (oldest first)

A JSON report is written next to this script after every run.
"""
import argparse
import json
import logging
import sys

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s")
logger = logging.getLogger("backfill_raw_vectors")

from boto3.dynamodb.conditions import Key                      # noqa: E402

from src.services import handlers                              # noqa: E402
from src.utils import project_details as pd                    # noqa: E402
from src.utils.recommended import delete_error_vectors         # noqa: E402


def _raw_blocks_for_request(rid: str):
    """The raw blocks the PRODUCTION pipeline would store for this request today."""
    messages = []
    for row in handlers.get_archived_payload_references(rid) or []:
        s3_key = str((row or {}).get("s3_key") or "").strip()
        if not s3_key:
            continue
        try:
            payload = handlers.download_payload_zip(s3_key=s3_key, expected_sha256=row.get("sha256"))
        except Exception:
            logger.warning("archive unreadable | request_id=%s | s3_key=%s", rid, s3_key)
            continue
        messages.extend(handlers._extract_error_messages(payload, include_context=True))
    blocks = handlers._prepare_messages_for_vectorization(messages)
    return blocks


def _old_reference_rows(rid: str):
    rows = pd.get_vector_references(rid) or []
    out = []
    for r in rows:
        vid = str((r or {}).get("vector_id") or "").strip()
        sig = str((r or {}).get("error_signature_hash") or "").strip().lower()
        sk = str((r or {}).get("SK") or "").strip()
        if vid:
            out.append({"vector_id": vid, "sig": sig, "SK": sk})
    return out


def _delete_reference_rows(rid: str, stale_vector_ids: set) -> int:
    deleted = 0
    for r in _old_reference_rows(rid):
        if r["vector_id"] in stale_vector_ids and r["SK"]:
            try:
                pd.ai_assisted_data_table.delete_item(Key={"PK": rid, "SK": r["SK"]})
                deleted += 1
            except Exception:
                logger.exception("reference row delete failed | rid=%s | SK=%s", rid, r["SK"])
    return deleted


def _delete_dangling_index_rows(project: str, sigs: set, stale_vector_ids: set) -> int:
    """Signature-index rows that still point at a deleted vector would let a future legacy-mode
    write 'reuse' a vector that no longer exists. Remove exactly those."""
    deleted = 0
    envs = list(dict.fromkeys(list(handlers._KNOWN_SIGNATURE_ENVS) + ["dev", "test", "prod"]))
    for sig in sigs:
        for env in envs:
            try:
                idx = pd.get_error_vector_index(project, env, sig) or {}
            except Exception:
                idx = {}
            vid = str(idx.get("vector_id") or "").strip()
            if vid and vid in stale_vector_ids:
                try:
                    pd.ai_assisted_data_table.delete_item(
                        Key={"PK": f"ERROR#{project}#{env}#{sig}", "SK": "VECTOR"})
                    deleted += 1
                except Exception:
                    logger.exception("index row delete failed | project=%s env=%s sig=%s", project, env, sig)
    return deleted


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default="TESTGBE")
    ap.add_argument("--request-id", default="", help="backfill just this request")
    ap.add_argument("--limit", type=int, default=0, help="stop after N requests (0 = all)")
    ap.add_argument("--apply", action="store_true", help="write changes (default: dry-run)")
    args = ap.parse_args()

    project = args.project.strip().lower()
    if not handlers._error_raw_mode():
        print("ERROR_TEXT_RAW_MODE is OFF — this backfill only makes sense in raw mode. Aborting.")
        sys.exit(2)

    if args.request_id.strip():
        rows = [{"request_id": args.request_id.strip(), "created_date": ""}]
    else:
        rows = list(pd.list_final_build_payloads_by_project(project) or [])
        rows.sort(key=lambda r: str((r or {}).get("created_date") or ""))  # oldest first

    mode = "APPLY" if args.apply else "DRY-RUN"
    print(f"=== RAW VECTOR BACKFILL | project={project} | requests={len(rows)} | {mode} ===")

    report = {"project": project, "mode": mode, "requests": []}
    done = 0
    for row in rows:
        rid = str((row or {}).get("request_id") or "").strip()
        if not rid:
            continue
        if args.limit and done >= args.limit:
            break

        old = _old_reference_rows(rid)
        old_ids = {r["vector_id"] for r in old}
        old_sigs = {r["sig"] for r in old if r["sig"]}

        blocks = _raw_blocks_for_request(rid)
        new_sigs = set()
        for b in blocks:
            s = handlers._signature_hash_from_text(b)
            if s:
                new_sigs.add(s.lower())

        entry = {"request_id": rid, "old_vectors": len(old_ids),
                 "raw_blocks": len(blocks), "action": ""}

        if not blocks:
            entry["action"] = "SKIP: no raw source (no readable archive / no failure text)"
            print(f"{rid}  {entry['action']}")
            report["requests"].append(entry)
            done += 1
            continue

        if new_sigs and new_sigs.issubset(old_sigs):
            entry["action"] = "SKIP: already raw (signatures match)"
            print(f"{rid}  {entry['action']}")
            report["requests"].append(entry)
            done += 1
            continue

        if not args.apply:
            entry["action"] = (f"WOULD re-vectorize {len(blocks)} raw block(s), "
                               f"then delete stale old vectors (of {len(old_ids)})")
            print(f"{rid}  {entry['action']}  first_block={blocks[0][:70]!r}")
            report["requests"].append(entry)
            done += 1
            continue

        # ---- APPLY ----
        try:
            handlers._finalize_request_vectors(rid)
        except Exception:
            logger.exception("finalize failed | rid=%s — old vectors kept", rid)
            entry["action"] = "ERROR: finalize failed, nothing deleted"
            report["requests"].append(entry)
            done += 1
            continue

        after = _old_reference_rows(rid)
        keep_ids = {r["vector_id"] for r in after if r["sig"] in new_sigs}
        if not keep_ids:
            entry["action"] = "ERROR: no raw reference rows after finalize — nothing deleted"
            print(f"{rid}  {entry['action']}")
            report["requests"].append(entry)
            done += 1
            continue

        stale = old_ids - keep_ids
        removed = delete_error_vectors(sorted(stale)) if stale else 0
        ref_rows = _delete_reference_rows(rid, stale) if stale else 0
        idx_rows = _delete_dangling_index_rows(project, old_sigs - new_sigs, stale) if stale else 0

        entry["action"] = (f"OK: raw blocks={len(blocks)} kept_vectors={len(keep_ids)} "
                           f"deleted_vectors={removed} deleted_ref_rows={ref_rows} deleted_index_rows={idx_rows}")
        print(f"{rid}  {entry['action']}")
        report["requests"].append(entry)
        done += 1

    out = "backfill_raw_vectors_report.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    print(f"\n{done} request(s) processed ({mode}). Report: {out}")


if __name__ == "__main__":
    main()
