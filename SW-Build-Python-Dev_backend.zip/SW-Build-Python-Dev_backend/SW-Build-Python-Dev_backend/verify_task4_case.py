"""
Verify the artifact-evidence ranking guarantees against a REAL recommendation trace.

Run AFTER the tester triggers the failure and requests a recommendation (the checks read
the newest stored decision chain - no HTTP, no auth, direct trace store read):

    python verify_task4_case.py                          # newest trace
    python verify_task4_case.py --request <request_id>   # traces of one request/trace id
    python verify_task4_case.py --expect-token r1p456 --expect-top 0a2b52c5

Checks:
  1  live artifact capture is COMPLETE (query artifacts contain the root-cause token)
  2  artifact evidence fired (a candidate matched via the user's artifact content)
  3  evidence wins: the candidate with the strongest exact-token overlap is ranked #1
  4  the expected solution is ranked #1 (default prefix 0a2b52c5 - the dev ctc_aurix fix)
  5  contrast is active when evidence disagrees (#1 earns the full artifact weight)
  6  INFO: #1's stored task vs the failing task (after the same fix is re-confirmed on the
     user's task, the task refresh + family-representative rule make these EQUAL)
"""
import argparse
import sys

import src.utils.log_setup  # noqa: F401
from src.utils import recommendation_trace


def flt(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--request", default="", help="request or trace id (default: newest trace)")
    ap.add_argument("--expect-token", default="r1p456", help="root-cause token expected in query artifacts")
    ap.add_argument("--expect-top", default="0a2b52c5", help="request-id prefix expected at rank 1")
    args = ap.parse_args()

    if args.request.strip():
        traces = recommendation_trace.get_traces_for_request(args.request.strip())
    else:
        traces = recommendation_trace.list_recent(1)
    if not traces:
        print("FAIL: no trace found - run a recommendation first")
        return 1
    trace = traces[0]

    print(f"trace {trace.get('trace_id')} | {trace.get('SK', '')[:20]} | project={trace.get('project_name')}")
    print(f"failing task: {trace.get('task_path')} | changed: {trace.get('changed_files')}")
    q_arts = trace.get("query_artifacts") or []
    q_text = " ".join(str((a or {}).get("text") or "") for a in q_arts if isinstance(a, dict))
    print(f"query artifacts: {[str((a or {}).get('name') or '') for a in q_arts if isinstance(a, dict)]}"
          f" | total {len(q_text)} chars")

    cands = [c for c in (trace.get("candidates") or []) if isinstance(c, dict)]
    if not cands:
        print("FAIL: trace has no candidates")
        return 1

    print()
    print(f"{'rk':<3}{'request':<10}{'task':<24}{'final':<8}{'art_sim':<9}{'vec':<7}{'tok':<7}"
          f"{'contrast':<9}{'via':<18}{'shown':<6}")
    for c in cands:
        am = c.get("artifact_matched") or {}
        print(f"{str(c.get('rank')):<3}{str(c.get('request_id'))[:8]:<10}"
              f"{str(c.get('task_name'))[:22]:<24}{str(c.get('final_score'))[:6]:<8}"
              f"{str(c.get('artifact_match_similarity'))[:7]:<9}"
              f"{str(am.get('vector_similarity'))[:5]:<7}{str(am.get('token_overlap'))[:5]:<7}"
              f"{str(am.get('contrast'))[:7]:<9}{str(am.get('via'))[:16]:<18}"
              f"{str(c.get('shown')):<6}")

    # Context decomposition of the top shown candidates: exactly which points built each
    # score (base task/file/token, admin task weight, artifact lift, success, after-pattern).
    print()
    for c in cands[:3]:
        comp = c.get("context_components") or {}
        print(f"#{c.get('rank')} {str(c.get('request_id'))[:8]} context breakdown: "
              + (", ".join(f"{k}={v}" for k, v in comp.items()) or "(none)")
              + f" | task_weight_applied={c.get('task_match_weight_applied')}")

    print()
    passed = True
    token = args.expect_token.strip().lower()

    ok1 = token in q_text.lower()
    print(f"{'PASS' if ok1 else 'FAIL'} 1: query artifacts carry the root-cause token '{token}' "
          f"(live capture complete)")
    passed &= ok1

    # The probe LABEL changed: one probe per live artifact file, keyed
    # "artifact:<name>", with the old single "artifact_content" key demoted to a fallback for
    # extensions that send no per-file excerpts. This check kept comparing for equality against
    # the pre-rename label, so every modern extension produced FAIL 2 unconditionally - it read
    # as "artifact evidence never fired" on traces where artifact lift of 20+ points had plainly
    # been applied, and it sent a live accuracy investigation chasing a probe that was working.
    # Matched by PREFIX, the same class test the engine itself uses (handlers.py _art_probes).
    via_hits = [c for c in cands
                if str((c.get("artifact_matched") or {}).get("via") or "").startswith("artifact")]
    ok2 = bool(via_hits)
    _vias = sorted({str((c.get("artifact_matched") or {}).get("via") or "") for c in via_hits})
    print(f"{'PASS' if ok2 else 'FAIL'} 2: artifact-content probe matched "
          f"({len(via_hits)} candidate(s) via {', '.join(_vias) or 'nothing'})")
    passed &= ok2

    shown = [c for c in cands if str(c.get("shown")).lower() == "true"] or cands
    rank1 = min(shown, key=lambda c: int(c.get("rank") or 99))

    # The LLM evidence-selection layer runs AFTER the trace snapshot and promotes its pick to
    # Candidate 1 in the developer's webview (stamped on the trace as llm_pick). What the
    # DEVELOPER sees first = the promoted pick when present, else trace rank 1.
    pick = trace.get("llm_pick") or {}
    if pick:
        print(f"INFO: LLM evidence pick = {str(pick.get('request_id'))[:8]} "
              f"(confidence {pick.get('confidence')}) - {pick.get('note')}")
    dev_top = str(pick.get("request_id") or "") if str(pick.get("promoted")).lower() == "true" \
        else str(rank1.get("request_id") or "")

    with_tok = [(flt((c.get("artifact_matched") or {}).get("token_overlap")), c) for c in cands]
    best_tok, best_cand = max(with_tok, key=lambda x: x[0])
    ok3 = best_tok <= 0 or str(best_cand.get("request_id")) == dev_top
    print(f"{'PASS' if ok3 else 'FAIL'} 3: strongest exact-token evidence is the developer's Candidate 1 "
          f"(best tok={best_tok:.2f} on {str(best_cand.get('request_id'))[:8]}, "
          f"dev_top={dev_top[:8]}, trace rank1={str(rank1.get('request_id'))[:8]})")
    passed &= ok3

    ok4 = dev_top.startswith(args.expect_top.strip())
    print(f"{'PASS' if ok4 else 'FAIL'} 4: expected solution shown to the developer as Candidate 1 "
          f"(want {args.expect_top}*, got {dev_top[:8]})")
    passed &= ok4

    r1_contrast = str((rank1.get("artifact_matched") or {}).get("contrast") or "")
    print(f"INFO 5: rank1 contrast={r1_contrast or '(off - evidence spread < 0.15 or single artifact)'}")

    q_task = str(trace.get("task_path") or "").strip(":").split(":")[-1].lower()
    r1_task = str(rank1.get("task_name") or "").strip(":").split(":")[-1].lower()
    print(f"INFO 6: failing task '{q_task}' vs rank1 stored task '{r1_task}' - "
          + ("MATCH" if q_task and q_task == r1_task else
         "different (expected until the same fix is confirmed on the user's task; the "
         "29-Jul task refresh + 24-Aug family rule then align them - re-confirm and rerun)"))

    print()
    print("RESULT:", "ALL CHECKS PASSED" if passed else "SOME CHECKS FAILED - paste this output back")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
