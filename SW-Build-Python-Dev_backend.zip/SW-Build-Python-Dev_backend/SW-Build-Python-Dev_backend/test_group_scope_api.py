"""Developer API test for GROUP SCOPE - does sharing evidence across a group actually work,
and does it stay safe?

Run this BEFORE handing the feature to a tester in VS Code. It exercises the real pipeline
(search + recall + artifact fusion + rerank + gate + trace) exactly as the service does, so a
failure here is a real failure, not a test artefact.

WHAT IT PROVES, in order of how badly each would hurt if wrong:

  1. NO REGRESSION      With scope=project, ranking is exactly what it is today.
  2. THE RULE HOLDS     An UNGROUPED project never widens, even with scope=group.
                        ("Other" is a removal bucket, not a group.)
  3. SHARING WORKS      A project in a DEFINED group can see its siblings' solutions.
  4. EVIDENCE STILL     A cross-project candidate does NOT win just for being visible.
     DECIDES            The failure's own log still picks the winner.

Usage:

    python test_group_scope_api.py --discover
        Reads the group configuration and tells you which projects can actually be tested,
        WITHOUT changing anything. Start here - group scope does nothing where no group is
        defined, and that looks identical to "broken".

    python test_group_scope_api.py --project <name> --task <task> --error-file <path>
        Runs the same failure under both scopes and compares. Restores the original scope
        setting afterwards, even if a check fails.

Nothing here writes solutions or artifacts. It only reads, and it puts the scope knob back.
"""
import argparse
import io
import sys

import src.utils.log_setup  # noqa: F401

from src.services import handlers
from src.services import project_groups as pg
from src.services import recommendation_config as rc


def _set_scope(value: str) -> None:
    """Write the scope and make sure the running process SEES it.

    get_config() caches for a TTL, so writing alone is not enough - the very next
    recommendation would read the stale value and the comparison below would be meaningless.
    The scope resolver has its own short cache too; both are cleared here.
    """
    rc.set_values({"recommendationScope": value}, updated_by="test_group_scope_api.py")
    rc.get_config(force=True)
    try:
        pg._scope_cache.clear()
    except Exception:
        pass
    print(f"  [scope set to '{value}']")


def _rule(title: str) -> None:
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)


def _scope_of(project: str):
    members, mode = pg.resolve_scope_projects(project)
    return members, mode


def discover() -> int:
    """Show what CAN be tested. Group scope is invisible where no group is defined, so this
    exists to stop a correct 'nothing changed' being read as a broken feature."""
    _rule("GROUP CONFIGURATION")
    defs = pg.list_group_defs()
    if not defs:
        print("  No groups are defined.")
        print("  Group scope will correctly change NOTHING until a group exists on")
        print("  Prediction Config -> Project Group Configuration.")
        return 1
    for d in defs:
        print(f"  group {d['group_name']:<20} pattern {d.get('project_pattern') or '(none)'}")

    from src.utils.project_details import get_all_projects
    names = sorted({str((r or {}).get("project_name") or "").strip().lower()
                    for r in (get_all_projects() or []) if (r or {}).get("project_name")})
    overrides = pg.get_overrides()

    _rule("PROJECTS AND THEIR GROUPS")
    by_group = {}
    for n in names:
        g = pg.resolve_group(n, defs, overrides)
        by_group.setdefault(g, []).append(n)
    for g in sorted(by_group):
        marker = "  <- ungrouped: will NOT share (by design)" if g == pg.DEFAULT_GROUP else ""
        print(f"  {g:<20} {len(by_group[g])} project(s){marker}")
        for n in by_group[g]:
            print(f"      {n}")

    _rule("WHAT IS ACTUALLY TESTABLE")
    testable = {g: p for g, p in by_group.items()
                if g != pg.DEFAULT_GROUP and len(p) > 1}
    if not testable:
        print("  Nothing. Group scope needs a DEFINED group with at least TWO projects that")
        print("  both hold stored solutions. Today no group qualifies, so turning the knob on")
        print("  would correctly change nothing - which is easy to mistake for a broken feature.")
        print()
        print("  To make it testable: define a group whose pattern matches two projects that")
        print("  already have stored fixes, then re-run --discover.")
        return 1
    for g, p in testable.items():
        print(f"  group {g}: {', '.join(p)}")
        print(f"      test with:  python test_group_scope_api.py --project {p[0]} \\")
        print(f"                      --task <a task of {p[0]}> --error-file <failure.txt>")
    return 0


def _run(project, task, message, artifact_text, changed_files):
    result = handlers._run_report_error_recommendation(
        project_name=project,
        errors=[{"severity": "ERROR", "message": message, "task_path": task, "file_path": ""}],
        task_path=task,
        query_artifact_text=("debug.log\n" + artifact_text) if artifact_text else "",
        query_changed_files=changed_files or [],
        user_requested_task=task.lstrip(":"),
        query_artifact_excerpts=([{"name": "debug.log", "text": artifact_text}]
                                 if artifact_text else []),
    )
    recs = (result or {}).get("recommendations") or []
    rows = [{
        "rank": r.get("rank"),
        "request_id": str(r.get("request_id") or "")[:8],
        "project": str(r.get("project_name") or ""),
        "final": r.get("final_score"),
        "artifact_sim": r.get("artifact_match_similarity"),
        "evidence_state": r.get("evidence_state"),
    } for r in recs[:8]]
    return str((result or {}).get("trace_id") or ""), rows


def _show(rows, home_project):
    if not rows:
        print("    (no candidates)")
        return
    for r in rows:
        foreign = "" if (r["project"] or "").lower() == home_project.lower() else "   <- OTHER PROJECT"
        print(f"    {r['rank']}. {r['request_id']}  {str(r['project'])[:22]:<22} "
              f"final={r['final']}  art={r['artifact_sim']}  {r['evidence_state'] or ''}{foreign}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--discover", action="store_true",
                    help="show which projects/groups can be tested, change nothing")
    ap.add_argument("--project", default="", help="project the failure happened in")
    ap.add_argument("--task", default="", help="task path, e.g. :TARGETS:master:task4")
    ap.add_argument("--error-file", default="", help="file holding the failure's error text")
    ap.add_argument("--artifact-file", default="", help="file holding the live debug.log content")
    ap.add_argument("--changed-file", action="append", default=[],
                    help="a file the developer changed (repeatable)")
    args = ap.parse_args()

    if args.discover or not args.project:
        return discover()

    if not args.task or not args.error_file:
        print("--task and --error-file are required (or use --discover)")
        return 2

    message = io.open(args.error_file, encoding="utf-8", errors="replace").read()
    artifact = (io.open(args.artifact_file, encoding="utf-8", errors="replace").read()
                if args.artifact_file else "")
    project = args.project.strip().lower()

    _rule(f"SCOPE OF {project}")
    members, mode = _scope_of(project)
    print(f"  resolves to: {mode}   members: {', '.join(members)}")
    if mode != "group":
        print()
        print("  This project does not widen - it is ungrouped, in a group of one, or its group")
        print("  is not defined. That is CORRECT behaviour, but it means the sharing test below")
        print("  cannot prove anything. Run --discover to find a project that qualifies.")

    original = str((rc.get_config() or {}).get("recommendationScope") or "project")
    failures = []
    inconclusive = False
    try:
        # ---- 1. project scope: the baseline, and the no-regression check ----
        _set_scope("project")
        _rule("SCOPE = PROJECT  (today's behaviour)")
        t1, rows1 = _run(project, args.task, message, artifact, args.changed_file)
        print(f"  trace {t1}")
        _show(rows1, project)
        foreign1 = [r for r in rows1 if (r["project"] or "").lower() != project]
        if foreign1:
            failures.append("project scope returned candidates from OTHER projects - "
                            "scoping is leaking")

        # ---- 2. group scope ----
        _set_scope("group")
        _rule("SCOPE = GROUP")
        t2, rows2 = _run(project, args.task, message, artifact, args.changed_file)
        print(f"  trace {t2}")
        _show(rows2, project)

        top1 = rows1[0]["request_id"] if rows1 else None
        top2 = rows2[0]["request_id"] if rows2 else None
        foreign2 = [r for r in rows2 if (r["project"] or "").lower() != project]

        _rule("VERDICT")
        if mode != "group":
            print("  Scope did not widen for this project (correct - see above).")
            print(f"  Ranking unchanged: {'YES' if top1 == top2 else 'NO'}")
            if top1 != top2:
                failures.append("ranking moved even though the scope did not widen")
        else:
            print(f"  1. NO REGRESSION       project-scope top = {top1}")
            print(f"  2. SHARING            cross-project candidates seen: {len(foreign2)}")
            if not foreign2:
                inconclusive = True
                print("     INCONCLUSIVE - the scope widened correctly, but no sibling produced a")
                print("     candidate, so nothing was actually shared and nothing was proven. The")
                print("     siblings most likely hold no comparable stored fix.")
                print("     To prove sharing you need a sibling project with a fix that genuinely")
                print("     answers this failure. Check what they hold:")
                for m in members:
                    if m != project:
                        print(f"         python audit_data.py --project {m}")
            print(f"  3. EVIDENCE DECIDES    group-scope top = {top2}")
            winner = next((r for r in rows2 if r["rank"] == 1), None)
            if winner and (winner["project"] or "").lower() != project:
                art = winner.get("artifact_sim")
                has_art = bool(art) and float(art or 0) > 0
                print(f"     A CROSS-PROJECT fix won, with artifact similarity {art}.")
                if artifact:
                    # The query carried a live artifact probe, so artifact evidence WAS available
                    # to score. A cross-project fix winning without it is the failure mode group
                    # scope must never have: a sibling promoted on context and helpers alone.
                    if not has_art:
                        failures.append(
                            "a cross-project candidate won with NO artifact evidence even though "
                            "the query carried an artifact probe - this is the failure mode group "
                            "scope must never have")
                    else:
                        print("     It won on artifact evidence, which is the intended behaviour.")
                else:
                    # No artifact probe in the query - so NO candidate can score artifact
                    # evidence, and demanding it here would be a check that cannot pass whatever
                    # the product does. (It did exactly that once and reported FAIL on a run
                    # that had just proven sharing works.) What remains is the error-text match,
                    # which is real evidence - just not the artifact half.
                    print("     No --artifact-file was given, so artifact evidence is 0 for EVERY")
                    print("     candidate. This fix won on error-text match: that proves retrieval")
                    print("     sharing, and says nothing either way about artifact-backed")
                    print("     ranking. Re-run with --artifact-file to test that half.")
            else:
                print("     The winner is still a same-project fix.")

        # ---- 3. the rule: an ungrouped project must never widen ----
        _rule("RULING CHECK: ungrouped projects never share")
        defs = pg.list_group_defs()
        overrides = pg.get_overrides()
        from src.utils.project_details import get_all_projects
        names = sorted({str((r or {}).get("project_name") or "").strip().lower()
                        for r in (get_all_projects() or []) if (r or {}).get("project_name")})
        ungrouped = [n for n in names
                     if pg.resolve_group(n, defs, overrides) == pg.DEFAULT_GROUP]
        if not ungrouped:
            print("  No ungrouped projects exist to check.")
        for n in ungrouped[:5]:
            m, md = _scope_of(n)
            ok = (md == "project" and m == [n])
            print(f"  {n:<28} scope={md} {'OK' if ok else 'LEAK'}")
            if not ok:
                failures.append(f"ungrouped project {n} widened to {m} - violates the ruling")
    finally:
        _set_scope(original)
        print()
        print(f"scope setting restored to '{original}'")

    _rule("RESULT")
    if failures:
        for f in failures:
            print(f"  FAIL: {f}")
        return 1
    if inconclusive:
        print("  Safety checks PASSED - no regression, and the ruling holds.")
        print("  The SHARING check was INCONCLUSIVE: the scope widened but no sibling")
        print("  contributed a candidate, so cross-project sharing is not yet proven.")
        print("  This is safe to leave enabled; it is not yet evidence that it helps.")
        return 0
    print("  All checks passed.")
    print("  Hand to the tester: turn scope on with")
    print("      python set_reco_config.py recommendationScope=group")
    print("  then run the same failure from VS Code and compare the trace.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
