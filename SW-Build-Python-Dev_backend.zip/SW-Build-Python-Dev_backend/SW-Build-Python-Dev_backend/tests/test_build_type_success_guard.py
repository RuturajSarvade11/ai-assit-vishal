"""Same build type, or the failure is not resolved.

Otherwise a build that fails in one build type and passes in another would be treated as that
error resolved, which is wrong.

The acceptance example: RMS fails under one requested task. The developer
changes something and runs a DIFFERENT task that also executes RMS. That build goes green, but
it says nothing about the original failure, so the original must stay open.

What makes it cheap: for Gradle the build type IS the requested task - a lifecycle task -
and it is already in the report's problemsReport.requestedTasks, which the recommendation path
already reads. Nothing new is read and nothing new is stored: the value rides on
the SESSION, which carries a TTL and is never part of the stored error or fix. That is an
explicit constraint - the value must not be stored anywhere.

The rule that needed the most care is the fail-open one. TD5 has no report.html at all, and any
extension older than this change sends no requestedTasks. A guard that quietly stopped recording
fixes wherever the signal is missing would be a much worse regression than the mismatch it
prevents, so it only ever fires when BOTH sides are known and they differ.
"""
import os
import re
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

_H = open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()
_PD = open(os.path.join(_ROOT, "src", "utils", "project_details.py"), encoding="utf-8-sig").read()

# The comparison form the guard uses, lifted from the shipping source rather than retyped.
_token_src = re.search(r"def _canonical_task_token\(task: str\) -> str:.*?\n(?=\n)", _H, re.S)
assert _token_src, "_canonical_task_token not found - the guard's comparison form moved"
_ns = {}
exec(_token_src.group(0), _ns)
canonical = _ns["_canonical_task_token"]


def guard(session_task, success_task):
    """The shipping condition, expressed once: block only when both are known and differ.

    The .strip() is not decoration - handlers.py strips both sides before testing them, so a
    whitespace-only value reads as UNKNOWN and falls through to the fail-open path. Writing this
    helper without the strip made it disagree with the shipping code on exactly that input,
    which is how the test first failed."""
    session_task = str(session_task or "").strip()
    success_task = str(success_task or "").strip()
    if success_task and session_task:
        return canonical(success_task) != canonical(session_task)
    return False


# --------------------------------------------------------------- the acceptance example

def test_a_pass_on_a_different_task_does_not_resolve_the_failure():
    """RMS failed on one task, passed under another that also runs RMS."""
    assert guard(":TARGETS:master:1_normal_without_arproc", ":TARGETS:master:2_full_with_arproc") is True


def test_a_pass_on_the_same_task_still_resolves_the_failure():
    """The whole existing flow must be untouched for the ordinary case."""
    assert guard(":TARGETS:master:task4", ":TARGETS:master:task4") is False


def test_the_comparison_ignores_path_prefix_and_case():
    """':TARGETS:master:task4' and 'task4' are the same lifecycle task named two ways - the
    same canonical form the same-task confirmation already uses."""
    assert guard(":TARGETS:master:task4", "TASK4") is False
    assert guard("task4", ":targets:master:task4") is False


# --------------------------------------------------------------- fail-open

def test_an_unknown_success_task_never_blocks():
    """An older extension sends no requestedTasks. Behaviour must be exactly as before."""
    assert guard(":TARGETS:master:task4", "") is False


def test_an_unknown_failure_task_never_blocks():
    """Sessions started before this change carry no requested_task."""
    assert guard("", ":TARGETS:master:task4") is False


def test_neither_side_known_never_blocks():
    """TD5: no report.html, so no requestedTasks on either side, ever."""
    assert guard("", "") is False


def test_whitespace_only_counts_as_unknown():
    assert guard("   ", ":TARGETS:master:task4") is False
    assert guard(":TARGETS:master:task4", "   ") is False


# --------------------------------------------------------------- how it is wired

def test_the_guard_reads_requested_tasks_and_not_the_failing_task():
    """taskPath/taskName are the FAILING task; requestedTasks is what the user RAN. Comparing
    the wrong one is exactly the defect that had to be corrected on the other code path."""
    block = _H[_H.index("def handle_copilot_build_success"):]
    block = block[:block.index("\ndef ", 10)]
    assert 'payload.get("requestedTasks")' in block
    assert 'session.get("requested_task")' in block
    assert 'payload.get("taskPath")' not in block, "the guard compares the failing task, not the run task"


def test_the_guard_sits_after_the_build_context_check():
    """It is an ADD-ON condition - the existing guards keep their behaviour
    and their order, and this one is simply another reason to decline."""
    block = _H[_H.index("def handle_copilot_build_success"):]
    assert block.index("build context does not match") < block.index("different build type")


def test_a_declined_pairing_says_why_and_saves_nothing():
    block = _H[_H.index("def handle_copilot_build_success"):]
    block = block[:block.index("\ndef ", 10)]
    assert '"build_type_mismatch": True' in block
    assert '"saved_outcomes": 0' in block
    assert "the original failure stays open" in block


def test_the_value_rides_on_the_session_and_is_never_stored_with_the_fix():
    """The do-not-store constraint. The session row carries a TTL; the error and solution
    records do not gain a build-type field."""
    assert 'requested_task: str = ""' in _PD, "session writer no longer accepts it"
    assert _PD.count('"requested_task": str(requested_task or "").strip(),') == 3, \
        "the three session rows must agree, or which row the success lookup reads decides the answer"
    for stored in ("def save_error_log", "def save_solution"):
        if stored in _PD:
            body = _PD[_PD.index(stored):]
            body = body[:body.index("\ndef ", 10)]
            assert "requested_task" not in body, f"{stored} started storing the build type"


def test_the_session_start_passes_it_through():
    block = _H[_H.index("def handle_copilot_session_start"):]
    block = block[:block.index("\ndef ", 10)]
    assert "requested_task=str(payload.get(\"requestedTasks\")" in block


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
