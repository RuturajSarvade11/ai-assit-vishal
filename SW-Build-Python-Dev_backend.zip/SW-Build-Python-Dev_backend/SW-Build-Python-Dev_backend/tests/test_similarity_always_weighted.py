"""Match points are always built from the actual similarity. The flag is gone.

similarityWeightedScoring shipped OFF, and that single default is the whole story behind the
reported always-12:

  - every semantic candidate kept the FULL base, so the Match column read a flat 12.00 whatever
    the similarity shown beside it said - 0.89, 0.76, 0.67 all scored 12.00
  - the similarity was computed, stored, displayed, and then not used
  - ranking therefore fell to circumstantial signals - same task, same file name, shared tokens -
    and a correct fix with the HIGHEST similarity of four candidates placed fourth
  - a trace tooltip tried to show the base by dividing the match by the similarity, which with a
    flat 12 produced 12 / 0.83 = 14.5 and 12 / 0.46 = 26, for a value that is only ever 18 or 12

There is no configuration in which a match score should ignore how well the candidate matched, so
the flag is retired rather than defaulted on: a stored False cannot bring the old behaviour back.
"""
import io
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _handlers():
    return io.open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()


def test_the_semantic_match_is_scaled_without_consulting_any_flag():
    src = _handlers()
    # The scaling line covers task recall as well now (a task-recall row used to keep the
    # full base for having been compared to nothing) - anchor on the current line.
    block = src[src.index("if match_type in (\"semantic\", \"task\") and isinstance(recommendation_similarity"):]
    block = block[:block.index("recommendation[\"context_score\"]")]
    assert "match_score * max(0.0, min(1.0, float(recommendation_similarity)))" in block
    assert "similarityWeightedScoring" not in block, "the scaling still depends on the flag"


def test_no_scoring_path_reads_the_flag_any_more():
    """Every gate it used to control - match scaling, the task-recall evidence rule, the
    error-plus-artifact blend - now runs unconditionally."""
    src = _handlers()
    for dead in ("_sim_w_on", "_match_scaling_on", "_sim_weighting_on"):
        assert dead not in src, f"{dead} still gates scoring"


def test_the_error_and_artifact_blend_is_not_gated():
    src = _handlers()
    # The blend runs for every semantic/task candidate with LIVE artifact evidence. The only
    # extra condition allowed is "not probed by the error text alone" (no live log was sent) -
    # never the retired similarityWeightedScoring flag.
    line = 'if _ev_w > 0 and _mt in ("semantic", "task") and not _via_error_text:'
    assert line in src, "the combined error+artifact similarity is gated again"
    blend_line = next(l for l in src.splitlines() if l.strip() == line)
    assert "similarityWeightedScoring" not in blend_line


def test_a_stored_false_cannot_turn_it_off():
    """The retired key is read as True whatever the store holds."""
    cfg = io.open(os.path.join(_ROOT, "src", "services", "recommendation_config.py"),
                  encoding="utf-8").read()
    assert 'data["similarityWeightedScoring"] = True' in cfg
    assert 'bool(data.get("similarityWeightedScoring"))' not in cfg
