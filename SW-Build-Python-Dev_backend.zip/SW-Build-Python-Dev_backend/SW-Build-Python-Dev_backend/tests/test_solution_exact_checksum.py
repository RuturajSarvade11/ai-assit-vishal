"""Approved storage rule (Storage and Duplicate Handling doc, Section 6 / Table 5):
SOLUTION identity is a PLAIN EXACT checksum — two solutions are the same only when they are
100% identical. Even a whitespace-only difference is a different solution (stored as its own
version). Cleaned/normalized checksums apply to ERROR and ARTIFACT identity only.

Run from the repo root:  python -m pytest tests/test_solution_exact_checksum.py -q
                   or :  python tests/test_solution_exact_checksum.py
"""
import ast
import hashlib
import json
import os
import sys

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_function_from_source(module_path, func_name, namespace):
    """Extract one function from a source file and exec it in an isolated namespace.
    Lets this test run on machines without the server dependencies (azure, openai, ...)
    while still testing the REAL production source, not a copy."""
    with open(module_path, "r", encoding="utf-8-sig") as fh:
        tree = ast.parse(fh.read())
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            code = compile(ast.Module(body=[node], type_ignores=[]), module_path, "exec")
            exec(code, namespace)
            return namespace[func_name]
    raise AssertionError(f"{func_name} not found in {module_path}")


sig = _load_function_from_source(
    os.path.join(_REPO, "src", "services", "handlers.py"),
    "_solution_signature_hash_from_payload",
    {"json": json, "hashlib": hashlib, "Dict": dict},
)


def _payload(changes, file_name="build.gradle"):
    return {"solution": [{"fileName": file_name, "filePath": "work/" + file_name,
                          "changes": list(changes), "changeObjects": []}]}


def test_identical_solutions_same_hash():
    a = _payload(["implementation 'org.slf4j:slf4j-api:2.0.9' [[line:42]]"])
    b = _payload(["implementation 'org.slf4j:slf4j-api:2.0.9' [[line:42]]"])
    assert sig(a) == sig(b) and sig(a)


def test_whitespace_difference_is_a_different_solution():
    a = _payload(["implementation 'org.slf4j:slf4j-api:2.0.9'"])
    b = _payload(["implementation  'org.slf4j:slf4j-api:2.0.9'"])  # one extra space
    assert sig(a) != sig(b)


def test_case_difference_is_a_different_solution():
    assert sig(_payload(["Implementation 'x'"])) != sig(_payload(["implementation 'x'"]))


def test_line_marker_shift_is_a_different_solution():
    a = _payload(["implementation 'x' [[line:42]]"])
    b = _payload(["implementation 'x' [[line:57]]"])
    assert sig(a) != sig(b)


def test_change_order_matters():
    a = _payload(["first change", "second change"])
    b = _payload(["second change", "first change"])
    assert sig(a) != sig(b)


def test_dict_key_order_is_serialization_not_content():
    a = {"solution": [{"fileName": "f", "filePath": "p", "changes": ["c"], "changeObjects": []}]}
    b = {"solution": [{"changeObjects": [], "changes": ["c"], "filePath": "p", "fileName": "f"}]}
    assert sig(a) == sig(b)


def test_hash_is_sha256_hex_not_legacy_sha1():
    assert len(sig(_payload(["c"]))) == 64  # legacy normalized rows carry 40-hex sha1


def test_empty_or_bad_payload_is_no_signature():
    assert sig({}) == "" and sig({"solution": []}) == "" and sig(None) == ""


if __name__ == "__main__":
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS  {name}")
            except AssertionError:
                failed += 1
                print(f"FAIL  {name}")
    sys.exit(1 if failed else 0)
