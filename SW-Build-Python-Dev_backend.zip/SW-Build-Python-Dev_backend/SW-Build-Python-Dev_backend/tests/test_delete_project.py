"""DELETE /delete-project removes ONE project outright.

A project has no row of its own - it is every request filed under that name - so deleting it
means the /delete-requests sweep for each of those requests, then the rows that belong to the
project itself and carry no request id. /deleteProjectFromGroup is a different thing: it only
moves a project to the Other group.

What these tests pin:

  - an empty name is rejected before anything is touched
  - every request of the project goes through the same per-request sweep as /delete-requests,
    and each one gets a tombstone
  - the project's own rows follow, each as its own stage: project-keyed data rows, vectors in
    the base and learned spaces, the group pin, adapter overrides, the project row
  - one stage failing never skips the others, and the answer names the stage that failed
  - a request sweep that only partly succeeded makes the whole answer a partial failure
  - a project with nothing left answers not_found and still succeeds, so the call is idempotent
  - the name is normalized the way the dashboard spells projects (strip + lower)
  - the dashboard read caches are dropped so the project disappears at once
  - the route exists for DELETE and POST, admin-only, and is documented
"""
import io
import os
import sys
import types

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

import src.services  # noqa: E402
import src.utils  # noqa: E402
from src.services import handlers  # noqa: E402


class _Collection:
    """Just enough of the Chroma / AzureCollection surface: get(where=...) and delete(ids=...)."""

    def __init__(self, ids_by_project=None):
        self.ids = {k: list(v) for k, v in (ids_by_project or {}).items()}
        self.deleted = []
        self.where_seen = []

    def get(self, where=None, include=None, **_):
        self.where_seen.append(where)
        return {"ids": list(self.ids.get((where or {}).get("project_name"), []))}

    def delete(self, ids=None, **_):
        self.deleted.extend(ids or [])
        for key in self.ids:
            self.ids[key] = [i for i in self.ids[key] if i not in set(ids or [])]


def _install_module(monkeypatch, package, dotted, module):
    """Make `from <package> import <name>` and `sys.modules[dotted]` both answer with `module`."""
    monkeypatch.setitem(sys.modules, dotted, module)
    monkeypatch.setattr(package, dotted.rsplit(".", 1)[1], module, raising=False)


@pytest.fixture
def world(monkeypatch):
    state = {
        "requests": {},                 # project -> [request ids]
        "sweep_status": "deleted",
        "project_rows": [],
        "project_row_count": 1,
        "pin_count": 1,
        "overrides": {"error": {}, "artifact": {}},
        "base": _Collection(),
        "learned": _Collection(),
        "fail_stage": None,
    }
    calls = {"listed_for": [], "swept": [], "tombstoned": [], "data_rows": [], "group_pins": [],
             "adapter_cleared": [], "project_rows": [], "cache": 0}

    def _list(project):
        calls["listed_for"].append(project)
        return [{"request_id": rid} for rid in state["requests"].get(project, [])]

    def _sweep(rid):
        calls["swept"].append(rid)
        return {"request_id": rid, "status": state["sweep_status"]}

    def _delete_rows(items):
        calls["data_rows"].extend(items)
        return len(items)

    def _delete_project_row(name):
        calls["project_rows"].append(name)
        return state["project_row_count"]

    monkeypatch.setattr(handlers, "list_final_build_payloads_by_project", _list)
    monkeypatch.setattr(handlers, "_delete_request_data", _sweep)
    monkeypatch.setattr(handlers, "_write_request_tombstone", lambda rid: calls["tombstoned"].append(rid))
    monkeypatch.setattr(handlers, "list_project_scoped_items", lambda project: list(state["project_rows"]))
    monkeypatch.setattr(handlers, "delete_ai_assisted_items", _delete_rows)
    monkeypatch.setattr(handlers, "delete_project_row", _delete_project_row)
    monkeypatch.setattr(handlers, "_invalidate_dashboard_read_cache",
                        lambda: calls.__setitem__("cache", calls["cache"] + 1))

    fake_rec = types.ModuleType("src.utils.recommended")
    fake_rec.collection = state["base"]
    fake_rec._get_learned_collection = lambda: state["learned"]
    _install_module(monkeypatch, src.utils, "src.utils.recommended", fake_rec)

    fake_pg = types.ModuleType("src.services.project_groups")

    def _remove_pin(name):
        if state["fail_stage"] == "group_override":
            raise RuntimeError("dynamo down")
        calls["group_pins"].append(name)
        return state["pin_count"]

    fake_pg.remove_project_override = _remove_pin
    _install_module(monkeypatch, src.services, "src.services.project_groups", fake_pg)

    fake_as = types.ModuleType("src.services.adapter_settings")
    fake_as.get_settings = lambda force=False, domain="error": {"project_overrides": dict(state["overrides"][domain])}

    def _clear(project, by, domain="error"):
        state["overrides"][domain].pop(project, None)
        calls["adapter_cleared"].append((project, by, domain))

    fake_as.clear_project = _clear
    _install_module(monkeypatch, src.services, "src.services.adapter_settings", fake_as)

    return state, calls


# ------------------------------------------------------------------ validation

def test_an_empty_name_is_rejected_before_anything_runs(world):
    state, calls = world
    state["requests"]["x"] = ["r1"]
    with pytest.raises(ValueError):
        handlers.handle_delete_project("   ")
    assert calls["swept"] == [] and calls["project_rows"] == [] and calls["cache"] == 0


# ------------------------------------------------------------------ the requests

def test_every_request_of_the_project_is_swept_and_tombstoned(world):
    state, calls = world
    state["requests"]["proj"] = ["r1", "r2", "r1"]  # a duplicate row must not sweep twice
    out = handlers.handle_delete_project("proj")
    assert calls["swept"] == ["r1", "r2"]
    assert calls["tombstoned"] == ["r1", "r2"]
    assert out["success"] is True
    assert out["status"] == "deleted"
    assert out["request_count"] == 2 and out["deleted_count"] == 2
    assert [r["request_id"] for r in out["requests"]] == ["r1", "r2"]


def test_a_request_sweep_that_only_partly_succeeded_fails_the_whole_answer(world):
    state, calls = world
    state["requests"]["proj"] = ["r1"]
    state["sweep_status"] = "partial_failure"
    out = handlers.handle_delete_project("proj")
    assert out["success"] is False
    assert out["status"] == "partial_failure"
    assert out["partial_failure_count"] == 1
    # the project's own rows are still removed - a half-deleted request is no reason to keep them
    assert calls["project_rows"] == ["proj"]


# ------------------------------------------------------------------ the project's own rows

def test_the_projects_own_rows_follow_the_requests_stage_by_stage(world):
    state, calls = world
    state["requests"]["proj"] = ["r1"]
    state["project_rows"] = [{"PK": "PREDICT_HISTORY#proj", "SK": "2026-10-01"},
                             {"PK": "MCPSESSION#proj#dev", "SK": "MCP_SESSION#STATE"}]
    state["base"] = _Collection({"proj": ["v1", "v2"], "other": ["v9"]})
    state["learned"] = _Collection({"proj": ["l1"]})
    sys.modules["src.utils.recommended"].collection = state["base"]
    sys.modules["src.utils.recommended"]._get_learned_collection = lambda: state["learned"]
    state["overrides"]["error"] = {"proj": False, "other": True}

    out = handlers.handle_delete_project("proj", actor="admin@test")

    assert out["stages"]["project_rows"] == {"ok": True, "count": 2}
    assert [r["PK"] for r in calls["data_rows"]] == ["PREDICT_HISTORY#proj", "MCPSESSION#proj#dev"]
    assert out["stages"]["vectors"] == {"ok": True, "count": 3}
    assert sorted(state["base"].deleted) == ["v1", "v2"] and state["base"].ids["other"] == ["v9"]
    assert state["learned"].deleted == ["l1"]
    assert out["stages"]["group_override"] == {"ok": True, "count": 1}
    assert calls["group_pins"] == ["proj"]
    assert out["stages"]["adapter_overrides"] == {"ok": True, "count": 1}
    assert calls["adapter_cleared"] == [("proj", "admin@test", "error")]  # artifact domain had no override
    assert state["overrides"]["error"] == {"other": True}
    assert out["stages"]["project_row"] == {"ok": True, "count": 1}
    assert out["failed_stages"] == []


def test_one_failing_stage_never_skips_the_others_and_is_named(world):
    state, calls = world
    state["requests"]["proj"] = ["r1"]
    state["fail_stage"] = "group_override"
    out = handlers.handle_delete_project("proj")
    assert out["success"] is False
    assert out["status"] == "partial_failure"
    assert out["failed_stages"] == ["group_override"]
    assert out["stages"]["group_override"]["ok"] is False
    assert "dynamo down" in out["stages"]["group_override"]["error"]
    # the stages after it still ran
    assert out["stages"]["adapter_overrides"]["ok"] is True
    assert calls["project_rows"] == ["proj"]
    assert out["stages"]["project_row"] == {"ok": True, "count": 1}
    # and the request sweep before it is intact
    assert out["deleted_count"] == 1


# ------------------------------------------------------------------ idempotence

def test_a_project_with_nothing_left_answers_not_found_and_still_succeeds(world):
    state, calls = world
    state["project_row_count"] = 0
    state["pin_count"] = 0
    out = handlers.handle_delete_project("gone")
    assert out["success"] is True
    assert out["status"] == "not_found"
    assert out["request_count"] == 0
    assert all(st == {"ok": True, "count": 0} for st in out["stages"].values())
    assert calls["swept"] == [] and calls["tombstoned"] == []


# ------------------------------------------------------------------ naming + caches

def test_the_name_is_normalized_the_way_the_dashboard_spells_projects(world):
    state, calls = world
    state["requests"]["dev_platform_01"] = ["r1"]
    out = handlers.handle_delete_project("  DEV_Platform_01 ")
    assert calls["listed_for"] == ["dev_platform_01"]
    assert calls["swept"] == ["r1"]
    assert out["project_name"] == "dev_platform_01"
    assert state["base"].where_seen == [{"project_name": "dev_platform_01"}]
    # stores that were written as typed get the stripped raw spelling and try both themselves
    assert calls["group_pins"] == ["DEV_Platform_01"]
    assert calls["project_rows"] == ["DEV_Platform_01"]


def test_the_dashboard_read_caches_are_dropped_once(world):
    state, calls = world
    handlers.handle_delete_project("proj")
    assert calls["cache"] == 1


# ------------------------------------------------------------------ the route and its docs

def _route_src():
    return io.open(os.path.join(_ROOT, "src", "routes", "route.py"), encoding="utf-8-sig").read()


def test_the_route_is_registered_for_delete_and_post_and_is_admin_only():
    src = _route_src()
    start = src.index('@app.route("/delete-project", methods=["POST", "DELETE"])')
    block = src[start:src.index("def delete_project(", start)]
    assert '@app.route("/delete-project/<path:project_name>", methods=["DELETE"])' in block
    assert '@require_role("owner", "admin")' in block
    body = src[start:src.index("@app.route", start + len(block) + 1)]
    assert "handlers.handle_delete_project(" in body


def test_the_endpoint_is_documented_next_to_the_other_project_admin_calls():
    from src.routes import docs_route
    spec = docs_route._DETAILED_PATHS["/delete-project"]["delete"]
    assert spec["tags"] == ["Project Groups (Admin)"]
    assert "DeleteWholeProjectRequest" in spec["requestBody"]["content"]["application/json"]["schema"]["$ref"]
    assert "DeleteWholeProjectRequest" in docs_route._COMPONENTS["schemas"]
    assert "DeleteWholeProjectResponse" in docs_route._COMPONENTS["schemas"]
