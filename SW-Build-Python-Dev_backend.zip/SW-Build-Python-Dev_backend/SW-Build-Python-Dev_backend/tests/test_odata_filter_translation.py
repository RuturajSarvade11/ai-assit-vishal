"""The Azure OData filter translator.

Two live defects are pinned here:
  1. An unknown operator was coerced to 'eq', so {"$in": ["a","b"]} emitted
     project_name eq '[''a'', ''b'']'  - well-formed OData that matches NOTHING and raises
     nothing. Already latent in cleanup_noise_artifacts.py, and it is the first shape any
     multi-project (group) scope reaches for, so it would have passed Chroma dev testing and
     silently returned zero rows on Azure.
  2. An empty $or returned None, and a None filter is not "match nothing" - the query layer
     then sweeps the WHOLE index, returning other projects' rows.
Every pre-existing filter shape must translate byte-identically; those cases are asserted too.
"""
import io
import os

_SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "src", "azure_search", "azure_collection.py")


def _translator():
    """Load the pure translator without importing the module (no store connection needed)."""
    src = io.open(_SRC, encoding="utf-8").read()
    ns = {}
    exec(src[src.index("def _odata_literal"):src.index("\nclass ")], ns)  # noqa: S102
    return ns["_odata"]


def test_existing_filter_shapes_are_unchanged():
    _odata = _translator()
    assert _odata({"project_name": "p"}) == "project_name eq 'p'"
    assert _odata({"project_name": {"$eq": "p"}}) == "project_name eq 'p'"
    assert _odata({"project_name": {"$ne": "p"}}) == "project_name ne 'p'"
    assert _odata({"$and": [{"a": "1"}, {"b": "2"}]}) == "(a eq '1') and (b eq '2')"
    assert _odata({"$or": [{"a": "1"}, {"b": "2"}]}) == "(a eq '1') or (b eq '2')"
    assert _odata({}) is None
    assert _odata(None) is None


def test_in_expands_instead_of_matching_nothing():
    _odata = _translator()
    got = _odata({"project_name": {"$in": ["a", "b"]}})
    assert got == "(project_name eq 'a' or project_name eq 'b')", got
    assert "[" not in got, "the list was stringified into the literal again"


def test_in_with_one_member_is_a_plain_equality():
    _odata = _translator()
    assert _odata({"project_name": {"$in": ["a"]}}) == "(project_name eq 'a')"


def test_empty_sets_never_match_instead_of_sweeping_the_index():
    """A filter that cannot be satisfied must never degrade into NO filter."""
    _odata = _translator()
    for where in ({"project_name": {"$in": []}}, {"$or": []}):
        got = _odata(where)
        assert got is not None, f"{where} dropped the filter - would sweep the whole index"
        assert "search.in(project_name, '')" in got, got


def test_nin_expands_to_and_of_inequalities():
    _odata = _translator()
    assert _odata({"project_name": {"$nin": ["a", "b"]}}) == "(project_name ne 'a' and project_name ne 'b')"


def test_group_scope_shape_nested_in_and():
    """The shape a task-scoped group query produces: scope AND task."""
    _odata = _translator()
    got = _odata({"$and": [{"project_name": {"$in": ["a", "b"]}}, {"task_path": "t"}]})
    assert got == "((project_name eq 'a' or project_name eq 'b')) and (task_path eq 't')", got


def test_unknown_operator_raises_rather_than_being_guessed():
    """Silent coercion is exactly how the $in bug shipped."""
    _odata = _translator()
    for op in ("$gt", "$lt", "$contains", "$regex"):
        try:
            _odata({"x": {op: 5}})
        except ValueError:
            continue
        raise AssertionError(f"{op} was silently accepted instead of raising")


def test_quotes_in_values_stay_escaped():
    _odata = _translator()
    assert _odata({"project_name": {"$in": ["o'brien"]}}) == "(project_name eq 'o''brien')"
