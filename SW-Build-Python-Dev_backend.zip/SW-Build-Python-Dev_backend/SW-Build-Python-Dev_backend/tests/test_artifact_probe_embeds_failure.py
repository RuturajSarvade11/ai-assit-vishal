"""The artifact probe embeds the WHOLE artifact.

The question was whether a small artifact matches on full context while a large one - stored
differently because of its size - still matches the same way. It did not.

create_embedding defaults to the FIRST 40 lines capped at 1500 chars: head truncation. Logs put
the failure LAST. Measured on a 122-line debug.log, only 19 lines survived and the root-cause token
never reached the vector at all - the leg was matching on the progress chatter every log shares.

It stayed invisible because the other legs were fine: the stored side is a summary that LEADS with
its error signals, and the token leg scans the whole probe. So a 10-line artifact matched perfectly
and a real one degraded silently, which is the worst shape a bug can have.

The fix is the one the ERROR path already uses. VECTOR_BLOCK_MODE raises its budget to
EMBEDDING_ERROR_MAX_CHARS / EMBEDDING_ERROR_MAX_LINES so a whole failure block is embedded; the
artifact probe now does the same. No selecting, no filtering, no reordering, and no marker list
deciding which lines count - the artifact goes in as the machine produced it. Two earlier attempts
here were rejected for exactly that reason, and rightly: one replaced the probe with its
marker-matched lines (which would delete a root cause phrased without a marker word), the other
reordered by structural rarity (a heuristic where none is needed).
"""
import os
import re
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# The real budgets, read from the shipping source rather than retyped.
_H = open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8").read()
ARTIFACT_CHARS = int(re.search(r'EMBEDDING_ARTIFACT_MAX_CHARS", "(\d+)"', _H).group(1))
ARTIFACT_LINES = int(re.search(r'EMBEDDING_ARTIFACT_MAX_LINES", "(\d+)"', _H).group(1))
# The probe text is now cut to the SAME budget, so there is no second, smaller cap in
# front of the embedder - a fix that only raised one of the two would just move the
# truncation rather than remove it. This test file caught exactly that.
# The probe keeps the TAIL of the log (the failure sits at the end): [-_ARTIFACT_EMBED_CHARS:].
# The head form is accepted too - what matters here is that the cap IS the embedding budget.
PROBE_CAP = int(re.search(r'strip\(\)\[(?::|-)_ARTIFACT_EMBED_CHARS:?\]', _H) is not None and ARTIFACT_CHARS or 0)


def test_the_probe_keeps_the_tail_where_the_failure_is():
    assert re.search(r'strip\(\)\[-_ARTIFACT_EMBED_CHARS:\]', _H), \
        "the artifact probe is cut from the head again - a long log loses its failure line"

_O = open(os.path.join(_ROOT, "src", "utils", "oai_client.py"), encoding="utf-8").read()
DEFAULT_CHARS = int(re.search(r'EMBEDDING_MAX_CHARS", "(\d+)"', _O).group(1))
DEFAULT_LINES = int(re.search(r'EMBEDDING_MAX_LINES", "(\d+)"', _O).group(1))


def prepare(text, cap_chars, cap_lines):
    """_prepare_text_for_embedding's real behaviour: first N lines, then a char cap."""
    out = []
    for line in str(text or "").replace("\r", "").split("\n"):
        s = line.strip()
        if not s or s.startswith("at ") or s.startswith("... "):
            continue
        out.append(s)
        if len(out) >= cap_lines:
            break
    joined = " | ".join(out) if out else str(text).replace("\n", " ")
    return re.sub(r"\s+", " ", joined).strip()[:cap_chars]


def embedded(text):
    """What the artifact probe now sends to the embedder."""
    return prepare(text, ARTIFACT_CHARS, ARTIFACT_LINES)


def old_embedded(text):
    """What it sent before - the defaults."""
    return prepare(text, DEFAULT_CHARS, DEFAULT_LINES)


def _long_log(root_cause):
    lines = [f"2026-08-31 10:33:{i:02d},100 [DEBUG] step {i} completed, reading config entry {i}"
             for i in range(120)]
    lines.append("2026-08-31 10:35:00,285 [ERROR] Error parsing input file")
    lines.append(f"2026-08-31 10:35:00,286 [DEBUG] {root_cause}")
    return chr(10).join(lines)


CTC = "'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p456'."


def test_the_old_behaviour_really_did_lose_the_root_cause():
    """Pins the bug itself, so this file still means something if the budgets ever move back."""
    assert CTC.split()[-1].strip(".'") not in old_embedded(_long_log(CTC))


def test_a_root_cause_at_the_end_of_a_long_log_now_reaches_the_vector():
    assert "6.2r1p456" in embedded(_long_log(CTC))


def test_the_whole_log_is_embedded_not_a_selection_of_it():
    """No filtering: the ordinary progress lines are still there alongside the failure. If this
    ever fails, something started choosing which lines count."""
    text = embedded(_long_log(CTC))
    assert "step 0 completed" in text
    assert "step 119 completed" in text
    assert "6.2r1p456" in text


def test_nothing_is_reordered():
    """The artifact reaches the embedder in the order the machine produced it."""
    text = embedded(_long_log(CTC))
    assert text.index("step 0 completed") < text.index("step 119 completed") < text.index("6.2r1p456")


def test_a_small_artifact_is_unaffected():
    """It fits under both the old and the new budget, so it is embedded identically - it was never
    the bug and nothing here should shift its vector."""
    small = ("2026-08-31 10:33:35,285 [ERROR] Error parsing input file" + chr(10)
             + "2026-08-31 10:33:35,286 [DEBUG] 'tools[name=python].version' "
               "must be '3.10.0' but got '3.11.0'.")
    assert embedded(small) == old_embedded(small)
    assert "3.11.0" in embedded(small)


def test_two_failures_sharing_a_preamble_become_distinguishable():
    """The point of the whole thing: identical chatter, different root cause."""
    ctc = embedded(_long_log(CTC))
    py = embedded(_long_log("'tools[name=python].version' must be '3.10.0' but got '3.11.0'."))
    assert ctc != py
    assert "ctc_aurix" in ctc and "ctc_aurix" not in py
    assert "python" in py and "python" not in ctc


def test_the_probe_cap_and_the_embedding_budget_are_the_same():
    """Two caps sit in front of the embedder - the probe slice and the embedding budget. Raising
    only one moves the truncation instead of removing it, which is what my first attempt did: at
    8000 the 10039-char test log still lost its root cause."""
    assert PROBE_CAP == ARTIFACT_CHARS, "the probe slice no longer follows the embedding budget"
    assert ARTIFACT_CHARS >= 28000, "budget fell below the error path's own block-mode budget"


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
