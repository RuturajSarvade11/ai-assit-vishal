from unittest.mock import patch

import src.routes.route as route_module
from src.services import handlers
from src.utils import project_details, recommendation_trace


def test_recommendation_trace_includes_token_usage_for_request(monkeypatch):
    monkeypatch.setattr(project_details, "get_token_usage_for_request", lambda request_id: {
        "prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0, "llm_calls": 0,
    })
    monkeypatch.setattr(
        recommendation_trace,
        "get_traces_for_request",
        lambda request_id: [
            {"project_name": "Project A"},
            {"project_name": "Project B"},
        ],
    )
    usage_by_project = {
        "Project A": {"prompt_tokens": 10, "output_tokens": 2, "total_tokens": 12, "llm_calls": 1},
        "Project B": {"prompt_tokens": 5, "output_tokens": 3, "total_tokens": 8, "llm_calls": 2},
    }
    monkeypatch.setattr(
        project_details,
        "get_token_usage_map_for_project",
        lambda project_name: {"req-1": usage_by_project[project_name]},
    )

    with route_module.app.test_request_context("/recommendation-trace/req-1"):
        response, status = route_module.recommendation_trace_for_request.__wrapped__("req-1")

    assert status == 200
    payload = response.get_json()
    assert payload["recommendation_token_usage"] == {
        "prompt_tokens": 15,
        "output_tokens": 5,
        "total_tokens": 20,
        "llm_calls": 3,
    }


def test_recommendation_trace_can_lookup_tokens_without_trace_rows(monkeypatch):
    monkeypatch.setattr(project_details, "get_token_usage_for_request", lambda request_id: {
        "prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0, "llm_calls": 0,
    })
    monkeypatch.setattr(recommendation_trace, "get_traces_for_request", lambda request_id: [])
    monkeypatch.setattr(
        project_details,
        "get_final_build_payload",
        lambda request_id: {"project_name": "Project A"},
    )
    monkeypatch.setattr(
        project_details,
        "get_token_usage_map_for_project",
        lambda project_name: {
            "req-2": {"prompt_tokens": 20, "output_tokens": 4, "total_tokens": 24, "llm_calls": 1}
        },
    )

    with route_module.app.test_request_context("/recommendation-trace/req-2"):
        response, status = route_module.recommendation_trace_for_request.__wrapped__("req-2")

    assert status == 200
    payload = response.get_json()
    assert payload["traces"] == []
    assert payload["recommendation_token_usage"] == {
        "prompt_tokens": 20,
        "output_tokens": 4,
        "total_tokens": 24,
        "llm_calls": 1,
    }


def test_indexed_usage_does_not_require_traces_or_duplicate_project_totals():
    usage = {"prompt_tokens": 100, "output_tokens": 20, "total_tokens": 120, "llm_calls": 1}
    with patch.object(recommendation_trace, "get_traces_for_request", return_value=[]), \
            patch.object(project_details, "get_token_usage_for_request", return_value=usage), \
            patch.object(project_details, "get_token_usage_map_for_project") as project_lookup, \
            route_module.app.test_request_context("/recommendation-trace/second"):
        response, status = route_module.recommendation_trace_for_request.__wrapped__("second")

    assert status == 200
    assert response.get_json()["recommendation_token_usage"] == usage
    project_lookup.assert_not_called()


def test_report_usage_is_linked_to_all_fallback_solutions_and_trace():
    result = {
        "status": "success",
        "recommendations": [],
        "weak_recommendations": [{"request_id": "first"}, {"request_id": "second"}],
        "trace_id": "flow-trace",
        "llm_token_usage": {"prompt_tokens": 100, "output_tokens": 20, "total_tokens": 120},
    }
    with patch.object(handlers, "_run_report_error_recommendation", return_value=result), \
            patch.object(project_details, "save_token_usage") as save_usage:
        handlers.handle_report_errors_by_message("demo", "error")

    save_usage.assert_called_once()
    assert save_usage.call_args.kwargs["related_request_ids"] == ["first", "second", "flow-trace"]
    assert save_usage.call_args.kwargs["total_tokens"] == 120