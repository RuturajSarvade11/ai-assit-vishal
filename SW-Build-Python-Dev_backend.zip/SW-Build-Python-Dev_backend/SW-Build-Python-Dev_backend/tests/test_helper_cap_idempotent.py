"""The helper cap settles ONCE: running it a second time must not change any count.

Two properties are pinned here, both regressions we actually shipped:
  1. NO DOUBLE-SUBTRACTION - the cap must not remove points the evidence gate already removed.
  2. IDEMPOTENCE - running the cap again must change nothing.
The cap logic is replicated exactly as handlers.py applies it, so the test fails the moment the
production arithmetic drifts from the rule.
"""


def _apply_helper_cap(rec):
    """Mirror of the helper-cap block in handlers.py _hydrate_recommendations.

    ONE FLOW (no separate trimming step): the rule
    is min(helpers, evidence) and nothing more. The helpers are read back as context - artifact,
    so every adjustment an earlier stage already made is inherently included and nothing can be
    subtracted twice.
    """
    comp = rec["context_components"]
    evidence = float(rec.get("match_score") or 0.0) + float(comp.get("artifact") or 0.0)
    if evidence <= 0:
        return rec
    artifact = float(comp.get("artifact") or 0.0)
    ctx = float(rec["context_score"])
    helpers = ctx - artifact
    counted = max(0.0, min(helpers, evidence))
    if abs(counted - helpers) > 1e-9:
        rec["context_score"] = artifact + counted
        rec["final_score"] = float(rec.get("match_score") or 0.0) + float(rec["context_score"])
        comp["helper_cap"] = -round(helpers - counted, 2)
    return rec


def _candidate_after_gate():
    """A candidate whose evidence gate already trimmed history (-3.60) and task points (-1.80)."""
    comp = {"base": 16.0, "success": 6.0, "patch": 4.0, "after_pattern": 0.0,
            "task_weight": 0.0, "artifact": 10.0,
            "evidence_gate": -3.60, "task_identity_scaled": -1.80}
    context = (comp["base"] + comp["success"] + comp["patch"] + comp["artifact"]
               - 3.60 - 1.80)
    return {"request_id": "cand", "match_score": 8.0, "context_score": context,
            "final_score": 8.0 + context, "context_components": comp}


def test_cap_does_not_resubtract_what_the_gate_already_removed():
    rec = _apply_helper_cap(_candidate_after_gate())
    comp = rec["context_components"]
    # Helpers still worth 26.00 - 5.40 = 20.60 against evidence 18.00 -> trim exactly 2.60.
    # The buggy version summed the RAW 26.00 and trimmed 8.00, removing 5.40 twice.
    assert round(abs(comp["helper_cap"]), 2) == 2.60, comp["helper_cap"]
    assert round(rec["context_score"], 2) == 28.00, rec["context_score"]


def test_second_pass_changes_nothing():
    rec = _apply_helper_cap(_candidate_after_gate())
    first = (round(rec["context_score"], 4), round(rec["final_score"], 4),
             round(rec["context_components"]["helper_cap"], 4))
    for _ in range(5):
        rec = _apply_helper_cap(rec)
    again = (round(rec["context_score"], 4), round(rec["final_score"], 4),
             round(rec["context_components"]["helper_cap"], 4))
    assert first == again, f"cap is not idempotent: {first} -> {again}"


def test_helpers_never_outweigh_evidence_after_the_cap():
    rec = _apply_helper_cap(_candidate_after_gate())
    comp = rec["context_components"]
    helpers = max(0.0, (comp["base"] + comp["success"] + comp["patch"] + comp["after_pattern"]
                        + comp["task_weight"])
                  + comp["evidence_gate"] + comp["task_identity_scaled"] + comp["helper_cap"])
    evidence = rec["match_score"] + comp["artifact"]
    assert helpers <= evidence + 1e-9, f"helpers {helpers} > evidence {evidence}"


def test_final_score_is_always_produced_and_never_negative():
    """The cap trims - it never withholds a score; a final score is always produced.
    Even an all-helpers candidate with minimal evidence keeps a real number."""
    comp = {"base": 16.0, "success": 4.0, "patch": 12.0, "after_pattern": 0.0,
            "task_weight": 0.0, "artifact": 0.0}
    rec = {"request_id": "helpers-only", "match_score": 0.5, "context_score": 32.0,
           "final_score": 32.5, "context_components": comp}
    rec = _apply_helper_cap(rec)
    assert rec["context_score"] >= 0.0
    assert rec["final_score"] == rec["match_score"] + rec["context_score"]
    assert isinstance(rec["final_score"], float)


def test_candidate_with_no_evidence_is_left_alone():
    """evidence == 0 means nothing to measure helpers against; the cap must not fire."""
    comp = {"base": 16.0, "success": 4.0, "patch": 0.0, "after_pattern": 0.0,
            "task_weight": 0.0, "artifact": 0.0}
    rec = {"request_id": "no-evidence", "match_score": 0.0, "context_score": 20.0,
           "final_score": 20.0, "context_components": comp}
    before = rec["context_score"]
    rec = _apply_helper_cap(rec)
    assert rec["context_score"] == before
    assert "helper_cap" not in comp


def test_one_flow_matches_the_previous_add_then_trim_arithmetic():
    """The refactor must not move a single score. This is the property that justified it:
    'add everything then subtract the excess' and 'count at most the evidence' are the same
    function. Checked over the whole plausible input space plus random samples."""
    import itertools
    import random

    def add_then_trim(match, artifact, helpers):
        evidence = match + artifact
        context = helpers + artifact
        if evidence > 0 and helpers > evidence:
            context -= (helpers - evidence)
        return match + context

    def one_flow(match, artifact, helpers):
        evidence = match + artifact
        if evidence <= 0:
            return match + helpers + artifact
        return evidence + max(0.0, min(helpers, evidence))

    random.seed(7)
    cases = list(itertools.product([0, 0.5, 8.44, 18], [0, 10, 21.15, 30], [0, 4, 20.6, 32]))
    cases += [(round(random.uniform(0, 18), 2), round(random.uniform(0, 30), 2),
               round(random.uniform(0, 32), 2)) for _ in range(500)]
    for match, artifact, helpers in cases:
        assert abs(add_then_trim(match, artifact, helpers)
                   - one_flow(match, artifact, helpers)) < 1e-9, (match, artifact, helpers)
