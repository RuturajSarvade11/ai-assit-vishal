"""The complete error reaches the vector, on both sides of the search.

Asked for directly (09-Oct): the whole error message, from the actual error to the end, stored
and embedded without truncation - and the command line, interpreter path and input-file paths
that open every build log must never be the reason the error itself is cut.

Two things were wrong, and these tests pin both:

  1. The query side embedded the reported error with the embedder's DEFAULTS - the first 40
     lines capped at 1500 characters - while the stored side (block mode) embedded up to 400
     lines and 28,000 characters. One error, two different vectors, and the distance between
     them measured the asymmetry. search_similar_errors, the learned-space search and the store
     now read ONE budget: error_embed_budget().
  2. When a text does not fit the budget, the embedder kept the START. Logs put the failure
     LAST, so the cut kept the preamble and dropped the error. Over budget it now keeps the
     END. A text under budget is untouched, nothing is reordered, and no marker decides
     which lines count.
"""
import os
import sys

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

from src.utils import oai_client as oai  # noqa: E402
from src.utils import recommended as rec  # noqa: E402


FAILURE = [
    "2026-10-09 10:35:00,285 [ERROR] Error parsing input file",
    "2026-10-09 10:35:00,286 [DEBUG] 'tools[name=oryx_2g].version' must be '2.1' but got '2.3'.",
]


def _log(n_steps, failure_lines=FAILURE):
    """A build log the way the machine writes it: the shared preamble first, the failure last."""
    lines = ["Starting the execution of the command line(s) for the GBE process task3",
             "cmd /c c:/LegacyApp/python/3.10.0/python.exe D:/AI_Build/Projects/TestGbe/in/read_xml_config.py"]
    lines += [f"2026-10-09 10:33:{i % 60:02d},100 [DEBUG] step {i} completed, reading config entry {i}"
              for i in range(n_steps)]
    return "\n".join(lines + list(failure_lines))


# ------------------------------------------------------------------ over budget: keep the end

def test_over_the_line_budget_the_failure_at_the_end_survives():
    out = oai._prepare_text_for_embedding(_log(100), max_chars=100000, max_lines=40)
    assert "oryx_2g" in out and "Error parsing input file" in out
    assert "Starting the execution" not in out and "step 0 completed" not in out
    assert out.count(" | ") == 39  # exactly the budget: the LAST forty lines


def test_over_the_character_budget_the_end_is_kept_and_starts_on_a_whole_line():
    out = oai._prepare_text_for_embedding(_log(100), max_chars=1500, max_lines=10000)
    assert out.endswith("but got '2.3'.")
    assert len(out) <= 1500
    assert out.startswith("2026-10-09 10:33:")  # a whole line, not the tail of one


def test_nothing_is_reordered():
    out = oai._prepare_text_for_embedding(_log(100), max_chars=100000, max_lines=40)
    assert (out.index("step 98 completed") < out.index("step 99 completed")
            < out.index("Error parsing") < out.index("oryx_2g"))


def test_a_text_under_budget_is_untouched():
    text = _log(5)
    out = oai._prepare_text_for_embedding(text, max_chars=28000, max_lines=400)
    assert out == " | ".join(ln.strip() for ln in text.splitlines())


def test_the_preamble_is_still_there_when_it_fits():
    """Keeping the end is not a selection: when the whole log fits, the whole log goes in."""
    out = oai._prepare_text_for_embedding(_log(100), max_chars=28000, max_lines=400)
    assert "Starting the execution" in out and "oryx_2g" in out


def test_stack_trace_lines_are_still_dropped():
    text = "Exception in thread main\nat com.x.Y(Y.java:1)\n... 3 more\nCaused by: boom"
    assert oai._prepare_text_for_embedding(text) == "Exception in thread main | Caused by: boom"


def test_a_single_very_long_line_is_not_thrown_away_for_tidiness():
    out = oai._prepare_text_for_embedding("x" * 5000, max_chars=1500)
    assert len(out) == 1500


# ------------------------------------------------------------------ one budget, both sides

BUDGET = oai.embedding_token_budget()


def test_the_budget_follows_block_mode(monkeypatch):
    """Block mode: the MODEL's token budget decides and nothing else cuts (0 = no char cap, no
    line cap). A 28,000-char cap was over the token limit on every real log; a 400-line cap
    dropped lines that fitted. Both stay env-tunable."""
    monkeypatch.setenv("VECTOR_BLOCK_MODE", "1")
    for k in ("EMBEDDING_ERROR_MAX_CHARS", "EMBEDDING_ERROR_MAX_LINES", "EMBEDDING_ERROR_MAX_TOKENS"):
        monkeypatch.delenv(k, raising=False)
    assert rec.error_embed_budget() == (0, 0, BUDGET)
    monkeypatch.setenv("EMBEDDING_ERROR_MAX_CHARS", "30000")
    monkeypatch.setenv("EMBEDDING_ERROR_MAX_LINES", "500")
    monkeypatch.setenv("EMBEDDING_ERROR_MAX_TOKENS", "4000")
    assert rec.error_embed_budget() == (30000, 500, 4000)
    monkeypatch.setenv("VECTOR_BLOCK_MODE", "0")
    assert rec.error_embed_budget() == (None, None, None)


@pytest.fixture
def embed_spy(monkeypatch):
    calls = []

    def _one(text, request_id=None, max_chars=None, max_lines=None, max_tokens=None):
        calls.append({"text": text, "max_chars": max_chars, "max_lines": max_lines, "max_tokens": max_tokens})
        return [0.1, 0.2, 0.3]

    def _many(texts, request_id=None, max_chars=None, max_lines=None, max_tokens=None):
        calls.append({"text": list(texts), "max_chars": max_chars, "max_lines": max_lines, "max_tokens": max_tokens})
        return [[0.1, 0.2, 0.3] for _ in texts]

    monkeypatch.setattr(rec, "create_embedding", _one)
    monkeypatch.setattr(rec, "create_embeddings_batch", _many)
    monkeypatch.setattr(rec, "_safe_query", lambda *a, **k: dict(rec._EMPTY_QUERY_RESULT))
    monkeypatch.setattr(rec, "_scope_filter", lambda *a, **k: {"project_name": "p"})
    monkeypatch.setenv("VECTOR_BLOCK_MODE", "1")
    for k in ("EMBEDDING_ERROR_MAX_CHARS", "EMBEDDING_ERROR_MAX_LINES", "EMBEDDING_ERROR_MAX_TOKENS",
              "ERROR_DOC_STORE_CHARS"):
        monkeypatch.delenv(k, raising=False)
    return calls


def _budget_of(call):
    return (call["max_chars"], call["max_lines"], call["max_tokens"])


def test_the_base_search_embeds_the_query_with_the_store_budget(embed_spy):
    rec.search_similar_errors("Error parsing input file", "p", top_k=3, allow_global_fallback=False)
    assert embed_spy and _budget_of(embed_spy[0]) == (0, 0, BUDGET)


def test_the_learned_space_search_embeds_the_query_with_the_store_budget(embed_spy, monkeypatch):
    monkeypatch.setattr(rec, "_get_learned_collection", lambda: object())
    monkeypatch.setattr(rec.feedback_adapter, "transform", lambda v: v)
    rec._search_learned_space("Error parsing input file", "p", top_k=3, allow_global_fallback=False)
    assert embed_spy and _budget_of(embed_spy[0]) == (0, 0, BUDGET)


def test_the_store_side_reads_the_same_budget_and_stores_the_document_whole(embed_spy, monkeypatch):
    class _Col:
        def __init__(self):
            self.upserts = []

        def upsert(self, **kw):
            self.upserts.append(kw)

    col = _Col()
    monkeypatch.setattr(rec, "collection", col)
    monkeypatch.setenv("EMBEDDING_BATCH_SLEEP_MS", "0")
    big = _log(600)  # far over the old 28,000-char document cap
    rec.save_errors_on_vector_db_batch([{
        "vector_id": "v1", "project_name": "p", "error_message": big,
        "all_solution": "{}", "batch_id": "r1", "request_id": "r1",
    }])
    assert embed_spy and _budget_of(embed_spy[0]) == (0, 0, BUDGET)
    assert col.upserts and col.upserts[0]["documents"] == [big]  # stored whole, no cap


def test_outside_block_mode_both_sides_use_the_embedder_defaults(embed_spy, monkeypatch):
    monkeypatch.setenv("VECTOR_BLOCK_MODE", "0")
    rec.search_similar_errors("Error parsing input file", "p", top_k=3, allow_global_fallback=False)
    assert embed_spy and _budget_of(embed_spy[0]) == (None, None, None)


# ------------------------------------------------------------------ the whole message, in tokens

def _stripped_lines(text):
    return [ln.strip() for ln in text.splitlines() if ln.strip()]


def test_a_long_error_is_chunked_by_tokens_and_nothing_is_lost():
    """Asked for directly (09-Oct): the error message embedding must be stored fully. A chunk is
    one vector; every line of the message lands in exactly one chunk, in order, and every chunk
    fits the model."""
    log = _log(1500)  # ~90k chars, several times the model limit
    chunks = oai.chunk_text_by_tokens(log)
    assert len(chunks) >= 3
    assert all(oai.embedding_token_count(c) <= BUDGET for c in chunks)
    rebuilt = [ln for c in chunks for ln in _stripped_lines(c)]
    assert rebuilt == [" ".join(ln.split()) for ln in _stripped_lines(log)]


def test_a_text_within_the_token_budget_is_one_chunk():
    assert oai.chunk_text_by_tokens(_log(5)) == [_log(5)]


def test_a_single_line_over_the_budget_is_split_not_dropped():
    line = "tools[name=oryx_2g].version must be '2.1' but got '2.3'. " * 2000
    chunks = oai.chunk_text_by_tokens(line)
    assert len(chunks) >= 2 and all(oai.embedding_token_count(c) <= BUDGET for c in chunks)
    assert "".join(chunks).replace("\n", "") == line.strip()


def test_a_chunk_is_embedded_whole_under_the_block_budget():
    """What the store chunked, the embedder keeps: no char cap, no line cap, every line of the
    chunk reaches the vector and the token budget is respected."""
    chunks = oai.chunk_text_by_tokens(_log(1500))
    for c in chunks:
        out = oai._prepare_text_for_embedding(c, max_chars=0, max_lines=0, max_tokens=BUDGET)
        assert out.count(" | ") == len(_stripped_lines(c)) - 1
        assert oai.embedding_token_count(out) <= BUDGET


def test_the_embedder_never_sends_more_than_the_model_accepts():
    """A caller that did not chunk (legacy defaults, artifacts) is still protected: over the
    limit the LAST whole lines that fit are kept, so the failure at the end survives."""
    out = oai._prepare_text_for_embedding(_log(1500), max_chars=0, max_lines=0)
    assert oai.embedding_token_count(out) <= BUDGET
    assert out.endswith("but got '2.3'.")


def test_block_mode_vectorisation_keeps_every_line_of_a_huge_error(monkeypatch):
    from src.services import handlers
    monkeypatch.setenv("VECTOR_BLOCK_MODE", "1")
    monkeypatch.setenv("ERROR_TEXT_RAW_MODE", "1")   # the shipped default: verbatim, no focus slice
    monkeypatch.delenv("EMBEDDING_ERROR_MAX_TOKENS", raising=False)
    monkeypatch.setenv("VECTOR_MAX_MESSAGES", "50")
    log = _log(1500)
    blocks = handlers._prepare_messages_for_vectorization([log])
    assert len(blocks) >= 3
    assert all(oai.embedding_token_count(b) <= BUDGET for b in blocks)
    rebuilt = [ln for b in blocks for ln in _stripped_lines(b)]
    assert rebuilt == [" ".join(ln.split()) for ln in _stripped_lines(log)]
