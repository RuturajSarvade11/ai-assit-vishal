"""The artifact is what separates two failures whose error text is the same - so the artifact path
must actually see the line that names the failure.

Traced for a live case (10-Oct): an AURIX failure answered with the CTC-compiler fix. Both
report texts are "Error parsing input file" plus progress chatter; the cause lives in debug.log,
on the line AFTER the error marker:

    [ERROR] Error parsing input file
    [DEBUG] <Target><Compiler> must contain 'CTC' but found 'Diab'      (ctc fix's log)
    [DEBUG] 'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p5'   (aurix fix's log)

The second detail line carries marker words ("must be", "but got"); the first carries none and
was invisible to _failure_signal_lines - and with it to the evidence tokens, the ingest
ownership gate, the wording tier and the stored summary's verbatim appendix. A CTC-compiler log
therefore named nothing but the generic error line every GBE failure shares.
"""
import os
import re
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.services import handlers  # noqa: E402
from src.services import recommendation_config as rc  # noqa: E402

PREAMBLE = ["[DEBUG] read_json_config.py starting.",
            "[DEBUG] Reading JSON file from disk.",
            "[DEBUG] Starting validation for config root keys: ['project', 'build', 'tools', 'targets']"]
CTC_DETAIL = "[DEBUG] <Target><Compiler> must contain 'CTC' but found 'Diab'"
AURIX_DETAIL = "[DEBUG] 'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p5'."


def _log(detail):
    return "\n".join(PREAMBLE + ["[ERROR] Error parsing input file", detail])


def _evidence_tokens(text):
    sig = "\n".join(handlers._failure_signal_lines(text))
    return handlers._distinctive_token_set(sig or text)


def test_the_line_after_the_error_marker_is_part_of_the_failure(monkeypatch):
    monkeypatch.delenv("FAILURE_DETAIL_LINES", raising=False)
    assert handlers._failure_signal_lines(_log(CTC_DETAIL)) == ["[ERROR] Error parsing input file", CTC_DETAIL]
    assert handlers._failure_signal_lines(_log(AURIX_DETAIL)) == ["[ERROR] Error parsing input file", AURIX_DETAIL]


def test_the_detail_window_is_bounded_and_restarts_on_a_marker(monkeypatch):
    monkeypatch.setenv("FAILURE_DETAIL_LINES", "1")
    text = "\n".join(["[ERROR] first", "detail one", "unrelated", "[ERROR] second", "detail two", "unrelated"])
    assert handlers._failure_signal_lines(text) == ["[ERROR] first", "detail one", "[ERROR] second", "detail two"]
    monkeypatch.setenv("FAILURE_DETAIL_LINES", "0")
    assert handlers._failure_signal_lines(text) == ["[ERROR] first", "[ERROR] second"]


def test_a_ctc_compiler_log_now_names_its_failure():
    """Before: the ctc log's evidence tokens were {error, parsing, input, file} - shared with
    every GBE failure - so against an AURIX live log it scored as 'generic', never 'different'."""
    ctc = _evidence_tokens(_log(CTC_DETAIL))
    assert {"compiler", "ctc", "diab"} <= ctc


def test_the_token_leg_separates_aurix_from_ctc_on_the_detail_lines():
    """The rarity-weighted lexical leg exactly as _artifact_match_scores computes it, over the two
    stored logs as the neighbour set: the live AURIX log must score its own log far above the
    ctc log, and the spread must clear the contrast threshold so the contrast decides."""
    live = _evidence_tokens(_log(AURIX_DETAIL))
    docs = {"aurix": _evidence_tokens(_log(AURIX_DETAIL)), "ctc": _evidence_tokens(_log(CTC_DETAIL))}
    df = {}
    for d in docs.values():
        for t in d & live:
            df[t] = df.get(t, 0) + 1
    total = sum(1.0 / df[t] for t in live if t in df)
    token = {k: sum(1.0 / df[t] for t in (d & live) if t in df) / total for k, d in docs.items()}
    assert token["aurix"] == pytest.approx(1.0)
    assert token["ctc"] < 0.5  # only the generic words ('error', 'parsing', 'must', 'but'...) are shared
    assert token["aurix"] - token["ctc"] >= rc.SCORING_DEFAULTS["evidenceContrastMinSpread"]


def test_xml_element_names_are_words_of_the_failure():
    """`<Compiler>CTC</Compiler>` used to reduce to {'ctc'}: the closing tag read as a path and
    the opening tag as a cleaner placeholder. The element name is the word that links a fix to
    the log line that names the same element."""
    assert {"compiler", "ctc"} <= handlers._distinctive_token_set("<Compiler>CTC</Compiler>")
    assert {"target", "compiler", "ctc", "diab"} <= handlers._distinctive_token_set(CTC_DETAIL)
    assert "path" not in handlers._distinctive_token_set("<Platform>AURIX</Platform>")


def test_the_ingest_gate_can_now_tell_whose_log_a_ctc_log_is():
    """The ownership gate compares a log's failure tokens with each fix's change lines and needs
    two shared tokens for proof. With the detail line invisible the ctc log had no specific
    token at all; now 'compiler' and 'ctc' are there to match '<Compiler>CTC</Compiler>'."""
    art = handlers._distinctive_token_set("\n".join(handlers._failure_signal_lines(_log(CTC_DETAIL))))
    art -= handlers._ARTIFACT_OWNERSHIP_COMMON_TOKENS
    ctc_fix = handlers._distinctive_token_set("<Compiler>CTC</Compiler>") - handlers._ARTIFACT_OWNERSHIP_COMMON_TOKENS
    aurix_fix = handlers._distinctive_token_set('<Tool name="ctc_aurix" version="6.2r1p4"/>') - handlers._ARTIFACT_OWNERSHIP_COMMON_TOKENS
    assert len(art & ctc_fix) >= 2
    assert len(art & aurix_fix) < 2


def test_the_contrast_threshold_is_a_setting(monkeypatch):
    assert "evidenceContrastMinSpread" in rc.SCORING_DEFAULTS
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {"evidenceContrastMinSpread": 0.05})
    assert handlers._rc_value("evidenceContrastMinSpread", hi=1.0) == 0.05
    src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "src", "services", "handlers.py"), encoding="utf-8").read()
    assert "_spread >= 0.15" not in src
    assert '_rc_value("evidenceContrastMinSpread"' in src


def test_the_stored_artifact_is_embedded_with_the_probe_budget():
    src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "src", "services", "handlers.py"), encoding="utf-8").read()
    assert "embeddings.append(create_embedding(chunk_text))" not in src
    assert re.search(r"create_embedding\(chunk_text,\s*max_chars=_ARTIFACT_EMBED_CHARS", src)
