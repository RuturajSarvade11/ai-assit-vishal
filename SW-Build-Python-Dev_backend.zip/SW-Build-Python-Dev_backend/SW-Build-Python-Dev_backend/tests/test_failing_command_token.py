"""The word that names the failing command must survive into the comparison.

THE REPORTED CASE (01-Oct, production demo). A build failed with:

    'ech' is not recognized as an internal or external command,
    operable program or batch file.

a typo for `echo` in one line of a Python script. The recommendation came back with three
unrelated candidates - a compiler version mismatch and two Python version mismatches - all at an
identical similarity of 0.67, all presented as strong.

Why: `_extract_config_tokens` asked for four characters or more, so `ech` was discarded for being
three letters. What survived was "recognized", "internal", "external", "command" - words that
appear in EVERY Windows not-recognized error, whatever the command was. The one token that
identified this failure never entered the comparison, and the tokens that did could not tell two
such failures apart.

The same threshold discarded `cp`, `ls`, `gcc`, `rm` and `cd`.

Two rules now: three characters or more generally, and a quoted word of any length - which is how
a toolchain names the thing that failed. Quoted words are taken first so a sixteen-token budget
spent on the surrounding boilerplate cannot crowd them out.

Common words still get through. They cost nothing: the artifact comparison weights a token by how
rare it is, so a word present in every stored record is worth close to zero.
"""
import os
import re
import sys

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# The extraction is pure text handling, so it is read out of the module rather than importing
# handlers.py, which would need AWS.
_SRC = open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()


def _rules():
    quoted = re.search(r'_QUOTED_TOKEN_RE = re\.compile\(r"(.+?)"\)', _SRC)
    general = re.search(r'pattern = re\.compile\(r"(\[A-Z_\]\{3,\}[^"]+)"\)', _SRC)
    assert quoted, "the quoted-token rule is gone - a failing command name will be dropped again"
    assert general, "the general token pattern changed shape; update this test"
    return re.compile(quoted.group(1)), re.compile(general.group(1))


def _tokens(text, limit=16):
    quoted, general = _rules()
    out, seen = [], set()
    for raw in quoted.findall(text) + general.findall(text):
        t = re.sub(r"[^a-z0-9_]+", "", str(raw).strip().lower())
        if t and t not in seen:
            seen.add(t)
            out.append(t)
            if len(out) >= limit:
                break
    return out


REPORTED_ERROR = (
    "'ech' is not recognized as an internal or external command,\n"
    "operable program or batch file.\n"
    "Traceback (most recent call last):\n"
    '  File "run_file_handler_use_case_windows.py", line 41, in create_files\n'
    "    run_cmd(f'ech {content}> \"{file_path}\"')\n"
    "subprocess.CalledProcessError: Command 'ech Dummy content for file 1.' "
    "returned non-zero exit status 1."
)


def test_the_failing_command_is_captured():
    """`ech` is the only word in that error that says which command failed."""
    assert "ech" in _tokens(REPORTED_ERROR), (
        "the failing command name was dropped - the recommendation cannot tell this error "
        "apart from any other not-recognized error"
    )


def test_it_is_captured_early_enough_to_survive_the_budget():
    """Only sixteen tokens are kept, and the boilerplate comes first in a build log."""
    assert _tokens(REPORTED_ERROR).index("ech") < 4


def test_short_command_names_are_not_dropped_for_being_short():
    for cmd in ("cp", "ls", "gcc", "rm", "cd", "ech"):
        assert cmd in _tokens(f"'{cmd}' is not recognized as an internal or external command"), cmd


def test_two_not_recognized_errors_differ_by_the_command_name():
    """The failure this prevents: unrelated errors scoring identically.

    Everything in these two lines is shared except the command. If the command is dropped, the
    two are indistinguishable - which is how a compiler-version fix came top for a typo in echo.
    """
    a = set(_tokens("'ech' is not recognized as an internal or external command"))
    b = set(_tokens("'gcc' is not recognized as an internal or external command"))
    assert a != b, "two different failing commands produced identical tokens"
    assert a - b == {"ech"} and b - a == {"gcc"}


def test_the_generic_words_are_still_there():
    """They are not harmful - rarity weighting makes a word in every record worth almost nothing."""
    got = _tokens(REPORTED_ERROR)
    assert "recognized" in got and "command" in got
