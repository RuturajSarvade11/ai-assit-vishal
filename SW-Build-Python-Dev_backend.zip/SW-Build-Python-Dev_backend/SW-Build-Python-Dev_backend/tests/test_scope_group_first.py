"""Group is the scope.

A project in a DEFINED group is searched together with its siblings in ONE pass, every source
widened; "Other" and single-member groups stay at project scope until an admin assigns them; a
sibling's fix is scored like the project's own and the project's own fix wins only a TIE in the
display order. This replaced the earlier two-pass fallback (project first, siblings only when the
project showed nothing).

These tests pin: the scope resolution, that the exact-signature lookup widens with the scope and
stays byte-identical under project scope, that the wrapper runs exactly one pass, and the
tie-break.
"""
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

os.environ.setdefault("OPENAI_API_VERSION", "2024-02-01")
os.environ.setdefault("OAI_API_VERSION", "2024-02-01")
os.environ.setdefault("AWS_DEFAULT_REGION", "eu-central-1")

from src.services import handlers  # noqa: E402
from src.services import project_groups as pg  # noqa: E402
from src.services import recommendation_config as rc  # noqa: E402
from src.utils import recommended  # noqa: E402

MEMBERS = ["testgbe", "sibling1", "sibling2"]


def _grouped(monkeypatch):
    """testgbe IS in a real multi-member group."""
    pg._scope_cache.clear()
    monkeypatch.setattr(pg, "list_group_defs", lambda: [{"group_name": "HIP26"}])
    monkeypatch.setattr(pg, "get_overrides", lambda: {})
    monkeypatch.setattr(pg, "resolve_group", lambda n, d=None, o=None: "HIP26")


def _knob(monkeypatch, value):
    monkeypatch.setattr(rc, "get_config", lambda force=False: {"recommendationScope": value})


def test_a_grouped_project_searches_its_whole_group(monkeypatch):
    _grouped(monkeypatch)
    members, mode = pg.resolve_scope_projects("testgbe", all_project_names=MEMBERS)
    assert mode == "customer"
    assert set(members) == set(MEMBERS)


def test_other_stays_project_until_assigned(monkeypatch):
    pg._scope_cache.clear()
    monkeypatch.setattr(pg, "list_group_defs", lambda: [{"group_name": "HIP26"}])
    monkeypatch.setattr(pg, "get_overrides", lambda: {})
    monkeypatch.setattr(pg, "resolve_group", lambda n, d=None, o=None: pg.DEFAULT_GROUP)
    assert pg.resolve_scope_projects("lonely", all_project_names=MEMBERS) == (["lonely"], "project")


def test_a_group_of_one_is_project_scope(monkeypatch):
    _grouped(monkeypatch)
    assert pg.resolve_scope_projects("testgbe", all_project_names=["testgbe"]) == (["testgbe"], "project")


class _FakeCollection:
    def __init__(self, rows):
        self.rows = rows
        self.where_seen = []

    def get(self, where=None, include=None, **_):
        self.where_seen.append(where)
        return {"ids": [r["id"] for r in self.rows],
                "metadatas": [r["meta"] for r in self.rows],
                "documents": [r.get("doc", "") for r in self.rows]}


_ROWS = [{"id": "v1", "meta": {"project_name": "testgbe", "error_signature_hash": "h1"}},
         {"id": "v2", "meta": {"project_name": "sibling1", "error_signature_hash": "h1"}},
         {"id": "v3", "meta": {"project_name": "stranger", "error_signature_hash": "h1"}}]


def test_exact_signature_lookup_widens_with_the_scope(monkeypatch):
    _knob(monkeypatch, "group")
    monkeypatch.setattr(pg, "resolve_scope_projects",
                        lambda p, all_project_names=None, requested_scope=None: (list(MEMBERS), "customer"))
    fake = _FakeCollection(_ROWS)
    monkeypatch.setattr(recommended, "collection", fake)
    res = recommended.search_errors_by_signatures("testgbe", ["h1"], top_k=10)
    assert res["ids"][0] == ["v1", "v2"], "the sibling's stored error is in, the stranger's is not"
    assert fake.where_seen[0] == {"$and": [{"project_name": {"$in": ["sibling1", "sibling2", "testgbe"]}},
                                            {"error_signature_hash": "h1"}]}


def test_exact_signature_lookup_is_byte_identical_under_project_scope(monkeypatch):
    _knob(monkeypatch, "project")
    fake = _FakeCollection(_ROWS)
    monkeypatch.setattr(recommended, "collection", fake)
    res = recommended.search_errors_by_signatures("testgbe", ["h1"], top_k=10)
    assert res["ids"][0] == ["v1"]
    assert fake.where_seen[0] == {"$and": [{"project_name": "testgbe"}, {"error_signature_hash": "h1"}]}


def test_group_scope_runs_exactly_one_pass(monkeypatch):
    calls = []
    monkeypatch.setattr(handlers, "_reco_scope_members", lambda p: (list(MEMBERS), "customer"))
    monkeypatch.setattr(handlers, "_run_report_error_recommendation_scoped",
                        lambda *a, **k: calls.append(k) or {"recommendations": []})
    out = handlers._run_report_error_recommendation(project_name="testgbe", errors=[])
    assert len(calls) == 1, "the two-pass fallback is gone: one widened pass"
    assert out == {"recommendations": []}


def _rec(rid, project, final):
    return {"request_id": rid, "project_name": project, "final_score": final, "document": "error x",
            "task_name": ":TARGETS:master:task4", "solution": [], "thumbs_up": 0, "thumbs_down": 0,
            "match_type": "semantic"}


def test_own_project_wins_only_a_tie(monkeypatch):
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {"downvoteSinkMinVotes": 1})
    tie = [_rec("sib", "sibling1", 20.0), _rec("own", "testgbe", 20.0)]
    out = handlers._rerank_recommendations_for_relevance(
        tie, query_text="error x", query_task_path=":TARGETS:master:task4", query_project="testgbe")
    assert [r["request_id"] for r in out] == ["own", "sib"]
    assert out[0]["rank_factors"]["same_project"] is True
    assert out[1]["rank_factors"]["same_project"] is False

    higher = [_rec("own", "testgbe", 19.9), _rec("sib", "sibling1", 20.0)]
    out = handlers._rerank_recommendations_for_relevance(
        higher, query_text="error x", query_task_path=":TARGETS:master:task4", query_project="testgbe")
    assert [r["request_id"] for r in out] == ["sib", "own"], "a sibling that scored higher stays ahead"
