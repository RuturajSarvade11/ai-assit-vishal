"""Every function the documents name must still exist.

WHY THIS IS A TEST. Schaeffler's point on 29-Sep was that a handwritten document drifts from the
code the moment somebody renames something, and that the review step which would catch it is the
step that always gets skipped. Their own house style is a generator that reads the code on every
push, so nothing can be missed.

This is that check, in the cheapest form that fits what we already run: the documents no longer
contain pasted code, they contain ADDRESSES (a file and a symbol) which are resolved when the
document is built. This test resolves the same addresses in CI. Rename `_match_type_score` and
this test fails, naming it, in the same run as everything else - instead of a client reading a
function that has not existed for two months.

Adding a function to a document means adding it here. That is the whole maintenance cost, and it
is paid by whoever writes the document rather than by whoever later has to discover the drift.

The extension's TypeScript symbols are checked by the document build (docgen), not here - this
suite is Python-only and must not depend on the extension repo being checked out beside it.
"""
import ast
import io
import os

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# (module path relative to the backend repo, symbol) for every function named in
# "AI Assisted SW - Recommendation Flow" - its figures, its tables and its code extracts.
DOCUMENTED = [
    # Figure 1 / Table 1 - the call path
    ("src/services/handlers.py", "handle_report_errors"),
    ("src/services/handlers.py", "_run_report_error_recommendation"),
    ("src/services/handlers.py", "_run_report_error_recommendation_scoped"),
    # Figure 2 / Table 3 - retrieval
    ("src/services/handlers.py", "_build_recommendation_query_candidates"),
    ("src/services/handlers.py", "_search_recommendation_matches"),
    ("src/services/handlers.py", "_task_ledger_candidates"),
    ("src/services/handlers.py", "_signature_hash_from_text"),
    ("src/utils/recommended.py", "search_errors_by_signatures"),
    ("src/utils/recommended.py", "search_similar_errors_fused"),
    ("src/utils/recommended.py", "search_similar_errors"),
    ("src/utils/recommended.py", "_pool_from"),
    ("src/services/project_groups.py", "resolve_scope_projects"),
    ("src/services/project_groups.py", "scope_where"),
    # Figure 3 / Table 5 - scoring
    ("src/services/handlers.py", "_hydrate_recommendations"),
    ("src/services/handlers.py", "_match_type_score"),
    ("src/services/handlers.py", "_fix_context_score"),
    ("src/services/handlers.py", "_artifact_match_scores"),
    ("src/services/handlers.py", "_recommended_hit_count"),
    # Figure 4 / Table 6 - ordering, the gate, the trace
    ("src/services/handlers.py", "_recommendation_order_key"),
    ("src/services/handlers.py", "_rerank_recommendations_for_relevance"),
    ("src/services/handlers.py", "_dedupe_recommendations_by_fix"),
    ("src/services/handlers.py", "_evaluate_recommendation_strength"),
]


def _defines(path, name):
    """True when `path` defines `name` anywhere, including inside another function.

    ast rather than a text search, so a CALL to the function can never be mistaken for its
    definition - the whole point is to detect that the definition is gone. Nested defs count:
    _recommendation_order_key is declared inside the function that sorts with it and is still a
    symbol the document legitimately points at.
    """
    source = io.open(os.path.join(_ROOT, path), encoding="utf-8-sig").read()
    tree = ast.parse(source)
    return any(
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        and node.name == name
        for node in ast.walk(tree)
    )


@pytest.mark.parametrize("path,name", DOCUMENTED, ids=[f"{n}" for _p, n in DOCUMENTED])
def test_documented_symbol_still_exists(path, name):
    assert os.path.exists(os.path.join(_ROOT, path)), (
        f"{path} is gone, and the Recommendation Flow document still points at it."
    )
    assert _defines(path, name), (
        f"{path} no longer defines {name!r}, but the Recommendation Flow document names it "
        f"(a figure, a table or a code extract). Rename it there too, or update this list."
    )


def test_the_documented_list_has_no_duplicates():
    """A duplicate means two documents drifted apart about where a function lives."""
    assert len(DOCUMENTED) == len(set(DOCUMENTED)), "duplicate entries in DOCUMENTED"
