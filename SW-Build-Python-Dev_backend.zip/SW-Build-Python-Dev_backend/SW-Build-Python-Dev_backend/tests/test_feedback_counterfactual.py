"""Did developer feedback actually change the recommendation order?

The trace must PROVE how feedback influences the solution rather than print a state
word. The honest way to answer is a counterfactual on the real ordering key: re-sort the same
candidate pool with the vote-derived term neutralised and compare positions.

The ordering key built in _rerank_recommendations_for_relevance is:

    (no_solution, -final, -similarity, -(up - down), -same_project, -task_hit, -user_task_hit,
     -file_hit, -relevance, idx)

Exactly ONE of those ten comes from votes: `-(up - down)` at position 3, a tie-break behind the
final score and the similarity. Feedback is a tie-break, never a weight (asked for directly,
08-Oct): a downvote cannot bury a better-scoring fix and an upvote cannot lift a worse one. The
counterfactual neutralises that one term and NOTHING else.

These tests pin the property that makes the displayed number trustworthy: it must be 0 whenever
no vote exists, it must be 0 whenever the scores were not tied, and it must report a tie-break
correctly. A counterfactual that drifted from the real key would put a confident, wrong number
in front of the reader - worse than the "untrained" it replaces.
"""
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)


def _key(rec, idx):
    """The real ordering key, mirrored from handlers._rerank_recommendations_for_relevance."""
    up, down = rec.get("up", 0), rec.get("down", 0)
    no_solution = 0 if rec.get("solution", True) else 1
    return (no_solution, -round(rec.get("final", 0.0), 3), -round(rec.get("sim", 0.0), 6),
            -(up - down), -rec.get("same_project", 0), -rec.get("task", 0),
            -rec.get("user_task", 0), -rec.get("file", 0), -rec.get("relevance", 0.0), idx)


def _order_with_and_without(recs):
    """Returns [(request, rank, rank_without_feedback, delta)] using the same construction as the
    implementation: neutralise position 3, keep every other term identical."""
    keyed = [_key(r, i) + (r,) for i, r in enumerate(recs)]
    keyed.sort(key=lambda k: k[:10])
    no_fb = sorted(keyed, key=lambda k: tuple(k[0:3]) + (0,) + tuple(k[4:10]))
    rank_without = {k[9]: i for i, k in enumerate(no_fb)}
    out = []
    for i, k in enumerate(keyed):
        was = rank_without[k[9]]
        out.append((k[10]["id"], i + 1, was + 1, was - i))
    return out


def test_no_votes_anywhere_means_no_influence_claimed():
    """The common case. If nobody voted, every delta must be 0 - the column must not imply
    feedback did something on a request where no feedback exists."""
    recs = [{"id": "a", "final": 50.0}, {"id": "b", "final": 30.0}, {"id": "c", "final": 10.0}]
    for _id, rank, without, delta in _order_with_and_without(recs):
        assert delta == 0, f"{_id} claimed movement with no votes"


def test_a_downvote_cannot_bury_the_best_scoring_fix():
    """Feedback is a tie-break, never a weight. The best-scoring fix stays first however many
    downvotes it carries, and the counterfactual honestly reports no movement."""
    recs = [{"id": "best", "final": 90.0, "down": 3},
            {"id": "mid", "final": 50.0},
            {"id": "low", "final": 10.0}]
    result = {r[0]: r for r in _order_with_and_without(recs)}
    assert result["best"][1] == 1, "a downvote must not outrank the final score"
    assert result["best"][3] == 0, "no movement to claim when score decided it"


def test_net_votes_break_a_tie_and_only_a_tie():
    """Net votes sit at position 3 - after score and similarity. They may decide between
    otherwise identical candidates and must not override a score difference."""
    # The voted one is listed SECOND, so without votes the stable index tie-break would keep it
    # second. Only then does moving to first prove the votes did it.
    tie = [{"id": "unvoted", "final": 40.0, "sim": 0.8}, {"id": "voted", "final": 40.0, "sim": 0.8, "up": 5}]
    result = {r[0]: r for r in _order_with_and_without(tie)}
    assert result["voted"][1] == 1
    assert result["voted"][2] == 2, "without votes the stable order would have kept it second"
    assert result["voted"][3] == 1, "upvotes should win an exact tie"

    # Same votes, but now the rival scores higher: feedback must NOT flip it.
    outscored = [{"id": "voted", "final": 40.0, "up": 5}, {"id": "better", "final": 80.0}]
    result = {r[0]: r for r in _order_with_and_without(outscored)}
    assert result["better"][1] == 1, "score must outrank a late vote tie-break"
    assert result["voted"][3] == 0, "no movement to claim when score decided it"


def test_similarity_breaks_a_score_tie_before_any_vote():
    """Equal final scores, different similarities: the closer error wins, and five upvotes on the
    other one change nothing - votes only decide when the similarity ties too."""
    recs = [{"id": "loved", "final": 40.0, "sim": 0.70, "up": 5},
            {"id": "closer", "final": 40.0, "sim": 0.81}]
    result = {r[0]: r for r in _order_with_and_without(recs)}
    assert result["closer"][1] == 1
    assert result["loved"][3] == 0, "votes must not be credited when similarity decided it"


def test_a_single_stray_downvote_moves_nothing_unless_tied():
    """One not-helpful vote with no ups used to sink a candidate (a real case). It no longer can:
    only a tie on score and similarity lets it decide."""
    recs = [{"id": "voted", "final": 70.0, "down": 1}, {"id": "other", "final": 60.0}]
    result = {r[0]: r for r in _order_with_and_without(recs)}
    assert result["voted"][1] == 1 and result["voted"][3] == 0

    tied = [{"id": "voted", "final": 60.0, "sim": 0.5, "down": 1}, {"id": "other", "final": 60.0, "sim": 0.5}]
    result = {r[0]: r for r in _order_with_and_without(tied)}
    assert result["voted"][1] == 2 and result["voted"][2] == 1 and result["voted"][3] == -1


def test_upvotes_alone_never_lift_a_worse_score():
    recs = [{"id": "loved", "final": 20.0, "up": 9}, {"id": "plain", "final": 80.0}]
    result = {r[0]: r for r in _order_with_and_without(recs)}
    assert result["plain"][1] == 1, "a high score still leads"
    assert result["loved"][1] == 2


def test_nothing_to_recommend_sorts_last_whatever_the_score():
    recs = [{"id": "bare", "final": 99.0, "solution": False}, {"id": "fix", "final": 10.0}]
    assert [r[0] for r in _order_with_and_without(recs)] == ["fix", "bare"]


def test_deltas_are_a_permutation_and_sum_to_zero():
    """Sanity: the two orders are permutations of the same pool, so the movements must cancel.
    A non-zero sum would mean the counterfactual dropped or duplicated a candidate."""
    recs = [{"id": "a", "final": 90.0, "down": 2}, {"id": "b", "final": 70.0, "sim": 0.5, "up": 3},
            {"id": "c", "final": 70.0, "sim": 0.5}, {"id": "d", "final": 10.0, "down": 5}]
    rows = _order_with_and_without(recs)
    assert sum(r[3] for r in rows) == 0
    assert sorted(r[1] for r in rows) == [1, 2, 3, 4]
    assert sorted(r[2] for r in rows) == [1, 2, 3, 4]


def test_ties_are_stable_so_the_number_does_not_flicker():
    """Identical candidates must keep their original order in both sorts, or a trace opened twice
    would report different movement for the same request."""
    recs = [{"id": "x", "final": 50.0}, {"id": "y", "final": 50.0}, {"id": "z", "final": 50.0}]
    first = _order_with_and_without(recs)
    second = _order_with_and_without(recs)
    assert first == second
    assert [r[0] for r in first] == ["x", "y", "z"]


if __name__ == "__main__":
    import traceback
    failed = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print("ok  ", name)
            except Exception:
                failed += 1
                print("FAIL", name)
                traceback.print_exc()
    sys.exit(1 if failed else 0)
