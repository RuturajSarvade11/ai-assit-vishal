from io import BytesIO
from zipfile import ZipFile

from src.services import handlers
from src.utils import project_details
from src.utils import payload_archive, ttl_cache


def _fix_rows(other_change):
    return [
        {
            "request_id": "candidate",
            "payload_json": {
                "solution": [{
                    "filePath": "work/tools/config.xml",
                    "changes": ["<Compiler>CTC</Compiler>"],
                }],
            },
        },
        {
            "request_id": "other-fix",
            "payload_json": {
                "solution": [{
                    "filePath": "src/error_file.py",
                    "changes": [other_change],
                }],
            },
        },
    ]


def test_generic_error_and_file_words_do_not_exclude_candidate_artifact(monkeypatch):
    monkeypatch.setattr(handlers, "_PROJECT_FIX_TOKENS_CACHE", {})
    monkeypatch.setattr(
        project_details,
        "list_final_build_payloads_by_project",
        lambda project: _fix_rows("Update file handling"),
    )

    claimant = handlers._artifact_claimed_by_another_solution(
        "demo", "candidate", b"[ERROR] Error parsing input file", "debug.log",
    )

    assert claimant == ""


def test_specific_artifact_terms_still_identify_another_fix(monkeypatch):
    monkeypatch.setattr(handlers, "_PROJECT_FIX_TOKENS_CACHE", {})
    monkeypatch.setattr(
        project_details,
        "list_final_build_payloads_by_project",
        lambda project: _fix_rows("Set Python version to 3.10"),
    )

    claimant = handlers._artifact_claimed_by_another_solution(
        "demo", "candidate", b"Python 3.10 version mismatch", "debug.log",
    )

    assert claimant == "other-fix"


def test_legacy_false_flag_is_rechecked_with_current_ownership_rule(monkeypatch):
    archive_bytes = BytesIO()
    with ZipFile(archive_bytes, "w") as archive:
        archive.writestr("debug.log", "[ERROR] Error parsing input file")
    monkeypatch.setattr(payload_archive, "download_s3_zip_bytes",
                        lambda key: (archive_bytes.getvalue(), "debug.log.zip"))
    monkeypatch.setattr(handlers, "_PROJECT_FIX_TOKENS_CACHE", {})
    monkeypatch.setattr(handlers, "_artifact_claimed_by_another_solution", lambda *args: "")
    ttl_cache.clear()

    eligible = handlers._artifact_reference_evidence_eligible(
        "demo", "candidate", {
            "evidence_eligible": False,
            "s3_key": "runtime/debug.log.zip",
            "file_name": "debug.log",
        },
    )

    assert eligible is True