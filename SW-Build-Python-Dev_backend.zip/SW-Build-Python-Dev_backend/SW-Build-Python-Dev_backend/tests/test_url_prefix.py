"""The API answers under /agent as well as at the root (new servers, Sep-2026)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, url_for  # noqa: E402

from src.utils.url_prefix import mount_under_prefix  # noqa: E402


def _app():
    app = Flask(__name__)

    @app.route("/ping")
    def ping():
        return url_for("ping")

    return app


def test_root_path_is_untouched():
    app = _app()
    mount_under_prefix(app, "/agent")
    assert app.test_client().get("/ping").data == b"/ping"


def test_prefixed_path_reaches_the_same_route_and_links_keep_the_prefix():
    app = _app()
    mount_under_prefix(app, "/agent")
    res = app.test_client().get("/agent/ping")
    assert res.status_code == 200
    assert res.data == b"/agent/ping"


def test_a_lookalike_path_is_not_stripped():
    app = _app()
    mount_under_prefix(app, "/agent")
    assert app.test_client().get("/agents/ping").status_code == 404


def test_empty_prefix_switches_it_off_and_double_mount_is_harmless():
    app = _app()
    assert mount_under_prefix(app, "") == ""
    assert app.test_client().get("/agent/ping").status_code == 404
    mount_under_prefix(app, "agent/")
    mount_under_prefix(app, "/agent")
    assert app.test_client().get("/agent/ping").status_code == 200
