from src.services import handlers


def test_exact_lookup_searches_whole_report_and_block_prepared_signatures(monkeypatch):
    monkeypatch.setattr(
        handlers,
        "_signature_hashes_from_candidates",
        lambda candidates, max_hashes=10: [
            "whole-report" if candidates[0] == "full report" else "prepared-block"
        ],
    )
    monkeypatch.setattr(
        handlers,
        "_prepare_messages_for_vectorization",
        lambda messages: ["focused stored error block"],
    )

    signatures, block_signatures = handlers._exact_query_signature_hashes(
        ["full report"], ["whole-report"])

    assert signatures == ["whole-report", "prepared-block"]
    assert block_signatures == ["prepared-block"]
