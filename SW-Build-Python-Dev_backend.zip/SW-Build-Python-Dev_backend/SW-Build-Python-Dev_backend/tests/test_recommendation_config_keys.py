"""Every setting the API accepts must actually be written.

The route decides which keys it will accept and the writer decides which it will store. Nothing
kept the two in step, and fileContentMatchWeight was accepted by one and unknown to the other -
so it was dropped. Sent on its own it raised; sent alongside a key the writer did know, it went
missing under a 200 OK, which is the shape worth guarding against.

The test that matters is therefore not "this key now works". It is that the two lists cannot drift
apart again without the next attempt failing and saying so.

No module is stubbed here. The module under test imports cleanly, and swapping modules in and out
of sys.modules is what has repeatedly made this suite depend on collection order.
"""
import os
import sys
from decimal import Decimal

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

os.environ.setdefault("AWS_DEFAULT_REGION", "eu-central-1")

from src.services import recommendation_config as rc  # noqa: E402

_stored = {}


class _FakeTable:
    def get_item(self, Key):
        return {"Item": dict(_stored)} if _stored else {}

    def put_item(self, Item):
        _stored.clear()
        _stored.update(Item)


@pytest.fixture(autouse=True)
def _table(monkeypatch):
    _stored.clear()
    monkeypatch.setattr(rc, "_table", lambda: _FakeTable())
    monkeypatch.setattr(rc._pc, "_ensure_table", lambda: None)
    monkeypatch.setattr(rc, "_cache", {"data": None}, raising=False)
    yield


# The list the HTTP route is willing to accept. If it changes, this list changes with it - which is
# the point: the two are meant to be kept in step deliberately, not by accident.
ROUTE_ACCEPTS = [
    "minSimilarityPercent", "taskMatchWeight", "artifactMatchWeight", "minSemanticSimilarity",
    "downvoteSinkMinVotes", "baseTaskWeight", "baseFileWeight",
    "baseTokenWeight", "llmPromoteEnabled", "evidenceSimilarityWeight", "historyWeightCeiling",
    "fileContentMatchWeight", "afterPatternWeight", "semanticMatchBase", "exactMatchBase",
    "evidenceContrastMinSpread", "feedbackSupportWeight",
    "usageHitsWeight", "shownHistoryWeight", "helperEvidenceRatio",
    "errorTextArtifactWeight", "ambiguityMargin",
]

SAMPLE = {
    "minSimilarityPercent": 40, "taskMatchWeight": 5, "artifactMatchWeight": 30,
    "minSemanticSimilarity": 0.4, "downvoteSinkMinVotes": 2,
    "baseTaskWeight": 3, "baseFileWeight": 6, "baseTokenWeight": 4, "llmPromoteEnabled": False,
    "evidenceSimilarityWeight": 0.3, "historyWeightCeiling": 4, "fileContentMatchWeight": 8,
    "afterPatternWeight": 2, "semanticMatchBase": 12, "exactMatchBase": 18, "feedbackSupportWeight": 1,
    "evidenceContrastMinSpread": 0.1,
    "usageHitsWeight": 1, "shownHistoryWeight": 0.5, "helperEvidenceRatio": 0.5,
    "errorTextArtifactWeight": 0.25, "ambiguityMargin": 0.05,
}


@pytest.mark.parametrize("key", ROUTE_ACCEPTS)
def test_every_accepted_setting_is_actually_written(key):
    """One at a time, so a key cannot pass by hiding behind a neighbour that works."""
    rc.set_values({key: SAMPLE[key]}, updated_by="tester")
    assert key in _stored, f"{key} is accepted by the route and never stored"


def test_the_three_identity_weights_really_do_change():
    """The three that are administrator settings - the ones behind same task, same
    file and configuration tokens."""
    rc.set_values({"baseTaskWeight": 3, "baseFileWeight": 6, "baseTokenWeight": 4},
                  updated_by="tester")
    assert _stored["baseTaskWeight"] == Decimal("3.0")
    assert _stored["baseFileWeight"] == Decimal("6.0")
    assert _stored["baseTokenWeight"] == Decimal("4.0")


def test_a_dropped_key_can_no_longer_hide_behind_a_working_one():
    """The shape worth guarding: a good key makes the call succeed while an unknown one goes
    missing under a 200. It has to fail instead, and name the key."""
    with pytest.raises(ValueError) as err:
        rc.set_values({"minSimilarityPercent": 40, "totallyUnknownKnob": 1}, updated_by="tester")
    assert "totallyUnknownKnob" in str(err.value)


def test_an_unknown_key_on_its_own_still_fails():
    with pytest.raises(ValueError):
        rc.set_values({"somethingElse": 1}, updated_by="tester")


def test_values_are_clamped_not_rejected():
    """An administrator typing 999 gets the top of the range, not a failure part-way through a
    change."""
    rc.set_values({"baseFileWeight": 999}, updated_by="tester")
    assert _stored["baseFileWeight"] == Decimal("30.0")
    rc.set_values({"baseFileWeight": -5}, updated_by="tester")
    assert _stored["baseFileWeight"] == Decimal("0.0")


def test_who_changed_it_and_when_are_recorded():
    """A weight that moves overnight with no record of who moved it is a debugging trap."""
    rc.set_values({"baseFileWeight": 6}, updated_by="omkar")
    assert _stored["updated_by"] == "omkar"
    assert int(_stored["updated_at"]) > 0


def test_updating_one_setting_leaves_the_others_alone():
    rc.set_values({"baseFileWeight": 6}, updated_by="tester")
    rc.set_values({"baseTaskWeight": 3}, updated_by="tester")
    assert _stored["baseFileWeight"] == Decimal("6.0")
    assert _stored["baseTaskWeight"] == Decimal("3.0")


def test_the_narrower_caps_are_not_widened_by_a_neighbour():
    """afterPatternWeight stops at 1 and feedbackSupportWeight at 18, while the weights beside them
    run to 30. A later block that clamped everything to 30 would silently widen these two, which is
    exactly what one did."""
    rc.set_values({"afterPatternWeight": 25}, updated_by="tester")
    assert _stored["afterPatternWeight"] == Decimal("1.0")
    rc.set_values({"feedbackSupportWeight": 25}, updated_by="tester")
    assert _stored["feedbackSupportWeight"] == Decimal("18.0")


def test_the_retired_similarity_flag_is_accepted_but_never_stored():
    """similarityWeightedScoring is retired: always on, and a PUT cannot turn it back off.

    It shipped OFF and that single default is what made every semantic candidate carry the full
    base - the Match column read a flat 12.00 whatever the similarity beside it, so ranking fell
    to circumstantial signals and a tooltip divided the match by the similarity to recover a
    "base" of 14.5 or 26 for a number that is only ever 18 or 12.

    Still accepted so an older dashboard's PUT is not an error, and still READ as True so a page
    built against the earlier shape does not report the weighting as off.
    """
    from src.services import recommendation_config as rc
    src = open(rc.__file__, encoding="utf-8").read()
    assert 'data["similarityWeightedScoring"] = True' in src, "the read path can report it as off again"
    assert 'item["similarityWeightedScoring"]' not in src, "a PUT can still store it and turn it off"
