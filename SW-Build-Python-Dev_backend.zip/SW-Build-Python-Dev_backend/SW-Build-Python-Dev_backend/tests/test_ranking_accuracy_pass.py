"""The accuracy pass: the closer fix must not lose rank 1 to a familiar one.

Pinned here:
  1. each request is scored on its BEST match across queries, not the first one met;
  2. a semantic hit surfaces the NEWER fixes stored under the same error signature;
  3. being SHOWN before earns no points by default (usage hits, hit_count, "shown" outcomes);
  4. helpers may total at most helperEvidenceRatio x evidence (default 0.5);
  5. file identity compares basenames, so a fix stored with a full path still matches;
  6. the accuracy measurement ranks an uploaded fix inside the trace correctly.
"""
import os
import sys

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

from src.services import handlers  # noqa: E402
from src.services import recommendation_accuracy as ra  # noqa: E402
from src.services import recommendation_config as rc  # noqa: E402


def _m(rid, sim, match_type="semantic", sig="", vid=None):
    meta = {"request_id": rid}
    if sig:
        meta["error_signature_hash"] = sig
    return {"vector_id": vid or f"v-{rid}-{sim}", "meta": meta, "match_type": match_type,
            "similarity": sim}


# ---- 1. best match per request ----------------------------------------------------------------

def test_best_similarity_wins_over_first_seen():
    out = handlers._best_match_per_request([_m("A", 0.80), _m("B", 0.90), _m("A", 0.97)])
    assert [handlers._match_request_id(m) for m in out] == ["A", "B"]
    assert out[0]["similarity"] == 0.97


def test_exact_beats_any_semantic_similarity():
    out = handlers._best_match_per_request([_m("A", 0.99), _m("A", 1.0, match_type="exact")])
    assert out[0]["match_type"] == "exact"


def test_matches_without_request_id_pass_through():
    stray = {"vector_id": "x", "meta": {}, "match_type": "semantic", "similarity": 0.5}
    out = handlers._best_match_per_request([stray, _m("A", 0.7)])
    assert out[0] is stray and len(out) == 2


def test_missing_similarity_never_beats_a_measured_one():
    out = handlers._best_match_per_request([_m("A", None), _m("A", 0.42)])
    assert out[0]["similarity"] == 0.42


# ---- 2. same-signature siblings -----------------------------------------------------------------

def test_semantic_hit_brings_in_newer_fix_of_same_signature():
    matches = [_m("OLD", 0.93, sig="s1")]
    ids, metas = ["v-OLD"], [matches[0]["meta"]]
    added = handlers._expand_semantic_hits_to_signature_siblings(
        matches, ids, metas, lambda meta, _fb: ["NEW", "OLD"], limit=10)
    assert added == 1
    sibling = matches[-1]
    assert handlers._match_request_id(sibling) == "NEW"
    assert sibling["similarity"] == 0.93 and sibling["signature_sibling_of"] == "OLD"
    assert matches[0]["meta"]["request_id"] == "OLD", "the original meta must not be mutated"


def test_sibling_expansion_skips_requests_already_in_pool_and_respects_caps():
    matches = [_m("A", 0.9, sig="s"), _m("B", 0.8, sig="s2")]
    added = handlers._expand_semantic_hits_to_signature_siblings(
        matches, [], [], lambda meta, _fb: ["A", "B", "C", "D", "E"], limit=2, per_hit=5)
    assert added == 2
    assert {handlers._match_request_id(m) for m in matches} == {"A", "B", "C", "D"}


def test_sibling_expansion_is_fail_open():
    def _boom(meta, _fb):
        raise RuntimeError("dynamo down")
    matches = [_m("A", 0.9, sig="s")]
    assert handlers._expand_semantic_hits_to_signature_siblings(matches, [], [], _boom) == 0
    assert len(matches) == 1


def test_hits_without_signature_are_not_expanded():
    calls = []
    handlers._expand_semantic_hits_to_signature_siblings(
        [_m("A", 0.9)], [], [], lambda meta, fb: calls.append(1) or ["Z"])
    assert calls == []


# ---- 3. popularity earns nothing by default -------------------------------------------------------

def test_defaults_switch_view_points_off_and_halve_helpers():
    assert rc.SCORING_DEFAULTS["usageHitsWeight"] == 0.0
    assert rc.SCORING_DEFAULTS["shownHistoryWeight"] == 0.0
    assert rc.SCORING_DEFAULTS["helperEvidenceRatio"] == 0.5


def _context_score(monkeypatch, cfg, hits=3):
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: cfg)
    payload = {"task_name": "", "recommended_count": ["d"] * hits}
    details = {}
    score = handlers._fix_context_score(fix_instances=[], final_payload=payload,
                                        context={"task_paths": [], "file_names": [], "tokens": []},
                                        details=details)
    return score, details


def test_usage_hits_earn_nothing_by_default(monkeypatch):
    score, details = _context_score(monkeypatch, {})
    assert score == 0.0 and details["points"]["hits"] == 0.0


def test_usage_hits_restorable_by_admin(monkeypatch):
    score, _ = _context_score(monkeypatch, {"usageHitsWeight": 1.0})
    assert score == 3.0


def test_shown_history_earns_nothing_but_confirmed_success_still_counts(monkeypatch):
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {})
    now = handlers.datetime.now(handlers.UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    monkeypatch.setattr(handlers, "get_recommendation_outcome_summary", lambda rid: {"hit_count": 40})
    monkeypatch.setattr(handlers, "list_recommendation_outcomes",
                        lambda rid: [{"outcome_type": "shown", "created_date": now}] * 20)
    assert handlers._recommendation_success_score("R", {}, {}) == 0.0
    monkeypatch.setattr(handlers, "list_recommendation_outcomes",
                        lambda rid: [{"outcome_type": "success_correlated", "created_date": now}])
    assert handlers._recommendation_success_score("R", {}, {}) > 2.9


# ---- 5. file identity by basename -----------------------------------------------------------------

def test_file_points_match_full_stored_path_against_changed_basename(monkeypatch):
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {})
    details = {}
    score = handlers._fix_context_score(
        fix_instances=[{"file_name": "D:\\proj\\cfg\\config.xml", "task_path": ""}],
        final_payload={"task_name": ""},
        context={"task_paths": [], "file_names": ["config.xml"], "tokens": []},
        details=details)
    assert details["points"]["file"] == rc.SCORING_DEFAULTS["baseFileWeight"]
    assert score == rc.SCORING_DEFAULTS["baseFileWeight"]


# ---- 4. helper cap arithmetic (worked example from the analysis) ----------------------------------

def _final(match, helpers, ratio):
    counted = max(0.0, min(helpers, match * ratio))
    return match + counted


def test_closer_fix_wins_at_half_ratio_and_lost_at_full_ratio():
    old_fix = (12 * 0.85, 3 + 3 + 4)       # familiar: task + usage + history
    new_fix = (12 * 0.95, 3)               # closer: task only
    assert _final(*old_fix, 1.0) > _final(*new_fix, 1.0), "the bug this pass fixes"
    old_no_pop = (old_fix[0], 3)           # popularity points now 0 by default
    assert _final(*new_fix, 0.5) > _final(*old_no_pop, 0.5)


def test_helper_cap_ratio_is_read_by_the_scorer():
    src = open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()
    assert 'min(_helpers, _evidence * _helper_ratio)' in src


# ---- 6. accuracy measurement --------------------------------------------------------------------

_SOL = {
    "R1": [{"fileName": "build.gradle.kts", "changes": ["+ a"]}],
    "R2": [{"fileName": "config.xml", "changes": ["- <v>2.1</v>", "+ <v>2.3</v>"]}],
    "R3": [{"fileName": "config.xml", "changes": ["+ other"]}],
}


def _trace():
    return {"trace_id": "t1",
            "candidates": [{"rank": i, "request_id": r} for i, r in enumerate(["R1", "R2", "R3", "R4"], 1)],
            "shown_request_ids": ["R1", "R2", "R3"]}


def test_uploaded_fix_found_at_rank_2_by_content():
    upload = [{"fileName": "config.xml", "changes": ["- <v>2.1</v>", "+ <v>2.3</v>"]}]
    out = ra.rank_upload_in_trace(_trace(), "NEW-ID", handlers._solution_fingerprint(upload),
                                  {"config.xml"}, lambda rid: _SOL.get(rid, []))
    assert out["shown_rank"] == 2 and out["pool_rank"] == 2 and out["file_rank"] == 2


def test_uploaded_fix_matched_by_request_id_for_duplicate_upload():
    out = ra.rank_upload_in_trace(_trace(), "R4", "", set(), lambda rid: [])
    assert out["shown_rank"] == 0 and out["pool_rank"] == 4


def test_unknown_fix_is_a_miss():
    out = ra.rank_upload_in_trace(_trace(), "NEW", handlers._solution_fingerprint(
        [{"fileName": "x.c", "changes": ["+ y"]}]), {"x.c"}, lambda rid: _SOL.get(rid, []))
    assert out == {"shown_rank": 0, "pool_rank": 0, "file_rank": 0, "shown_count": 3, "pool_count": 4}


def test_summary_metrics():
    rows = [{"project_name": "p", "shown_rank": 1, "pool_rank": 1, "file_rank": 1},
            {"project_name": "p", "shown_rank": 2, "pool_rank": 2, "file_rank": 1},
            {"project_name": "q", "shown_rank": 0, "pool_rank": 5, "file_rank": 0},
            {"project_name": "q", "shown_rank": 0, "pool_rank": 0, "file_rank": 0}]
    s = ra.summarize(rows)["overall"]
    assert s["evaluated"] == 4
    assert s["hit_at_1"] == 0.25 and s["hit_at_3"] == 0.5
    assert s["in_pool"] == 0.75 and s["retrieved_but_hidden"] == 0.25
    assert s["mrr"] == pytest.approx((1 + 0.5) / 4, abs=1e-4)


def test_summary_of_nothing_is_empty_not_an_error():
    assert ra.summarize([])["overall"]["evaluated"] == 0
