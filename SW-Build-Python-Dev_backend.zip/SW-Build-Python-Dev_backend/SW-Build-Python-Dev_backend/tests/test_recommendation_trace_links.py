from src.services import handlers
from src.routes.route import _build_report_error_output
from src.utils import recommendation_trace


def test_report_error_weak_fallback_candidates_are_linked_to_trace(monkeypatch):
    captured = {}
    candidates = [{"request_id": "weak-1"}, {"request_id": "weak-2"}]

    monkeypatch.setattr(
        handlers,
        "_evaluate_recommendation_strength",
        lambda rec: {
            "match_status": "below_threshold",
            "confidence_score": 0.1,
            "source": "test",
        },
    )
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {})
    monkeypatch.setattr(handlers, "_reco_scope_members", lambda project: ([], "project"))
    monkeypatch.setattr(handlers, "_adapter_state_for", lambda project: False)
    monkeypatch.setattr(handlers, "_adapter_runtime_state", lambda project: {})
    monkeypatch.setattr(handlers, "_recommendation_min_final", lambda: 0)
    monkeypatch.setattr(
        recommendation_trace,
        "save_trace",
        lambda **kwargs: captured.update(kwargs) or "trace-id",
    )

    result = handlers._gate_recommendation_results(
        candidates,
        top_k=2,
        project_name="demo",
        trace_context={"endpoint": "report-error"},
    )

    assert result["recommendations"] == []
    assert result["weak_recommendations"] == candidates
    assert captured["shown_request_ids"] == ["weak-1", "weak-2"]
    assert [candidate["shown"] for candidate in captured["candidates"]] == [True, True]


def test_report_error_gate_fills_unused_slots_with_flagged_weak_candidates(monkeypatch):
    captured = {}
    candidates = [
        {"request_id": "strong-1"},
        {"request_id": "weak-1"},
        {"request_id": "weak-2"},
        {"request_id": "weak-3"},
    ]

    def evaluate(rec):
        status = "strong" if rec["request_id"] == "strong-1" else "below_threshold"
        return {"match_status": status, "confidence_score": 0.8 if status == "strong" else 0.2,
                "source": "test"}

    monkeypatch.setattr(handlers, "_evaluate_recommendation_strength", evaluate)
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {})
    monkeypatch.setattr(handlers, "_reco_scope_members", lambda project: ([], "project"))
    monkeypatch.setattr(handlers, "_adapter_state_for", lambda project: False)
    monkeypatch.setattr(handlers, "_adapter_runtime_state", lambda project: {})
    monkeypatch.setattr(handlers, "_recommendation_min_final", lambda: 0)
    monkeypatch.setattr(
        recommendation_trace,
        "save_trace",
        lambda **kwargs: captured.update(kwargs) or "trace-id",
    )

    result = handlers._gate_recommendation_results(
        candidates,
        top_k=3,
        project_name="demo",
        trace_context={"endpoint": "report-error"},
    )

    assert [rec["request_id"] for rec in result["recommendations"]] == ["strong-1"]
    assert [rec["request_id"] for rec in result["weak_recommendations"]] == ["weak-1", "weak-2"]
    assert all(rec["is_weak_match"] for rec in result["weak_recommendations"])
    assert captured["shown_request_ids"] == ["strong-1", "weak-1", "weak-2"]


def test_error_report_response_returns_strong_then_valid_weak_candidates():
    result = _build_report_error_output(
        project_name="demo",
        result={
            "recommendations": [
                {"request_id": "strong-1", "solution": [{"content": "fix"}], "match_status": "strong"}
            ],
            "weak_recommendations": [
                {"request_id": "weak-1", "solution": [{"content": "fix one"}],
                 "match_status": "below_threshold", "is_weak_match": True},
                {"request_id": "empty", "solution": [],
                 "match_status": "below_threshold", "is_weak_match": True},
                {"request_id": "weak-2", "solution": [{"content": "fix two"}],
                 "match_status": "below_threshold", "is_weak_match": True},
            ],
            "document_context": {"results": [], "artifact_context": {"results": []}},
            "context_enrichment": {},
        },
    )

    rows = result["recommendations"]
    assert [row["request_id"] for row in rows] == ["strong-1", "weak-1", "weak-2"]
    assert rows[1]["match_status"] == "below_threshold"
    assert rows[1]["is_weak_match"] is True