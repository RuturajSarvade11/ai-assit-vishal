"""Extension usage and adoption KPIs.

How identity is handled, which replaced what had been built:
store a KEY derived from the login, never the login, and never display an id on the dashboard.
So the tests for sealing, masking, encrypting, revealing and the capture toggle are gone with
the API they covered.

What is pinned here is what the screen must keep getting right:

  - a key identifies the same PERSON twice and nothing else, so one developer on two machines
    counts once - which an installation count cannot express
  - the people figures are counts only. Nothing that could identify anyone leaves that block
  - the adoption and value numbers need no key at all, so they work for installations that
    send none
  - "not tracking yet" must never render as "nobody is using it", and an unfinished scan must
    never render as either
"""
import os
import sys
import types

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

os.environ.setdefault("AUTH_JWT_SECRET", "test-secret-for-kpi-tests")

# project_details opens real DynamoDB tables at import time, so it is stubbed before the module
# under test can pull it in. Only the pieces extension_usage actually uses are provided.
_rows = []
_traces = []
_fake_pd = types.ModuleType("src.utils.project_details")
_fake_pd.EXTUSAGE_PROFILE_SK = "PROFILE"
_fake_pd.EXTUSAGE_PK_PREFIX = "EXTUSAGE#"
_fake_pd.list_extension_usage = lambda: list(_rows)
_fake_pd.list_all_recommendation_feedback = lambda: []
_fake_pd.list_all_recommendation_outcomes = lambda: []


def _scan_kpi_rows(budget_sec=20.0, page_size=500):
    """Stands in for the single bounded pass. The real one buckets by key from one scan; the
    fakes below still drive it through the same three lists so each test reads the same."""
    return {
        "usage": list(_rows),
        "feedback": list(_fake_pd.list_all_recommendation_feedback()),
        "outcomes": list(_fake_pd.list_all_recommendation_outcomes()),
        "traces": list(_traces),
        "scanned": len(_rows),
        "partial": False,
        "seconds": 0.0,
    }


_fake_pd.scan_kpi_rows = _scan_kpi_rows
_saved = []


def _save(**kwargs):
    _saved.append(kwargs)
    return True


_fake_pd.save_extension_usage = _save
_installed = []


def _save_install(**kwargs):
    _installed.append(kwargs)
    return True


_fake_pd.save_extension_install = _save_install

# The module under test reaches for project_details lazily, inside each function, so the stub has
# to be in place while the tests RUN and not merely while they import. It is installed per test
# through monkeypatch rather than written into sys.modules once: a permanent entry there is
# inherited by every test file collected afterwards, and those files then import a
# project_details with four names on it instead of the real one.
import pytest  # noqa: E402


@pytest.fixture(autouse=True)
def _stub_project_details(monkeypatch):
    monkeypatch.setitem(sys.modules, "src.utils.project_details", _fake_pd)
    yield

# The real cache is used, not a fake. It has no external dependencies, and stubbing it here put
# a permanent fake in sys.modules that every test file collected afterwards inherited - which is
# how the cache's own tests came to fail in the suite while passing on their own. Each test
# starts from an empty cache instead.
from src.utils import ttl_cache  # noqa: E402

from src.services import extension_usage as eu  # noqa: E402


def _reset(rows=None, traces=None):
    _rows[:] = rows or []
    _traces[:] = traces or []
    _saved[:] = []
    ttl_cache.clear()


def _use(install, date, project="hip26", builds=1, failures=0, version="2.3.9",
         uploads=0, recommended=0):
    return {"PK": f"EXTUSAGE#{install}", "SK": f"USE#{date}#{project}", "use_date": date,
            "project_name": project, "builds": builds, "failures": failures,
            "uploads": uploads, "recommended": recommended, "ext_version": version}


def _profile(install, first, last, version="2.3.9", dev_key=None):
    row = {"PK": f"EXTUSAGE#{install}", "SK": "PROFILE", "first_seen": first,
           "last_seen": last, "ext_version": version}
    if dev_key:
        row["dev_key"] = dev_key
    return row


# ------------------------------------------------------------------ the key

def test_the_key_is_taken_as_given_and_prefixed():
    """The extension derives it on the developer's own machine, so nothing here reverses or
    re-hashes anything - the value simply arrives. The prefix keeps it in its own space, apart
    from the dashboard sign-in values."""
    assert eu.usage_key("ABC123") == "ext#abc123"
    assert eu.usage_key("  abc123  ") == "ext#abc123"
    assert eu.usage_key("ext#abc123") == "ext#abc123", "the prefix was applied twice"
    assert eu.usage_key("") == ""


def test_no_login_is_ever_accepted_or_stored():
    """The whole point of the decision: the server has nothing to store, because a login never
    reaches it. What arrives is already an identifier."""
    _reset()
    eu.record_build(install_id="i1", project_name="hip26", developer_key="deadbeef")
    saved = _saved[0]
    assert saved["dev_key"] == "ext#deadbeef"
    assert "login" not in str(saved).lower()
    assert "identity_sealed" not in saved and "masked_id" not in saved


def test_a_build_without_a_key_still_counts_as_a_build():
    """A machine that cannot derive a key is not a machine we ignore. The build counts; it just
    cannot be attributed to a person."""
    _reset()
    eu.record_build(install_id="i1", project_name="hip26", developer_key="")
    assert _saved[0]["dev_key"] == ""


def test_the_removed_identity_api_is_really_gone():
    """These existed and were removed by decision, not by accident. If any of them reappears,
    the screen can show a login again, which is the thing that was ruled out."""
    for name in ("seal", "mask", "encrypt_identity", "decrypt_identity", "reveal_developer",
                 "resolve_developer", "identity_enabled"):
        assert not hasattr(eu, name), f"{name} is back in extension_usage"


# ------------------------------------------------------------------ people, as counts

def test_one_person_on_two_machines_counts_once():
    """The only reason the key exists. Counting installations would say two."""
    key = "ext#abc"
    _reset([_profile("i1", "2026-08-01", "2026-08-10", dev_key=key),
            _profile("i2", "2026-08-05", "2026-08-20", dev_key=key),
            _use("i1", "2026-08-10"), _use("i2", "2026-08-20")])
    people = eu._active_people("2026-08-01", list(_rows))
    assert people["people_known"] == 1
    assert people["people_active"] == 1
    assert people["max_machines_per_person"] == 2


def test_two_people_count_as_two():
    _reset([_profile("i1", "2026-08-01", "2026-08-10", dev_key="ext#a"),
            _profile("i2", "2026-08-01", "2026-08-10", dev_key="ext#b"),
            _use("i1", "2026-08-10"), _use("i2", "2026-08-10")])
    assert eu._active_people("2026-08-01", list(_rows))["people_active"] == 2


def test_a_person_who_has_not_built_in_the_window_is_known_but_not_active():
    """"Active" has to mean active, or the number answers a different question from the one
    asked."""
    _reset([_profile("i1", "2026-06-01", "2026-06-02", dev_key="ext#a"),
            _use("i1", "2026-06-02")])
    people = eu._active_people("2026-08-01", list(_rows))
    assert people["people_known"] == 1
    assert people["people_active"] == 0


def test_installations_without_a_key_are_reported_not_guessed_at():
    """An older extension sends no key. Those installations still count as installations, and
    the number that cannot be attributed is stated rather than folded into the people count."""
    _reset([_profile("i1", "2026-08-01", "2026-08-10", dev_key="ext#a"),
            _profile("i2", "2026-08-01", "2026-08-10"),
            _use("i1", "2026-08-10"), _use("i2", "2026-08-10")])
    people = eu._active_people("2026-08-01", list(_rows))
    assert people["people_active"] == 1
    assert people["installs_without_key"] == 1


def test_nothing_identifying_leaves_the_people_block():
    """The question is how many, never who. The block carries counts
    and one line per person, and the key that made those lines distinct must not be among them -
    not in a field, not in a label, not anywhere in the payload."""
    _reset([_profile("i1", "2026-08-01", "2026-08-10", dev_key="ext#secret"),
            _use("i1", "2026-08-10")])
    people = eu._active_people("2026-08-01", list(_rows))
    assert all(isinstance(v, int) for k, v in people.items() if k != "rows"), people
    assert "ext#secret" not in str(people)
    assert "secret" not in str(people)


# ------------------------------------------------------------------ the per-person table

def test_the_table_says_what_each_person_did_and_never_who_they_are():
    """The identifier is followed through what it does - how many times the person uploads,
    and how often a recommendation came back - while the identifier itself does not
    appear. Both have to hold at once, so the key groups the rows and is then dropped."""
    _reset([_profile("i1", "2026-08-01", "2026-08-20", dev_key="ext#a"),
            _use("i1", "2026-08-10", builds=2, uploads=5, recommended=4),
            _use("i1", "2026-08-11", builds=1, uploads=3, recommended=1, failures=1)])
    rows = eu._active_people("2026-08-01", list(_rows))["rows"]
    assert len(rows) == 1
    row = rows[0]
    assert row["uploads"] == 8
    assert row["recommended"] == 5
    assert row["builds"] == 3
    assert row["failures"] == 1
    assert row["active_days"] == 2
    assert "ext#a" not in str(row), "the key reached the screen"


def test_two_machines_belonging_to_one_person_make_one_line():
    """The reason the key exists at all. Two installation rows would say two people, and the
    counts would be split across them."""
    _reset([_profile("i1", "2026-08-01", "2026-08-10", dev_key="ext#a"),
            _profile("i2", "2026-08-02", "2026-08-12", dev_key="ext#a"),
            _use("i1", "2026-08-10", uploads=2), _use("i2", "2026-08-12", uploads=3)])
    rows = eu._active_people("2026-08-01", list(_rows))["rows"]
    assert len(rows) == 1
    assert rows[0]["machines"] == 2
    assert rows[0]["uploads"] == 5


def test_the_line_number_follows_first_appearance_not_activity():
    """A table whose rows swap identity between two looks cannot be read across a period. Order
    by "most active" and everybody is renumbered the moment somebody runs a build."""
    _reset([_profile("i1", "2026-08-05", "2026-08-20", dev_key="ext#late"),
            _profile("i2", "2026-08-01", "2026-08-20", dev_key="ext#early"),
            _use("i1", "2026-08-20", uploads=50), _use("i2", "2026-08-20", uploads=1)])
    rows = eu._active_people("2026-08-01", list(_rows))["rows"]
    assert [r["line"] for r in rows] == [1, 2]
    assert rows[0]["uploads"] == 1, "the earliest adopter is line 1, busiest or not"


def test_activity_before_the_window_is_not_counted_into_it():
    """The totals have to match the period named at the top of the screen, or the table quietly
    answers a different question."""
    _reset([_profile("i1", "2026-06-01", "2026-08-20", dev_key="ext#a"),
            _use("i1", "2026-06-15", uploads=99),
            _use("i1", "2026-08-10", uploads=2)])
    row = eu._active_people("2026-08-01", list(_rows))["rows"][0]
    assert row["uploads"] == 2


def test_somebody_who_did_nothing_in_the_window_still_has_a_line():
    """They installed it and stopped - which is the case most worth seeing. Dropping the row
    would make the screen show only success."""
    _reset([_profile("i1", "2026-06-01", "2026-06-02", dev_key="ext#a"),
            _use("i1", "2026-06-02", uploads=4)])
    rows = eu._active_people("2026-08-01", list(_rows))["rows"]
    assert len(rows) == 1
    assert rows[0]["active_in_period"] is False
    assert rows[0]["uploads"] == 0


def test_an_installation_with_no_key_has_no_line():
    """It cannot be attributed to anybody, so inventing a line for it would be a guess. The
    count of such installations is reported separately instead."""
    _reset([_profile("i1", "2026-08-01", "2026-08-10"),
            _use("i1", "2026-08-10", uploads=3)])
    people = eu._active_people("2026-08-01", list(_rows))
    assert people["rows"] == []
    assert people["installs_without_key"] == 1


# ------------------------------------------------------- asking, and being answered

def test_a_failure_report_counts_the_ask_and_the_answer_separately():
    """Two different facts. A report that got nothing back still happened, and hiding it would
    make the assistant look better than it is."""
    _reset()
    eu.record_report(install_id="i1", project_name="hip26", developer_key="k",
                     recommendations=3)
    saved = _saved[0]
    assert saved["uploads"] == 1
    assert saved["recommended"] == 1
    assert saved["answered"] == 3


def test_a_failure_report_that_got_nothing_back_is_still_counted():
    _reset()
    eu.record_report(install_id="i1", project_name="hip26", developer_key="k",
                     recommendations=0)
    assert _saved[0]["uploads"] == 1
    assert _saved[0]["recommended"] == 0


def test_asking_for_help_is_never_counted_as_a_build():
    """A build is a fix that was uploaded. Counting a question as one would inflate the adoption
    figure with exactly the events that did not succeed."""
    _reset()
    eu.record_report(install_id="i1", project_name="hip26", developer_key="k",
                     recommendations=2)
    assert _saved[0]["builds"] == 0


# ------------------------------------------------------ installed but never used

def test_an_installation_that_never_built_is_still_counted():
    """The rollout case. A usage record only exists once a build completes, so without the
    installation announcing itself, somebody who installs the extension and never builds is
    invisible - and those are exactly the people worth following up."""
    _reset([_profile("i1", "2026-08-01", "2026-08-20"),   # installed AND built
            _use("i1", "2026-08-20"),
            _profile("i2", "2026-08-02", "2026-08-02")])  # installed, never built
    a = eu._adoption(30, "2026-08-01", "", list(_rows))
    assert a["installations_known"] == 2
    assert a["active_installs"] == 1
    assert a["never_built"] == 1


def test_never_built_is_zero_when_everyone_has_built():
    _reset([_profile("i1", "2026-08-01", "2026-08-20"), _use("i1", "2026-08-20")])
    a = eu._adoption(30, "2026-08-01", "", list(_rows))
    assert a["never_built"] == 0
    assert a["installations_known"] == a["active_installs"] == 1


def test_announcing_an_installation_writes_no_build():
    """It must not inflate any build figure - the point is to show a zero, honestly."""
    _reset()
    _installed[:] = []
    eu.record_install(install_id="i9", ext_version="2.3.9")
    assert len(_installed) == 1 and _installed[0]["install_id"] == "i9"
    assert _saved == [], "announcing an installation wrote a build record"


# ------------------------------------------------------------------ adoption

def test_no_installations_reads_as_not_tracking_yet():
    """The failure mode this guards against: a fleet on an older extension rendering as a
    confident zero, which reads as 'nobody uses the tool'."""
    _reset([])
    a = eu._adoption(30, "2026-08-01", "", list(_rows))
    assert a["tracking_started"] is False
    assert a["active_installs"] == 0
    assert "handed out" in a["note"]


def test_an_unfinished_scan_is_not_reported_as_nothing_reported():
    """A live table of ~34,000 rows took 18.7s against a 20s budget, so the scan was cut short
    and usage rows - a tiny fraction of the table, returned in no particular order - were
    missed. The screen then announced "no installation has reported yet" about data that was
    sitting in the table, which reads as a finding rather than a gap and sent us hunting for a
    fault in the extension."""
    _reset([])
    complete = eu._adoption(30, "2026-08-01", "", [], False)
    truncated = eu._adoption(30, "2026-08-01", "", [], True)
    assert "No installation has reported yet" in complete["note"]
    assert "No installation has reported yet" not in truncated["note"]
    assert "not complete" in truncated["note"]
    assert truncated["tracking_started"] is False


def test_installations_are_counted_once_however_many_days_they_appear():
    _reset([_use("i1", "2026-08-20"), _use("i1", "2026-08-21"), _use("i2", "2026-08-21"),
            _profile("i1", "2026-08-20", "2026-08-21"), _profile("i2", "2026-08-21", "2026-08-21")])
    a = eu._adoption(30, "2026-08-01", "", list(_rows))
    assert a["tracking_started"] is True
    assert a["active_installs"] == 2
    assert a["builds_analysed"] == 3


def test_the_daily_series_carries_every_metric_the_chart_offers():
    """The chart lets the admin choose what to plot, so each day has to carry all of it."""
    _reset([_use("i1", "2026-08-20", builds=3, failures=1),
            _use("i2", "2026-08-20", builds=2, failures=0),
            _use("i1", "2026-08-21", builds=4, failures=2)])
    daily = eu._adoption(30, "2026-08-01", "", list(_rows))["daily"]
    assert [d["date"] for d in daily] == ["2026-08-20", "2026-08-21"]
    assert daily[0] == {"date": "2026-08-20", "installs": 2, "builds": 5, "failures": 1}
    assert daily[1] == {"date": "2026-08-21", "installs": 1, "builds": 4, "failures": 2}


def test_rows_before_the_window_are_excluded():
    _reset([_use("i1", "2026-07-01"), _use("i2", "2026-08-20")])
    assert eu._adoption(30, "2026-08-01", "", list(_rows))["active_installs"] == 1


def test_the_project_filter_narrows_the_count():
    _reset([_use("i1", "2026-08-20", project="hip26"), _use("i2", "2026-08-20", project="td5")])
    assert eu._adoption(30, "2026-08-01", "hip26", list(_rows))["active_installs"] == 1
    assert eu._adoption(30, "2026-08-01", "", list(_rows))["active_installs"] == 2


def test_version_spread_counts_installations_not_builds():
    """The point of this number is 'who still has an old build', so a busy machine on an old
    version must not outweigh a quiet one on the new version."""
    _reset([_use("i1", "2026-08-20", builds=50), _use("i2", "2026-08-20", builds=1),
            _profile("i1", "2026-08-20", "2026-08-20", version="2.3.7"),
            _profile("i2", "2026-08-20", "2026-08-20", version="2.3.9")])
    versions = {v["version"]: v["installs"] for v in eu._adoption(30, "2026-08-01", "", list(_rows))["versions"]}
    assert versions == {"2.3.7": 1, "2.3.9": 1}


# ------------------------------------------------------------------ value

def test_rates_are_none_rather_than_zero_when_nothing_was_measured():
    """A rate with no denominator is unknown, not 0%. Reporting 0% would read as a failure."""
    assert eu._rate(0, 0) is None
    assert eu._rate(0, 4) == 0.0
    assert eu._rate(3, 4) == 75.0


def _trace(tid, date, shown=True, sigs=("aaa",), project="hip26"):
    return {"PK": "RECTRACE", "trace_id": tid, "created_date": date + "T10:00:00Z",
            "project_name": project, "query_signature_hashes": list(sigs),
            "shown_request_ids": ["r1"] if shown else []}


def test_the_value_block_needs_no_identity_and_no_installations():
    """The shippable half. It has to produce numbers with capture off and not one installation
    reporting, or stage 1 collapses back into needing the approval."""
    _reset([], traces=[
        _trace("t1", "2026-08-20", shown=True, sigs=("aaa",)),
        _trace("t2", "2026-08-21", shown=True, sigs=("aaa",)),
        _trace("t3", "2026-08-21", shown=False, sigs=("bbb",)),
    ])
    _fake_pd.list_all_recommendation_feedback = lambda: [
        {"project_name": "hip26", "created_date": "2026-08-20T10:00:00Z", "is_helpful": True},
        {"project_name": "hip26", "created_date": "2026-08-21T10:00:00Z", "is_helpful": True},
        {"project_name": "hip26", "created_date": "2026-08-21T10:00:00Z", "is_helpful": False},
    ]
    _fake_pd.list_all_recommendation_outcomes = lambda: [
        {"project_name": "hip26", "created_date": "2026-08-20T10:00:00Z",
         "outcome_type": "success_correlated", "query_signature_hashes": ["aaa"]},
    ]
    try:
        v = eu._value("2026-08-01", "2026-08-31", "", "",
                      list(_fake_pd.list_all_recommendation_feedback()),
                      list(_fake_pd.list_all_recommendation_outcomes()), list(_traces))
        assert v["helpful"] == 2 and v["not_helpful"] == 1
        assert v["helpful_rate_percent"] == 66.7
        assert v["fixed_after_recommendation"] == 1
        # 3 failures asked, 2 got something shown.
        assert v["failures"] == 3 and v["answered"] == 2
        assert v["answer_rate_percent"] == 66.7
        # "aaa" came back on two separate occasions, "bbb" on one.
        assert v["distinct_failure_signatures"] == 2
        assert v["repeating_failure_signatures"] == 1
        assert v["repeat_rate_percent"] == 50.0
    finally:
        _fake_pd.list_all_recommendation_feedback = lambda: []
        _fake_pd.list_all_recommendation_outcomes = lambda: []


def test_the_answer_rate_can_never_exceed_one_hundred_percent():
    """It read 484.8% on UAT. The old formula divided the dashboard's totalRecommended by its
    totalErrors, which count different things - how often a stored fix was later recommended to
    others, over stored errors - so it was not a rate at all. One trace is one failure that
    asked, and shown_request_ids says whether it got an answer, so the two sides now match."""
    _reset([], traces=[_trace(f"t{i}", "2026-08-20", shown=True) for i in range(5)])
    v = eu._value("2026-08-01", "2026-08-31", "", "", [], [], list(_traces))
    assert v["answer_rate_percent"] == 100.0
    assert v["answered"] <= v["failures"]


def test_repeating_failures_counts_occasions_not_candidate_rows():
    """It sat at 100% because one failure writes a row per CANDIDATE, all carrying the same
    signature, so every signature trivially appeared more than once. Counting distinct traces
    asks the real question: did this error come back on another occasion."""
    _reset([], traces=[_trace("t1", "2026-08-20", sigs=("aaa", "bbb")),
                       _trace("t2", "2026-08-21", sigs=("aaa",))])
    v = eu._value("2026-08-01", "2026-08-31", "", "", [], [], list(_traces))
    assert v["distinct_failure_signatures"] == 2
    assert v["repeating_failure_signatures"] == 1, "bbb was seen once and must not count"
    assert v["repeat_rate_percent"] == 50.0


def test_one_failure_with_many_candidates_is_still_one_failure():
    """The precise shape of the old bug, pinned."""
    _reset([], traces=[_trace("t1", "2026-08-20", sigs=("aaa",))])
    v = eu._value("2026-08-01", "2026-08-31", "", "", [], [], list(_traces))
    assert v["failures"] == 1
    assert v["repeating_failure_signatures"] == 0
    assert v["repeat_rate_percent"] == 0.0


def test_the_not_helpful_count_is_reported_alongside_the_helpful_one():
    """Client rule: the thumbs-down path is always shown, never hidden behind a single rate."""
    _reset([])
    v = eu._value("2026-08-01", "2026-08-31", "", "", list(_fake_pd.list_all_recommendation_feedback()), list(_fake_pd.list_all_recommendation_outcomes()), list(_traces))
    assert "not_helpful" in v and "helpful" in v


# ------------------------------------------------------------------ per-developer

# ------------------------------------------------------------------ encrypt and reveal

# ------------------------------------------------------------------ lookup

# ------------------------------------------------------------------ the whole tab

def test_a_failing_scan_still_answers_instead_of_erroring():
    """The endpoint first shipped with three unbounded scans and returned 504 on UAT. Because
    the request died before finishing, the cache never filled and the timeout then repeated on
    every later call. Whatever goes wrong underneath, this must still answer."""
    _reset([])
    good = _fake_pd.scan_kpi_rows

    def _boom(**kw):
        raise RuntimeError("scan failed")

    _fake_pd.scan_kpi_rows = _boom
    try:
        out = eu.compute_kpis(days=30)
        assert out["success"] is True
        assert out["data"]["adoption"]["tracking_started"] is False
        assert out["data"]["coverage"]["partial"] is True
    finally:
        _fake_pd.scan_kpi_rows = good


def test_the_blocks_read_one_shared_pass_not_three_scans():
    """The fix itself. Three separate scans of the same table were what caused the timeout, so
    the number of passes is the thing worth pinning - a future edit that reintroduces a private
    scan in one block would put the 504 straight back."""
    _reset([_use("i1", "2026-08-20")])
    calls = {"n": 0}
    good = _fake_pd.scan_kpi_rows

    def _counting(**kw):
        calls["n"] += 1
        return good(**kw)

    _fake_pd.scan_kpi_rows = _counting
    try:
        eu.compute_kpis(days=30)
        assert calls["n"] == 1, f"the table was read {calls['n']} times for one request"
    finally:
        _fake_pd.scan_kpi_rows = good


def test_a_partial_scan_is_reported_and_never_passed_off_as_complete():
    """Locked rule: no silent caps. A screen whose entire job is to be trusted as a count must
    say when it is looking at a sample."""
    _reset([_use("i1", "2026-08-20")])
    good = _fake_pd.scan_kpi_rows

    def _truncated(**kw):
        out = good(**kw)
        out["partial"] = True
        out["scanned"] = 500
        return out

    _fake_pd.scan_kpi_rows = _truncated
    try:
        cov = eu.compute_kpis(days=30)["data"]["coverage"]
        assert cov["partial"] is True
        assert cov["records_scanned"] == 500
        assert cov["note"], "a partial result carries no explanation"
    finally:
        _fake_pd.scan_kpi_rows = good


def test_the_scan_budget_and_cache_window_are_bounded():
    """The budget has to stay well under the gateway timeout, and the cache window long enough
    that the expensive pass is not repeated per click."""
    assert 2.0 <= eu._scan_budget_sec() <= 120.0
    # Must comfortably exceed the ~19s a live table already takes, or the scan truncates and
    # whole categories of row go missing.
    assert eu._scan_budget_sec() >= 30
    assert eu._scan_cache_ttl_sec() >= 30


def test_the_window_is_bounded():
    """0 means "not supplied" here, the same as an absent query parameter, so it falls back to
    the default rather than asking for a zero-day range."""
    assert eu._window(0)[0] == eu.DEFAULT_WINDOW_DAYS
    assert eu._window(None)[0] == eu.DEFAULT_WINDOW_DAYS
    assert eu._window(9999)[0] == 365
    assert eu._window(-5)[0] == 1
    assert eu._window(30)[0] == 30


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)


# --------------------------------------------------------------------- the period block

def _seen(install, date, project="hip26", seen_builds=0, seen_failures=0, **kw):
    row = _use(install, date, project=project, builds=0, **kw)
    row["seen_builds"] = seen_builds
    row["seen_failures"] = seen_failures
    return row


def test_the_period_block_answers_the_five_questions():
    _reset([
        _profile("i1", "2026-08-01", "2026-08-20", dev_key="ext#a"),
        _profile("i2", "2026-08-01", "2026-08-20", dev_key="ext#a"),   # same person, 2nd machine
        _profile("i3", "2026-08-01", "2026-08-20"),                    # older extension, no key
        _seen("i1", "2026-08-20", seen_builds=5, seen_failures=2, uploads=3, recommended=2),
        _seen("i2", "2026-08-21", seen_builds=1, seen_failures=1),
        _seen("i3", "2026-08-21", seen_builds=2, seen_failures=0, uploads=1),
    ])
    _rows[3]["builds"] = 2   # two fixes uploaded from i1
    p = eu._period("2026-08-01", "", list(_rows))
    assert p["active_users"] == 2, "one person on two machines + one unkeyed installation"
    assert p["builds"] == 8
    assert p["builds_failed"] == 3
    assert p["issues_captured"] == 2
    assert p["recommendation_requests"] == 4
    assert p["recommendation_answered"] == 2


def test_builds_read_as_not_reported_until_an_extension_reports_them():
    _reset([_profile("i1", "2026-08-01", "2026-08-20"), _use("i1", "2026-08-20", builds=3, failures=3)])
    p = eu._period("2026-08-01", "", list(_rows))
    assert p["builds"] is None and p["builds_failed"] is None
    assert p["issues_captured"] == 3


def test_a_build_outcome_adds_to_the_seen_counters_and_never_to_builds():
    _reset()
    assert eu.record_build_seen("i9", project_name="hip26", failed=True) is True
    assert _saved[-1]["builds"] == 0
    assert _saved[-1]["seen_builds"] == 1 and _saved[-1]["seen_failures"] == 1


def test_the_group_filter_uses_the_shared_group_resolution(monkeypatch):
    from src.services import project_groups as pg
    monkeypatch.setattr(pg, "build_group_map",
                        lambda names: {n: ("HIP26" if n.startswith("hip") else "Other") for n in names})
    rows = [_profile("i1", "2026-08-01", "2026-08-20"),
            _use("i1", "2026-08-20", project="hip26"), _use("i2", "2026-08-20", project="td5")]
    kept = eu._group_filter(rows, "HIP26")
    assert [r.get("project_name") for r in kept if r.get("SK") != "PROFILE"] == ["hip26"]
    assert len(eu._group_filter(rows, "ALL")) == 3
    assert len(eu._group_filter(rows, "")) == 3


# --------------------------------------------------------------------- the page summary

def _day(install, date, project="hip26", **counters):
    row = _use(install, date, project=project, builds=counters.pop("fix_uploads", 0),
               uploads=counters.pop("requests", 0), recommended=counters.pop("answered", 0))
    row["seen_builds"] = counters.pop("builds", 0)
    row["seen_failures"] = counters.pop("failed", 0)
    row["seen_issues"] = counters.pop("issues", 0)
    return row


def test_the_six_cards_and_their_change_against_the_previous_period():
    _reset([
        _profile("i1", "2026-07-01", "2026-08-20", dev_key="ext#a"),
        _profile("i2", "2026-07-01", "2026-08-20", dev_key="ext#b"),
        # previous 10 days: 1 user, 10 builds
        _day("i1", "2026-08-05", builds=10, failed=2, issues=4, fix_uploads=1, requests=2, answered=1),
        # current 10 days: 2 users, 15 builds
        _day("i1", "2026-08-12", builds=9, failed=3, issues=6, fix_uploads=2, requests=3, answered=2),
        _day("i2", "2026-08-15", builds=6, failed=0, issues=0, fix_uploads=0, requests=1, answered=0),
    ])
    s = eu._summary(10, "2026-08-11", "2026-08-20", "", list(_rows))
    c = s["cards"]
    assert c["active_users"] == {"value": 2, "previous": 1, "change_percent": 100.0}
    assert c["total_builds"] == {"value": 15, "previous": 10, "change_percent": 50.0}
    assert c["failed_builds"]["value"] == 3 and c["issues_captured"]["value"] == 6
    assert c["uploads"]["value"] == 2 and c["recommendation_requests"]["value"] == 4
    assert s["insights"]["failed_build_rate_percent"] == 20.0
    assert s["insights"]["recommendation_answered"] == 2 and s["insights"]["answer_rate_percent"] == 50.0
    assert s["comparison"] == {"from": "2026-08-01", "to": "2026-08-10", "available": True}


def test_the_trend_has_one_point_per_day_of_the_period():
    _reset([_profile("i1", "2026-08-01", "2026-08-20"),
            _day("i1", "2026-08-12", builds=9, failed=3, issues=6)])
    trend = eu._summary(10, "2026-08-11", "2026-08-20", "", list(_rows))["trend"]
    assert [p["date"] for p in trend][0] == "2026-08-11" and len(trend) == 10
    assert trend[1] == {"date": "2026-08-12", "active_users": 1, "total_builds": 9, "failed_builds": 3,
                        "issues_captured": 6, "uploads": 0, "recommendation_requests": 0}
    assert trend[0]["total_builds"] == 0 and trend[0]["active_users"] == 0


def test_build_figures_are_unknown_not_zero_until_an_extension_reports_them():
    _reset([_profile("i1", "2026-08-01", "2026-08-20"),
            _day("i1", "2026-08-12", fix_uploads=2, requests=3)])
    s = eu._summary(10, "2026-08-11", "2026-08-20", "", list(_rows))
    assert s["builds_reported"] is False
    assert s["cards"]["total_builds"]["value"] is None and s["cards"]["issues_captured"]["value"] is None
    assert s["cards"]["uploads"]["value"] == 2
    assert s["trend"][1]["total_builds"] is None and s["trend"][1]["uploads"] == 2
    assert s["insights"]["failed_build_rate_percent"] is None


def test_no_change_is_claimed_without_a_previous_period_to_compare_with():
    _reset([_profile("i1", "2026-08-01", "2026-08-20"), _day("i1", "2026-08-12", builds=5)])
    s = eu._summary(10, "2026-08-11", "2026-08-20", "", list(_rows))
    assert s["cards"]["total_builds"]["change_percent"] is None        # nothing before it
    long = eu._summary(90, "2026-05-23", "2026-08-20", "", list(_rows))
    assert long["comparison"]["available"] is False                      # past the row retention
    assert long["cards"]["active_users"]["change_percent"] is None


def test_the_build_ping_carries_the_captured_issues_only_for_a_failed_build():
    _reset()
    eu.record_build_seen("i9", project_name="hip26", failed=True, issues=3)
    assert _saved[-1]["seen_issues"] == 3
    eu.record_build_seen("i9", project_name="hip26", failed=False, issues=3)
    assert _saved[-1]["seen_issues"] == 0
    eu.record_build_seen("i9", project_name="hip26", failed=True, issues=10 ** 6)
    assert _saved[-1]["seen_issues"] == 500


def test_compute_kpis_returns_the_summary_and_refresh_drops_the_cache():
    _reset([_profile("i1", "2026-08-01", "2026-08-20")])
    data = eu.compute_kpis(days=7)["data"]
    assert set(data["summary"]["cards"]) == {"active_users", "total_builds", "failed_builds",
                                             "issues_captured", "uploads", "recommendation_requests"}
    assert len(data["summary"]["trend"]) == 7 and data["updated_at"].endswith("Z")
    _rows.append(_day("i1", datetime_today(), requests=1))
    assert eu.compute_kpis(days=7)["data"]["summary"]["cards"]["recommendation_requests"]["value"] == 0   # cached pass
    assert eu.compute_kpis(days=7, refresh=True)["data"]["summary"]["cards"]["recommendation_requests"]["value"] == 1


def datetime_today():
    from datetime import UTC, datetime
    return datetime.now(UTC).strftime("%Y-%m-%d")
