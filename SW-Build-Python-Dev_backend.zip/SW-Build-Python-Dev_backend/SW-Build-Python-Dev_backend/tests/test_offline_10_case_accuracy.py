"""10 stored failures, 1 live failure: is the right fix ranked FIRST?

Runs the REAL recommendation pipeline (_run_report_error_recommendation: query building, exact +
semantic retrieval, same-signature siblings, task ledger, artifact matching, scoring, rerank,
dedupe, gate) against an in-memory store of 10 fixed failures. Only the edges are replaced:

  - storage (DynamoDB / vector store / S3)   -> dicts in this file
  - the embedding model (Azure OpenAI)       -> a local hashing embedder (words + char 4-grams)
  - the LLM analysis and trace persistence    -> switched off

So this proves the PIPELINE ranks correctly given embeddings that behave like embeddings (similar
text -> high cosine). It does not measure the real embedding model; /recommendation-accuracy does
that on live data.

Three stores, each with 10 fixes for the same project + task:
  identical : all 10 report errors are the SAME text (one signature); only the debug.log names the
              real cause - the hardest case, the artifact alone must decide
  distinct  : 10 different report errors, each with its own log
  similar   : 10 errors of one template differing in a single value (tool + version)

For every store, each of the 10 failures is replayed as the live query (fresh timestamps, other
paths, different log chatter) - 30 queries per mode. Popularity trap: fix #1 of every store carries
heavy view history (shown 40x), the exact thing that used to keep a wrong fix on top.

    python tests/test_offline_10_case_accuracy.py      # prints the tables
    python -m pytest tests/test_offline_10_case_accuracy.py
"""
import hashlib
import math
import os
import re
import sys
from datetime import datetime, timedelta, timezone

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# Production stores one focused failure BLOCK per error (VECTOR_BLOCK_MODE=1 on the servers). In
# per-line mode the generic first line ("Execution failed for task ...") would be stored alone.
os.environ["VECTOR_BLOCK_MODE"] = "1"

import logging  # noqa: E402

from src.services import handlers  # noqa: E402
from src.utils import project_details, recommendation_trace, recommended  # noqa: E402

PROJECT = "demo"
TASK = ":TARGETS:master:task4"
# FIXED clock: the stored and live logs carry timestamps built from this, and token-level noise
# decides near-ties - a moving clock made the tie counts change from one run to the next.
_NOW = datetime(2026, 10, 10, 12, 0, 0, tzinfo=timezone.utc)

# ---------------------------------------------------------------------------------------------
# Local embedder: L2-normalised hashed bag of words + character 4-grams. Similar text -> high
# cosine, different text -> low cosine, deterministic, no network.
# ---------------------------------------------------------------------------------------------
_DIM = 4096


def _embed(text, *args, **kwargs):
    text = str(text or "").lower()
    vec = [0.0] * _DIM
    feats = re.findall(r"[a-z0-9_.']+", text)
    squashed = " ".join(feats)
    feats += [squashed[i:i + 4] for i in range(max(0, len(squashed) - 3))]
    for f in feats:
        h = int(hashlib.md5(f.encode("utf-8")).hexdigest(), 16)
        vec[h % _DIM] += -1.0 if (h >> 20) & 1 else 1.0
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def _cos(a, b):
    return max(-1.0, min(1.0, sum(x * y for x, y in zip(a, b))))


# ---------------------------------------------------------------------------------------------
# The 10 root causes. Each: the debug.log root-cause lines and the fix that resolved it.
# ---------------------------------------------------------------------------------------------
CAUSES = [
    ("python version", "'tools[name=python].version' must be '3.10.0' but got '3.1111.0'.",
     "config.json", ['- "version": "3.1111.0"', '+ "version": "3.10.0"']),
    ("ctc_aurix version", "'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p5'.",
     "config.json", ['- "version": "6.2r1p5"', '+ "version": "6.2r1p4"']),
    ("missing targets key", "KeyError: 'targets' - config root is missing required key 'targets'.",
     "config.json", ['+ "targets": ["master"]']),
    ("json syntax", "JSONDecodeError: Expecting ',' delimiter: line 42 column 7 (char 1180)",
     "config.json", ['-   "name": "core"', '+   "name": "core",']),
    ("missing header", "fatal error: can_driver_cfg.h: No such file or directory",
     "include_paths.txt", ['+ ${PROJ}/drivers/can/cfg']),
    ("license expired", "TASKING license checkout failed: feature ctc_aurix expired on 2026-09-30",
     "license.env", ['- LM_LICENSE_FILE=27000@oldlic', '+ LM_LICENSE_FILE=27000@lic-eu-02']),
    ("linker memory", "ltc E106: unresolved external: _Can_Init in section .text.can (memory region PFLASH0 overflow by 0x2c0)",
     "linker.lsl", ['- PFLASH0 size = 0x100000', '+ PFLASH0 size = 0x180000']),
    ("path too long", "OSError: [WinError 206] The filename or extension is too long: build\\master\\task4\\out\\gen",
     "settings.gradle.kts", ['+ buildDir = file("C:/b")']),
    ("permission denied", "PermissionError: [Errno 13] Permission denied: 'out/generated/version_info.h'",
     "task4.processes.gradle.kts", ['+ outputs.upToDateWhen { false }', '+ doFirst { delete(outDir) }']),
    ("duplicate target", "ValueError: duplicate target name 'master' in config targets list",
     "config.json", ['- "targets": ["master", "master"]', '+ "targets": ["master"]']),
]

_TEMPLATE_ERROR = ("Execution failed for task '{task}'.\n"
                   "> Process 'command 'c:/LegacyApp/python/3.10.0/python.exe'' finished with non-zero exit value 1\n"
                   "Error parsing input file")

_DISTINCT_ERRORS = [
    "Execution failed for task '{task}'. python.exe read_json_config.py: tool version check failed for python",
    "Execution failed for task '{task}'. Toolchain ctc_aurix version mismatch reported by read_json_config.py",
    "Execution failed for task '{task}'. read_json_config.py could not find the targets section",
    "Execution failed for task '{task}'. read_json_config.py failed: malformed JSON in config.json",
    "Execution failed for task '{task}'. cctc compilation of can_driver.c failed with 1 error",
    "Execution failed for task '{task}'. Compiler could not obtain a license for ctc_aurix",
    "Execution failed for task '{task}'. Linking task4.elf failed: unresolved symbols and memory overflow",
    "Execution failed for task '{task}'. Could not create output directory: path length limit exceeded",
    "Execution failed for task '{task}'. Unable to write generated header version_info.h",
    "Execution failed for task '{task}'. Configuration validation failed: duplicate target entries",
]

_SIMILAR_TOOLS = [("python", "3.10.0", "3.1111.0"), ("ctc_aurix", "6.2r1p4", "6.2r1p5"),
                  ("tricore_gcc", "11.3.1", "11.2.0"), ("cmake", "3.27.4", "3.21.0"),
                  ("ninja", "1.11.1", "1.10.2"), ("java", "17.0.8", "11.0.2"),
                  ("gradle_gbe", "9.5.0", "9.4.1"), ("doxygen", "1.9.8", "1.8.17"),
                  ("perl", "5.36.0", "5.32.1"), ("srecord", "1.64", "1.58")]


def _debug_log(cause_line: str, variant: int) -> str:
    """A realistic debug.log: chatter + the failure marker + the root-cause detail line.
    ``variant`` changes the timestamps, ids and chatter so stored and live logs never match
    byte-for-byte."""
    ts = (_NOW - timedelta(days=30 - variant)).strftime("%Y-%m-%d %H:%M:%S")
    return "\n".join([
        f"{ts},064 [INFO] read_json_config.py starting... (pid {4100 + variant * 7})",
        f"{ts},064 [DEBUG] Reading JSON file from disk: D:/ws{variant}/build/master/task4/in/config.json",
        f"{ts},066 [DEBUG] Validating config root keys: ['project', 'build', 'tools', 'targets']",
        f"{ts},067 [DEBUG] Snapshot c:/LegacyApp/ctc_aurix/6.2r1p4 created in [{variant % 5}] ms",
        f"{ts},068 [ERROR] Error parsing input file",
        f"{ts},068 [DEBUG] {cause_line}",
        f"{ts},069 [INFO] read_json_config.py finished with exit code 1",
    ])


def build_store(kind: str):
    """10 stored fixes: final-build payloads, error vectors, artifacts, histories."""
    fixes = []
    for i in range(10):
        if kind == "similar":
            tool, want, got = _SIMILAR_TOOLS[i]
            cause = f"'tools[name={tool}].version' must be '{want}' but got '{got}'."
            error = (f"Execution failed for task '{TASK}'.\n> Tool {tool} version check failed: "
                     f"expected {want}, found {got}")
            fname, changes = "config.json", [f'- "{tool}": "{got}"', f'+ "{tool}": "{want}"']
        else:
            _label, cause, fname, changes = CAUSES[i]
            error = (_TEMPLATE_ERROR if kind == "identical" else _DISTINCT_ERRORS[i]).format(task=TASK)
        rid = f"{kind[:3]}-{i:02d}"
        fixes.append({
            "request_id": rid, "index": i, "error": error, "cause": cause,
            "solution": [{"fileName": fname, "changes": changes}],
            "artifact_text": _debug_log(cause, variant=i),
            "s3_key": f"task-runtime-artifacts/{PROJECT}/{rid}/debug.log.zip",
            "created_date": (_NOW - timedelta(days=20 - i)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            # Popularity trap: fix #0 was SHOWN many times (views, not successes).
            "views": 40 if i == 0 else 0,
        })
    return fixes


OTHER_TASK = ":TARGETS:master:task3"


def _bump(text: str, times: int) -> str:
    for _ in range(times):
        text = _bump_last_number(text)
    return text


def build_stress_store():
    """40 fixes, every report error IDENTICAL (one signature), so only log + task can decide:
      - 10 causes x 3 VERSIONS: each version's log differs only in one value
        (got '3.1111.0' / '3.1111.1' / '3.1111.2') and each version had its OWN fix;
      - 10 CROSS-TASK TWINS: version 0's exact log and error, stored under another task with a
        different fix (the same failure can need a different fix in another task).
    The right answer for a query is the same-task fix of the same version."""
    fixes = []
    error = _TEMPLATE_ERROR.format(task=TASK)
    for c, (_label, cause0, fname, changes0) in enumerate(CAUSES):
        for v in range(3):
            cause = _bump(cause0, v)
            rid = f"str-{c:02d}-v{v}"
            fixes.append({
                "request_id": rid, "index": len(fixes), "error": error, "cause": cause,
                "solution": [{"fileName": fname, "changes": [_bump(x, v) for x in changes0] + [f"# version {v}"]}],
                "artifact_text": _debug_log(cause, variant=c * 3 + v),
                "s3_key": f"task-runtime-artifacts/{PROJECT}/{rid}/debug.log.zip",
                "created_date": (_NOW - timedelta(days=40 - c - v)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "views": 40 if v == 2 else 0,   # popularity trap on the wrong version
            })
        rid = f"str-{c:02d}-twin"
        fixes.append({
            "request_id": rid, "index": len(fixes), "error": error.replace("task4", "task3"),
            "cause": cause0, "task": OTHER_TASK,
            "solution": [{"fileName": "task3.processes.gradle.kts", "changes": [f"+ task3 workaround {c}"]}],
            "artifact_text": _debug_log(cause0, variant=60 + c),
            "s3_key": f"task-runtime-artifacts/{PROJECT}/{rid}/debug.log.zip",
            "created_date": _NOW.strftime("%Y-%m-%dT%H:%M:%SZ"),   # newest of all
            "views": 0,
        })
    return fixes


def _messy_log(cause: str) -> str:
    """A live log as it really comes: an unrelated earlier [ERROR] that was recovered from, a
    stack trace between the marker and the real cause, and trailing shutdown lines."""
    return "\n".join([
        "2026-10-10 08:00:00,001 [INFO] read_json_config.py starting... (pid 9001)",
        "2026-10-10 08:00:00,010 [ERROR] Could not reach artifact cache, retrying (attempt 1/3)",
        "2026-10-10 08:00:00,450 [INFO] Artifact cache reachable, continuing",
        "2026-10-10 08:00:01,066 [DEBUG] Validating config root keys: ['project', 'build', 'tools', 'targets']",
        "2026-10-10 08:00:01,068 [ERROR] Error parsing input file",
        "Traceback (most recent call last):",
        '  File "read_json_config.py", line 88, in <module>',
        "    validate(cfg)",
        f"ConfigError: {cause}",
        "2026-10-10 08:00:01,070 [INFO] read_json_config.py finished with exit code 1",
    ])


def run_stress(mode_cfg, setter, messy: bool = True):
    store = _Store(build_stress_store())
    _install(setter, store, mode_cfg)
    ranks = []
    for f in store.fixes.values():
        if f.get("task") == OTHER_TASK:
            continue  # twins are traps, not queries
        live_log = _messy_log(f["cause"]) if messy else _debug_log(f["cause"], variant=97)
        errors = [{"severity": "ERROR", "message": f["error"], "task_path": TASK,
                   "file_path": "task4.processes.gradle.kts", "locations": ["task4.processes.gradle.kts"]}]
        out = handlers._run_report_error_recommendation(
            project_name=PROJECT, errors=errors, task_path=TASK, user_requested_task=TASK,
            query_artifact_text=live_log,
            query_artifact_excerpts=[{"name": "debug.log", "text": live_log}],
            query_changed_files=[])
        shown = [str(r.get("request_id")) for r in (out.get("recommendations") or [])]
        rank = shown.index(f["request_id"]) + 1 if f["request_id"] in shown else 0
        ranks.append({"rid": f["request_id"], "rank": rank, "top": shown[:3],
                      "separable": _versions_separable(store, f),
                      "decision": out.get("decision") or {}})
    return ranks


def _versions_separable(store, fix) -> bool:
    """Can ANY system tell this fix's version apart from its siblings? Not when the versions'
    root-cause lines are the same after the pipeline's own normalisation (no number to differ, or
    the value is a date / hex address, which are stripped as volatile on purpose)."""
    family = fix["request_id"].rsplit("-v", 1)[0]
    mine = handlers._distinctive_token_set(fix["cause"])
    for other in store.fixes.values():
        if other is fix or not other["request_id"].startswith(family + "-v"):
            continue
        if handlers._distinctive_token_set(other["cause"]) == mine:
            return False
    return True


class _Store:
    """Answers every storage call the pipeline makes, from the 10 fixes."""

    def __init__(self, fixes):
        self.fixes = {f["request_id"]: f for f in fixes}
        self.vectors = {}          # signature -> vector row (FIRST uploader names it, like prod)
        self.by_sig = {}           # signature -> [request ids], newest first
        for f in fixes:
            doc = (handlers._prepare_messages_for_vectorization([f["error"]]) or [f["error"]])[0]
            sig = handlers._signature_hashes_from_candidates([doc], max_hashes=1)[0]
            f["sig"] = sig
            self.by_sig.setdefault(sig, []).insert(0, f["request_id"])
            if sig not in self.vectors:
                self.vectors[sig] = {"id": f"vec-{sig[:10]}", "doc": doc, "emb": _embed(doc),
                                     "meta": {"request_id": f["request_id"], "batch_id": f["request_id"],
                                              "project_name": PROJECT, "env": "test",
                                              "error_signature_hash": sig, "task_name": f.get("task", TASK)}}
        self.artifacts = {f["s3_key"]: {"doc": f["artifact_text"], "emb": _embed(f["artifact_text"])}
                          for f in fixes}

    # -- error vectors -------------------------------------------------------------------------
    def search_similar(self, query, project_name, top_k=10, **_kw):
        q = _embed(query)
        rows = sorted(self.vectors.values(), key=lambda v: -_cos(q, v["emb"]))[:top_k]
        return {"ids": [[r["id"] for r in rows]], "metadatas": [[dict(r["meta"]) for r in rows]],
                "documents": [[r["doc"] for r in rows]],
                "distances": [[2.0 * (1.0 - _cos(q, r["emb"])) for r in rows]]}

    def search_signatures(self, project_name, signature_hashes, top_k=2):
        rows = [self.vectors[s] for s in (signature_hashes or []) if s in self.vectors][:top_k]
        return {"ids": [[r["id"] for r in rows]], "metadatas": [[dict(r["meta"]) for r in rows]],
                "documents": [[r["doc"] for r in rows]]}

    def signature_summary(self, owner, env, sig):
        rids = self.by_sig.get(sig) or []
        return {"latest_request_id": rids[0]} if rids else None

    def signature_refs(self, owner, env, sig):
        return [{"request_id": r} for r in (self.by_sig.get(sig) or [])]

    # -- payloads ------------------------------------------------------------------------------
    def payload(self, rid):
        f = self.fixes.get(rid)
        if not f:
            return None
        return {"request_id": rid, "project_name": PROJECT, "task_name": f.get("task", TASK),
                "solution": f["solution"], "created_date": f["created_date"],
                "recommended_count": ["2026-10-01T00:00:00Z"] * f["views"],
                "errorDetails": [{"message": f["error"]}]}

    def ledger_rows(self, project):
        return [{"request_id": rid, "project_name": PROJECT, "task_name": f.get("task", TASK),
                 "created_date": f["created_date"],
                 "payload_json": {"solution": f["solution"], "errorDetails": [{"message": f["error"]}]}}
                for rid, f in self.fixes.items()]

    def fix_instances(self, rid):
        f = self.fixes.get(rid)
        return [{"task_path": f.get("task", TASK), "file_name": s["fileName"], "config_tokens": []}
                for s in (f["solution"] if f else [])]

    def outcome_summary(self, rid):
        return {"hit_count": self.fixes.get(rid, {}).get("views", 0)}

    def outcomes(self, rid):
        n = self.fixes.get(rid, {}).get("views", 0)
        return [{"outcome_type": "shown", "created_date": _NOW.strftime("%Y-%m-%dT%H:%M:%SZ")}] * n

    # -- artifacts -----------------------------------------------------------------------------
    def artifact_refs(self, rid, artifact_type="runtime"):
        f = self.fixes.get(rid)
        return [{"s3_key": f["s3_key"]}] if (f and artifact_type == "runtime") else []

    def artifact_summaries(self, project, limit=2000):
        return {k: {"summary": v["doc"]} for k, v in self.artifacts.items()}

    def artifact_collection(self):
        store = self

        class _Col:
            def query(self, query_embeddings, n_results=10, include=None, where=None):
                q = query_embeddings[0]
                rows = sorted(store.artifacts.items(), key=lambda kv: -_cos(q, kv[1]["emb"]))[:n_results]
                return {"metadatas": [[{"s3_key": k, "project_name": PROJECT} for k, _ in rows]],
                        "documents": [[v["doc"] for _, v in rows]],
                        "distances": [[2.0 * (1.0 - _cos(q, v["emb"])) for _, v in rows]]}

            def get(self, *a, **k):
                return {"ids": [], "metadatas": [], "documents": []}
        return _Col()


MODES = {
    # The shipped defaults after the accuracy pass.
    "new defaults": {},
    # The pre-pass weights: views earn points, helpers may equal the evidence.
    "old weights": {"usageHitsWeight": 1.0, "shownHistoryWeight": 1.0, "helperEvidenceRatio": 1.0},
}


def _install(monkeypatch_set, store, cfg):
    s = monkeypatch_set
    for mod in (handlers, recommended):
        if hasattr(mod, "create_embedding"):
            s(mod, "create_embedding", _embed)
    s(handlers, "search_similar_errors_fused", store.search_similar)
    s(handlers, "search_errors_by_signatures", store.search_signatures)
    s(handlers, "get_error_signature_summary", store.signature_summary)
    s(handlers, "get_error_solution_references_summary_first", store.signature_refs)
    s(handlers, "_resolve_signature_env", lambda owner, env, sig: env)
    s(handlers, "get_final_build_payload", store.payload)
    s(handlers, "get_fix_instances", store.fix_instances)
    s(handlers, "get_recommendation_outcome_summary", store.outcome_summary)
    s(handlers, "list_recommendation_outcomes", store.outcomes)
    s(handlers, "list_recommendation_feedback", lambda *a, **k: [])
    s(project_details, "list_final_build_payloads_by_project", store.ledger_rows)
    s(handlers, "get_artifact_references", store.artifact_refs)
    s(project_details, "get_artifact_references", store.artifact_refs)
    s(handlers, "_artifact_reference_evidence_eligible", lambda *a, **k: True)
    s(handlers, "_artifact_summaries_for_project", store.artifact_summaries)
    s(handlers, "get_artifact_chroma_collection", store.artifact_collection)
    s(handlers, "_reco_scope_members", lambda p: ([PROJECT], "project"))
    s(handlers, "_rc_get_config_cached", lambda: dict(cfg))
    s(handlers, "_track_recommendation_hits", lambda *a, **k: None)
    s(handlers, "_write_recommendation_report_html", lambda *a, **k: "")
    s(handlers, "_build_unified_context_enrichment", lambda *a, **k: {})
    s(recommendation_trace, "save_trace", lambda *a, **k: "offline")
    from src.utils import ttl_cache
    s(ttl_cache, "get_or_compute", lambda key, fn, **k: fn())


def _bump_last_number(text: str) -> str:
    """Same root cause, different literal: the last number in the line changes (3.1111.0 ->
    3.1111.1, line 42 -> 43). The developer's failure is the same KIND as the stored one, never a
    byte-for-byte copy."""
    m = list(re.finditer(r"\d+", text))
    if not m:
        return text
    last = m[-1]
    return text[:last.start()] + str(int(last.group()) + 1) + text[last.end():]


EVIDENCE = {
    "error + artifact": {"artifact": True},
    "long log (300 lines)": {"artifact": True, "chatter": 300},
    "changed value": {"artifact": True, "bump": True},
    "error only": {"artifact": False},
}


def _live_query(fix, kind, with_artifact, chatter: int = 0, bump: bool = False):
    """The developer's failure today: same root cause, new timestamps / paths / chatter."""
    error = fix["error"].replace("c:/LegacyApp", "C:/LegacyApp")
    cause = _bump_last_number(fix["cause"]) if bump else fix["cause"]
    if bump:
        error = _bump_last_number(error)
    errors = [{"severity": "ERROR", "message": error, "task_path": TASK,
               "file_path": "task4.processes.gradle.kts", "locations": ["task4.processes.gradle.kts"]}]
    live_log = _debug_log(cause, variant=97)
    if chatter:
        # Real logs: hundreds of progress lines BEFORE the failure, which sits at the end.
        noise = "\n".join(f"2026-10-10 09:{i // 60:02d}:{i % 60:02d},{i:03d} [DEBUG] processed module "
                          f"m{i:04d} ({i * 13 % 997} symbols, {i % 7} warnings)" for i in range(chatter))
        live_log = noise + "\n" + live_log
    return dict(
        project_name=PROJECT, errors=errors, task_path=TASK, user_requested_task=TASK,
        query_artifact_text=live_log if with_artifact else "",
        query_artifact_excerpts=[{"name": "debug.log", "text": live_log}] if with_artifact else [],
        query_changed_files=[],
    )


def run_case(kind, mode_cfg, evidence, setter):
    """evidence: a key of EVIDENCE (or True/False for plain artifact / error only)."""
    if isinstance(evidence, bool):
        evidence = "error + artifact" if evidence else "error only"
    ev = EVIDENCE[evidence]
    store = _Store(build_store(kind))
    _install(setter, store, mode_cfg)
    ranks = []
    for f in store.fixes.values():
        out = handlers._run_report_error_recommendation(**_live_query(
            f, kind, ev["artifact"], chatter=ev.get("chatter", 0), bump=ev.get("bump", False)))
        shown = [str(r.get("request_id")) for r in (out.get("recommendations") or [])]
        pool = shown + [str(r.get("request_id")) for r in (out.get("weak_recommendations") or [])]
        rank = shown.index(f["request_id"]) + 1 if f["request_id"] in shown else 0
        ranks.append({"rid": f["request_id"], "rank": rank, "top": shown[:3],
                      "in_pool": f["request_id"] in pool})
    return ranks


def _setter_from(monkeypatch):
    return lambda obj, name, value: monkeypatch.setattr(obj, name, value, raising=False)


# ---- pytest ------------------------------------------------------------------------------------

def _quiet():
    logging.disable(logging.CRITICAL)


def test_identical_errors_artifact_decides_rank_1(monkeypatch):
    _quiet()
    ranks = run_case("identical", MODES["new defaults"], True, _setter_from(monkeypatch))
    assert all(r["rank"] == 1 for r in ranks), ranks


def test_distinct_errors_rank_1(monkeypatch):
    _quiet()
    ranks = run_case("distinct", MODES["new defaults"], True, _setter_from(monkeypatch))
    assert all(r["rank"] == 1 for r in ranks), ranks


def test_similar_errors_rank_1(monkeypatch):
    _quiet()
    ranks = run_case("similar", MODES["new defaults"], True, _setter_from(monkeypatch))
    assert all(r["rank"] == 1 for r in ranks), ranks


def test_long_log_failure_at_the_end_still_decides(monkeypatch):
    """300 lines of chatter before the failure line: the tail must reach the comparison."""
    _quiet()
    ranks = run_case("identical", MODES["new defaults"], "long log (300 lines)", _setter_from(monkeypatch))
    assert all(r["rank"] == 1 for r in ranks), ranks


def test_same_cause_with_a_different_value_still_finds_the_fix(monkeypatch):
    _quiet()
    ranks = run_case("identical", MODES["new defaults"], "changed value", _setter_from(monkeypatch))
    assert all(r["rank"] == 1 for r in ranks), ranks


# ---- report ------------------------------------------------------------------------------------

if __name__ == "__main__":
    _quiet()
    import contextlib

    class _Patch:
        def __init__(self):
            self.saved = []

        def __call__(self, obj, name, value):
            self.saved.append((obj, name, getattr(obj, name, None)))
            setattr(obj, name, value)

        def undo(self):
            for obj, name, value in reversed(self.saved):
                setattr(obj, name, value)
            self.saved.clear()

    patch = _Patch()
    print(f"{'store':<10} {'mode':<13} {'evidence':<21} {'rank1':>6} {'top3':>6}  ranks of the right fix (1 = first)")
    print("-" * 100)
    for kind in ("identical", "distinct", "similar"):
        for mode_name, cfg in MODES.items():
            for label in EVIDENCE:
                with contextlib.suppress(Exception):
                    patch.undo()
                ranks = run_case(kind, cfg, label, patch)
                patch.undo()
                r1 = sum(1 for r in ranks if r["rank"] == 1)
                r3 = sum(1 for r in ranks if 1 <= r["rank"] <= 3)
                print(f"{kind:<10} {mode_name:<13} {label:<21} {r1:>4}/10 {r3:>4}/10  "
                      + " ".join(str(r['rank'] or '-') for r in ranks))


# ---- stress: 40 fixes, versions + cross-task twins, messy logs ---------------------------------

def test_stress_separable_versions_always_rank_1(monkeypatch):
    """Identical error text everywhere; 3 versions per cause and a twin in another task. Every
    version that CAN be told apart is ranked first, and the answer is never called ambiguous."""
    _quiet()
    ranks = run_stress(MODES["new defaults"], _setter_from(monkeypatch), messy=True)
    separable = [r for r in ranks if r["separable"]]
    assert separable and all(r["rank"] == 1 for r in separable), separable
    assert not any(r["decision"].get("ambiguous") for r in separable), \
        [r["rid"] for r in separable if r["decision"].get("ambiguous")]


def test_stress_inseparable_versions_stay_in_top3_and_are_mostly_flagged(monkeypatch):
    """Versions that differ only in a date / hex / nothing cannot be told apart by anybody: the
    right one must still be shown, and the response must say the top fixes are tied."""
    _quiet()
    ranks = run_stress(MODES["new defaults"], _setter_from(monkeypatch), messy=True)
    tied = [r for r in ranks if not r["separable"]]
    assert all(1 <= r["rank"] <= 3 for r in tied), tied
    flagged = sum(1 for r in tied if r["decision"].get("ambiguous"))
    assert flagged >= len(tied) * 0.75, f"only {flagged}/{len(tied)} ties flagged"


def test_cross_task_twin_never_wins(monkeypatch):
    _quiet()
    ranks = run_stress(MODES["new defaults"], _setter_from(monkeypatch), messy=True)
    assert not any(r["top"] and r["top"][0].endswith("-twin") for r in ranks)


def test_error_only_exact_match_is_not_overturned_by_stored_logs(monkeypatch):
    """No live log: the stored logs are probed with the error text - weak evidence that once let
    a log mentioning the same file beat an EXACT error match."""
    _quiet()
    ranks = run_case("distinct", MODES["new defaults"], "error only", _setter_from(monkeypatch))
    assert all(r["rank"] == 1 for r in ranks), ranks


# ---- decision confidence --------------------------------------------------------------------

def _r(rid, final, sim=1.0, art=None):
    rec = {"request_id": rid, "final_score": final, "similarity": sim, "solution": [{"fileName": "a"}]}
    if art is not None:
        rec["artifact_match_similarity"] = art
        rec["artifact_evidence_via"] = "live_artifact"   # a log the developer sent
    return rec


def test_decision_clear_likely_ambiguous():
    d = handlers._decision_confidence
    assert d([_r("a", 30, art=0.6), _r("b", 20, art=0.3)])["status"] == "clear"
    assert d([_r("a", 30, art=0.6), _r("b", 28, art=0.5)])["status"] == "likely"
    amb = d([_r("a", 30, art=0.50), _r("b", 29.8, art=0.505), _r("c", 10, art=0.1)])
    assert amb["status"] == "ambiguous" and amb["tied_request_ids"] == ["a", "b"]
    assert d([])["status"] == "none"


def test_close_scores_with_different_evidence_are_not_called_a_tie():
    # Scores within 5% only because both share the exact base of 18 - the logs differ clearly.
    out = handlers._decision_confidence([_r("a", 30, art=0.60), _r("b", 29, art=0.50)])
    assert out["status"] == "likely" and not out["ambiguous"]


# ---- report.html only (no live log): same error message, different stored logs ----------------

def _no_log_run(kind, setter):
    store = _Store(build_store(kind))
    _install(setter, store, MODES["new defaults"])
    rows = []
    for f in store.fixes.values():
        out = handlers._run_report_error_recommendation(**_live_query(f, kind, False))
        d = out.get("decision") or {}
        shown = [str(r.get("request_id")) for r in (out.get("recommendations") or [])]
        clues = {c["request_id"]: c["clue"] for c in (d.get("how_to_choose") or [])}
        cause_tokens = handlers._distinctive_token_set(f["cause"])
        rows.append({
            "rank1": bool(shown) and shown[0] == f["request_id"],
            "ambiguous": bool(d.get("ambiguous")),
            "named": f["request_id"] in clues
                     and bool(cause_tokens & handlers._distinctive_token_set(clues[f["request_id"]])),
            "analysis": str(out.get("llm_analysis") or ""),
        })
    return rows


def test_same_error_no_log_says_tie_and_names_every_fix_by_its_log_line(monkeypatch):
    """The developer sends only report.html; all 10 stored failures share its message. Nobody can
    rank the right one first - so every query must say it is a tie, and list the right fix with
    the log line that identifies it, in the analysis text the shipped extension shows."""
    _quiet()
    rows = _no_log_run("identical", _setter_from(monkeypatch))
    assert all(r["ambiguous"] for r in rows)
    assert all(r["named"] for r in rows)
    assert all("Find which of these lines your log contains" in r["analysis"] for r in rows)


def test_different_errors_no_log_rank_first_without_false_alarm(monkeypatch):
    _quiet()
    for kind in ("distinct", "similar"):
        rows = _no_log_run(kind, _setter_from(monkeypatch))
        assert all(r["rank1"] for r in rows), kind
        assert not any(r["ambiguous"] for r in rows), kind


def test_build_scripts_are_not_file_evidence():
    assert handlers._is_build_script_name("task4.processes.gradle.kts")
    assert handlers._is_build_script_name("D:\ws\build.gradle")
    assert not handlers._is_build_script_name("config.xml")
    assert not handlers._is_build_script_name("CanDriver.java")


def test_log_scores_from_the_error_text_alone_do_not_break_a_tie():
    # No live log: the stored logs were probed with the error text - not evidence about this failure.
    a, b = _r("a", 30, art=0.60), _r("b", 29.9, art=0.40)
    for rec in (a, b):
        rec["artifact_evidence_via"] = "error_text"
    assert handlers._decision_confidence([a, b])["status"] == "ambiguous"
