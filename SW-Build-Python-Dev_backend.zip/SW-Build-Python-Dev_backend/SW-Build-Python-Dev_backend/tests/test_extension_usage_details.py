"""The drill-down behind every Extension Usage card: Metric -> Group -> Project -> records.

What is pinned here:

  - every level is summed from the same rows as the card, so the summary equals the card and
    the groups add up to it, the projects to their group, the days to their project
  - only the days on which the chosen thing happened take part, and a project with no such day
    is not listed
  - the two build cards list individual builds (failed-builds only the failed ones); builds
    reported without a record are counted but not listed, and the gap is reported
  - a project sits in the same group here as on the screen above (one resolution rule)
  - a person on two machines is one active user at every level, and no key or id leaves
  - an unknown type is refused in the same envelope
  - a build report with a `build` object stores one build record; without one it is only counted
"""
import os
import sys
import types

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

os.environ.setdefault("AUTH_JWT_SECRET", "test-secret-for-kpi-tests")

_rows = []
_builds = []
_saved_builds = []
_fake_pd = types.ModuleType("src.utils.project_details")
_fake_pd.EXTUSAGE_PROFILE_SK = "PROFILE"
_fake_pd.EXTUSAGE_PK_PREFIX = "EXTUSAGE#"
_fake_pd.scan_kpi_rows = lambda budget_sec=20.0, page_size=500: {
    "usage": list(_rows), "builds": list(_builds), "feedback": [], "outcomes": [], "traces": [],
    "scanned": len(_rows), "partial": False, "seconds": 0.0}
_fake_pd.save_extension_usage = lambda **kw: True


def _save_build(**kw):
    _saved_builds.append(kw)
    return True


_fake_pd.save_extension_build = _save_build

# project_groups reads group definitions out of DynamoDB; stand in with one fixed rule.
_fake_pg = types.ModuleType("src.services.project_groups")
_fake_pg.DEFAULT_GROUP = "Other"
_fake_pg.build_group_map = lambda names: {
    n: ("HIP-26" if str(n).startswith("hip") else "Other") for n in names}

import pytest  # noqa: E402


@pytest.fixture(autouse=True)
def _stub_modules(monkeypatch):
    monkeypatch.setitem(sys.modules, "src.utils.project_details", _fake_pd)
    monkeypatch.setitem(sys.modules, "src.services.project_groups", _fake_pg)
    yield


from src.utils import ttl_cache  # noqa: E402
from src.services import extension_usage as eu  # noqa: E402

_TODAY = eu.datetime.now(eu.UTC).strftime("%Y-%m-%d")


def _reset(rows=None, builds=None):
    _rows[:] = rows or []
    _builds[:] = builds or []
    _saved_builds[:] = []
    ttl_cache.clear()


def _use(install, date=_TODAY, project="hip26", seen_builds=0, seen_failures=0, seen_issues=0,
         builds=0, uploads=0, recommended=0):
    return {"PK": f"EXTUSAGE#{install}", "SK": f"USE#{date}#{project}", "use_date": date,
            "project_name": project, "seen_builds": seen_builds, "seen_failures": seen_failures,
            "seen_issues": seen_issues, "builds": builds, "uploads": uploads, "recommended": recommended}


def _build(install, build_id, finished=f"{_TODAY}T10:00:00Z", project="hip26", failed=False,
           duration=120, task="assembleDebug"):
    return {"PK": f"EXTUSAGE#{install}", "SK": f"BUILD#{finished}#{build_id}", "build_id": build_id,
            "project_name": project, "build_status": "failed" if failed else "success",
            "started_at": "", "finished_at": finished, "duration_sec": duration, "task_name": task,
            "issues": 2 if failed else 0, "updated_date": finished}


def _profile(install, dev_key=None):
    row = {"PK": f"EXTUSAGE#{install}", "SK": "PROFILE", "first_seen": _TODAY, "last_seen": _TODAY}
    if dev_key:
        row["dev_key"] = dev_key
    return row


def _details(**kw):
    return eu.metric_details(**kw)


def _tree(**kw):
    """The group -> project -> day distribution and its totals.

    The response no longer carries this - the screen lists rows, and the tree repeated every
    counter at three levels. The counting rules are unchanged, so they are tested here, against
    the function the endpoint itself computes them with.
    """
    kw.setdefault("metric_type", "total-builds")
    data, summary, _window, _partial = eu.metric_breakdown(
        kw["metric_type"], kw.get("group", ""), kw.get("days"), kw.get("search", ""))
    return data, summary


def _groups(**kw):
    return _tree(**kw)[0]


def _project(groups, name):
    for g in groups:
        for p in g["projects"]:
            if p["projectName"] == name:
                return p
    raise AssertionError(f"project {name} not listed")


# ------------------------------------------------------------------ adds up to the card

def test_every_level_adds_up_to_the_card():
    _reset([_use("i1", seen_builds=3, seen_failures=1), _use("i2", seen_builds=2, seen_failures=2),
            _use("i1", project="other-prj", seen_builds=4, seen_failures=1)])
    payload, status = _details(metric_type="failed-builds", days=30)
    groups, summary = _tree(metric_type="failed-builds", days=30)
    assert status == 200 and payload["success"] is True
    assert payload["message"] == "User metric details fetched successfully"
    card = eu.compute_kpis(days=30)["data"]["summary"]["cards"]["failed_builds"]["value"]
    assert summary["failedBuilds"] == card == 4
    assert sum(g["failedBuilds"] for g in groups) == 4
    assert sum(p["failedBuilds"] for g in groups for p in g["projects"]) == 4
    assert sum(d["failedBuilds"] for g in groups for p in g["projects"] for d in p["days"]) == 4
    assert summary["groups"] == 2 and summary["projects"] == 2


def test_the_distribution_reads_group_then_project_with_their_counts():
    _reset([_use("i1", seen_builds=3), _use("i2", seen_builds=2),
            _use("i1", project="hip27", seen_builds=3), _use("i1", project="other-prj", seen_builds=13)])
    payload, _ = _details(metric_type="total-builds", days=30)
    groups, summary = _tree(metric_type="total-builds", days=30)
    assert [(g["groupName"], g["projectCount"], g["totalBuilds"]) for g in groups] == [
        ("HIP-26", 2, 8), ("Other", 1, 13)]
    assert [(p["projectName"], p["totalBuilds"]) for p in groups[0]["projects"]] == [
        ("hip26", 5), ("hip27", 3)]
    assert summary["totalBuilds"] == 21
    assert groups[0]["activeUsers"] == 2 and _project(groups, "hip26")["activeUsers"] == 2


def test_a_project_carries_its_days_newest_first():
    _reset([_use("i1", date="2026-09-20", seen_builds=1, seen_failures=1),
            _use("i1", date="2026-09-25", seen_builds=4, seen_failures=1)])
    payload, _ = _details(metric_type="total-builds", days=30)
    groups, summary = _tree(metric_type="total-builds", days=30)
    assert _project(groups, "hip26")["days"] == [
        {"date": "2026-09-25", "totalBuilds": 4, "failedBuilds": 1, "successfulBuilds": 3, "issuesCaptured": 0,
         "uploads": 0, "recommendationRequests": 0, "recommendationsAnswered": 0, "activeUsers": 1},
        {"date": "2026-09-20", "totalBuilds": 1, "failedBuilds": 1, "successfulBuilds": 0, "issuesCaptured": 0,
         "uploads": 0, "recommendationRequests": 0, "recommendationsAnswered": 0, "activeUsers": 1}]


def test_a_day_with_nothing_of_that_kind_is_not_listed_nor_a_project_with_no_such_day():
    _reset([_use("i1", seen_builds=3, seen_failures=0),
            _use("i1", date="2026-09-20", project="other-prj", seen_builds=2, seen_failures=1),
            _use("i1", date="2026-09-21", project="other-prj", seen_builds=2, seen_failures=0)])
    payload, _ = _details(metric_type="failed-builds", days=30)
    groups, summary = _tree(metric_type="failed-builds", days=30)
    assert [g["groupName"] for g in groups] == ["Other"]
    assert [d["date"] for d in _project(groups, "other-prj")["days"]] == ["2026-09-20"]


def test_successful_builds_are_the_builds_not_reported_failed():
    _reset([_use("i1", seen_builds=8, seen_failures=3)])
    payload, _ = _details(metric_type="total-builds", days=30)
    groups, summary = _tree(metric_type="total-builds", days=30)
    assert _project(groups, "hip26")["successfulBuilds"] == 5


# ------------------------------------------------------------------ every card

def test_each_card_uses_its_own_counter():
    # Stored names are historical (see _METRICS): `builds` is a fix upload, `uploads` a
    # recommendation request.
    _reset([_use("i1", seen_issues=23), _use("i1", project="other-prj", builds=2),
            _use("i2", project="hip27", uploads=40, recommended=30)])
    issues, _ = _details(metric_type="issues-captured", days=30)
    assert [(p["projectName"], p["issuesCaptured"])
            for g in _groups(metric_type="issues-captured", days=30)
            for p in g["projects"]] == [("hip26", 23)]
    uploads, _ = _details(metric_type="uploads", days=30)
    assert [(p["projectName"], p["uploads"])
            for g in _groups(metric_type="uploads", days=30)
            for p in g["projects"]] == [("other-prj", 2)]
    requests, _ = _details(metric_type="recommendation-requests", days=30)
    assert [(p["projectName"], p["recommendationRequests"], p["recommendationsAnswered"])
            for g in _groups(metric_type="recommendation-requests", days=30)
            for p in g["projects"]] == [("hip27", 40, 30)]
    # None of these cards drills into builds, so none reports a gap and none lists a build.
    for payload in (issues, uploads, requests):
        assert "note" not in payload
    for kind in ("issues-captured", "uploads", "recommendation-requests"):
        groups, summary = _tree(metric_type=kind, days=30)
        assert summary["buildsListed"] == 0
        assert all(p["builds"] == [] for g in groups for p in g["projects"])


def test_active_users_are_distributed_by_where_they_were_active():
    _reset([_profile("i1", dev_key="ext#a"), _profile("i2", dev_key="ext#a"),
            _use("i1", seen_builds=1), _use("i2", seen_builds=1), _use("i3", project="other-prj", uploads=1)])
    payload, _ = _details(metric_type="active-users", days=30)
    groups, summary = _tree(metric_type="active-users", days=30)
    card = eu.compute_kpis(days=30)["data"]["summary"]["cards"]["active_users"]["value"]
    assert summary["activeUsers"] == card == 2
    assert [(g["groupName"], g["activeUsers"]) for g in groups] == [("HIP-26", 1), ("Other", 1)]
    assert "ext#a" not in str(payload) and "EXTUSAGE#" not in str(payload)


# ------------------------------------------------------------------ the individual builds

def test_a_project_lists_its_builds_newest_first():
    _reset([_use("i1", seen_builds=2, seen_failures=1)],
           [_build("i1", "#1", finished=f"{_TODAY}T09:00:00Z"),
            _build("i1", "#2", finished=f"{_TODAY}T11:00:00Z", failed=True, duration=492)])
    payload, _ = _details(metric_type="total-builds", days=30)
    groups, summary = _tree(metric_type="total-builds", days=30)
    p = _project(groups, "hip26")
    assert [b["buildId"] for b in p["builds"]] == ["#2", "#1"]
    assert p["builds"][0] == {"buildId": "#2", "buildStatus": "failed", "startedAt": "",
                              "finishedAt": f"{_TODAY}T11:00:00Z", "durationSec": 492, "duration": "8m 12s",
                              "taskName": "assembleDebug", "issues": 2}
    assert p["buildsListed"] == 2 and groups[0]["buildsListed"] == 2
    assert summary["buildsListed"] == 2 and "note" not in payload


def test_failed_builds_lists_only_the_builds_that_failed():
    _reset([_use("i1", seen_builds=2, seen_failures=1)],
           [_build("i1", "#1"), _build("i1", "#2", failed=True)])
    payload, _ = _details(metric_type="failed-builds", days=30)
    groups, summary = _tree(metric_type="failed-builds", days=30)
    p = _project(groups, "hip26")
    assert [b["buildId"] for b in p["builds"]] == ["#2"]
    assert p["failedBuilds"] == 1 and p["buildsListed"] == 1


def test_builds_counted_before_records_existed_are_reported_as_a_gap():
    _reset([_use("i1", seen_builds=5, seen_failures=2)], [_build("i1", "#1"), _build("i1", "#2", failed=True)])
    total, _ = _details(metric_type="total-builds", days=30)
    _groups_, summary = _tree(metric_type="total-builds", days=30)
    assert summary["totalBuilds"] == 5 and summary["buildsListed"] == 2
    assert total["note"].startswith("3 of 5 builds were reported without a build record")
    failed, _ = _details(metric_type="failed-builds", days=30)
    assert failed["note"].startswith("1 of 2 builds")


def test_a_build_outside_the_window_or_another_project_is_not_listed():
    _reset([_use("i1", seen_builds=1), _use("i1", project="other-prj", seen_builds=1)],
           [_build("i1", "old", finished="2020-01-01T10:00:00Z"), _build("i1", "theirs", project="other-prj")])
    payload, _ = _details(metric_type="total-builds", days=30)
    groups, summary = _tree(metric_type="total-builds", days=30)
    assert _project(groups, "hip26")["builds"] == []
    assert [b["buildId"] for b in _project(groups, "other-prj")["builds"]] == ["theirs"]


def test_a_build_with_an_odd_finish_time_falls_back_to_when_its_record_arrived():
    row = _build("i1", "odd", finished="1727776800000")
    row["updated_date"] = f"{_TODAY}T12:00:00Z"
    _reset([_use("i1", seen_builds=1)], [row])
    payload, _ = _details(metric_type="total-builds", days=30)
    groups, summary = _tree(metric_type="total-builds", days=30)
    assert [b["buildId"] for b in _project(groups, "hip26")["builds"]] == ["odd"]


def test_duration_reads_as_minutes_and_seconds():
    assert eu._duration_text(492) == "8m 12s"
    assert eu._duration_text(45) == "45s"
    assert eu._duration_text(3725) == "1h 2m 5s"
    assert eu._duration_text(None) == ""


def test_a_build_report_with_a_record_stores_it_and_without_one_is_only_counted():
    _reset()
    eu.record_build_seen("i1", project_name="hip26", failed=True, issues=3,
                         build={"buildId": "#1024", "startedAt": "s", "finishedAt": "f",
                                "durationSec": 492, "taskName": "assembleDebug"})
    assert len(_saved_builds) == 1
    saved = _saved_builds[0]
    assert saved["build_id"] == "#1024" and saved["failed"] is True and saved["issues"] == 3
    assert saved["duration_sec"] == 492 and saved["task_name"] == "assembleDebug"
    eu.record_build_seen("i1", project_name="hip26", failed=False)
    eu.record_build_seen("i1", project_name="hip26", failed=False, build={"taskName": "no id"})
    assert len(_saved_builds) == 1


# ------------------------------------------------------------------ the table

ROW_KEYS = {"projectName", "groupName", "date", "count",
            "totalBuilds", "failedBuilds", "successfulBuilds",
            "buildId", "buildStatus", "buildDateTime", "duration"}


def test_every_card_returns_the_same_row_shape():
    """One shape, whichever card was clicked.

    Rows used to carry only the fields their own card needed, so switching from Total Builds to
    Uploads dropped three keys and added another. The screen could not hold one table and one
    column set against that. A column a card does not use is emptied, never removed.
    """
    _reset([_use("i1", date="2026-09-20", seen_builds=2, seen_failures=1, seen_issues=3,
                 builds=1, uploads=4, recommended=2)])
    shapes = {}
    for kind in ("total-builds", "failed-builds", "active-users",
                 "issues-captured", "uploads", "recommendation-requests"):
        payload, _ = _details(metric_type=kind, days=30)
        assert payload["data"], f"{kind} returned no rows"
        for row in payload["data"]:
            assert set(row) == ROW_KEYS, f"{kind} row has {sorted(set(row) ^ ROW_KEYS)}"
        shapes[kind] = tuple(sorted(payload["data"][0]))
    assert len(set(shapes.values())) == 1, "the shape still changes with the card"


def test_count_is_the_figure_of_the_card_that_was_clicked():
    """So the column the table sorts by is the same column whatever was drilled into."""
    _reset([_use("i1", date="2026-09-20", seen_builds=2, seen_failures=1, seen_issues=3,
                 builds=1, uploads=4, recommended=2)])
    got = {}
    for kind in ("total-builds", "failed-builds", "issues-captured",
                 "uploads", "recommendation-requests", "active-users"):
        payload, _ = _details(metric_type=kind, days=30)
        got[kind] = payload["data"][0]["count"]
    assert got == {"total-builds": 2, "failed-builds": 1, "issues-captured": 3,
                   "uploads": 1, "recommendation-requests": 4, "active-users": 1}


def test_a_day_row_carries_the_three_build_counts_and_empty_build_fields():
    _reset([_use("i1", date="2026-09-20", seen_builds=2, seen_failures=1)])
    row = _details(metric_type="total-builds", days=30)[0]["data"][0]
    assert row["projectName"] == "hip26" and row["groupName"] == "HIP-26"
    assert row["totalBuilds"] == 2 and row["failedBuilds"] == 1 and row["successfulBuilds"] == 1
    assert row["buildId"] == "" and row["buildStatus"] == "" and row["duration"] == ""


def test_a_build_row_describes_that_one_build():
    """Its counts are that build's own, so a page of build rows still sums correctly."""
    _reset([_use("i1", date="2026-09-25", project="other-prj", seen_builds=1)],
           [_build("i1", "#7", finished="2026-09-25T11:00:00Z", project="other-prj", duration=65)])
    row = next(r for r in _details(metric_type="total-builds", days=30)[0]["data"]
               if r["buildId"])
    assert set(row) == ROW_KEYS
    assert row["buildId"] == "#7" and row["buildStatus"] == "success"
    assert row["buildDateTime"] == "2026-09-25T11:00:00Z" and row["duration"] == "1m 5s"
    assert row["count"] == 1 and row["totalBuilds"] == 1
    assert row["failedBuilds"] == 0 and row["successfulBuilds"] == 1


def test_a_build_without_a_number_is_skipped_rather_than_shown_blank():
    """A build reported without a record cannot be listed as a build.

    The count on the card already includes it and `note` says in words how many there are, so a
    row with a blank or invented build number would add nothing and mislead.
    """
    _reset([_use("i1", date="2026-09-25", project="other-prj", seen_builds=2)],
           [_build("i1", "", finished="2026-09-25T11:00:00Z", project="other-prj", duration=10),
            _build("i1", "#9", finished="2026-09-25T12:00:00Z", project="other-prj", duration=20)])
    payload, _ = _details(metric_type="total-builds", days=30)
    ids = [r.get("buildId") for r in payload["data"] if "buildId" in r]
    assert ids == ["#9"], f"a build with no number was listed: {ids}"


def test_rows_follow_the_page():
    """One row per page, and the pages walk the list in order without repeating a row."""
    _reset([_use("i1", project=f"hip{n:02d}", seen_builds=1) for n in range(3)]
           + [_use("i1", project="other-prj", seen_builds=1)])
    seen = []
    for page in ("1", "2", "3", "4"):
        payload, _ = _details(metric_type="total-builds", days=30,
                              page_number=page, page_size="1")
        assert payload["pagination"]["totalRecords"] == 4
        assert payload["pagination"]["totalPages"] == 4
        assert len(payload["data"]) == 1
        seen.append(payload["data"][0]["projectName"])
    assert sorted(seen) == ["hip00", "hip01", "hip02", "other-prj"]


# ------------------------------------------------------------------ identity, envelope, paging

def test_one_person_on_two_machines_is_one_active_user_at_every_level():
    _reset([_profile("i1", dev_key="ext#a"), _profile("i2", dev_key="ext#a"),
            _use("i1", seen_builds=1), _use("i2", seen_builds=2)])
    payload, _ = _details(metric_type="total-builds", days=30)
    groups, summary = _tree(metric_type="total-builds", days=30)
    assert groups[0]["activeUsers"] == 1
    assert _project(groups, "hip26")["activeUsers"] == 1
    assert summary["activeUsers"] == 1
    assert "ext#a" not in str(payload) and "EXTUSAGE#" not in str(payload)


def test_no_rows_is_the_empty_envelope():
    _reset([_use("i1", seen_builds=3, seen_failures=0)])
    payload, _ = _details(metric_type="failed-builds", days=30)
    groups, summary = _tree(metric_type="failed-builds", days=30)
    assert groups == []
    assert payload["message"] == "No user metric details found"
    assert payload["pagination"] == {"pageNumber": 1, "pageSize": 10, "totalPages": 0, "totalRecords": 0}
    assert summary["groups"] == 0 and summary["failedBuilds"] == 0


def test_search_matches_project_or_group_name_case_insensitively():
    _reset([_use("i1", project="core-platform", seen_builds=1), _use("i1", project="hip26", seen_builds=1),
            _use("i1", project="ingest", seen_builds=1)])
    by_project, _ = _details(metric_type="total-builds", days=30, search="CORE")
    assert [r["projectName"] for r in by_project["data"]] == ["core-platform"]
    _g, summary = _tree(metric_type="total-builds", days=30, search="CORE")
    assert summary["projects"] == 1 and summary["totalBuilds"] == 1
    by_group, _ = _details(metric_type="total-builds", days=30, search="hip-26")
    assert [r["projectName"] for r in by_group["data"]] == ["hip26"]


def test_paging_is_by_row_so_the_count_matches_what_the_table_lists():
    """Paging by GROUP reported one record for a page of many rows.

    The table shows "1-8 of 11" and turns pages on that number, so a page has to be a page of
    rows. By group, a group holding forty rows and a group holding one both counted as a single
    record and the table could neither size itself nor page.
    """
    _reset([_use("i1", project=f"hip{n:02d}", seen_builds=1) for n in range(12)]
           + [_use("i1", project="other-prj", seen_builds=1)])
    payload, _ = _details(metric_type="total-builds", days=30, page_number="2", page_size="5")
    # Thirteen projects, each with a day row: thirteen records over three pages of five.
    assert payload["pagination"] == {"pageNumber": 2, "pageSize": 5,
                                     "totalPages": 3, "totalRecords": 13}
    assert len(payload["data"]) == 5
    first, _ = _details(metric_type="total-builds", days=30, page_number="1", page_size="5")
    last, _ = _details(metric_type="total-builds", days=30, page_number="3", page_size="5")
    assert len(first["data"]) == 5 and len(last["data"]) == 3
    # No row appears on two pages, and between them the pages hold every record.
    seen = [r["projectName"] for r in first["data"] + payload["data"] + last["data"]]
    assert len(seen) == 13 and len(set(seen)) == 13


def test_an_unknown_type_is_refused_in_the_same_envelope():
    _reset([_use("i1", seen_builds=1)])
    assert eu.METRIC_TYPES == ("active-users", "total-builds", "failed-builds", "issues-captured",
                               "uploads", "recommendation-requests")
    payload, status = _details(metric_type="something-else")
    assert status == 400 and payload["success"] is False
    assert payload["message"] == "Failed to fetch user metric details"
    assert payload["data"] == [] and payload["pagination"]["totalRecords"] == 0


def test_all_groups_means_no_group_filter():
    _reset([_use("i1", seen_builds=1)])
    payload, _ = _details(metric_type="total-builds", days=30, group="All Groups")
    assert payload["pagination"]["totalRecords"] == 1


def test_the_failure_envelope_has_the_pagination_block_the_screen_reads():
    assert eu.details_failure()["pagination"] == {"pageNumber": 1, "pageSize": 10, "totalPages": 0, "totalRecords": 0}
