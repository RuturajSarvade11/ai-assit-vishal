"""Azure's cosine @search.score maps to the Chroma squared-L2 distance the rest of the pipeline
reads (similarity = 1 - d/2). Microsoft documents the score as 1 / (1 + cosine_distance), i.e.
score = 1 / (2 - cos), range 0.333..1.0 - not (1 + cos)/2. The old mapping understated every
non-identical match (a 0.90 score, true cosine 0.889, read as similarity 0.80)."""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.azure_search.azure_collection import _score_to_l2sq  # noqa: E402


def _similarity(score):
    return 1.0 - _score_to_l2sq(score) / 2.0


@pytest.mark.parametrize("cos", [1.0, 0.95, 0.889, 0.75, 0.5, 0.0, -1.0])
def test_the_distance_inverts_the_documented_score_formula(cos):
    score = 1.0 / (2.0 - cos)
    assert _score_to_l2sq(score) == pytest.approx(2.0 * (1.0 - cos), abs=1e-5)
    assert _similarity(score) == pytest.approx(cos, abs=1e-5)


def test_identical_is_zero_and_opposite_is_four():
    assert _score_to_l2sq(1.0) == 0.0
    assert _score_to_l2sq(1.0 / 3.0) == pytest.approx(4.0, abs=1e-5)


def test_a_missing_score_is_as_far_as_possible_and_never_raises():
    assert _score_to_l2sq(None) == 4.0
    assert _score_to_l2sq(0) == 4.0
    assert _score_to_l2sq("not a number") == 4.0
