"""A developer's description must reach the recommendation panel.

REPORTED FROM PRODUCTION (07-Oct): a recommendation was generated and its description was not
displayed.

The save path writes it camelCase - project_details.update_final_build_resolution_description
sets payload["resolutionDescription"] - and the recommendation read only the snake_case spelling.
So the text was entered, stored, and then looked up under a name nothing writes. Always empty,
for every recommendation, silently.

The export path had already met this and carried fallbacks for both spellings, which is why the
description appeared in an exported report and not in the panel beside the fix.
"""
import io
import os
import re

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read(rel):
    return io.open(os.path.join(_ROOT, rel), encoding="utf-8-sig").read()


def test_the_recommendation_reads_the_key_the_save_path_writes():
    src = _read("src/services/handlers.py")
    block = src[src.index('"resolution_description": str('):][:400]
    assert "resolutionDescription" in block, (
        "the recommendation reads only snake_case while the save path writes camelCase - "
        "the description will be blank for every candidate"
    )


def test_the_older_spelling_still_works():
    """Rows written before the camelCase save path must not lose their text."""
    src = _read("src/services/handlers.py")
    block = src[src.index('"resolution_description": str('):][:400]
    assert '"resolution_description"' in block.replace('"resolution_description": str(', "", 1)


def test_the_save_path_is_still_the_one_this_assumes():
    """If the write moves to another spelling, this test is where that is noticed."""
    saved = _read("src/utils/project_details.py")
    assert re.search(r'payload\["resolutionDescription"\]\s*=', saved), (
        "the save path no longer writes resolutionDescription - check what the read must accept"
    )
