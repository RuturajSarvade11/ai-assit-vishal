"""One space decides, the other is recorded.

Either the adapter is applied or it is not. With the adapter ON the learned-space ranking IS the
pool and its distance is the one the pipeline scores; with it OFF the base ranking is. There is no
rank fusion in between any more - the earlier Reciprocal Rank Fusion kept positions, discarded the
similarity magnitudes, and reported the base distance for nearly every row.

What must always hold, whichever space decides: the trace can show, per candidate, the similarity
in BOTH spaces, and "not retrieved in that space" stays distinguishable from "scored low there".
"""
import os
import re
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# Pure dict arithmetic, but recommended.py opens Azure/Chroma at import time. The two functions
# are loaded from source so the test exercises the SHIPPING code without that chain.
_SRC = open(os.path.join(_ROOT, "src", "utils", "recommended.py"), encoding="utf-8").read()
_ns = {}
exec("from typing import Dict\n", _ns)
for name in ("_ranked", "_pool_from"):
    m = re.search(r"\ndef %s\(.*?\n(?=\ndef )" % name, _SRC, re.S)
    assert m, f"{name} not found - the pool builder was renamed or removed"
    exec(m.group(0), _ns)
_pool_from = _ns["_pool_from"]


def _result(ids, dists):
    return {"ids": [ids], "metadatas": [[{} for _ in ids]],
            "documents": [[f"doc-{i}" for i in ids]], "distances": [dists]}


_EMPTY = {"ids": [[]], "metadatas": [[]], "documents": [[]], "distances": [[]]}


def _meta(pool, vid):
    ids = pool["ids"][0]
    return pool["metadatas"][0][ids.index(vid)]


# ------------------------------------------------------------------ adapter ON: learned decides

def test_adapter_on_the_learned_order_is_the_pool_order():
    base = _result(["a", "b", "c"], [0.1, 0.2, 0.3])
    learned = _result(["c", "b", "a"], [0.05, 0.15, 0.25])
    pool = _pool_from(learned, base, "learned", top_k=3)
    assert pool["ids"][0] == ["c", "b", "a"]


def test_adapter_on_the_distance_the_pipeline_reads_is_the_learned_one():
    """The adapter reaches the final score through the
    similarity that earns match points, not through a rank."""
    pool = _pool_from(_result(["a"], [0.70]), _result(["a"], [0.50]), "learned", top_k=5)
    assert pool["distances"][0][0] == 0.70
    assert _meta(pool, "a")["adapter_distance_learned"] == 0.70
    assert _meta(pool, "a")["adapter_distance_base"] == 0.50
    assert _meta(pool, "a")["adapter_space"] == "learned"


def test_adapter_on_a_candidate_base_never_retrieved_has_no_base_numbers():
    pool = _pool_from(_result(["z"], [0.1]), _result(["a"], [0.4]), "learned", top_k=5)
    assert pool["ids"][0] == ["z"]
    assert _meta(pool, "z")["adapter_rank_learned"] == 1
    assert _meta(pool, "z")["adapter_rank_base"] is None
    assert _meta(pool, "z")["adapter_distance_base"] is None


# ------------------------------------------------------------------ adapter OFF: base decides

def test_adapter_off_the_base_order_is_the_pool_order_and_learned_is_only_recorded():
    base = _result(["a", "b", "c"], [0.1, 0.2, 0.3])
    learned = _result(["c", "b", "a"], [0.05, 0.15, 0.25])
    pool = _pool_from(base, learned, "base", top_k=3)
    assert pool["ids"][0] == ["a", "b", "c"]
    assert pool["distances"][0] == [0.1, 0.2, 0.3]
    assert _meta(pool, "a")["adapter_distance_learned"] == 0.25
    assert _meta(pool, "a")["adapter_rank_learned"] == 3
    assert _meta(pool, "a")["adapter_space"] == "base"


def test_adapter_off_a_learned_only_candidate_is_not_in_the_pool():
    """Off means off: what the adapter would have surfaced does not enter the pool."""
    pool = _pool_from(_result(["a"], [0.4]), _result(["z"], [0.1]), "base", top_k=5)
    assert pool["ids"][0] == ["a"]


def test_an_empty_other_space_leaves_every_other_number_none():
    base = _result(["a", "b"], [0.1, 0.2])
    pool = _pool_from(base, _EMPTY, "base", top_k=5)
    assert pool["ids"][0] == ["a", "b"]
    assert all(_meta(pool, v)["adapter_distance_learned"] is None for v in ["a", "b"])
    assert all(_meta(pool, v)["adapter_rank_learned"] is None for v in ["a", "b"])


# ------------------------------------------------------------------ shape and limits

def test_top_k_cuts_the_chosen_list():
    pool = _pool_from(_result(["a", "b", "c"], [0.1, 0.2, 0.3]), _EMPTY, "base", top_k=2)
    assert pool["ids"][0] == ["a", "b"]
    assert len(pool["metadatas"][0]) == len(pool["documents"][0]) == len(pool["distances"][0]) == 2


def test_missing_distances_do_not_break_the_pool():
    """Some stores answer without distances. The ranks still mean something."""
    base = {"ids": [["a"]], "metadatas": [[{}]], "documents": [["d"]], "distances": [[]]}
    pool = _pool_from(base, _result(["a"], [0.2]), "base", top_k=5)
    assert pool["distances"][0] == [None]
    assert _meta(pool, "a")["adapter_distance_base"] is None
    assert _meta(pool, "a")["adapter_distance_learned"] == 0.2


def test_existing_metadata_survives_the_annotation():
    base = {"ids": [["a"]], "metadatas": [[{"project_name": "p1"}]], "documents": [["d"]],
            "distances": [[0.3]]}
    pool = _pool_from(base, _EMPTY, "base", top_k=5)
    assert _meta(pool, "a")["project_name"] == "p1"


def test_no_rank_fusion_remains_in_the_retrieval_code():
    """The decision was 'no RRF between base and learned'. The LLM evidence stage has its own,
    separate fusion in handlers.py; this guards only the retrieval module."""
    assert "_rrf_fuse" not in _SRC
    assert "1.0 / (k + rank)" not in _SRC


# --------------------------------------------------------------- the similarity mapping

def _sim(dist):
    """The mapping handlers.py applies - identical to the base similarity's own formula."""
    if dist is None:
        return None
    return max(0.0, min(1.0, 1.0 - float(dist) / 2.0))


def test_both_similarities_use_the_same_formula_as_the_base_one():
    handlers_src = open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8").read()
    assert handlers_src.count("1.0 - float(dist) / 2.0") == 1, \
        "the adapter similarity no longer maps distance the way the base similarity does"
    assert "1.0 - raw_dist / 2.0" in handlers_src, "the base similarity mapping moved"


def test_a_closer_adapter_distance_reads_as_a_higher_similarity():
    assert _sim(0.70) < _sim(0.50)
    assert round(_sim(0.50), 3) == 0.75
    assert round(_sim(0.70), 3) == 0.65


def test_the_delta_is_only_defined_when_both_sides_exist():
    base, learned = _sim(0.50), _sim(0.30)
    assert round(learned - base, 4) == 0.1
    assert _sim(None) is None


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
