"""Same file: the name, and then the content.

The 6 points for "same file" compare names only, so an unrelated fix that
happened to touch a file of the same name earns exactly what the right fix earns. A file name
that merely appears on both sides is not a meaningful match.

The requirement: extra points when the fix's own changed line is actually present in the file
the developer has in front of them. With one condition - it must not make a recommendation take
minutes longer.

These tests pin three things: that it is genuinely off by default, that it separates the two fixes
the name check could not tell apart, and that it cannot be satisfied by a fragment that would match
anything.
"""
import os
import sys
import types

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

os.environ.setdefault("OPENAI_API_VERSION", "2024-02-01")
os.environ.setdefault("OAI_API_VERSION", "2024-02-01")
os.environ.setdefault("AWS_DEFAULT_REGION", "eu-central-1")

from src.services import handlers  # noqa: E402


# The failure: config.xml, running :TARGETS:master:task4, python 3.10.0.
CURRENT_FILE = """
  <Tools>
    <Tool name="python" version="3.10.0" path="c:/LegacyApp/python/3.10.0/python.exe">
    <Tool name="ctc_aurix" version="6.2r1p4">
  </Tools>
"""

RIGHT_FIX = {"task_name": ":TARGETS:master:task4", "solution": [
    {"fileName": "work/tools/config.xml",
     "changes": ['<Tool name="python" version="3.10.0" path="c:/LegacyApp/python/3.10.0/python.exe">']}]}

WRONG_FIX = {"task_name": ":TARGETS:master:task4", "solution": [
    {"fileName": "other/module/config.xml",
     "changes": ['<Compiler flag="-O2" target="tricore" optimise="size">']}]}

INSTANCES = [{"task_path": ":TARGETS:master:task4", "file_name": "config.xml",
              "config_tokens": []}]

CONTEXT = {"task_paths": [":TARGETS:master:task4"], "file_names": ["config.xml"],
           "tokens": [], "file_contents": [CURRENT_FILE]}


def _cfg(monkeypatch, content_weight):
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {
        "baseTaskWeight": 3.0, "baseFileWeight": 6.0, "baseTokenWeight": 4.0,
        "fileContentMatchWeight": content_weight})
    monkeypatch.setattr(handlers, "_recommended_hit_count", lambda payload: 0)


def _score(payload, **over):
    ctx = dict(CONTEXT)
    ctx.update(over)
    details = {}
    total = handlers._fix_context_score(fix_instances=INSTANCES, final_payload=payload,
                                        context=ctx, details=details)
    return total, details


# ------------------------------------------------------------------ off by default

def test_nothing_changes_until_it_is_switched_on(monkeypatch):
    """The standing rule is that shipped behaviour does not move underneath anyone. With the weight
    at its default of 0, the right and the wrong fix must still score identically - exactly as they
    do today."""
    _cfg(monkeypatch, 0.0)
    right, _ = _score(RIGHT_FIX)
    wrong, _ = _score(WRONG_FIX)
    assert right == wrong == 3.0 + 6.0


def test_the_default_really_is_zero(monkeypatch):
    """Read from configuration with a default, not from a constant. If the key is absent the
    feature is off."""
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {"baseFileWeight": 6.0})
    monkeypatch.setattr(handlers, "_recommended_hit_count", lambda payload: 0)
    _, details = _score(RIGHT_FIX)
    assert details["points"]["file_content"] == 0.0


# ------------------------------------------------------------------ what it separates

def test_it_separates_the_two_fixes_the_name_could_not(monkeypatch):
    """Both fixes changed a file called config.xml, so the name check gives both the same 6. Only
    one of them changed the line that is actually in the developer's file."""
    _cfg(monkeypatch, 8.0)
    right, right_details = _score(RIGHT_FIX)
    wrong, wrong_details = _score(WRONG_FIX)

    assert right_details["points"]["file"] == 6.0
    assert wrong_details["points"]["file"] == 6.0, "the name still matches for both"

    assert right_details["points"]["file_content"] == 8.0
    assert wrong_details["points"]["file_content"] == 0.0
    assert right - wrong == 8.0


def test_the_matched_line_is_named_so_it_can_be_checked(monkeypatch):
    """A score that cannot be traced to a line is another number to argue about. The breakdown
    page shows which line was found."""
    _cfg(monkeypatch, 8.0)
    _, details = _score(RIGHT_FIX)
    assert details["matched_file_lines"]
    assert "python" in details["matched_file_lines"][0]


def test_indentation_does_not_hide_a_match(monkeypatch):
    """The same line, differently indented, is the same line."""
    _cfg(monkeypatch, 8.0)
    squashed = CURRENT_FILE.replace("    ", "").replace("\n", " ")
    _, details = _score(RIGHT_FIX, file_contents=[squashed])
    assert details["points"]["file_content"] == 8.0


# ------------------------------------------------------------------ what it refuses

def test_a_fragment_that_would_match_anything_earns_nothing(monkeypatch):
    """A brace or a closing tag appears in every file. Awarding points for finding one would
    recreate the fault this was written to fix."""
    _cfg(monkeypatch, 8.0)
    trivial = {"solution": [{"fileName": "config.xml", "changes": ["}", "</Tools>", "  "]}]}
    _, details = _score(trivial)
    assert details["points"]["file_content"] == 0.0


def test_a_line_from_a_file_whose_name_did_not_match_is_ignored(monkeypatch):
    """A line found in some unrelated file is not evidence about this one."""
    _cfg(monkeypatch, 8.0)
    elsewhere = {"solution": [{"fileName": "build.gradle.kts",
                               "changes": ['<Tool name="python" version="3.10.0" '
                                           'path="c:/LegacyApp/python/3.10.0/python.exe">']}]}
    _, details = _score(elsewhere, file_names=["config.xml"])
    assert details["points"]["file_content"] == 0.0


def test_no_current_file_means_no_points_not_a_crash(monkeypatch):
    """Older extensions send no file content. Those candidates fall back to the name check, which
    is what they get today."""
    _cfg(monkeypatch, 8.0)
    total, details = _score(RIGHT_FIX, file_contents=[])
    assert details["points"]["file_content"] == 0.0
    assert total == 3.0 + 6.0


def test_content_points_need_the_name_to_match_first(monkeypatch):
    """The content check runs on files the name check already accepted. It is an addition to that
    step, not a way around it."""
    _cfg(monkeypatch, 8.0)
    total, details = _score(RIGHT_FIX, file_names=["something-else.xml"])
    assert details["points"]["file"] == 0.0
    assert details["points"]["file_content"] == 0.0


# ------------------------------------------------------------------ the cost

def test_it_reads_nothing_it_was_not_already_holding(monkeypatch):
    """The other condition attached to this request: a recommendation must not take minutes
    longer. The changed lines are on the payload and the current file arrived with the request, so
    nothing here downloads, embeds or calls out."""
    _cfg(monkeypatch, 8.0)
    for name in ("download_prediction_feature_json", "create_embedding"):
        if hasattr(handlers, name):
            monkeypatch.setattr(handlers, name,
                                lambda *a, **k: pytest.fail(f"{name} was called"))
    _score(RIGHT_FIX)
