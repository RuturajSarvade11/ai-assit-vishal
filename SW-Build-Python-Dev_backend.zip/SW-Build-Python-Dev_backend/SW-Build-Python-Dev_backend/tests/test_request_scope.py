"""The developer chooses the scope, per request.

THE DECISION (30-Sep review). Three scopes - project, customer, global - with **project** as the
default, and the choice belongs to the developer on each request rather than to an administrator.
Sankar's objection was not any particular default: it was that "this can only be changed by the
R&D team now".

What these tests pin, in the order they matter:

  - project is the default, so an unconfigured deployment searches one project
  - a requested scope beats the stored one, because that is the whole point of the change
  - global means NO project filter, and it has to be asked for explicitly
  - an unrecognised scope NARROWS; a typo must never be the reason evidence is searched
    estate-wide
  - "group" still means customer, so stored rows and old traces keep working
"""
import os
import sys
import types

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# Same single-import stubbing as the sibling scope tests: the rules are pure logic and the suite
# must not need AWS. Restored right after the import.
_fake_db = types.ModuleType("src.databases.database")
_fake_db.get_dynamodb = lambda *a, **k: None
_real_db = sys.modules.get("src.databases.database")
sys.modules["src.databases.database"] = _fake_db

_fake_cfg = types.ModuleType("src.configurations.config")
for _attr in ("DYNAMODB_TABLE_SUFFIX", "DYNAMODB_REGION", "DYNAMODB_ENDPOINT"):
    setattr(_fake_cfg, _attr, "")
_fake_pkg = types.ModuleType("src.configurations")
_fake_pkg.config = _fake_cfg
sys.modules.setdefault("src.configurations", _fake_pkg)
_real_cfg = sys.modules.get("src.configurations.config")
sys.modules["src.configurations.config"] = _fake_cfg
try:
    from src.services import project_groups as pg
finally:
    if _real_cfg is not None:
        sys.modules["src.configurations.config"] = _real_cfg
    else:
        sys.modules.pop("src.configurations.config", None)
        if sys.modules.get("src.configurations") is _fake_pkg:
            sys.modules.pop("src.configurations", None)
    if _real_db is not None:
        sys.modules["src.databases.database"] = _real_db
    else:
        sys.modules.pop("src.databases.database", None)


ALL = ["1ghio_000u0_000", "1ghio_111u0_000", "4p231_ptp4lite", "testgbe"]


@pytest.fixture(autouse=True)
def _grouped():
    """One defined group with two members, so customer scope has something to widen to."""
    pg.list_group_defs = lambda: [{"group_name": "HIP26", "project_pattern": "1GHIO*"}]
    pg.get_overrides = lambda: {}
    pg._scope_cache.clear()


# ---------------------------------------------------------------- normalize_scope
def test_the_default_is_project():
    """An unconfigured deployment must search one project, not a customer."""
    assert pg.normalize_scope("") == pg.SCOPE_PROJECT
    assert pg.normalize_scope(None) == pg.SCOPE_PROJECT


def test_all_three_scopes_are_accepted():
    for value in ("project", "customer", "global", "  GLOBAL  ", "Customer"):
        assert pg.normalize_scope(value) in pg.VALID_SCOPES


def test_group_still_means_customer():
    """Stored configuration rows and older traces say "group". They must keep working."""
    assert pg.normalize_scope("group") == pg.SCOPE_CUSTOMER


def test_an_unrecognised_scope_narrows_rather_than_widens():
    """A typo must never be the reason a project's evidence is searched estate-wide."""
    for junk in ("globl", "everything", "all", "customer-wide", "'; drop table"):
        assert pg.normalize_scope(junk) == pg.SCOPE_PROJECT


# ---------------------------------------------------------------- resolve_scope_projects
def test_requesting_project_scope_stays_with_the_one_project():
    members, mode = pg.resolve_scope_projects("1ghio_000u0_000", ALL, requested_scope="project")
    assert mode == pg.SCOPE_PROJECT
    assert members == ["1ghio_000u0_000"]


def test_requesting_customer_scope_widens_to_the_siblings():
    members, mode = pg.resolve_scope_projects("1ghio_000u0_000", ALL, requested_scope="customer")
    assert mode == pg.SCOPE_CUSTOMER
    assert members == ["1ghio_000u0_000", "1ghio_111u0_000"]


def test_requesting_global_resolves_to_no_members():
    """Global is the ABSENCE of a filter, not a wider list of projects to filter on."""
    members, mode = pg.resolve_scope_projects("1ghio_000u0_000", ALL, requested_scope="global")
    assert mode == pg.SCOPE_GLOBAL
    assert members == []


def test_asking_for_more_than_exists_still_narrows():
    """A project with no customer cannot be widened into one by asking."""
    members, mode = pg.resolve_scope_projects("testgbe", ALL, requested_scope="customer")
    assert mode == pg.SCOPE_PROJECT
    assert members == ["testgbe"]


# ---------------------------------------------------------------- scope_where
def test_global_emits_no_project_filter():
    assert pg.scope_where("1ghio_000u0_000", members=[], mode=pg.SCOPE_GLOBAL) is None


def test_global_keeps_any_other_filter_it_was_given():
    extra = {"task_path": ":TARGETS:HIP26:aramis"}
    assert pg.scope_where("1ghio_000u0_000", extra=extra, members=[], mode=pg.SCOPE_GLOBAL) == extra


def test_an_empty_member_list_alone_does_NOT_mean_global():
    """The failure this prevents: a lookup that resolved nothing silently searching everything.

    "nothing resolved" and "deliberately unfiltered" arrive as the same empty list, so global has
    to be asked for by mode. Without this, a failed resolution would widen instead of narrow.
    """
    where = pg.scope_where("1ghio_000u0_000", members=[])
    assert where == {"project_name": "1ghio_000u0_000"}


def test_project_scope_emits_the_same_filter_as_before():
    """A caller that is not widening must emit a byte-identical query."""
    assert pg.scope_where("testgbe", members=["testgbe"]) == {"project_name": "testgbe"}


def test_customer_scope_emits_an_in_filter():
    where = pg.scope_where("1ghio_000u0_000", members=["1ghio_000u0_000", "1ghio_111u0_000"])
    assert where == {"project_name": {"$in": ["1ghio_000u0_000", "1ghio_111u0_000"]}}
