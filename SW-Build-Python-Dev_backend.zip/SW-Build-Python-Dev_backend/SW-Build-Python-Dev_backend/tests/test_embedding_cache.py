"""Resumable embedding cache.

Training on Azure has to re-embed the whole corpus, and the previous one-shot pass lost the entire
run to a single rate limit - the first dev audit died after 264 seconds having produced nothing,
and every retry restarted from zero.

The property that fixes that is narrow and worth pinning: work already paid for must survive a
failure. These tests use a fake embedder so they never touch the network, and they assert the
things that would silently reintroduce the original bug - a batch not being saved before the next
call, a resumed run re-embedding what it already has, or the cache returning vectors in the wrong
order for repeated documents.
"""
import os
import shutil
import sys
import tempfile
import types

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

_tmp = tempfile.mkdtemp(prefix="embedcache")

_fake_cfg = types.ModuleType("src.configurations.config")
_fake_cfg.FEEDBACK_ADAPTER_PATH = os.path.join(_tmp, "adapter_W")
_fake_cfg.EMBEDDING_MODEL = "test-embed-model"
_fake_cfg.APP_ENV = "test"
_fake_pkg = types.ModuleType("src.configurations")
_fake_pkg.config = _fake_cfg
sys.modules.setdefault("src.configurations", _fake_pkg)

# Scoped to this import and no further. A fake left in sys.modules is inherited by every test
# file collected afterwards, and a config carrying three settings breaks modules that read a
# fourth - which showed up as three suites failing together while each passed on its own.
_real_cfg = sys.modules.get("src.configurations.config")
sys.modules["src.configurations.config"] = _fake_cfg
try:
    from src.utils import embedding_cache as ec  # noqa: E402
finally:
    if _real_cfg is not None:
        sys.modules["src.configurations.config"] = _real_cfg
    else:
        sys.modules.pop("src.configurations.config", None)
        sys.modules.pop("src.configurations", None)

# Pin the reference the module under test actually reads.
#
# The sys.modules swap above only works when embedding_cache is imported FRESH here. Any earlier
# test file that imported src.configurations leaves the real package in sys.modules, the
# setdefault above then installs nothing, and `from src.configurations import config` resolves
# through the real package attribute to the real config - whose EMBEDDING_MODEL is unset, so
# _cache_path() fell back to a literal "model" and two cache paths that must differ came out
# identical. Binding ec.config directly does not care what order the suite ran in.
ec.config = _fake_cfg

# The fake embedder records every text it is asked for, so a test can prove what was NOT re-sent.
CALLS = []


class _Boom(Exception):
    pass


SIZES = []          # the batch size of every call the embedder was asked to make


def _install(fail_after=None, max_batch=None):
    """Replace the real client with a counter.

    fail_after=N  raises once N texts have been served (a quota that runs out mid-run).
    max_batch=N   raises for ANY call larger than N (a per-request token limit - the dev case,
                  where the very first batch of 64 failed and nothing was embedded).
    """
    CALLS.clear()
    SIZES.clear()
    served = {"n": 0}

    def _batch(texts, *a, **k):
        SIZES.append(len(texts))
        if max_batch is not None and len(texts) > max_batch:
            raise _Boom("request too large")
        if fail_after is not None and served["n"] + len(texts) > fail_after:
            raise _Boom("rate limited")
        served["n"] += len(texts)
        CALLS.extend(texts)
        # A deterministic 3-dim vector so order can be checked.
        return [[float(len(t)), float(sum(bytearray(t.encode()[:1])) if t else 0.0), 1.0]
                for t in texts]

    mod = types.ModuleType("src.utils.oai_client")
    mod.create_embeddings_batch = _batch
    sys.modules["src.utils.oai_client"] = mod


def _reset_cache():
    """Remove the cache the module will ACTUALLY use, not the one in a fixed directory.

    The path is derived from config.FEEDBACK_ADAPTER_PATH at call time, and another test file
    moves that. Sweeping a hard-coded directory then cleared nothing, the previous test's vectors
    were still on disk, and the embed call under test was served from cache - so the recorded
    calls were empty and these two tests failed in the full suite while passing alone.
    """
    try:
        actual = ec._cache_path()
        if os.path.exists(actual):
            os.remove(actual)
    except Exception:
        pass
    for d in {_tmp, os.path.dirname(ec._cache_path()) or "."}:
        try:
            for name in os.listdir(d):
                if name.startswith("embed_cache"):
                    os.remove(os.path.join(d, name))
        except OSError:
            pass


def test_embeds_everything_once_and_keeps_order():
    _reset_cache(); _install(); ec.BATCH = 2
    docs = ["alpha", "beta", "gamma"]
    out = ec.embed_documents(docs)
    assert len(out) == 3
    assert out[0][0] == 5.0 and out[1][0] == 4.0 and out[2][0] == 5.0
    assert sorted(CALLS) == ["alpha", "beta", "gamma"]


def test_second_run_embeds_nothing():
    """The whole point: a rerun over an unchanged corpus must be free."""
    _reset_cache(); _install(); ec.BATCH = 2
    ec.embed_documents(["alpha", "beta", "gamma"])
    _install()                                  # clears CALLS, cache file stays
    out = ec.embed_documents(["alpha", "beta", "gamma"])
    assert CALLS == [], f"re-embedded {CALLS} despite a warm cache"
    assert len(out) == 3


def test_progress_survives_a_failure_and_the_rerun_resumes():
    """The original bug. A failure part-way must keep the completed batches, and the next run must
    ask only for what is still missing."""
    _reset_cache(); _install(fail_after=4); ec.BATCH = 2
    docs = ["a1", "b2", "c3", "d4", "e5", "f6"]
    try:
        ec.embed_documents(docs)
        raise AssertionError("expected the fake rate limit to raise")
    except _Boom:
        pass
    embedded_before = list(CALLS)
    assert len(embedded_before) == 4, embedded_before

    _install()                                  # the limit clears; cache still on disk
    out = ec.embed_documents(docs)
    assert len(out) == 6
    # Only the four that never succeeded... i.e. the remaining two.
    assert sorted(CALLS) == ["e5", "f6"], f"resume re-embedded too much: {CALLS}"


def test_batch_shrinks_until_the_request_fits():
    """The dev failure exactly: the FIRST batch is too large, so a fixed size makes no progress at
    all - 0 of 627 documents embedded. Halving must converge on a size the deployment accepts."""
    _reset_cache(); _install(max_batch=4); ec.BATCH = 16
    docs = [f"doc{i}" for i in range(10)]
    out = ec.embed_documents(docs)
    assert len(out) == 10
    assert sorted(CALLS) == sorted(docs), "every document must end up embedded"
    # The opening slice is min(BATCH, corpus size) - 10 docs here, not the configured 16.
    assert SIZES[0] == len(docs), "should open with the configured size, capped by the corpus"
    assert max(SIZES[1:]) < SIZES[0], "must shrink after the first failure"
    assert any(s <= 4 for s in SIZES), "must reach a size the limit accepts"


def test_shrink_stops_and_saves_when_even_one_document_fails():
    """If a single document cannot be embedded, that is not a batching problem - stop, keep the
    progress, and say so rather than looping forever."""
    _reset_cache(); _install(max_batch=0); ec.BATCH = 4
    try:
        ec.embed_documents(["a", "b"])
        raise AssertionError("expected a raise once batch=1 still fails")
    except _Boom:
        pass
    assert min(SIZES) == 1, "should have shrunk all the way to 1 before giving up"


def test_shrunk_size_is_kept_for_the_rest_of_the_run():
    """After discovering the working size, it must not climb straight back to a size already
    known to fail - that would re-pay the timeout on every batch."""
    _reset_cache(); _install(max_batch=2); ec.BATCH = 8
    ec.embed_documents([f"d{i}" for i in range(8)])
    after_first_success = SIZES[SIZES.index(2):]
    assert all(s <= 2 for s in after_first_success), f"batch size grew back: {SIZES}"


def test_duplicate_documents_are_embedded_once_but_returned_for_each():
    _reset_cache(); _install(); ec.BATCH = 8
    out = ec.embed_documents(["same", "same", "other", "same"])
    assert len(out) == 4
    assert out[0] == out[1] == out[3]
    assert sorted(CALLS) == ["other", "same"], f"duplicate work: {CALLS}"


def test_empty_input_makes_no_calls():
    _reset_cache(); _install()
    assert ec.embed_documents([]) == []
    assert CALLS == []


def test_a_corrupt_cache_costs_time_not_correctness():
    _reset_cache(); _install(); ec.BATCH = 4
    ec.embed_documents(["alpha", "beta"])
    with open(ec._cache_path(), "wb") as fh:
        fh.write(b"not an npz file")
    _install()
    out = ec.embed_documents(["alpha", "beta"])
    assert len(out) == 2
    assert sorted(CALLS) == ["alpha", "beta"], "should re-embed rather than fail"


def test_changing_the_model_does_not_mix_vector_spaces():
    """Vectors from two embedding models must never share a cache - the path carries the model."""
    _reset_cache(); _install(); ec.BATCH = 4
    ec.embed_documents(["alpha"])
    first = ec._cache_path()
    _fake_cfg.EMBEDDING_MODEL = "a-different-model"
    second = ec._cache_path()
    _fake_cfg.EMBEDDING_MODEL = "test-embed-model"
    assert first != second


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    try:
        for name, fn in sorted(globals().items()):
            if not name.startswith("test_") or not callable(fn):
                continue
            try:
                fn()
                passed += 1
                print(f"  PASS  {name}")
            except Exception:
                failed += 1
                print(f"  FAIL  {name}")
                traceback.print_exc()
        print(f"\n{passed} passed, {failed} failed")
    finally:
        shutil.rmtree(_tmp, ignore_errors=True)
    sys.exit(1 if failed else 0)
