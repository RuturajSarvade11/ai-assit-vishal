"""Confidence is the similarity that earned the match points, and the threshold gates it.

Asked for directly (09-Oct): a semantic match could never reach 100% confidence. The old
confidence was final_score / 30, and because support may never exceed evidence a semantic
candidate's final score tops out at 2 x 12 x cosine = 24 - confidence 0.80 at a perfect cosine,
0.40 x cosine with no support. The dashboard's "minimum similarity 70%" therefore hid every
semantic match below cosine 0.875 while claiming to be about similarity.

Now:  exact signature -> 1.0;  blended evidence -> evidence_similarity;  otherwise the error
cosine;  nothing compared -> no confidence, and a switched-on threshold refuses it.
minSimilarityPercent / 100 is compared against THAT number. The final score still orders.
No scoring literal is written twice: the fallbacks in handlers read SCORING_DEFAULTS.
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.services import handlers  # noqa: E402
from src.services import recommendation_config as rc  # noqa: E402


@pytest.fixture
def cfg(monkeypatch):
    live = {}
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: live)
    monkeypatch.setattr(handlers.config, "RECOMMENDATION_MIN_FINAL_SCORE", 0.0, raising=False)
    return live


def _rec(match_type="semantic", similarity=None, evidence=None, final=10.0, solution=True):
    rec = {"match_type": match_type, "match_score": 6.0, "context_score": final - 6.0,
           "final_score": final, "solution": [{"filePath": "a", "changes": ["x"]}] if solution else []}
    if similarity is not None:
        rec["similarity"] = similarity
    if evidence is not None:
        rec["evidence_similarity"] = evidence
    return rec


# ------------------------------------------------------------------ what confidence IS

def test_an_exact_signature_is_fully_confident(cfg):
    out = handlers._evaluate_recommendation_strength(_rec("exact", similarity=1.0, final=36.0))
    assert out["confidence_score"] == 1.0 and out["confidence_source"] == "exact_signature"


def test_a_semantic_candidate_reports_its_cosine_whatever_its_final_score(cfg):
    low_support = handlers._evaluate_recommendation_strength(_rec(similarity=0.93, final=11.16))
    full_support = handlers._evaluate_recommendation_strength(_rec(similarity=0.93, final=22.32))
    assert low_support["confidence_score"] == full_support["confidence_score"] == 0.93
    assert low_support["confidence_source"] == "error_similarity"


def test_a_perfect_semantic_match_reaches_one(cfg):
    out = handlers._evaluate_recommendation_strength(_rec(similarity=1.0, final=24.0))
    assert out["confidence_score"] == 1.0


def test_the_evidence_blend_wins_over_the_bare_error_cosine_when_present(cfg):
    out = handlers._evaluate_recommendation_strength(_rec(similarity=0.9, evidence=0.7))
    assert out["confidence_score"] == 0.7 and out["confidence_source"] == "evidence_similarity"


def test_nothing_compared_means_no_confidence(cfg):
    out = handlers._evaluate_recommendation_strength(_rec("task"))
    assert out["confidence_score"] == 0.0 and out["confidence_source"] == "unavailable"
    assert out["match_status"] == "strong"  # the gate is off: shown, honestly labelled


def test_the_abnormal_case_is_named_on_the_confidence():
    """A ledger row with no stored error text has a blank similarity and the reason travels with
    it, so the trace can say 'nothing to compare' instead of a bare 'unavailable'."""
    rec = _rec("task")
    rec["similarity_source"] = "no_error_text"
    assert handlers._recommendation_confidence(rec) == (None, "no_error_text")


def test_a_computed_task_recall_cosine_is_a_plain_similarity(cfg):
    """It is the same measure as a vector-search row's, so it reads as one: a number, source
    empty, confidence equal to it."""
    rec = _rec("task", similarity=0.84)
    rec["similarity_source"] = ""
    out = handlers._evaluate_recommendation_strength(rec)
    assert out["confidence_score"] == 0.84 and out["confidence_source"] == "error_similarity"


def test_no_solution_is_never_confident(cfg):
    out = handlers._evaluate_recommendation_strength(_rec(similarity=0.99, solution=False))
    assert out == {"match_status": "none", "confidence_score": 0.0,
                   "confidence_source": "no_solution", "source": "contextual"}


# ------------------------------------------------------------------ the threshold gates it

def test_seventy_percent_means_seventy_percent_similar(cfg):
    cfg["minSimilarityPercent"] = 70
    assert handlers._evaluate_recommendation_strength(_rec(similarity=0.71, final=8.5))["match_status"] == "strong"
    assert handlers._evaluate_recommendation_strength(_rec(similarity=0.69, final=30.0))["match_status"] == "below_threshold"


def test_an_exact_signature_always_clears_the_threshold(cfg):
    cfg["minSimilarityPercent"] = 99
    assert handlers._evaluate_recommendation_strength(_rec("exact", final=18.0))["match_status"] == "strong"


def test_a_switched_on_threshold_refuses_a_candidate_with_no_confidence(cfg):
    cfg["minSimilarityPercent"] = 10
    assert handlers._evaluate_recommendation_strength(_rec("task"))["match_status"] == "below_threshold"


def test_the_error_cosine_floor_still_applies_to_the_raw_error_text(cfg):
    cfg["minSemanticSimilarity"] = 0.8
    out = handlers._evaluate_recommendation_strength(_rec(similarity=0.75, evidence=0.9))
    assert out["match_status"] == "below_threshold"


def test_the_env_final_score_floor_is_separate_and_still_honoured(cfg, monkeypatch):
    monkeypatch.setattr(handlers.config, "RECOMMENDATION_MIN_FINAL_SCORE", 12.0, raising=False)
    assert handlers._evaluate_recommendation_strength(_rec(similarity=0.9, final=11.0))["match_status"] == "below_threshold"
    assert handlers._evaluate_recommendation_strength(_rec(similarity=0.9, final=12.0))["match_status"] == "strong"


# ------------------------------------------------------------------ artifacts: present is never worse than absent

def test_agreeing_artifacts_leave_the_error_cosine_alone():
    """Contrast off: the logs agree too closely to say anything for or against a candidate, so a
    weak absolute artifact figure (0.5 - the boilerplate level of any log) must NOT drag the
    confidence below a rival that has no artifacts at all."""
    combined, rule = handlers._blend_evidence(0.9, True, 0.5, None, False, 0.5)
    assert combined == 0.9 and rule.startswith("error cosine")


def test_the_best_log_raises_and_a_contradicted_log_lowers_relative_to_rivals():
    best, _ = handlers._blend_evidence(0.9, True, 0.8, 1.0, True, 0.5)
    worst, _ = handlers._blend_evidence(0.9, True, 0.3, 0.0, True, 0.5)
    assert best == pytest.approx(0.95) and worst == pytest.approx(0.45)
    assert best > 0.9 > worst  # the no-artifact rival at 0.9 sits between them


def test_the_share_not_the_absolute_figure_is_what_blends():
    with_share, _ = handlers._blend_evidence(0.9, True, 0.55, 1.0, True, 0.5)
    assert with_share == pytest.approx(0.95)  # 0.55 absolute, but the best in the pool


def test_task_recall_without_error_text_scores_on_the_artifact_alone():
    assert handlers._blend_evidence(None, False, 0.6, 1.0, True, 0.5)[0] == 1.0
    assert handlers._blend_evidence(None, False, 0.6, None, False, 0.5)[0] == 0.6


def test_the_blend_weight_is_clamped():
    assert handlers._blend_evidence(0.9, True, 0.0, 0.0, True, 7)[0] == 0.0
    assert handlers._blend_evidence(0.9, True, 0.0, 0.0, True, -1)[0] == 0.9


def test_the_trace_page_replays_the_same_blend_as_the_ranking(cfg):
    """_adapter_score_chain re-derives match points for the adapter comparison. It carried its
    own copy of the old absolute blend; it must read the stored contrast share and call the
    one blend the ranking used."""
    def _cand(share):
        return {"match_type": "semantic", "artifact_match_similarity": "0.5",
                "similarity_source": "", "similarity_components": {"contrast_share": share}}
    agreeing = handlers._adapter_score_chain(_cand(""), 0.9, 0.9, 0.0)
    assert agreeing["without"]["combined_evidence"] == 0.9       # contrast off: cosine stands
    best = handlers._adapter_score_chain(_cand("1.0"), 0.9, 0.9, 0.0)
    assert best["without"]["combined_evidence"] == pytest.approx(0.95)
    worst = handlers._adapter_score_chain(_cand("0.0"), 0.9, 0.9, 0.0)
    assert worst["without"]["combined_evidence"] == pytest.approx(0.45)


# ------------------------------------------------------------------ no scoring literal twice

def test_the_match_bases_come_from_the_config_and_fall_back_to_the_shared_defaults(cfg):
    assert handlers._match_type_score("exact") == rc.SCORING_DEFAULTS["exactMatchBase"]
    assert handlers._match_type_score("semantic") == rc.SCORING_DEFAULTS["semanticMatchBase"]
    assert handlers._match_type_score("task") == rc.SCORING_DEFAULTS["semanticMatchBase"]
    cfg["exactMatchBase"] = 20
    cfg["semanticMatchBase"] = 15
    assert handlers._match_type_score("exact") == 20.0
    assert handlers._match_type_score("semantic") == 15.0


def test_an_unreadable_config_scores_exactly_like_the_default_one(monkeypatch):
    def _boom():
        raise RuntimeError("table unreachable")
    monkeypatch.setattr(handlers, "_rc_get_config_cached", _boom)
    for key in ("exactMatchBase", "semanticMatchBase", "baseTaskWeight", "historyWeightCeiling"):
        assert handlers._rc_value(key) == rc.SCORING_DEFAULTS[key]


def test_artifacts_are_used_whenever_present(monkeypatch):
    """Asked for directly (09-Oct): if artifacts are present, use them. The lift shipped at 0,
    which switched the whole artifact-evidence path off; the default is now the semantic base,
    and an unreadable config falls back to the same value - never to 0."""
    assert rc.SCORING_DEFAULTS["artifactMatchWeight"] > 0
    monkeypatch.setattr(rc, "_table", lambda: (_ for _ in ()).throw(RuntimeError("no table")))
    monkeypatch.setattr(rc._pc, "_ensure_table", lambda: None)
    monkeypatch.setattr(rc, "_cache", {"data": None, "ts": 0.0})
    assert rc.get_config(force=True)["artifactMatchWeight"] == rc.SCORING_DEFAULTS["artifactMatchWeight"]
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {})
    assert handlers._rc_value("artifactMatchWeight", hi=60.0) == rc.SCORING_DEFAULTS["artifactMatchWeight"]
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {"artifactMatchWeight": 0})
    assert handlers._rc_value("artifactMatchWeight", hi=60.0) == 0.0  # an explicit 0 still switches it off


def test_get_config_fills_the_same_defaults(monkeypatch):
    monkeypatch.setattr(rc, "_table", lambda: (_ for _ in ()).throw(RuntimeError("no table")))
    monkeypatch.setattr(rc._pc, "_ensure_table", lambda: None)
    monkeypatch.setattr(rc, "_cache", {"data": None, "ts": 0.0})
    data = rc.get_config(force=True)
    for key, value in rc.SCORING_DEFAULTS.items():
        assert data[key] == value, key


def test_the_config_route_accepts_the_exact_base(monkeypatch):
    monkeypatch.setattr(rc, "_table", lambda: _FakeTable())
    monkeypatch.setattr(rc._pc, "_ensure_table", lambda: None)
    monkeypatch.setattr(rc, "_cache", {"data": None, "ts": 0.0})
    rc.set_values({"exactMatchBase": 999}, updated_by="t")
    assert float(_FakeTable.stored["exactMatchBase"]) == 30.0  # clamped to the ceiling


class _FakeTable:
    stored: dict = {}

    def get_item(self, Key):
        return {"Item": dict(self.stored)}

    def put_item(self, Item):
        _FakeTable.stored = dict(Item)
