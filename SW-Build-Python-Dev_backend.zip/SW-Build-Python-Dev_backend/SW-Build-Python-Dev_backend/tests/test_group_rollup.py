"""Dashboard chart rollup to project GROUP.

The chart shows project groups instead of each and every project.

The rollup runs on the SERVER for a reason worth pinning: the dashboard loads only the first few
projects of each group for its cards, so the browser never holds a complete project -> group map.
A client-side rollup would file every project past that cutoff into "Other" and nobody would
notice, because "Other" is a legitimate bucket that is supposed to have projects in it.

These tests cover the arithmetic, the ordering, and the two ways the rollup could quietly lie:
losing a project's errors entirely, or inventing a group that was never configured.
"""
import os
import sys
import types

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# Same single-import stub as test_scope_resolution: the rollup is pure logic, so the test stays
# free of AWS, Azure and any network.
_fake_db = types.ModuleType("src.databases.database")
_fake_db.get_dynamodb = lambda *a, **k: None
_real_db = sys.modules.get("src.databases.database")
sys.modules["src.databases.database"] = _fake_db

_fake_cfg = types.ModuleType("src.configurations.config")
for _attr in ("DYNAMODB_TABLE_SUFFIX", "DYNAMODB_REGION", "DYNAMODB_ENDPOINT"):
    setattr(_fake_cfg, _attr, "")
_fake_pkg = types.ModuleType("src.configurations")
_fake_pkg.config = _fake_cfg
sys.modules.setdefault("src.configurations", _fake_pkg)

# Scoped to this one import, then put back. A stub left in sys.modules is inherited by every
# test file collected afterwards, so a config carrying three settings silently became THE config
# for suites that read a fourth - each of them passing alone and failing together.
_real_cfg = sys.modules.get("src.configurations.config")
sys.modules["src.configurations.config"] = _fake_cfg
try:
    from src.services import project_groups as pg  # noqa: E402
finally:
    if _real_cfg is not None:
        sys.modules["src.configurations.config"] = _real_cfg
    else:
        sys.modules.pop("src.configurations.config", None)
        if sys.modules.get("src.configurations") is _fake_pkg:
            sys.modules.pop("src.configurations", None)
    if _real_db is not None:
        sys.modules["src.databases.database"] = _real_db
    else:
        sys.modules.pop("src.databases.database", None)


def _rows(*triples):
    return [{"projectName": n, "errorCount": e, "recommendedCount": r} for n, e, r in triples]


def test_sums_projects_into_their_group():
    rows = _rows(("a", 10, 1), ("b", 5, 2), ("c", 3, 3))
    out = pg.rollup_by_group(rows, group_map={"a": "HIP26", "b": "HIP26", "c": "TD5"})
    by_name = {d["groupName"]: d for d in out}
    assert by_name["HIP26"]["errorCount"] == 15
    assert by_name["HIP26"]["recommendedCount"] == 3
    assert by_name["HIP26"]["projectCount"] == 2
    assert by_name["TD5"]["errorCount"] == 3


def test_no_errors_are_lost_in_the_rollup():
    """The total across groups must equal the total across projects. If this ever fails the chart
    is under-reporting, which is the one failure a reader cannot see."""
    rows = _rows(("a", 10, 1), ("b", 5, 2), ("c", 3, 3), ("d", 7, 4))
    gmap = {"a": "G1", "b": "G1", "c": "G2", "d": "Other"}
    out = pg.rollup_by_group(rows, group_map=gmap)
    assert sum(d["errorCount"] for d in out) == 25
    assert sum(d["recommendedCount"] for d in out) == 10
    assert sum(d["projectCount"] for d in out) == 4


def test_unmapped_project_falls_into_other_not_a_new_group():
    """A project the map does not cover must land in the existing "Other" bucket. Inventing a
    group here would put a name on the chart that exists nowhere in the configuration."""
    out = pg.rollup_by_group(_rows(("stray", 4, 0)), group_map={})
    assert len(out) == 1
    assert out[0]["groupName"] == pg.DEFAULT_GROUP


def test_busiest_group_first_with_name_as_tie_break():
    rows = _rows(("a", 1, 0), ("b", 9, 0), ("c", 1, 0))
    out = pg.rollup_by_group(rows, group_map={"a": "Bravo", "b": "Alpha", "c": "Charlie"})
    # Alpha wins on count; Bravo and Charlie tie on 1 and fall back to name order.
    assert [d["groupName"] for d in out] == ["Alpha", "Bravo", "Charlie"]


def test_other_is_pinned_last_even_when_it_is_the_biggest_bucket():
    """"Other" absorbs every unconfigured project, so on error count alone it would usually lead a
    chart that is supposed to be about groups. It is a removal bucket, not a group, and
    both _pg_group_order and the frontend sortGroups already pin it last."""
    rows = _rows(("a", 100, 0), ("b", 5, 0), ("c", 1, 0))
    out = pg.rollup_by_group(rows, group_map={"a": "Other", "b": "HIP26", "c": "TD5"})
    assert [d["groupName"] for d in out] == ["HIP26", "TD5", "Other"]
    # Pinning it last must not drop or alter its numbers.
    assert out[-1]["errorCount"] == 100


def test_order_is_stable_across_repeated_calls():
    """Equal counts must not shuffle between refreshes - a chart that reorders itself on reload
    reads as data changing when nothing changed."""
    rows = _rows(("a", 2, 0), ("b", 2, 0), ("c", 2, 0))
    gmap = {"a": "Gamma", "b": "Alpha", "c": "Beta"}
    first = [d["groupName"] for d in pg.rollup_by_group(rows, group_map=gmap)]
    second = [d["groupName"] for d in pg.rollup_by_group(rows, group_map=gmap)]
    assert first == second == ["Alpha", "Beta", "Gamma"]


def test_label_stays_in_projectname_so_the_chart_needs_no_model_change():
    out = pg.rollup_by_group(_rows(("a", 1, 0)), group_map={"a": "HIP26"})
    assert out[0]["projectName"] == "HIP26"
    assert out[0]["groupName"] == "HIP26"


def test_empty_and_malformed_input_do_not_raise():
    assert pg.rollup_by_group([]) == []
    assert pg.rollup_by_group(None) == []
    # A non-dict row is skipped rather than crashing the dashboard.
    assert pg.rollup_by_group(["not a row"], group_map={}) == []


def test_missing_counts_are_treated_as_zero():
    out = pg.rollup_by_group([{"projectName": "a"}], group_map={"a": "G1"})
    assert out[0]["errorCount"] == 0
    assert out[0]["recommendedCount"] == 0
    assert out[0]["projectCount"] == 1


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
