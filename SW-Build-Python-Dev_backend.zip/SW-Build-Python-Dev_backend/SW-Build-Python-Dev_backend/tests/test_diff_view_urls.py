"""The diff view page must work when the app is served under a prefix.

THE OUTAGE THIS PINS. On the servers the application is mounted under /agent, so the page is
opened at /agent/diff_view/request/<id>. Every URL inside the page was written from the domain
root - `/show-diff-page/<id>` for the data and `/image/<name>` for the icons - so each one dropped
the prefix and resolved at the domain root instead. The images 404'd and the diff never loaded:
the page rendered as an empty frame with a broken image and a download button, which is what was
reported from production.

Nothing failed loudly. The route returned 200 with a perfectly good page, and only the browser's
own requests were wrong - so no server log showed a problem.

The page now works out where it is mounted from its own address and prefixes everything with that,
which also keeps it working when the app is served at the root. These tests read the page source
out of route.py rather than importing the app, so they need no AWS and no network.
"""
import ast
import io
import os
import re

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_ROUTE = os.path.join(_ROOT, "src", "routes", "route.py")


def _diff_view_page() -> str:
    """The HTML string the diff_view route returns."""
    tree = ast.parse(io.open(_ROUTE, encoding="utf-8-sig").read())
    fn = next((n for n in ast.walk(tree)
               if isinstance(n, ast.FunctionDef) and n.name == "diff_view"), None)
    assert fn is not None, "the diff_view route is gone - this test needs updating"
    for node in ast.walk(fn):
        if isinstance(node, ast.Return) and isinstance(node.value, ast.Constant) \
                and isinstance(node.value.value, str):
            return node.value.value
    pytest.fail("diff_view no longer returns a plain HTML string - update this test")


def test_the_page_works_out_its_own_mount_point():
    page = _diff_view_page()
    assert "window.location.pathname.split" in page and "/diff_view/" in page, (
        "the page no longer derives its base path from its own address, so it will break "
        "again when served under /agent"
    )


def test_the_data_request_carries_the_base_path():
    """The empty panel in the production report was this one URL."""
    page = _diff_view_page()
    assert "${BASE}/show-diff-page/" in page, (
        "the diff data is fetched from a root-absolute URL again - under /agent it will 404 "
        "and the page will render empty"
    )
    assert "`/show-diff-page/" not in page, "a root-absolute data URL has come back"


def test_no_image_is_left_pointing_at_the_domain_root():
    """Either prefixed in the markup, or rewritten by the loop that runs on load."""
    page = _diff_view_page()
    bare = re.findall(r'<img[^>]*src="(/image/[^"]*)"', page)
    if bare:
        assert 'img[src^="/image/"]' in page, (
            f"these images point at the domain root and nothing rewrites them: {bare}. "
            f"Under /agent they will 404 and show as broken icons."
        )


def test_the_rewrite_actually_applies_the_base_path():
    page = _diff_view_page()
    assert 'setAttribute("src", BASE + el.getAttribute("src"))' in page, (
        "the image rewrite no longer prefixes the base path"
    )


@pytest.mark.parametrize("path,expected_base", [
    ("/agent/diff_view/request/c2b76613-9887-4ace-8bbe-da3d5d0d8721", "/agent"),
    ("/diff_view/request/c2b76613-9887-4ace-8bbe-da3d5d0d8721", ""),
    ("/agent/diff_view/vec-123", "/agent"),
    ("/diff_view/vec-123", ""),
])
def test_the_base_path_rule_holds_for_every_url_shape(path, expected_base):
    """The same split the page performs, including the reported production URL.

    Both route shapes must work - /diff_view/<vector_id> and /diff_view/request/<request_id> -
    which is why the base is taken from the text before "/diff_view/" rather than by counting
    path segments, since the two shapes have different depths.
    """
    assert path.split("/diff_view/")[0] == expected_base
