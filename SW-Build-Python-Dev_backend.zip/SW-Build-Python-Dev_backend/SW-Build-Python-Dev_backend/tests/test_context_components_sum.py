"""The context components must add up to the context score.

The trace shows every part of a candidate's context score and then the total the ranking used.
If those disagree, the screen is explaining a number it did not produce - and the whole point of
the breakdown is that a surprising score can be taken apart and understood.

They disagreed. A live row showed parts summing to 27.29 against a stored score of 33.30, and
the 6.01 difference was exactly the history cap. The cap did two things: it scaled
comp["success"] down to the capped value AND recorded comp["history_cap"] as the negative
excess. The score lost the excess once; the displayed parts lost it twice.

The fix keeps the parts raw and lets the cap line carry the whole subtraction, with the capped
total carried separately for the evidence gate, which does need it. These tests pin the
arithmetic rather than the wording, so any future component that subtracts has to keep the sum
honest.
"""
import os
import re
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

_H = open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()


def _history_cap_block():
    start = _H.index('rec["capped_history"] = round(min(_hist, _hist_cap), 4)')
    return _H[start - 1200:start + 900]


# --------------------------------------------------------------- the arithmetic

def _apply(components, cap):
    """The shipping rule, expressed once: the cap subtracts the excess and the parts stay raw."""
    hist = components.get("success", 0.0) + components.get("after_pattern", 0.0)
    out = dict(components)
    if hist > cap:
        out["history_cap"] = -round(hist - cap, 2)
    return out, round(min(hist, cap), 4)


def test_the_parts_add_up_to_what_the_score_lost():
    """The live case: raw history 10, ceiling 4. The score loses 6 once, so the parts must total
    6 less than they would uncapped - not 12 less."""
    parts, capped = _apply({"artifact": 21.97, "base": 10.0, "success": 10.0,
                            "after_pattern": 0.0}, cap=4.0)
    assert parts["success"] == 10.0, "the raw part was reduced as well as the cap line"
    assert parts["history_cap"] == -6.0
    assert round(sum(parts.values()), 2) == round(21.97 + 10.0 + 10.0 + 0.0 - 6.0, 2)
    assert capped == 4.0


def test_history_within_the_ceiling_records_no_cap_line():
    parts, capped = _apply({"success": 3.0, "after_pattern": 0.0}, cap=4.0)
    assert "history_cap" not in parts
    assert capped == 3.0


def test_the_gate_discounts_the_capped_history_not_the_raw_figure():
    """A candidate with a huge track record and weak evidence must not be discounted on the raw
    figure - the cap has already removed most of it, and discounting the raw amount would take
    the same points away twice in a different way."""
    _, capped = _apply({"success": 10.0, "after_pattern": 0.0}, cap=4.0)
    relevance = 0.75
    discount = (1.0 - relevance) * capped
    assert discount == 1.0, "the gate is working from the raw history again"


# --------------------------------------------------------------- pinned in the source

def test_the_cap_no_longer_rescales_the_parts():
    """This is the defect itself. Scaling the parts AND recording the cap line is what made the
    components sum below the score."""
    block = _history_cap_block()
    assert 'comp["success"] = round(float(comp.get("success")' not in block, \
        "the history cap is rescaling comp['success'] again"
    assert 'comp["after_pattern"] = round(float(comp.get("after_pattern")' not in block, \
        "the history cap is rescaling comp['after_pattern'] again"
    assert 'comp["history_cap"] = -round(_excess, 2)' in block


def test_the_capped_total_is_carried_for_the_gate():
    assert 'rec["capped_history"] = round(min(_hist, _hist_cap), 4)' in _H
    assert '_history = rec.get("capped_history")' in _H


def test_every_recorded_component_is_additive():
    """Each component either adds or subtracts, and each is applied to the score exactly once.
    A component that both changes another component AND records its own line double-counts,
    which is precisely the bug this file exists for."""
    subtracting = ["history_cap", "evidence_gate", "task_identity_scaled", "helper_cap"]
    for name in subtracting:
        assert f'comp["{name}"] = -round(' in _H or f'comp["{name}"] = -' in _H or \
               f'"{name}"' in _H, f"{name} is no longer recorded"
    # The two that trim other values must not also rewrite the parts they trim.
    gate = _H[_H.index('comp["evidence_gate"]') - 900:_H.index('comp["evidence_gate"]') + 120]
    assert 'comp["success"] =' not in gate, "the evidence gate started rewriting the parts"


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
