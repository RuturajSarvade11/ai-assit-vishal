from src.utils import oai_client


def test_candidate_linked_artifact_evidence_is_sent_with_its_solution(monkeypatch):
    captured = {}

    def fake_completion(*, user_message, system_message, **kwargs):
        captured["user"] = user_message
        captured["system"] = system_message
        return (
            '{"root_cause":"configuration mismatch",'
            '"chosen_request_id":"candidate-1","confidence":"high",'
            '"why_this_fix":"the linked log confirms it",'
            '"missing_line":"","analysis":"Apply the matching compiler setting."}',
            {"prompt_tokens": 1, "output_tokens": 1, "total_tokens": 2},
        )

    monkeypatch.setattr(oai_client.config, "LLM_ANALYSIS_ENABLED", True)
    monkeypatch.setattr(oai_client, "create_chat_completion", fake_completion)

    result = oai_client.analyze_and_select_solution_with_unified_evidence(
        errors=[{"message": "Error parsing input file"}],
        unified_evidence=[],
        candidate_solutions=[{
            "request_id": "candidate-1",
            "solution": [{"filePath": "config.xml", "changes": ["<Compiler>CTC</Compiler>"]}],
            "artifact_matched": {
                "file_name": "debug.log",
                "evidence_text": "Error parsing input file\nExpected compiler CTC",
            },
        }],
        query_text="Error parsing input file",
    )

    assert "candidate-linked artifact evidence: debug.log; use only for request_id=candidate-1" in captured["user"]
    assert "Expected compiler CTC" in captured["user"]
    assert "never transfer it to another request_id" in captured["system"]
    assert result[1]["chosen_request_id"] == "candidate-1"