"""Same-error feedback earns points, and can still never outrank evidence.

The trace's Feedback effect column used to say "no change" on every row - the raw
helpful/not-helpful counts are already available, and the question is what they DID. It was the
honest answer: votes were only a late tie-break and a downvote sink, so they almost never moved
anything.
So feedback now earns a visible, quantified share of the score.

The two properties that matter are opposites, and both are pinned here:

  1. The points are REAL - a same-error upvote measurably lifts a candidate, so the column shows a
     number instead of a shrug.
  2. The points are CAPPED - they are helper points, so the existing "helpers never outweigh
     evidence" invariant still stops a well-liked fix beating the one the failure's own log points
     at. The rule is unchanged: error and artifact decide, feedback confirms.

Only same-error votes (fb_link_net) count. Global thumbs earn nothing, and a recorded request showed
why: the LLM picked a candidate on a different task with no artifact evidence, scoring 13.8
against 55.2, because it had "the strongest helpful feedback signals".
"""
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

W = 6.0          # feedbackSupportWeight default
SAT = 2.0        # saturation constant in W*net/(net+SAT)


def points(net, weight=W):
    """The formula as implemented in handlers."""
    if net <= 0 or weight <= 0:
        return 0.0
    return weight * (net / (net + SAT))


def capped(helpers, evidence):
    """The existing helper-cap invariant: helpers may total at most the evidence."""
    return max(0.0, min(helpers, evidence))


def test_one_vote_earns_a_third_of_the_weight():
    assert round(points(1), 2) == 2.00


def test_points_saturate_so_one_keen_developer_cannot_buy_a_rank():
    assert round(points(2), 2) == 3.00
    assert round(points(5), 2) == 4.29
    assert round(points(50), 2) == 5.77
    # However many arrive, it never exceeds the weight.
    assert points(10 ** 6) < W


def test_more_votes_always_help_but_by_less_each_time():
    gains = [points(n + 1) - points(n) for n in range(1, 8)]
    assert all(g > 0 for g in gains), "another vote must never hurt"
    assert gains == sorted(gains, reverse=True), "each vote must add less than the last"


def test_no_votes_no_points():
    assert points(0) == 0.0
    assert points(-3) == 0.0, "negatives are the downvote sink's job, not a negative score here"


def test_weight_zero_switches_it_off_completely():
    for net in (1, 5, 100):
        assert points(net, weight=0.0) == 0.0


def test_feedback_cannot_outrank_evidence():
    """THE safety property. A candidate with strong feedback and weak evidence must not overtake
    one whose evidence actually matches the failure."""
    # Weak evidence, lots of same-error praise.
    liked_evidence = 6.0
    liked_helpers = 4.0 + points(10)          # other helpers + feedback
    liked_total = liked_evidence + capped(liked_helpers, liked_evidence)

    # Strong evidence (its log names this failure), nobody has voted on it yet.
    proven_evidence = 30.0
    proven_total = proven_evidence + capped(4.0, proven_evidence)

    assert proven_total > liked_total, (
        f"feedback overturned evidence: liked {liked_total} vs proven {proven_total}")


def test_the_cap_is_what_contains_it_not_the_weight_being_small():
    """Even at the maximum configurable weight the invariant holds - the protection is structural,
    not a hope that the number stays small."""
    evidence = 8.0
    helpers = 3.0 + points(1000, weight=18.0)   # 18 is the configurable ceiling
    assert capped(helpers, evidence) == evidence
    assert evidence + capped(helpers, evidence) == 16.0


def test_feedback_breaks_a_genuine_tie():
    """With evidence equal, same-error feedback is exactly the sort of signal that should decide."""
    a = 20.0 + capped(5.0 + points(3), 20.0)
    b = 20.0 + capped(5.0, 20.0)
    assert a > b
    assert round(a - b, 2) == round(points(3), 2)


def test_a_single_vote_does_not_overturn_a_clear_evidence_gap():
    """The realistic worry: one upvote on a mediocre fix while the right one has better evidence."""
    mediocre = 12.0 + capped(3.0 + points(1), 12.0)
    right = 18.0 + capped(3.0, 18.0)
    assert right > mediocre, f"one vote flipped a 6-point evidence gap: {mediocre} vs {right}"


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
