"""Retrieval scope resolution.

THE RULE: only projects that are PART OF A DEFINED GROUP share evidence. Ungrouped
projects do not - "Other" is a removal bucket, not a group, and widening to it would make every
unconfigured project in the estate share with every other one.

These tests pin that rule and the two ways it could silently be broken: a phantom group (a
typo'd name that assign_project accepts without checking a definition exists) and a fail-open
error path that widens instead of narrowing.
"""
import os
import sys
import types

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# project_groups needs exactly one thing from the stack - get_dynamodb - and the scope rules
# under test are pure logic. Stubbing that single import keeps the test free of AWS, Azure and
# any network, so it runs anywhere.
_fake_db = types.ModuleType("src.databases.database")
_fake_db.get_dynamodb = lambda *a, **k: None
_real_db = sys.modules.get("src.databases.database")
sys.modules["src.databases.database"] = _fake_db

_fake_cfg = types.ModuleType("src.configurations.config")
for _attr in ("DYNAMODB_TABLE_SUFFIX", "DYNAMODB_REGION", "DYNAMODB_ENDPOINT"):
    setattr(_fake_cfg, _attr, "")
_fake_pkg = types.ModuleType("src.configurations")
_fake_pkg.config = _fake_cfg
sys.modules.setdefault("src.configurations", _fake_pkg)

# Scoped to this one import, then put back. A stub left in sys.modules is inherited by every
# test file collected afterwards, so a config carrying three settings silently became THE config
# for suites that read a fourth - each of them passing alone and failing together.
_real_cfg = sys.modules.get("src.configurations.config")
sys.modules["src.configurations.config"] = _fake_cfg
try:
    from src.services import project_groups as pg
finally:
    if _real_cfg is not None:
        sys.modules["src.configurations.config"] = _real_cfg
    else:
        sys.modules.pop("src.configurations.config", None)
        if sys.modules.get("src.configurations") is _fake_pkg:
            sys.modules.pop("src.configurations", None)
    if _real_db is not None:
        sys.modules["src.databases.database"] = _real_db
    else:
        sys.modules.pop("src.databases.database", None)


def _stub(monkey_defs, monkey_overrides):
    pg.list_group_defs = lambda: monkey_defs
    pg.get_overrides = lambda: monkey_overrides
    pg._scope_cache.clear()


ALL = ["1ghio_000u0_000", "1ghio_111u0_000", "0ga1_0m0_td5", "testgbe"]


def test_defined_group_with_several_members_widens():
    _stub([{"group_name": "HIP26", "project_pattern": "1GHIO*"}], {})
    members, mode = pg.resolve_scope_projects("1ghio_000u0_000", ALL)
    # The widening level is called "customer" since the 30-Sep review; "group" remains an
    # accepted spelling on input, but the resolved mode reports the decided name.
    assert mode == "customer", mode
    assert members == ["1ghio_000u0_000", "1ghio_111u0_000"], members


def test_ungrouped_project_never_widens():
    """The rule: 'Other' does not share."""
    _stub([{"group_name": "HIP26", "project_pattern": "1GHIO*"}], {})
    members, mode = pg.resolve_scope_projects("testgbe", ALL)
    assert mode == "project", mode
    assert members == ["testgbe"], members


def test_every_ungrouped_project_is_isolated_from_every_other():
    """The specific failure the rule prevents: Other treated as a group."""
    _stub([{"group_name": "HIP26", "project_pattern": "1GHIO*"}], {})
    for name in ("testgbe", "0ga1_0m0_td5"):
        members, mode = pg.resolve_scope_projects(name, ALL)
        assert mode == "project" and members == [name], (name, members, mode)


def test_phantom_group_does_not_widen():
    """assign_project accepts ANY string with no check that the group exists. A typo'd override
    resolves to itself and is not DEFAULT_GROUP - only the defs-membership test stops it."""
    _stub([{"group_name": "HIP26", "project_pattern": "1GHIO*"}],
          {"testgbe": "HIP2G", "0ga1_0m0_td5": "HIP2G"})   # typo'd group, defined nowhere
    members, mode = pg.resolve_scope_projects("testgbe", ALL)
    assert mode == "project", f"a group that exists in no definition must not widen: {mode}"
    assert members == ["testgbe"]


def test_group_of_one_reports_project_scope():
    """A group with a single member is project scope; reporting 'group' would claim a widening
    that did not happen."""
    _stub([{"group_name": "SOLO", "project_pattern": "testgbe"}], {})
    members, mode = pg.resolve_scope_projects("testgbe", ALL)
    assert mode == "project", mode
    assert members == ["testgbe"]


def test_failure_falls_back_to_project_not_to_everything():
    """A scope resolver that fails OPEN widens the search - the opposite of safe."""
    def boom():
        raise RuntimeError("store unavailable")
    pg.list_group_defs = boom
    pg._scope_cache.clear()
    members, mode = pg.resolve_scope_projects("1ghio_000u0_000", ALL)
    assert mode == "project" and members == ["1ghio_000u0_000"], (members, mode)


def test_scope_where_is_byte_identical_for_project_scope():
    """A caller that is not widening must emit exactly the dict the code sends today."""
    assert pg.scope_where("testgbe", members=["testgbe"]) == {"project_name": "testgbe"}


def test_scope_where_never_emits_a_single_element_or():
    """Chroma REJECTS a 1-element $or and the rejection is swallowed into an empty result - the
    fail-open path would return NO candidates instead of project-scoped ones."""
    where = pg.scope_where("testgbe", members=["testgbe"])
    assert "$or" not in str(where) and "$in" not in str(where), where
    where_empty = pg.scope_where("testgbe", members=[])
    assert where_empty == {"project_name": "testgbe"}, where_empty


def test_scope_where_group_uses_in_and_nests_extra_under_and():
    where = pg.scope_where("a", extra={"task_path": "t"}, members=["a", "b"])
    assert where == {"$and": [{"project_name": {"$in": ["a", "b"]}}, {"task_path": "t"}]}, where
