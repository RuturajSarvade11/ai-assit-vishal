"""Task-recall rows are scored on how well they match, like every other row.

THE REPORTED CASE (08-Oct). A dashboard table showed two "task recall" rows at a flat Match of
12.00 above a semantic row whose similarity was 0.71 and whose Match was 8.55. The task ledger
surfaces a candidate by task identity alone and leaves its similarity at None; the scaling only
ran for semantic rows; so the candidate that was never compared to the failure earned MORE match
points than one that was compared and scored 0.71.

The fix gives a task-recall row the same cosine every semantic row carries - the two error texts
embedded through the same helper, compared the same way the vector store compares them - and
scales its base by it. A row whose embedding cannot be produced keeps the unscaled base, as before.
"""
import io
import os
import sys

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

from src.services import handlers  # noqa: E402
from src.services.handlers import _task_recall_similarity  # noqa: E402
from src.utils import project_details, ttl_cache  # noqa: E402


def _handlers_src():
    return io.open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()


def _fake_embed(table):
    def _embed(text, *args, **kwargs):
        return list(table[text])
    return _embed


def test_an_identical_error_scores_one(monkeypatch):
    monkeypatch.setattr(handlers, "create_embedding", _fake_embed({"same error": [1.0, 0.0, 0.0]}))
    assert _task_recall_similarity("same error", "same error", {}) == pytest.approx(1.0)


def test_an_unrelated_error_scores_zero(monkeypatch):
    monkeypatch.setattr(handlers, "create_embedding",
                        _fake_embed({"python 3.8 expected": [1.0, 0.0], "ctc compiler missing": [0.0, 1.0]}))
    assert _task_recall_similarity("python 3.8 expected", "ctc compiler missing", {}) == pytest.approx(0.0)


def test_it_is_the_cosine_on_the_same_scale_as_the_vector_search(monkeypatch):
    # The store returns 2(1-cos) and the search maps it back with 1 - d/2 - which is the cosine.
    # So a task-recall row's figure must BE the cosine, nothing rescaled.
    monkeypatch.setattr(handlers, "create_embedding",
                        _fake_embed({"q": [1.0, 1.0], "c": [1.0, 0.0]}))
    assert _task_recall_similarity("q", "c", {}) == pytest.approx(2 ** -0.5)


def test_a_negative_cosine_is_floored_at_zero(monkeypatch):
    monkeypatch.setattr(handlers, "create_embedding",
                        _fake_embed({"q": [1.0, 0.0], "c": [-1.0, 0.0]}))
    assert _task_recall_similarity("q", "c", {}) == 0.0


def test_empty_text_or_a_failed_embedding_leaves_the_base_unscaled(monkeypatch):
    def _boom(text, *a, **k):
        raise RuntimeError("embedding service down")
    monkeypatch.setattr(handlers, "create_embedding", _boom)
    assert _task_recall_similarity("", "c", {}) is None
    assert _task_recall_similarity("q", "   ", {}) is None
    assert _task_recall_similarity("q", "c", {}) is None   # failure -> None, never raises


def test_the_query_is_embedded_once_per_request(monkeypatch):
    calls = []

    def _embed(text, *a, **k):
        calls.append(text)
        return [1.0, 0.0]
    monkeypatch.setattr(handlers, "create_embedding", _embed)
    cache = {}
    _task_recall_similarity("q", "c1", cache)
    _task_recall_similarity("q", "c2", cache)
    _task_recall_similarity("q", "c1", cache)
    assert calls == ["q", "c1", "c2"], "the shared cache must stop the query being re-embedded per candidate"


# ---------------------------------------------------------------- wiring in the rerank loop

def test_task_recall_rows_are_given_the_cosine_before_scoring():
    src = _handlers_src()
    assert 'if match_type == "task" and recommendation_similarity is None:' in src
    assert "_tr_sim = _task_recall_similarity(" in src
    # It must happen BEFORE the base is scaled, or it changes nothing.
    assert src.index("_tr_sim = _task_recall_similarity(") < src.index(
        'if match_type in ("semantic", "task") and isinstance(recommendation_similarity, (int, float)):')


def test_task_recall_is_scaled_like_a_semantic_row():
    src = _handlers_src()
    assert ('if match_type in ("semantic", "task") and isinstance(recommendation_similarity, (int, float)):\n'
            '                match_score = match_score * max(0.0, min(1.0, float(recommendation_similarity)))'
            ) in src.replace("\r\n", "\n"), "task recall keeps the full base again"
    assert 'if match_type == "semantic" and isinstance(recommendation_similarity' not in src


def test_the_trace_records_where_the_similarity_came_from_and_the_hidden_bonus():
    trace = io.open(os.path.join(_ROOT, "src", "utils", "recommendation_trace.py"),
                    encoding="utf-8-sig").read()
    for key in ('"similarity_source"', '"distinctive_points"', '"distinctive_overlap"'):
        assert key in trace, f"{key} is not stored on the trace row - the table cannot reconcile Final"


def test_task_ledger_skips_same_task_rows_without_a_solution(monkeypatch):
    rows = [
        {
            "request_id": f"empty-record-{index}",
            "project_name": "demo",
            "task_name": ":TARGETS:master:task3",
            "payload_json": {"solution": []},
        }
        for index in range(6)
    ] + [
        {
            "request_id": "valid-record",
            "project_name": "demo",
            "task_name": ":TARGETS:master:task3",
            "payload_json": {"solution": [{"filePath": "fix.py", "changes": ["fix"]}]},
        },
    ]

    monkeypatch.setattr(handlers, "_reco_scope_members", lambda project: (["demo"], "project"))
    monkeypatch.setattr(project_details, "list_final_build_payloads_by_project", lambda project: rows)

    def cached_result(key, compute, **kwargs):
        if key[0] == "task-ledger-payloads":
            return rows
        if key[0] in {"ledger-errtext", "ledger-heal"}:
            return []
        return compute()

    monkeypatch.setattr(ttl_cache, "get_or_compute", cached_result)

    result = handlers._task_ledger_candidates(
        "demo", ":TARGETS:master:task3", [], [], limit=1,
    )

    assert [item["meta"]["request_id"] for item in result] == ["valid-record"]


# ---------------------------------------------------------------- every way a task row can arrive

def test_every_task_recall_outcome_is_named_and_scored():
    """Four cases, each named on the row and in the trace (similarity_source):

    task_recall_cosine     compared - the base is scaled by the cosine like any row
    no_error_text          the stored row has no error text: NOTHING to compare, so it earns no
                           match points (a bare same-task row took the full 12 and rank 2 with an
                           empty solution column, live 08-Oct); its context still counts
    no_query_text          the request carried no error text - base kept, nothing competes
    embedding_unavailable  the embedding call failed - base kept, as before (fail-open)
    """
    src = _handlers_src().replace("\r\n", "\n")
    block = src[src.index('if match_type == "task" and recommendation_similarity is None:'):]
    block = block[:block.index("final_payload = None")]
    for source in ("no_error_text", "no_query_text", "embedding_unavailable"):
        assert f'match["similarity_source"] = "{source}"' in block, f"{source} is not named"
    # A COMPUTED cosine carries no label: it is the same measure as a vector-search row's, on the
    # same prepared text, so the similarity column shows the number and nothing else (asked for
    # directly, 09-Oct: "don't show task_recall in the similarity column").
    assert "task_recall_cosine" not in block
    assert "_prepare_messages_for_vectorization([error_text])" in src  # the ledger embeds the stored form
    # No error text -> similarity stays BLANK (not a fake 0.0) and the match points are zeroed
    # explicitly, so the base cannot survive on a blank.
    assert "recommendation_similarity = 0.0" not in block
    scale = src[src.index('if match_type in ("semantic", "task") and isinstance(recommendation_similarity'):][:700]
    assert ('== "no_error_text":' in scale and "match_score = 0.0" in scale)
    # The blend treats that 0.0 as "nothing to compare", not "compared and unrelated".
    assert 'str(rec.get("similarity_source") or "") != "no_error_text"' in src
    # And the explain page replays the same rule - through the ONE blend the ranking used
    # (_blend_evidence), with "no_error_text" meaning "nothing to compare".
    assert '_sim_source != "no_error_text"' in src
    assert src.count("_blend_evidence(") >= 3  # defined once, called by the ranking and the explain page


# ---------------------------------------------------------------- nothing to recommend never ranks

def _rec(rid, final, solution, up=0, down=0):
    return {"request_id": rid, "project_name": "testgbe", "final_score": final, "document": "error x",
            "task_name": ":TARGETS:master:task3", "solution": solution, "thumbs_up": up,
            "thumbs_down": down, "match_type": "semantic"}


def test_a_candidate_without_a_solution_sinks_below_everything(monkeypatch):
    """The gate already refuses to SHOW it (match_status 'none'), but the trace table lists this
    order, and a bare row scored 15.00 sat at rank 2 above three real fixes. Downvotes no longer
    sink anything (feedback is a tie-break only), so the downvoted real fix keeps its place on
    score and only nothing-to-recommend goes last."""
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {"downvoteSinkMinVotes": 1})
    pool = [
        _rec("bare", 15.0, []),                       # highest-but-one score, nothing to recommend
        _rec("fix", 10.0, [{"file": "config.xml"}]),  # a real fix
        _rec("voted", 20.0, [{"file": "x.c"}], up=0, down=2),  # downvoted real fix, best score
    ]
    out = handlers._rerank_recommendations_for_relevance(
        pool, query_text="error x", query_task_path=":TARGETS:master:task3", query_project="testgbe")
    assert [r["request_id"] for r in out] == ["voted", "fix", "bare"], (
        "score order among real fixes, nothing-to-recommend last")
    assert out[2]["rank_factors"]["no_solution"] is True
    assert out[0]["rank_factors"]["no_solution"] is False


def test_the_feedback_counterfactual_still_measures_after_the_key_changed(monkeypatch):
    """The key changed shape; the counterfactual indexes the tuple by position and must still
    neutralise exactly the one vote term and nothing else. Votes decide a tie only."""
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {"downvoteSinkMinVotes": 1})
    pool = [_rec("a", 15.0, [{"f": 1}]), _rec("voted", 15.0, [{"f": 1}], up=2),
            _rec("b", 10.0, [{"f": 1}])]
    out = handlers._rerank_recommendations_for_relevance(
        pool, query_text="error x", query_task_path=":TARGETS:master:task3", query_project="testgbe")
    assert [r["request_id"] for r in out] == ["voted", "a", "b"]
    fb = out[0]["feedback_influence"]
    assert fb["rank"] == 1 and fb["rank_without_feedback"] == 2 and fb["delta"] == 1 and fb["sunk"] is False
    assert out[1]["feedback_influence"]["delta"] == -1
    assert out[2]["feedback_influence"]["delta"] == 0
