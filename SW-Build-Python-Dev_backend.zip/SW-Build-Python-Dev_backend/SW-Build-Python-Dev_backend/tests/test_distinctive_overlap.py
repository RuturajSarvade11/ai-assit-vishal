"""Whole message against whole message, scored on what DIFFERS.

THE REPORTED CASE (01-Oct). A build failed on `ech`, a typo for `echo`, in one line of a script.
The recommendation returned three unrelated candidates - a compiler version mismatch and two
Python version mismatches - every one at a similarity of 0.67 or 0.68.

Those numbers were not wrong. Measured on that log, 2,129 of the 2,138 characters compared were
identical for every build of that task: the snapshot lines, the tool install, the command line,
even the shape of the traceback. Nine characters said which command had failed. Two unrelated
failures genuinely ARE 99.6% the same text, so scoring on what they share returns the same answer
for all of them, and no threshold separates 99.58% from 99.60%.

Inverting the question fixes it. Remove what the two messages share, and judge only what is left -
which either corresponds or does not:

    the ech fix                  0.83
    ctc_aurix version mismatch   0.03
    python version mismatch      0.03

The same case the vector similarity could not separate at all.

It asks nothing about what a line MEANS. No phrase list, no language assumption, nothing learned
from how often something has been seen - so a toolchain nobody has encountered behaves like a
familiar one, and the answer for two given messages never changes.

Ships behind distinctiveMatchWeight, 0 by default.
"""
import io
import os
import sys

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# The Azure credentials handlers needs at import time are set for the whole suite in
# conftest.py, which pytest loads before any test module. This file used to set them itself and
# then undo it, evicting every src.* module as it went - which broke sixteen tests in
# test_trace_explain.py as soon as new test files changed the collection order.
from src.services.handlers import _distinctive_overlap, _differing_lines  # noqa: E402


BOILERPLATE = """Created inputs snapshot in [19] ms
Copied input files in [4] ms
Creating snapshot for [c:/LegacyApp/ctc_aurix/6.2r1p4].
Local installation of tool ctc_aurix:6.2r1p4 is UP-TO-DATE
Finished installing all relevant tools for the GBE process task1
Starting the execution of the command line(s) for the GBE process task1
2026-10-01 16:13:59 Running file handler win-utils demo..."""

QUERY = BOILERPLATE + """
'ech' is not recognized as an internal or external command,
Traceback (most recent call last):
subprocess.CalledProcessError: Command 'ech Dummy content' returned non-zero exit status 1."""

SAME_FAILURE = BOILERPLATE + """
'ech' is not recognized as an internal or external command,
Traceback (most recent call last):
subprocess.CalledProcessError: Command 'ech Hello content' returned non-zero exit status 1."""

CTC_MISMATCH = BOILERPLATE + """
'tools[ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p456'
Build failed with an exception."""

PYTHON_MISMATCH = BOILERPLATE + """
'tools[python].version' must be '3.10.0' but got '3.11.0'
Build failed with an exception."""


def test_the_right_answer_separates_from_the_wrong_ones():
    """The whole point. Vector similarity gave 0.67 against 0.68 - indistinguishable."""
    right = _distinctive_overlap(QUERY, SAME_FAILURE)
    ctc = _distinctive_overlap(QUERY, CTC_MISMATCH)
    py = _distinctive_overlap(QUERY, PYTHON_MISMATCH)
    assert right > 0.5, f"the matching failure scored only {right:.2f}"
    assert ctc < 0.5 and py < 0.5, f"an unrelated failure scored {max(ctc, py):.2f}"
    assert right > 2.5 * max(ctc, py), (
        f"separation is too small to rank on: {right:.2f} vs {max(ctc, py):.2f}"
    )


def test_the_shared_build_log_is_removed_before_scoring():
    """It is identical in both, so it must not reach the comparison at all."""
    q_only, c_only = _differing_lines(QUERY, CTC_MISMATCH)
    joined = " ".join(q_only + c_only).lower()
    for noise in ("created inputs snapshot", "copied input files", "up-to-date",
                  "finished installing", "starting the execution"):
        assert noise not in joined, f"shared boilerplate reached the comparison: {noise}"


def test_an_identical_message_scores_one():
    assert _distinctive_overlap(QUERY, QUERY) == 1.0


def test_messages_differing_only_in_paths_and_timestamps_still_match():
    """A different working folder or run time is not a different failure."""
    other_run = QUERY.replace("c:/LegacyApp", "d:/Other").replace("2026-10-01 16:13:59",
                                                                 "2026-09-30 09:02:11")
    assert _distinctive_overlap(QUERY, other_run) > 0.9


def test_a_one_token_difference_is_the_known_limit():
    """`ech` against `gcc` - the two lines differ by exactly one word out of seven.

    This case is NOT separated and the number says so: coverage comes out around 0.86, because
    six of the candidate's seven distinctive words are also in ours. Every token counts the same,
    so the one that matters - the command name - is outvoted by the six that appear in every
    not-recognized error.

    Weighting a token by how rare it is would fix it, and that principle is already used for the
    artifact comparison. It needs the candidate pool to compute rarity against, which this
    function does not receive. Recorded as the known edge rather than left to be found: where
    candidates differ by more than a single token - as the live cases did - the separation is
    1.00 against 0.20 to 0.36.
    """
    a = BOILERPLATE + "\n'ech' is not recognized as an internal or external command,"
    b = BOILERPLATE + "\n'gcc' is not recognized as an internal or external command,"
    assert _distinctive_overlap(a, a) == 1.0
    assert _distinctive_overlap(a, b) >= 0.8, (
        "if this now separates them, rarity weighting has been added - update this test"
    )

def test_an_empty_or_missing_candidate_does_not_raise():
    for bad in ("", None, "   "):
        assert 0.0 <= _distinctive_overlap(QUERY, bad) <= 1.0


def test_it_is_deterministic():
    """Same two messages, same answer, every time - nothing is learned or counted."""
    first = _distinctive_overlap(QUERY, CTC_MISMATCH)
    for _ in range(5):
        assert _distinctive_overlap(QUERY, CTC_MISMATCH) == first


def test_the_comparison_is_applied_last_and_onto_the_final_score():
    """It must survive every adjustment above it, or it is clawed back.

    Seven adjustments run over a candidate's context after it is first scored - the artifact
    lift, the after-pattern bonus, an excess trim, a discount, a task trim and the helper cap -
    and each recomputes the final score from the context. Added INTO the context, these points
    were taken back by whichever trim fired next, and the candidate with the most helper points
    to trim lost the most.

    A recorded request put the correct fix FOURTH, with a final score 7.14 below the sum of its
    own displayed parts: match 8.34 plus context 11.54 is 19.88, and the row read 12.74. The two
    candidates above it, which had nothing to trim, added up exactly.

    So it is applied after everything, straight onto the final score.
    """
    src = io.open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()

    assert 'rec["final_score"] = float(rec.get("final_score") or 0.0) + rec["distinctive_points"]' in src, (
        "the comparison is no longer applied to the final score"
    )
    assert 'rec["context_score"] = float(rec.get("context_score") or 0.0) + rec["distinctive_points"]' not in src, (
        "the comparison is back in the context, where the trims below it will take it away again"
    )

    # Nothing may recompute the final score after this point, or it is lost again.
    applied = src.index('+ rec["distinctive_points"]')
    after = src[applied:]
    end = after.index("def _recommendation_order_key")
    assert 'final_score"] = float(rec.get("match_score")' not in after[:end], (
        "an adjustment still recomputes the final score after the comparison is applied"
    )


# ---------------------------------------------------------------- evidence mode

def _evidence_final(evidence, support, ev_scale=18.0, sup_scale=30.0):
    """The evidence-mode formula, as handlers applies it."""
    return ev_scale * evidence * (1.0 + support / sup_scale)


def test_support_cannot_outweigh_a_missing_error_match():
    """The defect evidence mode exists to remove.

    Additively, a candidate with a poor match and strong circumstantial agreement beats a strong
    match with weak agreement - which is exactly what happened: the correct fix had the HIGHEST
    similarity of four candidates and placed fourth, beaten by three fixes that touched a file
    the developer had changed.
    """
    right = _evidence_final(evidence=0.83, support=11.54)   # the echo fix, little support
    wrong = _evidence_final(evidence=0.03, support=14.28)   # config.xml, every support signal
    assert right > wrong
    assert right > 10 * wrong, (
        f"support still rescues a candidate the error does not match: {right:.2f} vs {wrong:.2f}"
    )


def test_support_still_separates_candidates_that_match_equally_well():
    """It is not discarded - it decides between candidates whose evidence is comparable."""
    more = _evidence_final(evidence=0.80, support=12.0)
    less = _evidence_final(evidence=0.80, support=2.0)
    assert more > less


def test_no_evidence_scores_nothing_however_much_agrees():
    assert _evidence_final(evidence=0.0, support=60.0) == 0.0


def test_an_exact_signature_match_takes_full_evidence():
    """The same normalised error IS the same error, so it is not scored on a diff."""
    src = io.open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()
    block = src[src.index("if _evidence_mode and str(query_error_text"):]
    block = block[:block.index("def _recommendation_order_key")]
    assert '_ev = 1.0' in block and 'match_type' in block, (
        "an exact signature match no longer takes full evidence"
    )


def test_the_mode_is_off_unless_asked_for():
    """Shipped behaviour cannot move on its own, and a typo means additive rather than evidence."""
    cfg = io.open(os.path.join(_ROOT, "src", "services", "recommendation_config.py"),
                  encoding="utf-8").read()
    assert 'data["scoringMode"] = _mode if _mode in ("additive", "evidence") else "additive"' in cfg
    assert 'str(data.get("scoringMode") or "additive")' in cfg
