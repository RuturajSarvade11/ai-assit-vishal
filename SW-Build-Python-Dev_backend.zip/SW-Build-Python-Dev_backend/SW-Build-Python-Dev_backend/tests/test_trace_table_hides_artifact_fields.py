"""The trace TABLE does not show the matched artifact file or its similarity.

Asked for directly (08-Oct): the Recommended Solution column carried a "debug.log" chip and the
Similarity column a second line "art 0.235". Both come from two per-candidate fields of the
stored trace - artifact_matched and artifact_match_similarity. The fields stay stored (the
explain endpoint reads the row directly and keeps its deeper breakdown); only the two table
endpoints leave them out.
"""
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

import src.routes.route as route_module  # noqa: E402
from src.utils import project_details, recommendation_trace  # noqa: E402


def _trace():
    return {"trace_id": "t1", "project_name": "Project A", "candidates": [
        {"request_id": "r1", "similarity": "0.53", "match_score": "6.41",
         "artifact_match_similarity": "0.235",
         "artifact_matched": {"file_name": "debug.log", "s3_key": "k", "url": "/download-artifact/k"},
         "similarity_components": {"combined": "0.53"},
         "solution_lines": ["work/tools/config.xml :: <Compiler>CTC</Compiler>"]},
        {"request_id": "r2", "similarity": "0.81", "solution_lines": ["fix.py :: x"]},
        "not-a-dict",
    ]}


def test_for_table_drops_only_the_two_artifact_display_fields():
    out = recommendation_trace.for_table([_trace()])
    c1, c2, c3 = out[0]["candidates"]
    assert "artifact_matched" not in c1 and "artifact_match_similarity" not in c1
    assert c1["similarity"] == "0.53" and c1["match_score"] == "6.41"
    assert c1["similarity_components"] == {"combined": "0.53"}, "the deeper breakdown is untouched"
    assert c2 == {"request_id": "r2", "similarity": "0.81", "solution_lines": ["fix.py :: x"]}
    assert "solution_missing" not in c1 and "solution_missing" not in c2, "rows WITH a solution stay plain"
    assert c3 == "not-a-dict"


def test_for_table_does_not_mutate_the_stored_row():
    stored = _trace()
    recommendation_trace.for_table([stored])
    assert "artifact_matched" in stored["candidates"][0], "the stored trace must keep its fields"


def test_for_table_passes_malformed_rows_through():
    rows = [None, "x", {"no": "candidates"}, {"candidates": "not-a-list"}]
    assert recommendation_trace.for_table(rows) == rows
    assert recommendation_trace.for_table(None) == []


def test_the_recent_traces_endpoint_hides_the_fields(monkeypatch):
    monkeypatch.setattr(recommendation_trace, "list_recent", lambda limit: [_trace()])
    with route_module.app.test_request_context("/recommendation-traces/recent"):
        response, status = route_module.recommendation_traces_recent.__wrapped__()
    assert status == 200
    cand = response.get_json()["traces"][0]["candidates"][0]
    assert "artifact_matched" not in cand and "artifact_match_similarity" not in cand


def test_the_per_request_trace_endpoint_hides_the_fields(monkeypatch):
    monkeypatch.setattr(recommendation_trace, "get_traces_for_request", lambda rid: [_trace()])
    monkeypatch.setattr(project_details, "get_token_usage_for_request", lambda rid: {
        "prompt_tokens": 0, "output_tokens": 0, "total_tokens": 0, "llm_calls": 1})
    with route_module.app.test_request_context("/recommendation-trace/r1"):
        response, status = route_module.recommendation_trace_for_request.__wrapped__("r1")
    assert status == 200
    cand = response.get_json()["traces"][0]["candidates"][0]
    assert "artifact_matched" not in cand and "artifact_match_similarity" not in cand


# ------------------------------------------------- a candidate with nothing to recommend is labelled

def test_a_candidate_with_no_solution_is_labelled_not_dashed():
    """Orphan vectors (stored error, solution record gone) showed "-" in Task and Recommended
    Solution. Option 2, chosen 09-Oct: label them, keep them listed (they sort last)."""
    trace = {"candidates": [
        {"request_id": "orphan", "task_name": "", "solution_lines": [], "similarity": "0.72"},
        {"request_id": "orphan2", "solution_lines": ["", "  "]},
        {"request_id": "fix", "task_name": ":TARGETS:master:task3",
         "solution_lines": ["work/tools/config.xml :: <Compiler>CTC</Compiler>"]},
        {"request_id": "task-known", "task_name": ":TARGETS:master:task3", "solution_lines": []},
    ]}
    o1, o2, fix, tk = recommendation_trace.for_table([trace])[0]["candidates"]
    label = recommendation_trace.SOLUTION_MISSING_LABEL
    assert o1["solution_missing"] is True
    assert o1["solution_lines"] == [label] and o1["task_name"] == label
    assert o1["similarity"] == "0.72", "nothing else on the row changes"
    assert o2["solution_lines"] == [label], "blank lines count as no solution"
    assert "solution_missing" not in fix and fix["solution_lines"][0].startswith("work/tools/")
    assert tk["solution_lines"] == [label] and tk["task_name"] == ":TARGETS:master:task3", (
        "a known task is kept; only the empty column takes the label")
    assert "orphan" in {c["request_id"] for c in recommendation_trace.for_table([trace])[0]["candidates"]}, (
        "the row is listed, not hidden")
