"""Derived customer/project identity (29-Sep review).

THE CHANGE: retrieval scope stops coming from a hand-filed group and starts being read out of the
project name, because filing every new project by hand does not survive a worldwide rollout.

    1GHIO_000U0_TD5  ->  customer 1g / project hio

These tests pin the three things that would make the change unsafe:
  - it is OFF by default, so an unreviewed deployment behaves exactly as it does today;
  - a name that does NOT fit the convention derives nothing and keeps today's behaviour, rather
    than being guessed into somebody else's customer (a confidentiality problem);
  - the DISPLAY group stays manual, because management reads the dashboard by family name.
"""
import os
import re
import sys
import types

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# Same single-import stubbing as test_scope_resolution: the rules under test are pure logic, so the
# suite must not need AWS. Restored right after the import for the reason documented there - a stub
# left in sys.modules silently becomes THE module for every file collected afterwards.
_fake_db = types.ModuleType("src.databases.database")
_fake_db.get_dynamodb = lambda *a, **k: None
_real_db = sys.modules.get("src.databases.database")
sys.modules["src.databases.database"] = _fake_db

_fake_cfg = types.ModuleType("src.configurations.config")
for _attr in ("DYNAMODB_TABLE_SUFFIX", "DYNAMODB_REGION", "DYNAMODB_ENDPOINT"):
    setattr(_fake_cfg, _attr, "")
_fake_pkg = types.ModuleType("src.configurations")
_fake_pkg.config = _fake_cfg
sys.modules.setdefault("src.configurations", _fake_pkg)
_real_cfg = sys.modules.get("src.configurations.config")
sys.modules["src.configurations.config"] = _fake_cfg
try:
    from src.services import project_groups as pg
    from src.services import project_naming as pn
finally:
    if _real_cfg is not None:
        sys.modules["src.configurations.config"] = _real_cfg
    else:
        sys.modules.pop("src.configurations.config", None)
        if sys.modules.get("src.configurations") is _fake_pkg:
            sys.modules.pop("src.configurations", None)
    if _real_db is not None:
        sys.modules["src.databases.database"] = _real_db
    else:
        sys.modules.pop("src.databases.database", None)


ALL = ["1ghio_000u0_000", "1ghio_111u0_000", "1gab1_222_td5", "4p231_ptp4lite", "testgbe"]


# The convention under test asserts the SEPARATOR after the prefix, which is what distinguishes a
# conventional name from any other string. This is the shape the real Schaeffler expression needs.
CONVENTION = pn.EXAMPLE_REGEX


def _convention(enabled, regex=None):
    """Pin the stored convention without touching DynamoDB."""
    pn._cache["data"] = {
        "namingEnabled": 1 if enabled else 0,
        "namingRegex": CONVENTION if regex is None else regex,
    }
    pn._cache["ts"] = 9e18
    pn._identity_cache.clear()
    pg._scope_cache.clear()


def _groups(defs, overrides=None):
    pg.list_group_defs = lambda: defs
    pg.get_overrides = lambda: (overrides or {})
    pg._scope_cache.clear()


def test_identity_is_read_out_of_the_name():
    _convention(True)
    assert pn.derive_identity("1GHIO_000U0_TD5") == ("1g", "hio")
    assert pn.derive_identity("4P231_PTP4LITE") == ("4p", "231")


def test_case_does_not_change_the_identity():
    _convention(True)
    assert pn.derive_identity("1GHIO_000U0") == pn.derive_identity("1ghio_000u0") == ("1g", "hio")


def test_the_separator_is_what_bounds_the_prefix():
    """The defect this pins: with separators stripped, every name was one token, a prefix
    expression matched all of them, and testgbe was read as customer "te"."""
    _convention(True)
    assert pn.derive_identity("testgbe") == ("", "")
    assert pn.derive_identity("hm103") == ("hm", "103")        # end-of-string is a boundary too
    assert pn.derive_identity("4p231_ptp4lite") == ("4p", "231")


def test_off_by_default():
    """An unreviewed deployment must behave exactly as it does today."""
    assert pn.DEFAULTS["namingEnabled"] == 0


def test_no_convention_is_configured_by_default():
    """There must be no guessed default. A prefix expression matches every name, so shipping one
    would put unrelated projects in a shared customer the moment the feature was switched on."""
    assert pn.DEFAULTS["namingRegex"] == ""
    _convention(True, regex="")
    assert pn.derive_identity("1ghio_000u0_000") == ("", "")


def test_an_unbounded_prefix_expression_over_matches():
    """Pins the hazard, so no future edit drops the boundary: without it, testgbe is read as
    customer "te" and shares its evidence with any other te* project in the estate."""
    _convention(True, regex=r"^(?P<customer>[a-z0-9]{2})(?P<project>[a-z0-9]{3})")
    assert pn.derive_identity("testgbe") == ("te", "stg")


def test_derived_customer_widens_without_any_group_being_defined():
    """The maintenance overhead this removes: no admin filed these, and they still share."""
    _convention(True)
    _groups([])                                    # nothing configured by hand at all
    members, mode = pg.resolve_scope_projects("1ghio_000u0_000", ALL)
    assert mode == "customer", mode
    assert members == ["1gab1_222_td5", "1ghio_000u0_000", "1ghio_111u0_000"], members


def test_a_different_customer_is_never_pulled_in():
    _convention(True)
    _groups([])
    members, _mode = pg.resolve_scope_projects("4p231_ptp4lite", ALL)
    assert members == ["4p231_ptp4lite"], members


def test_a_name_outside_the_convention_keeps_todays_behaviour():
    """testgbe does not fit the convention. It must not be guessed into a customer."""
    _convention(True)
    _groups([])
    assert pn.derive_identity("testgbe") == ("", "")
    members, mode = pg.resolve_scope_projects("testgbe", ALL)
    assert mode == "project", mode
    assert members == ["testgbe"], members


def test_convention_off_falls_back_to_the_manual_group():
    _convention(False)
    _groups([{"group_name": "HIP26", "project_pattern": "1GHIO*"}])
    members, mode = pg.resolve_scope_projects("1ghio_000u0_000", ALL)
    assert mode == "customer", mode
    # The manual glob catches only 1GHIO*, so 1gab1 stays out - proof the derived path is not on.
    assert members == ["1ghio_000u0_000", "1ghio_111u0_000"], members


def test_display_group_stays_manual_when_the_convention_is_on():
    """Management reads family names. Scope changed; the label did not."""
    _convention(True)
    _groups([{"group_name": "HIP26", "project_pattern": "1GHIO*"}])
    assert pg.resolve_group("1ghio_000u0_000") == "HIP26"
    assert pg.resolve_scope_group("1ghio_000u0_000") == ("1g", "derived")


def test_a_regex_without_the_named_groups_is_rejected_on_write():
    """A bad expression must fail at write time, not derive nothing for the whole estate."""
    _convention(True)
    for bad in (r"^(..)(...)", r"^(?P<customer>..)", r"^(?P<customer>..)(?P<project>[", ""):
        try:
            pn.set_config(regex=bad)
        except ValueError:
            continue
        raise AssertionError(f"accepted an unusable namingRegex: {bad!r}")


def test_example_regex_reproduces_the_examples_given_on_the_call():
    """EXAMPLE_REGEX documents the call's examples. It is never active - pin only what it claims."""
    rx = re.compile(pn.EXAMPLE_REGEX)
    for name, customer, project in (("1ghio_000u0", "1g", "hio"),
                                    ("4p231_ptp4lite", "4p", "231"),
                                    ("vwa22_x", "vw", "a22"),
                                    ("hm103", "hm", "103")):
        match = rx.match(name)
        assert match, name
        assert match.group("customer") == customer and match.group("project") == project, name
