"""The gate's decision must reach the Copilot output, not just the panel.

THE DEFECT THIS PINS. `_evaluate_recommendation_strength` returns exactly three values -
"strong", "below_threshold" and "none". Two places that format the text Copilot is given tested
for a fourth value, "weak", that nothing anywhere assigns:

    if match_status in {"weak", "none"}:        # handlers.py:8205 and :8731

So a gate decision of "below_threshold" - candidates existed but none scored high enough - did not
match, and Copilot was handed the ordinary "Solution 1" template: a weak match presented as a real
answer. The panel was never affected, because it reads `is_weak_match` rather than this comparison.

It was a missed rename, and it survived because nothing tied the set of statuses the gate PRODUCES
to the set the formatter ACCEPTS. That is what these tests do.
"""
import ast
import io
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_HANDLERS = os.path.join(_ROOT, "src", "services", "handlers.py")


def _source():
    return io.open(_HANDLERS, encoding="utf-8-sig").read()


def _statuses_the_gate_returns():
    """Every literal assigned to "match_status" inside _evaluate_recommendation_strength."""
    tree = ast.parse(_source())
    fn = next(
        (n for n in ast.walk(tree)
         if isinstance(n, ast.FunctionDef) and n.name == "_evaluate_recommendation_strength"),
        None,
    )
    assert fn is not None, "_evaluate_recommendation_strength is gone - the gate was renamed"

    found = set()
    for node in ast.walk(fn):
        if isinstance(node, ast.Dict):
            for key, value in zip(node.keys, node.values):
                if (isinstance(key, ast.Constant) and key.value == "match_status"
                        and isinstance(value, ast.Constant) and isinstance(value.value, str)):
                    found.add(value.value)
    return found


def _sets_the_copilot_formatters_accept():
    """Every `match_status in {...}` set literal in the module, as a list of frozensets."""
    tree = ast.parse(_source())
    out = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Compare) or not node.ops:
            continue
        if not isinstance(node.ops[0], ast.In):
            continue
        left = node.left
        if not (isinstance(left, ast.Name) and left.id == "match_status"):
            continue
        right = node.comparators[0]
        if isinstance(right, ast.Set):
            out.append(frozenset(
                e.value for e in right.elts
                if isinstance(e, ast.Constant) and isinstance(e.value, str)
            ))
    return out


def test_the_gate_still_returns_the_three_known_statuses():
    """If a new status is added, the sets below must be revisited - this fails to make that happen."""
    assert _statuses_the_gate_returns() == {"strong", "below_threshold", "none"}


def test_every_not_strong_status_reaches_the_copilot_no_match_path():
    """Each status meaning "do not present this as an answer" must be in every membership test.

    The gate produces three values; "strong" is the only one that should render as a real
    recommendation. Every other one has to be caught, or Copilot shows a weak match as a solution.
    """
    not_strong = _statuses_the_gate_returns() - {"strong"}
    sets_found = _sets_the_copilot_formatters_accept()
    assert sets_found, "no `match_status in {...}` test found - the guard was removed entirely"

    for accepted in sets_found:
        missing = not_strong - accepted
        assert not missing, (
            f"a match_status the gate can return is not caught: {sorted(missing)}. "
            f"The test accepts {sorted(accepted)}. A status the gate produces but the formatter "
            f"does not catch means Copilot renders it as a normal recommendation."
        )


def test_no_membership_test_relies_only_on_a_status_nothing_assigns():
    """"weak" is accepted for older callers, but a set that contains ONLY dead values is the bug."""
    produced = _statuses_the_gate_returns()
    for accepted in _sets_the_copilot_formatters_accept():
        assert accepted & produced, (
            f"the set {sorted(accepted)} matches nothing the gate can return - "
            f"it is dead and the not-strong path is unreachable"
        )
