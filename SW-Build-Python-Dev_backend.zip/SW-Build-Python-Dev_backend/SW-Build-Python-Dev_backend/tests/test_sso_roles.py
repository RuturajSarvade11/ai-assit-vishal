"""SSO role rules: the role comes from OUR store keyed on an HMAC of the Schaeffler ID —
the plain ID is never stored; the admin screen sees only a masked form.

Run:  python tests/test_sso_roles.py   (loads the real source, no server deps needed)
"""
import ast
import hashlib
import hmac
import os
import sys

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load(func_names):
    path = os.path.join(_REPO, "src", "auth", "sso_roles.py")
    with open(path, "r", encoding="utf-8-sig") as fh:
        tree = ast.parse(fh.read())
    ns = {"hmac": hmac, "hashlib": hashlib, "os": os, "_KEY_PREFIX": "sso#"}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in func_names:
            exec(compile(ast.Module(body=[node], type_ignores=[]), path, "exec"), ns)
    return ns


ns = _load({"_norm", "_hash_secret", "_hash_id", "_row_key", "_mask_id"})


def test_hash_is_deterministic_and_case_insensitive():
    a = ns["_hash_id"]("SG586096@user.schaeffler.com")
    b = ns["_hash_id"]("  sg586096@user.schaeffler.com  ")
    assert a == b and len(a) == 64


def test_different_ids_different_hashes():
    assert ns["_hash_id"]("sg586096@user.schaeffler.com") != ns["_hash_id"]("sg586097@user.schaeffler.com")


def test_row_key_never_contains_the_id():
    key = ns["_row_key"]("sg586096@user.schaeffler.com")
    assert key.startswith("sso#") and "sg586096" not in key and "@" not in key


def test_mask_hides_most_of_the_local_part():
    masked = ns["_mask_id"]("sg586096@user.schaeffler.com")
    assert masked == "sg58***@user.schaeffler.com"
    assert "sg586096" not in masked


def test_mask_short_and_empty_ids():
    assert ns["_mask_id"]("ab@x.com") == "a***@x.com"
    assert ns["_mask_id"]("") == ""


if __name__ == "__main__":
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS  {name}")
            except AssertionError:
                failed += 1
                print(f"FAIL  {name}")
    sys.exit(1 if failed else 0)
