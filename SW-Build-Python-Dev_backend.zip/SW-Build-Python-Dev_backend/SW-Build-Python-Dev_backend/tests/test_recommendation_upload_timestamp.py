from src.routes.route import _build_report_error_output


def test_report_recommendation_exposes_original_upload_timestamp():
    output = _build_report_error_output(
        "testgbe",
        {
            "recommendations": [{
                "request_id": "request-1",
                "solution": [],
                "created_date": "2026-10-06T10:00:00Z",
                "uploaded_at": "2024-03-02T08:15:00Z",
            }],
            "document_context": {},
            "context_enrichment": {},
        },
    )

    recommendation = output["recommendations"][0]
    assert recommendation["uploaded_at"] == "2024-03-02T08:15:00Z"
    assert recommendation["created_date"] == "2026-10-06T10:00:00Z"