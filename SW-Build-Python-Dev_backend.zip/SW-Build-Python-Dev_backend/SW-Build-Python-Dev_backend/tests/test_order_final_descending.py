"""ONE order, by final score, descending - in the webview and in the trace alike.

Asked for directly (08-Oct):
  1. results are always sorted by the final score, descending;
  2. the webview (report-error API) and the Recommendation Trace list the same order;
  3. thumbs up/down count only as a tie-break between results with the same similarity -
     similarity stays the ranking factor, feedback never outranks it.

What changed to make that true: the downvote sink and the exact-signature tier no longer sit
above the final score in the visible order; the dedup/pool key no longer puts the match-type
tier or the same-error vote link ahead of the score; the trace snapshot is taken in the order
the webview receives (shown first, in order, then the rest); and the LLM pick is badged where it
stands instead of being moved to Candidate 1.
"""
import io
import os
import sys

import pytest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

from src.services import handlers  # noqa: E402


def _src():
    return io.open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8-sig").read()


def _rec(rid, final, sim=None, up=0, down=0, match_type="semantic", solution=True):
    return {"request_id": rid, "project_name": "testgbe", "final_score": final, "similarity": sim,
            "document": "error x", "task_name": ":TARGETS:master:task3",
            "solution": [{"file": "config.xml"}] if solution else [], "thumbs_up": up,
            "thumbs_down": down, "match_type": match_type}


def _order(pool, monkeypatch):
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: {"downvoteSinkMinVotes": 1})
    out = handlers._rerank_recommendations_for_relevance(
        pool, query_text="error x", query_task_path=":TARGETS:master:task3", query_project="testgbe")
    return [r["request_id"] for r in out], out


# ------------------------------------------------------------------ 1. final score, descending

def test_the_order_is_the_final_score_descending(monkeypatch):
    ids, _ = _order([_rec("c", 10.0), _rec("a", 30.0), _rec("b", 20.0)], monkeypatch)
    assert ids == ["a", "b", "c"]


def test_a_downvoted_fix_keeps_its_place_on_score(monkeypatch):
    """The sink is gone: three downvotes on the best-scoring fix move it nowhere."""
    ids, out = _order([_rec("best", 30.0, up=0, down=3), _rec("mid", 20.0), _rec("low", 10.0)], monkeypatch)
    assert ids == ["best", "mid", "low"]
    assert out[0]["rank_factors"]["downvoted"] is True
    assert out[0]["feedback_influence"]["delta"] == 0
    assert out[0]["feedback_influence"]["sunk"] is False


def test_an_exact_match_leads_on_score_not_on_a_tier(monkeypatch):
    """An exact signature earns the exact base and similarity 1.0, so it leads on score. It is
    no longer a tier that outranks a higher final score."""
    ids, _ = _order([_rec("exact", 18.0, sim=1.0, match_type="exact"), _rec("sem", 25.0, sim=0.8)], monkeypatch)
    assert ids == ["sem", "exact"]


def test_nothing_to_recommend_sorts_last(monkeypatch):
    ids, _ = _order([_rec("bare", 99.0, solution=False), _rec("fix", 5.0)], monkeypatch)
    assert ids == ["fix", "bare"]


# ------------------------------------------------------------------ 3. feedback as a tie-break only

def test_votes_decide_only_when_score_and_similarity_tie(monkeypatch):
    tie = [_rec("unvoted", 20.0, sim=0.8), _rec("voted", 20.0, sim=0.8, up=2)]
    ids, out = _order(tie, monkeypatch)
    assert ids == ["voted", "unvoted"]
    assert out[0]["feedback_influence"]["delta"] == 1

    closer = [_rec("loved", 20.0, sim=0.70, up=9), _rec("closer", 20.0, sim=0.81)]
    ids, out = _order(closer, monkeypatch)
    assert ids == ["closer", "loved"], "similarity breaks a score tie before any vote"
    assert all(r["feedback_influence"]["delta"] == 0 for r in out)

    scored = [_rec("loved", 19.0, sim=0.9, up=9), _rec("better", 20.0, sim=0.5)]
    ids, _ = _order(scored, monkeypatch)
    assert ids == ["better", "loved"], "votes never lift a lower final score"


def test_the_same_project_tie_break_still_follows_the_votes(monkeypatch):
    ids, _ = _order([_rec("sib", 20.0, sim=0.8) | {"project_name": "sibling"},
                     _rec("own", 20.0, sim=0.8)], monkeypatch)
    assert ids == ["own", "sib"]


# ------------------------------------------------------------------ 2. one order for both screens

def test_the_trace_snapshot_is_taken_in_the_order_the_webview_receives():
    src = _src()
    i = src.index("shown_for_trace = visible + weak_visible")
    block = src[i:i + 1200]
    assert "_trace_order = shown_for_trace + [r for r in ordered" in block
    assert "for rec in _trace_order[:10]:" in block
    assert "for rec in ordered[:10]:" not in block


def test_the_llm_pick_is_badged_in_place_and_never_moved():
    src = _src()
    assert "recs.insert(0, recs.pop(chosen_idx))" not in src, "the pick is moved to Candidate 1 again"
    assert '_chosen["is_recommended"] = True' in src


def test_the_dedup_key_puts_no_feedback_or_type_tier_ahead_of_the_score():
    src = _src().replace("\r\n", "\n")
    i = src.index("def _recommendation_order_key")
    block = src[i:src.index("deduped: List[Dict] = []", i)]
    ret = block[block.index("return ("):]
    terms = [ln.strip().split(",")[0] for ln in ret.splitlines()[1:] if ln.strip() and not ln.strip().startswith(")")]
    # The pool cut follows the score, like the visible order: the live task's own instance of an
    # identical fix wins only WITHIN a tie (it used to sit ahead of the score, and with more than
    # top_k candidates a same-task row pushed a higher-scoring other-task row out of the pool).
    assert terms == ["missing_solution", "final_score", "similarity", "task_mismatch",
                     "net_feedback", "link_boost", "recency_days", "request_id"], terms
    assert "match_priority" not in block


def test_no_term_of_the_visible_key_sits_above_the_final_score_except_nothing_to_recommend():
    src = _src()
    i = src.index("keyed.append((no_solution, -round(_final, 3)")
    assert i > 0
    line = src[i:src.index("\n", i)]
    assert line.startswith("keyed.append((no_solution, -round(_final, 3), -round(_sim, 6), -(up - down),")
