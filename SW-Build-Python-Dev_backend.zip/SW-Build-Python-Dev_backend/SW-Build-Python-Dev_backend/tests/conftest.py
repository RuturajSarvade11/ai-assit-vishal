"""One environment for the whole suite, set before any test module is imported.

src/services/handlers.py builds an Azure OpenAI client at IMPORT time, so importing it without
credentials raises before a single test runs. Several test files worked around that individually,
which left the suite order-dependent: whichever file was collected first happened to set the
variables, and the rest imported successfully by luck. Adding test files reordered collection and
sixteen tests in test_trace_explain.py stopped collecting at all - they had not changed.

pytest imports conftest.py before any test module, so these are in place for every file however
the suite is ordered, run whole or one file at a time.

Dummy values. Nothing here reaches a network: the client is constructed and never called, and a
test that does need a real response mocks it.
"""
import os

for _name, _value in (
    ("OPENAI_API_VERSION", "2024-02-01"),
    ("AZURE_OPENAI_API_KEY", "test-key-not-used"),
    ("AZURE_OPENAI_ENDPOINT", "https://test.invalid/"),
    ("OPENAI_API_KEY", "test-key-not-used"),
    ("OAI_API_VERSION", "2024-02-01"),
):
    os.environ.setdefault(_name, _value)
