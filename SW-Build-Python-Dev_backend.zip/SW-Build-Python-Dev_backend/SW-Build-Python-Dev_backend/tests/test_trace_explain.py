"""The on-demand breakdown of one candidate's context score.

The breakdown goes one level deeper than the trace - how each step and each number came
about - and the values are calculated at click time rather than kept pre-calculated.

The point of these tests is the property that makes the page trustworthy: the numbers come from
the SAME function that produced the score, so they cannot drift from it. A second implementation
would agree most of the time and disagree exactly when something is wrong - which is the only
moment anybody opens this page.
"""
import sys
import types
import pytest

from src.services import handlers


TRACE = {
    "trace_id": "t1",
    "query_error": "cannot find symbol: acm_init",
    "task_path": ":TARGETS:dev:task4",
    "changed_files": ["config.xml"],
    "query_context": {
        "task_paths": [":TARGETS:dev:task4"],
        "file_names": ["config.xml"],
        "tokens": ["python", "3.10.0", "gcc"],
    },
    "candidates": [{
        "request_id": "r1",
        "task_name": ":TARGETS:dev:task4",
        "file_name": "config.xml",
        "match_type": "semantic",
        "similarity": "0.81",
        "context_score": "11.0",
        "final_score": "20.72",
        "context_components": {"base": "11.0", "patch": "0.0", "success": "0.0"},
        "base_matches": {"matched_files": ["config.xml"],
                         "matched_tokens": ["3.10.0", "python"]},
        "artifact_match_similarity": "0.715",
        "evidence_similarity": "0.76",
        "match_score": "9.72",
        "thumbs_up": 4,
        "thumbs_down": 1,
        "adapter_influence": {"similarity_base": "0.71", "similarity_with_adapter": "0.78",
                              "similarity_delta": "0.07", "base_rank": "3",
                              "learned_rank": "1"},
    }],
    "adapter_state": {"reason": ""},
}

PAYLOAD = {"task_name": ":TARGETS:dev:task4"}
INSTANCES = [{"task_path": ":TARGETS:dev:task4", "file_name": "config.xml",
              "config_tokens": ["python", "3.10.0"]}]


@pytest.fixture(autouse=True)
def _stub(monkeypatch):
    fake = types.ModuleType("src.utils.recommendation_trace")
    fake.get_traces_for_request = lambda rid: [TRACE] if rid == "t1" else []
    monkeypatch.setitem(sys.modules, "src.utils.recommendation_trace", fake)
    # AND on the package itself. The code under test does `from src.utils import
    # recommendation_trace` inside the function, which resolves through the PACKAGE attribute
    # whenever that attribute already exists - sys.modules is only consulted when it does not.
    # Any other test file importing the real module at its top level sets that attribute, and
    # this fake was then bypassed: these sixteen tests began failing the moment two new test
    # files did exactly that, having changed nothing themselves.
    import src.utils as _src_utils
    monkeypatch.setattr(_src_utils, "recommendation_trace", fake, raising=False)
    monkeypatch.setattr(handlers, "get_final_build_payload", lambda rid: PAYLOAD)
    monkeypatch.setattr(handlers, "get_fix_instances", lambda rid: INSTANCES)
    monkeypatch.setattr(handlers, "_rc_get_config_cached",
                        lambda: {"baseTaskWeight": 3.0, "baseFileWeight": 6.0,
                                 "baseTokenWeight": 4.0})
    monkeypatch.setattr(handlers, "_recommended_hit_count", lambda payload: 0)


def test_a_missing_trace_says_so_rather_than_returning_an_empty_page():
    assert handlers.handle_trace_explain("nope", "r1")["success"] is False


def test_a_candidate_that_is_not_on_the_trace_is_refused():
    """Opening the breakdown for the wrong row would produce a page of numbers that belong to
    nothing - worse than an error, because it looks like an answer."""
    out = handlers.handle_trace_explain("t1", "r-other")
    assert out["success"] is False
    assert "not on this trace" in out["error"]


def test_the_parts_add_up_to_the_number_they_explain():
    """The whole claim of the page. If these ever disagree, the page is lying about the score."""
    out = handlers.handle_trace_explain("t1", "r1")
    assert out["success"] is True
    assert sum(p["points"] for p in out["parts"]) == pytest.approx(out["recomputed_base"])
    assert out["recomputed_base"] == pytest.approx(3.0 + 6.0 + 2.0)


def test_each_part_shows_what_was_compared_not_just_the_result():
    """"How did this become 4.00" cannot be answered by a description of the rule. The actual
    values on both sides have to be on the page."""
    out = handlers.handle_trace_explain("t1", "r1")
    tokens = next(p for p in out["parts"] if p["part"] == "Configuration tokens")
    assert tokens["compared"]["values in this failure"] == ["python", "3.10.0", "gcc"]
    assert tokens["compared"]["values in this fix"] == ["3.10.0", "python"]
    assert tokens["matched"] == ["3.10.0", "python"]
    assert tokens["points"] == 2.0

    files = next(p for p in out["parts"] if p["part"] == "Same file")
    assert files["matched"] == ["config.xml"]
    assert files["points"] == 6.0


def test_the_rules_quote_the_weights_actually_in_force():
    """An administrator can change these without a release. A page that printed the release-time
    defaults would explain a scoring system nobody is running."""
    out = handlers.handle_trace_explain("t1", "r1")
    task = next(p for p in out["parts"] if p["part"] == "Same task")
    assert "3 points" in task["rule"]


def test_a_changed_weight_is_reported_as_drift_never_hidden(monkeypatch):
    """The honest consequence of computing on request: the answer reflects today's settings.
    Two numbers disagreeing in silence is the failure this page exists to prevent."""
    monkeypatch.setattr(handlers, "_rc_get_config_cached",
                        lambda: {"baseTaskWeight": 30.0, "baseFileWeight": 6.0,
                                 "baseTokenWeight": 4.0})
    out = handlers.handle_trace_explain("t1", "r1")
    assert out["drift"]["differs"] is True
    assert out["drift"]["base_when_recommended"] == 11.0
    assert out["drift"]["base_now"] == 38.0
    assert out["drift"]["note"]


def test_matching_weights_report_no_drift():
    out = handlers.handle_trace_explain("t1", "r1")
    assert out["drift"]["differs"] is False
    assert out["drift"]["note"] == ""


def test_the_recorded_matches_are_compared_with_the_live_ones():
    """Level three is recomputed, but the trace already recorded which files and tokens hit. When
    the two disagree, something changed underneath - the page has to say which is which."""
    out = handlers.handle_trace_explain("t1", "r1")
    tokens = next(p for p in out["parts"] if p["part"] == "Configuration tokens")
    assert tokens["matched_when_recommended"] == ["3.10.0", "python"]
    assert tokens["same_as_when_recommended"] is True

    task = next(p for p in out["parts"] if p["part"] == "Same task")
    assert task["matched"] == [":targets:dev:task4"]
    assert task["matched_when_recommended"] == []
    assert task["same_as_when_recommended"] is False


def test_the_stored_trace_is_not_modified_while_being_explained():
    """The trace rows are cached and shared. A breakdown that wrote into the row it was reading
    would corrupt what every later reader sees - and it would do so invisibly, because the page
    that caused it would still look right."""
    import copy
    before = copy.deepcopy(TRACE)
    handlers.handle_trace_explain("t1", "r1")
    assert TRACE == before


def test_a_lost_payload_still_produces_a_page(monkeypatch):
    """Storage can fail. A breakdown that shows zero points and says so is more useful than a
    500 in the middle of an investigation."""
    def _gone(rid):
        raise RuntimeError("gone")
    monkeypatch.setattr(handlers, "get_final_build_payload", _gone)
    monkeypatch.setattr(handlers, "get_fix_instances", _gone)
    out = handlers.handle_trace_explain("t1", "r1")
    assert out["success"] is True
    assert out["recomputed_base"] == 0.0


# ------------------------------------------------------- everything on one page

def test_the_page_carries_the_evidence_the_expand_panel_used_to_show():
    """The expand panel was replaced by a clickable icon that opens a separate page, because
    the content is too large for an expand panel. So the separate page has
    to carry what the panel carried, or the information is simply lost."""
    out = handlers.handle_trace_explain("t1", "r1")
    assert out["evidence"]["error_similarity"] == "0.81"
    assert out["evidence"]["artifact_similarity"] == "0.715"
    assert out["evidence"]["combined_evidence"] == "0.76"
    assert out["evidence"]["match_type"] == "semantic"
    assert out["votes"] == {"up": 4, "down": 1, "validated_for_error": 0}


def test_the_adapter_block_reports_both_similarities_and_the_change():
    """Two columns, without the adapter and with it, so its
    influence on the similarity is visible rather than asserted."""
    out = handlers.handle_trace_explain("t1", "r1")
    assert out["adapter"]["available"] is True
    assert out["adapter"]["similarity_without"] == pytest.approx(0.71)
    assert out["adapter"]["similarity_with"] == pytest.approx(0.78)
    assert out["adapter"]["change"] == pytest.approx(0.07)
    assert out["adapter"]["base_rank"] == "3"


def test_an_absent_adapter_says_why_instead_of_showing_dashes():
    """Five dashes read as broken, and after several helpful votes the natural conclusion is that
    the votes should have filled them in. They cannot - and the line says so."""
    trace = dict(TRACE)
    trace["candidates"] = [dict(TRACE["candidates"][0], adapter_influence={},
                                match_type="semantic")]
    trace["adapter_state"] = {"reason": "not_trained"}
    fake = sys.modules["src.utils.recommendation_trace"]
    fake.get_traces_for_request = lambda rid: [trace] if rid == "t1" else []
    out = handlers.handle_trace_explain("t1", "r1")
    assert out["adapter"]["available"] is False
    assert "No adapter has been trained" in out["adapter"]["reason"]


def test_a_task_match_is_told_the_adapter_never_saw_it():
    """The commonest confusion on this screen. A candidate found by task identity was never in
    the adapter's space at all, which is a different fact from "the adapter did nothing"."""
    trace = dict(TRACE)
    trace["candidates"] = [dict(TRACE["candidates"][0], adapter_influence={}, match_type="task")]
    fake = sys.modules["src.utils.recommendation_trace"]
    fake.get_traces_for_request = lambda rid: [trace] if rid == "t1" else []
    out = handlers.handle_trace_explain("t1", "r1")
    assert "found by task identity" in out["adapter"]["reason"]
    assert "Only semantic matches" in out["adapter"]["reason"]


# --------------------------------------------- the adapter, followed to the final score

def _cfg_on(monkeypatch, **over):
    cfg = {"baseTaskWeight": 3.0, "baseFileWeight": 6.0, "baseTokenWeight": 4.0,
           "evidenceSimilarityWeight": 0.5, "semanticMatchBase": 12.0,
           "similarityWeightedScoring": True}
    cfg.update(over)
    monkeypatch.setattr(handlers, "_rc_get_config_cached", lambda: cfg)


def test_the_adapter_is_followed_through_match_to_the_final_score(monkeypatch):
    """The influence is shown where it lands, not asserted. Two similarity
    numbers on their own do not answer "so what" - the same 0.07 is worth nothing on a candidate
    whose context already decided the order, and worth a place on one where it did not."""
    _cfg_on(monkeypatch)
    chain = handlers.handle_trace_explain("t1", "r1")["adapter"]["chain"]
    assert chain["available"] is True

    # The relationships, not transcribed constants: the page is only trustworthy if each step
    # follows from the one before it, and pinning rounded literals would test the rounding.
    #   combined = the ONE blend the ranking used (_blend_evidence): this stored row carries no
    #   contrast share, so the candidates' artifacts agreed too closely to decide and the error
    #   cosine stands;  match = base x combined;  final = match + context
    for leg, error_sim in ((chain["without"], 0.71), (chain["with"], 0.78)):
        assert leg["combined_evidence"] == pytest.approx(error_sim, abs=1e-3)
        assert leg["match_points"] == pytest.approx(12 * leg["combined_evidence"], abs=0.02)
        assert leg["final"] == pytest.approx(leg["match_points"] + leg["context"], abs=0.01)

    # A better similarity has to reach the final score, or the two columns explain nothing.
    assert chain["with"]["final"] > chain["without"]["final"]
    assert chain["final_change"] == pytest.approx(
        chain["with"]["final"] - chain["without"]["final"], abs=0.01)


def test_context_is_the_same_on_both_sides_and_says_so(monkeypatch):
    """Not an oversight - it is the point. The adapter changes retrieval, not the context terms,
    and this is the one place a reader can see how far its influence actually reaches."""
    _cfg_on(monkeypatch)
    chain = handlers.handle_trace_explain("t1", "r1")["adapter"]["chain"]
    assert chain["without"]["context"] == chain["with"]["context"] == 11.0
    assert chain["context_unchanged"] is True


def test_the_chain_always_reports_evidence_weighting_as_on(monkeypatch):
    """It cannot be off any more.

    The flag shipped OFF, which meant match points were not built from the similarity at all:
    every semantic candidate kept the full base and the Match column read a flat 12.00 whatever
    the similarity beside it said. It is retired - a stored value of False no longer turns
    anything off - and the page must not claim otherwise.

    The key itself stays so a dashboard built against the earlier shape keeps working rather than
    reading it as absent.
    """
    _cfg_on(monkeypatch, similarityWeightedScoring=False)
    chain = handlers.handle_trace_explain("t1", "r1")["adapter"]["chain"]
    assert chain["evidence_weighting_on"] is True


def test_one_similarity_alone_produces_no_comparison(monkeypatch):
    """A single column labelled "with adapter" would read as a comparison against zero. There is
    nothing to compare, and the reason line already explains why."""
    _cfg_on(monkeypatch)
    trace = dict(TRACE)
    trace["candidates"] = [dict(TRACE["candidates"][0],
                                adapter_influence={"similarity_base": "0.71"})]
    sys.modules["src.utils.recommendation_trace"].get_traces_for_request =         lambda rid: [trace] if rid == "t1" else []
    chain = handlers.handle_trace_explain("t1", "r1")["adapter"]["chain"]
    assert chain["available"] is False


def test_the_whole_response_can_actually_be_sent():
    """These tests call the handler directly; Flask does not - it serialises what comes back.

    A local helper named the same as a value that goes into the response shadowed it, so the
    endpoint returned a FUNCTION under context_score. Every test here passed and every real
    request answered 500. Serialising the response closes the gap between what is tested and
    what is served.
    """
    import json
    for out in (handlers.handle_trace_explain("t1", "r1"),
                handlers.handle_trace_explain("t1", "missing"),
                handlers.handle_trace_explain("missing", "r1")):
        json.dumps(out)  # raises on anything Flask could not send
