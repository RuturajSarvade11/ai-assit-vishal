"""The User Management list is the access list.

Allowing everything by default is not acceptable. Only the users on the user
management list get in; everyone else is refused. These tests pin sign_in_decision:
listed -> in with the row's role; bootstrap admin -> in as admin; not listed -> refused and NO
row written; storage error -> refused (except bootstrap admins); SSO_ALLOW_UNLISTED=1 -> the
earlier open behaviour for a test environment.

Run:  python tests/test_sso_sign_in_decision.py   (loads the real source with a fake store)
"""
import os
import sys
import types

_REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _REPO)


class _FakeTable:
    def __init__(self, store):
        self.store = store

    def put_item(self, Item):
        self.store[Item["username"]] = dict(Item)

    def delete_item(self, Key):
        self.store.pop(Key["username"], None)

    def scan(self):
        return {"Items": list(self.store.values())}


def _load(store, fail_reads=False, group_of=None):
    """Import sso_roles with src.auth.users / src.databases.database replaced by a dict store.
    `group_of` is {project name: group name} and stands in for the project-group service, so the
    group expansion can be tested without a database."""
    users = types.ModuleType("src.auth.users")
    users.USERS_TABLE = "auth_users"

    def get_user(key):
        if fail_reads:
            raise RuntimeError("dynamodb unavailable")
        return store.get(key)
    users.get_user = get_user
    database = types.ModuleType("src.databases.database")
    database.get_dynamodb = lambda: types.SimpleNamespace(Table=lambda name: _FakeTable(store))
    for name in ("src", "src.auth", "src.databases", "src.services", "src.utils"):
        sys.modules.setdefault(name, types.ModuleType(name))
    sys.modules["src.auth.users"] = users
    sys.modules["src.databases.database"] = database
    mapping = dict(group_of or {})
    groups_mod = types.ModuleType("src.services.project_groups")
    groups_mod.build_group_map = lambda names: {n: mapping.get(n, "Other") for n in names}
    details_mod = types.ModuleType("src.utils.project_details")
    details_mod.get_all_projects = lambda: [{"project_name": n} for n in mapping]
    sys.modules["src.services.project_groups"] = groups_mod
    sys.modules["src.utils.project_details"] = details_mod
    sys.modules.pop("src.auth.sso_roles", None)
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "src.auth.sso_roles", os.path.join(_REPO, "src", "auth", "sso_roles.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _env(**values):
    for k in ("SSO_ADMIN_IDS", "SSO_ALLOW_UNLISTED", "SSO_DEFAULT_ROLE", "SSO_ID_HASH_SECRET",
              "RBAC_DEFAULT_ALLOW", "RBAC_DEFAULT_DENY"):
        os.environ.pop(k, None)
    os.environ["SSO_ID_HASH_SECRET"] = "test-secret"
    os.environ.update(values)


UID = "sg123456@user.schaeffler.com"


def test_not_listed_is_refused_and_no_row_is_written():
    _env()
    store = {}
    m = _load(store)
    d = m.sign_in_decision(UID, "Someone New")
    assert d["allowed"] is False and d["reason"] == "not_listed"
    assert store == {}, "a refused sign-in must not add itself to the admin's list"


def test_listed_user_gets_in_with_the_row_role():
    _env()
    store = {}
    m = _load(store)
    m.set_sso_role(UID, "user", "Listed Person")
    d = m.sign_in_decision(UID, "Listed Person")
    assert d["allowed"] is True and d["role"] == "user" and d["reason"] == "listed"
    row = store[m._row_key(UID)]
    assert row["last_login_at"] >= row["created_at"]


def test_listed_admin_keeps_admin():
    _env()
    store = {}
    m = _load(store)
    m.set_sso_role(UID, "admin", "An Admin")
    assert m.sign_in_decision(UID)["role"] == "admin"


def test_bootstrap_admin_gets_in_without_a_row_and_is_recorded_as_admin():
    _env(SSO_ADMIN_IDS="SG123456@user.schaeffler.com")
    store = {}
    m = _load(store)
    d = m.sign_in_decision(UID, "Boot Admin")
    assert d["allowed"] is True and d["role"] == "admin" and d["reason"] == "bootstrap_admin"
    assert store[m._row_key(UID)]["role"] == "admin"


def test_storage_error_refuses_everyone_but_bootstrap_admins():
    _env(SSO_ADMIN_IDS="sg999999@user.schaeffler.com")
    m = _load({}, fail_reads=True)
    assert m.sign_in_decision(UID)["reason"] == "store_error"
    assert m.sign_in_decision("sg999999@user.schaeffler.com")["allowed"] is True


def test_allow_unlisted_restores_the_open_behaviour():
    _env(SSO_ALLOW_UNLISTED="1")
    store = {}
    m = _load(store)
    d = m.sign_in_decision(UID, "Anyone")
    assert d["allowed"] is True and d["role"] == "user" and d["reason"] == "unlisted_allowed"
    assert store[m._row_key(UID)]["role"] == "user"


def test_no_identity_is_refused():
    _env()
    m = _load({})
    assert m.sign_in_decision("")["allowed"] is False


def test_removing_a_user_removes_their_access():
    """Delete on the User Management page is now a real removal, not a reset to default."""
    _env()
    store = {}
    m = _load(store)
    m.set_sso_role(UID, "user", "Temp")
    m.delete_sso_user(m._row_key(UID))
    assert m.sign_in_decision(UID)["allowed"] is False


# ------------------------------------------------------------------ access by project group

GROUPS = {"1g_hio_000u0": "HIP26", "1g_hio_000u0_uat": "HIP26",
          "0ppi1_0u0_100": "PPI", "loose_project": "Other"}


def test_a_group_assignment_expands_to_its_projects():
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "Member")
    m.set_sso_groups(UID, ["HIP26"])
    res = m.projects_for_sso_user(UID, "user")
    assert res["all"] is False
    assert res["projects"] == ["1g_hio_000u0", "1g_hio_000u0_uat"]
    assert res["groups"] == ["HIP26"]


def test_a_project_added_to_the_group_later_is_covered_without_re_saving():
    """The whole reason access is stored as a group: the project list keeps growing."""
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "Member")
    m.set_sso_groups(UID, ["HIP26"])
    assert len(m.projects_for_sso_user(UID, "user")["projects"]) == 2
    # A new project joins the group, and nobody edits the user.
    m._group_expansion_cache.clear()
    sys.modules["src.services.project_groups"].build_group_map = (
        lambda names: {**{n: GROUPS.get(n, "Other") for n in names}, "1g_hio_000u9": "HIP26"})
    sys.modules["src.utils.project_details"].get_all_projects = (
        lambda: [{"project_name": n} for n in list(GROUPS) + ["1g_hio_000u9"]])
    assert "1g_hio_000u9" in m.projects_for_sso_user(UID, "user")["projects"]


def test_several_groups_are_combined():
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "Member")
    m.set_sso_groups(UID, ["HIP26", "PPI"])
    assert m.projects_for_sso_user(UID, "user")["projects"] == [
        "0ppi1_0u0_100", "1g_hio_000u0", "1g_hio_000u0_uat"]


def test_a_user_with_no_group_sees_nothing():
    """Access is granted, never assumed: a newly added person sees an empty dashboard until an
    admin assigns them a group."""
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "New Person")
    res = m.projects_for_sso_user(UID, "user")
    assert res["all"] is False and res["projects"] == []


def test_clearing_the_groups_takes_the_projects_away():
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "Member")
    m.set_sso_groups(UID, ["HIP26"])
    m.set_sso_groups(UID, [])
    res = m.projects_for_sso_user(UID, "user")
    assert res["all"] is False and res["projects"] == []


def test_unassigned_users_can_be_opened_up_by_configuration():
    _env(RBAC_DEFAULT_ALLOW="1")
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "New Person")
    assert m.projects_for_sso_user(UID, "user")["all"] is True


def test_a_storage_error_shows_nothing_rather_than_everything():
    _env()
    m = _load({}, fail_reads=True)
    res = m.projects_for_sso_user(UID, "user")
    assert res["all"] is False and res["projects"] == []


def test_an_individually_assigned_project_still_works_and_adds_to_the_groups():
    """Rows created before access moved to groups must not lose what they had."""
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "Member")
    m.set_sso_projects(UID, ["loose_project"])
    assert m.projects_for_sso_user(UID, "user")["projects"] == ["loose_project"]
    m.set_sso_groups(UID, ["PPI"])
    assert m.projects_for_sso_user(UID, "user")["projects"] == ["0ppi1_0u0_100", "loose_project"]


def test_an_admin_sees_everything_regardless_of_groups():
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "admin", "An Admin")
    m.set_sso_groups(UID, ["PPI"])
    assert m.projects_for_sso_user(UID, "admin")["all"] is True


def test_groups_survive_a_role_change_and_a_sign_in():
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "Member")
    m.set_sso_groups(UID, ["HIP26"])
    m.set_sso_role(UID, "admin", "Member")
    assert store[m._row_key(UID)]["groups"] == ["HIP26"]
    m.sign_in_decision(UID, "Member")
    assert store[m._row_key(UID)]["groups"] == ["HIP26"]


def test_groups_are_listed_for_the_admin_screen():
    _env()
    store = {}
    m = _load(store, group_of=GROUPS)
    m.set_sso_role(UID, "user", "Member")
    m.set_sso_groups(UID, ["HIP26"])
    row = m.list_sso_users()[0]
    assert row["groups"] == ["HIP26"] and "sg123456" not in row["masked_id"]


# ------------------------------------------------- an open session follows the access list

def test_a_removed_user_loses_an_open_session_at_once():
    """A signed token stays valid until it expires, so the access list has to be re-checked on
    every request - otherwise a removed person keeps working until then."""
    _env()
    store = {}
    m = _load(store)
    m.set_sso_role(UID, "user", "Member")
    assert m.current_access(UID)["allowed"] is True
    m.delete_sso_user(m._row_key(UID))
    assert m.current_access(UID)["allowed"] is False


def test_a_role_change_applies_to_an_open_session():
    _env()
    store = {}
    m = _load(store)
    m.set_sso_role(UID, "admin", "Member")
    assert m.current_access(UID)["role"] == "admin"
    m.set_sso_role(UID, "user", "Member")
    assert m.current_access(UID)["role"] == "user"


def test_the_access_check_writes_nothing():
    _env()
    store = {}
    m = _load(store)
    m.set_sso_role(UID, "user", "Member")
    before = dict(store[m._row_key(UID)])
    m.current_access(UID)
    assert store[m._row_key(UID)] == before


def test_a_storage_error_keeps_an_open_session_alive():
    """Refusing here would sign out everyone on a transient database error, and unlike a
    sign-in this grants no new access."""
    _env()
    m = _load({}, fail_reads=True)
    assert m.current_access(UID)["allowed"] is True


def test_a_bootstrap_admin_session_needs_no_row():
    _env(SSO_ADMIN_IDS=UID)
    m = _load({})
    assert m.current_access(UID) == {"allowed": True, "role": "admin", "reason": "bootstrap_admin"}


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                passed += 1
                print(f"  PASS  {name}")
            except Exception:
                failed += 1
                print(f"  FAIL  {name}")
                traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
