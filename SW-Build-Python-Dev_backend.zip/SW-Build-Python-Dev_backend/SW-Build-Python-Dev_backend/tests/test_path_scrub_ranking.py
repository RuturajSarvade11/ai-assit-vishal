"""A folder name must not decide which fix is recommended.

The project under test lived in "D:\\Build type error\\TestGbe\\...". clean_volatile_text's path
rule is [a-z]:[\\/][^\\s"']+ - it stops at the first SPACE - so the folder kept the word "error",
every path line in the debug.log was classified as a FAILURE line, and the entire directory
layout entered the ranking token set. Rarity weighting then rewarded whichever candidate shared
the query's DIRECTORY layout rather than its failure: on a ctc failure a python fix scored 27
token hits (task4 alone weighing 0.100) against the ctc fix's 17 and won 1.6455 to 1.1909, while
only the ctc fix carried the real root-cause token '6.2r1p456' (weight 0.333).

This is the second time this bug has been found. It was fixed once for "TESTGBE_ERROR" - a folder
with no spaces, which the existing rule consumes. A space reopened it, so these tests pin BOTH
spellings.

The tests below also pin what must NOT change: text after a path still carries its own markers,
the fingerprint cleaner is untouched (its checksums drive artifact dedup and the upload precheck),
and a real failure line is still a failure line.
"""
import os
import re
import sys
import types

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

# handlers imports the world; the two functions under test are pure string logic, so they are
# re-created here from the real source rather than importing AWS, Azure and the whole service.
import importlib.util  # noqa: E402

_spec = importlib.util.spec_from_file_location("cf", os.path.join(_ROOT, "src", "utils", "content_fingerprint.py"))
cf = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(cf)

_src = open(os.path.join(_ROOT, "src", "services", "handlers.py"), encoding="utf-8").read()


def _extract(name, end_marker):
    start = _src.index(name)
    return _src[start:_src.index(end_marker, start)]


_ns = {"re": re, "clean_volatile_text": cf.clean_volatile_text}
exec(compile(_extract("_PATH_WITH_SPACES = re.compile", "def _distinctive_token_set"), "h", "exec"), _ns)
exec(compile(_extract("_FAILURE_SIGNAL_MARKERS = (", "def _line_has_failure_marker"), "h", "exec"), _ns)

scrub = _ns["_scrub_paths_for_ranking"]
MARKERS = _ns["_FAILURE_SIGNAL_MARKERS"]


def has_marker(line):
    """Mirrors handlers._line_has_failure_marker after the fix."""
    low = cf.clean_volatile_text(scrub(line)).lower()
    return any(m in low for m in MARKERS)


def tokens(text):
    """Mirrors handlers._distinctive_token_set. Both the path scrub and the placeholder regex are
    taken from the real source above rather than retyped, so this cannot drift from what ships -
    it already did once, and the test then reported the mirror's staleness as a product bug."""
    cleaned = cf.clean_volatile_text(scrub(text))
    cleaned = _ns["_CLEANER_PLACEHOLDER"].sub(" ", cleaned)
    return {t for t in re.split(r"[^a-z0-9.]+", cleaned.lower()) if len(t) >= 2}


# The four lines that were wrongly classified, verbatim from the trace.
PATH_LINES = [
    r"2026-08-31 10:33:35,283 [DEBUG] Detailed debug log file=D:\Build type error\TestGbe\build\master\task4\log\debug.log",
    r"2026-08-31 10:33:35,283 [DEBUG] json_path=D:\Build type error\TestGbe\build\master\task4\in\config.json",
    r"2026-08-31 10:33:35,283 [DEBUG] output_dir=D:\Build type error\TestGbe\build\master\task4\out",
    r"2026-08-31 10:33:35,283 [DEBUG] log_dir=D:\Build type error\TestGbe\build\master\task4\log",
]
ROOT_CAUSE = r"2026-08-31 10:33:35,286 [DEBUG] 'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p456'."
REAL_ERROR = r"2026-08-31 10:33:35,285 [ERROR] Error parsing input file"


def test_a_folder_named_error_no_longer_makes_path_lines_failure_lines():
    for line in PATH_LINES:
        assert not has_marker(line), f"still reads as a failure line: {line}"


def test_the_no_space_spelling_stays_fixed():
    """The original report was TESTGBE_ERROR. It must not regress while fixing the spaced form."""
    assert not has_marker(r"[DEBUG] json_path=D:\TESTGBE_ERROR\build\master\task4\in\config.json")


def test_real_failure_lines_are_still_failure_lines():
    assert has_marker(REAL_ERROR)
    assert has_marker(ROOT_CAUSE), "the 'must be/but got' root cause must still register"


def test_text_after_a_path_keeps_its_own_marker():
    """The scrub must not swallow the rest of the line - the last path segment may not contain
    spaces, so a message following a path survives."""
    line = r"c:/LegacyApp/python/3.10.0/python.exe: can't find '__main__' module in 'D:\x\y'"
    assert has_marker(line), "swallowed the real failure text after the path"


def test_directory_names_no_longer_enter_the_token_set():
    """The heart of it: layout words must not be comparison evidence."""
    toks = tokens(chr(10).join(PATH_LINES + [REAL_ERROR, ROOT_CAUSE]))
    for noise in ("testgbe", "master", "task4", "build"):
        assert noise not in toks, f"path token {noise!r} still ranks as evidence"


def test_the_root_cause_token_survives():
    toks = tokens(ROOT_CAUSE)
    assert "6.2r1p456" in toks
    assert "ctc" in toks and "aurix" in toks


def test_the_ctc_query_now_outscores_a_python_doc_on_shared_tokens():
    """End to end on the real texts: with the layout noise gone, the ctc summary must overlap the
    ctc query more than the python summary does - which was inverted before the fix."""
    query = chr(10).join(PATH_LINES + [REAL_ERROR, ROOT_CAUSE])
    q = {t for line in (REAL_ERROR, ROOT_CAUSE) for t in tokens(line)} & tokens(query)
    ctc = tokens("- Error Signals: - [ERROR] Error parsing input file - tools[name=ctc_aurix].version "
                 "must be '6.2r1p4' but got '6.2r1p456' - Missing or Failing Components: - config.json")
    py = tokens("- Error Signals: - Error parsing input file - Validation failure: "
                "tools[name=python].version must be '3.10.0' but got '3.112120.0' - "
                "Missing or Failing Components: - config.json - Root Cause Clues")
    assert len(ctc & q) > len(py & q), (
        f"ctc overlap {sorted(ctc & q)} must beat python overlap {sorted(py & q)}")


def test_fingerprint_cleaner_is_untouched():
    """clean_volatile_text drives artifact dedup checksums and the upload precheck. If this test
    fails, every stored fingerprint has shifted and existing artifacts stop matching new uploads."""
    line = r"[DEBUG] json_path=D:\Build type error\TestGbe\build\master\task4\in\config.json"
    assert "type error" in cf.clean_volatile_text(line), (
        "clean_volatile_text changed - fingerprints would shift and dedup would break")


# ---------------------------------------------------------------------------------------------
# Normalisation placeholders must never be evidence.
# ---------------------------------------------------------------------------------------------
# clean_volatile_text replaces a timestamp with "<ts>", a path with "<path>" and so on. The
# tokeniser splits on non-alphanumerics, so each placeholder survives as a bare word - and rarity
# weighting then treats it as the RAREST, heaviest signal, because most stored summaries have had
# their timestamps paraphrased away and only a couple still carry one.
#
# Measured: on a ctc failure a python fix beat the ctc fix by exactly 0.5000 of token weight, and
# that was ONE token - "ts", df=2, weight 0.5000, the heaviest in the whole comparison. The
# winning artifact was the vaguest of four ("Validation indicates ... mismatch", no version
# number) and won because it happened to keep a timestamp.

def test_no_cleaner_placeholder_is_ever_a_token():
    """Derived, not enumerated: whatever clean_volatile_text emits as <something> must not survive
    tokenisation. A hardcoded word list would go stale the moment the cleaner gains a placeholder,
    and would also delete those words from real error text where they are ordinary vocabulary."""
    noisy = (r"2026-08-31 10:33:35,283 [DEBUG] file=D:\x\y.log took 12 ms 0xDEADBEEF "
             r"550e8400-e29b-41d4-a716-446655440000 at Foo.java:42")
    emitted = set(re.findall(r"<([a-z]+)>", cf.clean_volatile_text(noisy)))
    assert emitted, "this input should have produced placeholders - the test proves nothing if not"
    leaked = emitted & tokens(noisy)
    assert not leaked, f"cleaner placeholders scored as evidence: {sorted(leaked)}"


def test_a_timestamp_no_longer_outweighs_the_failing_tool():
    """The exact inversion from the trace: a vague summary that kept a timestamp versus one that
    names the failing tool. The specific one must share more with the query."""
    query = ("[ERROR] Error parsing input file" + chr(10)
             + "[DEBUG] 'tools[name=ctc_aurix].version' must be '6.2r1p4' but got '6.2r1p5'.")
    q = tokens(query)
    vague_with_timestamp = ("2026-07-31 11:06:34,120 - Error Signals: - Error parsing input file "
                            "- Validation indicates tools[name=python].version mismatch")
    specific_ctc = ("- Error Signals: - [ERROR] Error parsing input file - "
                    "tools[name=ctc_aurix].version must be '6.2r1p4' but got '6.2r1p5'")
    assert len(tokens(specific_ctc) & q) > len(tokens(vague_with_timestamp) & q), (
        "the artifact naming the failing tool must share more with the query than a vague one "
        "whose only advantage was a timestamp")


def test_real_words_are_still_kept():
    """Only the placeholder spellings are dropped - ordinary failure vocabulary survives."""
    toks = tokens("Error parsing input file: tools[name=ctc_aurix].version must be 6.2r1p4")
    for word in ("error", "parsing", "input", "file", "tools", "name", "ctc", "aurix", "6.2r1p4"):
        assert word in toks, f"real token {word!r} was dropped"


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
