"""Votes move distance in W.

The required behaviour is a downvote increasing the distance between an error and the fix that was
recommended for it, so the next similar failure scores that fix lower. That is not what the
adapter did: it learned only from "these two errors had the same proven fix", and votes reached
nothing but the ordering.

A vote is exactly the pair the contrastive loss already consumes:

    thumbs up   on (error E, fix F)  ->  E belongs with the errors F resolved
    thumbs down on (error E, fix F)  ->  E does not

The downvote is the more valuable half. Today's negatives are "two errors with different fixes",
which is weak - two unrelated errors are trivially different. A downvote is a CONFIRMED negative:
the system recommended this and a person rejected it.

These tests check the geometry rather than the plumbing. Training is a numerical process, so the
thing worth pinning is that distance actually moves in the direction claimed, and that a vote is
worth less than a proven fix rather than equal to it.
"""
import os
import sys

import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

import types  # noqa: E402

_fake_cfg = types.ModuleType("src.configurations.config")
_fake_cfg.FEEDBACK_ADAPTER_EPOCHS = 300
_fake_cfg.FEEDBACK_ADAPTER_LR = 0.5
_fake_cfg.FEEDBACK_ADAPTER_MARGIN = 1.0
_fake_cfg.FEEDBACK_ADAPTER_BATCH = 512
_fake_cfg.FEEDBACK_ADAPTER_VOTE_WEIGHT = 0.0
_fake_cfg.FEEDBACK_ADAPTER_PATH = "./feedback_adapter/W.npy"
_fake_cfg.FEEDBACK_ADAPTER_ARTIFACT_PATH = "./feedback_adapter/W_art.npy"
_fake_cfg.EMBEDDING_MODEL = "test"
_pkg = types.ModuleType("src.configurations")
_pkg.config = _fake_cfg
sys.modules.setdefault("src.configurations", _pkg)

# The stub stands in only while the module under test is imported, and the real module goes back
# immediately. Leaving it in sys.modules made every test file collected AFTER this one see a
# config with four adapter settings and nothing else - three of them failed on
# DYNAMODB_TABLE_SUFFIX, in a suite where each passed on its own.
_real_cfg = sys.modules.get("src.configurations.config")
sys.modules["src.configurations.config"] = _fake_cfg
try:
    from src.utils import feedback_adapter as fa  # noqa: E402
finally:
    if _real_cfg is not None:
        sys.modules["src.configurations.config"] = _real_cfg
    else:
        sys.modules.pop("src.configurations.config", None)
        sys.modules.pop("src.configurations", None)


def _corpus():
    """Four errors in a plain 3-D space. 0 and 1 share a proven fix; 2 and 3 share another.
    Error 0 sits close to the pair it does NOT belong with, which is what a vote can correct."""
    X = np.array([
        [1.0, 0.0, 0.0],   # 0  fix A
        [0.9, 0.1, 0.0],   # 1  fix A
        [0.8, 0.2, 0.0],   # 2  fix B, and near error 0
        [0.0, 1.0, 0.0],   # 3  fix B
    ], dtype=np.float64)
    return fa.l2norm(X), ["A", "A", "B", "B"]


def _distance(W, X, i, j):
    d = (X[i] - X[j]) @ W
    return float(np.sqrt(np.sum(d * d)))


def test_a_downvote_pushes_the_error_away_from_the_fix_it_rejected():
    """The required behaviour, stated as geometry: after a downvote on
    (error 0, a fix that resolved error 2), 0 and 2 must end up further apart than training
    without that vote leaves them."""
    X, labels = _corpus()
    base = fa.train_adapter(X, labels, seed=0)
    voted = fa.train_adapter(X, labels, seed=0, vote_neg=[(0, 2)], vote_weight=1.0)
    assert _distance(voted, X, 0, 2) > _distance(base, X, 0, 2), \
        "a downvote did not increase the distance it was supposed to"


def test_an_upvote_pulls_the_error_towards_the_fix_it_confirmed():
    X, labels = _corpus()
    base = fa.train_adapter(X, labels, seed=0)
    voted = fa.train_adapter(X, labels, seed=0, vote_pos=[(0, 3)], vote_weight=1.0)
    assert _distance(voted, X, 0, 3) < _distance(base, X, 0, 3), \
        "an upvote did not reduce the distance it was supposed to"


def test_a_vote_counts_for_less_than_a_proven_fix():
    """A click is weaker evidence than a change that made the build pass, and the weight has to
    say so - otherwise a single vote can undo what the corpus established."""
    X, labels = _corpus()
    light = fa.train_adapter(X, labels, seed=0, vote_neg=[(0, 2)], vote_weight=0.2)
    heavy = fa.train_adapter(X, labels, seed=0, vote_neg=[(0, 2)], vote_weight=1.0)
    base = fa.train_adapter(X, labels, seed=0)
    moved_light = _distance(light, X, 0, 2) - _distance(base, X, 0, 2)
    moved_heavy = _distance(heavy, X, 0, 2) - _distance(base, X, 0, 2)
    assert 0 < moved_light < moved_heavy, "the weight is not scaling the vote's influence"


def test_weight_zero_reproduces_the_previous_behaviour_exactly():
    """The switch ships off, and off has to mean identical - not merely similar."""
    X, labels = _corpus()
    base = fa.train_adapter(X, labels, seed=0)
    off = fa.train_adapter(X, labels, seed=0, vote_pos=[(0, 3)], vote_neg=[(0, 2)],
                           vote_weight=0.0)
    assert np.allclose(base, off), "votes changed W while the weight was zero"


def test_no_votes_at_all_is_unchanged():
    X, labels = _corpus()
    assert np.allclose(fa.train_adapter(X, labels, seed=0),
                       fa.train_adapter(X, labels, seed=0, vote_pos=[], vote_neg=[]))


def test_votes_alone_can_train_when_no_fix_pairs_exist():
    """A young project has no error resolved twice by the same fix, so there are no proven-fix
    pairs at all. Votes should still be able to shape the space rather than the run being
    abandoned - which is what happened before, with a warning and an identity matrix."""
    X = fa.l2norm(np.array([[1.0, 0.0, 0.0], [0.9, 0.2, 0.0], [0.0, 1.0, 0.0]]))
    labels = ["A", "B", "C"]          # every fix distinct: no positive pairs
    W = fa.train_adapter(X, labels, seed=0, vote_pos=[(0, 2)], vote_weight=1.0)
    identity = np.eye(X.shape[1])
    assert not np.allclose(W, identity), "votes alone left the space untouched"


def test_a_downvote_does_not_tear_the_space_open():
    """A negative pair stops pushing once it is beyond the margin. Without that, a few
    downvotes could drive distances arbitrarily far and wreck the rest of the space."""
    X, labels = _corpus()
    W = fa.train_adapter(X, labels, seed=0, vote_neg=[(0, 2)] * 20, vote_weight=1.0)
    assert np.all(np.isfinite(W))
    same_fix = _distance(W, X, 0, 1)
    assert same_fix < 5.0, "errors sharing a proven fix were flung apart by unrelated downvotes"


if __name__ == "__main__":
    import traceback
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("test_") or not callable(fn):
            continue
        try:
            fn()
            passed += 1
            print(f"  PASS  {name}")
        except Exception:
            failed += 1
            print(f"  FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
