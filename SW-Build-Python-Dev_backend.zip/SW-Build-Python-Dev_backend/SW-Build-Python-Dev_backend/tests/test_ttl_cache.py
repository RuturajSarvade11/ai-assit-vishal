"""UAT perf fix: short-TTL cache for the dashboard read path.

Run:  python tests/test_ttl_cache.py   (pure module — no server dependencies)
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.utils import ttl_cache


def _fresh():
    ttl_cache.clear()
    os.environ["DASHBOARD_CACHE_TTL_SEC"] = "60"


def test_computes_once_within_ttl():
    _fresh()
    calls = []
    for _ in range(5):
        ttl_cache.get_or_compute(("solutions", "p", "a", "b"), lambda: calls.append(1) or [{"x": 1}])
    assert len(calls) == 1


def test_different_keys_compute_separately():
    _fresh()
    calls = []
    ttl_cache.get_or_compute(("solutions", "p1", "a", "b"), lambda: calls.append(1) or [])
    ttl_cache.get_or_compute(("solutions", "p2", "a", "b"), lambda: calls.append(1) or [])
    assert len(calls) == 2


def test_deep_copy_isolates_callers():
    _fresh()
    first = ttl_cache.get_or_compute(("solutions", "p", "a", "b"), lambda: [{"rows": [1]}])
    first[0]["rows"].append(999)   # caller mutates its copy (enrichment does this in place)
    second = ttl_cache.get_or_compute(("solutions", "p", "a", "b"), lambda: [{"rows": ["never"]}])
    assert second[0]["rows"] == [1]   # cached original untouched, not recomputed


def test_shared_mode_returns_same_object():
    _fresh()
    a = ttl_cache.get_or_compute(("art-summaries", "p"), lambda: {"k": {}}, deep_copy=False)
    b = ttl_cache.get_or_compute(("art-summaries", "p"), lambda: {"k": {}}, deep_copy=False)
    assert a is b


def test_invalidate_prefix_drops_matching_keys_only():
    _fresh()
    calls = []
    ttl_cache.get_or_compute(("solutions", "p", "a", "b"), lambda: calls.append(1) or [])
    ttl_cache.get_or_compute(("recent", "a", "b"), lambda: calls.append(1) or [])
    ttl_cache.invalidate_prefix("solutions")
    ttl_cache.get_or_compute(("solutions", "p", "a", "b"), lambda: calls.append(1) or [])   # recomputes
    ttl_cache.get_or_compute(("recent", "a", "b"), lambda: calls.append(1) or [])           # still cached
    assert len(calls) == 3


def test_ttl_zero_disables_caching():
    _fresh()
    os.environ["DASHBOARD_CACHE_TTL_SEC"] = "0"
    calls = []
    ttl_cache.get_or_compute(("solutions", "p", "a", "b"), lambda: calls.append(1) or [])
    ttl_cache.get_or_compute(("solutions", "p", "a", "b"), lambda: calls.append(1) or [])
    assert len(calls) == 2
    os.environ["DASHBOARD_CACHE_TTL_SEC"] = "60"


def test_expiry_recomputes():
    _fresh()
    os.environ["DASHBOARD_CACHE_TTL_SEC"] = "1"
    calls = []
    ttl_cache.get_or_compute(("recent", "a", "b"), lambda: calls.append(1) or [])
    time.sleep(1.2)
    ttl_cache.get_or_compute(("recent", "a", "b"), lambda: calls.append(1) or [])
    assert len(calls) == 2
    os.environ["DASHBOARD_CACHE_TTL_SEC"] = "60"


if __name__ == "__main__":
    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS  {name}")
            except AssertionError:
                failed += 1
                print(f"FAIL  {name}")
    sys.exit(1 if failed else 0)
