"""Promote (or un-promote) a trained adapter, one domain at a time.

audit_adapter_training.py --evaluate measured the ERROR adapter on dev at
top-1 55.8% -> 62.0%, +6.2pp against a 2.0pp gate. This script is how that becomes live, and -
just as importantly - how it stops being live.

WHY NOT THE ADMIN ENDPOINT. POST /admin/adapter-train needs an admin token and runs BOTH domains
in one cycle, so promoting the error adapter also drags the artifact corpus through a full
embedding pass it has never done (~12 minutes at dev's tokens-per-minute quota). For a controlled
change you want one domain, deliberately.

WHY A REVERT MATTERS. The adapter changes WHICH candidates reach scoring, and the ranking it
would alter is the one that was carefully proven correct in both directions. A +6.2pp average
across 711 held-out cases is not a promise about any particular case, so the ability to put it
back in one command is part of the change, not an afterthought. is_active() is literally "does a
W file load", so removing the file reverts instantly - no restart, no config.

    python promote_adapter.py --status
    python promote_adapter.py --promote            # ERROR domain only (the measured one)
    python promote_adapter.py --promote --domain artifact
    python promote_adapter.py --revert             # remove it; back to today's behaviour

Promotion still respects the gain gate: an adapter that does not beat it is NOT promoted, and the
script says so rather than pretending. --force overrides that, and should only be used when you
have decided to ship something that failed its own quality bar.
"""
import argparse
import os
import sys

import src.utils.log_setup  # noqa: F401

from src.configurations import config


def _rule(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)


def _topk(scores, k):
    """topk_accuracy returns {1: .., 3: ..} with INT keys, but save_adapter persists the metrics
    through json.dump, and JSON object keys are always strings - so the same value is scores[1]
    in memory and scores["1"] after a round trip. Read both."""
    if not isinstance(scores, dict):
        return None
    for key in (k, str(k)):
        if key in scores:
            try:
                return float(scores[key])
            except (TypeError, ValueError):
                return None
    return None


def _paths(domain):
    from src.utils import feedback_adapter as fa
    path = fa._domain_path(domain)
    found = [p for p in (path, path + ".npy") if os.path.exists(p)]
    real = found[0] if found else ""
    meta = fa._meta_path(real) if real else ""
    return path, real, meta


def status():
    from src.utils import feedback_adapter as fa
    _rule("ADAPTER STATUS")
    for domain in ("error", "artifact"):
        configured, real, meta = _paths(domain)
        active = False
        try:
            active = bool(fa.is_active(domain))
        except Exception as exc:
            print(f"  {domain:<9} is_active raised: {exc}")
        print(f"  {domain:<9} {'ACTIVE' if active else 'not promoted'}   {real or configured}")
        if real:
            try:
                _W, m = fa.load_adapter(real)
                metrics = (m or {}).get("metrics") or {}
                before = _topk(metrics.get("baseline"), 1)
                after = _topk(metrics.get("learned"), 1)
                if before is not None and after is not None:
                    print(f"  {'':<9} top-1 {before * 100:.1f}% -> {after * 100:.1f}% "
                          f"({float(metrics.get('gain_top1_pp') or 0):+.1f}pp)"
                          f" on {metrics.get('n_heldout')} held out")
                print(f"  {'':<9} trained_at {(m or {}).get('trained_at') or '-'}")
            except Exception as exc:
                print(f"  {'':<9} metadata unreadable: {exc}")
    return 0


def promote(domain, force):
    from src.services import adapter_trainer
    _rule(f"PROMOTING THE {domain.upper()} ADAPTER")
    if domain == "artifact":
        print("  NOTE: the artifact corpus has never been embedded, so this pays a full")
        print("  embedding pass the first time. It is resumable - a rate limit costs a batch,")
        print("  not the run - but it is not quick.")
    print("  training ...")
    result = (adapter_trainer._train_artifact_cycle(force=force) if domain == "artifact"
              else adapter_trainer._train_error_cycle(force=force))

    summary = result.get("summary") or {}
    if summary:
        print(f"  top-1 {summary.get('top1_before')}% -> {summary.get('top1_after')}%"
              f"   gain {summary.get('gain_pp')}pp   gate {summary.get('gate_pp')}pp")
        print(f"  trained on {summary.get('trained_on')} rows, {summary.get('held_out')} held out,"
              f" {summary.get('fixes')} distinct fixes")

    if not result.get("ok"):
        print(f"  NOT PROMOTED: {result.get('reason')}")
        return 1
    if not result.get("promoted"):
        print("  NOT PROMOTED: the gain did not clear the gate. That is the gate working -")
        print("  promoting anyway would ship a ranking worse than the one running today.")
        print("  Use --force only if you have decided to ship it regardless.")
        return 1

    print(f"  PROMOTED. Learned space rebuilt with {result.get('learned_count')} vectors.")
    print()
    print("  The adapter is live for every project whose switch is ON. Now re-run the accuracy")
    print("  proof and compare against the baseline, because this changes WHICH candidates reach")
    print("  scoring:")
    print("      python simulate_recommendation.py --case python")
    print("      python simulate_recommendation.py --case ctc")
    print("  If the right fix no longer leads, revert with:  python promote_adapter.py --revert")
    return 0


def revert(domain):
    _rule(f"REVERTING THE {domain.upper()} ADAPTER")
    configured, real, meta = _paths(domain)
    if not real:
        print(f"  Nothing to revert - no adapter file at {configured}")
        return 0
    removed = []
    for path in (real, meta):
        if path and os.path.exists(path):
            try:
                os.remove(path)
                removed.append(path)
            except Exception as exc:
                print(f"  could NOT remove {path}: {exc}")
                return 1
    for path in removed:
        print(f"  removed {path}")
    print()
    print("  Reverted. is_active() is 'does a W load', so the base ranking is in force again")
    print("  immediately - no restart needed. The learned-space collection still holds its")
    print("  vectors; they are ignored while no adapter loads, and the next promotion rebuilds")
    print("  the collection from scratch anyway.")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--status", action="store_true", help="show what is promoted (default)")
    ap.add_argument("--promote", action="store_true", help="train and promote if it clears the gate")
    ap.add_argument("--revert", action="store_true", help="remove the adapter - back to base ranking")
    ap.add_argument("--domain", choices=["error", "artifact"], default="error")
    ap.add_argument("--force", action="store_true",
                    help="promote even if the gain gate fails (ships a worse ranking - be sure)")
    args = ap.parse_args()

    print(f"APP_ENV={config.APP_ENV}")
    if args.revert:
        rc = revert(args.domain)
    elif args.promote:
        rc = promote(args.domain, args.force)
    else:
        return status()
    status()
    return rc


if __name__ == "__main__":
    sys.exit(main())
