"""
Backfill AI summaries for artifacts that have none.

WHY: summarization+embedding at upload was introduced after launch. Artifacts uploaded before
that (and any whose embed call failed at upload) are in S3 + DynamoDB but have NO ChromaDB record,
so the dashboard (get-total-errors) shows an empty summary for them.

WHAT IT DOES: for every artifact reference in DynamoDB whose file is .log/.txt, not a noise file,
and has no ChromaDB artifact record yet:
  1) downloads the raw file from S3 (the original bytes, zipped at upload),
  2) reads the original upload metadata from the S3 object (project/task_path/action/source_folder),
  3) runs it through the EXISTING upload pipeline `handle_artifact_text_embedding`
     (LLM structured summary -> embed -> store in ChromaDB), exactly as a fresh upload would.

It only ADDS missing records — existing summaries are never touched. DynamoDB and S3 are read-only.
Binary (non .log/.txt) files are skipped by design (they are never summarised).

COST: one LLM summary call per backfilled file — run --dry-run first to see the volume.

RUN WITH THE BACKEND STOPPED (single writer to ChromaDB), from the backend folder, in the venv,
with the target .env (APP_ENV):

    python backfill_artifact_summaries.py --dry-run   # count + report only, change nothing
    python backfill_artifact_summaries.py             # backfill
"""
import logging
import os
import sys
import time
from io import BytesIO
from zipfile import ZipFile

import src.utils.log_setup  # noqa: F401
from boto3.dynamodb.conditions import Attr

from src.configurations import config
from src.utils import project_details as pd
from src.utils.payload_archive import get_s3_client, S3_BUCKET
from src.services import handlers

log = logging.getLogger("backfill_summaries")
DRY_RUN = "--dry-run" in sys.argv
SLEEP_MS = max(0, int(os.getenv("BACKFILL_SLEEP_MS", "500")))
# Extra cool-down after a file exhausts its 429 retries (deployment quota saturated).
RATE_LIMIT_COOLDOWN_SEC = max(5, int(os.getenv("BACKFILL_RATE_LIMIT_COOLDOWN_SEC", "60")))
# Per client: files captured from these build source folders get NO summaries (the 'in' folder holds
# build INPUTS, not failure evidence; new captures collect out/log only). The folder is the
# second-to-last segment of the artifact S3 key (.../{action}/[task]/{source}/{file}-{sha}.zip).
EXCLUDED_SOURCE_FOLDERS = {
    p.strip().lower()
    for p in os.getenv("BACKFILL_EXCLUDE_SOURCE_FOLDERS", "in,tmp").split(",") if p.strip()
}
# sha256("")[:12] — the content hash of a ZERO-BYTE file. Old empty artifacts (captured before the
# empty-file guards) are skipped by key alone, no download needed.
EMPTY_CONTENT_SHA12 = "e3b0c44298fc"


def _source_folder_of(s3_key: str) -> str:
    parts = [p for p in str(s3_key or "").split("/") if p]
    return parts[-2].lower() if len(parts) >= 2 else ""


def all_artifact_references() -> list[dict]:
    """Every BINARY#/RUNTIME# artifact reference row in DynamoDB."""
    flt = Attr("SK").begins_with(f"{pd.BINARY_SK}#") | Attr("SK").begins_with(f"{pd.RUNTIME_SK}#")
    rows = pd._scan_all(pd.ai_assisted_data_table, filter_expression=flt)
    log.info("DynamoDB artifact references found: %d", len(rows))
    return rows


def existing_summary_coverage() -> tuple[set[str], set[str]]:
    """(s3_keys, content_sha12s) already covered by a ChromaDB artifact record. The sha set lets us
    treat every duplicate copy of the same file content as already summarised."""
    col = handlers.get_artifact_chroma_collection()
    keys: set[str] = set()
    shas: set[str] = set()
    offset = 0
    page = 5000
    while True:
        res = col.get(include=["metadatas"], limit=page, offset=offset)
        metas = res.get("metadatas") or []
        if not metas:
            break
        for meta in metas:
            if isinstance(meta, dict):
                k = str(meta.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
                if k:
                    keys.add(k)
                sha = str(meta.get("content_sha12") or "").strip().lower() or handlers._sha12_from_s3_key(k)
                if sha:
                    shas.add(sha)
        if len(metas) < page:
            break
        offset += page
    log.info("ChromaDB artifact records cover %d s3_key(s) / %d unique content hash(es)", len(keys), len(shas))
    return keys, shas


def fetch_raw_and_meta(s3_key: str) -> tuple[bytes, dict]:
    """Download the artifact zip and return (original file bytes, S3 object metadata).
    The zip contains exactly the one original file as written at upload."""
    resp = get_s3_client().get_object(Bucket=S3_BUCKET, Key=s3_key)
    body = resp["Body"].read()
    meta = {k.lower(): v for k, v in (resp.get("Metadata") or {}).items()}
    with ZipFile(BytesIO(body), "r") as zf:
        names = zf.namelist()
        raw = zf.read(names[0]) if names else b""
    return raw, meta


def parse_from_key(s3_key: str) -> dict:
    """Fallback when S3 object metadata is absent: recover project/batch from the key layout
    {prefix}/{project}/{env}/{batch}/{action}/[task]/[source]/{file}-{sha12}.zip"""
    parts = [p for p in s3_key.split("/") if p]
    out = {"project_name": "", "batch_id": "", "action": "modified", "source_folder": "", "task_path": ""}
    if len(parts) >= 5:
        out["project_name"] = parts[1]
        out["batch_id"] = parts[3]
        out["action"] = parts[4]
    if len(parts) >= 8:
        out["source_folder"] = parts[-2]
    return out


def main() -> None:
    log.info(
        "BACKFILL start | APP_ENV=%s | collection=%s | bucket=%s | dry_run=%s",
        config.APP_ENV, config.CHROMA_COLLECTION_ARTIFACTS, S3_BUCKET, DRY_RUN,
    )
    log.info("Adds ONLY missing summaries. Existing summaries, DynamoDB and S3 are not modified.")

    refs = all_artifact_references()
    have_keys, have_shas = existing_summary_coverage()

    seen: set[str] = set()
    seen_shas: set[str] = set()
    todo: list[dict] = []
    skipped_not_text = skipped_noise = skipped_have = skipped_duplicate = skipped_in_folder = skipped_empty = 0
    for ref in refs:
        s3_key = str(ref.get("s3_key") or "").strip().rstrip('"').rstrip("%22")
        file_name = str(ref.get("file_name") or "").strip()
        if not s3_key or s3_key in seen:
            continue
        seen.add(s3_key)
        if not handlers._is_semantic_artifact_file(file_name):
            skipped_not_text += 1
            continue
        if handlers._is_noise_artifact_file(file_name):
            skipped_noise += 1
            continue
        if _source_folder_of(s3_key) in EXCLUDED_SOURCE_FOLDERS:
            skipped_in_folder += 1
            continue
        sha = handlers._sha12_from_s3_key(s3_key)
        # Zero-byte files: recognisable from the key's content hash — skip without downloading.
        if sha == EMPTY_CONTENT_SHA12:
            skipped_empty += 1
            continue
        # Cheap pre-filter on the key's 12-char suffix to skip downloads of already-covered content.
        # This is only an optimization: the authoritative, collision-safe dedup is the FULL sha256
        # check inside handle_artifact_text_embedding (which has the real file bytes).
        if s3_key in have_keys or (sha and sha in have_shas):
            skipped_have += 1
            continue
        # Duplicate content within this backfill run (same file uploaded in many builds):
        # summarise the FIRST copy only — every other copy resolves to it via the content hash.
        if sha and sha in seen_shas:
            skipped_duplicate += 1
            continue
        if sha:
            seen_shas.add(sha)
        todo.append({"s3_key": s3_key, "file_name": file_name,
                     "request_id": str(ref.get("request_id") or ""),
                     "artifact_type": str(ref.get("artifact_type") or "runtime")})

    log.info(
        "REPORT | references=%d | already_have_summary=%d | duplicate_content(skipped)=%d | "
        "not_text(skipped)=%d | noise(skipped)=%d | in_folder(skipped)=%d | empty(skipped)=%d | "
        "UNIQUE TO BACKFILL=%d",
        len(seen), skipped_have, skipped_duplicate, skipped_not_text, skipped_noise,
        skipped_in_folder, skipped_empty, len(todo),
    )
    if DRY_RUN:
        for t in todo[:20]:
            log.info("[dry-run] would summarise: %s (%s)", t["file_name"], t["s3_key"])
        if len(todo) > 20:
            log.info("[dry-run] ... and %d more", len(todo) - 20)
        log.info("[dry-run] cost estimate: %d LLM summary call(s). Exiting without changes.", len(todo))
        return

    ok = fail = 0
    started = time.monotonic()
    for i, t in enumerate(todo, 1):
        try:
            raw, s3_meta = fetch_raw_and_meta(t["s3_key"])
            fallback = parse_from_key(t["s3_key"])
            result = handlers.handle_artifact_text_embedding(
                project_name=str(s3_meta.get("project_name") or fallback["project_name"]),
                file_name=t["file_name"],
                file_bytes=raw,
                s3_key=t["s3_key"],
                batch_id=str(s3_meta.get("batch_id") or fallback["batch_id"]),
                request_id=t["request_id"],
                artifact_type=t["artifact_type"],
                action=str(s3_meta.get("action") or fallback["action"]),
                source_folder=str(s3_meta.get("source_folder") or fallback["source_folder"]),
                task_path=str(s3_meta.get("task_path") or fallback["task_path"]),
            )
            if result.get("success"):
                ok += 1
            elif str(result.get("error") or "") == "artifact text is empty":
                # Whitespace-only file (zero-byte ones are pre-skipped by hash) — nothing to
                # summarise; clean skip, not a failure.
                ok += 1
                log.info("[%d/%d] %s skipped — empty content (no failure signal)", i, len(todo), t["file_name"])
            elif result.get("rate_limited"):
                fail += 1
                log.warning("[%d/%d] %s rate-limited (429) — cooling down %ds; re-run later to pick it up",
                            i, len(todo), t["file_name"], RATE_LIMIT_COOLDOWN_SEC)
                time.sleep(RATE_LIMIT_COOLDOWN_SEC)
            else:
                fail += 1
                log.warning("[%d/%d] %s NOT summarised: %s", i, len(todo), t["file_name"],
                            result.get("reason") or result.get("error"))
        except Exception as exc:
            fail += 1
            log.error("[%d/%d] %s FAILED: %s", i, len(todo), t["s3_key"], exc)
        if SLEEP_MS:
            time.sleep(SLEEP_MS / 1000.0)
        if i % 10 == 0 or i == len(todo):
            log.info("progress %d/%d | ok=%d | fail=%d | elapsed=%ds",
                     i, len(todo), ok, fail, int(time.monotonic() - started))

    log.info("BACKFILL done | summarised=%d | failed=%d | total=%d", ok, fail, len(todo))
    if fail:
        log.warning("Failures are safe to re-run: already-summarised files are skipped next time.")


if __name__ == "__main__":
    main()
